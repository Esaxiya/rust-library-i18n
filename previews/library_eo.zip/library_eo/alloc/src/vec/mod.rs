//! Apuda kreskebla tabelspeco kun amas-asignita enhavo, skribita `Vec<T>`.
//!
//! Vectors havas `O(1)`-indeksadon, amortizitan `O(1)`-puŝon (ĝis la fino) kaj `O(1)`-popon (de la fino).
//!
//!
//! Vectors certigas, ke ili neniam asignas pli ol `isize::MAX`-bitokojn.
//!
//! # Examples
//!
//! Vi povas eksplicite krei [`Vec`] per [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... aŭ uzante la [`vec!`]-makroon:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // dek nuloj
//! ```
//!
//! Vi povas [`push`]-valorojn al la fino de vector (kiu kreskigos la vector laŭbezone):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Malplenigi valorojn funkcias laŭ la sama maniero:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors ankaŭ subtenas indeksadon (per la [`Index`] kaj [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Apuda kreskebla tabelspeco, skribita kiel `Vec<T>` kaj prononcita 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// La makroo [`vec!`] estas provizita por faciligi komencigon:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Ĝi ankaŭ povas pravalorizi ĉiun elementon de `Vec<T>` kun donita valoro.
/// Ĉi tio povas esti pli efika ol plenumi atribuon kaj komencigon per apartaj paŝoj, precipe dum pravalorizado de vector de nuloj:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // La sekvaĵo estas ekvivalenta, sed eble pli malrapida:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Por pliaj informoj, vidu [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Uzu `Vec<T>` kiel efika stako:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Presaĵoj 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// La `Vec`-tipo permesas aliri valorojn laŭ indekso, ĉar ĝi efektivigas la [`Index`] trait.Ekzemplo estos pli eksplicita:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // ĝi montros '2'
/// ```
///
/// Tamen atentu: se vi provas aliri indekson, kiu ne estas en la `Vec`, via programaro estos panic!Vi ne povas fari ĉi tion:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Uzu [`get`] kaj [`get_mut`] se vi volas kontroli ĉu la indekso estas en `Vec`.
///
/// # Slicing
///
/// `Vec` povas esti ŝanĝebla.Aliflanke, tranĉaĵoj estas nurlegeblaj objektoj.
/// Por akiri [slice][prim@slice], uzu [`&`].Ekzemplo:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... kaj jen ĉio!
/// // vi ankaŭ povas fari ĝin tiel:
/// let u: &[usize] = &v;
/// // aŭ tiel:
/// let u: &[_] = &v;
/// ```
///
/// En Rust, pli ofte pasas tranĉaĵojn kiel argumentojn anstataŭ vectors kiam vi nur volas doni legan aliron.La samo validas por [`String`] kaj [`&str`].
///
/// # Kapablo kaj reasignado
///
/// La kapablo de vector estas la kvanto de spaco asignita por iuj future-elementoj, kiuj aldoniĝos al la vector.Ĉi tio ne konfuzu kun la *longo* de vector, kiu specifas la nombron de efektivaj elementoj ene de vector.
/// Se la longo de vector superas sian kapablon, ĝia kapablo aŭtomate pliiĝos, sed ĝiaj elementoj devos esti reasignitaj.
///
/// Ekzemple, vector kun kapablo 10 kaj longo 0 estus malplena vector kun spaco por 10 pliaj elementoj.Puŝi 10 aŭ malpli da elementoj al la vector ne ŝanĝos ĝian kapablon aŭ kaŭzos reasignadon.
/// Tamen, se la longo de la vector pliiĝas al 11, ĝi devos reasigni, kio povas esti malrapida.Tial oni rekomendas uzi [`Vec::with_capacity`] kiam ajn eblas por specifi kiom grandan la vector atendas.
///
/// # Guarantees
///
/// Pro sia nekredeble fundamenta naturo, `Vec` donas multajn garantiojn pri sia projektado.Ĉi tio certigas, ke ĝi estas kiel eble plej malmultekosta en la ĝenerala kazo, kaj ke ĝi povas esti ĝuste manipulita laŭ primitivaj manieroj per nesekura kodo.Notu, ke ĉi tiuj garantioj rilatas al nekvalifikita `Vec<T>`.
/// Se aldoniĝas pliaj tipparametroj (ekz. Por subteni kutimajn asignilojn), anstataŭigi iliajn defaŭltojn povas ŝanĝi la konduton.
///
/// Plej fundamente, `Vec` estas kaj ĉiam estos (montrilo, kapacito, longo) triopo.Ne pli, ne malpli.La ordo de ĉi tiuj kampoj estas tute nespecifita, kaj vi devas uzi la taŭgajn metodojn por modifi ĉi tiujn.
/// La montrilo neniam estos nula, do ĉi tiu tipo estas nula-montrila-optimumigita.
///
/// Tamen la montrilo eble ne efektive montras al asignita memoro.
/// Aparte, se vi konstruos `Vec` kun kapacito 0 per [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], aŭ vokante [`shrink_to_fit`] sur malplena Vec, ĝi ne asignos memoron.Simile, se vi stokas nulgrandajn specojn ene de `Vec`, ĝi ne asignos spacon por ili.
/// *Notu, ke ĉi-kaze la `Vec` eble ne raportos [`capacity`] de 0*.
/// `Vec` asignos se kaj nur se [`mem: : grandeco_de::<T>`]`() * capacity()> 0`.
/// Ĝenerale, la atribuaj detaloj de "Vec" estas tre subtilaj-se vi intencas atribui memoron per `Vec` kaj uzi ĝin por io alia (aŭ por transdoni al nesekura kodo, aŭ por konstrui vian propran memore subtenitan kolekton), estu certa por repartigi ĉi tiun memoron per `from_raw_parts` por rekuperi la `Vec` kaj poste faligi ĝin.
///
/// Se `Vec`*havas* asignitan memoron, tiam la memoro, kiun ĝi montras, estas sur la amaso (kiel difinita de la atribuilo Rust estas agordita por uzi defaŭlte), kaj ĝia montrilo montras al [`len`] komencigitaj, apudaj elementoj en ordo (kion vi volus vidu ĉu vi devigis ĝin al tranĉaĵo), sekvata de [`kapacito`]`,`[`len`] logike neiniciigitaj, apudaj elementoj.
///
///
/// vector enhavanta la elementojn `'a'` kaj `'b'` kun kapablo 4 videblas kiel sube.La supra parto estas la `Vec`-strukturo, ĝi enhavas montrilon al la kapo de la atribuo en la amaso, longo kaj kapablo.
/// La malsupra parto estas la atribuo sur la amaso, apuda memora bloko.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** reprezentas memoron ne pravalorizitan, vidu [`MaybeUninit`].
/// - Note: la ABI ne estas stabila kaj `Vec` ne garantias pri sia memora aranĝo (inkluzive la ordon de kampoj).
///
/// `Vec` neniam plenumos "small optimization", kie elementoj estas efektive stokitaj sur la stako pro du kialoj:
///
/// * Pli malfaciligus ke nesekura kodo ĝuste manipulu `Vec`.La enhavo de `Vec` ne havus stabilan adreson se ĝi estus nur movita, kaj estus pli malfacile determini ĉu `Vec` efektive asignis memoron.
///
/// * Ĝi punus la ĝeneralan kazon, kaŭzante aldonan branch ĉe ĉiu aliro.
///
/// `Vec` neniam aŭtomate ŝrumpos sin, eĉ se tute malplena.Ĉi tio certigas, ke ne okazu nenecesaj atribuoj aŭ transdono.Malplenigi `Vec` kaj poste plenigi ĝin ĝis la sama [`len`] devas kaŭzi neniujn alvokojn al la atribuilo.Se vi volas liberigi neuzatan memoron, uzu [`shrink_to_fit`] aŭ [`shrink_to`].
///
/// [`push`] kaj [`insert`] neniam (re) asignos se la raportita kapablo sufiĉas.[`push`] kaj [`insert`]* *(re) asignos se [`len`]`==`[`kapacito`].Tio estas, la raportita kapablo estas tute preciza, kaj oni povas fidi ĝin.Ĝi eĉ povas esti uzata por mane liberigi la memoron asignitan de `Vec` se ĝi deziras.
/// Grandaj enmetaj metodoj *povas* reasigni, eĉ kiam ne necese.
///
/// `Vec` ne garantias iun apartan kreskostrategion dum reasignado kiam plena, nek kiam [`reserve`] estas vokita.La nuna strategio estas baza kaj eble montriĝos dezirinde uzi nekonstantan kreskfaktoron.Kia ajn strategio uzata kompreneble garantios *O*(1) amortizitan [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, kaj [`Vec::with_capacity(n)`][`Vec::with_capacity`], ĉiuj produktos `Vec` kun ĝuste la petita kapablo.
/// Se [`len`]`==`[`kapablo`], (kiel estas la kazo por la [`vec!`]-makroo), tiam `Vec<T>` povas esti transformita al kaj de [`Box<[T]>`][owned slice] sen reasignado aŭ movado de la elementoj.
///
/// `Vec` ne specife anstataŭigos iujn datumojn forigitajn de ĝi, sed ankaŭ ne specife konservos ĝin.Ĝia senpripensa memoro estas nulo, kiun ĝi povas uzi kiel ajn ĝi volas.Ĝi ĝenerale simple faros ĉion plej efikan aŭ alie facile efektivigeblan.Ne fidu forigitajn datumojn por esti forigitaj por sekurecaj celoj.
/// Eĉ se vi faligas `Vec`, ĝia bufro eble simple reuziĝos per alia `Vec`.
/// Eĉ se vi nuligas la memoron de "Vec" unue, tio eble ne efektive okazos, ĉar la optimumigilo ne konsideras ĉi tion kromefike konservenda.
/// Estas unu kazo, kiun ni tamen ne rompos: uzi kodon `unsafe` por skribi al la troa kapablo, kaj poste pliigi la longon por kongrui, ĉiam validas.
///
/// Nuntempe `Vec` ne garantias la ordon en kiu falas elementoj.
/// La ordo ŝanĝiĝis en la pasinteco kaj eble ŝanĝiĝos denove.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Inecaj metodoj
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Konstruas novan, malplenan `Vec<T>`.
    ///
    /// La vector ne atribuos ĝis elementoj enŝoviĝos sur ĝin.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Konstruas novan malplenan `Vec<T>` kun la specifa kapablo.
    ///
    /// La vector povos teni ĝuste `capacity`-elementojn sen reasignado.
    /// Se `capacity` estas 0, vector ne asignos.
    ///
    /// Gravas noti, ke kvankam la redonita vector havas la specifan *kapaciton*, la vector havos nul *longon*.
    ///
    /// Por klarigo pri la diferenco inter longo kaj kapablo, vidu *[Kapacito kaj reasignado]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // La vector enhavas neniujn erojn, kvankam ĝi havas kapablon por pli
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Ĉi tiuj estas faritaj sen reasignado ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... sed ĉi tio eble igos vector reasigni
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Kreas `Vec<T>` rekte de la krudaj eroj de alia vector.
    ///
    /// # Safety
    ///
    /// Ĉi tio estas tre nesekura, pro la nombro de neŝanĝeblaj neŝanĝeblaj:
    ///
    /// * `ptr` devas esti antaŭe asignita per [`String`]/`Vec<T>`(almenaŭ, tre verŝajne estos malĝusta se ĝi ne estus).
    /// * `T` devas havi la saman grandecon kaj vicigon kiel kun kio `ptr` estis asignita.
    ///   (`T` havanta malpli striktan vicigon ne sufiĉas, la vicigo vere devas esti egala por kontentigi la [`dealloc`]-postulon, ke memoro devas esti asignita kaj dislokigita kun la sama aranĝo.)
    ///
    /// * `length` devas esti malpli ol aŭ egala al `capacity`.
    /// * `capacity` devas esti la kapablo kun kiu la montrilo estis asignita.
    ///
    /// Malobservi ĉi tiujn povas kaŭzi problemojn kiel korupti la internajn datumajn strukturojn de la atribuilo.Ekzemple estas **ne** sekure konstrui `Vec<u8>` de montrilo al C `char`-tabelo kun longo `size_t`.
    /// Ankaŭ ne estas sekure konstrui unu de `Vec<u16>` kaj ĝia longo, ĉar la asignilo zorgas pri la vicigo, kaj ĉi tiuj du tipoj havas malsamajn vicojn.
    /// La bufro estis asignita kun vicigo 2 (por `u16`), sed post igi ĝin `Vec<u8>` ĝi estos dislokigita kun vicigo 1.
    ///
    /// La posedo de `ptr` estas efike transdonita al la `Vec<T>`, kiu tiam povas transdoni, reasigni aŭ ŝanĝi la enhavon de memoro montrita de la montrilo laŭplaĉe.
    /// Certigu, ke nenio alia uzas la montrilon post nomi ĉi tiun funkcion.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Ĝisdatigu ĉi tion kiam vec_into_raw_parts estas stabiligita.
    ///     // Malhelpu lanĉi detruilon de `v`, do ni regas la atribuon.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Elprenu la diversajn gravajn informojn pri `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Anstataŭigi memoron per 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Remetu ĉion en Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Konstruas novan, malplenan `Vec<T, A>`.
    ///
    /// La vector ne atribuos ĝis elementoj enŝoviĝos sur ĝin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Konstruas novan, malplenan `Vec<T, A>` kun la specifa kapablo per la provizita asignilo.
    ///
    /// La vector povos teni ĝuste `capacity`-elementojn sen reasignado.
    /// Se `capacity` estas 0, vector ne asignos.
    ///
    /// Gravas noti, ke kvankam la redonita vector havas la specifan *kapaciton*, la vector havos nul *longon*.
    ///
    /// Por klarigo pri la diferenco inter longo kaj kapablo, vidu *[Kapacito kaj reasignado]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // La vector enhavas neniujn erojn, kvankam ĝi havas kapablon por pli
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Ĉi tiuj estas faritaj sen reasignado ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... sed ĉi tio eble igos vector reasigni
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Kreas `Vec<T, A>` rekte de la krudaj eroj de alia vector.
    ///
    /// # Safety
    ///
    /// Ĉi tio estas tre nesekura, pro la nombro de neŝanĝeblaj neŝanĝeblaj:
    ///
    /// * `ptr` devas esti antaŭe asignita per [`String`]/`Vec<T>`(almenaŭ, tre verŝajne estos malĝusta se ĝi ne estus).
    /// * `T` devas havi la saman grandecon kaj vicigon kiel kun kio `ptr` estis asignita.
    ///   (`T` havanta malpli striktan vicigon ne sufiĉas, la vicigo vere devas esti egala por kontentigi la [`dealloc`]-postulon, ke memoro devas esti asignita kaj dislokigita kun la sama aranĝo.)
    ///
    /// * `length` devas esti malpli ol aŭ egala al `capacity`.
    /// * `capacity` devas esti la kapablo kun kiu la montrilo estis asignita.
    ///
    /// Malobservi ĉi tiujn povas kaŭzi problemojn kiel korupti la internajn datumajn strukturojn de la atribuilo.Ekzemple estas **ne** sekure konstrui `Vec<u8>` de montrilo al C `char`-tabelo kun longo `size_t`.
    /// Ankaŭ ne estas sekure konstrui unu de `Vec<u16>` kaj ĝia longo, ĉar la asignilo zorgas pri la vicigo, kaj ĉi tiuj du tipoj havas malsamajn vicojn.
    /// La bufro estis asignita kun vicigo 2 (por `u16`), sed post igi ĝin `Vec<u8>` ĝi estos dislokigita kun vicigo 1.
    ///
    /// La posedo de `ptr` estas efike transdonita al la `Vec<T>`, kiu tiam povas transdoni, reasigni aŭ ŝanĝi la enhavon de memoro montrita de la montrilo laŭplaĉe.
    /// Certigu, ke nenio alia uzas la montrilon post nomi ĉi tiun funkcion.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Ĝisdatigu ĉi tion kiam vec_into_raw_parts estas stabiligita.
    ///     // Malhelpu lanĉi detruilon de `v`, do ni regas la atribuon.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Elprenu la diversajn gravajn informojn pri `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Anstataŭigi memoron per 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Remetu ĉion en Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Malkonstruas `Vec<T>` en ĝiajn krudajn erojn.
    ///
    /// Redonas la krudan montrilon al la subaj datumoj, la longo de la vector (en elementoj) kaj la asignita kapablo de la datumoj (en elementoj).
    /// Ĉi tiuj estas la samaj argumentoj en la sama ordo kiel la argumentoj al [`from_raw_parts`].
    ///
    /// Nominte ĉi tiun funkcion, la alvokanto respondecas pri la memoro antaŭe administrita de la `Vec`.
    /// La sola maniero fari tion estas konverti la krudan montrilon, longon kaj kapaciton en `Vec` kun la funkcio [`from_raw_parts`], permesante al la detruanto plenumi la purigadon.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Ni nun povas fari ŝanĝojn al la komponantoj, kiel ekzemple transmutado de la kruda montrilo al kongrua tipo.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Malkonstruas `Vec<T>` en ĝiajn krudajn erojn.
    ///
    /// Redonas la krudan montrilon al la subaj datumoj, la longo de la vector (en elementoj), la asignita kapablo de la datumoj (en elementoj) kaj la atribuilo.
    /// Ĉi tiuj estas la samaj argumentoj en la sama ordo kiel la argumentoj al [`from_raw_parts_in`].
    ///
    /// Nominte ĉi tiun funkcion, la alvokanto respondecas pri la memoro antaŭe administrita de la `Vec`.
    /// La sola maniero fari tion estas konverti la krudan montrilon, longon kaj kapaciton en `Vec` kun la funkcio [`from_raw_parts_in`], permesante al la detruanto plenumi la purigadon.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Ni nun povas fari ŝanĝojn al la komponantoj, kiel ekzemple transmutado de la kruda montrilo al kongrua tipo.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Liveras la nombron da elementoj kiujn la vector povas teni sen reasignado.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Rezervas kapaciton por almenaŭ `additional` pliaj elementoj enmetotaj en la donita `Vec<T>`.
    /// La kolekto eble rezervos pli da spaco por eviti oftajn reasignojn.
    /// Post voki `reserve`, kapacito estos pli granda aŭ egala al `self.len() + additional`.
    /// Faras nenion se kapablo jam sufiĉas.
    ///
    /// # Panics
    ///
    /// Panics se la nova kapablo superas `isize::MAX`-bitokojn.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Rezervas la minimuman kapaciton por ekzakte `additional` pli da elementoj enmetotaj en la donita `Vec<T>`.
    ///
    /// Post voki `reserve_exact`, kapacito estos pli granda aŭ egala al `self.len() + additional`.
    /// Faras nenion se la kapablo jam sufiĉas.
    ///
    /// Notu, ke la asignilo eble donas al la kolekto pli da spaco ol ĝi petas.
    /// Sekve, oni ne povas fidi, ke kapablo estas precize minimuma.
    /// Preferu `reserve` se future-enmetoj estas atendataj.
    ///
    /// # Panics
    ///
    /// Panics se la nova kapablo superfluas `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Provas rezervi kapaciton por almenaŭ `additional` pli da elementoj enmetotaj en la donita `Vec<T>`.
    /// La kolekto eble rezervos pli da spaco por eviti oftajn reasignojn.
    /// Post voki `try_reserve`, kapacito estos pli granda aŭ egala al `self.len() + additional`.
    /// Faras nenion se kapablo jam sufiĉas.
    ///
    /// # Errors
    ///
    /// Se la kapacito superfluas, aŭ la asignilo raportas fiaskon, tiam eraro revenas.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Antaŭ-rezervu la memoron, elirante se ni ne povas
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nun ni scias, ke ĉi tio ne povas OOM meze de nia kompleksa laboro
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // tre komplika
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Provas rezervi la minimuman kapaciton por ekzakte `additional`-elementoj enmetotaj en la donita `Vec<T>`.
    /// Post voki `try_reserve_exact`, kapacito estos pli granda aŭ egala al `self.len() + additional` se ĝi redonos `Ok(())`.
    ///
    /// Faras nenion se la kapablo jam sufiĉas.
    ///
    /// Notu, ke la asignilo eble donas al la kolekto pli da spaco ol ĝi petas.
    /// Sekve, oni ne povas fidi, ke kapablo estas precize minimuma.
    /// Preferu `reserve` se future-enmetoj estas atendataj.
    ///
    /// # Errors
    ///
    /// Se la kapacito superfluas, aŭ la asignilo raportas fiaskon, tiam eraro revenas.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Antaŭ-rezervu la memoron, elirante se ni ne povas
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Nun ni scias, ke ĉi tio ne povas OOM meze de nia kompleksa laboro
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // tre komplika
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Ŝrumpas la kapablon de la vector laŭeble.
    ///
    /// Ĝi falos kiel eble plej proksime al la longo, sed la asignilo eble ankoraŭ informos vector, ke estas spaco por kelkaj pliaj elementoj.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // La kapablo neniam estas malpli ol la longo, kaj estas nenio farebla kiam ili egalas, do ni povas eviti la kazon panic en `RawVec::shrink_to_fit` nur nomante ĝin kun pli granda kapablo.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Malpligrandigas la kapablon de la vector kun malsupra rando.
    ///
    /// La kapablo restos almenaŭ same granda kiel la longo kaj la provizita valoro.
    ///
    ///
    /// Se la nuna kapablo estas malpli ol la suba limo, ĉi tio estas senoperacio.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Konvertas la vector en [`Box<[T]>`][owned slice].
    ///
    /// Notu, ke ĉi tio faligos iun ajn troan kapaciton.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Ĉiu troa kapablo estas forigita:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Mallongigas la vector, konservante la unuajn `len`-elementojn kaj faligante la reston.
    ///
    /// Se `len` estas pli granda ol la aktuala longo de vector, ĉi tio ne efikas.
    ///
    /// La [`drain`]-metodo povas kopii `truncate`, sed kaŭzas ke la troaj elementoj estu redonitaj anstataŭ faligitaj.
    ///
    ///
    /// Notu, ke ĉi tiu metodo ne efikas sur la asignita kapablo de la vector.
    ///
    /// # Examples
    ///
    /// Tranĉante kvin elementon vector al du elementoj:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Neniu detranĉo okazas kiam `len` estas pli granda ol la nuna longo de la vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Tranĉi kiam `len == 0` estas ekvivalenta al voki la [`clear`]-metodon.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Ĉi tio estas sekura ĉar:
        //
        // * la tranĉaĵo transdonita al `drop_in_place` validas;la `len > self.len`-kazo evitas krei nevalidan tranĉaĵon, kaj
        // * la `len` de la vector malpliiĝas antaŭ voki `drop_in_place`, tiel ke neniu valoro falos dufoje en kazo `drop_in_place` estus panic unufoje (se ĝi panics dufoje, la programo ĉesigas).
        //
        //
        //
        unsafe {
            // Note: Estas intence, ke ĉi tio estas `>` kaj ne `>=`.
            //       Ŝanĝi ĝin al `>=` havas negativajn efikojn en iuj kazoj.
            //       Vidu #78884 por pli.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Eltiras tranĉaĵon enhavantan la tutan vector.
    ///
    /// Ekvivalenta al `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Eltiras ŝanĝeblan tranĉaĵon de la tuta vector.
    ///
    /// Ekvivalenta al `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Redonas krudan montrilon al la bufro de vector.
    ///
    /// La alvokanto devas certigi, ke vector superas la montrilon, kiun ĉi tiu funkcio redonas, alie ĝi finos montrante rubon.
    /// Modifi la vector povas kaŭzi reaklokigon de sia bufro, kio ankaŭ malvalidigus iujn indikojn al ĝi.
    ///
    /// La alvokanto devas ankaŭ certigi, ke la memoro al kiu montras la montrilo (non-transitively) neniam estas skribita (krom ene de `UnsafeCell`) per ĉi tiu montrilo aŭ iu ajn montrilo derivita de ĝi.
    /// Se vi bezonas mutigi la enhavon de la tranĉaĵo, uzu [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Ni ombras la tranĉan samnoman metodon por eviti trakti `deref`, kiu kreas mezan referencon.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Redonas nesekuran ŝanĝeblan montrilon al la bufro de vector.
    ///
    /// La alvokanto devas certigi, ke vector superas la montrilon, kiun ĉi tiu funkcio redonas, alie ĝi finos montrante rubon.
    ///
    /// Modifi la vector povas kaŭzi reaklokigon de sia bufro, kio ankaŭ malvalidigus iujn indikojn al ĝi.
    ///
    /// # Examples
    ///
    /// ```
    /// // Asigni vector sufiĉe grandan por 4 elementoj.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Komencu elementojn per krudaj montriloj, tiam starigu longon.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Ni ombras la tranĉan samnoman metodon por eviti trakti `deref_mut`, kiu kreas mezan referencon.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Liveras referencon al la suba atribuilo.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Devigas la longon de la vector al `new_len`.
    ///
    /// Ĉi tio estas malaltnivela operacio, kiu konservas neniun el la normalaj invariantoj de la tipo.
    /// Normale ŝanĝi la longon de vector fariĝas anstataŭe uzante unu el la sekuraj operacioj, kiel [`truncate`], [`resize`], [`extend`] aŭ [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` devas esti malpli ol aŭ egala al [`capacity()`].
    /// - La elementoj ĉe `old_len..new_len` devas esti pravalorizitaj.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Ĉi tiu metodo povas esti utila por situacioj, en kiuj vector funkcias kiel bufro por alia kodo, precipe super FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Ĉi tio estas nur minimuma skeleto por la doc-ekzemplo;
    /// # // ne uzu ĉi tion kiel deirpunkton por vera biblioteko.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Laŭ la dokumentoj de la FFI-metodo, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SEKURECO: Kiam `deflateGetDictionary` redonas `Z_OK`, ĝi diras, ke:
    ///     // 1. `dict_length` elementoj estis pravalorizitaj.
    ///     // 2.
    ///     // `dict_length` <=la kapablo (32_768), kiu igas `set_len` sekura telefoni.
    ///     unsafe {
    ///         // Fari la FFI-vokon ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... kaj ĝisdatigu la longon al tio, kio estis pravalorizita.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Dum la sekva ekzemplo sonas, ekzistas memora likado ĉar la internaj vectors ne estis liberigitaj antaŭ la `set_len`-alvoko:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` estas malplena do neniuj elementoj devas esti pravalorizitaj.
    /// // 2. `0 <= capacity` ĉiam tenas kio ajn `capacity` estas.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Kutime ĉi tie oni anstataŭe uzus [`clear`] por ĝuste faligi la enhavon kaj tiel ne liki memoron.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Forigas elementon de la vector kaj redonas ĝin.
    ///
    /// La forigita elemento estas anstataŭigita per la lasta elemento de la vector.
    ///
    /// Ĉi tio ne konservas mendadon, sed estas O(1).
    ///
    /// # Panics
    ///
    /// Panics se `index` estas ekster limoj.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Ni anstataŭigas mem [indekso] per la lasta elemento.
            // Notu, ke se la limo-kontrolo supre sukcesas, devas esti lasta elemento (kiu povas esti mem [indekso] mem).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Enmetas elementon ĉe pozicio `index` ene de la vector, movante ĉiujn elementojn post ĝi dekstren.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // spaco por la nova elemento
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // senerara La loko por doni novan valoron
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Ŝanĝu ĉion por fari spacon.
                // (Duplikante la `index`th-elementon en du sinsekvajn lokojn.)
                ptr::copy(p, p.offset(1), len - index);
                // Skribu ĝin, anstataŭigante la unuan kopion de la `index`-a elemento.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Forigas kaj redonas la elementon ĉe pozicio `index` ene de vector, movante ĉiujn elementojn post ĝi maldekstren.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `index` estas ekster limoj.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // la loko, de kiu ni prenas.
                let ptr = self.as_mut_ptr().add(index);
                // kopiu ĝin, malsekure havante kopion de la valoro sur la stako kaj en la vector samtempe.
                //
                ret = ptr::read(ptr);

                // Ŝovu ĉion malsupren por plenigi tiun lokon.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Konservas nur la elementojn specifitajn de la predikato.
    ///
    /// Alivorte, forigu ĉiujn elementojn `e` tiel ke `f(&e)` redonu `false`.
    /// Ĉi tiu metodo funkcias modloko, vizitante ĉiun elementon ekzakte unufoje en la originala ordo, kaj konservas la ordon de la konservitaj elementoj.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Ĉar la elementoj estas vizititaj ekzakte unufoje en la originala ordo, ekstera stato povas esti uzata por decidi kiujn elementojn konservi.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Evitu duoblan falon se la faligilo ne estas efektivigita, ĉar ni eble faros iujn truojn dum la procezo.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-prilaborita len-> |^-apud kontrolo
        //                  | <-forigita cnt-> |
        //      | <-original_len-> |Konservita: Elementoj sur kiuj predikato revenas vera.
        //
        // Truo: Movita aŭ faligita elemento-fendo.
        // Nekontrolita: Nekontrolitaj validaj elementoj.
        //
        // Ĉi tiu faligilo estos alvokita kiam predikato aŭ `drop` de elemento panikiĝos.
        // Ĝi ŝanĝas nemontritajn elementojn por kovri truojn kaj `set_len` al la ĝusta longo.
        // En kazoj, kiam predikato kaj `drop` neniam panikiĝas, ĝi estos plibonigita.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SEKURECO: Sekvi nekontrolitajn erojn devas esti validaj ĉar ni neniam tuŝas ilin.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SEKURECO: Post plenigado de truoj, ĉiuj aĵoj estas en apuda memoro.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SEKURECO: Nekontrolita elemento devas esti valida.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Antaŭeniru frue por eviti duoblan falon se `drop_in_place` panikiĝos.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SEKURECO: Ni neniam plu tuŝas ĉi tiun elementon post falo.
                unsafe { ptr::drop_in_place(cur) };
                // Ni jam antaŭenigis la vendotablon.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SEKURECO: `deleted_cnt`> 0, do la trua fendo ne devas interkovri kun aktuala elemento.
                // Ni uzas kopion por movo, kaj neniam plu tuŝas ĉi tiun elementon.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Ĉiuj eroj estas prilaboritaj.Ĉi tio povas esti optimumigita al `set_len` per LLVM.
        drop(g);
    }

    /// Forigas ĉiujn krom sinsekvaj elementoj en la vector, kiuj solvas al la sama ŝlosilo.
    ///
    ///
    /// Se la vector estas ordigita, ĉi tio forigas ĉiujn duplikatojn.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Forigas ĉiujn krom la unuajn sinsekvajn elementojn en la vektor kontentigante donitan egalecan rilaton.
    ///
    /// La funkcio `same_bucket` ricevas referencojn al du elementoj de la vector kaj devas determini ĉu la elementoj egalas.
    /// La elementoj estas pasitaj laŭ kontraŭa ordo de sia ordo en la tranĉaĵo, do se `same_bucket(a, b)` redonas `true`, `a` estas forigita.
    ///
    ///
    /// Se la vector estas ordigita, ĉi tio forigas ĉiujn duplikatojn.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Aldonas elementon al la malantaŭo de kolekto.
    ///
    /// # Panics
    ///
    /// Panics se la nova kapablo superas `isize::MAX`-bitokojn.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Ĉi tio panic aŭ ĉesos se ni asignus> isize::MAX-bitokojn aŭ se la longokvanto pligrandiĝus por nulgrandaj specoj.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Forigas la lastan elementon de vector kaj redonas ĝin, aŭ [`None`] se ĝi estas malplena.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Movas ĉiujn elementojn de `other` en `Self`, lasante `other` malplena.
    ///
    /// # Panics
    ///
    /// Panics se la nombro da elementoj en la vector superverŝas `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Aldonas elementojn al `Self` de alia bufro.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Kreas malplenigan ripeton, kiu forigas la specifitan gamon en la vector kaj donas la forigitajn erojn.
    ///
    /// Kiam la ripeto **estas** faligita, ĉiuj elementoj en la gamo estas forigitaj de la vector, eĉ se la ripeto ne estis plene konsumita.
    /// Se la ripeto **ne** falas (kun [`mem::forget`] ekzemple), estas nespecifite kiom da elementoj estas forigitaj.
    ///
    /// # Panics
    ///
    /// Panics se la komenca punkto estas pli granda ol la fina punkto aŭ se la fina punkto estas pli granda ol la longo de la vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Plena gamo malplenigas la vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Memora sekureco
        //
        // Kiam la Drain unue estas kreita, ĝi mallongigas la longon de la fonto vector por certigi, ke neniuj neinicialigitaj aŭ movitaj elementoj tute ne estas alireblaj se la detruilo de Drain neniam funkcias.
        //
        //
        // Drain ptr::read eligos la forigeblajn valorojn.
        // Fininte, restanta vosto de la vec estas kopiita reen por kovri la truon, kaj la vector-longo reestiĝas al la nova longo.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // starigu self.vec-longon por komenci, por esti sekura en la kazo, ke Drain elfluos
            self.set_len(start);
            // Uzu la prunton en la IterMut por indiki pruntan konduton de la tuta Drain-ripetilo (kiel &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Forigas vector, forigante ĉiujn valorojn.
    ///
    /// Notu, ke ĉi tiu metodo ne efikas sur la asignita kapablo de la vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Liveras la nombron da elementoj en la vector, ankaŭ nomata ĝia 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Liveras `true` se vector enhavas neniujn elementojn.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Disigas la kolekton en du ĉe la donita indekso.
    ///
    /// Liveras nove asignitan vector enhavantan la elementojn en la gamo `[at, len)`.
    /// Post la alvoko, la originala vector restos enhavanta la elementojn `[0, at)` kun sia antaŭa kapablo senŝanĝa.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // la nova vector povas transpreni la originalan bufron kaj eviti la kopion
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Malsekure `set_len` kaj kopiu erojn al `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Regrandigas la `Vec` surloke tiel ke `len` egalas al `new_len`.
    ///
    /// Se `new_len` estas pli granda ol `len`, la `Vec` pligrandiĝas per la diferenco, kun ĉiu aldona fendo plenigita per la rezulto de nomi la fermon `f`.
    ///
    /// La revenaj valoroj de `f` finiĝos en la `Vec` laŭ la ordo, kiun ili generis.
    ///
    /// Se `new_len` estas malpli ol `len`, la `Vec` estas simple detranĉita.
    ///
    /// Ĉi tiu metodo uzas fermon por krei novajn valorojn ĉe ĉiu puŝo.Se vi preferas [`Clone`] donitan valoron, uzu [`Vec::resize`].
    /// Se vi volas uzi la [`Default`] trait por generi valorojn, vi povas pasi [`Default::default`] kiel la dua argumento.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Konsumas kaj likas la `Vec`, redonante ŝanĝeblan referencon al la enhavo, `&'a mut [T]`.
    /// Notu, ke la tipo `T` devas postvivi la elektitan vivdaŭron `'a`.
    /// Se la tipo havas nur statikajn referencojn, aŭ entute neniujn, tiam ĉi tiu elekteblas esti `'static`.
    ///
    /// Ĉi tiu funkcio similas al la [`leak`][Box::leak]-funkcio sur [`Box`] krom ke ekzistas neniu maniero retrovi la likitan memoron.
    ///
    ///
    /// Ĉi tiu funkcio estas ĉefe utila por datumoj, kiuj vivas dum la resto de la vivo de la programo.
    /// Faligi la redonitan referencon kaŭzos memoron.
    ///
    /// # Examples
    ///
    /// Simpla uzado:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Redonas la restantan rezervan kapaciton de la vector kiel tranĉaĵo `MaybeUninit<T>`.
    ///
    /// La redonita tranĉaĵo povas esti uzata por plenigi la vector per datumoj (ekz
    /// per legado de dosiero) antaŭ ol marki la datumojn kiel komencitajn per la [`set_len`]-metodo.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Asigni vector sufiĉe grandan por 10 elementoj.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Plenigu la unuajn 3 elementojn.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Marku la unuajn 3 elementojn de la vector kiel pravalorizitaj.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Ĉi tiu metodo ne estas efektivigita laŭ `split_at_spare_mut`, por malebligi nuligon de montriloj al la bufro.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Redonas enhavon de vector kiel tranĉaĵo `T`, kune kun la restanta rezerva kapablo de vector kiel tranĉaĵo `MaybeUninit<T>`.
    ///
    /// La redonita rezervokapacita tranĉaĵo povas esti uzata por plenigi la vector per datumoj (ekz. Per legado de dosiero) antaŭ ol marki la datumojn kiel inicialigitaj per la [`set_len`]-metodo.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Rimarku, ke temas pri malalta nivela API, kiu devas esti uzata zorge por optimumigaj celoj.
    /// Se vi bezonas aldoni datumojn al `Vec`, vi povas uzi [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] aŭ [`resize_with`], depende de viaj ĝustaj bezonoj.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Rezervu plian spacon sufiĉe grandan por 10 elementoj.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Plenigu la sekvajn 4 elementojn.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Marku la 4 elementojn de la vector kiel pravalorizitaj.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len estas ignorata kaj do neniam ŝanĝita
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Sekureco: ŝanĝi redonitan .2 (uzokutimo de &mut) estas konsiderata same kiel voki `.set_len(_)`.
    ///
    /// Ĉi tiu metodo kutimas havi unikan aliron al ĉiuj vec-partoj samtempe en `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` estas garantiita esti valida por `len`-elementoj
        // - `spare_ptr` montras unu elementon preter la bufro, do ĝi ne interkovras kun `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Regrandigas la `Vec` surloke tiel ke `len` egalas al `new_len`.
    ///
    /// Se `new_len` estas pli granda ol `len`, la `Vec` plilongiĝas per la diferenco, kun ĉiu plia fendo plenigita per `value`.
    ///
    /// Se `new_len` estas malpli ol `len`, la `Vec` estas simple detranĉita.
    ///
    /// Ĉi tiu metodo postulas `T` efektivigi [`Clone`], por povi kloni la pasitan valoron.
    /// Se vi bezonas pli da fleksebleco (aŭ volas fidi je [`Default`] anstataŭ [`Clone`]), uzu [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Klonas kaj aldonas ĉiujn elementojn en tranĉaĵo al la `Vec`.
    ///
    /// Ripetas super la tranĉaĵo `other`, klonas ĉiun elementon, kaj poste aldonas ĝin al ĉi tiu `Vec`.
    /// La `other` vector estas trairita en ordo.
    ///
    /// Notu, ke ĉi tiu funkcio samas kiel [`extend`] krom ke ĝi estas specialigita por labori kun tranĉaĵoj anstataŭe.
    ///
    /// Se kaj kiam Rust specialiĝos, ĉi tiu funkcio probable estos malaktuala (sed ankoraŭ disponebla).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kopias elementojn de `src`-gamo ĝis la fino de la vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garantias, ke la donita intervalo validas por indeksi mem
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Ĉi tiu kodo ĝeneraligas `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Etendu la vector per `n`-valoroj, uzante la donitan generatoron.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Uzu SetLenOnDrop por prilabori cimon kie kompililo eble ne realigas la butikon per `ptr` tra self.set_len() ne kaŝnomo.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Skribu ĉiujn elementojn krom la lasta
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Pliigu la longon en ĉiu paŝo, se next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Ni povas skribi la lastan elementon rekte sen klonado senbezone
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len starigita de amplekso-gardisto
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Forigas sinsekvajn ripetajn elementojn en la vector laŭ la efektivigo de [`PartialEq`] trait.
    ///
    ///
    /// Se la vector estas ordigita, ĉi tio forigas ĉiujn duplikatojn.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Internaj metodoj kaj funkcioj
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` bezonas esti valida indekso
    /// - `self.capacity() - self.len()` devas esti `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len pliiĝas nur post pravalorizado de elementoj
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - vokanto garantias, ke src estas valida indekso
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Elemento ĵus estis pravalorizita per `MaybeUninit::write`, do estas bone pliigi lenon
            // - len pliiĝas post ĉiu elemento por malebligi likojn (vidu numeron #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - telefonanto garantias, ke `src` estas valida indekso
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Ambaŭ montriloj estas kreitaj el unikaj tranĉaj referencoj (`&mut [_]`) do ili validas kaj ne interkovras.
            //
            // - Elementoj estas: Kopii do estas bone kopii ilin, sen fari ion ajn kun la originalaj valoroj
            // - `count` estas egala al la len de `source`, do fonto validas por legoj de `count`
            // - `.reserve(count)` garantias, ke `spare.len() >= count` tiel rezerva validas por `count` skribas
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - La elementoj ĵus estis pravalorizitaj de `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Oftaj trait-efektivigoj por Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): kun cfg(test) la eneca `[T]::to_vec`-metodo, necesa por ĉi tiu metododifino, ne haveblas.
    // Anstataŭe uzu la `slice::to_vec`-funkcion, kiu nur haveblas kun cfg(test) NB. Vidu la slice::hack-modulon en slice.rs por pli da informoj.
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // faligu ĉion, kio ne estos anstataŭigita
        self.truncate(other.len());

        // self.len <= other.len pro la supera detranĉado, do la tranĉaĵoj ĉi tie ĉiam estas enlimaj.
        //
        let (init, tail) = other.split_at(self.len());

        // reuzu la enhavitajn valorojn allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Kreas konsumantan ripetilon, tio estas unu, kiu movas ĉiun valoron el la vector (de komenco ĝis fino).
    /// La vector ne uzeblas post voki ĉi tion.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s havas tipon String, ne &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // folia metodo al kiu diversaj SpecFrom/SpecExtend-efektivigoj delegas kiam ili ne havas pliajn optimumigojn por apliki
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Ĉi tio estas la kazo por ĝenerala ripetilo.
        //
        // Ĉi tiu funkcio devas esti la morala ekvivalento de:
        //
        //      por ero en ripeto {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB ne povas superflui, ĉar ni devintus asigni la adresan spacon
                self.set_len(len + 1);
            }
        }
    }

    /// Kreas kunplanan ripeton, kiu anstataŭigas la specifan gamon en la vector per la donita `replace_with`-ripeto kaj donas la forigitajn erojn.
    ///
    /// `replace_with` ne bezonas la saman longon kiel `range`.
    ///
    /// `range` estas forigita eĉ se la ripetilo ne konsumiĝas ĝis la fino.
    ///
    /// Estas nespecifita, kiom da elementoj estas forigitaj de la vector se la `Splice`-valoro estas likita.
    ///
    /// La eniga ripetilo `replace_with` konsumiĝas nur kiam la `Splice`-valoro falas.
    ///
    /// Ĉi tio estas optimuma se:
    ///
    /// * La vosto (elementoj en la vector post `range`) estas malplena,
    /// * aŭ `replace_with` donas malpli aŭ egalajn elementojn ol la longo de 'gamo'
    /// * aŭ la malsupra rando de ĝia `size_hint()` estas ĝusta.
    ///
    /// Alie, provizora vector estas asignita kaj la vosto moviĝas dufoje.
    ///
    /// # Panics
    ///
    /// Panics se la komenca punkto estas pli granda ol la fina punkto aŭ se la fina punkto estas pli granda ol la longo de la vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Kreas ripeton, kiu uzas fermon por determini ĉu elemento devas esti forigita.
    ///
    /// Se la fermo revenas vera, tiam la elemento estas forigita kaj cedita.
    /// Se la fermo revenas falsa, la elemento restos en la vektoro kaj ne estos donita de la ripetilo.
    ///
    /// Uzi ĉi tiun metodon ekvivalentas al la sekva kodo:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // via kodo ĉi tie
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Sed `drain_filter` estas pli facile uzebla.
    /// `drain_filter` estas ankaŭ pli efika, ĉar ĝi povas retroŝanĝi la elementojn de la tabelo grandparte.
    ///
    /// Notu, ke `drain_filter` ankaŭ permesas mutacii ĉiun elementon en la filtrila fermo, sendepende de tio, ĉu vi elektas konservi aŭ forigi ĝin.
    ///
    ///
    /// # Examples
    ///
    /// Dividante tabelon en egalajn kaj probablajn, reuzante la originalan atribuon:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Gardu nin, ke ni elfluiĝu (amplifo de liko)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Etendu efektivigon, kiu kopias elementojn el referencoj antaŭ puŝi ilin al la Vec.
///
/// Ĉi tiu efektivigo estas specialigita por tranĉaĵaj ripetiloj, kie ĝi uzas [`copy_from_slice`] por almeti la tutan tranĉaĵon samtempe.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Efektivigas komparon de vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Efektivigas mendadon de vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // uzu guton por [T] uzu krudan tranĉaĵon por nomi la elementojn de la vector kiel la plej malforta necesa tipo;
            //
            // povus eviti validajn demandojn en iuj kazoj
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec traktas interkonsenton
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Kreas malplenan `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: testo ekas libstd, kio kaŭzas erarojn ĉi tie
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: testo ekas libstd, kio kaŭzas erarojn ĉi tie
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Akiras la tutan enhavon de la `Vec<T>` kiel tabelo, se ĝia grandeco ĝuste kongruas kun tiu de la petita tabelo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Se la longo ne kongruas, la enigo revenas en `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Se vi fartas nur kun akiri prefikson de la `Vec<T>`, vi unue povas telefoni al [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SEKURECO: `.set_len(0)` ĉiam sonas.
        unsafe { vec.set_len(0) };

        // SEKURECO: Montrilo de "Vec" estas ĉiam ĝuste vicigita, kaj
        // la vicigo, kiun la tabelo bezonas, samas al la eroj.
        // Ni kontrolis pli frue, ke ni havas sufiĉajn erojn.
        // La aĵoj ne falos duoble, ĉar la `set_len` diras al la `Vec`, ke ili ankaŭ ne faligu ilin.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}