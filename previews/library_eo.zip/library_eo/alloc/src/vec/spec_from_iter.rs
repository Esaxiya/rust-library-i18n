use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specialiĝo trait uzata por Vec::from_iter
///
/// ## La delegacia grafeo:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Ofta kazo estas transdoni vector en funkcion, kiu tuj rekolektas en vector.
        // Ni povas fuŝkontakti ĉi tion se la IntoIter tute ne progresis.
        // Kiam ĝi estas progresinta Ni ankaŭ povas reuzi la memoron kaj movi la datumojn al la fronto.
        // Sed ni faras tion nur kiam la rezulta Vec ne havus pli neuzatan kapablon ol kreus ĝin per la ĝenerala FromIterator-efektivigo.
        //
        // Tiu limigo ne strikte necesas, ĉar la asignokonduto de Vec estas intence nespecifita.
        // Sed ĝi estas konservativa elekto.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // devas delegi al spec_extend() ĉar extend() mem delegas al spec_from por malplenaj Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Ĉi tio uzas `iterator.as_slice().to_vec()` ĉar spec_extend devas fari pli multajn paŝojn por rezoni pri la fina kapablo + longo kaj tiel fari pli da laboro.
// `to_vec()` rekte asignas la ĝustan sumon kaj plenigas ĝin ekzakte.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): kun cfg(test) la eneca `[T]::to_vec`-metodo, necesa por ĉi tiu metododifino, ne haveblas.
    // Anstataŭe uzu la `slice::to_vec`-funkcion, kiu nur haveblas kun cfg(test) NB. Vidu la slice::hack-modulon en slice.rs por pli da informoj.
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}