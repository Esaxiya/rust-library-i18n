use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Ripetanto kiu uzas fermon por determini ĉu elemento devas esti forigita.
///
/// Ĉi tiu strukturo estas kreita de [`Vec::drain_filter`].
/// Vidu ĝian dokumentadon por pli.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// La indekso de la ero inspektota per la sekva alvoko al `next`.
    pub(super) idx: usize,
    /// La nombro da eroj ĝis nun malplenigitaj (removed).
    pub(super) del: usize,
    /// La originala longo de `vec` antaŭ malplenigo.
    pub(super) old_len: usize,
    /// La filtrila testa predikato.
    pub(super) pred: F,
    /// Flago, kiu indikas panic, okazis en la filtrila testpredikato.
    /// Ĉi tio estas uzata kiel aludo pri la faliga efektivigo por malhelpi konsumon de la resto de la `DrainFilter`.
    /// Ĉiuj neprilaboritaj eroj estos malantaŭenŝovitaj en la `vec`, sed neniuj pliaj eroj estos faligitaj aŭ testitaj de la filtrila predikato.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Liveras referencon al la suba atribuilo.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Ĝisdatigu la indekson *post kiam* la predikato nomiĝas.
                // Se la indekso estas ĝisdatigita antaŭe kaj la predikato panics, la elemento ĉe ĉi tiu indekso estus likita.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Ĉi tio estas sufiĉe fuŝita stato, kaj vere ne estas evidente ĝusta farendaĵo.
                        // Ni ne volas daŭre provi ekzekuti `pred`, do ni nur malantaŭenŝovas ĉiujn neprilaboritajn elementojn kaj diras al la vec ke ili ankoraŭ ekzistas.
                        //
                        // La malantaŭa ŝanĝo necesas por malhelpi duoblan falon de la lasta sukcese elĉerpita ero antaŭ panic en la predikato.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Provu konsumi iujn ceterajn elementojn se la filtrila predikato ankoraŭ ne panikiĝis.
        // Ni malantaŭenŝovos iujn ceterajn elementojn, ĉu ni jam panikiĝis, ĉu se la konsumo ĉi tie panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}