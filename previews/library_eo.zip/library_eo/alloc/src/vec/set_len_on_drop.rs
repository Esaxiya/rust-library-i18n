// Agordu la longon de la vec kiam la `SetLenOnDrop`-valoro malaperas.
//
// La ideo estas: La longo-kampo en SetLenOnDrop estas loka variablo, kiun la optimumiganto vidos, ne kaŝnomas kun iuj butikoj per la datuma montrilo de Vec.
// Ĉi tio estas solvo por kaŝnoma analitika numero #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}