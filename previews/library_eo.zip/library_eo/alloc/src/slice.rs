//! Dinamike granda vido al apuda sinsekvo, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Tranĉaĵoj estas vido al bloko de memoro reprezentita kiel montrilo kaj longo.
//!
//! ```
//! // tranĉante Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // devigante tabelon al tranĉaĵo
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Tranĉaĵoj estas aŭ ŝanĝeblaj aŭ dividitaj.
//! La komuna tranĉaĵospeco estas `&[T]`, dum la ŝanĝebla tranĉaĵospeco estas `&mut [T]`, kie `T` reprezentas la elementospecon.
//! Ekzemple, vi povas mutacii la blokon de memoro, al kiu ŝanĝiĝema tranĉaĵo montras:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Jen kelkaj aferoj, kiujn ĉi tiu modulo enhavas:
//!
//! ## Structs
//!
//! Estas pluraj strukturoj utilaj por tranĉaĵoj, kiel [`Iter`], kiu reprezentas ripeton super tranĉaĵo.
//!
//! ## Efektivigoj de Trait
//!
//! Estas pluraj efektivigoj de komuna traits por tranĉaĵoj.Iuj ekzemploj inkluzivas:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], por tranĉaĵoj kies elementospeco estas [`Eq`] aŭ [`Ord`].
//! * [`Hash`] - por tranĉaĵoj kies elementa tipo estas [`Hash`].
//!
//! ## Iteration
//!
//! La tranĉaĵoj efektivigas `IntoIterator`.La ripeto donas referencojn al la tranĉaĵelementoj.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! La ŝanĝebla tranĉaĵo donas ŝanĝeblajn referencojn al la elementoj:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Ĉi tiu ripeto donas ŝanĝeblajn referencojn al la elementoj de la tranĉaĵo, do dum la elemento-tipo de la tranĉaĵo estas `i32`, la elemento-tipo de la ripeto estas `&mut i32`.
//!
//!
//! * [`.iter`] kaj [`.iter_mut`] estas la eksplicitaj metodoj por redoni la defaŭltajn ripetilojn.
//! * Pliaj metodoj, kiuj redonas ripetilojn, estas [`.split`], [`.splitn`], [`.chunks`], [`.windows`] kaj pli.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Multaj el la uzoj en ĉi tiu modulo estas uzataj nur en la test-agordo.
// Estas pli simple nur malŝalti la averton unused_imports ol ripari ilin.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Bazaj etendaj metodoj
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) bezonata por la efektivigo de `vec!`-makroo dum provado de NB, vidu la `hack`-modulon en ĉi tiu dosiero por pliaj detaloj.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) bezonata por la efektivigo de `Vec::clone` dum provado de NB, vidu la `hack`-modulon en ĉi tiu dosiero por pliaj detaloj.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Kun cfg(test) `impl [T]` ne disponeblas, ĉi tiuj tri funkcioj estas efektive metodoj, kiuj estas en `impl [T]` sed ne en `core::slice::SliceExt`, ni bezonas provizi ĉi tiujn funkciojn por la `test_permutations`-testo.
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Ni ne aldonu linian atributon al ĉi tio, ĉar ĉi tio estas uzata en `vec!`-makroo plejparte kaj kaŭzas perf regreson.
    // Vidu #71204 por diskutado kaj rezultoj.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // eroj estis markitaj inicialigitaj en la suba buklo
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) necesas, ke LLVM forigu limajn kontrolojn kaj havas pli bonan kodregenon ol zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // la vec estis atribuita kaj pravalorizita supre almenaŭ al ĉi tiu longo.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // atribuita supre kun la kapablo de `s`, kaj pravalorizi al `s.len()` en ptr::copy_to_non_overlapping sube.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Ordigas la tranĉaĵon.
    ///
    /// Ĉi tiu speco estas stabila (t.e. ne reordigas egalajn elementojn) kaj *O*(*n*\*log(* n*)) plej malbone.
    ///
    /// Se aplikebla, malstabila ordigo estas preferata ĉar ĝi estas ĝenerale pli rapida ol stabila ordigo kaj ĝi ne asignas helpan memoron.
    /// Vidu [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Nuna efektivigo
    ///
    /// La nuna algoritmo estas adapta, ripeta kuniga speco inspirita de [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Ĝi estas desegnita por esti tre rapida en kazoj, kiam la tranĉaĵo estas preskaŭ ordigita, aŭ konsistas el du aŭ pli ordigitaj vicoj interligitaj unu post alia.
    ///
    ///
    /// Ankaŭ ĝi asignas provizoran stokadon duone pli grandan ol `self`, sed por mallongaj tranĉaĵoj oni uzas anstataŭ ne-asignan enmetan specon.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Ordigas la tranĉaĵon per komparila funkcio.
    ///
    /// Ĉi tiu speco estas stabila (t.e. ne reordigas egalajn elementojn) kaj *O*(*n*\*log(* n*)) plej malbone.
    ///
    /// La komparila funkcio devas difini totalan mendadon de la elementoj en la tranĉaĵo.Se la mendado ne estas totala, la ordo de la elementoj estas nespecifita.
    /// Ordo estas totala ordo se ĝi estas (por ĉiuj `a`, `b` kaj `c`):
    ///
    /// * totala kaj kontraŭsimetria: ĝuste unu el `a < b`, `a == b` aŭ `a > b` estas vera, kaj
    /// * transitiva, `a < b` kaj `b < c` implicas `a < c`.La samo devas esti valida por ambaŭ `==` kaj `>`.
    ///
    /// Ekzemple, dum [`f64`] ne efektivigas [`Ord`] ĉar `NaN != NaN`, ni povas uzi `partial_cmp` kiel nia ordiga funkcio, kiam ni scias, ke la tranĉaĵo ne enhavas `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Se aplikebla, malstabila ordigo estas preferata ĉar ĝi estas ĝenerale pli rapida ol stabila ordigo kaj ĝi ne asignas helpan memoron.
    /// Vidu [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Nuna efektivigo
    ///
    /// La nuna algoritmo estas adapta, ripeta kuniga speco inspirita de [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Ĝi estas desegnita por esti tre rapida en kazoj, kiam la tranĉaĵo estas preskaŭ ordigita, aŭ konsistas el du aŭ pli ordigitaj vicoj interligitaj unu post alia.
    ///
    /// Ankaŭ ĝi asignas provizoran stokadon duone pli grandan ol `self`, sed por mallongaj tranĉaĵoj oni uzas anstataŭ ne-asignan enmetan specon.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // inversa ordigo
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Ordigas la tranĉaĵon per ŝlosila eltira funkcio.
    ///
    /// Ĉi tiu speco estas stabila (t.e. ne reordigas egalajn elementojn) kaj *O*(*m*\* * n *\* log(*n*)) plej malbone, kie la ŝlosila funkcio estas *O*(*m*).
    ///
    /// Por multekostaj ŝlosilaj funkcioj (ekz
    /// funkcioj, kiuj ne estas simplaj nemoveblaĵoj aŭ bazaj operacioj), [`sort_by_cached_key`](slice::sort_by_cached_key) probable estos multe pli rapida, ĉar ĝi ne rekomputas elementajn klavojn.
    ///
    ///
    /// Se aplikebla, malstabila ordigo estas preferata ĉar ĝi estas ĝenerale pli rapida ol stabila ordigo kaj ĝi ne asignas helpan memoron.
    /// Vidu [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Nuna efektivigo
    ///
    /// La nuna algoritmo estas adapta, ripeta kuniga speco inspirita de [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Ĝi estas desegnita por esti tre rapida en kazoj, kiam la tranĉaĵo estas preskaŭ ordigita, aŭ konsistas el du aŭ pli ordigitaj vicoj interligitaj unu post alia.
    ///
    /// Ankaŭ ĝi asignas provizoran stokadon duone pli grandan ol `self`, sed por mallongaj tranĉaĵoj oni uzas anstataŭ ne-asignan enmetan specon.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Ordigas la tranĉaĵon per ŝlosila eltira funkcio.
    ///
    /// Dum ordigo, la ŝlosila funkcio estas nomata nur unufoje por elemento.
    ///
    /// Ĉi tiu speco estas stabila (t.e. ne reordigas egalajn elementojn) kaj *O*(*m*\* * n *+* n *\* log(*n*)) plej malbone, kie la ŝlosila funkcio estas *O*(*m*) .
    ///
    /// Por simplaj klavaj funkcioj (ekz. Funkcioj, kiuj estas nemoveblaĵoj aŭ bazaj operacioj), [`sort_by_key`](slice::sort_by_key) probable estos pli rapida.
    ///
    /// # Nuna efektivigo
    ///
    /// La nuna algoritmo baziĝas sur [pattern-defeating quicksort][pdqsort] de Orson Peters, kiu kombinas la rapidan averaĝan kazon de hazarda rapidokvanto kun la rapida plej malbona kazo de pakaĵeto, atingante linian tempon sur tranĉaĵoj kun iuj ŝablonoj.
    /// Ĝi uzas iom da hazardo por eviti degeneritajn kazojn, sed kun fiksa seed por ĉiam doni determinisman konduton.
    ///
    /// En la plej malbona kazo, la algoritmo asignas provizoran stokadon en `Vec<(K, usize)>` la longo de la tranĉaĵo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Helpa makroo por indeksi nian vector laŭ la plej malgranda ebla tipo, por redukti asignon.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // La elementoj de `indices` estas unikaj, ĉar ili estas indeksitaj, do ia speco estos stabila rilate al la originala tranĉaĵo.
                // Ni uzas `sort_unstable` ĉi tie ĉar ĝi postulas malpli da memora asigno.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kopias `self` en novan `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Ĉi tie `s` kaj `x` povas esti modifitaj sendepende.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kopias `self` en novan `Vec` kun asignilo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Ĉi tie `s` kaj `x` povas esti modifitaj sendepende.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, vidu la `hack`-modulon en ĉi tiu dosiero por pliaj detaloj.
        hack::to_vec(self, alloc)
    }

    /// Konvertas `self` en vector sen klonoj aŭ asigno.
    ///
    /// La rezulta vector povas esti konvertita reen en skatolon per `Vec<T>`into_boxed_slice`-metodo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ne plu uzeblas ĉar ĝi estis konvertita al `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, vidu la `hack`-modulon en ĉi tiu dosiero por pliaj detaloj.
        hack::into_vec(self)
    }

    /// Kreas vector ripetante tranĉaĵon `n`-fojojn.
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio estos panic se la kapablo superfluus.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic post superfluo:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Se `n` estas pli granda ol nulo, ĝi povas esti dividita kiel `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` estas la nombro reprezentita de la plej maldekstra '1'-bito de `n`, kaj `rem` estas la restanta parto de `n`.
        //
        //

        // Uzante `Vec` por aliri `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` ripeto estas farata per duobligado de `buf`-tempoj "expn".
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Se `m > 0`, restas ceteraj bitoj ĝis la plej maldekstra '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` havas kapaciton de `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) ripeto estas farita per kopiado de unuaj `rem`-ripetoj de `buf` mem.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Ĉi tio ne interkovras ekde `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` egalas al `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Platigas tranĉaĵon `T` en ununuran valoron `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Platigas tranĉaĵon `T` en ununuran valoron `Self::Output`, metante donitan apartigilon inter ĉiu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Platigas tranĉaĵon `T` en ununuran valoron `Self::Output`, metante donitan apartigilon inter ĉiu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Liveras vector enhavanta kopion de ĉi tiu tranĉaĵo, kie ĉiu bajto estas mapita al sia ASCII-majuskla ekvivalento.
    ///
    ///
    /// Askiaj literoj 'a' al 'z' estas mapitaj al 'A' al 'Z', sed ne-ASCII-literoj estas senŝanĝaj.
    ///
    /// Por majuskli la lokan valoron, uzu [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Liveras vector enhavanta kopion de ĉi tiu tranĉaĵo, kie ĉiu bajto estas mapita al sia ASCII minuskla ekvivalento.
    ///
    ///
    /// Askiaj literoj 'A' al 'Z' estas mapitaj al 'a' al 'z', sed ne-ASCII-literoj estas senŝanĝaj.
    ///
    /// Por minuskli la lokan valoron, uzu [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Etendaĵo traits por tranĉaĵoj super specifaj specoj de datumoj
////////////////////////////////////////////////////////////////////////////////

/// Helper trait por [`[T]: : concat`](tranĉaĵo::concat).
///
/// Note: la `Item`-tipa parametro ne estas uzata en ĉi tiu trait, sed ĝi permesas al impls esti pli ĝenerala.
/// Sen ĝi, ni ricevas ĉi tiun eraron:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Ĉi tio estas ĉar povus ekzisti `V`-specoj kun multnombraj `Borrow<[_]>`-impls, tiel ke pluraj `T`-tipoj validus:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// La rezulta tipo post interligo
    type Output;

    /// Efektivigo de [`[T]: : concat`](tranĉaĵo::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait por [`[T]: : kunigi`](tranĉaĵo::kunigi)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// La rezulta tipo post interligo
    type Output;

    /// Efektivigo de [`[T]: : kunigi`](tranĉaĵo::kunigi)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Normaj trait-efektivigoj por tranĉaĵoj
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // faligu ion ajn en la celo, kiu ne estos anstataŭigita
        target.truncate(self.len());

        // target.len <= self.len pro la supera detranĉado, do la tranĉaĵoj ĉi tie ĉiam estas enlimaj.
        //
        let (init, tail) = self.split_at(target.len());

        // reuzu la enhavitajn valorojn allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Enmetas `v[0]` en antaŭordigitan sinsekvon `v[1..]` tiel ke tuta `v[..]` fariĝas ordigita.
///
/// Ĉi tiu estas la integra subprogramo de enmeta varo.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Estas tri manieroj efektivigi enmeton ĉi tie:
            //
            // 1. Interŝanĝu apudajn elementojn ĝis la unua atingos sian finan celon.
            //    Tamen tiel ni kopias datumojn ĉirkaŭ pli ol necesas.
            //    Se elementoj estas grandaj strukturoj (multekoste kopieblaj), ĉi tiu metodo estos malrapida.
            //
            // 2. Ripetu ĝis la ĝusta loko por la unua elemento troviĝas.
            // Poste ŝanĝu la sekvajn elementojn por fari lokon por ĝi kaj fine metu ĝin en la restantan truon.
            // Ĉi tio estas bona metodo.
            //
            // 3. Kopiu la unuan elementon en portempan variablon.Ripetu ĝis la ĝusta loko por ĝi troviĝas.
            // Dum ni iras antaŭen, kopiu ĉiun trairitan elementon en la antaŭan fendon.
            // Fine, kopiu datumojn de la portempa variablo en la restantan truon.
            // Ĉi tiu metodo estas tre bona.
            // Komparnormoj montris iomete pli bonan rendimenton ol per la dua metodo.
            //
            // Ĉiuj metodoj estis komparitaj, kaj la 3a montris plej bonajn rezultojn.Do ni elektis tiun.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Meza stato de la enmeta procezo ĉiam estas spurita per `hole`, kiu servas du celojn:
            // 1. Protektas integrecon de `v` de panics en `is_less`.
            // 2. Plenigas la restantan truon en `v` finfine.
            //
            // Panic sekureco:
            //
            // Se `is_less` panics en iu ajn punkto dum la procezo, `hole` falos kaj plenigos la truon en `v` per `tmp`, tiel certigante ke `v` ankoraŭ tenas ĉiun objekton, kiun ĝi komence tenis ekzakte unufoje.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` falas kaj tiel kopias `tmp` en la restantan truon en `v`.
        }
    }

    // Se faligita, kopioj de `src` en `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Kunfandas malpliiĝantajn kurojn `v[..mid]` kaj `v[mid..]` uzante `buf` kiel provizoran stokadon, kaj stokas la rezulton en `v[..]`.
///
/// # Safety
///
/// La du tranĉaĵoj devas esti malplenaj kaj `mid` devas esti limigita.
/// Bufro `buf` devas esti sufiĉe longa por teni kopion de la pli mallonga tranĉaĵo.
/// Ankaŭ `T` ne rajtas esti nulgranda tipo.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // La kombina procezo unue kopias la pli mallongan kuron en `buf`.
    // Tiam ĝi spuras la nove kopiitan kuron kaj la pli longan kuron antaŭen (aŭ malantaŭen), komparante iliajn sekvajn neuzitajn elementojn kaj kopiante la malpli grandan (aŭ pli grandan) en `v`.
    //
    // Tuj kiam la pli mallonga kuro estas plene konsumita, la procezo finiĝas.Se la pli longa kuro konsumiĝas unue, tiam ni devas kopii ĉion, kio restas de la pli mallonga kuro en la restantan truon en `v`.
    //
    // Meza stato de la procezo ĉiam estas spurita per `hole`, kiu servas du celojn:
    // 1. Protektas integrecon de `v` de panics en `is_less`.
    // 2. Plenigas la restantan truon en `v` se la pli longa kuro unue konsumiĝas.
    //
    // Panic sekureco:
    //
    // Se `is_less` panics iam ajn dum la procezo, `hole` falos kaj plenigos la truon en `v` kun la neuzita intervalo en `buf`, tiel certigante ke `v` ankoraŭ tenas ĉiun objekton, kiun ĝi unue tenis ekzakte unufoje.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // La maldekstra kuro estas pli mallonga.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Komence, ĉi tiuj montriloj montras la komencojn de siaj tabeloj.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Konsumu la malpli grandan flankon.
            // Se egala, preferu la maldekstran kuron por konservi stabilecon.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // La ĝusta kuro estas pli mallonga.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Komence, ĉi tiuj montriloj montras preter la finoj de siaj tabeloj.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Konsumu la plej grandan flankon.
            // Se egala, preferu la ĝustan kuron por konservi stabilecon.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Fine, `hole` falas.
    // Se la pli mallonga kurado ne plene konsumiĝis, kio ajn el ĝi restos nun kopiita en la truon en `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Se faligita, kopias la intervalon `start..end` en `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ne estas nulgranda tipo, do estas bone dividi per ĝia grandeco.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Ĉi tiu kuniga speco pruntas iujn (sed ne ĉiujn) ideojn de TimSort, kiu estas detale priskribita [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// La algoritmo identigas strikte descendajn kaj ne-descendajn subsekvencojn, kiuj nomiĝas naturaj kuroj.Estas amaso da pritraktataj kuroj ankoraŭ kunfandotaj.
/// Ĉiu ĵus trovita kuro estas puŝita sur la stakon, kaj tiam iuj paroj de apudaj kuroj kunfandiĝas ĝis ĉi tiuj du invariantoj kontentiĝas:
///
/// 1. por ĉiu `i` en `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. por ĉiu `i` en `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// La invariantoj certigas, ke la totala rultempo estas *O*(*n*\*log(* n*)) plej malbona.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tranĉaĵoj ĝis ĉi tiu longo estas ordigitaj per enmeta ordigo.
    const MAX_INSERTION: usize = 20;
    // Tre mallongaj kuroj estas etenditaj per enmet-ordigo por ampleksi almenaŭ ĉi multajn elementojn.
    const MIN_RUN: usize = 10;

    // Ordigo havas neniun sencan konduton ĉe nulgrandaj specoj.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Mallongaj tabeloj aranĝiĝas surloke per enmeta ordigo por eviti atribuojn.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Asignu bufron por uzi kiel gratvortan memoron.Ni konservas la longon 0 tiel ke ni povas konservi en ĝi malprofundajn kopiojn de la enhavo de `v` sen riski la kuracistojn kun kopioj se `is_less` panics.
    //
    // Kunfandante du ordigitajn kurojn, ĉi tiu bufro enhavas kopion de la pli mallonga, kiu ĉiam havos longon maksimume `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Por identigi naturajn kurojn en `v`, ni trairas ĝin malantaŭen.
    // Tio povus ŝajni stranga decido, sed konsideru la fakton, ke kunfandiĝoj pli ofte iras en la kontraŭa direkto (forwards).
    // Laŭ normoj, kunfandi antaŭen estas iomete pli rapide ol kunfandi malantaŭen.
    // Por fini, identigi kurojn trairante malantaŭen plibonigas rendimenton.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Trovu la sekvan naturan kuradon kaj inversigu ĝin se ĝi strikte descendas.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Enmetu pliajn elementojn en la kuron, se ĝi estas tro mallonga.
        // Enmet-ordigo pli rapide ol kunmetas en mallongaj sekvencoj, do tio signife plibonigas rendimenton.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Enpuŝu ĉi tiun kuron sur la stakon.
        runs.push(Run { start, len: end - start });
        end = start;

        // Kunfandi iujn parojn de apudaj kuroj por kontentigi la invariantojn.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Fine, ĝuste unu kuro devas resti en la stako.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Ekzamenas la stakon de kuroj kaj identigas la sekvan paron da kuroj kunfandotaj.
    // Pli specife, se `Some(r)` estas redonita, tio signifas, ke `runs[r]` kaj `runs[r + 1]` devas esti kunigitaj poste.
    // Se la algoritmo devas daŭre krei novan kuron anstataŭe, `None` estas redonita.
    //
    // TimSort estas fifama pro siaj kaleŝaj efektivigoj, kiel priskribite ĉi tie:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // La esenco de la rakonto estas: ni devas plenumi la senvariantojn en la supraj kvar kuroj sur la stako.
    // Devigi ilin nur super tri ne sufiĉas por certigi, ke la invariantoj ankoraŭ tenos por *ĉiuj* kuroj en la stako.
    //
    // Ĉi tiu funkcio ĝuste kontrolas invariantojn por la plej bonaj kvar kuroj.
    // Aldone, se la supro kuro komenciĝas ĉe indekso 0, ĝi ĉiam postulos kunfandan operacion ĝis la stako plene kolapsos, por kompletigi la ordigon.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}