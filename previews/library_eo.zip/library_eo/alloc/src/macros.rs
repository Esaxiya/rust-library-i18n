/// Kreas [`Vec`] enhavantan la argumentojn.
///
/// `vec!` permesas difini `Vec`s kun la sama sintakso kiel tabelaj esprimoj.
/// Estas du formoj de ĉi tiu makroo:
///
/// - Kreu [`Vec`] enhavantan donitan liston de elementoj:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Kreu [`Vec`] de donita elemento kaj grandeco:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Notu, ke malkiel tabelaj esprimoj ĉi tiu sintakso subtenas ĉiujn elementojn, kiuj efektivigas [`Clone`] kaj la nombro da elementoj ne devas esti konstanto.
///
/// Ĉi tio uzos `clone` por kopii esprimon, do oni devas zorgi uzi ĉi tion kun tipoj havantaj nenorman `Clone`-efektivigon.
/// Ekzemple, `vec![Rc::new(1);5] `kreos vector de kvin referencoj al la sama boksita entjera valoro, ne kvin referencoj montrantaj al sendepende boksitaj entjeroj.
///
///
/// Ankaŭ rimarku, ke `vec![expr; 0]` estas permesita, kaj produktas malplenan vector.
/// Ĉi tio tamen taksos `expr`, kaj tuj faligos la rezultan valoron, do atentu pri kromefikoj.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): kun cfg(test) la eneca `[T]::into_vec`-metodo, necesa por ĉi tiu makro-difino, ne disponeblas.
// Anstataŭe uzu la `slice::into_vec`-funkcion, kiu nur haveblas kun cfg(test) NB. Vidu la slice::hack-modulon en slice.rs por pli da informoj.
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Kreas `String` uzante interpoladon de rultempaj esprimoj.
///
/// La unua argumento, kiun `format!` ricevas, estas formato-ĉeno.Ĉi tio devas esti ĉeno laŭvorta.La potenco de la formato-ĉeno estas en la enhavo `{}` s.
///
/// Pliaj parametroj transdonitaj al `format!` anstataŭigas la "{}` s ene de la formato-ĉeno en la ordo donita krom se nomitaj aŭ poziciaj parametroj estas uzataj;vidu [`std::fmt`] por pliaj informoj.
///
///
/// Ofta uzo por `format!` estas interligo kaj interpolado de kordoj.
/// La sama konvencio estas uzata kun makrooj [`print!`] kaj [`write!`], depende de la celita celloko.
///
/// Por konverti unu valoron al ĉeno, uzu la [`to_string`]-metodon.Ĉi tio uzos la [`Display`]-formatadon trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics se formato de trait-efektivigo redonas eraron.
/// Ĉi tio indikas malĝustan efektivigon, ĉar `fmt::Write for String` neniam redonas eraron mem.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Devigu AST-nodon al esprimo por plibonigi diagnozojn en ŝablona pozicio.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}