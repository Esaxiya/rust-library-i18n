# Kontribuante al staro

La `stdarch` crate pli ol volas akcepti kontribuojn!Unue vi probable volas kontroli la deponejon kaj certigi, ke testoj sukcesas por vi:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Kie `<your-target-arch>` estas la cela triopo uzata de `rustup`, ekz. `x86_x64-unknown-linux-gnu` (sen iu ajn antaŭa `nightly-` aŭ simila).
Memoru ankaŭ, ke ĉi tiu deponejo postulas la noktan kanalon de Rust!
La supraj testoj fakte postulas ke nokta rust estu la apriora en via sistemo, por agordi tiun uzon `rustup default nightly` (kaj `rustup default stable` por reiri).

Se iu el la supraj paŝoj ne funkcias, [please let us know][new]!

Poste vi povas helpi [find an issue][issues], ni elektis kelkajn per la etikedoj [`help wanted`][help] kaj [`impl-period`][impl], kiuj povus precipe helpi. 
Eble plej interesas vin [#40][vendor], efektivigante ĉiujn vendistajn propraĵojn en x86.Tiu numero havas bonajn indikojn pri kie komenci!

Se vi havas ĝeneralajn demandojn, bonvolu demandi [join us on gitter][gitter] kaj demandu!Bonvolu ping aŭ@BurntSushi aŭ@alexcrichton kun demandoj.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Kiel verki ekzemplojn por internaj internuloj

Estas kelkaj funkcioj, kiuj devas esti ebligitaj por ke la propra ena funkcio funkciu ĝuste kaj la ekzemplo devas esti funkciigita nur de `cargo test --doc` kiam la funkcio estas subtenata de la CPU.

Rezulte, la defaŭlta `fn main` generita de `rustdoc` ne funkcios (plejofte).
Konsideru uzi jenon kiel gvidilon por certigi, ke via ekzemplo funkcias kiel atendite.

```rust
/// # // Ni bezonas cfg_target_feature por certigi, ke la ekzemplo estas nur
/// # // funkciigita de `cargo test --doc` kiam la CPU subtenas la funkcion
/// # #![feature(cfg_target_feature)]
/// # // Ni bezonas cel-funkcion por ke la interna funkciu
/// # #![feature(target_feature)]
/// #
/// # // rustdoc defaŭlte uzas `extern crate stdarch`, sed ni bezonas la
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // La vera ĉefa funkcio
/// # fn main() {
/// #     // Kuru ĉi tion nur se `<target feature>` estas subtenata
/// #     se cfg_feature_enabled! ("<target feature>"){
/// #         // Kreu `worker`-funkcion, kiu ruliĝos nur se la cela funkcio
/// #         // estas subtenata kaj certigu, ke `target_feature` estas ebligita por via laboristo
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         nesekura fn worker() {
/// // Skribu vian ekzemplon ĉi tie.Trajtoj specifaj internuloj funkcios ĉi tie!Sovaĝiĝu!
///
/// #         }
///
/// #         nesekura { worker(); }
/// #     }
/// # }
```

Se iuj el la supra sintakso ne aspektas konataj, la [Documentation as tests]-sekcio de la [Rust Book] sufiĉe bone priskribas la `rustdoc`-sintakson.
Kiel ĉiam, bonvolu [join us on gitter][gitter] kaj demandu nin, ĉu vi trafis problemojn, kaj dankon pro helpo plibonigi la dokumentadon de `stdarch`!

# Alternativaj Instruaj Instruoj

Ĝenerale oni rekomendas uzi `ci/run.sh` por fari la testojn.
Tamen ĉi tio eble ne funkcios por vi, ekz. Se vi estas ĉe Windows.

En tiu kazo vi povas refari la funkciadon de `cargo +nightly test` kaj `cargo +nightly test --release -p core_arch` por provi la kodgeneradon.
Notu, ke ĉi tiuj postulas la noktan ilĉenon por esti instalita kaj ke `rustc` sciu pri via cela triopo kaj ĝia CPU.
Precipe vi devas agordi la median variablon `TARGET` kiel vi farus por `ci/run.sh`.
Krome vi devas agordi `RUSTCFLAGS` (bezonas la `C`) por indiki celajn ecojn, ekz `RUSTCFLAGS="-C -target-features=+avx2"`.
Vi ankaŭ povas agordi `-C -target-cpu=native` se vi "just" disvolvas kontraŭ via nuna CPU.

Atentu, ke kiam vi uzas ĉi tiujn alternativajn instrukciojn, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], ekz
testoj pri instrukcia generado povas malsukcesi ĉar la malmuntilo nomis ilin alimaniere, ekz
ĝi povas generi `vaesenc` anstataŭ `aesenc`-instrukcioj malgraŭ ke ili kondutas same.
Ankaŭ ĉi tiuj instrukcioj efektivigas malpli da testoj ol kutime farite, do ne miru, ke kiam vi fine petos, iuj eraroj aperos por testoj ne traktitaj ĉi tie.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






