`core::arch` - La kerna biblioteko de Rust-specifaj ar architectureitekturoj
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

La `core::arch`-modulo efektivigas internajn dependajn de arkitekturo (ekz. SIMD).

# Usage 

`core::arch` estas havebla kiel parto de `libcore` kaj ĝi estas reeksportita de `libstd`.Preferu uzi ĝin per `core::arch` aŭ `std::arch` ol per ĉi tiu crate.
Malstabilaj ecoj ofte haveblas en nokta Rust per la `feature(stdsimd)`.

Uzi `core::arch` per ĉi tiu crate postulas noktan Rust, kaj ĝi povas (kaj efektive) ofte rompiĝas.La solaj kazoj, en kiuj vi devas konsideri uzi ĝin per ĉi tiu crate, estas:

* se vi bezonas rekompili `core::arch` mem, ekz. kun apartaj celaj funkcioj ebligitaj, kiuj ne estas ebligitaj por `libcore`/`libstd`.
Note: se vi bezonas rekompili ĝin por ne-norma celo, bonvolu preferi uzi `xargo` kaj rekompili `libcore`/`libstd` laŭ taŭge anstataŭ uzi ĉi tiun crate.
  
* uzante iujn funkciojn, kiuj eble ne haveblas eĉ malantaŭ malstabilaj Rust-funkcioj.Ni klopodas minimumigi ĉi tiujn.
Se vi bezonas uzi iujn el ĉi tiuj funkcioj, bonvolu malfermi numeron, por ke ni povu elmontri ilin en nokta Rust kaj vi povos uzi ilin de tie.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` estas ĉefe distribuata laŭ la kondiĉoj de la licenco MIT kaj de la permesilo Apache (Versio 2.0), kun partoj kovritaj de diversaj licencoj BSD-similaj.

Vidu LICENSE-APACHE, kaj LICENSE-MIT por detaloj.

# Contribution

Krom se vi eksplicite deklaras alie, iu ajn kontribuo intence prezentita por esti inkluzivita en `core_arch` de vi, kiel difinita en la permesilo Apache-2.0, estos duoble aprobita kiel supre, sen aldonaj kondiĉoj aŭ kondiĉoj.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












