use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Kutimis diri al niaj `#[assert_instr]`-komentarioj, ke ĉiuj simplaj internaj programoj disponeblas por testi sian kodegenon, ĉar iuj estas malantaŭ alia ekstra `-Ctarget-feature=+unimplemented-simd128`, kiu ne havas ekvivalenton en `#[target_feature]` nun.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}