#![feature(no_core)]
#![no_core]

// Vidu rustc-std-workspace-core por kial ĉi tiu crate necesas.

// Renomi la crate por eviti konflikton kun la alloc-modulo en liballoc.
extern crate alloc as foo;

pub use foo::*;