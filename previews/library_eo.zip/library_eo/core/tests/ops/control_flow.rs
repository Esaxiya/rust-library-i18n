use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Ĉi tio ne estas stabila surfaca areo, sed helpas konservi `?` malmultekoste inter ili, eĉ se LLVM ne povas ĉiam utiligi ĝin nun.
    //
    // (Bedaŭrinde Rezulto kaj Opcio ne kongruas, do ControlFlow ne povas egali ambaŭ.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}