use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Envolvaĵo por malhelpi kompililon aŭtomate nomi la detruilon de "T".
/// Ĉi tiu envolvaĵo estas 0-kosta.
///
/// `ManuallyDrop<T>` estas submetita al la samaj aranĝaj optimumigoj kiel `T`.
/// Sekve, ĝi havas *nenian efikon* sur la supozoj, kiujn la kompililo faras pri ĝia enhavo.
/// Ekzemple, pravalorizi `ManuallyDrop<&mut T>` per [`mem::zeroed`] estas nedifinita konduto.
/// Se vi bezonas trakti neinicialigitajn datumojn, uzu [`MaybeUninit<T>`] anstataŭe.
///
/// Notu, ke aliri la valoron ene de `ManuallyDrop<T>` estas sekura.
/// Ĉi tio signifas, ke `ManuallyDrop<T>` kies enhavo estis forigita ne rajtas esti elmontrita per publika sekura API.
/// Koresponde, `ManuallyDrop::drop` estas nesekura.
///
/// # `ManuallyDrop` kaj faligi mendon.
///
/// Rust havas klare difinitan [drop order] de valoroj.
/// Por certigi, ke kampoj aŭ lokanoj falas laŭ specifa ordo, reordigu la deklarojn tiel, ke la implica faliga ordo estas la ĝusta.
///
/// Eblas uzi `ManuallyDrop` por kontroli la falan ordon, sed tio postulas nesekuran kodon kaj malfacilas korekte en la ĉeesto de malvolviĝo.
///
///
/// Ekzemple, se vi volas certigi, ke specifa kampo falas post la aliaj, faru ĝin la lasta kampo de strukturo:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` estos forigita post `children`.
///     // Rust garantias, ke kampoj estas malplenigitaj laŭ la ordo de deklaro.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Envolvu valoron mane faligotan.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Vi ankoraŭ povas sekure agi laŭ la valoro
    /// assert_eq!(*x, "Hello");
    /// // Sed `Drop` ne funkcios ĉi tie
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Ĉerpas la valoron de la `ManuallyDrop`-ujo.
    ///
    /// Ĉi tio permesas faligi la valoron denove.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Ĉi tio faligas la `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Elprenas la valoron de la `ManuallyDrop<T>`-ujo.
    ///
    /// Ĉi tiu metodo ĉefe celas movi valorojn en falo.
    /// Anstataŭ uzi [`ManuallyDrop::drop`] por mane faligi la valoron, vi povas uzi ĉi tiun metodon por preni la valoron kaj uzi ĝin kiel ajn deziratan.
    ///
    /// Kiam ajn eblas, estas preferinde uzi [`into_inner`][`ManuallyDrop::into_inner`] anstataŭe, kio malebligas duobligi la enhavon de la `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio semantike movas la enhavitan valoron sen malhelpi plian uzadon, lasante la staton de ĉi tiu ujo senŝanĝa.
    /// Estas via respondeco certigi, ke ĉi tiu `ManuallyDrop` ne plu estu uzata.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SEKURECO: ni legas de referenco, kiu estas garantiita
        // validi por legaĵoj.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Mane faligas la enhavitan valoron.Ĉi tio egalas al nomi [`ptr::drop_in_place`] per montrilo al la enhavita valoro.
    /// Kiel tia, krom se la enhavita valoro estas plenplena strukturo, la detruanto estos nomata surloke sen movi la valoron, kaj tiel oni povas uzi ĝin por sekure faligi [pinned]-datumojn.
    ///
    /// Se vi posedas la valoron, vi povas uzi [`ManuallyDrop::into_inner`] anstataŭe.
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio funkciigas la detruilon de la enhavita valoro.
    /// Krom ŝanĝoj faritaj de la detruilo mem, la memoro restas senŝanĝa, kaj tiom kiom koncernas la kompililon ankoraŭ tenas iom-ŝablono valida por la tipo `T`.
    ///
    ///
    /// Tamen ĉi tiu "zombie"-valoro ne devas esti elmetita al sekura kodo, kaj ĉi tiun funkcion oni ne nomu pli ol unufoje.
    /// Uzi valoron post kiam ĝi falis aŭ faligi valoron plurfoje povas kaŭzi Nedifinitan Konduton (depende de tio, kion faras `drop`).
    /// Ĉi tion kutime malebligas la tipa sistemo, sed uzantoj de `ManuallyDrop` devas subteni tiujn garantiojn sen helpo de la kompililo.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SEKURECO: ni faligas la valoron montritan de ŝanĝebla referenco
        // kiu estas garantiita validi por skriboj.
        // Dependas de la alvokanto certigi, ke `slot` ne plu falos.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}