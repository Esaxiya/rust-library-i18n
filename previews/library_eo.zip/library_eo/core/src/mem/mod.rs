//! Bazaj funkcioj por trakti memoron.
//!
//! Ĉi tiu modulo enhavas funkciojn por pridemandi la grandecon kaj vicigon de tipoj, pravalorizi kaj manipuli memoron.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Akiras posedon kaj "forgets" pri la valoro **sen lanĉi ĝian detruanton**.
///
/// Ĉiuj rimedoj, kiujn la valoro administras, kiel amasa memoro aŭ dosiertenilo, restos por ĉiam en neatingebla stato.Tamen ĝi ne garantias, ke montriloj al ĉi tiu memoro restos validaj.
///
/// * Se vi volas liki memoron, vidu [`Box::leak`].
/// * Se vi volas akiri krudan montrilon al la memoro, vidu [`Box::into_raw`].
/// * Se vi volas ĝuste forigi valoron, funkciigante ĝian detruilon, vidu [`mem::drop`].
///
/// # Safety
///
/// `forget` ne estas markita kiel `unsafe`, ĉar la sekurecaj garantioj de Rust ne inkluzivas garantion, ke detruantoj ĉiam funkcios.
/// Ekzemple programo povas krei referencan ciklon per [`Rc`][rc], aŭ telefoni al [`process::exit`][exit] por eliri sen lanĉi detruilojn.
/// Tiel, permesi `mem::forget` de sekura kodo ne funde ŝanĝas la sekurecajn garantiojn de Rust.
///
/// Dirite, liki rimedojn kiel memoron aŭ I/O-objektojn estas kutime nedezirinda.
/// La bezono aperas en iuj specialigitaj uzokazoj por FFI aŭ nesekura kodo, sed eĉ tiam [`ManuallyDrop`] estas kutime preferata.
///
/// Ĉar forgesi valoron estas permesita, iu ajn `unsafe`-kodo, kiun vi skribas, devas permesi ĉi tiun eblon.Vi ne povas redoni valoron kaj atendi, ke la alvokanto nepre funkciigos la detruilon de la valoro.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// La kanonika sekura uzo de `mem::forget` estas eviti detruan valoron efektivigitan de la `Drop` trait.Ekzemple, ĉi tio likos `File`, t.e.
/// reprenu la spacon prenitan de la variablo sed neniam fermu la suban sisteman rimedon:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Ĉi tio utilas kiam la posedo de la suba rimedo antaŭe estis transdonita al kodo ekster Rust, ekzemple per transdono de la kruda dosierpriskribilo al C-kodo.
///
/// # Rilato kun `ManuallyDrop`
///
/// Dum `mem::forget` ankaŭ povas esti uzata por transdoni posedon de *memoro*, fari tion estas erara.
/// [`ManuallyDrop`] devus esti uzata anstataŭe.Pripensu ekzemple ĉi tiun kodon:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Konstruu `String` uzante la enhavon de `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // liki `v` ĉar ĝia memoro nun estas administrata de `s`
/// mem::forget(v);  // ERARO, v estas nevalida kaj ne rajtas esti transdonita al funkcio
/// assert_eq!(s, "Az");
/// // `s` estas implicite faligita kaj ĝia memoro estas dislokigita.
/// ```
///
/// Estas du problemoj kun la supra ekzemplo:
///
/// * Se pli da kodo estus aldonita inter la konstruado de `String` kaj la alvoko de `mem::forget()`, panic ene de ĝi kaŭzus duoblan liberon ĉar la sama memoro estas pritraktita de `v` kaj `s`.
/// * Post voki `v.as_mut_ptr()` kaj transdoni la posedon de la datumoj al `s`, la valoro `v` estas malvalida.
/// Eĉ kiam valoro ĵus moviĝas al `mem::forget` (kiu ne inspektos ĝin), iuj tipoj havas striktajn postulojn pri siaj valoroj, kiuj malvalidigas ilin dum pendado aŭ ne plu posedas.
/// Uzi malvalidajn valorojn iel ajn, inkluzive transdoni ilin aŭ redoni ilin de funkcioj, konsistigas nedifinitan konduton kaj povas rompi la supozojn faritajn de la kompililo.
///
/// Ŝanĝo al `ManuallyDrop` evitas ambaŭ problemojn:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Antaŭ ol ni malmunti `v` en ĝiajn krudajn partojn, certigu, ke ĝi ne falas!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Nun malmuntu `v`.Ĉi tiuj operacioj ne povas panic, do ne povas esti likado.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Fine konstruu `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` estas implicite faligita kaj ĝia memoro estas dislokigita.
/// ```
///
/// `ManuallyDrop` fortike malebligas duoble liberan ĉar ni malŝaltas la detruilon de `v` antaŭ ol fari ion alian.
/// `mem::forget()` ne permesas tion, ĉar ĝi konsumas sian argumenton, devigante nin nomi ĝin nur post ĉerpado de io ajn, kion ni bezonas de `v`.
/// Eĉ se panic estus enkondukita inter konstruado de `ManuallyDrop` kaj konstruado de la ĉeno (kio ne povas okazi en la kodo kiel montrite), ĝi rezultigus likon kaj ne duoblan liberon.
/// Alivorte, `ManuallyDrop` eraras flanke anstataŭ erari flanke de (duobla) falado.
///
/// Ankaŭ, `ManuallyDrop` malhelpas nin devi "touch" `v` post transdono de la proprieto al `s`-la fina paŝo interagi kun `v` por forigi ĝin sen funkciigi ĝian detruanton estas tute evitita.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Kiel [`forget`], sed ankaŭ akceptas nedimensiajn valorojn.
///
/// Ĉi tiu funkcio estas nur ŝimeto destinita al forigo kiam la `unsized_locals`-funkcio stabiliĝas.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Liveras la grandecon de tipo en bajtoj.
///
/// Pli specife, ĉi tio estas la ofseto en bajtoj inter pluaj elementoj en tabelo kun tiu ero-tipo inkluzive de viciga kompletigo.
///
/// Tiel, por iu tipo `T` kaj longo `n`, `[T; n]` havas grandecon de `n * size_of::<T>()`.
///
/// Ĝenerale la grandeco de tipo ne estas stabila inter kompiloj, sed specifaj tipoj kiel primitivuloj estas.
///
/// La sekva tabelo donas la grandecon por primitivuloj.
///
/// Tajpu |grandeco_de: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 signoj |4
///
/// Krome, `usize` kaj `isize` havas la saman grandecon.
///
/// La specoj `*const T`, `&T`, `Box<T>`, `Option<&T>` kaj `Option<Box<T>>` ĉiuj havas la saman grandecon.
/// Se `T` estas Grandigita, ĉiuj tiuj tipoj havas la saman grandecon kiel `usize`.
///
/// La ŝanĝebleco de montrilo ne ŝanĝas sian grandecon.Tiel, `&T` kaj `&mut T` havas la saman grandecon.
/// Same por `*const T` kaj `* mut T`.
///
/// # Grandeco de `#[repr(C)]`-aĵoj
///
/// La `C`-reprezento por eroj havas difinitan aranĝon.
/// Kun ĉi tiu aranĝo, la grandeco de eroj ankaŭ stabilas kondiĉe ke ĉiuj kampoj havas stabilan grandecon.
///
/// ## Grandeco de Strukturoj
///
/// Por `structs`, la grandeco estas determinita per la sekva algoritmo.
///
/// Por ĉiu kampo en la strukturo ordigita per deklara ordo:
///
/// 1. Aldonu la grandecon de la kampo.
/// 2. Rondigu la nunan grandecon al la plej proksima oblo de la sekva kampo [alignment].
///
/// Fine ĉirkaŭiru la grandecon de la strukturo al la plej proksima oblo de ĝia [alignment].
/// La vicigo de la strukturo estas kutime la plej granda vicigo de ĉiuj ĝiaj kampoj;ĉi tio povas esti ŝanĝita per la uzo de `repr(align(N))`.
///
/// Male al `C`, nul-grandaj strukturoj ne estas rondigitaj ĝis unu bajto.
///
/// ## Grandeco de Enumeroj
///
/// Enumeroj, kiuj ne portas aliajn datumojn krom la diskriminacio, havas la saman grandecon kiel C-enumeroj sur la platformo por kiu ili estas kompilitaj.
///
/// ## Grandeco de Sindikatoj
///
/// La grandeco de unio estas la grandeco de sia plej granda kampo.
///
/// Male al `C`, nulgrandaj kuniĝoj ne rondiĝas ĝis unu bajto.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Iuj primitivuloj
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Iuj tabeloj
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Montrilo grandeco egaleco
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Uzante `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // La grandeco de la unua kampo estas 1, do aldonu 1 al la grandeco.Grandeco estas 1.
/// // La vicigo de la dua kampo estas 2, do aldonu 1 al la grandeco por kompletigo.Grandeco estas 2.
/// // La grandeco de la dua kampo estas 2, do aldonu 2 al la grandeco.Grandeco estas 4.
/// // La vicigo de la tria kampo estas 1, do aldonu 0 al la grandeco por kompletigo.Grandeco estas 4.
/// // La grandeco de la tria kampo estas 1, do aldonu 1 al la grandeco.Grandeco estas 5.
/// // Fine, la vicigo de la strukturo estas 2 (ĉar la plej granda vicigo inter ĝiaj kampoj estas 2), do aldonu 1 al la grandeco por kompletigo.
/// // Grandeco estas 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Opstrukturoj sekvas la samajn regulojn.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Notu, ke reordigi la kampojn povas malpliigi la grandecon.
/// // Ni povas forigi ambaŭ kompletigajn bajtojn metante `third` antaŭ `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Unia grandeco estas la grandeco de la plej granda kampo.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Liveras la grandecon de la indikita valoro en bajtoj.
///
/// Ĉi tio kutime samas kiel `size_of::<T>()`.
/// Tamen, kiam `T`*havas* neniun statike konatan grandecon, ekzemple tranĉaĵon [`[T]`][slice] aŭ [trait object], tiam `size_of_val` povas esti uzata por akiri la dinamike konatan grandecon.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SEKURECO: `val` estas referenco, do ĝi estas valida kruda montrilo
    unsafe { intrinsics::size_of_val(val) }
}

/// Liveras la grandecon de la indikita valoro en bajtoj.
///
/// Ĉi tio kutime samas kiel `size_of::<T>()`.Tamen, kiam `T`*havas* neniun statike konatan grandecon, ekzemple tranĉaĵon [`[T]`][slice] aŭ [trait object], tiam `size_of_val_raw` povas esti uzata por akiri la dinamike konatan grandecon.
///
/// # Safety
///
/// Ĉi tiu funkcio estas sekure alvokebla nur se sekvas la jenaj kondiĉoj:
///
/// - Se `T` estas `Sized`, ĉi tiu funkcio estas ĉiam sekure alvokebla.
/// - Se la nedimensia vosto de `T` estas:
///     - a [slice], tiam la longo de la tranĉaĵa vosto devas esti pravalorizita entjero, kaj la grandeco de la *tuta valoro*(dinamika vosta longo + statike granda prefikso) devas kongrui en `isize`.
///     - a [trait object], tiam la vtable-parto de la montrilo devas montri al valida vtable akirita per malgrandiga devigo, kaj la grandeco de la *tuta valoro*(dinamika vostolongo + statike grandigita prefikso) devas kongrui en `isize`.
///
///     - (unstable) [extern type], tiam ĉi tiu funkcio estas ĉiam sekura telefonebla, sed panic aŭ alimaniere redonas la malĝustan valoron, ĉar la aranĝo de la ekstera tipo ne estas konata.
///     Ĉi tiu estas la sama konduto kiel [`size_of_val`] pri referenco al tipo kun ekstera tipa vosto.
///     - alie, konservative ne rajtas nomi ĉi tiun funkcion.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SEKURECO: la alvokanto devas provizi validan krudan montrilon
    unsafe { intrinsics::size_of_val(val) }
}

/// Liveras la bezonatan minimuman vicigon de tipo [ABI].
///
/// Ĉiu referenco al valoro de la tipo `T` devas esti oblo de ĉi tiu nombro.
///
/// Ĉi tiu estas la vicigo uzata por struktaj kampoj.Ĝi eble estas pli malgranda ol la preferata vicigo.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Liveras la bezonatan minimuman vicigon de [ABI] de la tipo de la valoro al kiu montras `val`.
///
/// Ĉiu referenco al valoro de la tipo `T` devas esti oblo de ĉi tiu nombro.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SEKURECO: val estas referenco, do ĝi estas valida kruda montrilo
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Liveras la bezonatan minimuman vicigon de tipo [ABI].
///
/// Ĉiu referenco al valoro de la tipo `T` devas esti oblo de ĉi tiu nombro.
///
/// Ĉi tiu estas la vicigo uzata por struktaj kampoj.Ĝi eble estas pli malgranda ol la preferata vicigo.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Liveras la bezonatan minimuman vicigon de [ABI] de la tipo de la valoro al kiu montras `val`.
///
/// Ĉiu referenco al valoro de la tipo `T` devas esti oblo de ĉi tiu nombro.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SEKURECO: val estas referenco, do ĝi estas valida kruda montrilo
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Liveras la bezonatan minimuman vicigon de [ABI] de la tipo de la valoro al kiu montras `val`.
///
/// Ĉiu referenco al valoro de la tipo `T` devas esti oblo de ĉi tiu nombro.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Ĉi tiu funkcio estas sekure alvokebla nur se sekvas la jenaj kondiĉoj:
///
/// - Se `T` estas `Sized`, ĉi tiu funkcio estas ĉiam sekure alvokebla.
/// - Se la nedimensia vosto de `T` estas:
///     - a [slice], tiam la longo de la tranĉaĵa vosto devas esti pravalorizita entjero, kaj la grandeco de la *tuta valoro*(dinamika vosta longo + statike granda prefikso) devas kongrui en `isize`.
///     - a [trait object], tiam la vtable-parto de la montrilo devas montri al valida vtable akirita per malgrandiga devigo, kaj la grandeco de la *tuta valoro*(dinamika vostolongo + statike grandigita prefikso) devas kongrui en `isize`.
///
///     - (unstable) [extern type], tiam ĉi tiu funkcio estas ĉiam sekura telefonebla, sed panic aŭ alimaniere redonas la malĝustan valoron, ĉar la aranĝo de la ekstera tipo ne estas konata.
///     Ĉi tiu estas la sama konduto kiel [`align_of_val`] pri referenco al tipo kun ekstera tipa vosto.
///     - alie, konservative ne rajtas nomi ĉi tiun funkcion.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SEKURECO: la alvokanto devas provizi validan krudan montrilon
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Liveras `true` se falas valoroj de tipo `T` gravas.
///
/// Ĉi tio estas nur konsilo pri optimumigo, kaj povas esti efektivigita konservative:
/// ĝi eble redonos `true` por tipoj, kiuj ne efektive devas esti forĵetitaj.
/// Kiel tia ĉiam redoni `true` estus valida efektivigo de ĉi tiu funkcio.Tamen se ĉi tiu funkcio efektive redonas `false`, tiam vi povas esti certa, ke faligi `T` havas neniun kromefikon.
///
/// Malaltnivelaj efektivigoj de aferoj kiel kolektoj, kiuj bezonas mane faligi siajn datumojn, devas uzi ĉi tiun funkcion por eviti nenecese provi faligi sian tutan enhavon kiam ili estas detruitaj.
///
/// Ĉi tio eble ne diferencas en eldonaj versioj (kie buklo, kiu havas neniujn kromefikojn, facile detekteblas kaj forigeblas), sed ofte estas granda venko por debug-versioj.
///
/// Notu, ke [`drop_in_place`] jam plenumas ĉi tiun kontrolon, do se via labora ŝarĝo redukteblas al iu malgranda nombro da [`drop_in_place`]-vokoj, uzi ĉi tion estas nenecese.
/// Precipe rimarku, ke vi povas [`drop_in_place`] tranĉi, kaj tio faros ununuran bezonan_kontrolon pri ĉiuj valoroj.
///
/// Tipoj kiel Vec do nur `drop_in_place(&mut self[..])` sen uzi `needs_drop` eksplicite.
/// Tipoj kiel [`HashMap`], aliflanke, devas faligi valorojn unuope kaj devas uzi ĉi tiun API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Jen ekzemplo pri kiel kolekto povus uzi `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // faligu la datumojn
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Liveras la valoron de tipo `T` reprezentita per la tute-nula bajta ŝablono.
///
/// Ĉi tio signifas, ke ekzemple la kompletiga bajto en `(u8, u16)` ne nepre estas nuligita.
///
/// Estas neniu garantio, ke tute-nula bajta ŝablono reprezentas validan valoron de iu tipo `T`.
/// Ekzemple, la tute-nula bajta ŝablono ne estas valida valoro por referencaj tipoj (`&T`, `&mut T`) kaj funkciaj montriloj.
/// Uzi `zeroed` sur tiaj specoj kaŭzas tujan [undefined behavior][ub] ĉar [the Rust compiler assumes][inv], ke ĉiam ekzistas valida valoro en variablo, kiun ĝi konsideras inicialigita.
///
///
/// Ĉi tio efikas same kiel [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Ĝi estas utila por FFI kelkfoje, sed ĝenerale evitenda.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Ĝusta uzado de ĉi tiu funkcio: pravalorizado de entjero kun nulo.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Malĝusta* uzado de ĉi tiu funkcio: komenci referencon per nulo.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Nedifinita konduto!
/// let _y: fn() = unsafe { mem::zeroed() }; // Kaj denove!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SEKURECO: la alvokanto devas garantii, ke tute-nula valoro validas por `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Preterpasas la normalajn kontrolojn de memorigo de Rust per ŝajnigado produkti valoron de tipo `T`, dum tute nenion faras.
///
/// **Ĉi tiu funkcio estas malrekomendata.** Uzu [`MaybeUninit<T>`] anstataŭe.
///
/// La kialo de malrekomendo estas, ke la funkcio esence ne povas esti ĝuste uzata: ĝi efikas same kiel [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Kiel la [`assume_init` documentation][assume_init] klarigas, [the Rust compiler assumes][inv], ke valoroj estas ĝuste pravalorizitaj.
/// Kiel konsekvenco, voki ekz
/// `mem::uninitialized::<bool>()` kaŭzas tujan nedifinitan konduton por redoni `bool`, kiu certe ne estas nek `true` nek `false`.
/// Pli malbona, vere seniniciata memoro kiel tio, kio estas resendita ĉi tie, estas speciala, ĉar la kompililo scias, ke ĝi ne havas fiksan valoron.
/// Ĉi tio faras nedifinitan konduton havi neinicialigitajn datumojn en variablo eĉ se tiu variablo havas entjeran tipon.
/// (Rimarku, ke la reguloj ĉirkaŭ neinicialigitaj entjeroj ankoraŭ ne estas finitaj, sed ĝis ili estas, estas konsilinde eviti ilin.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SEKURECO: la alvokanto devas garantii, ke unuigita valoro validas por `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Interŝanĝas la valorojn ĉe du ŝanĝeblaj lokoj, sen seninicialigi unu.
///
/// * Se vi volas interŝanĝi kun apriora aŭ imita valoro, vidu [`take`].
/// * Se vi volas interŝanĝi kun pasita valoro, redonante la malnovan valoron, vidu [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SEKURECO: la krudaj montriloj estis kreitaj el sekuraj ŝanĝeblaj referencoj kontentigantaj ĉiujn
    // limoj sur `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Anstataŭigas `dest` per la apriora valoro de `T`, redonante la antaŭan `dest`-valoron.
///
/// * Se vi volas anstataŭigi la valorojn de du variabloj, vidu [`swap`].
/// * Se vi volas anstataŭigi per pasigita valoro anstataŭ la defaŭlta valoro, vidu [`replace`].
///
/// # Examples
///
/// Simpla ekzemplo:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` permesas ekposedon de struktura kampo anstataŭigante ĝin per "empty"-valoro.
/// Sen `take` vi povas renkonti problemojn kiel ĉi tiuj:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Notu, ke `T` ne nepre efektivigas [`Clone`], do ĝi eĉ ne povas kloni kaj reagordi `self.buf`.
/// Sed `take` povas esti uzata por disigi la originalan valoron de `self.buf` de `self`, permesante redoni ĝin:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Movas `src` en la referencitan `dest`, redonante la antaŭan `dest`-valoron.
///
/// Nek valoro malaltiĝas.
///
/// * Se vi volas anstataŭigi la valorojn de du variabloj, vidu [`swap`].
/// * Se vi volas anstataŭigi per apriora valoro, vidu [`take`].
///
/// # Examples
///
/// Simpla ekzemplo:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` permesas konsumon de struktura kampo anstataŭigante ĝin per alia valoro.
/// Sen `replace` vi povas renkonti problemojn kiel ĉi tiuj:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Notu, ke `T` ne nepre efektivigas [`Clone`], do ni eĉ ne povas kloni `self.buf[i]` por eviti la movon.
/// Sed `replace` povas esti uzata por disigi la originalan valoron ĉe tiu indekso de `self`, permesante ĝin redoni:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SEKURECO: Ni legas de `dest` sed rekte skribas `src` en ĝin poste,
    // tia ke la malnova valoro ne estas duobligita.
    // Nenio falas kaj nenio ĉi tie povas panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Forigas valoron.
///
/// Ĉi tio faras vokante la efektivigon de la argumento de [`Drop`][drop].
///
/// Ĉi tio efike faras nenion por specoj, kiuj efektivigas `Copy`, ekz
/// integers.
/// Tiaj valoroj estas kopiitaj kaj _then_ movita en la funkcion, do la valoro daŭras post ĉi tiu funkcio.
///
///
/// Ĉi tiu funkcio ne estas magia;ĝi estas laŭvorte difinita kiel
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Ĉar `_x` estas movita en la funkcion, ĝi aŭtomate falas antaŭ ol la funkcio revenas.
///
/// [drop]: Drop
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // eksplicite faligi la vector
/// ```
///
/// Ĉar [`RefCell`] plenumas la pruntajn regulojn dum rultempo, `drop` povas liberigi prunton de [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // rezignu la ŝanĝeblan prunton en ĉi tiu fendo
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Entjeroj kaj aliaj specoj efektivigantaj [`Copy`] ne estas influitaj de `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // kopio de `x` estas movita kaj faligita
/// drop(y); // kopio de `y` estas movita kaj faligita
///
/// println!("x: {}, y: {}", x, y.0); // ankoraŭ disponebla
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpretas `src` kiel tipon `&U`, kaj tiam legas `src` sen movi la enhavitan valoron.
///
/// Ĉi tiu funkcio malsekure supozos, ke la montrilo `src` validas por [`size_of::<U>`][size_of]-bitokoj per transmutacio de `&T` al `&U` kaj tiam legado de la `&U` (krom ke tio fariĝas ĝuste eĉ kiam `&U` faras pli striktajn vicigajn postulojn ol `&T`).
/// Ĝi ankaŭ malsekure kreos kopion de la enhavita valoro anstataŭ eliri el `src`.
///
/// Ne estas kompila tempo-eraro se `T` kaj `U` havas malsamajn grandecojn, sed estas tre kuraĝe alvoki nur ĉi tiun funkcion, kie `T` kaj `U` havas la saman grandecon.Ĉi tiu funkcio ekigas [undefined behavior][ub] se `U` estas pli granda ol `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopiu la datumojn de 'foo_array' kaj traktu ĝin kiel 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Modifi la kopiitajn datumojn
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // La enhavo de 'foo_array' ne devus esti ŝanĝita
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Se U havas pli altan vicigan postulon, src eble ne taŭge viciĝas.
    if align_of::<U>() > align_of::<T>() {
        // SEKURECO: `src` estas referenco, kiu certas esti valida por legaĵoj.
        // La alvokanto devas garantii, ke la efektiva transmutacio estas sekura.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SEKURECO: `src` estas referenco, kiu certas esti valida por legaĵoj.
        // Ni ĵus kontrolis, ke `src as *const U` estis ĝuste vicigita.
        // La alvokanto devas garantii, ke la efektiva transmutacio estas sekura.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Maldiafana tipo reprezentanta la diskriminanton de enum.
///
/// Vidu la funkcion [`discriminant`] en ĉi tiu modulo por pliaj informoj.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Ĉi tiuj trait-efektivigoj ne povas esti derivitaj ĉar ni ne volas limojn por T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Liveras valoron unike identigante la enum-varianton en `v`.
///
/// Se `T` ne estas enum, voki ĉi tiun funkcion ne rezultigos nedifinitan konduton, sed la revenvaloro estas nespecifita.
///
///
/// # Stability
///
/// La diskriminanto de enuma varianto povas ŝanĝiĝi se la enuma difino ŝanĝiĝas.
/// Diskriminanto de iu varianto ne ŝanĝiĝos inter kompiloj kun la sama kompililo.
///
/// # Examples
///
/// Ĉi tio povas esti uzata por kompari enumojn kun datumoj, malatentante la realajn datumojn:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Liveras la nombron de variantoj en la enum-tipo `T`.
///
/// Se `T` ne estas enum, voki ĉi tiun funkcion ne rezultigos nedifinitan konduton, sed la revenvaloro estas nespecifita.
/// Egale, se `T` estas enum kun pli da variantoj ol `usize::MAX`, la revenvaloro estas nespecifita.
/// Neloĝataj variantoj estos kalkulitaj.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}