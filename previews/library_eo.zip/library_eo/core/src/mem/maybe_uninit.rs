use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Envolva tipo por konstrui neinicialigitajn ekzemplojn de `T`.
///
/// # Inicialigo senvaria
///
/// La kompililo ĝenerale supozas, ke variablo estas ĝuste pravalorizita laŭ la postuloj de la tipo de la variablo.Ekzemple, variablo de referenca tipo devas esti vicigita kaj ne-NULA.
/// Ĉi tio estas neŝanĝebla, kiu devas *ĉiam* esti subtenata, eĉ en nesekura kodo.
/// Kiel konsekvenco, nul-komenca variablo de referenca tipo kaŭzas tujan [undefined behavior][ub], negrave ĉu tiu referenco iam kutimas aliri memoron:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // nedifinita konduto!⚠️
/// // La ekvivalenta kodo kun `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // nedifinita konduto!⚠️
/// ```
///
/// Ĉi tio estas ekspluatata de la kompililo por diversaj optimumigoj, kiel ekzemple eviti rultempajn kontrolojn kaj optimumigi `enum`-aranĝon.
///
/// Simile, tute neinicialigita memoro povas havi ajnan enhavon, dum `bool` ĉiam devas esti `true` aŭ `false`.Sekve, krei neinicialigitan `bool` estas nedifinita konduto:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // nedifinita konduto!⚠️
/// // La ekvivalenta kodo kun `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // nedifinita konduto!⚠️
/// ```
///
/// Cetere, neinicialigita memoro estas speciala, ĉar ĝi ne havas fiksan valoron ("fixed" signifanta "it won't change without being written to").Legi la saman neinicialigitan bajton plurfoje povas doni malsamajn rezultojn.
/// Ĉi tio igas nedifinitan konduton havi neinicialigitajn datumojn en variablo eĉ se tiu variablo havas entjeran tipon, kiu alie povas teni iun ajn *fiksan* biton:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // nedifinita konduto!⚠️
/// // La ekvivalenta kodo kun `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // nedifinita konduto!⚠️
/// ```
/// (Rimarku, ke la reguloj ĉirkaŭ neinicialigitaj entjeroj ankoraŭ ne estas finitaj, sed ĝis ili estas, estas konsilinde eviti ilin.)
///
/// Aldone al tio, memoru, ke plej multaj tipoj havas aldonajn senvariantojn preter nur konsiderataj pravalorizitaj je la tipo-nivelo.
/// Ekzemple, '1`-komencita [`Vec<T>`] estas konsiderata pravalorizita (sub la nuna efektivigo; ĉi tio ne konsistigas stabilan garantion) ĉar la sola postulo, kiun la kompilinto scias pri ĝi, estas, ke la datuma montrilo devas esti nenula.
/// Krei tian `Vec<T>` ne kaŭzas *tujan* nedifinitan konduton, sed kaŭzos nedifinitan konduton kun plej sekuraj operacioj (inkluzive faligi ĝin).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` utilas por ebligi nesekuran kodon trakti neinicialigitajn datumojn.
/// Ĝi estas signalo al la kompililo, kiu indikas, ke la datumoj ĉi tie eble *ne* estu pravalorizitaj:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Kreu eksplicite neinicialigitan referencon.
/// // La kompililo scias, ke datumoj ene de `MaybeUninit<T>` povas esti malvalidaj, kaj tial ĉi tio ne estas UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Agordu ĝin al valida valoro.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Ĉerpu la pravalorizitajn datumojn-ĉi tio estas permesata nur *post* ĝuste pravalorizi `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// La kompililo tiam scias ne fari malĝustajn supozojn aŭ optimumigojn pri ĉi tiu kodo.
///
/// Vi povas pensi pri `MaybeUninit<T>` kiel iom simila al `Option<T>` sed sen iu ajn rultempa spurado kaj sen iuj sekurecaj kontroloj.
///
/// ## out-pointers
///
/// Vi povas uzi `MaybeUninit<T>` por efektivigi "out-pointers": anstataŭ redoni datumojn de funkcio, transdonu ĝin al iu (uninitialized)-memoro por enmeti la rezulton.
/// Ĉi tio povas esti utila kiam gravas por la alvokanto kontroli kiel la memoro en kiu estas konservita rezulto estas asignita, kaj vi volas eviti nenecesajn movojn.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ne faligas la malnovan enhavon, kio gravas.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Nun ni scias, ke `v` estas pravalorizita!Ĉi tio ankaŭ certigas, ke la vector konvene falas.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inicialigo de tabelo elemento post elemento
///
/// `MaybeUninit<T>` uzeblas por pravalorizi grandan tabelon elementon post elemento:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Kreu neinicialigitan tabelon de `MaybeUninit`.
///     // La `assume_init` estas sekura ĉar la tipo, kiun ni pretendas inicialigi ĉi tie, estas aro da "EbleUnit", kiuj ne bezonas inicialigon.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Faligi `MaybeUninit` faras nenion.
///     // Tiel uzi krudan montrilan taskon anstataŭ `ptr::write` ne kaŭzas la malnovan neinicialigitan valoron faligi.
/////
///     // Ankaŭ se estas panic dum ĉi tiu buklo, ni havas memoran likon, sed ne ekzistas problemo pri memora sekureco.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Ĉio estas pravalorizita.
///     // Transmutu la tabelon al la komencita tipo.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Vi ankaŭ povas labori kun parte komencitaj tabeloj, kiuj troveblas en malaltnivelaj datumstrukturoj.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Kreu neinicialigitan tabelon de `MaybeUninit`.
/// // La `assume_init` estas sekura ĉar la tipo, kiun ni pretendas inicialigi ĉi tie, estas aro da "EbleUnit", kiuj ne bezonas inicialigon.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Kalkulu la nombron de elementoj, kiujn ni asignis.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Por ĉiu ero en la tabelo, faligu se ni asignis ĝin.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Komencante strukt kampon post kampo
///
/// Vi povas uzi `MaybeUninit<T>`, kaj la [`std::ptr::addr_of_mut`]-makroon, por pravalorizi strukturojn kampo post kampo:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Komencante la kampon `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Komenci la `list`-kampon Se estas panic ĉi tie, tiam la `String` en la `name`-kampo likas.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Ĉiuj kampoj estas pravalorizitaj, do ni telefonas al `assume_init` por ricevi pravalorizitan Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` estas garantiita havi la saman grandecon, vicigon kaj ABI kiel `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Tamen memoru, ke tipo *enhavanta*`MaybeUninit<T>` ne nepre estas la sama aranĝo;Rust ĝenerale ne garantias, ke la kampoj de `Foo<T>` havas la saman ordon kiel `Foo<U>` eĉ se `T` kaj `U` havas la saman grandecon kaj vicon.
///
/// Krome ĉar iu ajn bitvaloro validas por `MaybeUninit<T>` la kompililo ne povas apliki non-zero/niche-filling-optimumigojn, eble rezultigante pli grandan grandecon:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Se `T` estas FFI-sekura, do ankaŭ `MaybeUninit<T>`.
///
/// Dum `MaybeUninit` estas `#[repr(transparent)]` (indikante ke ĝi garantias la saman grandecon, vicigon kaj ABI kiel `T`), ĉi tio *ne* ŝanĝas iujn ajn el la antaŭaj avertoj.
/// `Option<T>` kaj `Option<MaybeUninit<T>>` ankoraŭ povas havi malsamajn grandecojn, kaj specoj enhavantaj kampon de tipo `T` povas esti aranĝitaj (kaj mezuritaj) alimaniere ol se tiu kampo estus `MaybeUninit<T>`.
/// `MaybeUninit` estas unia tipo, kaj `#[repr(transparent)]` ĉe kuniĝoj estas malstabila (vidu [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Kun la paso de la tempo, la ĝustaj garantioj de `#[repr(transparent)]` pri sindikatoj povas evolui, kaj `MaybeUninit` povas aŭ ne resti `#[repr(transparent)]`.
/// Dirite, `MaybeUninit<T>`*ĉiam* garantios, ke ĝi havas la saman grandecon, vicon kaj ABI kiel `T`;nur la maniero kiel `MaybeUninit` efektivigas tiun garantion povas evolui.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang-aĵo por ke ni povu envolvi aliajn specojn en ĝi.Ĉi tio utilas por generatoroj.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ne vokante `T::clone()`, ni ne povas scii, ĉu ni estas sufiĉe pravalorizitaj por tio.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Kreas novan `MaybeUninit<T>` komencitan per la donita valoro.
    /// Estas sekure telefoni [`assume_init`] al la redonita valoro de ĉi tiu funkcio.
    ///
    /// Notu, ke faligi `MaybeUninit<T>` neniam vokos la faligan kodon de "T".
    /// Estas via respondeco certigi, ke `T` falos, se ĝi estos pravalorizita.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Kreas novan `MaybeUninit<T>` en senpripensa stato.
    ///
    /// Notu, ke faligi `MaybeUninit<T>` neniam vokos la faligan kodon de "T".
    /// Estas via respondeco certigi, ke `T` falos, se ĝi estos pravalorizita.
    ///
    /// Vidu la [type-level documentation][MaybeUninit] por iuj ekzemploj.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Kreu novan tabelon de `MaybeUninit<T>`-aĵoj, en neinicialigita stato.
    ///
    /// Note: en versio future Rust ĉi tiu metodo povas iĝi nenecesa kiam tabla laŭvorta sintakso permesas [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// La suba ekzemplo tiam povus uzi `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Liveras (eble pli malgrandan) tranĉaĵon de datumoj, kiuj estis vere legitaj
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SEKURECO: Unitialized `[MaybeUninit<_>; LEN]` validas.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Kreas novan `MaybeUninit<T>` en seniniciata stato, kun la memoro plenigita per `0`-bitokoj.Dependas de `T`, ĉu tio jam taŭgas por ĝusta inicialigo.
    ///
    /// Ekzemple, `MaybeUninit<usize>::zeroed()` estas pravalorizita, sed `MaybeUninit<&'static i32>::zeroed()` ne ĉar referencoj ne devas esti nulaj.
    ///
    /// Notu, ke faligi `MaybeUninit<T>` neniam vokos la faligan kodon de "T".
    /// Estas via respondeco certigi, ke `T` falos, se ĝi estos pravalorizita.
    ///
    /// # Example
    ///
    /// Ĝusta uzado de ĉi tiu funkcio: pravalorizado de strukt kun nulo, kie ĉiuj kampoj de la strukt povas teni la bit-ŝablonon 0 kiel validan valoron.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Malĝusta* uzado de ĉi tiu funkcio: voki `x.zeroed().assume_init()` kiam `0` ne estas valida bita ŝablono por la tipo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // En paro, ni kreas `NotZero`, kiu ne havas validan diskriminanton.
    /// // Ĉi tio estas nedifinita konduto.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SEKURECO: `u.as_mut_ptr()` montras al asignita memoro.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Agordas la valoron de la `MaybeUninit<T>`.
    /// Ĉi tio anstataŭigas iun ajn antaŭan valoron sen faligi ĝin, do zorgu ne uzi ĉi tion dufoje krom se vi volas preterlasi funkciigi la detruilon.
    ///
    /// Por via komforto, ĉi tio ankaŭ redonas ŝanĝeblan referencon al la (nun sekure pravalorizita) enhavo de `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SEKURECO: Ni ĵus pravalorizis ĉi tiun valoron.
        unsafe { self.assume_init_mut() }
    }

    /// Akiras montrilon al la enhavita valoro.
    /// Legi de ĉi tiu montrilo aŭ fari ĝin referenco estas nedifinita konduto krom se la `MaybeUninit<T>` estas pravalorizita.
    /// Skribi al memoro, kiun montras ĉi tiu montrilo (non-transitively), estas nedifinita konduto (krom ene de `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Ĝusta uzado de ĉi tiu metodo:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Kreu referencon en la `MaybeUninit<T>`.Ĉi tio estas en ordo, ĉar ni pravalorizis ĝin.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Malĝusta* uzado de ĉi tiu metodo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Ni kreis referencon al neinicialigita vector!Ĉi tio estas nedifinita konduto.⚠️
    /// ```
    ///
    /// (Rimarku, ke la reguloj pri referencoj al neinicialigitaj datumoj ankoraŭ ne estas finitaj, sed ĝis ili estas, konsilas eviti ilin.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` kaj `ManuallyDrop` estas ambaŭ `repr(transparent)` do ni povas ĵeti la montrilon.
        self as *const _ as *const T
    }

    /// Akiras ŝanĝeblan montrilon al la enhavita valoro.
    /// Legi de ĉi tiu montrilo aŭ fari ĝin referenco estas nedifinita konduto krom se la `MaybeUninit<T>` estas pravalorizita.
    ///
    /// # Examples
    ///
    /// Ĝusta uzado de ĉi tiu metodo:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Kreu referencon en la `MaybeUninit<Vec<u32>>`.
    /// // Ĉi tio estas en ordo, ĉar ni pravalorizis ĝin.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Malĝusta* uzado de ĉi tiu metodo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Ni kreis referencon al neinicialigita vector!Ĉi tio estas nedifinita konduto.⚠️
    /// ```
    ///
    /// (Rimarku, ke la reguloj pri referencoj al neinicialigitaj datumoj ankoraŭ ne estas finitaj, sed ĝis ili estas, konsilas eviti ilin.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` kaj `ManuallyDrop` estas ambaŭ `repr(transparent)` do ni povas ĵeti la montrilon.
        self as *mut _ as *mut T
    }

    /// Ĉerpas la valoron de la `MaybeUninit<T>`-ujo.Ĉi tio estas bonega maniero certigi, ke la datumoj malaperos, ĉar la rezulta `T` estas submetita al la kutima falmaniero.
    ///
    /// # Safety
    ///
    /// Dependas de la alvokanto garantii, ke la `MaybeUninit<T>` vere estas en pravalorizita stato.Voki ĉi tion kiam la enhavo ankoraŭ ne estas tute pravalorizita kaŭzas tujan nedifinitan konduton.
    /// La [type-level documentation][inv] enhavas pli da informoj pri ĉi tiu komenciga invarianto.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Aldone al tio, memoru, ke plej multaj tipoj havas aldonajn senvariantojn preter nur konsiderataj pravalorizitaj je la tipo-nivelo.
    /// Ekzemple, '1`-komencita [`Vec<T>`] estas konsiderata pravalorizita (sub la nuna efektivigo; ĉi tio ne konsistigas stabilan garantion) ĉar la sola postulo, kiun la kompilinto scias pri ĝi, estas, ke la datuma montrilo devas esti nenula.
    ///
    /// Krei tian `Vec<T>` ne kaŭzas *tujan* nedifinitan konduton, sed kaŭzos nedifinitan konduton kun plej sekuraj operacioj (inkluzive faligi ĝin).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Ĝusta uzado de ĉi tiu metodo:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Malĝusta* uzado de ĉi tiu metodo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ankoraŭ ne estis pravalorizita, do ĉi tiu lasta linio kaŭzis nedifinitan konduton.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SEKURECO: la alvokanto devas garantii, ke `self` estas pravalorizita.
        // Ĉi tio ankaŭ signifas, ke `self` devas esti `value`-varianto.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Legas la valoron de la `MaybeUninit<T>`-ujo.La rezulta `T` estas submetita al la kutima falmaniero.
    ///
    /// Kiam ajn eblas, estas preferinde uzi [`assume_init`] anstataŭe, kio malebligas duobligi la enhavon de la `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Dependas de la alvokanto garantii, ke la `MaybeUninit<T>` vere estas en pravalorizita stato.Voki ĉi tion kiam la enhavo ankoraŭ ne estas tute pravalorizita kaŭzas nedifinitan konduton.
    /// La [type-level documentation][inv] enhavas pli da informoj pri ĉi tiu komenciga invarianto.
    ///
    /// Cetere ĉi tio lasas kopion de la samaj datumoj en la `MaybeUninit<T>`.
    /// Kiam vi uzas plurajn kopiojn de la datumoj (vokante `assume_init_read` plurfoje, aŭ unue vokante `assume_init_read` kaj poste [`assume_init`]), estas via respondeco certigi, ke tiuj datumoj efektive estu duobligitaj.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Ĝusta uzado de ĉi tiu metodo:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` estas `Copy`, do ni eble legos plurfoje.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Kopii `None`-valoron estas en ordo, do ni eble legos plurfoje.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Malĝusta* uzado de ĉi tiu metodo:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Ni nun kreis du kopiojn de la sama vector, kio kondukas al duoble senpaga ⚠️ kiam ili ambaŭ falos!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SEKURECO: la alvokanto devas garantii, ke `self` estas pravalorizita.
        // Legado de `self.as_ptr()` estas sekura, ĉar `self` devas esti pravalorizita.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Faligas la enhavitan valoron modloko.
    ///
    /// Se vi posedas la `MaybeUninit`, vi povas uzi [`assume_init`] anstataŭe.
    ///
    /// # Safety
    ///
    /// Dependas de la alvokanto garantii, ke la `MaybeUninit<T>` vere estas en pravalorizita stato.Voki ĉi tion kiam la enhavo ankoraŭ ne estas tute pravalorizita kaŭzas nedifinitan konduton.
    ///
    /// Aldone al tio, ĉiuj aldonaj invariantoj de la tipo `T` devas esti kontentigitaj, ĉar la efektivigo de `Drop` de `T` (aŭ ĝiaj membroj) povas fidi ĉi tion.
    /// Ekzemple, '1`-komencita [`Vec<T>`] estas konsiderata pravalorizita (sub la nuna efektivigo; ĉi tio ne konsistigas stabilan garantion) ĉar la sola postulo, kiun la kompilinto scias pri ĝi, estas, ke la datuma montrilo devas esti nenula.
    ///
    /// Faligi tian `Vec<T>` tamen kaŭzos nedifinitan konduton.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SEKURECO: la alvokanto devas garantii, ke `self` estas pravalorizita kaj
        // kontentigas ĉiujn invariantojn de `T`.
        // Faligi la valoron en loko estas sekura se tio estas la kazo.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Akiras komunan referencon al la enhavita valoro.
    ///
    /// Ĉi tio povas esti utila kiam ni volas aliri `MaybeUninit` kiu estis pravalorizita sed ne posedas la `MaybeUninit` (malebligante la uzon de `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Voki ĉi tion kiam la enhavo ankoraŭ ne estas plene pravalorizita kaŭzas nedifinitan konduton: dependas de la telefonanto garantii, ke la `MaybeUninit<T>` vere estas en pravalorizita stato.
    ///
    ///
    /// # Examples
    ///
    /// ### Ĝusta uzado de ĉi tiu metodo:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inicialigi `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Nun, kiam oni scias, ke nia `MaybeUninit<_>` estas komencita, estas bone krei komunan referencon al ĝi:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SEKURECO: `x` estis pravalorizita.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Malĝustaj* uzoj de ĉi tiu metodo:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Ni kreis referencon al neinicialigita vector!Ĉi tio estas nedifinita konduto.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Komencu la `MaybeUninit` per `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Referenco al neinicialigita `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SEKURECO: la alvokanto devas garantii, ke `self` estas pravalorizita.
        // Ĉi tio ankaŭ signifas, ke `self` devas esti `value`-varianto.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Akiras ŝanĝeblan (unique)-referencon al la enhavita valoro.
    ///
    /// Ĉi tio povas esti utila kiam ni volas aliri `MaybeUninit` kiu estis pravalorizita sed ne posedas la `MaybeUninit` (malebligante la uzon de `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Voki ĉi tion kiam la enhavo ankoraŭ ne estas plene pravalorizita kaŭzas nedifinitan konduton: dependas de la telefonanto garantii, ke la `MaybeUninit<T>` vere estas en pravalorizita stato.
    /// Ekzemple, `.assume_init_mut()` ne uzeblas por pravalorizi `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Ĝusta uzado de ĉi tiu metodo:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Komencas *ĉiujn* bitokojn de la eniga bufro.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inicialigi `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Nun ni scias, ke `buf` estis pravalorizita, do ni povus `.assume_init()` ĝin.
    /// // Tamen uzi `.assume_init()` povas ekigi `memcpy` de la 2048-bajtoj.
    /// // Por aserti, ke nia bufro estis pravalorizita sen kopii ĝin, ni ĝisdatigas la `&mut MaybeUninit<[u8; 2048]>` al `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SEKURECO: `buf` estis pravalorizita.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Nun ni povas uzi `buf` kiel normalan tranĉaĵon:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Malĝustaj* uzoj de ĉi tiu metodo:
    ///
    /// Vi ne povas uzi `.assume_init_mut()` por pravalorizi valoron:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Ni kreis (mutable)-referencon al neinicialigita `bool`!
    ///     // Ĉi tio estas nedifinita konduto.⚠️
    /// }
    /// ```
    ///
    /// Ekzemple, vi ne povas [`Read`] en senpripensitan bufron:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) referenco al seninicia memoro!
    ///                             // Ĉi tio estas nedifinita konduto.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Ankaŭ vi ne povas uzi rektan kampan aliron por fari laŭkampan laŭgradan komencadon:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referenco al seninicia memoro!
    ///                  // Ĉi tio estas nedifinita konduto.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referenco al seninicia memoro!
    ///                  // Ĉi tio estas nedifinita konduto.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Ni nuntempe fidas, ke ĉi-supraj estas malĝustaj, do ni havas referencojn al neinicialigitaj datumoj (ekz. En `libcore/fmt/float.rs`).
    // Ni devas fari finan decidon pri la reguloj antaŭ stabiligo.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SEKURECO: la alvokanto devas garantii, ke `self` estas pravalorizita.
        // Ĉi tio ankaŭ signifas, ke `self` devas esti `value`-varianto.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Ĉerpas la valorojn el tabelo de `MaybeUninit`-ujoj.
    ///
    /// # Safety
    ///
    /// Dependas de la alvokanto garantii, ke ĉiuj elementoj de la tabelo estas en pravalorizita stato.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SEKURECO: Nun sekura, ĉar ni pravalorizis ĉiujn elementojn
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * La alvokanto garantias, ke ĉiuj elementoj de la tabelo estas pravalorizitaj
        // * `MaybeUninit<T>` kaj T estas garantiitaj havi la saman aranĝon
        // * EbleUnint ne falas, do ne ekzistas duoble-liberaj Kaj tiel la konvertiĝo estas sekura
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Supozante, ke ĉiuj elementoj estas pravalorizitaj, ricevu tranĉaĵon al ili.
    ///
    /// # Safety
    ///
    /// Dependas de la alvokanto garantii, ke la `MaybeUninit<T>`-elementoj vere estas en pravalorizita stato.
    ///
    /// Voki ĉi tion kiam la enhavo ankoraŭ ne estas tute pravalorizita kaŭzas nedifinitan konduton.
    ///
    /// Vidu [`assume_init_ref`] por pli da detaloj kaj ekzemploj.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SEKURECO: ĵeti tranĉaĵon al `*const [T]` estas sekura, ĉar la alvokanto garantias tion
        // `slice` estas pravalorizita, kaj "EbleUnit" estas garantiita havi la saman aranĝon kiel `T`.
        // La montrilo akirita validas, ĉar ĝi rilatas al memoro posedata de `slice`, kiu estas referenco kaj tiel garantiita esti valida por legaĵoj.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Supozante, ke ĉiuj elementoj estas pravalorizitaj, ricevu ŝanĝeblan tranĉaĵon al ili.
    ///
    /// # Safety
    ///
    /// Dependas de la alvokanto garantii, ke la `MaybeUninit<T>`-elementoj vere estas en pravalorizita stato.
    ///
    /// Voki ĉi tion kiam la enhavo ankoraŭ ne estas tute pravalorizita kaŭzas nedifinitan konduton.
    ///
    /// Vidu [`assume_init_mut`] por pli da detaloj kaj ekzemploj.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SEKURECO: simila al sekurecaj notoj por `slice_get_ref`, sed ni havas
        // ŝanĝebla referenco, kiu ankaŭ garantias validan por skribaĵoj.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Akiras montrilon al la unua elemento de la tabelo.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Akiras ŝanĝeblan montrilon al la unua elemento de la tabelo.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopias la elementojn de `src` al `this`, redonante ŝanĝeblan referencon al la nun komencita enhavo de `this`.
    ///
    /// Se `T` ne efektivigas `Copy`, uzu [`write_slice_cloned`]
    ///
    /// Ĉi tio similas al [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio estos panic se la du tranĉaĵoj havas malsamajn longojn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SEKURECO: ni ĵus kopiis ĉiujn elementojn de len en la rezervan kapaciton
    /// // la unuaj src.len()-elementoj de la vec validas nun.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SEKURECO: &[T] kaj&[EbleUnit<T>] havas la saman aranĝon
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SEKURECO: Validaj elementoj ĵus estis kopiitaj en `this` do ĝi estas komencita
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klonas la elementojn de `src` al `this`, redonante ŝanĝeblan referencon al la nun komencita enhavo de `this`.
    /// Iuj jam iniciigitaj elementoj ne estos faligitaj.
    ///
    /// Se `T` efektivigas `Copy`, uzu [`write_slice`]
    ///
    /// Ĉi tio similas al [`slice::clone_from_slice`] sed ne faligas ekzistantajn elementojn.
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio estos panic se la du tranĉaĵoj havas malsamajn longojn, aŭ se la efektivigo de `Clone` panics.
    ///
    /// Se estas panic, la jam klonitaj elementoj falos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SEKURECO: ni ĵus klonis ĉiujn elementojn de len en la rezervan kapaciton
    /// // la unuaj src.len()-elementoj de la vec validas nun.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // male al copy_from_slice ĉi tio ne nomas clone_from_slice sur la tranĉaĵo, ĉar `MaybeUninit<T: Clone>` ne efektivigas Kloni.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SEKURECO: ĉi tiu kruda tranĉaĵo enhavos nur komencitajn objektojn
                // tial ĝi rajtas faligi ĝin.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Ni devas eksplicite tranĉi ilin laŭ la sama longo
        // por limigado de limoj, kaj la optimumigilo generos memppy por simplaj kazoj (ekzemple T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // gardisto bezonas b/c panic povus okazi dum klono
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SEKURECO: Validaj elementoj ĵus estis skribitaj en `this` do ĝi estas komencita
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}