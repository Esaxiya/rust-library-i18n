#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// La versio de [Unicode](http://www.unicode.org/) sur kiu baziĝas la unikodaj partoj de metodoj `char` kaj `str`.
///
/// Novaj versioj de Unikodo estas publikigitaj regule kaj poste ĉiuj metodoj en la norma biblioteko depende de Unikodo estas ĝisdatigitaj.
/// Tial la konduto de iuj `char` kaj `str`-metodoj kaj la valoro de ĉi tiu konstanto ŝanĝiĝas laŭlonge de la tempo.
/// Ĉi tio estas *ne* konsiderata kiel rompiĝanta ŝanĝo.
///
/// La versia numera skemo estas klarigita en [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Por uzo en liballoc, ne reeksportita en libstd.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;