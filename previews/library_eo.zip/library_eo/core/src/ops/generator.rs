use crate::marker::Unpin;
use crate::pin::Pin;

/// La rezulto de rekomencilo de generatoro.
///
/// Ĉi tiu enumo estas redonita de la `Generator::resume`-metodo kaj indikas la eblajn revenvalorojn de generatoro.
/// Nuntempe ĉi tio respondas al aŭ pendopunkto (`Yielded`) aŭ fina punkto (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// La generatoro malakceptita kun valoro.
    ///
    /// Ĉi tiu stato indikas, ke generatoro estis nuligita, kaj kutime respondas al `yield`-aserto.
    /// La valoro donita en ĉi tiu varianto respondas al la esprimo pasita al `yield` kaj permesas al generatoroj doni valoron ĉiufoje, kiam ili donas.
    ///
    ///
    Yielded(Y),

    /// La generatoro kompletigita kun revenvaloro.
    ///
    /// Ĉi tiu stato indikas, ke generatoro finis ekzekuton kun la donita valoro.
    /// Post kiam generatoro redonis `Complete`, ĝi estas konsiderata kiel programera eraro voki `resume` denove.
    ///
    Complete(R),
}

/// La trait efektivigita per enkonstruitaj generatoraj specoj.
///
/// Generatoroj, ankaŭ ofte nomataj korutinoj, estas nuntempe eksperimenta lingva trajto en Rust.
/// Aldonitaj en [RFC 2033]-generatoroj nuntempe celas ĉefe provizi konstruan blokon por async/await-sintakso sed probable etendiĝos al ankaŭ disponigi ergonomian difinon por ripetantoj kaj aliaj primitivuloj.
///
///
/// La sintakso kaj semantiko por generatoroj estas malstabilaj kaj postulos plian RFC por stabiligo.Tamen nuntempe la sintakso similas fermon:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Pli da dokumentado pri generatoroj troveblas en la malstabila libro.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// La speco de valoro donas ĉi tiun generatoron.
    ///
    /// Ĉi tiu rilata tipo respondas al la `yield`-esprimo kaj al la valoroj, kiuj rajtas esti redonitaj ĉiufoje, kiam generatoro cedas.
    ///
    /// Ekzemple ripetilo-kiel-generatoro probable havus ĉi tiun tipon kiel `T`, la tipo ripetata.
    ///
    type Yield;

    /// La speco de valoro, kiun ĉi tiu generatoro redonas.
    ///
    /// Ĉi tio respondas al la tipo redonita de generatoro aŭ kun aserto `return` aŭ implicite kiel la lasta esprimo de laŭvorta generilo.
    /// Ekzemple futures uzus ĉi tion kiel `Result<T, E>` ĉar ĝi reprezentas finitan future.
    ///
    ///
    type Return;

    /// Rekomencas la ekzekuton de ĉi tiu generatoro.
    ///
    /// Ĉi tiu funkcio rekomencos ekzekuti la generatoron aŭ komencos ekzekuti se ĝi ne jam faris.
    /// Ĉi tiu alvoko revenos al la lasta pendopunkto de la generatoro, rekomencante ekzekuton de la plej nova `yield`.
    /// La generatoro daŭre plenumiĝos ĝis ĝi donos aŭ revenos, tiam tiu funkcio revenos.
    ///
    /// # Reveno de valoro
    ///
    /// La `GeneratorState`-enumo redonita de ĉi tiu funkcio indikas, en kiu stato la generatoro revenas.
    /// Se la `Yielded`-varianto estas redonita tiam la generatoro atingis pendopunkton kaj valoro estis donita.
    /// Generatoroj en ĉi tiu stato disponeblas por rekomenci poste.
    ///
    /// Se `Complete` estas redonita, tiam la generatoro tute finiĝis kun la valoro donita.Estas malvalide por la rekomencado de la generatoro.
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio povas panic se ĝi estas vokita post kiam la `Complete`-varianto estis redonita antaŭe.
    /// Dum generatoraj literoj en la lingvo estas garantiitaj al panic rekomencante post `Complete`, ĉi tio ne estas garantiita por ĉiuj efektivigoj de la `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}