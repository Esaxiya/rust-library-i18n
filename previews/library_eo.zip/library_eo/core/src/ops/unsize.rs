use crate::marker::Unsize;

/// Trait kiu indikas ke temas pri montrilo aŭ envolvaĵo por unu, kie malgrandigo povas esti farita sur la punkto.
///
/// Vidu la [DST coercion RFC][dst-coerce] kaj [the nomicon entry on coercion][nomicon-coerce] por pli da detaloj.
///
/// Por tipoj de enmetitaj montriloj, montriloj al `T` devigos al montriloj al `U` se `T: Unsize<U>` per konvertiĝo de maldika montrilo al dika montrilo.
///
/// Por laŭmendaj specoj, la devigo ĉi tie funkcias per devigo de `Foo<T>` al `Foo<U>` kondiĉe ke ekzistas impl. De `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Tia impl povas esti skribita nur se `Foo<T>` havas nur unu ne-fantomodatajn kampojn kun `T`.
/// Se la tipo de tiu kampo estas `Bar<T>`, efektivigo de `CoerceUnsized<Bar<U>> for Bar<T>` devas ekzisti.
/// La devigo funkcios per devigo de la kampo `Bar<T>` en `Bar<U>` kaj plenigado de la resto de la kampoj de `Foo<T>` por krei `Foo<U>`.
/// Ĉi tio efike traboros al montrila kampo kaj devigos tion.
///
/// Ĝenerale por inteligentaj montriloj vi efektivigos `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, kun laŭvola `?Sized` ligita al `T` mem.
/// Por envolvaĵaj specoj, kiuj rekte enigas `T` kiel `Cell<T>` kaj `RefCell<T>`, vi povas rekte efektivigi `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Ĉi tio lasos funkcii devigojn de specoj kiel `Cell<Box<T>>`.
///
/// [`Unsize`][unsize] estas uzata por marki specojn, kiuj povas esti devigitaj al DST-oj se malantaŭ montriloj.Ĝi estas efektivigita aŭtomate de la kompililo.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * konst U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * konst U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Ĉi tio estas uzata por sekureco de objektoj, por kontroli, ke la ricevila tipo de metodo povas esti ekspedita.
///
/// Ekzempla efektivigo de la trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}