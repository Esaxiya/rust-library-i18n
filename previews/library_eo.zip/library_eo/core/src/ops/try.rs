/// trait por agordi la konduton de la `?`-operatoro.
///
/// Tipo efektiviganta `Try` estas tiu, kiu havas kanonan manieron rigardi ĝin laŭ success/failure-dikotomio.
/// Ĉi tiu trait permesas ambaŭ ĉerpi tiujn sukcesajn aŭ malsukcesajn valorojn de ekzistanta petskribo kaj krei novan ekzemplon de sukcesa aŭ malsukcesa valoro.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// La speco de ĉi tiu valoro vidata kiel sukcesa.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// La tipo de ĉi tiu valoro vidata kiel malsukcesa.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Aplikas la "?"-operatoron.Reveno de `Ok(t)` signifas, ke la ekzekuto devas daŭri normale, kaj la rezulto de `?` estas la valoro `t`.
    /// Reveno de `Err(e)` signifas, ke ekzekuto devas branch al la plej interna enfermanta `catch`, aŭ reveni de la funkcio.
    ///
    /// Se `Err(e)`-rezulto estas redonita, la valoro `e` estos "wrapped" en la revena tipo de la enfermanta amplekso (kiu devas mem efektivigi `Try`).
    ///
    /// Specife, la valoro `X::from_error(From::from(e))` estas redonita, kie `X` estas la revena tipo de la enfermanta funkcio.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Envolvu eraran valoron por konstrui la kompozitan rezulton.
    /// Ekzemple, `Result::Err(x)` kaj `Result::from_error(x)` estas ekvivalentaj.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Envolvu bonan valoron por konstrui la kompozitan rezulton.
    /// Ekzemple, `Result::Ok(x)` kaj `Result::from_ok(x)` estas ekvivalentaj.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}