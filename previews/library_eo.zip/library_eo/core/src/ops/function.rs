/// La versio de la telefonisto, kiu prenas neŝanĝeblan ricevilon.
///
/// Okazoj de `Fn` povas esti vokitaj plurfoje sen mutacia stato.
///
/// *Ĉi tiu trait (`Fn`) ne konfuzu kun [function pointers] (`fn`).*
///
/// `Fn` estas efektivigita aŭtomate per fermoj, kiuj nur prenas neŝanĝeblajn referencojn al kaptitaj variabloj aŭ tute nenion kaptas, same kiel (safe) [function pointers] (kun iuj avertoj, vidu ilian dokumentadon por pli da detaloj).
///
/// Aldone, por iu tipo `F`, kiu efektivigas `Fn`, ankaŭ `&F` efektivigas `Fn`.
///
/// Ĉar ambaŭ [`FnMut`] kaj [`FnOnce`] estas supertraktoj de `Fn`, iu ajn kazo de `Fn` povas esti uzata kiel parametro, kie [`FnMut`] aŭ [`FnOnce`] estas atendata.
///
/// Uzu `Fn` kiel binditan kiam vi volas akcepti parametron de funkcio-simila tipo kaj bezonas voki ĝin plurfoje kaj sen mutacia stato (ekz. Kiam vi vokas ĝin samtempe).
/// Se vi ne bezonas tiajn striktajn postulojn, uzu [`FnMut`] aŭ [`FnOnce`] kiel limojn.
///
/// Vidu la [chapter on closures in *The Rust Programming Language*][book] por pliaj informoj pri ĉi tiu temo.
///
/// Rimarkindas ankaŭ la speciala sintakso por `Fn` traits (ekz
/// `Fn(usize, bool) -> uzumi`).Tiuj, kiuj interesiĝas pri la teknikaj detaloj, povas raporti al [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Nomante fermon
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Uzante `Fn`-parametron
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // tiel ke regex povas fidi tiun `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Faras la alvokan operacion.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// La versio de la telefonisto, kiu prenas ŝanĝeblan ricevilon.
///
/// Okazoj de `FnMut` povas esti vokitaj plurfoje kaj povas mutacii staton.
///
/// `FnMut` estas efektivigita aŭtomate per fermoj, kiuj prenas ŝanĝeblajn referencojn al kaptitaj variabloj, kaj ankaŭ ĉiujn specojn, kiuj efektivigas [`Fn`], ekz. (safe) [function pointers] (ĉar `FnMut` estas supertreto de [`Fn`]).
/// Aldone, por iu tipo `F`, kiu efektivigas `FnMut`, ankaŭ `&mut F` efektivigas `FnMut`.
///
/// Ĉar [`FnOnce`] estas supertrait de `FnMut`, iu kazo de `FnMut` povas esti uzata kie [`FnOnce`] estas atendita, kaj ĉar [`Fn`] estas subtrait de `FnMut`, iu ajn kazo de [`Fn`] povas esti uzata kie `FnMut` estas atendita.
///
/// Uzu `FnMut` kiel binditan kiam vi volas akcepti parametron de funkcio-simila tipo kaj bezonas voki ĝin plurfoje, permesante al ĝi mutacii staton.
/// Se vi ne volas, ke la parametro mutas staton, uzu [`Fn`] kiel binditan;se vi ne bezonas telefoni ĝin plurfoje, uzu [`FnOnce`].
///
/// Vidu la [chapter on closures in *The Rust Programming Language*][book] por pliaj informoj pri ĉi tiu temo.
///
/// Rimarkindas ankaŭ la speciala sintakso por `Fn` traits (ekz
/// `Fn(usize, bool) -> uzumi`).Tiuj, kiuj interesiĝas pri la teknikaj detaloj, povas raporti al [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Nomante mutige kaptan fermon
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Uzante `FnMut`-parametron
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // tiel ke regex povas fidi tiun `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Faras la alvokan operacion.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// La versio de la telefonisto, kiu ricevas kromvaloran ricevilon.
///
/// Instancoj de `FnOnce` povas esti vokitaj, sed eble ne estas alvokeblaj plurfoje.Pro tio, se la sola afero konata pri tipo estas, ke ĝi efektivigas `FnOnce`, ĝi povas esti vokita nur unufoje.
///
/// `FnOnce` estas efektivigita aŭtomate per fermoj, kiuj eble konsumas kaptitajn variablojn, kaj ankaŭ ĉiujn specojn, kiuj efektivigas [`FnMut`], ekz. (safe) [function pointers] (ĉar `FnOnce` estas supertreto de [`FnMut`]).
///
///
/// Ĉar ambaŭ [`Fn`] kaj [`FnMut`] estas subtrajtoj de `FnOnce`, ajna kazo de [`Fn`] aŭ [`FnMut`] povas esti uzata kie `FnOnce` estas atendata.
///
/// Uzu `FnOnce` kiel binditan kiam vi volas akcepti parametron de funkcio-simila tipo kaj nur bezonas nomi ĝin unufoje.
/// Se vi bezonas voki la parametron plurfoje, uzu [`FnMut`] kiel binditan;se vi ankaŭ bezonas ĝin por ne mutacii staton, uzu [`Fn`].
///
/// Vidu la [chapter on closures in *The Rust Programming Language*][book] por pliaj informoj pri ĉi tiu temo.
///
/// Rimarkindas ankaŭ la speciala sintakso por `Fn` traits (ekz
/// `Fn(usize, bool) -> uzumi`).Tiuj, kiuj interesiĝas pri la teknikaj detaloj, povas raporti al [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Uzante `FnOnce`-parametron
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` konsumas siajn kaptitajn variablojn, do ĝi ne povas esti rulata pli ol unufoje.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Provi alvoki `func()` denove ĵetos `use of moved value`-eraron por `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ne plu povas esti alvokita ĉe ĉi tiu punkto
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // tiel ke regex povas fidi tiun `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// La redonita tipo post la alvokfunkciigisto estas uzata.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Faras la alvokan operacion.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}