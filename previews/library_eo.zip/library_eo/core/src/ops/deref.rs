/// Uzata por neŝanĝeblaj dereferencaj operacioj, kiel `*v`.
///
/// Krom uzado por eksplicitaj dereferencaj operacioj kun la operatoro (unary) `*` en neŝanĝeblaj kuntekstoj, `Deref` ankaŭ estas uzita implicite de la kompililo en multaj cirkonstancoj.
/// Ĉi tiu mekanismo nomiĝas ['`Deref` coercion'][more].
/// En ŝanĝeblaj kuntekstoj, [`DerefMut`] estas uzata.
///
/// Efektivigi `Deref` por inteligentaj montriloj faciligas aliri la datumojn malantaŭ ili, tial ili efektivigas `Deref`.
/// Aliflanke, la reguloj pri `Deref` kaj [`DerefMut`] estis desegnitaj specife por akcepti inteligentajn montrilojn.
/// Pro tio,**"Deref" devas esti efektivigita nur por inteligentaj montriloj** por eviti konfuzon.
///
/// Pro similaj kialoj,**ĉi tiu trait neniam devas malsukcesi**.Malsukceso dum dereferencado povas esti tre konfuza kiam `Deref` estas alvokita implicite.
///
/// # Pli pri `Deref`-devigo
///
/// Se `T` efektivigas `Deref<Target = U>`, kaj `x` estas valoro de tipo `T`, tiam:
///
/// * En neŝanĝeblaj kuntekstoj, `*x` (kie `T` estas nek referenco nek kruda montrilo) estas ekvivalenta al `* Deref::deref(&x)`.
/// * Valoroj de tipo `&T` estas devigitaj al valoroj de tipo `&U`
/// * `T` implicite efektivigas ĉiujn (immutable)-metodojn de la tipo `U`.
///
/// Por pli da detaloj, vizitu [the chapter in *The Rust Programming Language*][book] same kiel la referencajn sekciojn pri [the dereference operator][ref-deref-op], [method resolution] kaj [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struct kun ununura kampo alirebla per malreferencado de la struct.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// La rezulta tipo post malreferencado.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Diferencigas la valoron.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Uzata por ŝanĝeblaj dereferencaj operacioj, kiel en `*v = 1;`.
///
/// Krom esti uzata por eksplicitaj dereferencaj operacioj kun la operatoro (unary) `*` en ŝanĝeblaj kuntekstoj, `DerefMut` ankaŭ estas uzita implicite de la kompililo en multaj cirkonstancoj.
/// Ĉi tiu mekanismo nomiĝas ['`Deref` coercion'][more].
/// En neŝanĝeblaj kuntekstoj, [`Deref`] estas uzata.
///
/// Efektivigi `DerefMut` por inteligentaj montriloj faciligas mutacii la datumojn malantaŭ ili, tial ili efektivigas `DerefMut`.
/// Aliflanke, la reguloj pri [`Deref`] kaj `DerefMut` estis desegnitaj specife por akcepti inteligentajn montrilojn.
/// Pro tio,**"DerefMut" devas esti efektivigita nur por inteligentaj montriloj** por eviti konfuzon.
///
/// Pro similaj kialoj,**ĉi tiu trait neniam devas malsukcesi**.Malsukceso dum dereferencado povas esti tre konfuza kiam `DerefMut` estas alvokita implicite.
///
/// # Pli pri `Deref`-devigo
///
/// Se `T` efektivigas `DerefMut<Target = U>`, kaj `x` estas valoro de tipo `T`, tiam:
///
/// * En ŝanĝeblaj kuntekstoj, `*x` (kie `T` estas nek referenco nek kruda montrilo) estas ekvivalenta al `* DerefMut::deref_mut(&mut x)`.
/// * Valoroj de tipo `&mut T` estas devigitaj al valoroj de tipo `&mut U`
/// * `T` implicite efektivigas ĉiujn (mutable)-metodojn de la tipo `U`.
///
/// Por pli da detaloj, vizitu [the chapter in *The Rust Programming Language*][book] same kiel la referencajn sekciojn pri [the dereference operator][ref-deref-op], [method resolution] kaj [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struct kun ununura kampo modifebla per dereferencado de la struct.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Reciproke malreferencas la valoron.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Indikas, ke strukt povas esti uzata kiel metodo-ricevilo, sen la `arbitrary_self_types`-funkcio.
///
/// Ĉi tio estas efektivigita per stdlib-montriloj kiel `Box<T>`, `Rc<T>`, `&T` kaj `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}