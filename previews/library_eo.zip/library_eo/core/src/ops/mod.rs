//! Troŝarĝeblaj operatoroj.
//!
//! Efektivigi ĉi tiujn traits permesas al vi troŝarĝi iujn telefonistojn.
//!
//! Iuj el ĉi tiuj traits estas importitaj de prelude, do ili haveblas en ĉiu programo Rust.Nur telefonistoj subtenataj de traits povas esti troŝarĝitaj.
//! Ekzemple, la aldona operatoro (`+`) povas esti troŝarĝita per la [`Add`] trait, sed ĉar la asigna operatoro (`=`) havas neniun subtenan trait, ne ekzistas maniero troŝarĝi sian semantikon.
//! Aldone, ĉi tiu modulo ne provizas iun ajn mekanismon krei novajn telefonistojn.
//! Se necesas senkaraktera troŝarĝo aŭ kutimaj funkciigistoj, vi devas rigardi al makrooj aŭ kompililaj aldonaĵoj por etendi la sintakson de Rust.
//!
//! Efektivigoj de operatoro traits devas esti surprizaj en siaj respektivaj kuntekstoj, konsiderante siajn kutimajn signifojn kaj [operator precedence].
//! Ekzemple, dum efektivigado de [`Mul`], la operacio devas havi iom da simileco al multipliko (kaj dividi atendatajn ecojn kiel asocieco).
//!
//! Notu, ke la `&&` kaj `||`-operatoroj fuŝkontaktigas, do ili taksas sian duan operandon nur se ĝi kontribuas al la rezulto.Ĉar ĉi tiu konduto ne estas plenumebla de traits, `&&` kaj `||` ne estas subtenataj kiel troŝarĝeblaj operatoroj.
//!
//! Multaj el la telefonistoj taksas siajn operaciantojn laŭ valoro.En ne-senmarkaj kuntekstoj kun enkonstruitaj tipoj, ĉi tio kutime ne estas problemo.
//! Tamen uzi ĉi tiujn telefonistojn en ĝenerala kodo postulas iom da atento se valoroj devas esti reuzataj kontraste al lasi la telefonistojn konsumi ilin.Unu eblo estas foje uzi [`clone`].
//! Alia eblo estas dependi de la koncernaj tipoj, kiuj provizas aldonajn efektivigilojn por referencoj.
//! Ekzemple, por uzanto-difinita tipo `T`, kiu supozeble subtenas aldonon, verŝajne estas bona ideo havi kaj `T` kaj `&T` efektivigi la traits [`Add<T>`][`Add`] kaj [`Add<&T>`][`Add`] tiel ke ĝenerala kodo povas esti skribita sen nenecesa klonado.
//!
//!
//! # Examples
//!
//! Ĉi tiu ekzemplo kreas `Point`-strukturon, kiu efektivigas [`Add`] kaj [`Sub`], kaj tiam montras aldoni kaj subtrahi du `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Vidu la dokumentaron por ĉiu trait por ekzempla efektivigo.
//!
//! La [`Fn`], [`FnMut`] kaj [`FnOnce`] traits estas efektivigitaj per specoj, kiujn oni povas alvoki kiel funkcioj.Notu, ke [`Fn`] prenas `&self`, [`FnMut`] prenas `&mut self` kaj [`FnOnce`] prenas `self`.
//! Ĉi tiuj respondas al la tri specoj de metodoj, kiujn oni povas alvoki en kazo: alvoko laŭ referenco, alvoko laŭ ŝanĝebla referenco kaj alvoko laŭ valoro.
//! La plej ofta uzo de ĉi tiuj traits estas agi kiel limoj al pli altnivelaj funkcioj, kiuj prenas funkciojn aŭ fermojn kiel argumentojn.
//!
//! Prenante [`Fn`] kiel parametron:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Prenante [`FnMut`] kiel parametron:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Prenante [`FnOnce`] kiel parametron:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` konsumas siajn kaptitajn variablojn, do ĝi ne povas esti rulata pli ol unufoje
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Provi alvoki `func()` denove ĵetos `use of moved value`-eraron por `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ne plu povas esti alvokita ĉe ĉi tiu punkto
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;