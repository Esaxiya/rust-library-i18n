/// Propra kodo ene de la detruilo.
///
/// Kiam valoro ne plu necesas, Rust funkciigos "destructor" per tiu valoro.
/// La plej ofta maniero, ke valoro ne plu bezonas, estas kiam ĝi eliras el amplekso.Detruigiloj eble ankoraŭ funkcias en aliaj cirkonstancoj, sed ni celos amplekson por la ekzemploj ĉi tie.
/// Por lerni pri iuj el tiuj aliaj kazoj, bonvolu vidi [the reference]-sekcion pri detruantoj.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Ĉi tiu detruilo konsistas el du eroj:
/// - Voko al `Drop::drop` por tiu valoro, se ĉi tiu speciala `Drop` trait estas efektivigita por sia tipo.
/// - La aŭtomate generita "drop glue", kiu rekursive nomas la detruantojn de ĉiuj kampoj de ĉi tiu valoro.
///
/// Ĉar Rust aŭtomate nomas la detruantojn de ĉiuj enhavitaj kampoj, vi ne bezonas efektivigi `Drop` plejofte.
/// Sed estas iuj kazoj, kiam ĝi utilas, ekzemple por tipoj, kiuj rekte administras rimedon.
/// Tiu rimedo eble estas memoro, ĝi povas esti dosierpriskribilo, ĝi povas esti reta ingo.
/// Post kiam tia valoro ne plu estos uzata, ĝi devas "clean up" sian rimedon liberigante la memoron aŭ fermante la dosieron aŭ ingon.
/// Ĉi tio estas la laboro de detruanto, kaj do la laboro de `Drop::drop`.
///
/// ## Examples
///
/// Por vidi detruantojn en agado, ni rigardu la sekvan programon:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust unue vokos `Drop::drop` por `_x` kaj poste por ambaŭ `_x.one` kaj `_x.two`, kio signifas, ke kurante ĉi tion presos
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Eĉ se ni forigos la efektivigon de `Drop` por `HasTwoDrop`, la detruantoj de ĝiaj kampoj ankoraŭ nomiĝas.
/// Ĉi tio rezultus
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Vi mem ne povas telefoni al `Drop::drop`
///
/// Ĉar `Drop::drop` estas uzata por purigi valoron, eble estos danĝere uzi ĉi tiun valoron post kiam la metodo estis vokita.
/// Ĉar `Drop::drop` ne posedas sian enigon, Rust malebligas misuzon ne permesante al vi telefoni rekte al `Drop::drop`.
///
/// Alivorte, se vi provus eksplicite voki `Drop::drop` en la supra ekzemplo, vi ricevus kompililon.
///
/// Se vi ŝatus eksplicite nomi la detruanton de valoro, anstataŭe oni povas uzi [`mem::drop`].
///
/// [`mem::drop`]: drop
///
/// ## Faligi mendon
///
/// Kiu el niaj du `HasDrop` falas unue, tamen?Por strukturoj, estas la sama ordo, ke ili estas deklaritaj: unue `one`, poste `two`.
/// Se vi ŝatus provi ĉi tion mem, vi povas modifi `HasDrop` supre por enhavi iujn datumojn, kiel entjero, kaj poste uzi ĝin en la `println!` ene de `Drop`.
/// Ĉi tiu konduto estas garantiita de la lingvo.
///
/// Male al por strukturoj, lokaj variabloj estas faligitaj en inversa sinsekvo:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Ĉi tio presos
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Bonvolu vidi [the reference] por la plenaj reguloj.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` kaj `Drop` estas ekskluzivaj
///
/// Vi ne povas efektivigi ambaŭ [`Copy`] kaj `Drop` sur la sama tipo.Tipoj, kiuj estas `Copy`, estas implicite duplikatitaj de la kompililo, tial tre malfacile antaŭdiras kiam kaj kiom ofte detruiloj estos ekzekutitaj.
///
/// Kiel tiaj, ĉi tiuj tipoj ne povas havi detruantojn.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Ekzekutas la detruanton por ĉi tiu tipo.
    ///
    /// Ĉi tiu metodo estas nomata implicite kiam la valoro eliras el amplekso, kaj ne povas esti nomata eksplicite (ĉi tio estas kompilila eraro [E0040]).
    /// Tamen la funkcio [`mem::drop`] en la prelude povas esti uzata por nomi la efektivigon de la argumento `Drop`.
    ///
    /// Kiam ĉi tiu metodo estis vokita, `self` ankoraŭ ne estis repartoprenita.
    /// Tio okazas nur post la fino de la metodo.
    /// Se ĉi tio ne estus la kazo, `self` estus pendanta referenco.
    ///
    /// # Panics
    ///
    /// Konsiderante, ke [`panic!`] vokos `drop` dum ĝi malvolviĝos, ĉiu [`panic!`] en efektivigo de `drop` probable ĉesos.
    ///
    /// Notu, ke eĉ se ĉi tiu panics, la valoro estas konsiderata kiel malplenigita;
    /// vi ne devas kaŭzi, ke `drop` estu vokita denove.
    /// Ĉi tion kutime aŭtomate pritraktas la kompililo, sed uzante nesekuran kodon, povas okazi senintence, precipe uzante [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}