//! Ĉi tio estas interna modulo uzata de la ifmt!rultempo.Ĉi tiuj strukturoj estas elsenditaj al statikaj tabeloj por antaŭkompili formatajn ĉenojn antaŭ tempo.
//!
//! Ĉi tiuj difinoj similas al siaj ekvivalentoj `ct`, sed diferencas per tio, ke ĉi tiuj povas esti statike atribuitaj kaj iomete optimumigitaj por la rultempo
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Eblaj vicigoj, kiujn oni povas peti kadre de formata direktivo.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indiko, ke enhavoj estu maldekstre vicigitaj.
    Left,
    /// Indiko, ke enhavoj estu dekstre vicigitaj.
    Right,
    /// Indiko, ke enhavoj devas esti meze vicigitaj.
    Center,
    /// Neniu vicigo estis petita.
    Unknown,
}

/// Uzata de [width](https://doc.rust-lang.org/std/fmt/#width) kaj [precision](https://doc.rust-lang.org/std/fmt/#precision)-specifiloj.
#[derive(Copy, Clone)]
pub enum Count {
    /// Specifita per laŭvorta nombro, stokas la valoron
    Is(usize),
    /// Specifita per sintaksoj `$` kaj `*`, stokas la indekson en `args`
    Param(usize),
    /// Ne specifita
    Implied,
}