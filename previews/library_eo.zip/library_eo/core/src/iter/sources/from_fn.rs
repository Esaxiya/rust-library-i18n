use crate::fmt;

/// Kreas novan ripeton, kie ĉiu ripeto nomas la provizitan fermon `F: FnMut() -> Option<T>`.
///
/// Ĉi tio permesas krei laŭmendan ripetilon kun iu ajn konduto sen uzi la pli detaleman sintakson krei specialan tipon kaj efektivigi la [`Iterator`] trait por ĝi.
///
/// Notu, ke la `FromFn`-ripetilo ne supozas pri la konduto de la fermo, kaj tial konservative ne efektivigas [`FusedIterator`], aŭ anstataŭigas [`Iterator::size_hint()`] de sia defaŭlta `(0, None)`.
///
///
/// La fermo povas uzi kaptojn kaj ĝian medion por spuri staton tra ripetoj.Depende de kiel la ripeto estas uzata, ĉi tio eble postulos specifi la ŝlosilvorton [`move`] ĉe la fermo.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Ni re-efektivigu la sumigilon de [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Pliigu nian kalkulon.Jen kial ni komencis je nulo.
///     count += 1;
///
///     // Kontrolu ĉu ni finis kalkuli aŭ ne.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Ripetanto, kie ĉiu ripeto nomas la provizitan fermon `F: FnMut() -> Option<T>`.
///
/// Ĉi tiu `struct` estas kreita per la funkcio [`iter::from_fn()`].
/// Vidu ĝian dokumentadon por pli.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}