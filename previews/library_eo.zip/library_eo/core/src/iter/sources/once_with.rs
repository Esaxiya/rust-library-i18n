use crate::iter::{FusedIterator, TrustedLen};

/// Kreas ripeton, kiu pigre generas valoron ekzakte unufoje alvokante la provizitan fermon.
///
/// Ĉi tio estas kutime uzata por adapti unu valoran generatoron al [`chain()`] de aliaj specoj de ripeto.
/// Eble vi havas ripeton, kiu kovras preskaŭ ĉion, sed vi bezonas ekstran specialan kazon.
/// Eble vi havas funkcion, kiu funkcias sur ripetiloj, sed vi bezonas nur prilabori unu valoron.
///
/// Male al [`once()`], ĉi tiu funkcio pigre generos la valoron laŭ peto.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// use std::iter;
///
/// // unu estas la plej soleca nombro
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // nur unu, jen ĉio, kion ni ricevas
/// assert_eq!(None, one.next());
/// ```
///
/// Katenante kune kun alia ripetilo.
/// Ni diru, ke ni volas ripeti ĉiun dosieron de la `.foo`-dosierujo, sed ankaŭ agordan dosieron,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ni bezonas konverti de ripeto de DirEntry-s al ripeto de PathBufs, do ni uzas mapon
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nun nia ripeto nur por nia agorda dosiero
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // katenu la du ripetilojn kune en unu grandan ripetilon
/// let files = dirs.chain(config);
///
/// // ĉi tio donos al ni ĉiujn dosierojn en .foo kaj .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Ripetanto, kiu donas unu elementon de tipo `A` per apliko de la provizita fermo `F: FnOnce() -> A`.
///
///
/// Ĉi tiu `struct` estas kreita per la funkcio [`once_with()`].
/// Vidu ĝian dokumentadon por pli.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}