use crate::iter::{FusedIterator, TrustedLen};

/// Kreas ripeton, kiu donas elementon ekzakte unufoje.
///
/// Ĉi tio estas ofte uzata por adapti ununuran valoron al [`chain()`] de aliaj specoj de ripeto.
/// Eble vi havas ripeton, kiu kovras preskaŭ ĉion, sed vi bezonas ekstran specialan kazon.
/// Eble vi havas funkcion, kiu funkcias sur ripetiloj, sed vi bezonas nur prilabori unu valoron.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// use std::iter;
///
/// // unu estas la plej soleca nombro
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // nur unu, jen ĉio, kion ni ricevas
/// assert_eq!(None, one.next());
/// ```
///
/// Katenante kune kun alia ripetilo.
/// Ni diru, ke ni volas ripeti ĉiun dosieron de la `.foo`-dosierujo, sed ankaŭ agordan dosieron,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ni bezonas konverti de ripeto de DirEntry-s al ripeto de PathBufs, do ni uzas mapon
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nun nia ripeto nur por nia agorda dosiero
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // katenu la du ripetilojn kune en unu grandan ripetilon
/// let files = dirs.chain(config);
///
/// // ĉi tio donos al ni ĉiujn dosierojn en .foo kaj .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Ripetanto, kiu donas elementon ekzakte unufoje.
///
/// Ĉi tiu `struct` estas kreita per la funkcio [`once()`].Vidu ĝian dokumentadon por pli.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}