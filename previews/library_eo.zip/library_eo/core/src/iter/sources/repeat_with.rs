use crate::iter::{FusedIterator, TrustedLen};

/// Kreas novan ripetilon, kiu ripetas elementojn de tipo `A` senfine per apliko de la provizita fermo, la ripetilo, `F: FnMut() -> A`.
///
/// La funkcio `repeat_with()` vokas la ripetilon ree.
///
/// Senfinaj ripetiloj kiel `repeat_with()` estas ofte uzataj kun adaptiloj kiel [`Iterator::take()`], por fari ilin finiaj.
///
/// Se la elementa speco de la ripetilo vi bezonas efektivigas [`Clone`], kaj estas bone konservi la fontan elementon en memoro, vi anstataŭe uzu la funkcion [`repeat()`].
///
///
/// Ripetanto produktita de `repeat_with()` ne estas [`DoubleEndedIterator`].
/// Se vi bezonas `repeat_with()` por redoni [`DoubleEndedIterator`], bonvolu malfermi GitHub-numeron klarigante vian uzokazon.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// use std::iter;
///
/// // ni supozu, ke ni havas ian valoron de tipo, kiu ne estas `Clone` aŭ kiuj ankoraŭ ne volas havi memoron ĉar ĝi estas multekosta:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // aparta valoro por ĉiam:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Uzante mutacion kaj irante finia:
///
/// ```rust
/// use std::iter;
///
/// // De la nul al la tria potenco de du:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... kaj nun ni finis
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Ripetanto, kiu ripetas elementojn de tipo `A` senfine per apliko de la provizita fermo `F: FnMut() -> A`.
///
///
/// Ĉi tiu `struct` estas kreita per la funkcio [`repeat_with()`].
/// Vidu ĝian dokumentadon por pli.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}