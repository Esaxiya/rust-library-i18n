use crate::iter::{FusedIterator, TrustedLen};

/// Kreas novan ripetilon, kiu senfine ripetas unu elementon.
///
/// La funkcio `repeat()` ripetas ununuran valoron ree.
///
/// Senfinaj ripetiloj kiel `repeat()` estas ofte uzataj kun adaptiloj kiel [`Iterator::take()`], por fari ilin finiaj.
///
/// Se la elementa speco de la iterilo, kiun vi bezonas, ne efektivigas `Clone`, aŭ se vi ne volas konservi la ripetitan elementon en memoro, vi povas anstataŭe uzi la funkcion [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// use std::iter;
///
/// // la numero kvar 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // jes, ankoraŭ kvar
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Finiĝi finite kun [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // tiu lasta ekzemplo estis tro multaj kvar.Ni havu nur kvar kvarojn.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... kaj nun ni finis
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Ripetanto, kiu ripetas elementon senfine.
///
/// Ĉi tiu `struct` estas kreita per la funkcio [`repeat()`].Vidu ĝian dokumentadon por pli.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}