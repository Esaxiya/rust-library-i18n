// ignore-tidy-filelength Ĉi tiu dosiero preskaŭ nur konsistas el la difino de `Iterator`.
// Ni ne povas dividi tion en plurajn dosierojn.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Interfaco por trakti ripetantojn.
///
/// Ĉi tiu estas la ĉefa ripeto trait.
/// Por pli pri la koncepto de ripetiloj ĝenerale, bonvolu vidi la [module-level documentation].
/// Precipe vi eble volas scii kiel [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// La speco de la ripetataj elementoj.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Antaŭeniras la ripetilon kaj redonas la sekvan valoron.
    ///
    /// Liveras [`None`] kiam ripeto finiĝas.
    /// Individuaj ripetaj efektivigoj povas elekti rekomenci ripeton, kaj tiel voki `next()` denove eble eble eventuale komencos redoni [`Some(Item)`] iam.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Voko al next() redonas la sekvan valoron ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... kaj poste Neniu post kiam ĝi finiĝis.
    /// assert_eq!(None, iter.next());
    ///
    /// // Pli da alvokoj eble aŭ ne redonos `None`.Ĉi tie, ili ĉiam faros.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Liveras la limojn sur la cetera longo de la ripetilo.
    ///
    /// Specife, `size_hint()` redonas opon, kie la unua elemento estas la malsupra rando, kaj la dua elemento estas la supra rando.
    ///
    /// La dua duono de la resendita opo estas [`Opcio`]`<`[`uzigi`] `>`.
    /// [`None`] ĉi tie signifas, ke aŭ ne estas konata supra rando, aŭ la supra rando estas pli granda ol [`usize`].
    ///
    /// # Efektivigaj notoj
    ///
    /// Ne estas devigite, ke itera efektivigo donas la deklaritan nombron da elementoj.Kaleza ripeto povas doni malpli ol la malsupran limon aŭ pli ol la supra rando de elementoj.
    ///
    /// `size_hint()` ĉefe celas esti uzata por optimumigoj kiel rezervado de spaco por la elementoj de la ripetilo, sed ne fidindas ekz. preterlasi kontrolojn de limoj en nesekura kodo.
    /// Malĝusta efektivigo de `size_hint()` ne devas konduki al malobservoj de memoro-sekureco.
    ///
    /// Dirite, la efektivigo devas doni ĝustan takson, ĉar alie ĝi estus malobservo de la protokolo de trait.
    ///
    /// La apriora efektivigo redonas `(0,` ['Neniu`]`)` kio estas ĝusta por iu ajn ripetilo.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Pli kompleksa ekzemplo:
    ///
    /// ```
    /// // La para nombroj de nulo ĝis dek.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Ni povus ripeti de nulo ĝis dek fojojn.
    /// // Scii, ke ĝuste estas kvin, ne eblus sen ekzekuti filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Ni aldonu kvin pliajn nombrojn per chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // nun ambaŭ limoj estas pliigitaj per kvin
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Revenante `None` por supra rando:
    ///
    /// ```
    /// // senfina ripetilo havas neniun supran limon kaj la maksimuman eblan malsupran limon
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Konsumas la ripeton, kalkulante la nombron de ripetoj kaj redonante ĝin.
    ///
    /// Ĉi tiu metodo alvokos [`next`] plurfoje ĝis [`None`] estos renkontita, redonante la fojon, kiam ĝi vidis [`Some`].
    /// Notu, ke [`next`] devas esti vokita almenaŭ unufoje eĉ se la ripetilo ne havas iujn elementojn.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Superflua Konduto
    ///
    /// La metodo ne protektas sin kontraŭ superfluoj, do kalkuli elementojn de ripetilo kun pli ol [`usize::MAX`]-elementoj aŭ produktas malĝustan rezulton aŭ panics.
    ///
    /// Se elpurigaj asertoj estas ebligitaj, panic estas garantiita.
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio povus panic se la ripetilo havas pli ol [`usize::MAX`]-elementojn.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Konsumas la ripetilon, redonante la lastan elementon.
    ///
    /// Ĉi tiu metodo taksos la ripetilon ĝis ĝi redonos [`None`].
    /// Tiel farante, ĝi konservas spuron de la nuna elemento.
    /// Post kiam [`None`] estas redonita, `last()` tiam redonos la lastan elementon, kiun ĝi vidis.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Antaŭenigas la ripetilon per `n`-elementoj.
    ///
    /// Ĉi tiu metodo fervore transsaltos `n`-elementojn vokante [`next`] ĝis `n`-fojoj ĝis [`None`] estos renkontita.
    ///
    /// `advance_by(n)` redonos [`Ok(())`][Ok] se la ripetilo sukcese progresas per `n`-elementoj, aŭ [`Err(k)`][Err] se [`None`] troviĝas, kie `k` estas la nombro da elementoj antaŭitaj de la iteratoro antaŭ ol elĉerpi elementojn (t.e.
    /// la longo de la ripetilo).
    /// Notu, ke `k` ĉiam malpli ol `n`.
    ///
    /// Voki `advance_by(0)` ne konsumas elementojn kaj ĉiam redonas [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // nur `&4` estis transsaltita
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Liveras la `n`-eron de la ripetilo.
    ///
    /// Kiel plej multaj indeksaj operacioj, la kalkulo komenciĝas de nulo, do `nth(0)` redonas la unuan valoron, `nth(1)` la duan, ktp.
    ///
    /// Notu, ke ĉiuj antaŭaj elementoj, same kiel la redonita elemento, estos konsumitaj de la ripetilo.
    /// Tio signifas, ke la antaŭaj elementoj estos forĵetitaj, kaj ankaŭ ke voki `nth(0)` plurfoje per la sama ripetilo redonos malsamajn elementojn.
    ///
    ///
    /// `nth()` redonos [`None`] se `n` estas pli granda aŭ egala al la longo de la ripetilo.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Voki `nth()` plurfoje ne rebobenas la ripetilon:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Revenante `None` se estas malpli ol `n + 1`-elementoj:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Kreas ripeton ekde la sama punkto, sed paŝante laŭ la donita kvanto ĉe ĉiu ripeto.
    ///
    /// Noto 1: La unua elemento de la ripetilo ĉiam estos redonita, sendepende de la paŝo donita.
    ///
    /// Noto 2: La tempo, kiam oni ignoras ignoritajn elementojn, ne estas fiksita.
    /// `StepBy` kondutas kiel la sinsekvo `next(), nth(step-1), nth(step-1),…`, sed ankaŭ rajtas konduti kiel la sinsekvo
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Kiu maniero estas uzata povas ŝanĝiĝi por iuj ripetantoj pro agadkialoj.
    /// La dua maniero antaŭenigos la ripetilon pli frue kaj eble konsumos pli da eroj.
    ///
    /// `advance_n_and_return_first` estas la ekvivalento de:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// La metodo estos panic se la donita paŝo estas `0`.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Prenas du ripetilojn kaj kreas novan ripetilon super ambaŭ laŭvice.
    ///
    /// `chain()` redonos novan ripetilon, kiu unue ripetos valorojn de la unua ripetilo kaj poste super valoroj de la dua ripetilo.
    ///
    /// Alivorte, ĝi ligas du ripetilojn kune, en ĉeno.🔗
    ///
    /// [`once`] estas ofte uzata por adapti unu valoron al ĉeno de aliaj specoj de ripeto.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ĉar la argumento al `chain()` uzas [`IntoIterator`], ni povas transdoni ĉion, kio povas esti konvertita en [`Iterator`], ne nur [`Iterator`] mem.
    /// Ekzemple, tranĉaĵoj (`&[T]`) efektivigas [`IntoIterator`], kaj do povas esti transdonita al `chain()` rekte:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Se vi laboras kun Windows-API, vi eble volas konverti [`OsStr`] al `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Ripetas' du ripetilojn en unu ripetilon de paroj.
    ///
    /// `zip()` redonas novan ripetilon, kiu ripetos super du aliaj ripetiloj, redonante opon, kie la unua elemento devenas de la unua ripetilo, kaj la dua elemento venas de la dua ripetilo.
    ///
    ///
    /// Alivorte, ĝi zipas du ripetilojn kune, en unu sola.
    ///
    /// Se iu ajn ripetilo redonas [`None`], [`next`] de la zipita ripetilo redonos [`None`].
    /// Se la unua ripetilo redonas [`None`], `zip` fuŝkontaktigos kaj `next` ne estos alvokita al la dua ripetilo.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ĉar la argumento al `zip()` uzas [`IntoIterator`], ni povas transdoni ĉion, kio povas esti konvertita en [`Iterator`], ne nur [`Iterator`] mem.
    /// Ekzemple, tranĉaĵoj (`&[T]`) efektivigas [`IntoIterator`], kaj do povas esti transdonita al `zip()` rekte:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` estas ofte uzata por konverti senfinan ripetilon al finia.
    /// Ĉi tio funkcias ĉar la finia ripetilo eventuale redonos [`None`], finante la zipon.Zipado per `(0..)` povas aspekti multe kiel [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Kreas novan ripeton, kiu metas kopion de `separator` inter apudaj eroj de la originala ripeto.
    ///
    /// Se `separator` ne efektivigas [`Clone`] aŭ bezonas komputadon ĉiufoje, uzu [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // La unua elemento de `a`.
    /// assert_eq!(a.next(), Some(&100)); // La apartigilo.
    /// assert_eq!(a.next(), Some(&1));   // La sekva elemento de `a`.
    /// assert_eq!(a.next(), Some(&100)); // La apartigilo.
    /// assert_eq!(a.next(), Some(&2));   // La lasta elemento de `a`.
    /// assert_eq!(a.next(), None);       // La ripeto finiĝis.
    /// ```
    ///
    /// `intersperse` povas esti tre utila por kunigi erojn de ripeto uzante komunan elementon:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Kreas novan ripetilon, kiu metas eron generitan de `separator` inter apudaj eroj de la originala ripetilo.
    ///
    /// La fermo nomiĝos ĝuste unufoje ĉiufoje kiam ero estas metita inter du apudaj eroj de la suba ripeto;
    /// specife, la fermo ne nomiĝas se la suba ripeto donas malpli ol du erojn kaj post la lasta ero estas donita.
    ///
    ///
    /// Se la ero de la ripeto efektivigas [`Clone`], eble estos pli facile uzi [`intersperse`].
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // La unua elemento de `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // La apartigilo.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // La sekva elemento de `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // La apartigilo.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // La lasta elemento de de `v`.
    /// assert_eq!(it.next(), None);               // La ripeto finiĝis.
    /// ```
    ///
    /// `intersperse_with` uzeblas en situacioj, kie la apartigilo devas esti komputita:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // La fermo mutule pruntas sian kuntekston por generi eron.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Prenas fermon kaj kreas ripetilon, kiu nomas tiun fermon sur ĉiu elemento.
    ///
    /// `map()` transformas unu ripetilon en alian, per ĝia argumento:
    /// io, kiu efektivigas [`FnMut`].Ĝi produktas novan ripetilon, kiu nomas ĉi tiun fermon sur ĉiu elemento de la originala ripetilo.
    ///
    /// Se vi lerte pensas pri specoj, vi povas pensi pri `map()` tiel:
    /// Se vi havas ripeton, kiu donas al vi elementojn de ia tipo `A`, kaj vi volas ripeton de iu alia tipo `B`, vi povas uzi `map()`, preterpasante fermon, kiu prenas `A` kaj redonas `B`.
    ///
    ///
    /// `map()` estas koncipe simila al [`for`]-buklo.Tamen, ĉar `map()` estas pigra, ĝi plej bone estas uzata kiam vi jam laboras kun aliaj ripetiloj.
    /// Se vi faras ia lopadon por kromefiko, ĝi estas pli idioma uzi [`for`] ol `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Se vi faras ian kromefikon, preferu [`for`] al `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ne faru ĉi tion:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ĝi eĉ ne funkcios, ĉar ĝi estas pigra.Rust avertos vin pri ĉi tio.
    ///
    /// // Anstataŭe uzu por:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Nomas fermon al ĉiu elemento de ripetilo.
    ///
    /// Ĉi tio ekvivalentas al uzado de [`for`]-buklo sur la ripetilo, kvankam `break` kaj `continue` ne eblas de fermo.
    /// Ĝenerale estas pli idiote uzi `for`-buklon, sed `for_each` eble estas pli legebla dum prilaborado de eroj ĉe la fino de pli longaj ripetaj ĉenoj.
    ///
    /// En iuj kazoj `for_each` ankaŭ povas esti pli rapida ol buklo, ĉar ĝi uzos internan ripeton sur adaptiloj kiel `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Por tia malgranda ekzemplo, `for`-buklo povas esti pli pura, sed `for_each` eble preferas konservi funkcian stilon kun pli longaj ripetiloj:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Kreas ripetilon, kiu uzas fermon por determini ĉu elemento devas esti cedita.
    ///
    /// Donita elemento la fermo devas redoni `true` aŭ `false`.La revenita ripetilo donos nur la elementojn, por kiuj la fermo redonas veron.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ĉar la fermo transdonita al `filter()` prenas referencon, kaj multaj ripetantoj ripetas referencojn, tio kondukas al eble konfuza situacio, kie la tipo de la fermo estas duobla referenco:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // bezonas du * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ofte oni anstataŭe uzas detruadon sur la argumento por forigi unu:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // kaj kaj *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// aŭ ambaŭ:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // du &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// de ĉi tiuj tavoloj.
    ///
    /// Notu, ke `iter.filter(f).next()` estas ekvivalenta al `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Kreas ripetilon, kiu filtras kaj mapas.
    ///
    /// La revenita ripetilo donas nur la "valorojn" por kiuj la liverita fermo redonas `Some(value)`.
    ///
    /// `filter_map` uzeblas por igi ĉenojn de [`filter`] kaj [`map`] pli koncizaj.
    /// La ekzemplo sube montras kiel `map().filter().map()` povas esti mallongigita al ununura alvoko al `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Jen la sama ekzemplo, sed kun [`filter`] kaj [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Kreas ripeton, kiu donas la aktualan ripetan kalkulon kaj ankaŭ la sekvan valoron.
    ///
    /// La ripetilo donas rendimentajn parojn `(i, val)`, kie `i` estas la aktuala indekso de ripeto kaj `val` estas la valoro redonita de la ripetilo.
    ///
    ///
    /// `enumerate()` konservas sian kalkulon kiel [`usize`].
    /// Se vi volas kalkuli laŭ malsama entjero, la funkcio [`zip`] provizas similan funkcion.
    ///
    /// # Superflua Konduto
    ///
    /// La metodo ne protektas kontraŭ superfluoj, do listigi pli ol [`usize::MAX`]-elementojn aŭ produktas malĝustan rezulton aŭ panics.
    /// Se elpurigaj asertoj estas ebligitaj, panic estas garantiita.
    ///
    /// # Panics
    ///
    /// La revenita ripeto eble panic se la resendota indekso superverŝus [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Kreas ripetilon, kiu povas uzi [`peek`] por rigardi la sekvan elementon de la ripetilo sen konsumi ĝin.
    ///
    /// Aldonas [`peek`]-metodon al ripetilo.Vidu ĝian dokumentaron por pliaj informoj.
    ///
    /// Rimarku, ke la suba ripeto estas ankoraŭ progresinta kiam [`peek`] estas vokata por la unua fojo: Por retrovi la sekvan elementon, [`next`] estas vokita al la suba ripeto, do iuj kromefikoj (t.e.
    ///
    /// io alia ol venigi la sekvan valoron) de la [`next`]-metodo okazos.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() lasas nin vidi en la future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // ni povas peek() plurfoje, la ripetilo ne progresos
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // post la ripeto finiĝas, do peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Kreas ripeton, kiu [`saltas`] elementojn bazitajn sur predikato.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` prenas fermon kiel argumenton.Ĝi nomos ĉi tiun fermon sur ĉiu elemento de la ripetilo, kaj ignoros elementojn ĝis ĝi redonos `false`.
    ///
    /// Post kiam `false` estas redonita, `skip_while()`'s-laboro finiĝis, kaj la resto de la elementoj cedas.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ĉar la fermo transdonita al `skip_while()` prenas referencon, kaj multaj ripetantoj ripetas referencojn, tio kondukas al eble konfuza situacio, kie la tipo de la ferma argumento estas duobla referenco:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // bezonas du * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ĉesi post komenca `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // dum ĉi tio estus falsa, ĉar ni jam ricevis falsaĵon, skip_while() ne plu estas uzata
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Kreas ripeton, kiu donas elementojn bazitajn sur predikato.
    ///
    /// `take_while()` prenas fermon kiel argumenton.Ĝi nomos ĉi tiun fermon sur ĉiu elemento de la ripetilo, kaj donos elementojn dum ĝi redonos `true`.
    ///
    /// Post kiam `false` estas redonita, `take_while()`'s-laboro finiĝis, kaj la resto de la elementoj estas ignorita.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ĉar la fermo transdonita al `take_while()` prenas referencon, kaj multaj ripetantoj ripetas referencojn, tio kondukas al eble konfuza situacio, kie la tipo de la fermo estas duobla referenco:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // bezonas du * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ĉesi post komenca `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Ni havas pli da elementoj malpli ol nul, sed ĉar ni jam ricevis falsaĵon, take_while() ne plu estas uzata
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ĉar `take_while()` bezonas rigardi la valoron por vidi ĉu ĝi devas esti inkluzivita aŭ ne, konsumantaj ripetantoj vidos, ke ĝi estas forigita:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// La `3` ne plu estas, ĉar ĝi estis konsumita por vidi ĉu la ripeto devas ĉesi, sed ne estis metita reen en la ripeton.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Kreas ripeton, kiu ambaŭ donas elementojn bazitajn sur predikato kaj mapoj.
    ///
    /// `map_while()` prenas fermon kiel argumenton.
    /// Ĝi nomos ĉi tiun fermon sur ĉiu elemento de la ripetilo, kaj donos elementojn dum ĝi redonos [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Jen la sama ekzemplo, sed kun [`take_while`] kaj [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ĉesi post komenca [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Ni havas pli da elementoj, kiuj povus kongrui kun u32 (4, 5), sed `map_while` redonis `None` por `-3` (kiel `predicate` redonis `None`) kaj `collect` haltas ĉe la unua renkontita `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Ĉar `map_while()` bezonas rigardi la valoron por vidi ĉu ĝi devas esti inkluzivita aŭ ne, konsumantaj ripetantoj vidos, ke ĝi estas forigita:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// La `-3` ne plu estas, ĉar ĝi estis konsumita por vidi ĉu la ripeto devas ĉesi, sed ne estis metita reen en la ripeton.
    ///
    /// Notu, ke male al [`take_while`], ĉi tiu ripetilo **ne** estas kunfandita.
    /// Ankaŭ ne estas specifite, kion ĉi tiu ripetilo redonas post kiam la unua [`None`] estas redonita.
    /// Se vi bezonas kunfanditan ripetilon, uzu [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Kreas ripeton, kiu preterlasas la unuajn `n`-elementojn.
    ///
    /// Post kiam ili estis konsumitaj, la resto de la elementoj estas donita.
    /// Anstataŭ anstataŭigi ĉi tiun metodon rekte, anstataŭe anstataŭigu la `nth`-metodon.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Kreas ripeton, kiu donas siajn unuajn `n`-elementojn.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` estas ofte uzata kun senfina ripetilo, por fari ĝin finia:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Se malpli ol `n`-elementoj disponeblas, `take` limiĝos al la grandeco de la suba ripeto:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Ripetanto-adaptilo simila al [`fold`], kiu tenas internan staton kaj produktas novan ripetilon.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` prenas du argumentojn: komenca valoro, kiu semas la internan staton, kaj fermo kun du argumentoj, la unua estas ŝanĝebla referenco al la interna stato kaj la dua estas itera elemento.
    ///
    /// La fermo povas atribui al la interna stato dividi staton inter ripetoj.
    ///
    /// Dum ripeto, la fermo estos aplikita al ĉiu elemento de la ripetilo kaj la revenvaloro de la fermo, [`Option`], estas donita de la ripetilo.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // ĉiu ripeto, ni multobligos la staton per la elemento
    ///     *state = *state * x;
    ///
    ///     // tiam ni donos la negadon de la ŝtato
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Kreas ripeton, kiu funkcias kiel mapo, sed ebenigas nestitan strukturon.
    ///
    /// La [`map`]-adaptilo estas tre utila, sed nur kiam la ferma argumento produktas valorojn.
    /// Se ĝi anstataŭe produktas ripetilon, estas kroma tavolo de malrekta.
    /// `flat_map()` forigos ĉi tiun ekstran tavolon per si mem.
    ///
    /// Vi povas pensi pri `flat_map(f)` kiel la semantika ekvivalento de [`map`] ping, kaj tiam [`platigi`] kiel en `map(f).flatten()`.
    ///
    /// Alia pensmaniero pri `flat_map()`: la fermo de [mapo] redonas unu eron por ĉiu elemento, kaj la fermo de `flat_map()`'s redonas ripetilon por ĉiu elemento.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() redonas ripetilon
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Kreas ripeton, kiu platigas nestitan strukturon.
    ///
    /// Ĉi tio estas utila, kiam vi havas ripetilon de ripetiloj aŭ ripetilon de aferoj, kiuj povas esti transformitaj en ripetilojn, kaj vi volas forigi unu nivelon de malrekteco.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mapado kaj poste platigo:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() redonas ripetilon
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Vi ankaŭ povas reskribi ĉi tion laŭ [`flat_map()`], kio estas preferinda en ĉi tiu kazo, ĉar ĝi transdonas intencon pli klare:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() redonas ripetilon
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Platigado nur forigas unu nivelon de nestado samtempe:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Ĉi tie ni vidas, ke `flatten()` ne plenumas "deep"-platon.
    /// Anstataŭe nur unu nivelo de nestado estas forigita.Tio estas, se vi `flatten()` tridimensia tabelo, la rezulto estos dudimensia kaj ne unudimensia.
    /// Por akiri unudimensian strukturon, vi devas `flatten()` denove.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Kreas ripeton, kiu finiĝas post la unua [`None`].
    ///
    /// Post kiam ripetilo redonas [`None`], future-alvokoj eble aŭ eble ne donos [`Some(T)`] denove.
    /// `fuse()` adaptas ripetilon, certigante, ke post donado de [`None`], ĝi ĉiam redonos [`None`] por ĉiam.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // ripetilo kiu alternas inter Iuj kaj Neniu
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // se ĝi egalas, Some(i32), alie Neniu
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // ni povas vidi nian ripetanton iri tien kaj reen
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // tamen, post kiam ni kunfandos ĝin ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ĝi ĉiam redonos `None` post la unua fojo.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Faras ion kun ĉiu elemento de ripeto, transdonante la valoron.
    ///
    /// Kiam vi uzas ripetilojn, vi ofte katenas plurajn el ili kune.
    /// Dum vi laboras pri tia kodo, vi eble volos kontroli, kio okazas ĉe diversaj partoj en la dukto.Por fari tion, enmetu vokon al `inspect()`.
    ///
    /// Estas pli ofte por `inspect()` esti uzata kiel elpuriga ilo ol ekzisti en via fina kodo, sed programoj povas trovi ĝin utila en iuj situacioj, kiam eraroj devas esti registritaj antaŭ ol forĵeti ilin.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // ĉi iteracia vico estas kompleksa.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ni aldonu kelkajn inspect()-vokojn por esplori kio okazas
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Ĉi tio presos:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Registradaj eraroj antaŭ forĵeti ilin:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Ĉi tio presos:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Pruntas ripetilon, anstataŭ konsumi ĝin.
    ///
    /// Ĉi tio utilas por permesi apliki iteratorajn adaptilojn, tamen konservante posedon de la originala iteratoro.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // se ni provos uzi iter denove, ĝi ne funkcios.
    /// // La sekva linio donas "eraron: uzo de movita valoro: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ni provu tion denove
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // anstataŭe ni aldonas .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // nun ĉi tio estas bone:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Transformas ripeton en kolekton.
    ///
    /// `collect()` povas preni ion ajn ripeteblan, kaj transformi ĝin en koncernan kolekton.
    /// Ĉi tiu estas unu el la pli potencaj metodoj en la norma biblioteko, uzata en diversaj kuntekstoj.
    ///
    /// La plej baza ŝablono per kiu `collect()` estas uzata estas igi unu kolekton en alian.
    /// Vi prenas kolekton, alvokas [`iter`]-on, faras multajn transformojn, kaj poste `collect()` fine.
    ///
    /// `collect()` povas ankaŭ krei ekzemplojn de tipoj, kiuj ne estas tipaj kolektoj.
    /// Ekzemple, [`String`] povas esti konstruita de [`char`] s, kaj ripetilo de [`Result<T, E>`][`Result`]-aĵoj povas esti kolektita en `Result<Collection<T>, E>`.
    ///
    /// Vidu la ekzemplojn sube por pli.
    ///
    /// Ĉar `collect()` estas tiel ĝenerala, ĝi povas kaŭzi problemojn kun tipo-konkludo.
    /// Tiel, `collect()` estas unu el la malmultaj fojoj, kiujn vi vidos la sintakson ame konatan kiel 'turbofish': `::<>`.
    /// Ĉi tio helpas la konkludan algoritmon kompreni specife en kiun kolekton vi provas kolekti.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Notu, ke ni bezonis la `: Vec<i32>` maldekstre.Ĉi tio estas ĉar ni povus kolekti en, ekzemple, [`VecDeque<T>`] anstataŭe:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Uzi la 'turbofish' anstataŭ komenti `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Ĉar `collect()` zorgas nur pri tio, kion vi kolektas, vi ankoraŭ povas uzi partan tipan aludon, `_`, kun la turbfiŝo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Uzante `collect()` por fari [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Se vi havas liston de [`Rezulto<T, E>`][`Rezulto`] s, vi povas uzi `collect()` por vidi ĉu iu el ili malsukcesis:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // donas al ni la unuan eraron
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // donas al ni la liston de respondoj
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Konsumas ripetilon, kreante du kolektojn el ĝi.
    ///
    /// La predikato transdonita al `partition()` povas redoni `true` aŭ `false`.
    /// `partition()` redonas paron, ĉiujn elementojn, por kiuj ĝi redonis `true`, kaj ĉiujn elementojn, por kiuj ĝi redonis `false`.
    ///
    ///
    /// Vidu ankaŭ [`is_partitioned()`] kaj [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reordigas la elementojn de ĉi tiu ripeto *surloke* laŭ la donita predikato, tiel ke ĉiuj tiuj, kiuj redonas `true` antaŭas ĉiujn, kiuj redonas `false`.
    ///
    /// Liveras la nombron de `true`-elementoj trovitaj.
    ///
    /// La relativa ordo de dispartigitaj eroj ne estas konservata.
    ///
    /// Vidu ankaŭ [`is_partitioned()`] kaj [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Sekcio surloke inter egaluloj kaj probabloj
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ĉu ni zorgu pri la superplena kalkulo?La sola maniero havi pli ol
        // `usize::MAX` ŝanĝeblaj referencoj estas kun ZST-oj, kiuj ne utilas por dispartigi ...

        // Ĉi tiuj fermaj "factory"-funkcioj ekzistas por eviti generecon en `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Ripete trovu la unuan `false` kaj interŝanĝu ĝin per la lasta `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Kontrolas ĉu la elementoj de ĉi tiu ripeto estas dispartigitaj laŭ la donita predikato, tiel ke ĉiuj tiuj, kiuj redonas `true` antaŭas ĉiujn, kiuj redonas `false`.
    ///
    ///
    /// Vidu ankaŭ [`partition()`] kaj [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Aŭ ĉiuj eroj testas `true`, aŭ la unua klaŭzo haltas ĉe `false` kaj ni kontrolas, ke ne plu ekzistas `true`-eroj post tio.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Ripeta metodo, kiu aplikas funkcion, se ĝi revenas sukcese, produktante unuopan finan valoron.
    ///
    /// `try_fold()` prenas du argumentojn: komenca valoro kaj fermo kun du argumentoj: 'accumulator' kaj elemento.
    /// La fermo aŭ revenas sukcese, kun la valoro, kiun la akumulilo havu por la sekva ripeto, aŭ ĝi redonas fiaskon, kun erara valoro disvastigita al la alvokanto tuj (short-circuiting).
    ///
    ///
    /// La komenca valoro estas la valoro, kiun la akumulilo havos ĉe la unua voko.Se apliki la fermon sukcesis kontraŭ ĉiu elemento de la ripetilo, `try_fold()` redonas la finan akumulilon kiel sukceson.
    ///
    /// Faldi estas utila kiam ajn vi havas kolekton de io, kaj volas produkti unu valoron el ĝi.
    ///
    /// # Noto al Efektivigantoj
    ///
    /// Pluraj el la aliaj (forward)-metodoj havas defaŭltajn efektivigojn laŭ ĉi tiu, do provu efektivigi ĉi tion eksplicite se ĝi povas fari ion pli bonan ol la defaŭlta `for`-bukla efektivigo.
    ///
    /// Precipe provu havi ĉi tiun alvokon `try_fold()` sur la internaj partoj, el kiuj konsistas ĉi tiu ripetilo.
    /// Se necesas pluraj alvokoj, la operatoro `?` eble taŭgas por ĉeni la valoron de la akumulilo, sed gardu vin kontraŭ ĉiuj invariantoj, kiuj devas esti konfirmitaj antaŭ tiuj fruaj revenoj.
    /// Ĉi tio estas `&mut self`-metodo, do ripeto devas esti rekomencinda post trafado de eraro ĉi tie.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // la kontrolita sumo de ĉiuj elementoj de la tabelo
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Ĉi tiu sumo superfluas kiam oni aldonas la 100 elementon
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Ĉar ĝi fuŝkontaktigis, la ceteraj elementoj ankoraŭ haveblas per la ripetilo.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Ripetmetodo, kiu aplikas fuŝeblan funkcion al ĉiu ero en la ripetilo, haltante ĉe la unua eraro kaj redonante tiun eraron.
    ///
    ///
    /// Ĉi tio ankaŭ povas esti pensata kiel la fuŝa formo de [`for_each()`] aŭ kiel la sennacia versio de [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Ĝi fuŝkontaktigis, do la ceteraj eroj ankoraŭ estas en la ripetilo:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Faldas ĉiun elementon en akumulilon aplikante operacion, redonante la finan rezulton.
    ///
    /// `fold()` prenas du argumentojn: komenca valoro kaj fermo kun du argumentoj: 'accumulator' kaj elemento.
    /// La fermo redonas la valoron, kiun la akumulilo devas havi por la sekva ripeto.
    ///
    /// La komenca valoro estas la valoro, kiun la akumulilo havos ĉe la unua voko.
    ///
    /// Post apliki ĉi tiun fermon al ĉiu elemento de la ripetilo, `fold()` redonas la akumulilon.
    ///
    /// Ĉi tiu operacio estas iam nomata 'reduce' aŭ 'inject'.
    ///
    /// Faldi estas utila kiam ajn vi havas kolekton de io, kaj volas produkti unu valoron el ĝi.
    ///
    /// Note: `fold()`, kaj similaj metodoj, kiuj trairas la tutan iteratoron, eble ne finiĝas por senfinaj iteratoroj, eĉ sur traits, por kiu rezulto estas difinebla en finia tempo.
    ///
    /// Note: [`reduce()`] uzeblas por uzi la unuan elementon kiel komencan valoron, se la akumulila tipo kaj ero-tipo estas samaj.
    ///
    /// # Noto al Efektivigantoj
    ///
    /// Pluraj el la aliaj (forward)-metodoj havas defaŭltajn efektivigojn laŭ ĉi tiu, do provu efektivigi ĉi tion eksplicite se ĝi povas fari ion pli bonan ol la defaŭlta `for`-bukla efektivigo.
    ///
    ///
    /// Precipe provu havi ĉi tiun alvokon `fold()` sur la internaj partoj, el kiuj konsistas ĉi tiu ripetilo.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // la sumo de ĉiuj elementoj de la tabelo
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ni trairu ĉiun paŝon de la ripeto ĉi tie:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Kaj tiel, nia fina rezulto, `6`.
    ///
    /// Ofte por homoj, kiuj ne multe uzis ripetilojn, uzi `for`-buklon kun listo de aferoj por krei rezulton.Tiuj povas esti transformitaj en `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // por buklo:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // ili samas
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Reduktas la elementojn al unu sola, plurfoje aplikante reduktantan operacion.
    ///
    /// Se la ripeto estas malplena, redonas [`None`];alie, redonas la rezulton de la redukto.
    ///
    /// Por ripetantoj kun almenaŭ unu elemento, tio samas kiel [`fold()`] kun la unua elemento de la ripetilo kiel la komenca valoro, faldante ĉiun postan elementon en ĝin.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Trovu la maksimuman valoron:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Provoj se ĉiu elemento de la ripetilo kongruas kun predikato.
    ///
    /// `all()` prenas fermon, kiu redonas `true` aŭ `false`.Ĝi aplikas ĉi tiun fermon al ĉiu elemento de la ripetilo, kaj se ili ĉiuj redonos `true`, do ankaŭ `all()`.
    /// Se iu el ili redonas `false`, ĝi redonas `false`.
    ///
    /// `all()` fuŝkontaktigas;alivorte, ĝi ĉesos prilaboradon tuj kiam ĝi trovos `false`, ĉar ne gravas kio alia okazos, la rezulto ankaŭ estos `false`.
    ///
    ///
    /// Malplena ripetilo redonas `true`.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Ĉesante ĉe la unua `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // ni ankoraŭ povas uzi `iter`, ĉar estas pli da elementoj.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Provoj se iu elemento de la ripetilo kongruas kun predikato.
    ///
    /// `any()` prenas fermon, kiu redonas `true` aŭ `false`.Ĝi aplikas ĉi tiun fermon al ĉiu elemento de la ripetilo, kaj se iu el ili redonas `true`, do ankaŭ `any()`.
    /// Se ili ĉiuj redonas `false`, ĝi redonas `false`.
    ///
    /// `any()` fuŝkontaktigas;alivorte, ĝi ĉesos prilaboradon tuj kiam ĝi trovos `true`, ĉar ne gravas kio alia okazos, la rezulto ankaŭ estos `true`.
    ///
    ///
    /// Malplena ripetilo redonas `false`.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Ĉesante ĉe la unua `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // ni ankoraŭ povas uzi `iter`, ĉar estas pli da elementoj.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Serĉas elementon de ripeto, kiu kontentigas predikaton.
    ///
    /// `find()` prenas fermon, kiu redonas `true` aŭ `false`.
    /// Ĝi aplikas ĉi tiun fermon al ĉiu elemento de la ripetilo, kaj se iu el ili redonas `true`, tiam `find()` redonas [`Some(element)`].
    /// Se ili ĉiuj redonas `false`, ĝi redonas [`None`].
    ///
    /// `find()` fuŝkontaktigas;alivorte, ĝi ĉesos prilaboradon tuj kiam la fermo redonos `true`.
    ///
    /// Ĉar `find()` prenas referencon, kaj multaj ripetoj ripetas referencojn, tio kondukas al eble konfuza situacio, kie la argumento estas duobla referenco.
    ///
    /// Vi povas vidi ĉi tiun efikon en la ekzemploj sube, kun `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Ĉesante ĉe la unua `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // ni ankoraŭ povas uzi `iter`, ĉar estas pli da elementoj.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Notu, ke `iter.find(f)` estas ekvivalenta al `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Aplikas funkcion al la elementoj de ripeto kaj redonas la unuan nenenan rezulton.
    ///
    ///
    /// `iter.find_map(f)` estas ekvivalenta al `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Aplikas funkcion al la elementoj de ripetilo kaj redonas la unuan veran rezulton aŭ la unuan eraron.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Serĉas elementon en ripeto, redonante ĝian indekson.
    ///
    /// `position()` prenas fermon, kiu redonas `true` aŭ `false`.
    /// Ĝi aplikas ĉi tiun fermon al ĉiu elemento de la ripetilo, kaj se unu el ili redonas `true`, tiam `position()` redonas [`Some(index)`].
    /// Se ĉiuj redonas `false`, ĝi redonas [`None`].
    ///
    /// `position()` fuŝkontaktigas;alivorte, ĝi ĉesos prilabori tuj kiam ĝi trovos `true`.
    ///
    /// # Superflua Konduto
    ///
    /// La metodo ne protektas sin kontraŭ superfluoj, do se estas pli ol [`usize::MAX`] ne kongruaj elementoj, ĝi aŭ produktas malĝustan rezulton aŭ panics.
    ///
    /// Se elpurigaj asertoj estas ebligitaj, panic estas garantiita.
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio povus panic se la ripetilo havas pli ol `usize::MAX` ne kongruajn elementojn.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Ĉesante ĉe la unua `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // ni ankoraŭ povas uzi `iter`, ĉar estas pli da elementoj.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // La revenita indekso dependas de la itera stato
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Serĉas elementon en ripeto dekstre, redonante ĝian indekson.
    ///
    /// `rposition()` prenas fermon, kiu redonas `true` aŭ `false`.
    /// Ĝi aplikas ĉi tiun fermon al ĉiu elemento de la ripetilo, ekde la fino, kaj se unu el ili redonas `true`, tiam `rposition()` redonas [`Some(index)`].
    ///
    /// Se ĉiuj redonas `false`, ĝi redonas [`None`].
    ///
    /// `rposition()` fuŝkontaktigas;alivorte, ĝi ĉesos prilabori tuj kiam ĝi trovos `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Ĉesante ĉe la unua `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // ni ankoraŭ povas uzi `iter`, ĉar estas pli da elementoj.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Ne necesas superflua kontrolo ĉi tie, ĉar `ExactSizeIterator` implicas, ke la nombro da elementoj kongruas al `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Liveras la maksimuman elementon de ripetilo.
    ///
    /// Se pluraj elementoj estas same maksimumaj, la lasta elemento estas redonita.
    /// Se la ripeto estas malplena, [`None`] estas redonita.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Liveras la minimuman elementon de ripeto.
    ///
    /// Se pluraj elementoj estas same minimumaj, la unua elemento estas redonita.
    /// Se la ripeto estas malplena, [`None`] estas redonita.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Liveras la elementon, kiu donas la maksimuman valoron de la specifa funkcio.
    ///
    ///
    /// Se pluraj elementoj estas same maksimumaj, la lasta elemento estas redonita.
    /// Se la ripeto estas malplena, [`None`] estas redonita.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Liveras la elementon, kiu donas la maksimuman valoron rilate al la specifa komparfunkcio.
    ///
    ///
    /// Se pluraj elementoj estas same maksimumaj, la lasta elemento estas redonita.
    /// Se la ripeto estas malplena, [`None`] estas redonita.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Liveras la elementon, kiu donas la minimuman valoron de la specifa funkcio.
    ///
    ///
    /// Se pluraj elementoj estas same minimumaj, la unua elemento estas redonita.
    /// Se la ripeto estas malplena, [`None`] estas redonita.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Liveras la elementon, kiu donas la minimuman valoron rilate al la specifa komparfunkcio.
    ///
    ///
    /// Se pluraj elementoj estas same minimumaj, la unua elemento estas redonita.
    /// Se la ripeto estas malplena, [`None`] estas redonita.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Inversigas la direkton de ripeto.
    ///
    /// Kutime, ripetoj ripetas de maldekstre dekstren.
    /// Post uzi `rev()`, ripetilo anstataŭe ripetiĝos de dekstre al maldekstre.
    ///
    /// Ĉi tio eblas nur se la ripetilo havas finon, do `rev()` funkcias nur ĉe [`DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Konvertas ripetilon de paroj en paron da ujoj.
    ///
    /// `unzip()` konsumas tutan ripetilon de paroj, produktante du kolektojn: unu el la maldekstraj elementoj de la paroj, kaj unu el la dekstraj elementoj.
    ///
    ///
    /// Ĉi tiu funkcio iusence estas la malo de [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Kreas ripeton, kiu kopias ĉiujn siajn elementojn.
    ///
    /// Ĉi tio utilas kiam vi havas ripetilon super `&T`, sed vi bezonas ripetilon super `T`.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopiita estas la sama kiel .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Kreas ripeton, kiu [`klonas`] ĉiuj ĝiaj elementoj.
    ///
    /// Ĉi tio utilas kiam vi havas ripetilon super `&T`, sed vi bezonas ripetilon super `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // klonita estas la sama kiel .map(|&x| x), por entjeroj
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Ripetas ripetilon senfine.
    ///
    /// Anstataŭ ĉesi ĉe [`None`], la ripetilo anstataŭe komenciĝos denove, de la komenco.Post ripetado, ĝi komenciĝos denove komence.Kaj denove.
    /// Kaj denove.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Sumas la elementojn de ripetilo.
    ///
    /// Prenas ĉiun elementon, aldonas ilin kune kaj redonas la rezulton.
    ///
    /// Malplena ripeto redonas la nulan valoron de la tipo.
    ///
    /// # Panics
    ///
    /// Kiam oni vokas `sum()` kaj oni redonas primitivan entjeran tipon, ĉi tiu metodo panic se la komputado superfluas kaj elpurigas asertojn estas ebligitaj.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Ripetas la tutan ripetilon, multobligante ĉiujn elementojn
    ///
    /// Malplena ripetilo redonas la unu valoron de la tipo.
    ///
    /// # Panics
    ///
    /// Kiam oni vokas `product()` kaj oni redonas primitivan entjeran tipon, metodo panic se la komputado superfluas kaj elpurigas asertojn estas ebligita.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) komparas la elementojn de ĉi tiu [`Iterator`] kun tiuj de alia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) komparas la elementojn de ĉi tiu [`Iterator`] kun tiuj de alia rilate al la specifa komparfunkcio.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) komparas la elementojn de ĉi tiu [`Iterator`] kun tiuj de alia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) komparas la elementojn de ĉi tiu [`Iterator`] kun tiuj de alia rilate al la specifa komparfunkcio.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Determinas ĉu la elementoj de ĉi tiu [`Iterator`] egalas al tiuj de alia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Determinas ĉu la elementoj de ĉi tiu [`Iterator`] egalas al tiuj de alia rilate al la specifa egaleca funkcio.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Determinas ĉu la elementoj de ĉi tiu [`Iterator`] estas neegalaj al tiuj de alia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Determinas ĉu la elementoj de ĉi tiu [`Iterator`] estas [lexicographically](Ord#lexicographical-comparison) malpli ol tiuj de alia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Determinas ĉu la elementoj de ĉi tiu [`Iterator`] estas [lexicographically](Ord#lexicographical-comparison) malpli aŭ egalaj al tiuj de alia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Determinas ĉu la elementoj de ĉi tiu [`Iterator`] estas [lexicographically](Ord#lexicographical-comparison) pli grandaj ol tiuj de alia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Determinas ĉu la elementoj de ĉi tiu [`Iterator`] estas [lexicographically](Ord#lexicographical-comparison) pli grandaj aŭ egalaj al tiuj de alia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Kontrolas ĉu la elementoj de ĉi tiu ripeto estas ordigitaj.
    ///
    /// Tio estas, por ĉiu elemento `a` kaj ĝia sekva elemento `b`, `a <= b` devas teni.Se la ripeto donas precize nulon aŭ unu elementon, `true` estas redonita.
    ///
    /// Notu, ke se `Self::Item` estas nur `PartialOrd`, sed ne `Ord`, la supra difino implicas, ke ĉi tiu funkcio redonas `false` se iuj du sinsekvaj eroj ne kompareblas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Kontrolas ĉu la elementoj de ĉi tiu ripetilo estas ordigitaj per la donita komparila funkcio.
    ///
    /// Anstataŭ uzi `PartialOrd::partial_cmp`, ĉi tiu funkcio uzas la donitan `compare`-funkcion por determini la ordon de du elementoj.
    /// Krom tio, ĝi ekvivalentas al [`is_sorted`];vidu ĝian dokumentadon por pliaj informoj.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Kontrolas ĉu la elementoj de ĉi tiu ripetilo estas ordigitaj per la donita ŝlosila eltira funkcio.
    ///
    /// Anstataŭ kompari rekte la elementojn de la ripetilo, ĉi tiu funkcio komparas la klavojn de la elementoj, kiel determinite de `f`.
    /// Krom tio, ĝi ekvivalentas al [`is_sorted`];vidu ĝian dokumentadon por pliaj informoj.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Vidu [TrustedRandomAccess]
    // La nekutima nomo estas eviti nomkoliziojn en metodo-rezolucio vidu #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}