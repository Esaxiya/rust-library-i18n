/// Ripetanto, kiu ĉiam daŭre donas `None` kiam elĉerpita.
///
/// Voki sekve kun kunfandita ripetilo, kiu redonis `None` unufoje, garantios redoni [`None`] denove.
/// Ĉi trait devas esti efektivigita de ĉiuj ripetantoj, kiuj tiel kondutas, ĉar ĝi permesas optimumigi [`Iterator::fuse()`].
///
///
/// Note: Ĝenerale vi ne uzu `FusedIterator` en ĝeneralaj limoj se vi bezonas kunfanditan ripetilon.
/// Anstataŭe vi devas simple telefoni al [`Iterator::fuse()`] per la ripetilo.
/// Se la ripeto jam estas kunfandita, la aldona envolvaĵo [`Fuse`] estos senoperacia sen rendimento.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Ripetanto, kiu raportas precizan longon per size_hint.
///
/// La ripetilo raportas grandecan aludon, kie ĝi estas aŭ ĝusta (malsupra rando egalas al supra rando), aŭ la supra rando estas [`None`].
///
/// La supra rando devas esti nur [`None`] se la efektiva ripeta longo estas pli granda ol [`usize::MAX`].
/// En tiu kazo, la malsupra rando devas esti [`usize::MAX`], rezultigante [`Iterator::size_hint()`] de `(usize::MAX, None)`.
///
/// La ripetanto devas produkti ĝuste la nombron da elementoj, kiujn ĝi raportis aŭ diverĝas, antaŭ ol atingi la finon.
///
/// # Safety
///
/// Ĉi tiu trait devas esti efektivigita nur kiam la kontrakto estas konfirmita.
/// Konsumantoj de ĉi tiu trait devas inspekti [`Iterator::size_hint()`]’s-supran limon.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Ripetanto, ke kiam vi donos eron, estos preninta almenaŭ unu elementon de ĝia suba [`SourceIter`].
///
/// Vokante iun ajn metodon, kiu antaŭenigas la ripetilon, ekz
/// [`next()`] aŭ [`try_fold()`], garantias, ke por ĉiu paŝo almenaŭ unu valoro de la suba fonto de la iteratoro estis elŝovita kaj la rezulto de la iterator-ĉeno povus esti enmetita anstataŭe, supozante ke strukturaj limoj de la fonto permesas tian enmeton.
///
/// Alivorte ĉi tiu trait indikas, ke ripeta dukto povas esti kolektita en loko.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}