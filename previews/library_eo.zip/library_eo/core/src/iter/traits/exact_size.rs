/// Ripetanto, kiu scias ĝian ĝustan longon.
///
/// Multaj ["Iterator"] ne scias kiomfoje ili ripetos, sed iuj jes.
/// Se ripetanto scias kiom multajn fojojn ĝi povas ripeti, provizi aliron al tiuj informoj povas esti utila.
/// Ekzemple, se vi volas ripeti malantaŭen, bona komenco estas scii, kie estas la fino.
///
/// Kiam vi efektivigas `ExactSizeIterator`, vi devas ankaŭ efektivigi [`Iterator`].
/// Farante tion, la efektivigo de [`Iterator::size_hint`]*devas* redoni la ĝustan grandecon de la ripetilo.
///
/// La [`len`]-metodo havas defaŭltan efektivigon, do vi kutime ne devas efektivigi ĝin.
/// Tamen vi eble povas provizi pli efikan efektivigon ol la defaŭlta, do anstataŭigi ĝin ĉi-kaze havas sencon.
///
///
/// Rimarku, ke ĉi tiu trait estas sekura trait kaj kiel tia *ne* kaj *ne povas* garantii, ke la revenita longo estas ĝusta.
/// Ĉi tio signifas, ke `unsafe`-kodo **ne** devas dependi de la ĝusteco de [`Iterator::size_hint`].
/// La malstabila kaj nesekura [`TrustedLen`](super::marker::TrustedLen) trait donas ĉi tiun aldonan garantion.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// // finia gamo scias precize kiom multajn fojojn ĝi ripetos
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// En la [module-level docs], ni efektivigis [`Iterator`], `Counter`.
/// Ni efektivigu `ExactSizeIterator` ankaŭ por ĝi:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Ni povas facile kalkuli la restantan nombron de ripetoj.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Kaj nun ni povas uzi ĝin!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Liveras la ĝustan longon de la ripetilo.
    ///
    /// La efektivigo certigas, ke la ripetilo redonos ĝuste `len()` pli ofte [`Some(T)`]-valoron, antaŭ ol redoni [`None`].
    ///
    /// Ĉi tiu metodo havas defaŭltan efektivigon, do vi kutime ne devas efektivigi ĝin rekte.
    /// Tamen, se vi povas provizi pli efikan efektivigon, vi povas fari tion.
    /// Vidu la dokumentojn de [trait-level] por ekzemplo.
    ///
    /// Ĉi tiu funkcio havas la samajn sekurecajn garantiojn kiel la funkcio [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // finia gamo scias precize kiom multajn fojojn ĝi ripetos
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Ĉi tiu aserto estas tro defenda, sed ĝi kontrolas la invarianton
        // garantiita de la trait.
        // Se ĉi tiu trait estus rust-interna, ni povus uzi debug_assert !;aserti_ekv!kontrolos ankaŭ ĉiujn Rust-uzajn efektivigojn.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Liveras `true` se la ripeto estas malplena.
    ///
    /// Ĉi tiu metodo havas defaŭltan efektivigon per [`ExactSizeIterator::len()`], do vi ne bezonas efektivigi ĝin mem.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}