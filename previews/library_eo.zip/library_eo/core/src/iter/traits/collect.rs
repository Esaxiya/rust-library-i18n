/// Konvertiĝo de [`Iterator`].
///
/// Efektivigante `FromIterator` por tipo, vi difinas kiel ĝi kreiĝos de ripeto.
/// Ĉi tio kutimas por specoj, kiuj priskribas ian kolekton.
///
/// [`FromIterator::from_iter()`] malofte estas nomata eksplicite, kaj anstataŭe estas uzata per [`Iterator::collect()`]-metodo.
///
/// Vidu dokumentadon de [`Iterator::collect()`]'s por pli da ekzemploj.
///
/// Vidu ankaŭ: [`IntoIterator`].
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Uzi [`Iterator::collect()`] por implicite uzi `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Efektivigante `FromIterator` por via tipo:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Ekzempla kolekto, tio estas nur envolvaĵo super Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ni donu al ĝi iujn metodojn, por ke ni povu krei unu kaj aldoni aferojn al ĝi.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // kaj ni efektivigos FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Nun ni povas krei novan ripetilon ...
/// let iter = (0..5).into_iter();
///
/// // ... kaj faru MyCollection el ĝi
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // kolektu ankaŭ verkojn!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Kreas valoron de ripeto.
    ///
    /// Vidu la [module-level documentation] por pli.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Konvertiĝo al [`Iterator`].
///
/// Efektivigante `IntoIterator` por tipo, vi difinas kiel ĝi konvertiĝos al ripetilo.
/// Ĉi tio kutimas por specoj, kiuj priskribas ian kolekton.
///
/// Unu avantaĝo de efektivigado de `IntoIterator` estas, ke via tipo [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Vidu ankaŭ: [`FromIterator`].
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Efektivigante `IntoIterator` por via tipo:
///
/// ```
/// // Ekzempla kolekto, tio estas nur envolvaĵo super Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ni donu al ĝi iujn metodojn, por ke ni povu krei unu kaj aldoni aferojn al ĝi.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // kaj ni efektivigos IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Nun ni povas fari novan kolekton ...
/// let mut c = MyCollection::new();
///
/// // ... aldonu iom da afero al ĝi ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... kaj poste transformu ĝin en Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Ofte oni uzas `IntoIterator` kiel trait bound.Ĉi tio permesas ŝanĝi la enigan kolekto-tipon, kondiĉe ke ĝi ankoraŭ estas ripetilo.
/// Pliaj limoj povas esti specifitaj per limigo de
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// La speco de la ripetataj elementoj.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// En kia ripeto ni transformas ĉi tion?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Kreas ripetilon de valoro.
    ///
    /// Vidu la [module-level documentation] por pli.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Etendi kolekton kun la enhavo de ripeto.
///
/// Ripetiloj produktas serion de valoroj, kaj kolektoj ankaŭ povas esti pensataj kiel serio de valoroj.
/// La `Extend` trait liberigas ĉi tiun interspacon, permesante al vi etendi kolekton per inkluzivo de la enhavo de tiu ripetilo.
/// Etendante kolekton kun jam ekzistanta ŝlosilo, tiu eniro estas ĝisdatigita aŭ, se temas pri kolektoj, kiuj permesas plurajn enirojn kun egalaj ŝlosiloj, tiu eniro estas enmetita.
///
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// // Vi povas etendi Ŝnuron kun iuj signoj:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Efektiviganta `Extend`:
///
/// ```
/// // Ekzempla kolekto, tio estas nur envolvaĵo super Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ni donu al ĝi iujn metodojn, por ke ni povu krei unu kaj aldoni aferojn al ĝi.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ĉar MyCollection havas liston de i32-oj, ni efektivigas Extend por i32
/// impl Extend<i32> for MyCollection {
///
///     // Ĉi tio estas iomete pli simpla kun la konkreta tipa subskribo: ni povas nomi etendi ĉion, kio povas iĝi Iterator, kiu donas al ni i32-ojn.
///     // Ĉar ni bezonas i32-ojn por meti en MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // La efektivigo estas tre simpla: trairu la iteratoron, kaj add() ĉiun elementon al ni mem.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // ni etendu nian kolekton per tri pliaj numeroj
/// c.extend(vec![1, 2, 3]);
///
/// // ni aldonis ĉi tiujn elementojn al la fino
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Etendas kolekton kun la enhavo de ripeto.
    ///
    /// Ĉar ĉi tiu estas la sola bezonata metodo por ĉi tiu trait, la dokumentoj [trait-level] enhavas pli da detaloj.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // Vi povas etendi Ŝnuron kun iuj signoj:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Etendas kolekton kun ekzakte unu elemento.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Rezervas kapaciton en kolekto por la donita nombro da aldonaj elementoj.
    ///
    /// La defaŭlta efektivigo faras nenion.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}