//! Komponebla ekstera ripeto.
//!
//! Se vi trovis vin kun ia kolekto, kaj bezonis fari operacion pri la elementoj de tiu kolekto, vi rapide renkontos 'iterators'.
//! Ripetoj estas tre uzataj en idioma Rust-kodo, do indas konatiĝi kun ili.
//!
//! Antaŭ ol klarigi pli, ni parolu pri kiel strukturiĝas ĉi tiu modulo:
//!
//! # Organization
//!
//! Ĉi tiu modulo estas plejparte organizita laŭ tipo:
//!
//! * [Traits] estas la kerna parto: ĉi tiuj traits difinas kiajn ripetilojn ekzistas kaj kion vi povas fari per ili.La metodoj de ĉi tiuj traits indas meti iom da kroma studotempo.
//! * [Functions] provizi iujn helpajn manierojn krei iujn bazajn ripetilojn.
//! * [Structs] ofte estas la revenaj specoj de la diversaj metodoj en la traits de ĉi tiu modulo.Vi kutime volas rigardi la metodon, kiu kreas la `struct`, anstataŭ la `struct` mem.
//! Por pli da detaloj pri kial, vidu '[Implementing Iterator](#Implementing-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Jen ĝi!Ni enprofundiĝu en ripetiloj.
//!
//! # Iterator
//!
//! La koro kaj animo de ĉi tiu modulo estas la [`Iterator`] trait.La kerno de [`Iterator`] aspektas tiel:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Ripetanto havas metodon, [`next`], kiu kiam vokita, redonas [`Opcio`]`<Item>`.
//! [`next`] redonos [`Some(Item)`] kondiĉe ke ekzistas elementoj, kaj post kiam ĉiuj elĉerpiĝos, redonos `None` por indiki ke ripeto finiĝis.
//! Individuaj ripetantoj povas elekti rekomenci ripeton, kaj tiel voki [`next`] denove eble eble eventuale komencos resendi [`Some(Item)`] iam (ekzemple, vidu [`TryIter`]).
//!
//!
//! La plena difino de [`Iterator`] inkluzivas ankaŭ multajn aliajn metodojn, sed ili estas defaŭltaj metodoj, konstruitaj aldone al [`next`], kaj do vi ricevas ilin senpage.
//!
//! Ripetiloj ankaŭ estas komponeblaj, kaj estas kutime kunligi ilin por fari pli kompleksajn formojn de prilaborado.Vidu la sekcion [Adapters](#adapters) sube por pliaj detaloj.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # La tri formoj de ripeto
//!
//! Estas tri oftaj metodoj, kiuj povas krei ripetilojn de kolekto:
//!
//! * `iter()`, kiu ripetas super `&T`.
//! * `iter_mut()`, kiu ripetas super `&mut T`.
//! * `into_iter()`, kiu ripetas super `T`.
//!
//! Diversaj aferoj en la norma biblioteko povas efektivigi unu aŭ pli el la tri, se konvene.
//!
//! # Efektiviganta Iterator
//!
//! Krei iteratoron propran implicas du paŝojn: krei `struct` por teni la staton de la iteratoro, kaj poste efektivigi [`Iterator`] por tiu `struct`.
//! Tial estas tiom da `struct`s en ĉi tiu modulo: ekzistas unu por ĉiu ripetilo kaj ripetilo.
//!
//! Ni kreu ripetilon nomatan `Counter`, kiu kalkulas de `1` al `5`:
//!
//! ```
//! // Unue, la strukturo:
//!
//! /// Ripetanto, kiu kalkulas de unu ĝis kvin
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ni volas, ke nia kalkulo komencu per unu, do ni aldonu new()-metodon por helpi.
//! // Ĉi tio ne strikte necesas, sed konvenas.
//! // Notu, ke ni startas `count` je nulo, ni vidos kial en `next()`'s-efektivigo sube.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Poste ni efektivigas `Iterator` por nia `Counter`:
//!
//! impl Iterator for Counter {
//!     // ni kalkulos kun uzokutimo
//!     type Item = usize;
//!
//!     // next() estas la sola bezonata metodo
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Pliigu nian kalkulon.Jen kial ni komencis je nulo.
//!         self.count += 1;
//!
//!         // Kontrolu ĉu ni finis kalkuli aŭ ne.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Kaj nun ni povas uzi ĝin!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Voki [`next`] tiamaniere ripetiĝas.Rust havas konstruaĵon, kiu povas nomi [`next`] per via ripetilo, ĝis ĝi atingos `None`.Ni pripensu tion sekve.
//!
//! Notu ankaŭ, ke `Iterator` provizas defaŭltan efektivigon de metodoj kiel `nth` kaj `fold`, kiuj nomas `next` interne.
//! Tamen eblas ankaŭ verki laŭmendan efektivigon de metodoj kiel `nth` kaj `fold` se ripeto povas komputi ilin pli efike sen voki `next`.
//!
//! # `for` masxojn kaj `IntoIterator`
//!
//! La bukla sintakso de Rust estas fakte sukero por ripetantoj.Jen baza ekzemplo de `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Ĉi tio presos la numerojn unu ĝis kvin, ĉiu sur sia propra linio.Sed vi rimarkos ion ĉi tie: ni neniam vokis ion al nia vector por produkti ripeton.Kio donas?
//!
//! Estas trait en la norma biblioteko por konverti ion en ripetilon: [`IntoIterator`].
//! Ĉi tiu trait havas unu metodon, [`into_iter`], kiu konvertas la aferon efektivigantan [`IntoIterator`] en ripetilon.
//! Ni rigardu tiun `for`-buklon denove, kaj en kio la kompililo konvertas ĝin:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sukeras ĉi tion en:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Unue ni nomas `into_iter()` laŭ la valoro.Poste ni kongruas kun la iteratoro, kiu revenas, vokante [`next`] ree ĝis ni vidas `None`.
//! Je tiu punkto, ni `break` elĉerpiĝis, kaj ni finis iteradon.
//!
//! Estas ankoraŭ unu subtila peceto ĉi tie: la norma biblioteko enhavas interesan efektivigon de [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Alivorte, ĉiuj [`Iterator`] efektivigas [`IntoIterator`], nur redonante sin mem.Ĉi tio signifas du aferojn:
//!
//! 1. Se vi skribas [`Iterator`], vi povas uzi ĝin kun `for`-buklo.
//! 2. Se vi kreas kolekton, efektivigi [`IntoIterator`] por ĝi permesos uzi vian kolekton kun la `for`-buklo.
//!
//! # Ripetante per referenco
//!
//! Ĉar [`into_iter()`] prenas `self` laŭ valoro, uzi `for`-buklon por ripeti kolekton konsumas tiun kolekton.Ofte vi eble volas ripeti kolekton sen konsumi ĝin.
//! Multaj kolektoj ofertas metodojn, kiuj provizas ripetilojn super referencoj, konvencie nomataj respektive `iter()` kaj `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` estas ankoraŭ posedata de ĉi tiu funkcio.
//! ```
//!
//! Se kolekta tipo `C` provizas `iter()`, ĝi kutime ankaŭ efektivigas `IntoIterator` por `&C`, kun efektivigo, kiu nur nomas `iter()`.
//! Same kolekto `C` kiu provizas `iter_mut()` ĝenerale efektivigas `IntoIterator` por `&mut C` per delegado al `iter_mut()`.Ĉi tio ebligas oportunan stenografion:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // same kiel `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // same kiel `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Dum multaj kolektoj ofertas `iter()`, ne ĉiuj ofertas `iter_mut()`.
//! Ekzemple, mutacii la klavojn de [`HashSet<T>`] aŭ [`HashMap<K, V>`] povus meti la kolekton en malkonsekvencan staton se la ŝlosila hakilo ŝanĝiĝas, do ĉi tiuj kolektoj nur ofertas `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funkcioj, kiuj prenas [`Iterator`] kaj redonas alian [`Iterator`], estas ofte nomataj "iteratoraj adaptiloj", ĉar ili estas formo de la "adaptilo"
//! pattern'.
//!
//! Oftaj iteratoraj adaptiloj inkluzivas [`map`], [`take`] kaj [`filter`].
//! Por pli, vidu ilian dokumentadon.
//!
//! Se iteratoradaptilo panics, la iterator estos en nespecifita (sed memore sekura) stato.
//! Ĉi tiu stato ankaŭ ne garantias resti la sama tra versioj de Rust, do vi devas eviti fidi je la ĝustaj valoroj redonitaj de ripeto, kiuj panikiĝis.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratoroj (kaj iteratoro [adapters](#adapters)) estas *pigraj*. Ĉi tio signifas, ke nur krei iteratoron ne _do_ multe. Nenio vere okazas ĝis vi vokas [`next`].
//! Ĉi tio estas foje fonto de konfuzo kiam oni kreas ripetilon nur por ĝiaj kromefikoj.
//! Ekzemple, la [`map`]-metodo nomas fermon sur ĉiu elemento, kiun ĝi ripetas:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Ĉi tio ne presos iujn valorojn, ĉar ni nur kreis ripetilon anstataŭ uzi ĝin.La kompililo avertos nin pri tia konduto:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! La idioma maniero skribi [`map`] por ĝiaj kromefikoj estas uzi `for`-buklon aŭ nomi la [`for_each`]-metodon:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Alia ofta maniero taksi ripeton estas uzi la [`collect`]-metodon por produkti novan kolekton.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Ripetantoj ne devas esti finiaj.Ekzemple, nelimigita intervalo estas senfina ripetilo:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Ofte oni uzas la [`take`]-iteratoran adaptilon por turni senfinan iteratoron en finian:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Ĉi tio presos la numerojn `0` ĝis `4`, ĉiu sur sia propra linio.
//!
//! Memoru, ke metodoj pri senfinaj ripetiloj, eĉ tiuj, por kiuj rezulto povas esti determinita matematike en finia tempo, eble ne finiĝas.
//! Specife, metodoj kiel [`min`], kiuj ĝenerale postulas trairi ĉiun elementon en la ripetilo, verŝajne ne revenos sukcese por iuj senfinaj ripetiloj.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Ho ne!Senfina buklo!
//! // `ones.min()` kaŭzas senfinan buklon, do ni ne atingos ĉi tiun punkton!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;