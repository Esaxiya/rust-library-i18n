use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Ĉi tiu trait provizas transiran aliron al fonto-scenejo en interator-adaptila dukto sub la kondiĉoj kiuj
/// * la iteracia fonto `S` mem efektivigas `SourceIter<Source = S>`
/// * ekzistas delega efektivigo de ĉi tiu trait por ĉiu adaptilo en la dukto inter la fonto kaj la dukto-konsumanto.
///
/// Kiam la fonto posedas ripetan strukturon (ofte nomatan `IntoIter`) tiam tio povas esti utila por specialigi [`FromIterator`]-efektivigojn aŭ rekuperi la ceterajn elementojn post kiam ripeto parte elĉerpiĝis.
///
///
/// Notu, ke efektivigoj ne nepre devas doni aliron al la plej interna fonto de dukto.Stata meza adaptilo eble fervore taksas parton de la dukto kaj elmontras ĝian internan stokadon kiel fonton.
///
/// trait estas nesekura ĉar efektivigantoj devas subteni pliajn sekurecajn propraĵojn.
/// Vidu [`as_inner`] por detaloj.
///
/// # Examples
///
/// Elŝuti parte konsumitan fonton:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Fonta stadio en ripeta dukto.
    type Source: Iterator;

    /// Rekuperu la fonton de ripeta dukto.
    ///
    /// # Safety
    ///
    /// Efektivigoj de devas redoni la saman ŝanĝeblan referencon dum sia vivo, krom se anstataŭitaj de alvokanto.
    /// Alvokantoj povas anstataŭigi la referencon nur kiam ili ĉesis ripeti kaj faligi la ripetan dukton post ĉerpi la fonton.
    ///
    /// Ĉi tio signifas, ke iteratoraj adaptiloj povas fidi, ke la fonto ne ŝanĝiĝas dum ripeto, sed ili ne povas fidi ĝin en siaj Drop-efektivigoj.
    ///
    /// Efektivigi ĉi tiun metodon signifas, ke adaptiloj rezignas nur pri privata aliro al sia fonto kaj povas fidi nur je garantioj faritaj surbaze de metodaj ricevilaj tipoj.
    /// La manko de limigita aliro ankaŭ postulas, ke adaptiloj devas subteni la publikan API de la fonto eĉ kiam ili havas aliron al ĝiaj internoj.
    ///
    /// Alvokantoj siavice devas atendi, ke la fonto estu en iu ajn stato kongrua kun sia publika API, ĉar adaptiloj sidantaj inter ĝi kaj la fonto havas la saman aliron.
    /// Precipe adaptilo eble konsumis pli da elementoj ol strikte necese.
    ///
    /// La ĝenerala celo de ĉi tiuj postuloj estas lasi la konsumanton de dukto uzi
    /// * ĉio, kio restas en la fonto post ripeto ĉesis
    /// * la memoro, kiu fariĝis neuzata antaŭenigante konsumantan ripetilon
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Ripetanto-adaptilo, kiu produktas produktaĵon kondiĉe ke la suba ripeto produktas `Result::Ok`-valorojn.
///
///
/// Se troviĝas eraro, la ripetilo haltas kaj la eraro estas konservita.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Prilaboru la donitan ripetilon kvazaŭ ĝi donus `T` anstataŭ `Result<T, _>`.
/// Iuj ajn eraroj haltigos la internan ripetilon kaj la ĝenerala rezulto estos eraro.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}