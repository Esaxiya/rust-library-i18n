Panics la nuna fadeno.

Ĉi tio permesas programon fini tuj kaj doni reagojn al la alvokanto de la programo.
`panic!` devas esti uzata kiam programo atingas nerevenigeblan staton.

Ĉi tiu makroo estas la perfekta maniero aserti kondiĉojn en ekzempla kodo kaj en testoj.
`panic!` estas proksime ligita kun la `unwrap`-metodo de ambaŭ [`Option`][ounwrap] kaj [`Result`][runwrap]-enumeroj.
Ambaŭ efektivigoj nomas `panic!` kiam ili estas agorditaj al [`None`] aŭ [`Err`]-variantoj.

Kiam vi uzas `panic!()`, vi povas specifi ĉenan utilan ŝarĝon, kiu estas kreita per la sintakso [`format!`].
Tiu utila ŝarĝo estas uzata kiam oni injektas la panic en la vokantan Rust-fadenon, kaŭzante la fadenon al panic tute.

La konduto de la apriora `std` hook, t.e.
la kodo, kiu funkcias rekte post la alvoko de panic, estas presi la mesaĝan utilan ŝarĝon al `stderr` kune kun la file/line/column-informoj de la `panic!()`-voko.

Vi povas anstataŭigi la panic hook per [`std::panic::set_hook()`].
En la hook oni povas aliri panic kiel `&dyn Any + Send`, kiu enhavas aŭ `&str` aŭ `String` por regulaj alvokoj de `panic!()`.
Al panic kun valoro de alia alia tipo, [`panic_any`] povas esti uzata.

[`Result`] enum ofte estas pli bona solvo por resaniĝi post eraroj ol uzi la `panic!`-makroon.
Ĉi tiu makroo estu uzata por eviti plu uzi malĝustajn valorojn, ekzemple de eksteraj fontoj.
Detalaj informoj pri erara pritraktado troviĝas en la [book].

Vidu ankaŭ la makroon [`compile_error!`], por levi erarojn dum kompilo.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Nuna efektivigo

Se la ĉefa fadeno panics ĝi finos ĉiujn viajn fadenojn kaj finos vian programon per kodo `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





