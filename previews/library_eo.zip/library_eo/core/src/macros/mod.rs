#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Vastiĝas al `$crate::panic::panic_2015` aŭ `$crate::panic::panic_2021` depende de la eldono de la alvokanto.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Asertas, ke du esprimoj egalas unu al la alia (uzante [`PartialEq`]).
///
/// Sur panic, ĉi tiu makro presos la valorojn de la esprimoj kun iliaj senararigaj prezentoj.
///
///
/// Kiel [`assert!`], ĉi tiu makro havas duan formon, kie laŭmenda panic-mesaĝo povas esti provizita.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // La subaj reboroj estas intencitaj.
                    // Sen ili, la staka fendo por pruntepreno estas pravalorizita eĉ antaŭ ol la valoroj estas komparitaj, kio kaŭzas rimarkindan malrapidiĝon.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // La subaj reboroj estas intencitaj.
                    // Sen ili, la staka fendo por pruntepreno estas pravalorizita eĉ antaŭ ol la valoroj estas komparitaj, kio kaŭzas rimarkindan malrapidiĝon.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Asertas, ke du esprimoj ne egalas unu al la alia (uzante [`PartialEq`]).
///
/// Sur panic, ĉi tiu makro presos la valorojn de la esprimoj kun iliaj senararigaj prezentoj.
///
///
/// Kiel [`assert!`], ĉi tiu makro havas duan formon, kie laŭmenda panic-mesaĝo povas esti provizita.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // La subaj reboroj estas intencitaj.
                    // Sen ili, la staka fendo por pruntepreno estas pravalorizita eĉ antaŭ ol la valoroj estas komparitaj, kio kaŭzas rimarkindan malrapidiĝon.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // La subaj reboroj estas intencitaj.
                    // Sen ili, la staka fendo por pruntepreno estas pravalorizita eĉ antaŭ ol la valoroj estas komparitaj, kio kaŭzas rimarkindan malrapidiĝon.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Asertas, ke bulea esprimo estas `true` dum rultempo.
///
/// Ĉi tio alvokos la [`panic!`]-makroon se la provizita esprimo ne povas esti taksita al `true` dum rultempo.
///
/// Kiel [`assert!`], ĉi tiu makro ankaŭ havas duan version, kie laŭmenda panic-mesaĝo povas esti provizita.
///
/// # Uses
///
/// Male al [`assert!`], `debug_assert!`-deklaroj estas nur ebligitaj en neoptimigitaj versioj defaŭlte.
/// Optimumigita konstruo ne plenumos `debug_assert!`-deklarojn krom se `-C debug-assertions` estos transdonita al la kompililo.
/// Ĉi tio igas `debug_assert!` utila por ĉekoj tro multekostaj por ĉeesti en versio, sed eble helpas dum disvolviĝo.
/// La rezulto de ekspansiiĝo de `debug_assert!` ĉiam estas tajpita.
///
/// Nekontrolita aserto permesas programon en malkonsekvenca stato plu funkcii, kio povus havi neatenditajn konsekvencojn sed ne enkondukas malsekurecon dum ĉi tio nur okazas en sekura kodo.
///
/// La agokosto de asertoj tamen ĝenerale ne estas mezurebla.
/// Anstataŭigi [`assert!`] per `debug_assert!` estas do kuraĝigita nur post profunda profilado, kaj pli grave, nur en sekura kodo!
///
/// # Examples
///
/// ```
/// // la panic-mesaĝo por ĉi tiuj asertoj estas la streĉita valoro de la donita esprimo.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // tre simpla funkcio
/// debug_assert!(some_expensive_computation());
///
/// // aserti per laŭmenda mesaĝo
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Asertas, ke du esprimoj egalas unu al la alia.
///
/// Sur panic, ĉi tiu makro presos la valorojn de la esprimoj kun iliaj senararigaj prezentoj.
///
/// Male al [`assert_eq!`], `debug_assert_eq!`-deklaroj estas nur ebligitaj en neoptimigitaj versioj defaŭlte.
/// Optimumigita konstruo ne plenumos `debug_assert_eq!`-deklarojn krom se `-C debug-assertions` estos transdonita al la kompililo.
/// Ĉi tio igas `debug_assert_eq!` utila por ĉekoj tro multekostaj por ĉeesti en versio, sed eble helpas dum disvolviĝo.
///
/// La rezulto de ekspansiiĝo de `debug_assert_eq!` ĉiam estas tajpita.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Asertas, ke du esprimoj ne egalas unu al la alia.
///
/// Sur panic, ĉi tiu makro presos la valorojn de la esprimoj kun iliaj senararigaj prezentoj.
///
/// Male al [`assert_ne!`], `debug_assert_ne!`-deklaroj estas nur ebligitaj en neoptimigitaj versioj defaŭlte.
/// Optimumigita konstruo ne plenumos `debug_assert_ne!`-deklarojn krom se `-C debug-assertions` estos transdonita al la kompililo.
/// Ĉi tio igas `debug_assert_ne!` utila por ĉekoj tro multekostaj por ĉeesti en versio, sed eble helpas dum disvolviĝo.
///
/// La rezulto de ekspansiiĝo de `debug_assert_ne!` ĉiam estas tajpita.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Liveras ĉu la donita esprimo kongruas kun iuj el la donitaj ŝablonoj.
///
/// Kiel en `match`-esprimo, la ŝablono povas esti laŭvole sekvita per `if` kaj gardista esprimo, kiu havas aliron al nomoj ligitaj per la ŝablono.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Malvolvas rezulton aŭ disvastigas ĝian eraron.
///
/// La `?`-operatoro estis aldonita por anstataŭigi `try!` kaj anstataŭe estu uzata.
/// Krome, `try` estas rezervita vorto en Rust 2018, do se vi devas uzi ĝin, vi devos uzi la [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` kongruas kun la donita [`Result`].En la kazo de la varianto `Ok`, la esprimo havas la valoron de la envolvita valoro.
///
/// En la kazo de la `Err`-varianto, ĝi retrovas la internan eraron.`try!` tiam plenumas konvertiĝon per `From`.
/// Ĉi tio provizas aŭtomatan konvertiĝon inter specialaj eraroj kaj pli ĝeneralaj.
/// La rezulta eraro tiam tuj estas redonita.
///
/// Pro la frua reveno, `try!` uzeblas nur en funkcioj, kiuj redonas [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // La preferata metodo por rapide redoni Erarojn
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // La antaŭa metodo de rapidaj revenantaj Eraroj
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Ĉi tio ekvivalentas al:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Verkas formatitajn datumojn en bufron.
///
/// Ĉi tiu makroo akceptas 'writer', formatan ĉenon kaj liston de argumentoj.
/// Argumentoj estos formatitaj laŭ la specifa formato-ĉeno kaj la rezulto estos transdonita al la verkisto.
/// La verkisto povas esti iu ajn valoro per `write_fmt`-metodo;ĝenerale ĉi tio venas de efektivigo de la [`fmt::Write`] aŭ de la [`io::Write`] trait.
/// La makroo redonas kion ajn la `write_fmt`-metodo redonas;kutime [`fmt::Result`], aŭ [`io::Result`].
///
/// Vidu [`std::fmt`] por pliaj informoj pri la sintaksa formato de ĉeno.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Modulo povas importi ambaŭ `std::fmt::Write` kaj `std::io::Write` kaj voki `write!` sur objektoj efektivigantaj ambaŭ, ĉar objektoj ne kutime efektivigas ambaŭ.
///
/// Tamen la modulo devas importi la kvalifikitan traits por ke iliaj nomoj ne konfliktu:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // uzas fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // uzas io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Ĉi tiu makroo povas esti uzata ankaŭ en `no_std`-aranĝoj.
/// En `no_std`-aranĝo vi respondecas pri la efektivigaj detaloj de la eroj.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Skribu formatitajn datumojn en bufron, kun nova linio aldonita.
///
/// Sur ĉiuj platformoj, la nova linio estas la LINE FEED-karaktero (`\n`/`U+000A`) sola (neniu aldona VENA REVENO (`\r`/`U+000D`).
///
/// Por pliaj informoj, vidu [`write!`].Por informoj pri la sintaksa formato de ĉeno, vidu [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Modulo povas importi ambaŭ `std::fmt::Write` kaj `std::io::Write` kaj voki `write!` sur objektoj efektivigantaj ambaŭ, ĉar objektoj ne kutime efektivigas ambaŭ.
/// Tamen la modulo devas importi la kvalifikitan traits por ke iliaj nomoj ne konfliktu:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // uzas fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // uzas io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Indikas neatingeblan kodon.
///
/// Ĉi tio utilas iam ajn, kiam la kompililo ne povas determini, ke iu kodo estas neatingebla.Ekzemple:
///
/// * Kunigu brakojn kun gardistaj kondiĉoj.
/// * Bukloj, kiuj dinamike finiĝas.
/// * Ripetoj, kiuj dinamike finiĝas.
///
/// Se la decido, ke la kodo estas neatingebla, montriĝas malĝusta, la programo tuj finiĝas per [`panic!`].
///
/// La nesekura ekvivalento de ĉi tiu makroo estas la funkcio [`unreachable_unchecked`], kiu kaŭzos nedifinitan konduton se la kodo estos atingita.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Ĉi tio ĉiam [`panic!`].
///
/// # Examples
///
/// Matĉobrakoj:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // kompili eraron se komentite
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // unu el la plej malbonaj efektivigoj de x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Indikas neefektivigitan kodon per paniko kun mesaĝo de "not implemented".
///
/// Ĉi tio permesas al via kodo tajpi-kontroli, kio estas utila se vi prototipas aŭ efektivigas trait, kiu postulas plurajn metodojn, kiujn vi ne planas uzi ĉiujn.
///
/// La diferenco inter `unimplemented!` kaj [`todo!`] estas, ke dum `todo!` transdonas intencon efektivigi la funkcion poste kaj la mesaĝo estas "not yet implemented", `unimplemented!` ne faras tiajn asertojn.
/// Ĝia mesaĝo estas "not implemented".
/// Ankaŭ iuj IDEoj markos `ĉio!` S.
///
/// # Panics
///
/// Ĉi tio ĉiam estos [`panic!`] ĉar `unimplemented!` estas nur stenografio por `panic!` kun fiksa specifa mesaĝo.
///
/// Kiel `panic!`, ĉi tiu makro havas duan formon por montri kutimajn valorojn.
///
/// # Examples
///
/// Diru, ke ni havas trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Ni volas efektivigi `Foo` por 'MyStruct', sed ial nur sencas efektivigi la funkcion `bar()`.
/// `baz()` kaj `qux()` ankoraŭ devos esti difinita en nia efektivigo de `Foo`, sed ni povas uzi `unimplemented!` en iliaj difinoj por permesi nian kodon kompili.
///
/// Ni ankoraŭ volas ĉesigi nian programon se la neefektivigitaj metodoj estas atingitaj.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Ĝi havas neniun sencon por `baz` a `MyStruct`, do ni tute ne havas logikon ĉi tie.
/////
///         // Ĉi tio montros "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Ni havas iom da logiko ĉi tie, Ni povas aldoni mesaĝon al neefektivigitaj!por montri nian preterlason.
///         // Ĉi tio montros: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Indikas nefinitan kodon.
///
/// Ĉi tio povas esti utila se vi prototipas kaj nur serĉas havi vian kodan tipekontrolon.
///
/// La diferenco inter [`unimplemented!`] kaj `todo!` estas, ke dum `todo!` transdonas intencon efektivigi la funkcion poste kaj la mesaĝo estas "not yet implemented", `unimplemented!` ne faras tiajn asertojn.
/// Ĝia mesaĝo estas "not implemented".
/// Ankaŭ iuj IDEoj markos `ĉio!` S.
///
/// # Panics
///
/// Ĉi tio ĉiam [`panic!`].
///
/// # Examples
///
/// Jen ekzemplo de iu progresanta kodo.Ni havas trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Ni volas efektivigi `Foo` sur unu el niaj specoj, sed ni ankaŭ volas labori pri nur `bar()` unue.Por kompili nian kodon, ni bezonas efektivigi `baz()`, do ni povas uzi `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // efektivigo iras ĉi tien
///     }
///
///     fn baz(&self) {
///         // ni ne zorgu pri efektivigo de baz() nuntempe
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ni eĉ ne uzas baz(), do estas bone.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Difinoj de enkonstruitaj makrooj.
///
/// Plej multaj makroaj ecoj (stabileco, videbleco ktp.) Estas prenitaj de la fontkodo ĉi tie, escepte de ekspansiaj funkcioj transformantaj makroajn enirojn en elirojn, tiujn funkciojn provizas la kompililo.
///
///
pub(crate) mod builtin {

    /// Kaŭzas malsukceson de kompilo kun la donita erarmesaĝo kiam oni renkontas ĝin.
    ///
    /// Ĉi tiu makroo estu uzata kiam crate uzas kondiĉan kompilan strategion por provizi pli bonajn erarmesaĝojn por eraraj kondiĉoj.
    ///
    /// Ĝi estas la kompilila nivelo de [`panic!`], sed elsendas eraron dum *kompilo* anstataŭ ĉe *rultempo*.
    ///
    /// # Examples
    ///
    /// Du tiaj ekzemploj estas makrooj kaj `#[cfg]`-medioj.
    ///
    /// Eligu pli bonan kompilan eraron se al makroo estas donitaj nevalidaj valoroj.
    /// Sen la fina branch, la kompililo ankoraŭ elsendus eraron, sed la mesaĝo de la eraro ne mencius la du validajn valorojn.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Eligu eraran kompililon se unu el kelkaj ecoj ne disponeblas.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Konstruas parametrojn por la aliaj ĉen-formataj makrooj.
    ///
    /// Ĉi tiu makroo funkcias prenante laŭvortan formatan ĉenon enhavantan `{}` por ĉiu plia argumento pasigita.
    /// `format_args!` preparas la aldonajn parametrojn por certigi, ke la eligo povas esti interpretata kiel ĉeno kaj kanonigas la argumentojn en unu tipon.
    /// Ĉiu valoro, kiu efektivigas la [`Display`] trait, povas esti transdonita al `format_args!`, same kiel iu ajn [`Debug`]-efektivigo povas esti transdonita al `{:?}` ene de la formato-ĉeno.
    ///
    ///
    /// Ĉi tiu makroo produktas valoron de tipo [`fmt::Arguments`].Ĉi tiu valoro povas esti transdonita al la makrooj ene de [`std::fmt`] por plenumi utilan alidirektadon.
    /// Ĉiuj aliaj formataj makrooj ([`formato!`], [`write!`], [`println!`], ktp) estas anstataŭigitaj per ĉi tiu.
    /// `format_args!`, male al ĝiaj derivitaj makrooj, evitas amasajn asignojn.
    ///
    /// Vi povas uzi la [`fmt::Arguments`]-valoron, kiun `format_args!` redonas en `Debug` kaj `Display`-kuntekstoj, kiel oni vidas sube.
    /// La ekzemplo ankaŭ montras, ke `Debug` kaj `Display` formatas al la sama afero: la interpolita formato-ĉeno en `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Por pliaj informoj, vidu la dokumentaron en [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Sama kiel `format_args`, sed aldonas novlinion finfine.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspektas median variablon dum kompila tempo.
    ///
    /// Ĉi tiu makroo pligrandiĝos al la valoro de la nomata ĉirkaŭa variablo dum kompila tempo, donante esprimon de tipo `&'static str`.
    ///
    ///
    /// Se la ĉirkaŭa variablo ne estas difinita, tiam kompila eraro estos elsendita.
    /// Por ne elsendi kompilan eraron, uzu anstataŭe la [`option_env!`]-makroon.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Vi povas agordi la erarmesaĝon pasante ĉenon kiel la duan parametron:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Se la ĉirkaŭa variablo `documentation` ne estas difinita, vi ricevos la jenan eraron:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Laŭvole inspektas median variablon dum kompila tempo.
    ///
    /// Se la nomita ĉirkaŭa variablo ĉeestas dum kompila tempo, ĉi tio disvolviĝos al esprimo de tipo `Option<&'static str>` kies valoro estas `Some` de la valoro de la ĉirkaŭa variablo.
    /// Se la ĉirkaŭa variablo ne ĉeestas, tiam ĉi tio pligrandiĝos al `None`.
    /// Vidu [`Option<T>`][Option] por pliaj informoj pri ĉi tiu tipo.
    ///
    /// Kompila temperaro neniam estas elsendita uzante ĉi tiun makroon sendepende de ĉu la ĉirkaŭa variablo ĉeestas aŭ ne.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Kunligas identigilojn en unu identigilon.
    ///
    /// Ĉi tiu makroo prenas ajnan nombron da kom-apartigitaj identigiloj, kaj kunligas ilin ĉiujn en unu, donante esprimon, kiu estas nova identigilo.
    /// Notu, ke higieno igas ĝin tia, ke ĉi tiu makroo ne povas kapti lokajn variablojn.
    /// Ankaŭ, kiel ĝenerala regulo, makrooj estas permesataj nur en ero, aserto aŭ esprimpozicio.
    /// Tio signifas, ke dum vi povas uzi ĉi tiun makroon por aludi al ekzistantaj variabloj, funkcioj aŭ moduloj ktp, vi ne povas difini novan per ĝi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (nova, amuza, nomo) { }//ne uzebla tiamaniere!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Interligas literojn en senmovan ĉentranĉon.
    ///
    /// Ĉi tiu makroo prenas iun ajn nombron de komaj apartaj literoj, donante esprimon de tipo `&'static str`, kiu reprezentas ĉiujn literojn kunligitajn maldekstre-dekstren.
    ///
    ///
    /// Entjeraj kaj glitkomaj literoj estas kordigitaj por esti kunligitaj.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Vastiĝas al la linia numero, sur kiu ĝi estis alvokita.
    ///
    /// Kun [`column!`] kaj [`file!`], ĉi tiuj makrooj provizas senararigajn informojn por programistoj pri la loko ene de la fonto.
    ///
    /// La vastigita esprimo havas tipon `u32` kaj estas 1-bazita, do la unua linio en ĉiu dosiero taksas 1, la dua al 2, ktp.
    /// Ĉi tio kongruas kun erarmesaĝoj de oftaj kompililoj aŭ popularaj redaktantoj.
    /// La revenita linio estas *ne nepre* la linio de la `line!`-alvoko mem, sed prefere la unua makro-alvoko kondukanta al la alvoko de la `line!`-makro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Vastiĝas al la kolumna numero, ĉe kiu ĝi estis alvokita.
    ///
    /// Kun [`line!`] kaj [`file!`], ĉi tiuj makrooj provizas senararigajn informojn por programistoj pri la loko ene de la fonto.
    ///
    /// La vastigita esprimo havas tipon `u32` kaj estas 1-bazita, do la unua kolumno en ĉiu linio taksas 1, la dua al 2, ktp.
    /// Ĉi tio kongruas kun erarmesaĝoj de oftaj kompililoj aŭ popularaj redaktantoj.
    /// La revenita kolumno estas *ne nepre* la linio de la `column!`-alvoko mem, sed prefere la unua makro-alvoko kondukanta al la alvoko de la `column!`-makro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Vastiĝas al la dosiernomo, en kiu ĝi estis alvokita.
    ///
    /// Kun [`line!`] kaj [`column!`], ĉi tiuj makrooj provizas senararigajn informojn por programistoj pri la loko ene de la fonto.
    ///
    /// La pligrandigita esprimo havas tipon `&'static str`, kaj la revenita dosiero ne estas la alvoko de la `file!`-makroo mem, sed prefere la unua makroa alvoko kondukanta al la alvoko de la `file!`-makroo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringigas siajn argumentojn.
    ///
    /// Ĉi tiu makroo donos esprimon de tipo `&'static str`, kiu estas la kordigo de ĉiuj tokens transdonitaj al la makroo.
    /// Neniuj limigoj estas metitaj al la sintakso de la makro-alvoko mem.
    ///
    /// Notu, ke la pligrandigitaj rezultoj de la eniga tokens povas ŝanĝiĝi en la future.Vi devas zorgi, se vi dependas de la eligo.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Inkludas koditan dosieron UTF-8 kiel ĉeno.
    ///
    /// La dosiero troviĝas relative al la nuna dosiero (simile al kiel moduloj troviĝas).
    /// La provizita vojo estas interpretita laŭ platforma specifa maniero dum kompila tempo.
    /// Do, ekzemple, alvoko kun Windows-vojo enhavanta malantaŭajn oblikvojn `\` ne kompiliĝus ĝuste ĉe Unix.
    ///
    ///
    /// Ĉi tiu makroo donas esprimon de tipo `&'static str`, kiu estas la enhavo de la dosiero.
    ///
    /// # Examples
    ///
    /// Supozu, ke estas du dosieroj en la sama dosierujo kun la sekva enhavo:
    ///
    /// Dosiero 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Dosiero 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Kompili 'main.rs' kaj plenumi la rezultan duumaĵon presos "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inkludas dosieron kiel referencon al bajta tabelo.
    ///
    /// La dosiero troviĝas relative al la nuna dosiero (simile al kiel moduloj troviĝas).
    /// La provizita vojo estas interpretita laŭ platforma specifa maniero dum kompila tempo.
    /// Do, ekzemple, alvoko kun Windows-vojo enhavanta malantaŭajn oblikvojn `\` ne kompiliĝus ĝuste ĉe Unix.
    ///
    ///
    /// Ĉi tiu makroo donos esprimon de tipo `&'static [u8; N]`, kiu estas la enhavo de la dosiero.
    ///
    /// # Examples
    ///
    /// Supozu, ke estas du dosieroj en la sama dosierujo kun la sekva enhavo:
    ///
    /// Dosiero 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Dosiero 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Kompili 'main.rs' kaj plenumi la rezultan duumaĵon presos "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Vastiĝas al ĉeno, kiu reprezentas la nunan modulan vojon.
    ///
    /// La nuna modula vojo povas esti opiniita kiel la hierarkio de moduloj gvidantaj reen al la crate root.
    /// La unua ero de la resendita vojo estas la nomo de la crate nuntempe kompilita.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Taksas buleajn kombinaĵojn de agordaj flagoj dum kompila tempo.
    ///
    /// Aldone al la `#[cfg]`-atributo, ĉi tiu makroo estas provizita por permesi bulean esprimon pritaksi agordajn flagojn.
    /// Ĉi tio ofte kondukas al malpli duobligita kodo.
    ///
    /// La sintakso donita al ĉi tiu makroo estas la sama sintakso kiel la atributo [`cfg`].
    ///
    /// `cfg!`, male al `#[cfg]`, ne forigas iun kodon kaj nur taksas veran aŭ falsan.
    /// Ekzemple, ĉiuj blokoj en if/else-esprimo devas esti validaj kiam `cfg!` estas uzata por la kondiĉo, sendepende de tio, kion `cfg!` taksas.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analizas dosieron kiel esprimon aŭ eron laŭ la kunteksto.
    ///
    /// La dosiero troviĝas relative al la nuna dosiero (simile al kiel moduloj troviĝas).La provizita vojo estas interpretita laŭ platforma specifa maniero dum kompila tempo.
    /// Do, ekzemple, alvoko kun Windows-vojo enhavanta malantaŭajn oblikvojn `\` ne kompiliĝus ĝuste ĉe Unix.
    ///
    /// Uzi ĉi tiun makroon ofte estas malbona ideo, ĉar se la dosiero estas analizita kiel esprimo, ĝi estos metita en la ĉirkaŭa kodo senhigene.
    /// Ĉi tio povus rezultigi variablojn aŭ funkciojn malsamajn al tio, kion atendis la dosiero, se estas variabloj aŭ funkcioj kun la sama nomo en la aktuala dosiero.
    ///
    ///
    /// # Examples
    ///
    /// Supozu, ke estas du dosieroj en la sama dosierujo kun la sekva enhavo:
    ///
    /// Dosiero 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Dosiero 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Kompili 'main.rs' kaj plenumi la rezultan duumaĵon presos "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Asertas, ke bulea esprimo estas `true` dum rultempo.
    ///
    /// Ĉi tio alvokos la [`panic!`]-makroon se la provizita esprimo ne povas esti taksita al `true` dum rultempo.
    ///
    /// # Uses
    ///
    /// Asertoj ĉiam estas kontrolitaj en kaj elpurigaj kaj liberigaj versioj, kaj ne povas esti malebligitaj.
    /// Vidu [`debug_assert!`] por asertoj, kiuj ne estas ebligitaj en eldonaj versioj defaŭlte.
    ///
    /// Nesekura kodo povas dependi de `assert!` por plenumi rultempajn invariantojn, kiuj se malobservitaj povus konduki al nesekureco
    ///
    /// Aliaj uzokazoj de `assert!` inkluzivas testadon kaj devigon de rultempaj invariantoj en sekura kodo (kies malobservo ne povas rezultigi nesekurecon).
    ///
    ///
    /// # Propraj Mesaĝoj
    ///
    /// Ĉi tiu makro havas duan formon, kie laŭmenda panic-mesaĝo povas esti provizita kun aŭ sen argumentoj por formatado.
    /// Vidu [`std::fmt`] por sintakso por ĉi tiu formo.
    /// Esprimoj uzataj kiel formataj argumentoj estos taksataj nur se la aserto malsukcesas.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // la panic-mesaĝo por ĉi tiuj asertoj estas la streĉita valoro de la donita esprimo.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // tre simpla funkcio
    ///
    /// assert!(some_computation());
    ///
    /// // aserti per laŭmenda mesaĝo
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Enreta aro.
    ///
    /// Legu la [unstable book] por la uzado.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-stila enlinia aro.
    ///
    /// Legu la [unstable book] por la uzado.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Modula nivelo enlinia aro.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Presaĵoj transdonis tokens al la norma eligo.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Ebligas aŭ malebligas spurfunkcion uzitan por senararigi aliajn makroojn.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Atributa makroo uzata por apliki derivajn makroojn.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Atributa makroo aplikita al funkcio por igi ĝin en unuoteston.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Atributa makroo aplikita al funkcio por igi ĝin en referencan teston.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Efektiviga detalo de la `#[test]` kaj `#[bench]`-makrooj.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Atributa makroo aplikita al statika por registri ĝin kiel tutmondan asignilon.
    ///
    /// Vidu ankaŭ [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Konservas la eron, al kiu ĝi estas aplikita, se la pasita vojo estas alirebla, kaj forigas ĝin alimaniere.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Vastigas ĉiujn `#[cfg]` kaj `#[cfg_attr]`-atributojn en la koda fragmento al kiu ĝi aplikiĝas.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Malstabila efektiviga detalo de la `rustc`-kompililo, ne uzu.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Malstabila efektiviga detalo de la `rustc`-kompililo, ne uzu.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}