//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// La plej alta valida kodpunkto, kiun `char` povas havi.
    ///
    /// `char` estas [Unicode Scalar Value], kio signifas, ke ĝi estas [Code Point], sed nur ene de certa rango.
    /// `MAX` estas la plej alta valida kodpunkto, kiu estas valida [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () estas uzata en Unikodo por reprezenti malkodan eraron.
    ///
    /// Ĝi povas okazi, ekzemple, donante misformitajn UTF-8-bitokojn al [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// La versio de [Unicode](http://www.unicode.org/) sur kiu baziĝas la unikodaj partoj de metodoj `char` kaj `str`.
    ///
    /// Novaj versioj de Unikodo estas publikigitaj regule kaj poste ĉiuj metodoj en la norma biblioteko depende de Unikodo estas ĝisdatigitaj.
    /// Tial la konduto de iuj `char` kaj `str`-metodoj kaj la valoro de ĉi tiu konstanto ŝanĝiĝas laŭlonge de la tempo.
    /// Ĉi tio estas *ne* konsiderata kiel rompiĝanta ŝanĝo.
    ///
    /// La versia numera skemo estas klarigita en [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Kreas ripeton super la koditaj kodpunktoj UTF-16 en `iter`, redonante neparajn surogatojn kiel `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Perda malĉifrilo povas esti akirita anstataŭigante `Err`-rezultojn per la anstataŭiga signo:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Konvertas `u32` al `char`.
    ///
    /// Notu, ke ĉiuj `char` estas validaj [`u32`]-oj, kaj povas esti gisitaj al unu kun
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Tamen la inverso ne veras: ne ĉiuj validaj [`u32`]-oj validas`char`s.
    /// `from_u32()` redonos `None` se la enigo ne estas valida valoro por `char`.
    ///
    /// Por nesekura versio de ĉi tiu funkcio, kiu ignoras ĉi tiujn kontrolojn, vidu [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Revenante `None` kiam la eniro ne estas valida `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Konvertas `u32` al `char`, ignorante validecon.
    ///
    /// Notu, ke ĉiuj `char` estas validaj [`u32`]-oj, kaj povas esti gisitaj al unu kun
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Tamen la inverso ne veras: ne ĉiuj validaj [`u32`]-oj validas`char`s.
    /// `from_u32_unchecked()` ignoros ĉi tion, kaj blinde ĵetos al `char`, eble kreos malvalidan.
    ///
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio estas nesekura, ĉar ĝi povas konstrui malvalidajn `char`-valorojn.
    ///
    /// Por sekura versio de ĉi tiu funkcio, vidu la funkcion [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SEKURECO: la sekureca kontrakto devas esti konfirmita de la alvokanto.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Konvertas ciferon en la donita radikso al `char`.
    ///
    /// Ĉi tie 'radix' foje estas ankaŭ nomata 'base'.
    /// Radikso de du indikas duuman nombron, radikon de dek, dekuma, kaj radikson de dek ses, deksesuma, por doni iujn komunajn valorojn.
    ///
    /// Arbitraj radioj estas subtenataj.
    ///
    /// `from_digit()` redonos `None` se la eniro ne estas cifero en la donita radikso.
    ///
    /// # Panics
    ///
    /// Panics se donita radikso pli granda ol 36.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Decimala 11 estas unu cifero en bazo 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Revenante `None` kiam la enigo ne estas cifero:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Pasante grandan radikson, kaŭzante panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Kontrolas ĉu `char` estas cifero en la donita radikso.
    ///
    /// Ĉi tie 'radix' foje estas ankaŭ nomata 'base'.
    /// Radikso de du indikas duuman nombron, radikon de dek, dekuma, kaj radikson de dek ses, deksesuma, por doni iujn komunajn valorojn.
    ///
    /// Arbitraj radioj estas subtenataj.
    ///
    /// Kompare kun [`is_numeric()`], ĉi tiu funkcio nur rekonas la signojn `0-9`, `a-z` kaj `A-Z`.
    ///
    /// 'Digit' estas difinita kiel nur la jenaj signoj:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Por pli ampleksa kompreno de 'digit', vidu [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics se donita radikso pli granda ol 36.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Pasante grandan radikson, kaŭzante panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Konvertas `char` al cifero en la donita radikso.
    ///
    /// Ĉi tie 'radix' foje estas ankaŭ nomata 'base'.
    /// Radikso de du indikas duuman nombron, radikon de dek, dekuma, kaj radikson de dek ses, deksesuma, por doni iujn komunajn valorojn.
    ///
    /// Arbitraj radioj estas subtenataj.
    ///
    /// 'Digit' estas difinita kiel nur la jenaj signoj:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Liveras `None` se `char` ne rilatas al cifero en la donita radikso.
    ///
    /// # Panics
    ///
    /// Panics se donita radikso pli granda ol 36.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Pasi neniferan rezulton en fiasko:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Pasante grandan radikson, kaŭzante panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // la kodo estas disigita ĉi tie por plibonigi ekzekutan rapidon por kazoj kie la `radix` estas konstanta kaj 10 aŭ pli malgranda
        //
        let val = if likely(radix <= 10) {
            // Se ne cifero, nombro pli granda ol radix kreiĝos.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Liveras ripeton, kiu donas la deksesuman Unikodan eskapon de rolulo kiel `char`s.
    ///
    /// Ĉi tio evitos signojn kun la sintakso Rust de la formo `\u{NNNNNN}` kie `NNNNNN` estas deksesuma reprezento.
    ///
    ///
    /// # Examples
    ///
    /// Kiel ripeto:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uzi `println!` rekte:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Ambaŭ samvaloras al:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Uzante `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // aŭ-ing 1 certigas, ke por c==0 la kodo kalkulas, ke unu cifero estu presita kaj (kio samas) evitas la (31, 32) subfluon
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // la indekso de la plej signifa deksesuma cifero
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Plilongigita versio de `escape_debug`, kiu laŭvole rajtas eskapi kodpunktojn de Etendaj Grafemoj.
    /// Ĉi tio permesas al ni pli bone formi signojn kiel senspacaj signoj kiam ili estas ĉe la komenco de ĉeno.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Liveras ripeton, kiu donas la laŭvortan eskapan kodon de rolulo kiel `char`s.
    ///
    /// Ĉi tio eskapos de la similaj signoj al la efektivigoj de `Debug` de `str` aŭ `char`.
    ///
    ///
    /// # Examples
    ///
    /// Kiel ripeto:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uzi `println!` rekte:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Ambaŭ samvaloras al:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Uzante `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Liveras ripeton, kiu donas la laŭvortan eskapan kodon de rolulo kiel `char`s.
    ///
    /// La defaŭlta estas elektita kun antaŭjuĝo al produktado de laŭvortoj laŭleĝaj en diversaj lingvoj, inkluzive de C++ 11 kaj similaj lingvoj de C-familio.
    /// La ĝustaj reguloj estas:
    ///
    /// * Tab estas eskapita kiel `\t`.
    /// * Reveno de kaleŝo eskapas kiel `\r`.
    /// * Linifluo eskapas kiel `\n`.
    /// * Ununura citaĵo eskapas kiel `\'`.
    /// * Duobla citaĵo eskapas kiel `\"`.
    /// * Backslash eskapas kiel `\\`.
    /// * Iu ajn signo en la 'presinda ASCII' gamo `0x20` .. `0x7e` inkluziva ne eskapas.
    /// * Ĉiuj aliaj signoj ricevas deksesumajn Unikodajn fuĝojn;vidu [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Kiel ripeto:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uzi `println!` rekte:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Ambaŭ samvaloras al:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Uzante `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Liveras la nombron da bajtoj, kiujn ĉi tiu `char` bezonus se kodita en UTF-8.
    ///
    /// Tiu nombro da bajtoj ĉiam estas inter 1 kaj 4, inkluzive.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// La `&str`-speco garantias, ke ĝia enhavo estas UTF-8, do ni povas kompari la longon, kiun ĝi prenus, se ĉiu kodpunkto estus reprezentita kiel `char` vs en la `&str` mem:
    ///
    ///
    /// ```
    /// // kiel signoj
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ambaŭ povas esti reprezentataj kiel tri bajtoj
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // kiel &str, ĉi tiuj du estas koditaj en UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // ni povas vidi, ke ili prenas ses bajtojn entute ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... same kiel la &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Liveras la nombron de 16-bitaj kodunuoj, kiujn ĉi tiu `char` bezonus se kodita en UTF-16.
    ///
    ///
    /// Vidu la dokumentaron por [`len_utf8()`] por pli da klarigo pri ĉi tiu koncepto.
    /// Ĉi tiu funkcio estas spegulo, sed por UTF-16 anstataŭ UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Ĉifras ĉi tiun signon kiel UTF-8 en la provizitan bajtan bufron, kaj poste redonas la subtranĉon de la bufro, kiu enhavas la koditan signon.
    ///
    ///
    /// # Panics
    ///
    /// Panics se la bufro ne estas sufiĉe granda.
    /// Bufro de longo kvar estas sufiĉe granda por ĉifri ajnan `char`.
    ///
    /// # Examples
    ///
    /// En ambaŭ ĉi tiuj ekzemploj, 'ß' bezonas du bajtojn por kodi.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Bufro tro malgranda:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SEKURECO: `char` ne estas anstataŭanto, do ĉi tio validas UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Ĉifras ĉi tiun signon kiel UTF-16 en la provizitan `u16`-bufron, kaj tiam redonas la subtranĉon de la bufro, kiu enhavas la koditan signon.
    ///
    ///
    /// # Panics
    ///
    /// Panics se la bufro ne estas sufiĉe granda.
    /// Bufro de longo 2 estas sufiĉe granda por ĉifri ajnan `char`.
    ///
    /// # Examples
    ///
    /// En ambaŭ ĉi tiuj ekzemploj, '𝕊' bezonas du `u16` por kodi.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Bufro tro malgranda:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Liveras `true` se ĉi tiu `char` havas la propraĵon `Alphabetic`.
    ///
    /// `Alphabetic` estas priskribita en Ĉapitro 4 (Karakterizaĵoj) de la [Unicode Standard] kaj specifita en la [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // amo estas multaj aferoj, sed ĝi ne estas alfabeta
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Liveras `true` se ĉi tiu `char` havas la propraĵon `Lowercase`.
    ///
    /// `Lowercase` estas priskribita en Ĉapitro 4 (Karakterizaĵoj) de la [Unicode Standard] kaj specifita en la [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // La diversaj ĉinaj skriboj kaj interpunkcio ne havas majusklojn, kaj tiel:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Liveras `true` se ĉi tiu `char` havas la propraĵon `Uppercase`.
    ///
    /// `Uppercase` estas priskribita en Ĉapitro 4 (Karakterizaĵoj) de la [Unicode Standard] kaj specifita en la [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // La diversaj ĉinaj skriboj kaj interpunkcio ne havas majusklojn, kaj tiel:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Liveras `true` se ĉi tiu `char` havas la propraĵon `White_Space`.
    ///
    /// `White_Space` estas specifita en la [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // nerompebla spaco
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Liveras `true` se ĉi tiu `char` kontentigas aŭ [`is_alphabetic()`] aŭ [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Liveras `true` se ĉi tiu `char` havas la ĝeneralan kategorion por regokodoj.
    ///
    /// Kontrolaj kodoj (kodaj punktoj kun la ĝenerala kategorio de `Cc`) estas priskribitaj en Ĉapitro 4 (Karakteraj Ecoj) de [Unicode Standard] kaj specifitaj en [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // U + 009C, KORDA TERMINATORO
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Liveras `true` se ĉi tiu `char` havas la propraĵon `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` estas priskribita en [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] kaj specifita en la [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Liveras `true` se ĉi tiu `char` havas unu el la ĝeneralaj kategorioj por nombroj.
    ///
    /// La ĝeneralaj kategorioj por nombroj (`Nd` por decimalaj ciferoj, `Nl` por liter-similaj numeraj signoj, kaj `No` por aliaj nombraj signoj) estas specifitaj en la [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Liveras ripeton, kiu donas la minusklan mapadon de ĉi tiu `char` kiel unu aŭ pli
    /// `char`s.
    ///
    /// Se ĉi tiu `char` ne havas minusklan mapadon, la ripetilo donas la saman `char`.
    ///
    /// Se ĉi tiu `char` havas unu-al-unu minusklan mapadon donitan de la [Unicode Character Database][ucd] [`UnicodeData.txt`], la ripetilo donas tiun `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Se ĉi tiu `char` postulas specialajn konsiderojn (ekz. Multoblaj `char`s) la ripetilo donas la`char` (s) donitajn de [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ĉi tiu operacio plenumas senkondiĉan mapadon sen tajlorado.Tio estas, la konvertiĝo estas sendependa de kunteksto kaj lingvo.
    ///
    /// En la [Unicode Standard], Ĉapitro 4 (Karakterizaĵoj) diskutas kazmapadon ĝenerale kaj Ĉapitro 3 (Conformance) diskutas la defaŭltan algoritmon por kazkonverto.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kiel ripeto:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uzi `println!` rekte:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Ambaŭ samvaloras al:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Uzante `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Foje la rezulto estas pli ol unu signo:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Signoj, kiuj ne havas majusklojn kaj minusklojn, konvertiĝas en si mem.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Liveras ripeton, kiu donas la majusklan mapadon de ĉi tiu `char` kiel unu aŭ pli
    /// `char`s.
    ///
    /// Se ĉi tiu `char` ne havas majusklan mapadon, la ripetilo donas la saman `char`.
    ///
    /// Se ĉi tiu `char` havas unu-al-unu majusklan mapadon donitan de la [Unicode Character Database][ucd] [`UnicodeData.txt`], la ripeto donas tiun `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Se ĉi tiu `char` postulas specialajn konsiderojn (ekz. Multoblaj `char`s) la ripetilo donas la`char` (s) donitajn de [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ĉi tiu operacio plenumas senkondiĉan mapadon sen tajlorado.Tio estas, la konvertiĝo estas sendependa de kunteksto kaj lingvo.
    ///
    /// En la [Unicode Standard], Ĉapitro 4 (Karakterizaĵoj) diskutas kazmapadon ĝenerale kaj Ĉapitro 3 (Conformance) diskutas la defaŭltan algoritmon por kazkonverto.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kiel ripeto:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uzi `println!` rekte:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Ambaŭ samvaloras al:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Uzante `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Foje la rezulto estas pli ol unu signo:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Signoj, kiuj ne havas majusklojn kaj minusklojn, konvertiĝas en si mem.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Noto pri lokaĵaro
    ///
    /// En la turka, la ekvivalento de 'i' en la latina havas kvin formojn anstataŭ du:
    ///
    /// * 'Dotless': I/ı, foje skribita ï
    /// * 'Dotted': İ/i
    ///
    /// Notu, ke la minuskla punktita 'i' samas al la latina.Sekve:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// La valoro de `upper_i` ĉi tie dependas de la lingvo de la teksto: se ni estas en `en-US`, ĝi devus esti `"I"`, sed se ni estas en `tr_TR`, ĝi devas esti `"İ"`.
    /// `to_uppercase()` ne konsideras ĉi tion, kaj do:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// tenas trans lingvoj.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Kontrolas ĉu la valoro estas ene de la ASCII-intervalo.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Faras kopion de la valoro en ĝia ASCII-majuskla ekvivalento.
    ///
    /// Askiaj literoj 'a' al 'z' estas mapitaj al 'A' al 'Z', sed ne-ASCII-literoj estas senŝanĝaj.
    ///
    /// Por majuskli la lokan valoron, uzu [`make_ascii_uppercase()`].
    ///
    /// Por majuskligi ASCII-signojn krom ne-ASCII-signoj, uzu [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Faras kopion de la valoro en sia ASCII minuskla ekvivalento.
    ///
    /// Askiaj literoj 'A' al 'Z' estas mapitaj al 'a' al 'z', sed ne-ASCII-literoj estas senŝanĝaj.
    ///
    /// Por minuskli la lokan valoron, uzu [`make_ascii_lowercase()`].
    ///
    /// Por minuskli ASCII-signojn krom ne-ASCII-signoj, uzu [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Kontrolas, ke du valoroj estas ASCII-usklecema matĉo.
    ///
    /// Ekvivalenta al `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Konvertas ĉi tiun tipon al sia ASCII-majuskla ekvivalento modloko.
    ///
    /// Askiaj literoj 'a' al 'z' estas mapitaj al 'A' al 'Z', sed ne-ASCII-literoj estas senŝanĝaj.
    ///
    /// Por redoni novan majusklan valoron sen modifi la ekzistantan, uzu [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Konvertas ĉi tiun tipon al sia ASCII minuskla ekvivalento modloko.
    ///
    /// Askiaj literoj 'A' al 'Z' estas mapitaj al 'a' al 'z', sed ne-ASCII-literoj estas senŝanĝaj.
    ///
    /// Por redoni novan minusklan valoron sen modifi la ekzistantan, uzu [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Kontrolas ĉu la valoro estas ASCII alfabeta signo:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', aŭ
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Kontrolas ĉu la valoro estas ASCII majuskla signo:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Kontrolas ĉu la valoro estas ASCII minuskla signo:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Kontrolas ĉu la valoro estas ASCII-alfanombra signo:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', aŭ
    /// - U + 0061 'a' ..=U + 007A 'z', aŭ
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Kontrolas ĉu la valoro estas dekuma cifero ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Kontrolas ĉu la valoro estas ASCII deksesuma cifero:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', aŭ
    /// - U + 0041 'A' ..=U + 0046 'F', aŭ
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Kontrolas ĉu la valoro estas ASCII-interpunkcia signo:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, aŭ
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, aŭ
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, aŭ
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Kontrolas ĉu la valoro estas grafika signo ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Kontrolas ĉu la valoro estas ASCII-blanka signo:
    /// U + 0020 SPACO, U + 0009 HORIZONTALA TABO, U + 000A LINIO-PLEJO, U + 000C FORM-PLEJO, aŭ U + 000D-VENA REVENO.
    ///
    /// Rust uzas [definition of ASCII whitespace][infra-aw] de WhatWG Infra Standard.Estas pluraj aliaj difinoj vaste uzataj.
    /// Ekzemple, [the POSIX locale][pct] inkluzivas U + 000B VERTICAL TAB same kiel ĉiujn suprajn signojn, sed - laŭ la sama specifo- [la defaŭlta regulo por "field splitting" en la Bourne shell][bfs] konsideras *nur* SPACON, HORIZONTAN TAB, kaj LINA FEED kiel blanka spaco.
    ///
    ///
    /// Se vi verkas programon, kiu prilaboros ekzistantan dosierformaton, kontrolu kia estas la difino de tiu formato de blanka spaco antaŭ ol uzi ĉi tiun funkcion.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Kontrolas ĉu la valoro estas regila signo ASCII:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, aŭ U + 007F DELETE.
    /// Notu, ke plej multaj ASCII-spacoj estas kontrolaj signoj, sed SPACO ne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Ĉifras krudan u32-valoron kiel UTF-8 en la provizitan bajtan bufron, kaj tiam redonas la subtranĉon de la bufro, kiu enhavas la koditan signon.
///
///
/// Male al `char::encode_utf8`, ĉi tiu metodo ankaŭ traktas kodpunktojn en la anstataŭa gamo.
/// (Krei `char` en la anstataŭa gamo estas UB.) La rezulto validas [generalized UTF-8] sed ne validas UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics se la bufro ne estas sufiĉe granda.
/// Bufro de longo kvar estas sufiĉe granda por ĉifri ajnan `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Ĉifras krudan u32-valoron kiel UTF-16 en la provizitan `u16`-bufron, kaj tiam redonas la subtranĉon de la bufro, kiu enhavas la koditan signon.
///
///
/// Male al `char::encode_utf16`, ĉi tiu metodo ankaŭ traktas kodpunktojn en la anstataŭa gamo.
/// (Krei `char` en la anstataŭa gamo estas UB.)
///
/// # Panics
///
/// Panics se la bufro ne estas sufiĉe granda.
/// Bufro de longo 2 estas sufiĉe granda por ĉifri ajnan `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SEKURECO: ĉiu brako kontrolas ĉu estas sufiĉe da bitoj por skribi
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // La BMP trapasas
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Suplementaj aviadiloj rompiĝas en anstataŭantoj.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}