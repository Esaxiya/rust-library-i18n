//! Karakteraj konvertiĝoj.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Konvertas `u32` al `char`.
///
/// Notu, ke ĉiuj [`char`] validas [`u32`] s, kaj povas esti gisitaj al unu kun
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Tamen la inverso ne veras: ne ĉiuj validaj [`u32`]-oj validas [`char`]-oj.
/// `from_u32()` redonos `None` se la enigo ne estas valida valoro por [`char`].
///
/// Por nesekura versio de ĉi tiu funkcio, kiu ignoras ĉi tiujn kontrolojn, vidu [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Revenante `None` kiam la eniro ne estas valida [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Konvertas `u32` al `char`, ignorante validecon.
///
/// Notu, ke ĉiuj [`char`] validas [`u32`] s, kaj povas esti gisitaj al unu kun
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Tamen la inverso ne veras: ne ĉiuj validaj [`u32`]-oj validas [`char`]-oj.
/// `from_u32_unchecked()` ignoros ĉi tion, kaj blinde ĵetos al [`char`], eble kreos malvalidan.
///
///
/// # Safety
///
/// Ĉi tiu funkcio estas nesekura, ĉar ĝi povas konstrui malvalidajn `char`-valorojn.
///
/// Por sekura versio de ĉi tiu funkcio, vidu la funkcion [`from_u32`].
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SEKURECO: la alvokanto devas garantii, ke `i` estas valida signa valoro.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Konvertas [`char`] en [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Konvertas [`char`] en [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // La signo estas gisita al la valoro de la kodpunkto, tiam nul-etendita ĝis 64 bitoj.
        // Vidu [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Konvertas [`char`] en [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // La signo estas gisita al la valoro de la kodpunkto, tiam nul-etendita ĝis 128 bitoj.
        // Vidu [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Mapas bajton en 0x00 ..=0xFF al `char` kies kodpunkto havas la saman valoron, en U + 0000 ..=U + 00FF.
///
/// Unikodo estas desegnita tiel, ke ĉi tio efike deĉifras bajtojn per la signokodado, kiun IANA nomas ISO-8859-1.
/// Ĉi tiu kodigado kongruas kun Askio.
///
/// Notu, ke ĉi tio diferencas de ISO/IEC 8859-1 alinome
/// ISO 8859-1 (kun unu malpli streketo), kiu lasas iujn "blanks", bajtajn valorojn, kiuj ne estas atribuitaj al iu ajn signo.
/// ISO-8859-1 (la IANA) atribuas ilin al la kontrolaj kodoj C0 kaj C1.
///
/// Rimarku, ke ĉi tio *ankaŭ* diferencas de Windows-1252 alinome
/// kodpaĝo 1252, kiu estas superaro ISO/IEC 8859-1, kiu atribuas iujn (ne ĉiujn!) malplenojn al interpunkcio kaj diversaj latinaj signoj.
///
/// Por plue konfuzi aferojn, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` kaj `windows-1252` estas ĉiuj kaŝnomoj por superaro de Vindozo-1252, kiu plenigas la ceterajn malplenojn kun respondaj C0 kaj C1-kontrolaj kodoj.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Konvertas [`u8`] en [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Eraro redonebla dum analizado de signo.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SEKURECO: kontrolis, ke ĝi estas laŭleĝa unikoda valoro
            Ok(unsafe { transmute(i) })
        }
    }
}

/// La erara tipo revenis kiam fiasko de konvertiĝo de u32 al signo.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Konvertas ciferon en la donita radikso al `char`.
///
/// Ĉi tie 'radix' foje estas ankaŭ nomata 'base'.
/// Radikso de du indikas duuman nombron, radikon de dek, dekuma, kaj radikson de dek ses, deksesuma, por doni iujn komunajn valorojn.
///
/// Arbitraj radioj estas subtenataj.
///
/// `from_digit()` redonos `None` se la eniro ne estas cifero en la donita radikso.
///
/// # Panics
///
/// Panics se donita radikso pli granda ol 36.
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Decimala 11 estas unu cifero en bazo 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Revenante `None` kiam la enigo ne estas cifero:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Pasante grandan radikson, kaŭzante panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}