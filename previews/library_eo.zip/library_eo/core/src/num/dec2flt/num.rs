//! Utilaj funkcioj por bignumoj, kiuj ne havas tro da senco transformiĝi en metodojn.

// FIXME La nomo de ĉi tiu modulo estas iom bedaŭrinda, ĉar aliaj moduloj ankaŭ importas `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Provu ĉu detranĉi ĉiujn bitojn malpli signifajn ol `ones_place` enkondukas relativan eraron malpli, egalan aŭ pli grandan ol 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Se ĉiuj ceteraj bitoj estas nulaj, ĝi estas= 0.5 ULP, alie> 0.5 Se ne plu estas bitoj (half_bit==0), la sube ankaŭ ĝuste redonas Egalan.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Konvertas ĉenon ASCII enhavantan nur dekumajn ciferojn al `u64`.
///
/// Ne faras kontrolojn pri superfluo aŭ nevalidaj signoj, do se la vokanto ne zorgas, la rezulto estas falsa kaj povas panic (kvankam ĝi ne estos `unsafe`).
/// Aldone, malplenaj ĉenoj estas traktataj kiel nul.
/// Ĉi tiu funkcio ekzistas ĉar
///
/// 1. uzi `FromStr` sur `&[u8]` postulas `from_utf8_unchecked`, kio estas malbona, kaj
/// 2. kunmeti la rezultojn de `integral.parse()` kaj `fractional.parse()` estas pli komplika ol ĉi tiu tuta funkcio.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Konvertas ĉenon de ASCII-ciferoj en grandegulon.
///
/// Kiel `from_str_unchecked`, ĉi tiu funkcio dependas de la analizilo por forigi ne-ciferojn.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Malvolvas bignum en 64-bitan entjeron.Panics se la nombro estas tro granda.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Eltiras gamon da bitoj.

/// Indekso 0 estas la malplej signifa bito kaj la gamo estas duone malfermita kiel kutime.
/// Panics se oni petas ĉerpi pli da bitoj ol taŭgas en la revena tipo.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}