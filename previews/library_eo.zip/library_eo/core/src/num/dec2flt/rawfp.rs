//! Bito ludanta sur pozitivaj flosiloj IEEE 754.Negativaj nombroj ne estas kaj ne bezonas esti traktataj.
//! Normalaj glitkomaj nombroj havas kanonikan reprezentadon kiel (frac, exp) tia ke la valoro estas 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) kie N estas la nombro da bitoj.
//!
//! Subnormaloj estas iomete malsamaj kaj strangaj, sed validas la sama principo.
//!
//! Ĉi tie ni tamen reprezentas ilin kiel (sig, k) kun f pozitiva, tia ke la valoro estas f *
//! 2 <sup>e</sup> .Krom ekspliciti la "hidden bit", ĉi tio ŝanĝas la eksponenton per la tiel nomata mantisa ŝanĝo.
//!
//! Diru alimaniere, kutime flosiloj estas skribitaj kiel (1) sed ĉi tie ili estas skribitaj kiel (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Ni nomas (1) la **frakcia reprezento** kaj (2) la **integra reprezento**.
//!
//! Multaj funkcioj en ĉi tiu modulo nur traktas normalajn nombrojn.La rutinoj dec2flt konservative konservas la universale ĝustan malrapidan vojon (Algoritmo M) por tre malgrandaj kaj tre grandaj nombroj.
//! Tiu algoritmo bezonas nur next_float(), kiu ja pritraktas subnormalojn kaj nulojn.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Helpanto trait por eviti duobligi esence la tutan konvertan kodon por `f32` kaj `f64`.
///
/// Vidu la dokumentan komenton de la gepatra modulo por kial tio necesas.
///
/// **Neniam**** estu efektivigata por aliaj specoj aŭ uzata ekster la dec2flt-modulo.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Tipo uzata de `to_bits` kaj `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Elfaras krudan transmutacion al entjero.
    fn to_bits(self) -> Self::Bits;

    /// Elfaras krudan transmutacion de entjero.
    fn from_bits(v: Self::Bits) -> Self;

    /// Liveras la kategorion en kiu ĉi tiu nombro falas.
    fn classify(self) -> FpCategory;

    /// Liveras la mantison, eksponenton kaj signon kiel entjerojn.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Malkodas la flosilon.
    fn unpack(self) -> Unpacked;

    /// Castetas de malgranda entjero, kiu povas esti precize reprezentata.
    /// Panic se la entjero ne povas esti reprezentata, la alia kodo en ĉi tiu modulo certigas, ke neniam tio okazos.
    fn from_int(x: u64) -> Self;

    /// Akiras la valoron 10 <sup>e</sup> de antaŭkomputita tabelo.
    /// Panics por `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Kion diras la nomo.
    /// Ĝi estas pli facila por malfacila kodo ol ĵongli kun internaj programoj kaj esperi ke LLVM-konstanto faldas ĝin.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Konservativa bindita sur la dekumaj ciferoj de enigoj, kiuj ne povas produkti superfluon aŭ nulon aŭ
    /// subnormaloj.Probable la dekuma eksponento de la maksimuma normala valoro, de tie la nomo.
    const MAX_NORMAL_DIGITS: usize;

    /// Kiam la plej signifa dekuma cifero havas lokan valoron pli grandan ol ĉi tio, la nombro certe rondiĝas ĝis senfineco.
    ///
    const INF_CUTOFF: i64;

    /// Kiam la plej signifa dekuma cifero havas lokan valoron malpli ol ĉi tiu, la nombro certe rondiĝas al nulo.
    ///
    const ZERO_CUTOFF: i64;

    /// La nombro de bitoj en la eksponento.
    const EXP_BITS: u8;

    /// La nombro de bitoj en la signifo,*inkluzive* la kaŝitan biton.
    const SIG_BITS: u8;

    /// La nombro de bitoj en la signifo,*ekskludante* la kaŝitan biton.
    const EXPLICIT_SIG_BITS: u8;

    /// La maksimuma jura eksponento en frakcia reprezento.
    const MAX_EXP: i16;

    /// La minimuma laŭleĝa eksponento en frakcia reprezento, ekskludante subnormalojn.
    const MIN_EXP: i16;

    /// `MAX_EXP` por integra reprezento, te kun la movo aplikita.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kodita (te kun ofseta antaŭjuĝo)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` por integra reprezento, te kun la movo aplikita.
    const MIN_EXP_INT: i16;

    /// La maksimuma normaligita signifo en integra reprezento.
    const MAX_SIG: u64;

    /// La minimuma normaligita signifo en integra reprezento.
    const MIN_SIG: u64;
}

// Plejparte solvo por #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Liveras la mantison, eksponenton kaj signon kiel entjerojn.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Eksponenta antaŭjuĝo + mantisa ŝanĝo
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe estas necerta, ĉu `as` funkcias ĝuste sur ĉiuj platformoj.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Liveras la mantison, eksponenton kaj signon kiel entjerojn.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Eksponenta antaŭjuĝo + mantisa ŝanĝo
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe estas necerta, ĉu `as` funkcias ĝuste sur ĉiuj platformoj.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Konvertas `Fp` al la plej proksima maŝin-flosa tipo.
/// Ne traktas subnormalajn rezultojn.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f estas 64 bitoj, do xe havas mantisŝovon de 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Ĉirkaŭigu la 64-bitan signifon al T::SIG_BITS-bitoj kun duon-ebena.
/// Ne traktas eksponan superfluon.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Ĝustigu mantisŝanĝon
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inverso de `RawFloat::unpack()` por normaligitaj nombroj.
/// Panics se la signifo aŭ eksponento ne validas por normaligitaj nombroj.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Forigu la kaŝitan biton
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Ĝustigu la eksponenton por eksponenta antaŭjuĝo kaj mantisa ŝanĝo
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Lasu signan biton je 0 ("+"), niaj nombroj estas ĉiuj pozitivaj
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Konstruu subnormalan.Mantiso de 0 estas permesita kaj konstruas nulon.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Kodita eksponento estas 0, la signobito estas 0, do ni nur devas reinterpreti la bitojn.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Proksimume bignum kun Fp.Rondoj ene de 0.5 ULP kun duon-ebena.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Ni fortranĉas ĉiujn bitojn antaŭ la indekso `start`, t.e., ni efike dekstre ŝanĝas per kvanto de `start`, do ĉi tio ankaŭ estas la eksponento, kiun ni bezonas.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Ronda (half-to-even) depende de la detranĉitaj bitoj.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Trovas la plej grandan glitkoman nombron strikte pli malgrandan ol la argumento.
/// Ne traktas subnormalajn, nulajn aŭ eksponentajn subfluojn.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Trovu la plej malgrandan glitkoman numeron strikte pli grandan ol la argumento.
// Ĉi tiu operacio estas saturita, te next_float(inf) ==inf.
// Male al plej multaj kodoj en ĉi tiu modulo, ĉi tiu funkcio traktas nulon, subnormalojn kaj senfinojn.
// Tamen, kiel ĉiuj aliaj kodoj ĉi tie, ĝi ne traktas NaN kaj negativajn nombrojn.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Ĉi tio ŝajnas tro bona por esti vera, sed ĝi funkcias.
        // 0.0 estas kodita kiel tute-nula vorto.Subnormaloj estas 0x000m ... m kie m estas la mantiso.
        // Aparte, la plej malgranda subnormalo estas 0x0 ... 01 kaj la plej granda estas 0x000F ... F.
        // La plej malgranda normala nombro estas 0x0010 ... 0, do ĉi tiu angula kazo funkcias ankaŭ.
        // Se la pliigo superfluas la mantison, la portpeco pliigas la eksponenton kiel ni volas, kaj la mantisaj bitoj fariĝas nulaj.
        // Pro la kaŝita bita konvencio, ankaŭ ĉi tio estas ĝuste tio, kion ni volas!
        // Fine, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}