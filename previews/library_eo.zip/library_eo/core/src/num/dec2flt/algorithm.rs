//! La diversaj algoritmoj de la papero.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Nombro de signifaj bitoj en Fp
const P: u32 = 64;

// Ni simple konservas la plej bonan proksimuman kalkuladon por *ĉiuj* eksponentoj, do la variablo "h" kaj la rilataj kondiĉoj povas esti preterlasitaj.
// Ĉi tio komercas agadon por kelkaj kilobajtoj da spaco.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// En plej multaj arkitekturoj, glitkomaj operacioj havas eksplicitan bitgrandecon, tial la precizeco de la komputado estas determinita laŭ po-operacia bazo.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Ĉe x86, la x87 FPU estas uzata por flosaj operacioj se la SSE/SSE2-etendaĵoj ne haveblas.
// La x87 FPU funkcias kun 80 bitoj da precizeco defaŭlte, kio signifas ke operacioj rondos ĝis 80 bitoj kaŭzante duoblan rondigon okazi kiam valoroj estas eventuale reprezentataj kiel
//
// 32/64 bitaj flosvaloroj.Por superi ĉi tion, la FPU-kontrolvorto povas esti agordita tiel ke la komputadoj plenumu la deziratan precizecon.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Strukturo uzata por konservi la originalan valoron de la FPU-kontrolvorto, tiel ke ĝi povas esti restarigita kiam la strukturo falas.
    ///
    ///
    /// La x87 FPU estas 16-bita registro, kies kampoj estas jenaj:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// La dokumentaro por ĉiuj kampoj estas havebla en la Manlibro de la Programisto pri Programaro IA-32 Architectures (Volumo 1).
    ///
    /// La sola kampo, kiu gravas por la sekva kodo, estas komputilo Precizeca Kontrolo.
    /// Ĉi tiu kampo determinas la precizecon de la operacioj faritaj de la FPU.
    /// Ĝi povas esti agordita al:
    ///  - 0b00, sola precizeco te 32-bitoj
    ///  - 0b10, duobla precizeco te 64-bitoj
    ///  - 0b11, duobla plilongigita precizeco te 80-bitoj (defaŭlta stato) La valoro 0b01 estas rezervita kaj ne uzu.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SEKURECO: la `fldcw`-instrukcio estis kontrolita por povi ĝuste funkcii kun
        // ajna `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Ni uzas ATT-sintakson por subteni LLVM 8 kaj LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Agordas la precizan kampon de la FPU al `T` kaj redonas `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Kalkulu la valoron por la kampo Preciza Kontrolo taŭga por `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bitoj
            8 => 0x0200, // 64 bitoj
            _ => 0x0300, // defaŭlte, 80 bitoj
        };

        // Akiru la originalan valoron de la kontrolvorto por restarigi ĝin poste, kiam la `FPUControlWord`-strukturo estas faligita SEKURECO: la `fnstcw`-instrukcio estis kontrolita por povi ĝuste funkcii kun iu `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Ni uzas ATT-sintakson por subteni LLVM 8 kaj LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Agordu la kontrolvorton laŭ la dezirata precizeco.
        // Ĉi tio estas atingita maskante la malnovan precizecon (bitoj 8 kaj 9, 0x300) kaj anstataŭigante ĝin per la preciza flago komputita supre.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// La rapida vojo de Belerofono uzanta maŝin-grandajn entjerojn kaj flosilojn.
///
/// Ĉi tio estas ĉerpita en apartan funkcion tiel ke ĝi povas esti provita antaŭ konstruado de bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Ni komparas la ĝustan valoron al MAX_SIG proksime al la fino, ĉi tio estas nur rapida, malmultekosta malakcepto (kaj ankaŭ liberigas la reston de la kodo de zorgo pri subfluo).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // La rapida vojo grave dependas de aritmetiko rondigita al la ĝusta nombro da bitoj sen iu meza rondigo.
    // Sur x86 (sen SSE aŭ SSE2) ĉi tio postulas ŝanĝi la precizecon de la stako XP1X FPU tiel ke ĝi rekte rondiras al 64/32-bito.
    // La funkcio `set_precision` prizorgas agordi la precizecon sur arkitekturoj, kiuj postulas agordi ĝin ŝanĝante la tutmondan staton (kiel la kontrola vorto de la x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // La kazo e <0 ne povas esti faldita en la alian branch.
    // Negativaj potencoj rezultigas ripetan frakcian parton en duuma, kiu estas rondigita, kio kaŭzas realajn (kaj foje sufiĉe signifajn!) Erarojn en la fina rezulto.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritmo Bellerophon estas bagatela kodo pravigita per nesensignifa nombra analizo.
///
/// Ĝi rondigas "f" al flosilo kun 64-bita signifo kaj multobligas ĝin per la plej bona aproksimado de `10^e` (en la sama glitkoma formato).Ĉi tio ofte sufiĉas por akiri la ĝustan rezulton.
/// Tamen, kiam la rezulto estas proksima al duonvojo inter du apudaj (ordinary)-flosiloj, la kunmetaĵa rondiga eraro de multobligado de du aproksimado signifas ke la rezulto povas esti malŝaltita per kelkaj bitoj.
/// Kiam ĉi tio okazas, la ripeta Algoritmo R riparas aferojn.
///
/// La mansaluta "close to halfway" fariĝas preciza per la nombra analizo en la papero.
/// En la vortoj de Clinger:
///
/// > Slop, esprimita en unuoj de la malplej signifa bito, estas inkluziva ligo por la eraro
/// > amasigita dum la glitkoma kalkulo de la aproksimado al f * 10 ^ e.(Slop estas
/// > ne ligita por la vera eraro, sed limigas la diferencon inter la proksimuma kalkulado z kaj
/// > la plej bona ebla aproksimado, kiu uzas p pecojn da signifo.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // La kazoj abs(e) <log5(2^N) estas en fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Ĉu la deklivo estas sufiĉe granda por fari diferencon kiam rondigo al n bitoj?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Ripeta algoritmo kiu plibonigas glitkoman aproksimadon de `f * 10^e`.
///
/// Ĉiu ripeto proksimiĝas al unu unuo, kio kompreneble daŭras terure konverĝi, se `z0` eĉ iomete malŝaltas.
/// Bonŝance, se uzata kiel rezerva por Bellerophon, la komenca proksimuma kalkulado estas ekstere de maksimume unu ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Trovu pozitivajn entjerojn `x`, `y` tia ke `x / y` estas ĝuste `(f *10^e) / (m* 2^k)`.
        // Ĉi tio ne nur evitas trakti la signojn de `e` kaj `k`, sed ni ankaŭ forigas la potencon de du komunaj al `10^e` kaj `2^k` por malgrandigi la nombrojn.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Ĉi tio estas iomete mallerte skribita, ĉar niaj bignumoj ne subtenas negativajn nombrojn, do ni uzas la absolutan valoron + signan informon.
        // La multipliko kun m_ciferoj ne povas superflui.
        // Se `x` aŭ `y` estas sufiĉe grandaj, ke ni devas zorgi pri superfluo, tiam ili ankaŭ estas sufiĉe grandaj, ke `make_ratio` reduktis la frakcion je faktoro 2 ^ 64 aŭ pli.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Ne plu bezonas x, konservu clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Ankoraŭ bezonas y, faru kopion.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Donita `x = f` kaj `y = m` kie `f` reprezentas enirajn dekumajn ciferojn kiel kutime kaj `m` estas la signifo de glitkoma aproksimado, faru la rilatumon `x / y` egala al `(f *10^e) / (m* 2^k)`, eble reduktita per potenco de du ambaŭ havas komunan.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, krom ke ni reduktas la frakcion per ia potenco de du.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Ĉi tio ne povas superflui ĉar ĝi postulas pozitivan `e` kaj negativan `k`, kio povas okazi nur por valoroj ekstreme proksimaj al 1, kio signifas ke `e` kaj `k` estos relative etaj.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Ankaŭ ĉi tio ne povas superflui, vidu supre.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), denove reduktante per komuna potenco de du.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Koncipe, Algoritmo M estas la plej simpla maniero konverti decimalon al flosilo.
///
/// Ni formas rilatumon egala al `f * 10^e`, tiam ĵetante potencojn de du ĝis ĝi donas validan ŝveban signifon.
/// La duuma eksponento `k` estas la nombro de fojoj, kiam ni multobligis numeratoron aŭ denominatoron per du, t.e., ĉiam `f *10^e` egalas al `(u / v)* 2^k`.
/// Kiam ni eksciis signifon, ni nur bezonas rondigi per inspektado de la resto de la divido, kio estas farita en helpaj funkcioj pli sube.
///
///
/// Ĉi tiu algoritmo estas tre malrapida, eĉ kun la optimumigo priskribita en `quick_start()`.
/// Tamen ĝi estas la plej simpla el la algoritmoj por adapti por superfluaj, subfluaj kaj subnormalaj rezultoj.
/// Ĉi tiu efektivigo transprenas kiam Bellerophon kaj Algorithm R estas superŝutitaj.
/// Detekti subfluon kaj superfluaĵon estas facila: la rilatumo ankoraŭ ne estas enmezura signifo, tamen la minimum/maximum-eksponento estas atingita.
/// En la kazo de superfluaĵo, ni simple redonas senfinecon.
///
/// Pritrakti subfluon kaj subnormalojn estas pli malfacila.
/// Unu granda problemo estas, ke, kun la minimuma eksponento, la proporcio povus ankoraŭ esti tro granda por signifo.
/// Vidu underflow() por detaloj.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME ebla optimumigo: ĝeneraligu big_to_fp tiel ke ni povu fari la ekvivalenton de fp_to_float(big_to_fp(u)) ĉi tie, nur sen la duobla rondigo.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Ni devas ĉesi ĉe la minimuma eksponento, se ni atendos ĝis `k < T::MIN_EXP_INT`, tiam ni malaktivus je du.
            // Bedaŭrinde ĉi tio signifas, ke ni devas specialkazi normalajn nombrojn kun la minimuma eksponento.
            // FIXME trovas pli elegantan formulon, sed faru la teston `tiny-pow10` por certigi, ke ĝi efektive ĝustas!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Transsaltas la plej multajn algoritmajn ripetojn kontrolante la bitlongon.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // La bita longo estas takso de la baza du logaritmo, kaj log(u / v) = log(u), log(v).
    // La takso estas ekstere de maksimume 1, sed ĉiam subtakso, do la eraro sur log(u) kaj log(v) estas de la sama signo kaj nuligas (se ambaŭ estas grandaj).
    // Tial la eraro por log(u / v) estas ankaŭ maksimume unu.
    // La cela proporcio estas unu, kie u/v estas en ampleksa signifo.Tiel nia fina kondiĉo estas log2(u / v) estanta la signifaj bitoj, plus/minus unu.
    // FIXME Rigardi la duan biton povus plibonigi la takson kaj eviti pliajn dividojn.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Subfluo aŭ subnormala.Lasu ĝin al la ĉefa funkcio.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Superfluaĵo.Lasu ĝin al la ĉefa funkcio.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Rilatumo ne estas ampleksa signifo kaj kun la minimuma eksponento, do ni devas rondigi troajn bitojn kaj ĝustigi la eksponenton laŭe.
    // La vera valoro nun aspektas tiel:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(reprezentita per rem)
    //
    // Tial, kiam la rondigitaj bitoj estas!= 0.5 ULP, ili decidas la rondigon memstare.
    // Kiam ili estas egalaj kaj la resto estas nula, la valoro ankoraŭ devas esti rondigita.
    // Nur kiam la rondigitaj bitoj estas 1/2 kaj la resto estas nula, ni havas duon-egalan situacion.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Ordinara ĉirkaŭ-ebena, malklarigita de devo rondigi surbaze de la resto de divido.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}