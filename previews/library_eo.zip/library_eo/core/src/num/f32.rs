//! Konstantoj specifaj por la `f32`-precizeca glitkoma tipo.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Matematike signifaj nombroj estas provizitaj en la `consts`-submodulo.
//!
//! Por la konstantoj difinitaj rekte en ĉi tiu modulo (aparte de tiuj difinitaj en la `consts`-submodulo), nova kodo anstataŭe uzu la asociitajn konstantojn difinitajn rekte sur la `f32`-tipo.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// La radikso aŭ bazo de la interna reprezentado de `f32`.
/// Uzu [`f32::RADIX`] anstataŭe.
///
/// # Examples
///
/// ```rust
/// // malrekomendata maniero
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // celita maniero
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Nombro de signifaj ciferoj en bazo 2.
/// Uzu [`f32::MANTISSA_DIGITS`] anstataŭe.
///
/// # Examples
///
/// ```rust
/// // malrekomendata maniero
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // celita maniero
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Proksimuma nombro de signifaj ciferoj en bazo 10.
/// Uzu [`f32::DIGITS`] anstataŭe.
///
/// # Examples
///
/// ```rust
/// // malrekomendata maniero
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // celita maniero
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] valoro por `f32`.
/// Uzu [`f32::EPSILON`] anstataŭe.
///
/// Jen la diferenco inter `1.0` kaj la sekva pli granda reprezentebla nombro.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // malrekomendata maniero
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // celita maniero
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Plej malgranda finia `f32`-valoro.
/// Uzu [`f32::MIN`] anstataŭe.
///
/// # Examples
///
/// ```rust
/// // malrekomendata maniero
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // celita maniero
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Plej malgranda pozitiva normala `f32`-valoro.
/// Uzu [`f32::MIN_POSITIVE`] anstataŭe.
///
/// # Examples
///
/// ```rust
/// // malrekomendata maniero
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // celita maniero
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Plej granda finia `f32`-valoro.
/// Uzu [`f32::MAX`] anstataŭe.
///
/// # Examples
///
/// ```rust
/// // malrekomendata maniero
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // celita maniero
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Unu pli granda ol la minimuma ebla normala potenco de 2 eksponento.
/// Uzu [`f32::MIN_EXP`] anstataŭe.
///
/// # Examples
///
/// ```rust
/// // malrekomendata maniero
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // celita maniero
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Maksimuma ebla potenco de 2 eksponento.
/// Uzu [`f32::MAX_EXP`] anstataŭe.
///
/// # Examples
///
/// ```rust
/// // malrekomendata maniero
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // celita maniero
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Minimuma ebla normala potenco de 10 eksponento.
/// Uzu [`f32::MIN_10_EXP`] anstataŭe.
///
/// # Examples
///
/// ```rust
/// // malrekomendata maniero
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // celita maniero
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Maksimuma ebla potenco de 10 eksponento.
/// Uzu [`f32::MAX_10_EXP`] anstataŭe.
///
/// # Examples
///
/// ```rust
/// // malrekomendata maniero
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // celita maniero
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Ne Numero (NaN).
/// Uzu [`f32::NAN`] anstataŭe.
///
/// # Examples
///
/// ```rust
/// // malrekomendata maniero
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // celita maniero
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Senfineco (∞).
/// Uzu [`f32::INFINITY`] anstataŭe.
///
/// # Examples
///
/// ```rust
/// // malrekomendata maniero
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // celita maniero
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Negativa malfinio (−∞).
/// Uzu [`f32::NEG_INFINITY`] anstataŭe.
///
/// # Examples
///
/// ```rust
/// // malrekomendata maniero
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // celita maniero
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Bazaj matematikaj konstantoj.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: anstataŭigi per matematikaj konstantoj de cmath.

    /// Konstanta (π) de Arimimedo
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// La konstanta kompleta cirklo (τ)
    ///
    /// Egala al 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Euler-numero (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// La radikso aŭ bazo de la interna reprezentado de `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Nombro de signifaj ciferoj en bazo 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Proksimuma nombro de signifaj ciferoj en bazo 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] valoro por `f32`.
    ///
    /// Jen la diferenco inter `1.0` kaj la sekva pli granda reprezentebla nombro.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Plej malgranda finia `f32`-valoro.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Plej malgranda pozitiva normala `f32`-valoro.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Plej granda finia `f32`-valoro.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Unu pli granda ol la minimuma ebla normala potenco de 2 eksponento.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Maksimuma ebla potenco de 2 eksponento.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Minimuma ebla normala potenco de 10 eksponento.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Maksimuma ebla potenco de 10 eksponento.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Ne Numero (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Senfineco (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Negativa malfinio (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Liveras `true` se ĉi tiu valoro estas `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` estas publike neatingebla en libcore pro zorgoj pri porteblo, do ĉi tiu efektivigo estas por privata uzo interne.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Liveras `true` se ĉi tiu valoro estas pozitiva malfinio aŭ negativa malfinio, kaj `false` alie.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Liveras `true` se ĉi tiu nombro estas nek senfina nek `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Ne necesas pritrakti NaN aparte: se mem estas NaN, la komparo ne veras, ekzakte kiel dezirata.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Liveras `true` se la nombro estas [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Valoroj inter `0` kaj `min` estas Subnormalaj.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Liveras `true` se la nombro estas nek nula, senfina, [subnormal] aŭ `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Valoroj inter `0` kaj `min` estas Subnormalaj.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Redonas la glitkoman kategorion de la nombro.
    /// Se nur unu posedaĵo estos provota, estas ĝenerale pli rapide uzi la specifan predikaton anstataŭe.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Liveras `true` se `self` havas pozitivan signon, inkluzive `+0.0`, `NaN kun pozitiva signobito kaj pozitiva senfineco.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Liveras `true` se `self` havas negativan signon, inkluzive `-0.0`, `NaN kun negativa signopeco kaj negativa senfineco.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 diras: isSignMinus(x) estas vera se kaj nur se x havas negativan signon.
        // isSignMinus validas ankaŭ por nuloj kaj NaN.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Prenas la reciprokan (inverse) de nombro, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Konvertas radianojn al gradoj.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Uzu konstanton por pli bona precizeco.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Konvertas gradojn al radianoj.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Liveras la maksimumon de la du nombroj.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Se unu el la argumentoj estas NaN, tiam la alia argumento estas redonita.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Liveras la minimumon de la du nombroj.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Se unu el la argumentoj estas NaN, tiam la alia argumento estas redonita.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Rondas al nulo kaj transformas al iu ajn primitiva entjerspeco, supozante ke la valoro estas finia kaj kongruas en tiu tipo.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// La valoro devas:
    ///
    /// * Ne estu `NaN`
    /// * Ne estu senfina
    /// * Estu reprezentebla en la revena tipo `Int`, post detranĉado de ĝia frakcia parto
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Kruda transmutacio al `u32`.
    ///
    /// Ĉi tio nuntempe identas al `transmute::<f32, u32>(self)` sur ĉiuj platformoj.
    ///
    /// Vidu `from_bits` por iu diskuto pri la porteblo de ĉi tiu operacio (preskaŭ ne ekzistas problemoj).
    ///
    /// Rimarku, ke ĉi tiu funkcio distingas de `as`-rolado, kiu provas konservi la *nombran* valoron, kaj ne la bitan valoron.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() ne gisas!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // SEKURECO: `u32` estas simpla malnova datumtipo, do ni ĉiam povas transmutacii al ĝi
        unsafe { mem::transmute(self) }
    }

    /// Kruda transmutacio de `u32`.
    ///
    /// Ĉi tio nuntempe identas al `transmute::<u32, f32>(v)` sur ĉiuj platformoj.
    /// Rezultas, ke ĉi tio estas nekredeble portebla, pro du kialoj:
    ///
    /// * Flosiloj kaj Ints havas la saman finon sur ĉiuj subtenataj platformoj.
    /// * IEEE-754 tre precize specifas la bitaranĝon de flosiloj.
    ///
    /// Tamen estas unu averto: antaŭ la versio de IEEE-754 en 2008, kiel interpreti la signalan biton NaN ne estis fakte specifita.
    /// Plej multaj platformoj (precipe x86 kaj ARM) elektis la interpreton, kiu finfine estis normigita en 2008, sed iuj ne (precipe MIPS).
    /// Rezulte, ĉiuj signalaj NaN sur MIPS estas kvietaj NaN sur x86, kaj inverse.
    ///
    /// Prefere ol provi konservi signal-eco-plurplatformon, ĉi tiu efektivigo preferas konservi la ĝustajn bitojn.
    /// Ĉi tio signifas, ke iuj utilaj ŝarĝoj koditaj en NaN-oj konserviĝos eĉ se la rezulto de ĉi tiu metodo estos sendita tra la reto de x86-maŝino al MIPS.
    ///
    ///
    /// Se la rezultoj de ĉi tiu metodo estas manipulitaj nur per la sama arkitekturo, kiu produktis ilin, tiam ne estas zorgo pri portebleco.
    ///
    /// Se la enigo ne estas NaN, tiam ne temas pri portebleco.
    ///
    /// Se vi ne zorgas pri signaleco (tre verŝajne), tiam ne estas portebla zorgo.
    ///
    /// Rimarku, ke ĉi tiu funkcio distingas de `as`-rolado, kiu provas konservi la *nombran* valoron, kaj ne la bitan valoron.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // SEKURECO: `u32` estas simpla malnova datumtipo, do ni ĉiam povas transmutacii de ĝi
        // Rezultas, ke la sekurecaj problemoj kun sNaN estis tro multaj!Hura!
        unsafe { mem::transmute(v) }
    }

    /// Redonu la memoran reprezentadon de ĉi tiu glitkoma nombro kiel bajta tabelo en grand-endiana (network)-bajta ordo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Redonu la memoran reprezentadon de ĉi tiu glitkoma nombro kiel bajta tabelo en iom-endiana bajta ordo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Redonu la memoran reprezentadon de ĉi tiu glitkoma nombro kiel bajta tabelo en denaska bajta ordo.
    ///
    /// Ĉar la denaska endianeco de la cela platformo estas uzata, portebla kodo devas anstataŭe uzi [`to_be_bytes`] aŭ [`to_le_bytes`].
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Redonu la memoran reprezentadon de ĉi tiu glitkoma nombro kiel bajta tabelo en denaska bajta ordo.
    ///
    ///
    /// [`to_ne_bytes`] estu preferata super ĉi tio, kiam eblas.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // SEKURECO: `f32` estas simpla malnova datumtipo, do ni ĉiam povas transmutacii al ĝi
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Kreu glitkoman valoron de ĝia reprezento kiel bajta tabelo en granda endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Kreu glitkoman valoron de ĝia reprezento kiel bajta tabelo en malgranda endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Kreu glitkoman valoron de ĝia reprezento kiel bajta tabelo en denaska endian.
    ///
    /// Ĉar la denaska endianeco de la cela platformo estas uzata, portebla kodo probable volas uzi [`from_be_bytes`] aŭ [`from_le_bytes`], kiel taŭgas anstataŭe.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Liveras ordigon inter memo kaj aliaj valoroj.
    /// Male al la norma parta komparo inter glitkomaj nombroj, ĉi tiu komparo ĉiam produktas ordigon laŭ la totalOrder-predikato kiel difinite en IEEE 754 (2008-revizio) glitkomnormo.
    /// La valoroj estas ordigitaj laŭ jena ordo:
    /// - Negativa kvieta NaN
    /// - Negativa signalado NaN
    /// - Negativa malfinio
    /// - Negativaj nombroj
    /// - Negativaj subnormalaj nombroj
    /// - Negativa nulo
    /// - Pozitiva nulo
    /// - Pozitivaj subnormalaj nombroj
    /// - Pozitivaj nombroj
    /// - Pozitiva senfineco
    /// - Pozitiva signalado NaN
    /// - Pozitiva kvieta NaN
    ///
    /// Rimarku, ke ĉi tiu funkcio ne ĉiam konsentas kun la efektivigoj de [`PartialOrd`] kaj [`PartialEq`] de `f32`.Precipe ili konsideras negativan kaj pozitivan nulon egala, dum `total_cmp` ne.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // En kazo de negativoj, turnu ĉiujn bitojn krom la signo por atingi similan aranĝon kiel du-komplementaj entjeroj
        //
        // Kial ĉi tio funkcias?IEEE 754-flosiloj konsistas el tri kampoj:
        // Signobito, eksponento kaj mantiso.La aro de eksponentaj kaj mantisaj kampoj entute havas la econ, ke ilia laŭbita ordo egalas al la cifereca grando kie la grando estas difinita.
        // La grando kutime ne estas difinita per valoroj de NaN, sed IEEE 754 totalOrder difinas la valorojn de NaN ankaŭ por sekvi la laŭbitan ordon.Ĉi tio kondukas al ordo klarigita en la dokumenta komento.
        // Tamen la prezento de grando samas por negativaj kaj pozitivaj nombroj-nur la signobito diferencas.
        // Por facile kompari la flosilojn kiel subskribitajn entjerojn, ni devas klaki la eksponenton kaj mantizan bitojn en kazo de negativaj nombroj.
        // Ni efike konvertas la nombrojn al "two's complement"-formularo.
        //
        // Por fari la ĵetadon, ni konstruas maskon kaj XOR kontraŭ ĝi.
        // Ni senbranĉe kalkulas "all-ones except for the sign bit"-maskon de negativ-subskribitaj valoroj: dekstre ŝanĝanta signo-etendas la entjeron, do ni "fill" la masko kun signopecoj, kaj poste konvertas al sennoma por puŝi ankoraŭ unu nul-biton.
        //
        // Pri pozitivaj valoroj, la masko estas ĉiuj nuloj, do ĝi estas senoperacio.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Limigi valoron al certa intervalo krom se ĝi estas NaN.
    ///
    /// Liveras `max` se `self` estas pli granda ol `max`, kaj `min` se `self` estas malpli ol `min`.
    /// Alie ĉi tio redonas `self`.
    ///
    /// Notu, ke ĉi tiu funkcio redonas NaN se la komenca valoro ankaŭ estis NaN.
    ///
    /// # Panics
    ///
    /// Panics se `min > max`, `min` estas NaN, aŭ `max` estas NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}