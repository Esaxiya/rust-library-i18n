//! Eraraj tipoj por konvertiĝo al integralaj tipoj.

use crate::convert::Infallible;
use crate::fmt;

/// La erara tipo revenis kiam kontrolita integrala tipa konvertiĝo malsukcesas.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Kunigu prefere ol devigu por certigi, ke kodo kiel `From<Infallible> for TryFromIntError` supre plu funkcios kiam `Infallible` fariĝos kaŝnomo al `!`.
        //
        //
        match never {}
    }
}

/// Eraro redonebla dum analizo de entjero.
///
/// Ĉi tiu eraro estas uzata kiel la erara tipo por la funkcioj `from_str_radix()` sur la primitivaj entjeraj tipoj, kiel [`i8::from_str_radix`].
///
/// # Eblaj kaŭzoj
///
/// Inter aliaj kaŭzoj, `ParseIntError` povas esti ĵetita pro ĉefa aŭ posta blanka spaco en la ĉeno ekz. Kiam ĝi estas akirita de la norma enigo.
///
/// Uzi la [`str::trim()`]-metodon certigas, ke neniu blanka spaco restas antaŭ analizo.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum por stoki la diversajn specojn de eraroj, kiuj povas kaŭzi malsukceson de analizado de entjero.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Analizata valoro estas malplena.
    ///
    /// Inter aliaj kaŭzoj, ĉi tiu varianto konstruiĝos kiam analizos malplenan ĉenon.
    Empty,
    /// Enhavas nevalidan ciferon en ĝia kunteksto.
    ///
    /// Inter aliaj kaŭzoj, ĉi tiu varianto konstruiĝos dum analizado de ĉeno, kiu enhavas ne-ASCII-signon.
    ///
    /// Ĉi tiu varianto ankaŭ estas konstruita kiam `+` aŭ `-` estas mislokigitaj ene de ĉeno aŭ memstare aŭ meze de nombro.
    ///
    ///
    InvalidDigit,
    /// Entjero estas tro granda por konservi en cela entjerspeco.
    PosOverflow,
    /// Entjero estas tro malgranda por konservi en cela entjerspeco.
    NegOverflow,
    /// Valoro estis Nulo
    ///
    /// Ĉi tiu varianto estos elsendita kiam la analiza ĉeno havas valoron de nulo, kio estus kontraŭleĝa por ne-nulaj tipoj.
    ///
    Zero,
}

impl ParseIntError {
    /// Eligas la detalan kaŭzon de analizado de entjera malsukceso.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}