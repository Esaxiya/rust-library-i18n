macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// La plej malgranda valoro, kiun povas reprezenti ĉi tiu entjera tipo.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// La plej granda valoro, kiun povas reprezenti ĉi tiu entjera tipo.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// La grandeco de ĉi tiu entjera tipo en bitoj.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Konvertas ĉentranĉon en antaŭfiksita bazo al entjero.
        ///
        /// La ĉeno estas laŭvola `+` aŭ `-`-signo sekvita de ciferoj.
        /// Gvida kaj posta blanka spaco reprezentas eraron.
        /// Ciferoj estas subaro de ĉi tiuj signoj, depende de `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Ĉi tiu funkcio panics se `radix` ne estas inter 2 kaj 36.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Liveras la nombron de tiuj en la duuma reprezento de `self`.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Liveras la nombron de nuloj en la duuma reprezento de `self`.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Liveras la nombron de ĉefaj nuloj en la duuma reprezento de `self`.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Liveras la nombron de postaj nuloj en la duuma reprezento de `self`.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Liveras la nombron de gvidaj en la duuma reprezento de `self`.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Liveras la nombron de postaj en la duuma reprezento de `self`.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Ŝovas la bitojn maldekstren per specifa kvanto, `n`, envolvante la detranĉitajn bitojn ĝis la fino de la rezulta entjero.
        ///
        ///
        /// Bonvolu noti, ke ĉi tio ne estas la sama operacio kiel la ŝanĝa operatoro `<<`!
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Ŝovas la bitojn dekstren per specifa kvanto, `n`, envolvante la detranĉitajn bitojn al la komenco de la rezulta entjero.
        ///
        ///
        /// Bonvolu noti, ke ĉi tio ne estas la sama operacio kiel la ŝanĝa operatoro `>>`!
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Inversigas la bajtan ordon de la entjero.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lasu m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Inversigas la ordon de bitoj en la entjero.
        /// La malplej signifa bito fariĝas la plej signifa bito, dua malplej signifa bito fariĝas dua plej signifa bito, ktp.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lasu m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Konvertas entjeron de granda endian al la endianeco de la celo.
        ///
        /// Ĉe granda endian ĉi tio estas senoperacio.Sur malgranda endian la bajtoj estas interŝanĝitaj.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } alia {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Konvertas entjeron de malgranda endian al la endianeco de la celo.
        ///
        /// Pri malgranda endian ĉi tio estas senoperacio.Ĉe granda endian la bajtoj estas interŝanĝitaj.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } alia {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Konvertas `self` al granda endian de la endianeco de la celo.
        ///
        /// Ĉe granda endian ĉi tio estas senoperacio.Sur malgranda endian la bajtoj estas interŝanĝitaj.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // aŭ ne esti?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Konvertas `self` al malgranda endian de la endianeco de la celo.
        ///
        /// Pri malgranda endian ĉi tio estas senoperacio.Ĉe granda endian la bajtoj estas interŝanĝitaj.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Kontrolita entjera aldono.
        /// Komputas `self + rhs`, redonante `None` se superfluo okazis.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nekontrolita entjera aldono.Komputas `self + rhs`, supozante ke superfluo ne povas okazi.
        /// Ĉi tio rezultigas nedifinitan konduton kiam
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Kontrolita entjera subtraho.
        /// Komputas `self - rhs`, redonante `None` se superfluo okazis.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nekontrolita entjera subtraho.Komputas `self - rhs`, supozante ke superfluo ne povas okazi.
        /// Ĉi tio rezultigas nedifinitan konduton kiam
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Kontrolita entjera multipliko.
        /// Komputas `self * rhs`, redonante `None` se superfluo okazis.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nekontrolita entjera multipliko.Komputas `self * rhs`, supozante ke superfluo ne povas okazi.
        /// Ĉi tio rezultigas nedifinitan konduton kiam
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Kontrolita entjera divido.
        /// Kalkulas `self / rhs`, redonante `None` se `rhs == 0` aŭ la divido rezultigas superfluon.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SEKURECO: div per nul kaj per INT_MIN estis kontrolitaj supre
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Kontrolita eŭklida divido.
        /// Kalkulas `self.div_euclid(rhs)`, redonante `None` se `rhs == 0` aŭ la divido rezultigas superfluon.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Kontrolita entjera resto.
        /// Kalkulas `self % rhs`, redonante `None` se `rhs == 0` aŭ la divido rezultigas superfluon.
        ///
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SEKURECO: div per nul kaj per INT_MIN estis kontrolitaj supre
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Kontrolita eŭklida resto.
        /// Kalkulas `self.rem_euclid(rhs)`, redonante `None` se `rhs == 0` aŭ la divido rezultigas superfluon.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Kontrolita neado.
        /// Komputas `-self`, redonante `None` se `self == MIN`.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrolita deĵoro maldekstren.
        /// Komputas `self << rhs`, redonante `None` se `rhs` estas pli granda aŭ egala al la nombro da bitoj en `self`.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrolita movo dekstren.
        /// Komputas `self >> rhs`, redonante `None` se `rhs` estas pli granda aŭ egala al la nombro da bitoj en `self`.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrolita absoluta valoro.
        /// Komputas `self.abs()`, redonante `None` se `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Kontrolita potenco.
        /// Komputas `self.pow(exp)`, redonante `None` se superfluo okazis.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // ekde exp!=0, fine la exp devas esti 1.
            // Traktu la finan biton de la eksponento aparte, ĉar kvadratigi la bazon poste ne necesas kaj povas kaŭzi nenecesan superfluon.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Saturanta entjera aldono.
        /// Komputas `self + rhs`, saturante je la numeraj limoj anstataŭ superflui.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Saturanta entjera subtraho.
        /// Komputas `self - rhs`, saturante je la numeraj limoj anstataŭ superflui.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Saturanta entjera negacio.
        /// Komputas `-self`, redonante `MAX` se `self == MIN` anstataŭ superflui.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Saturanta absoluta valoro.
        /// Komputas `self.abs()`, redonante `MAX` se `self == MIN` anstataŭ superflui.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Saturanta entjera multipliko.
        /// Komputas `self * rhs`, saturante je la numeraj limoj anstataŭ superflui.
        ///
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Saturanta entjera potenco.
        /// Komputas `self.pow(exp)`, saturante je la numeraj limoj anstataŭ superflui.
        ///
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Envolvado de (modular)-aldono.
        /// Komputas `self + rhs`, ĉirkaŭvolvante ĉirkaŭ la rando de la tipo.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Envolvante (modular)-subtrahon.
        /// Komputas `self - rhs`, ĉirkaŭvolvante ĉirkaŭ la rando de la tipo.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Envolvanta (modular)-multiplikon.
        /// Komputas `self * rhs`, ĉirkaŭvolvante ĉirkaŭ la rando de la tipo.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Envolvante (modular)-dividon.Komputas `self / rhs`, ĉirkaŭvolvante ĉirkaŭ la rando de la tipo.
        ///
        /// La sola kazo, kie tia envolvaĵo povas okazi, estas kiam oni dividas `MIN / -1` sur subskribita tipo (kie `MIN` estas la negativa minimuma valoro por la tipo);ĉi tio ekvivalentas al `-MIN`, pozitiva valoro tro granda por reprezenti en la tipo.
        /// En tia kazo, ĉi tiu funkcio redonas `MIN` mem.
        ///
        /// # Panics
        ///
        /// Ĉi tiu funkcio estos panic se `rhs` estas 0.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Envolvante eŭklidan dividon.
        /// Komputas `self.div_euclid(rhs)`, ĉirkaŭvolvante ĉirkaŭ la rando de la tipo.
        ///
        /// Envolvado okazos nur en `MIN / -1` ĉe subskribita tipo (kie `MIN` estas la negativa minimuma valoro por la tipo).
        /// Ĉi tio ekvivalentas al `-MIN`, pozitiva valoro tro granda por reprezenti en la tipo.
        /// Ĉi-kaze ĉi tiu metodo redonas `MIN` mem.
        ///
        /// # Panics
        ///
        /// Ĉi tiu funkcio estos panic se `rhs` estas 0.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Envolvante (modular)-reston.Komputas `self % rhs`, ĉirkaŭvolvante ĉe la rando de la tipo.
        ///
        /// Tia ĉirkaŭvolvo neniam efektive okazas matematike;efektivigaj artefaktoj malvalidas `x % y` por `MIN / -1` sur subskribita tipo (kie `MIN` estas la negativa minimuma valoro).
        ///
        /// En tia kazo, ĉi tiu funkcio redonas `0`.
        ///
        /// # Panics
        ///
        /// Ĉi tiu funkcio estos panic se `rhs` estas 0.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Envolvante eŭklidan reston.Komputas `self.rem_euclid(rhs)`, ĉirkaŭvolvante ĉirkaŭ la rando de la tipo.
        ///
        /// Envolvado okazos nur en `MIN % -1` ĉe subskribita tipo (kie `MIN` estas la negativa minimuma valoro por la tipo).
        /// Ĉi-kaze ĉi tiu metodo redonas 0.
        ///
        /// # Panics
        ///
        /// Ĉi tiu funkcio estos panic se `rhs` estas 0.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Envolvante (modular)-neadon.Komputas `-self`, ĉirkaŭvolvante ĉirkaŭ la rando de la tipo.
        ///
        /// La sola kazo, kie tia envolvaĵo povas okazi, estas kiam oni neas `MIN` sur subskribita tipo (kie `MIN` estas la negativa minimuma valoro por la tipo);ĉi tio estas pozitiva valoro tro granda por reprezenti en la tipo.
        /// En tia kazo, ĉi tiu funkcio redonas `MIN` mem.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-libera bita movo-maldekstre;donas `self << mask(rhs)`, kie `mask` forigas iujn ajn altordajn pecojn de `rhs`, kiuj kaŭzus la ŝanĝon superi la bitlarĝon de la tipo.
        ///
        /// Rimarku, ke ĉi tio *ne* samas kiel rotacii-maldekstren;la RHS de envolvaĵo maldekstre estas limigita al la gamo de la tipo, prefere ol la pecoj ŝanĝitaj el la LHS estanta resenditaj al la alia fino.
        ///
        /// La primitivaj entjeraj tipoj ĉiuj efektivigas [`rotate_left`](Self::rotate_left)-funkcion, kiu eble estas tio, kion vi volas anstataŭe.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SEKURECO: la maskado per la bitgrandeco de la tipo certigas, ke ni ne ŝanĝiĝu
            // ekster limoj
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-senpova bita movo-dekstre;donas `self >> mask(rhs)`, kie `mask` forigas iujn ajn altordajn pecojn de `rhs`, kiuj kaŭzus la ŝanĝon superi la bitlarĝon de la tipo.
        ///
        /// Rimarku, ke ĉi tio *ne* samas al rotacia dekstro;la RHS de envolvaĵo-dekstra estas limigita al la gamo de la tipo, anstataŭ la bitoj ŝanĝitaj el la LHS estantaj resenditaj al la alia fino.
        ///
        /// La primitivaj entjeraj tipoj ĉiuj efektivigas [`rotate_right`](Self::rotate_right)-funkcion, kiu eble estas tio, kion vi volas anstataŭe.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SEKURECO: la maskado per la bitgrandeco de la tipo certigas, ke ni ne ŝanĝiĝu
            // ekster limoj
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Envolvante (modular) absolutan valoron.Komputas `self.abs()`, ĉirkaŭvolvante ĉirkaŭ la rando de la tipo.
        ///
        /// La sola kazo, kie tia envolvaĵo povas okazi, estas kiam oni prenas la absolutan valoron de la negativa minimuma valoro por la tipo;ĉi tio estas pozitiva valoro tro granda por reprezenti en la tipo.
        /// En tia kazo, ĉi tiu funkcio redonas `MIN` mem.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Kalkulas la absolutan valoron de `self` sen ia envolvaĵo aŭ paniko.
        ///
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Envolvante (modular)-potencon.
        /// Komputas `self.pow(exp)`, ĉirkaŭvolvante ĉirkaŭ la rando de la tipo.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // ekde exp!=0, fine la exp devas esti 1.
            // Traktu la finan biton de la eksponento aparte, ĉar kvadratigi la bazon poste ne necesas kaj povas kaŭzi nenecesan superfluon.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Kalkulas `self` + `rhs`
        ///
        /// Liveras opon de la aldono kune kun bulea indikanta ĉu aritmetika superfluo okazus.
        /// Se superfluaĵo okazus, tiam la envolvita valoro estas redonita.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Kalkulas `self`, `rhs`
        ///
        /// Liveras opon de la subtraho kune kun bulea indikanta ĉu aritmetika superfluaĵo okazus.
        /// Se superfluaĵo okazus, tiam la envolvita valoro estas redonita.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Kalkulas la multiplikon de `self` kaj `rhs`.
        ///
        /// Liveras opon de la multipliko kune kun bulea indikanta ĉu aritmetika superfluo okazus.
        /// Se superfluaĵo okazus, tiam la envolvita valoro estas redonita.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, vera));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Kalkulas la dividanton kiam `self` estas dividita per `rhs`.
        ///
        /// Liveras opon de la dividanto kune kun bulea indikanta ĉu aritmetika superfluaĵo okazus.
        /// Se superfluo okazus, tiam mem revenos.
        ///
        /// # Panics
        ///
        /// Ĉi tiu funkcio estos panic se `rhs` estas 0.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Kalkulas la kvocienton de eŭklida divido `self.div_euclid(rhs)`.
        ///
        /// Liveras opon de la dividanto kune kun bulea indikanta ĉu aritmetika superfluaĵo okazus.
        /// Se superfluo okazus, `self` estas redonita.
        ///
        /// # Panics
        ///
        /// Ĉi tiu funkcio estos panic se `rhs` estas 0.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Kalkulas la reston kiam `self` estas dividita per `rhs`.
        ///
        /// Liveras opon de la resto post dividado kune kun bulea indikado ĉu aritmetika superfluaĵo okazus.
        /// Se superfluo okazus, tiam 0 estas redonita.
        ///
        /// # Panics
        ///
        /// Ĉi tiu funkcio estos panic se `rhs` estas 0.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Inundanta eŭklida resto.Kalkulas `self.rem_euclid(rhs)`.
        ///
        /// Liveras opon de la resto post dividado kune kun bulea indikado ĉu aritmetika superfluaĵo okazus.
        /// Se superfluo okazus, tiam 0 estas redonita.
        ///
        /// # Panics
        ///
        /// Ĉi tiu funkcio estos panic se `rhs` estas 0.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Neas memon, superfluantan se ĉi tio egalas al la minimuma valoro.
        ///
        /// Liveras opon de la nea versio de mem kune kun bulea indikanta ĉu superfluo okazis.
        /// Se `self` estas la minimuma valoro (ekz. `i32::MIN` por valoroj de tipo `i32`), tiam la minimuma valoro estos redonita denove kaj `true` estos redonita por superfluaĵo okazanta.
        ///
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Ŝanĝas sin lasita de `rhs`-bitoj.
        ///
        /// Liveras opon de la ŝanĝita versio de mem kune kun bulea indikado ĉu la ŝanĝvaloro estis pli granda aŭ egala al la nombro da bitoj.
        /// Se la ŝovvaloro estas tro granda, tiam valoro estas maskita (N-1) kie N estas la nombro da bitoj, kaj ĉi tiu valoro estas tiam uzata por plenumi la ŝanĝon.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, vera));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Ŝanĝas sin rekte per `rhs`-bitoj.
        ///
        /// Liveras opon de la ŝanĝita versio de mem kune kun bulea indikado ĉu la ŝanĝvaloro estis pli granda aŭ egala al la nombro da bitoj.
        /// Se la ŝovvaloro estas tro granda, tiam valoro estas maskita (N-1) kie N estas la nombro da bitoj, kaj ĉi tiu valoro estas tiam uzata por plenumi la ŝanĝon.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, vera));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Kalkulas la absolutan valoron de `self`.
        ///
        /// Liveras opon de la absoluta versio de mem kune kun bulea indikanta ĉu superfluo okazis.
        /// Se mem estas la minimuma valoro
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// tiam la minimuma valoro estos redonita denove kaj vera estos redonita por superfluaĵo okazanta.
        ///
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Altigas sin al la potenco de `exp`, uzante potencon per kvadrato.
        ///
        /// Liveras opon de la potenco kune kun bool indikanta ĉu superfluo okazis.
        ///
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, vera));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Grata spaco por konservi rezultojn de overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // ekde exp!=0, fine la exp devas esti 1.
            // Traktu la finan biton de la eksponento aparte, ĉar kvadratigi la bazon poste ne necesas kaj povas kaŭzi nenecesan superfluon.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Altigas sin al la potenco de `exp`, uzante potencon per kvadrato.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // ekde exp!=0, fine la exp devas esti 1.
            // Traktu la finan biton de la eksponento aparte, ĉar kvadratigi la bazon poste ne necesas kaj povas kaŭzi nenecesan superfluon.
            //
            //
            acc * base
        }

        /// Kalkulas la kvocienton de eŭklida divido de `self` per `rhs`.
        ///
        /// Ĉi tio kalkulas la entjeron `n` tia, ke `self = n * rhs + self.rem_euclid(rhs)`, kun `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// Alivorte, la rezulto estas `self / rhs` rondigita al la entjero `n` tia ke `self >= n * rhs`.
        /// Se `self > 0`, ĉi tio egalas al rondo al nulo (la apriora en Rust);
        /// se `self < 0`, ĉi tio egalas al ronda al +/-malfinio.
        ///
        /// # Panics
        ///
        /// Ĉi tiu funkcio estos panic se `rhs` estas 0 aŭ la divido rezultigas superfluon.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// lasu b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Kalkulas la malplej nenegativan reston de `self (mod rhs)`.
        ///
        /// Ĉi tio fariĝas kvazaŭ per la eŭklida divida algoritmo-donita `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` kaj `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ĉi tiu funkcio estos panic se `rhs` estas 0 aŭ la divido rezultigas superfluon.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// lasu b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Kalkulas la absolutan valoron de `self`.
        ///
        /// # Superflua konduto
        ///
        /// La absoluta valoro de
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// ne povas esti prezentita kiel
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// kaj provi kalkuli ĝin kaŭzos superfluaĵon.
        /// Ĉi tio signifas, ke kodo en elpuriga reĝimo ekigos panic ĉi-kaze kaj optimumigita kodo revenos
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// sen panic.
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Notu, ke la supre#[inline] signifas, ke la superflua semantiko de la subtraho dependas de la crate, en kiu ni estas enliniaj.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Liveras nombron reprezentantan signon de `self`.
        ///
        ///  - `0` se la nombro estas nula
        ///  - `1` se la nombro estas pozitiva
        ///  - `-1` se la nombro estas negativa
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Liveras `true` se `self` estas pozitiva kaj `false` se la nombro estas nula aŭ negativa.
        ///
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Liveras `true` se `self` estas negativa kaj `false` se la nombro estas nula aŭ pozitiva.
        ///
        ///
        /// # Examples
        ///
        /// Baza uzado:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Redonu la memoran reprezentadon de ĉi tiu entjero kiel bajta tabelo en grand-endiana (network)-bajta ordo.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Redonu la memoran reprezentadon de ĉi tiu entjero kiel bajta tabelo en iom-endiana bajta ordo.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Redonu la memoran reprezentadon de ĉi tiu entjero kiel bajta tabelo en denaska bajta ordo.
        ///
        /// Ĉar la denaska endianeco de la cela platformo estas uzata, portebla kodo devas anstataŭe uzi [`to_be_bytes`] aŭ [`to_le_bytes`].
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bajtoj, se cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } alia {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SEKURECO: konstanta sono ĉar entjeroj estas simplaj malnovaj datentipoj, do ni ĉiam povas
        // transmutacii ilin al tabeloj de bajtoj
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SEKURECO: entjeroj estas simplaj malnovaj datentipoj, do ni ĉiam povas transmutacii ilin al
            // tabeloj de bajtoj
            unsafe { mem::transmute(self) }
        }

        /// Redonu la memoran reprezentadon de ĉi tiu entjero kiel bajta tabelo en denaska bajta ordo.
        ///
        ///
        /// [`to_ne_bytes`] estu preferata super ĉi tio, kiam eblas.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// let bajtoj= num.as_ne_bytes();
        /// assert_eq!(
        ///     bajtoj, se cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } alia {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SEKURECO: entjeroj estas simplaj malnovaj datentipoj, do ni ĉiam povas transmutacii ilin al
            // tabeloj de bajtoj
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Kreu entjeran valoron de ĝia reprezento kiel bajta tabelo en granda endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// uzu std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * enigo=ripozo;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Kreu entjeran valoron de ĝia reprezento kiel bajta tabelo en malgranda endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// uzu std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * enigo=ripozo;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Kreu entjeran valoron de ĝia memora reprezentado kiel bajta tabelo en denaska endianeco.
        ///
        /// Ĉar la denaska endianeco de la cela platformo estas uzata, portebla kodo probable volas uzi [`from_be_bytes`] aŭ [`from_le_bytes`], kiel taŭgas anstataŭe.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } alia {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// uzu std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * enigo=ripozo;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SEKURECO: konstanta sono ĉar entjeroj estas simplaj malnovaj datentipoj, do ni ĉiam povas
        // transmuti al ili
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SEKURECO: entjeroj estas simplaj malnovaj datentipoj do ni ĉiam povas transmutacii al ili
            unsafe { mem::transmute(bytes) }
        }

        /// Nova kodo preferu uzi
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Liveras la plej malgrandan valoron, kiun povas reprezenti ĉi tiu entjera tipo.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Nova kodo preferu uzi
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Liveras la plej grandan valoron, kiun povas reprezenti ĉi tiu entjera tipo.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}