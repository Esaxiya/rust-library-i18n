//! Malkodas glitkoman valoron en unuopajn partojn kaj erarajn gamojn.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Deĉifrita sennoma finhava valoro, tia ke:
///
/// - La originala valoro egalas al `mant * 2^exp`.
///
/// - Ĉiu nombro de `(mant - minus)*2^exp` al `(mant + plus)* 2^exp` rondos ĝis la originala valoro.
/// La gamo inkluzivas nur kiam `inclusive` estas `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// La skvama mantiso.
    pub mant: u64,
    /// La pli malalta erara gamo.
    pub minus: u64,
    /// La supra erara gamo.
    pub plus: u64,
    /// La komuna eksponento en bazo 2.
    pub exp: i16,
    /// Vera kiam la erara gamo inkluzivas.
    ///
    /// En IEEE 754, ĉi tio validas kiam la originala mantiso estis egala.
    pub inclusive: bool,
}

/// Deĉifrita sennoma valoro.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Senfinecoj, ĉu pozitivaj, ĉu negativaj.
    Infinite,
    /// Nulo, ĉu pozitiva ĉu negativa.
    Zero,
    /// Finiaj nombroj kun pliaj deĉifritaj kampoj.
    Finite(Decoded),
}

/// Glitkoma tipo, kiu povas esti "deĉifrita" d.
pub trait DecodableFloat: RawFloat + Copy {
    /// La minimuma pozitiva normaligita valoro.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Liveras signon (vera kiam negativa) kaj `FullDecoded`-valoron de donita glitkoma nombro.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // najbaroj: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode ĉiam konservas la eksponenton, do la mantiso estas skalita por subnormalaĵoj.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // najbaroj: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // kie maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // najbaroj: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}