//! Rust-adapto de la Grisu3-algoritmo priskribita en "Presado de glitkomaj nombroj rapide kaj precize per entjeroj" [^ 1].
//! Ĝi uzas ĉirkaŭ 1 KB de antaŭkomputita tablo, kaj siavice ĝi estas tre rapida por plej multaj enigaĵoj.
//!
//! [^1]: Florian Loitsch.2010. Presi glitkomajn numerojn rapide kaj
//!   precize kun entjeroj.SIGPLAN Ne.45, 6 (junio 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// vidu la komentojn en `format_shortest_opt` por la pravigo.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Donita `x > 0`, redonas `(k, 10^k)` tia, ke `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// La plej mallonga reĝima efektivigo por Grisu.
///
/// Ĝi redonas `None` kiam ĝi donus malprecizan reprezenton alie.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // ni bezonas almenaŭ tri bitojn da aldona precizeco

    // komencu per la normaligitaj valoroj kun la komuna eksponento
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // trovi ian `cached = 10^minusk` tian, ke `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // ĉar `plus` estas normaligita, ĉi tio signifas `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // donitaj al niaj elektoj de `ALPHA` kaj `GAMMA`, ĉi tio metas `plus * cached` en `[4, 2^32)`.
    //
    // evidente estas dezirinde maksimumigi `GAMMA - ALPHA`, tiel ke ni ne bezonas multajn kaŝmemorajn potencojn de 10, sed estas iuj konsideroj:
    //
    //
    // 1. ni volas konservi `floor(plus * cached)` ene de `u32`, ĉar ĝi bezonas multekostan dividon.
    //    (ĉi tio ne estas vere evitebla, cetero necesas por preciza takso.)
    // 2.
    // la resto de `floor(plus * cached)` plurfoje multiĝas per 10, kaj ĝi ne devas superflui.
    //
    // la unua donas `64 + GAMMA <= 32`, dum la dua donas `10 * 2^-ALPHA <= 2^64`;
    // -60 kaj -32 estas la maksimuma gamo kun ĉi tiu limo, kaj V8 ankaŭ uzas ilin.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // skalo fps.ĉi tio donas la maksimuman eraron de 1 ulp (pruvita de Teoremo 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-reala gamo de minus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // super `minus`, `v` kaj `plus` estas *kvantigitaj* aproksimadoj (eraro <1 ulp).
    // ĉar ni ne scias, ke la eraro estas pozitiva aŭ negativa, ni uzas du aproksimadojn interspacigitaj egale kaj havas la maksimuman eraron de 2 ulpoj.
    //
    // la "unsafe region" estas liberala intervalo, kiun ni komence generas.
    // la "safe region" estas konservativa intervalo, kiun ni nur akceptas.
    // ni komencas kun la ĝusta repr en la nesekura regiono, kaj provas trovi la plej proksiman repr al `v`, kiu ankaŭ estas en la sekura regiono.
    // se ni ne povas, ni rezignas.
    //
    let plus1 = plus.f + 1;
    // lasu plus0 = plus.f, 1;//nur por klarigo lasu minus0 = minus.f + 1;//nur por klarigo
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // komuna eksponento

    // dividu `plus1` en integrajn kaj frakciajn partojn.
    // integraj partoj estas garantiitaj por kongrui kun u32, ĉar kaŝmemora potenco garantias `plus < 2^32` kaj normaligita `plus.f` ĉiam malpli ol `2^64 - 2^4` pro la preciza postulo.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // kalkulu la plej grandan `10^max_kappa` ne pli ol `plus1` (do `plus1 < 10^(max_kappa+1)`).
    // ĉi tio estas supra rando de `kappa` sube.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teoremo 6.2: se `k` estas la plej granda entjero
    // `0 <= y mod 10^k <= y - x`,              tiam `V = floor(y / 10^k) * 10^k` estas en `[x, y]` kaj unu el la plej mallongaj reprezentoj (kun la minimuma nombro da signifaj ciferoj) en tiu intervalo.
    //
    //
    // trovi la ciferan longon `kappa` inter `(minus1, plus1)` laŭ Teoremo 6.2.
    // Teoremo 6.2 povas esti adoptita por ekskludi `x` postulante anstataŭe `y mod 10^k < y - x`.
    // (ekz. `x` =32000, `y` =32777; `kappa` =2 ĉar `y mod 10 ^ 3=777 <y, x=777`.) la algoritmo dependas de la posta kontrolfazo por ekskludi `y`.
    //
    let delta1 = plus1 - minus1;
    // lasu delta1int=(delta1>> e) kiel uzumi;//nur por klarigo
    let delta1frac = delta1 & ((1 << e) - 1);

    // redonu integrajn partojn, dum vi kontrolas la precizecon ĉe ĉiu paŝo.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // ciferoj ankoraŭ sendotaj
    loop {
        // ni ĉiam havas almenaŭ unu ciferon por bildigi, kiel `plus1 >= 10^kappa`-invariantoj:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (sekvas tiu `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // dividu `remainder` per `10^kappa`.ambaŭ estas skalitaj per `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; ni trovis la ĝustan `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // skalo 10 ^ kappa reen al la komuna eksponento
            return round_and_weed(
                // SEKURECO: ni pravalorizis tiun memoron supre.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // rompu la buklon kiam ni redonis ĉiujn integrajn ciferojn.
        // la ĝusta nombro de ciferoj estas `max_kappa + 1` kiel `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // restarigi invariantojn
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // redonu frakciajn partojn, dum vi kontrolas la precizecon ĉe ĉiu paŝo.
    // ĉi-foje ni fidas je ripetaj multiplikoj, ĉar divido perdos la precizecon.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // la sekva cifero devas esti signifa, ĉar ni provis tion antaŭ ol krevi invariantojn, kie `m = max_kappa + 1` (nombro da ciferoj en la integra parto):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ne superfluos, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // dividu `remainder` per `10^kappa`.
        // ambaŭ estas skalitaj per `2^e / 10^kappa`, do ĉi-lasta estas implicita ĉi tie.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // implicita dividanto
            return round_and_weed(
                // SEKURECO: ni pravalorizis tiun memoron supre.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // restarigi invariantojn
        kappa -= 1;
        remainder = r;
    }

    // ni generis ĉiujn signifajn ciferojn de `plus1`, sed ne certas, ĉu ĝi estas la plej bona.
    // ekzemple, se `minus1` estas 3.14153 ... kaj `plus1` estas 3.14158 ..., estas 5 malsamaj plej mallongaj prezentoj de 3.14154 al 3.14158 sed ni havas nur la plej grandan.
    // ni devas sinsekve malpliigi la lastan ciferon kaj kontroli ĉu ĉi tiu estas la optimuma repr.
    // estas maksimume 9 kandidatoj (..1 ĝis ..9), do ĉi tio estas sufiĉe rapida.("rounding"-fazo)
    //
    // la funkcio kontrolas ĉu ĉi tiu "optimal"-repr estas efektive ene de la ulp-intervaloj, kaj ankaŭ eblas, ke la "second-to-optimal"-repr povas efektive esti optimuma pro la rondiga eraro.
    // ambaŭkaze ĉi tio redonas `None`.
    // ("weeding"-fazo)
    //
    // ĉiuj argumentoj ĉi tie estas skalitaj per la komuna (sed implica) valoro `k`, tiel ke:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (kaj ankaŭ, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (kaj ankaŭ, `threshold > plus1v` de antaŭaj invariantoj)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // produkti du aproksimadojn al `v` (fakte `plus1 - v`) ene de 1.5-ulpoj.
        // la rezulta reprezento estu la plej proksima reprezentado al ambaŭ.
        //
        // ĉi tie `plus1 - v` estas uzata, ĉar kalkuloj estas faritaj rilate al `plus1` por eviti overflow/underflow (do la ŝajne interŝanĝitaj nomoj).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // malpliigu la lastan ciferon kaj haltu ĉe la plej proksima reprezento al `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // ni laboras kun la proksimumaj ciferoj `w(n)`, kiu komence egalas al `plus1 - plus1 % 10^kappa`.post ruli la buklan korpon `n` fojojn, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // ni starigas `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (do `resto= plus1w(0)`) por simpligi kontrolojn.
            // notu, ke `plus1w(n)` ĉiam pliiĝas.
            //
            // ni havas tri kondiĉojn por fini.iu el ili faros la buklon nekapabla daŭrigi, sed ni havas almenaŭ unu validan reprezenton, kiu estas plej proksima al `v + 1 ulp` ĉiuokaze.
            // ni indikos ilin kiel TC1 tra TC3 por mallongeco.
            //
            // TC1: `w(n) <= v + 1 ulp`, te, ĉi tiu estas la lasta reprodukto, kiu povas esti la plej proksima.
            // ĉi tio ekvivalentas al `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // kombinita kun TC2 (kiu kontrolas ĉu `w(n+1)` is valid), ĉi tio malebligas la eblan superfluaĵon en la kalkulo de `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, t.e., la sekva ripro certe ne rondiĝas al `v`.
            // ĉi tio ekvivalentas al `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // la maldekstra flanko povas superflui, sed ni konas `threshold > plus1v`, do se TC1 estas falsa, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` kaj ni povas sekure testi ĉu anstataŭe `threshold - plus1w(n) < 10^kappa`.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, te, la sekva repr estas
            // ne pli proksime al `v + 1 ulp` ol la nuna repr.
            // donita `z(n) = plus1v_up - plus1w(n)`, ĉi tio fariĝas `abs(z(n)) <= abs(z(n+1))`.denove supozante, ke TC1 estas malvera, ni havas `z(n) > 0`.ni havas du kazojn por konsideri:
            //
            // - kiam `z(n+1) >= 0`: TC3 fariĝas `z(n) <= z(n+1)`.
            // ĉar `plus1w(n)` pliiĝas, `z(n)` devas malpliiĝi kaj ĉi tio estas klare falsa.
            // - kiam `z(n+1) < 0`:
            //   - TC3a: la antaŭkondiĉo estas `plus1v_up < plus1w(n) + 10^kappa`.supozante, ke TC2 estas falsa, `threshold >= plus1w(n) + 10^kappa` do ĝi ne povas superflui.
            //   - TC3b: TC3 fariĝas `z(n) <= -z(n+1)`, t.e. `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   la neita TC1 donas `plus1v_up > plus1w(n)`, do ĝi ne povas superflui aŭ subflui kiam kombinita kun TC3a.
            //
            // sekve ni devas ĉesi kiam `TC1 || TC2 || (TC3a && TC3b)`.la sekvaĵo egalas al sia inversa, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // la plej mallonga reprodukto ne povas finiĝi per `0`
                plus1w += ten_kappa;
            }
        }

        // kontrolu ĉu ĉi tiu reprezento ankaŭ estas la plej proksima reprezentanto al `v - 1 ulp`.
        //
        // ĉi tio simple similas al la finaj kondiĉoj por `v + 1 ulp`, kun ĉiuj `plus1v_up` anstataŭigitaj per `plus1v_down` anstataŭe.
        // superflua analizo same validas.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // nun ni havas la plej proksiman reprezentadon al `v` inter `plus1` kaj `minus1`.
        // ĉi tio estas tro liberala, do ni malakceptas ajnan `w(n)` ne inter `plus0` kaj `minus0`, do `plus1 - plus1w(n) <= minus0` aŭ `plus1 - plus1w(n) >= plus0`.
        // ni uzas la faktojn, ke `threshold = plus1 - minus1` kaj `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// La plej mallonga reĝima efektivigo por Grisu kun Draka rezerva.
///
/// Ĉi tio devas esti uzata por plej multaj kazoj.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SEKURECO: La prunta kontrolilo ne estas sufiĉe inteligenta por permesi al ni uzi `buf`
    // en la dua branch, do ni lavas la vivon ĉi tie.
    // Sed ni nur reuzas `buf` se `format_shortest_opt` redonis `None` do ĉi tio estas en ordo.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// La ĝusta kaj fiksa reĝimo-efektivigo por Grisu.
///
/// Ĝi redonas `None` kiam ĝi donus malprecizan reprezenton alie.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // ni bezonas almenaŭ tri bitojn da aldona precizeco
    assert!(!buf.is_empty());

    // normaligi kaj skali `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // dividu `v` en integrajn kaj frakciajn partojn.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // ambaŭ malnovaj `v` kaj novaj `v` (skalitaj per `10^-k`) havas eraron <1 ulp (Teoremo 5.1).
    // ĉar ni ne scias, ke la eraro estas pozitiva aŭ negativa, ni uzas du aproksimadojn interspacigitaj egale kaj havas la maksimuman eraron de 2 ulpoj (same al la plej mallonga kazo).
    //
    //
    // la celo estas trovi la ekzakte rondigitan serion de ciferoj, kiuj estas komunaj al ambaŭ `v - 1 ulp` kaj `v + 1 ulp`, tiel ke ni maksimume certas.
    // se ĉi tio ne eblas, ni ne scias, kiu estas la ĝusta eliro por `v`, do ni rezignas kaj retiriĝas.
    //
    // `err` estas difinita kiel `1 ulp * 2^e` ĉi tie (same al la ulp en `vfrac`), kaj ni gramos ĝin kiam ajn `v` estos skalita.
    //
    //
    //
    let mut err = 1;

    // kalkulu la plej grandan `10^max_kappa` ne pli ol `v` (do `v < 10^(max_kappa+1)`).
    // ĉi tio estas supra rando de `kappa` sube.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // se ni laboras kun la lastcifera limigo, ni devas mallongigi la bufron antaŭ la efektiva bildigo por eviti duoblan rondigon.
    //
    // notu, ke ni devas pligrandigi la bufron denove kiam rondigo okazas!
    let len = if exp <= limit {
        // ho, ni eĉ ne povas produkti *unu* ciferon.
        // ĉi tio eblas kiam, ekzemple, ni havas ion kiel 9.5 kaj ĝi estas rondigita al 10.
        //
        // principe ni povas tuj voki `possibly_round` kun malplena bufro, sed skali `max_ten_kappa << e` per 10 povas rezultigi superfluon.
        //
        // tiel ni estas malzorgemaj ĉi tie kaj plilarĝigas la eraran gamon je faktoro 10.
        // ĉi tio pliigos la falsan negativan indicon, sed nur tre,*tre* iomete;
        // ĝi povas grave rimarki nur kiam la mantiso estas pli granda ol 60 bitoj.
        //
        // SEKURECO: `len=0`, do la devo esti pravalorizita ĉi tiun memoron estas bagatela.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // redonu integrajn partojn.
    // la eraro estas tute frakcia, do ni ne bezonas kontroli ĝin en ĉi tiu parto.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // ciferoj ankoraŭ sendotaj
    loop {
        // ni ĉiam havas almenaŭ unu ciferon por igi senvariantojn:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (sekvas tiu `remainder = vint % 10^(kappa+1)`)
        //
        //

        // dividu `remainder` per `10^kappa`.ambaŭ estas skalitaj per `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ĉu la bufro estas plena?kuru la rondigan enirpermesilon kun la resto.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SEKURECO: ni pravalorizis `len` multajn bajtojn.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // rompu la buklon kiam ni redonis ĉiujn integrajn ciferojn.
        // la ĝusta nombro de ciferoj estas `max_kappa + 1` kiel `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // restarigi invariantojn
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // redonu frakciajn partojn.
    //
    // principe ni povas daŭrigi ĝis la lasta disponebla cifero kaj kontroli la precizecon.
    // bedaŭrinde ni laboras kun la finhavaj entjeroj, do ni bezonas iun kriterion por detekti la superfluon.
    // V8 uzas `remainder > err`, kiu fariĝas falsa kiam la unuaj `i` signifaj ciferoj de `v - 1 ulp` kaj `v` malsamas.
    // tamen ĉi tio malakceptas tro multajn alie validajn enigaĵojn.
    //
    // ĉar la posta fazo havas ĝustan superfluan detekton, ni anstataŭe uzas pli striktan kriterion:
    // ni daŭras ĝis `err` superas `10^kappa / 2`, tiel ke la gamo inter `v - 1 ulp` kaj `v + 1 ulp` sendube enhavas du aŭ pli rondajn prezentojn.
    //
    // ĉi tio samas al la unuaj du komparoj de `possibly_round`, por la referenco.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // Invariantoj, kie `m = max_kappa + 1` (nombro da ciferoj en la integra parto):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ne superfluos, `2^e * 10 < 2^64`
        err *= 10; // ne superfluos, `err * 10 < 2^e * 5 < 2^64`

        // dividu `remainder` per `10^kappa`.
        // ambaŭ estas skalitaj per `2^e / 10^kappa`, do ĉi-lasta estas implicita ĉi tie.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ĉu la bufro estas plena?kuru la rondigan enirpermesilon kun la resto.
        if i == len {
            // SEKURECO: ni pravalorizis `len` multajn bajtojn.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // restarigi invariantojn
        remainder = r;
    }

    // plua kalkulo estas senutila (`possibly_round` certe malsukcesas), do ni rezignas.
    return None;

    // ni generis ĉiujn petitajn ciferojn de `v`, kiuj ankaŭ devas esti samaj al respondaj ciferoj de `v - 1 ulp`.
    // nun ni kontrolas ĉu estas unika reprezento dividita de ambaŭ `v - 1 ulp` kaj `v + 1 ulp`;ĉi tio povas esti egala al generitaj ciferoj, aŭ al la rondigita versio de tiuj ciferoj.
    //
    // se la gamo enhavas multoblajn prezentojn de la sama longo, ni ne povas esti certaj kaj anstataŭe redonu `None`.
    //
    // ĉiuj argumentoj ĉi tie estas skalitaj per la komuna (sed implica) valoro `k`, tiel ke:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SEKURECO: la unuaj `len`-bitokoj de `buf` devas esti pravalorizitaj.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (por la referenco, la punktita linio indikas la ĝustan valoron por eblaj reprezentoj en donita nombro de ciferoj.)
        //
        //
        // eraro estas tro granda, ke ekzistas almenaŭ tri eblaj reprezentoj inter `v - 1 ulp` kaj `v + 1 ulp`.
        // ni ne povas determini kiu ĝustas.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // fakte 1/2-ulp sufiĉas por enkonduki du eblajn reprezentojn.
        // (memoru, ke ni bezonas unikan prezenton por `v - 1 ulp` kaj `v + 1 ulp`.) ĉi tio ne superfluos, kiel `ulp < ten_kappa` de la unua kontrolo.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // se `v + 1 ulp` estas pli proksima al la rondigita malsupren-reprezento (kiu jam estas en `buf`), tiam ni povas sekure reveni.
        // notu, ke `v - 1 ulp`*povas* esti malpli ol la nuna reprezento, sed kiel `1 ulp < 10^kappa / 2`, ĉi tiu kondiĉo sufiĉas:
        // la distanco inter `v - 1 ulp` kaj la aktuala reprezento ne povas superi `10^kappa / 2`.
        //
        // la kondiĉo egalas al `remainder + ulp < 10^kappa / 2`.
        // ĉar ĉi tio povas facile superflui, unue kontrolu ĉu `remainder < 10^kappa / 2`.
        // ni jam kontrolis tiun `ulp < 10^kappa / 2`, do se `10^kappa` finfine ne superfluis, la dua kontrolo bonas.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SEKURECO: nia alvokanto pravalorizis tiun memoron.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------resto------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // aliflanke, se `v - 1 ulp` estas pli proksima al la rondigita reprezento, ni devas rondigi kaj reveni.
        // pro la sama kialo ni ne bezonas kontroli `v + 1 ulp`.
        //
        // la kondiĉo egalas al `remainder - ulp >= 10^kappa / 2`.
        // denove ni unue kontrolas ĉu `remainder > ulp` (rimarku, ke ĉi tio ne estas `remainder >= ulp`, ĉar `10^kappa` neniam estas nula).
        //
        // ankaŭ rimarku, ke `remainder - ulp <= 10^kappa`, do la dua kontrolo ne superfluas.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SEKURECO: nia alvokanto devas esti pravalorizinta tiun memoron.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // aldonu plian ciferon nur kiam oni petas nin pri la fiksa precizeco.
                // ni ankaŭ devas kontroli, ke, se la originala bufro estis malplena, la aldona cifero povas esti aldonita nur kiam `exp == limit` (kazo edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SEKURECO: ni kaj nia alvokanto pravalorizis tiun memoron.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // alie ni estas kondamnitaj (t.e. iuj valoroj inter `v - 1 ulp` kaj `v + 1 ulp` rondiĝas malsupren kaj aliaj rondiĝas supren) kaj rezignas.
        //
        None
    }
}

/// La ĝusta kaj fiksita reĝima efektivigo por Grisu kun Draka rezerva.
///
/// Ĉi tio devas esti uzata por plej multaj kazoj.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SEKURECO: La prunta kontrolilo ne estas sufiĉe inteligenta por permesi al ni uzi `buf`
    // en la dua branch, do ni lavas la vivon ĉi tie.
    // Sed ni nur reuzas `buf` se `format_exact_opt` redonis `None` do ĉi tio estas en ordo.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}