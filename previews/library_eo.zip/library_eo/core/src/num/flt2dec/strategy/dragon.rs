//! Preskaŭ rekta (sed iomete optimumigita) Rust-traduko de Figuro 3 de "Presi Glitkomajn Nombrojn Rapide kaj Precize" [^ 1].
//!
//!
//! [^1]: Burger, RG kaj Dybvig, RK 1996. Presantaj glitkomaj nombroj
//!   rapide kaj precize.SIGPLAN Ne.31, 5 (majo. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// antaŭkalkulitaj tabeloj de 'Ciferoj por 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// uzebla nur kiam `x < 16 * scale`;`scaleN` estu `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// La plej mallonga reĝima efektivigo por Drako.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // la formato `v` formatota estas:
    // - egala al `mant * 2^exp`;
    // - antaŭita de `(mant - 2 *minus)* 2^exp` en la originala tipo;kaj
    // - sekvita de `(mant + 2 *plus)* 2^exp` en la originala tipo.
    //
    // evidente, `minus` kaj `plus` ne povas esti nulaj.(por senfinoj, ni uzas eksterintervalajn valorojn.) ankaŭ ni supozas, ke almenaŭ unu cifero estas generita, te, `mant` ankaŭ ne povas esti nula.
    //
    // ĉi tio ankaŭ signifas, ke iu ajn nombro inter `low = (mant - minus)*2^exp` kaj `high = (mant + plus)* 2^exp` mapos al ĉi tiu ekzakta glitkoma nombro, kun limoj inkluzivitaj kiam la originala mantiso estis ebena (t.e. `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` estas `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // taksi `k_0` de originalaj enigaĵoj kontentigantaj `10^(k_0-1) < high <= 10^(k_0+1)`.
    // la streĉa `k` kontentiga `10^(k-1) < high <= 10^k` estas kalkulita poste.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // konverti `{mant, plus, minus} * 2^exp` al la frakcia formo tiel ke:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // dividu `mant` per `10^k`.nun `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // riparo kiam `mant + plus > scale` (aŭ `>=`).
    // ni fakte ne modifas `scale`, ĉar ni povas transsalti la komencan multiplikon anstataŭe.
    // nun `scale < mant + plus <= scale * 10` kaj ni pretas generi ciferojn.
    //
    // notu, ke `d[0]`*povas* esti nula, kiam `scale - plus < mant < scale`.
    // ĉi-kaze ĉirkaŭkondiĉo (`up` sube) tuj ekiĝos.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // ekvivalenta al skalo de `scale` je 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // kaŝmemoro `(2, 4, 8) * scale` por cifera generacio.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // Invariantoj, kie `d[0..n-1]` estas ciferoj generitaj ĝis nun:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (do `mant / scale < 10`) kie `d[i..j]` estas stenografio por `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // generi unu ciferon: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ĉi tio estas simpligita priskribo de la modifita Draka algoritmo.
        // multaj mezaj derivaĵoj kaj kompletecaj argumentoj estas preterlasitaj por facileco.
        //
        // komencu per modifitaj invariantoj, ĉar ni ĝisdatigis `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // supozu, ke `d[0..n-1]` estas la plej mallonga reprezento inter `low` kaj `high`, te `d[0..n-1]` kontentigas ambaŭ jenojn, sed `d[0..n-2]` ne:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijektiveco: ciferoj rondaj ĝis `v`);kaj
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (la lasta cifero ĝustas).
        //
        // la dua kondiĉo simpliĝas al `2 * mant <= scale`.
        // solvi invariantojn laŭ `mant`, `low` kaj `high` donas pli simplan version de la unua kondiĉo: `-plus < mant < minus`.
        // ekde `-plus < 0 <= mant`, ni havas la ĝustan plej mallongan reprezentadon kiam `mant < minus` kaj `2 * mant <= scale`.
        // (la unua fariĝas `mant <= minus` kiam la originala mantiso estas ebena.)
        //
        // kiam la dua ne tenas (`2 * mant> skalo`), ni bezonas pliigi la lastan ciferon.
        // ĉi tio sufiĉas por restarigi tiun kondiĉon: ni jam scias, ke la cifera generacio garantias `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // ĉi-kaze la unua kondiĉo fariĝas `-plus < mant - scale < minus`.
        // ekde `mant < scale` post la generacio, ni havas `scale < mant + plus`.
        // (denove ĉi tio fariĝas `scale <= mant + plus` kiam la originala mantiso egalas.)
        //
        // mallonge:
        // - halti kaj rondigi `down` (konservu ciferojn tiajn) kiam `mant < minus` (aŭ `<=`).
        // - halti kaj rondigi `up` (pliigi la lastan ciferon) kiam `scale < mant + plus` (aŭ `<=`).
        // - daŭre generas alimaniere.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // ni havas la plej mallongan reprezentadon, iru al la rondigo

        // restarigu la invariantojn.
        // ĉi tio igas la algoritmon ĉiam finiĝi: `minus` kaj `plus` ĉiam pliiĝas, sed `mant` estas tondita modulo `scale` kaj `scale` estas riparita.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // rondigo okazas kiam i) nur la rondiga stato ekiĝis, aŭ ii) ambaŭ kondiĉoj ekiĝis kaj egaleco preferas rondigi supren.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // se rondigo supren ŝanĝas la longon, la eksponento ankaŭ ŝanĝiĝu.
        // ŝajnas, ke ĉi tiu kondiĉo estas tre malfacile kontentigebla (eble malebla), sed ni nur estas sekuraj kaj konsekvencaj ĉi tie.
        //
        // SEKURECO: ni pravalorizis tiun memoron supre.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SEKURECO: ni pravalorizis tiun memoron supre.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// La ĝusta kaj fiksa reĝima efektivigo por Drako.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // taksi `k_0` de originalaj enigaĵoj kontentigantaj `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // dividu `mant` per `10^k`.nun `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // riparo kiam `mant + plus >= scale`, kie `plus / scale = 10^-buf.len() / 2`.
    // por konservi la fiksan grandecon, ni efektive uzas `mant + floor(plus) >= scale`.
    // ni fakte ne modifas `scale`, ĉar ni povas transsalti la komencan multiplikon anstataŭe.
    // denove per la plej mallonga algoritmo, `d[0]` povas esti nula, sed eventuale rondigita.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // ekvivalenta al skalo de `scale` je 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // se ni laboras kun la lastcifera limigo, ni devas mallongigi la bufron antaŭ la efektiva bildigo por eviti duoblan rondigon.
    //
    // notu, ke ni devas pligrandigi la bufron denove kiam rondigo okazas!
    let mut len = if k < limit {
        // ho, ni eĉ ne povas produkti *unu* ciferon.
        // ĉi tio eblas kiam, ekzemple, ni havas ion kiel 9.5 kaj ĝi estas rondigita al 10.
        // ni redonas malplenan bufron, escepte de la posta ronda kazo, kiu okazas kiam `k == limit` kaj devas produkti ĝuste unu ciferon.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // kaŝmemoro `(2, 4, 8) * scale` por cifera generacio.
        // (ĉi tio povas esti multekosta, do ne kalkulu ilin kiam la bufro estas malplena.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // jenaj ciferoj estas ĉiuj nuloj, ni ĉesas ĉi tie ne * provu plenumi rondigon!prefere plenigu ceterajn ciferojn.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SEKURECO: ni pravalorizis tiun memoron supre.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // rondigo supren se ni haltas meze de ciferoj se la sekvaj ciferoj estas ekzakte 5000 ..., kontrolu la antaŭan ciferon kaj provu rondigi al para (t.e. eviti rondigi supren kiam la antaŭa cifero estas egala).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SEKURECO: `buf[len-1]` estas pravalorizita.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // se rondigo supren ŝanĝas la longon, la eksponento ankaŭ ŝanĝiĝu.
        // sed oni petis al ni fiksitan nombron da ciferoj, do ne ŝanĝu la bufron ...
        // SEKURECO: ni pravalorizis tiun memoron supre.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... krom se oni petis nin pri la fiksa precizeco anstataŭe.
            // ni ankaŭ devas kontroli, ke, se la originala bufro estis malplena, la aldona cifero povas esti aldonita nur kiam `k == limit` (kazo edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SEKURECO: ni pravalorizis tiun memoron supre.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}