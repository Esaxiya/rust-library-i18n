//! Konstantoj por la montrilo-granda sennoma entjerspeco.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Nova kodo devas uzi la asociitajn konstantojn rekte sur la primitiva tipo.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }