#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` permesas al la efektiviganto de taskekzekutisto krei [`Waker`], kiu provizas personecigitan vekan konduton.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Ĝi konsistas el datuma montrilo kaj [virtual function pointer table (vtable)][vtable], kiu agordas la konduton de la `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Datuma montrilo, uzebla por stoki arbitrajn datumojn, kiel postulas la ekzekutisto.
    /// Ĉi tio povus esti ekz
    /// tajpita montrilo al `Arc` asociita kun la tasko.
    /// La valoro de ĉi tiu kampo estas transdonita al ĉiuj funkcioj, kiuj estas parto de la tabelo kiel la unua parametro.
    ///
    data: *const (),
    /// Virtuala funkcio montrila tablo, kiu agordas la konduton de ĉi tiu waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Kreas novan `RawWaker` de la provizita `data`-montrilo kaj `vtable`.
    ///
    /// La montrilo `data` povas esti uzata por stoki arbitrajn datumojn, kiel postulas la ekzekutisto.Ĉi tio povus esti ekz
    /// tajpita montrilo al `Arc` asociita kun la tasko.
    /// La valoro de ĉi tiu montrilo estos transdonita al ĉiuj funkcioj, kiuj estas parto de la `vtable` kiel la unua parametro.
    ///
    /// La `vtable` adaptas la konduton de `Waker` kreita de `RawWaker`.
    /// Por ĉiu operacio sur la `Waker`, la rilata funkcio en la `vtable` de la suba `RawWaker` estos vokita.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Virtuala funkcia montrila tablo (vtable), kiu specifas la konduton de [`RawWaker`].
///
/// La montrilo pasita al ĉiuj funkcioj ene de la tabelo estas la montrilo `data` de la ĉirkaŭa objekto [`RawWaker`].
///
/// La funkcioj ene de ĉi tiu strukt nur celas esti nomataj per la montrilo `data` de taŭge konstruita [`RawWaker`]-objekto de interne de la efektivigo de [`RawWaker`].
/// Voki unu el la enhavitaj funkcioj per iu ajn alia `data`-montrilo kaŭzos nedifinitan konduton.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Ĉi tiu funkcio estos nomata kiam la [`RawWaker`] estas klonita, ekz. Kiam la [`Waker`] en kiu estas konservita la [`RawWaker`] estas klonita.
    ///
    /// La efektivigo de ĉi tiu funkcio devas konservi ĉiujn rimedojn necesajn por ĉi tiu aldona kazo de [`RawWaker`] kaj rilata tasko.
    /// Voki `wake` per la rezulta [`RawWaker`] devas rezultigi vekon de la sama tasko, kiu estus vekita de la originala [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Ĉi tiu funkcio estos nomata kiam `wake` estas vokita sur la [`Waker`].
    /// Ĝi devas veki la taskon asociitan kun ĉi tiu [`RawWaker`].
    ///
    /// La efektivigo de ĉi tiu funkcio devas certigi liberigi iujn ajn rimedojn asociitajn kun ĉi tiu kazo de [`RawWaker`] kaj rilata tasko.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Ĉi tiu funkcio estos nomata kiam `wake_by_ref` estas vokita sur la [`Waker`].
    /// Ĝi devas veki la taskon asociitan kun ĉi tiu [`RawWaker`].
    ///
    /// Ĉi tiu funkcio similas al `wake`, sed ne devas konsumi la provizitan datuman montrilon.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Ĉi tiu funkcio nomiĝas kiam [`RawWaker`] falas.
    ///
    /// La efektivigo de ĉi tiu funkcio devas certigi liberigi iujn ajn rimedojn asociitajn kun ĉi tiu kazo de [`RawWaker`] kaj rilata tasko.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Kreas novan `RawWakerVTable` de la provizitaj `clone`, `wake`, `wake_by_ref` kaj `drop`-funkcioj.
    ///
    /// # `clone`
    ///
    /// Ĉi tiu funkcio estos nomata kiam la [`RawWaker`] estas klonita, ekz. Kiam la [`Waker`] en kiu estas konservita la [`RawWaker`] estas klonita.
    ///
    /// La efektivigo de ĉi tiu funkcio devas konservi ĉiujn rimedojn necesajn por ĉi tiu aldona kazo de [`RawWaker`] kaj rilata tasko.
    /// Voki `wake` per la rezulta [`RawWaker`] devas rezultigi vekon de la sama tasko, kiu estus vekita de la originala [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Ĉi tiu funkcio estos nomata kiam `wake` estas vokita sur la [`Waker`].
    /// Ĝi devas veki la taskon asociitan kun ĉi tiu [`RawWaker`].
    ///
    /// La efektivigo de ĉi tiu funkcio devas certigi liberigi iujn ajn rimedojn asociitajn kun ĉi tiu kazo de [`RawWaker`] kaj rilata tasko.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Ĉi tiu funkcio estos nomata kiam `wake_by_ref` estas vokita sur la [`Waker`].
    /// Ĝi devas veki la taskon asociitan kun ĉi tiu [`RawWaker`].
    ///
    /// Ĉi tiu funkcio similas al `wake`, sed ne devas konsumi la provizitan datuman montrilon.
    ///
    /// # `drop`
    ///
    /// Ĉi tiu funkcio nomiĝas kiam [`RawWaker`] falas.
    ///
    /// La efektivigo de ĉi tiu funkcio devas certigi liberigi iujn ajn rimedojn asociitajn kun ĉi tiu kazo de [`RawWaker`] kaj rilata tasko.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// La `Context` de nesinkrona tasko.
///
/// Nuntempe `Context` nur servas por doni aliron al `&Waker`, kiu povas esti uzata por veki la nunan taskon.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Certigu, ke ni future-pruvas kontraŭ variancaj ŝanĝoj devigante la vivon esti neŝanĝebla (argument-poziciaj vivdaŭroj estas kontraŭvariaj dum revenpoziciaj vivdaŭroj estas kunvariaj).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Kreu novan `Context` de `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Liveras referencon al la `Waker` por la aktuala tasko.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` estas tenilo por veki taskon, sciigante al sia ekzekutisto, ke ĝi pretas funkciigi.
///
/// Ĉi tiu tenilo enkapsuligas [`RawWaker`]-kazon, kiu difinas la ekzekutan specifan vekan konduton.
///
///
/// Efektivigas [`Clone`], [`Send`] kaj [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Veku la taskon asociitan kun ĉi tiu `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // La efektiva vekvoko estas delegita per virtuala funkciovoko al la efektivigo difinita de la ekzekutisto.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Ne voku `drop`-la vekanto estos konsumita de `wake`.
        crate::mem::forget(self);

        // SEKURECO: Ĉi tio estas sekura ĉar `Waker::from_raw` estas la sola maniero
        // pravalorizi `wake` kaj `data` devigante la uzanton agnoski ke la kontrakto de `RawWaker` estas konfirmita.
        //
        unsafe { (wake)(data) };
    }

    /// Veku la taskon asociitan kun ĉi tiu `Waker` sen foruzi la `Waker`.
    ///
    /// Ĉi tio similas al `wake`, sed povas esti iomete malpli efika en la kazo, ke posedata `Waker` estas havebla.
    /// Ĉi tiu metodo devas esti preferata al voko al `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // La efektiva vekvoko estas delegita per virtuala funkciovoko al la efektivigo difinita de la ekzekutisto.
        //

        // SEKURECO: vidu `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Liveras `true` se ĉi tiu `Waker` kaj alia `Waker` vekis la saman taskon.
    ///
    /// Ĉi tiu funkcio funkcias laŭ plej bona klopodo, kaj eble revenos malvera eĉ kiam la `Waker` vekus la saman taskon.
    /// Tamen, se ĉi tiu funkcio redonas `true`, estas garantiite, ke la `Waker` vekos la saman taskon.
    ///
    /// Ĉi tiu funkcio estas ĉefe uzata por optimumigo.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Kreas novan `Waker` de [`RawWaker`].
    ///
    /// La konduto de la redonita `Waker` estas nedifinita se la kontrakto difinita en la dokumentaro de ["RawWaker"] kaj ["RawWakerVTable"] ne estas konfirmita.
    ///
    /// Tial ĉi tiu metodo estas nesekura.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SEKURECO: Ĉi tio estas sekura ĉar `Waker::from_raw` estas la sola maniero
            // pravalorizi `clone` kaj `data` devigante la uzanton agnoski ke la kontrakto de [`RawWaker`] estas konfirmita.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SEKURECO: Ĉi tio estas sekura ĉar `Waker::from_raw` estas la sola maniero
        // pravalorizi `drop` kaj `data` devigante la uzanton agnoski ke la kontrakto de `RawWaker` estas konfirmita.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}