//! La libcore prelude
//!
//! Ĉi tiu modulo estas destinita al uzantoj de libcore, kiuj ankaŭ ne ligas al libstd.
//! Ĉi tiu modulo estas importita defaŭlte kiam `#![no_std]` estas uzata same kiel prelude de la norma biblioteko.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// La 2015-versio de la kerno prelude.
///
/// Vidu la [module-level documentation](self) por pli.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// La 2018-versio de la kerno prelude.
///
/// Vidu la [module-level documentation](self) por pli.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// La 2021-versio de la kerno prelude.
///
/// Vidu la [module-level documentation](self) por pli.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Aldonu pli da aferoj.
}