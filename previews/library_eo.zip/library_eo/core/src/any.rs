//! Ĉi tiu modulo efektivigas la `Any` trait, kiu ebligas dinamikan tajpadon de iu ajn `'static`-tipo per rultempa pripensado.
//!
//! `Any` mem povas esti uzata por akiri `TypeId`, kaj havas pli da funkcioj kiam ĝi estas uzata kiel objekto trait.
//! Kiel `&dyn Any` (pruntita trait objekto), ĝi havas la metodojn `is` kaj `downcast_ref`, por testi ĉu la enhavita valoro estas de donita tipo, kaj por ricevi referencon al la interna valoro kiel tipo.
//! Kiel `&mut dyn Any`, ekzistas ankaŭ la `downcast_mut`-metodo, por ricevi ŝanĝeblan referencon al la interna valoro.
//! `Box<dyn Any>` aldonas la `downcast`-metodon, kiu provas transformi al `Box<T>`.
//! Vidu la [`Box`]-dokumentaron por la plenaj detaloj.
//!
//! Notu, ke `&dyn Any` limiĝas al testado ĉu valoro estas de specifa konkreta tipo, kaj ne povas esti uzata por testi ĉu tipo efektivigas trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Inteligentaj montriloj kaj `dyn Any`
//!
//! Memorinda konduto dum uzado de `Any` kiel trait-objekto, precipe kun specoj kiel `Box<dyn Any>` aŭ `Arc<dyn Any>`, estas ke simple nomi `.type_id()` per la valoro produktos la `TypeId` de la *ujo*, ne la subesta trait-objekto.
//!
//! Ĉi tio evitas per konverti la inteligentan montrilon en `&dyn Any` anstataŭe, kiu redonos `TypeId` de la objekto.
//! Ekzemple:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Vi pli probable volas ĉi tion:
//! let actual_id = (&*boxed).type_id();
//! // ... ol ĉi tio:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Konsideru situacion, kie ni volas elsaluti valoron transdonitan al funkcio.
//! Ni scias la valoron, pri kiu ni laboras, por efektivigi Debug, sed ni ne scias ĝian konkretan tipon.Ni volas doni specialan traktadon al iuj tipoj: ĉi-kaze presi la longon de String-valoroj antaŭ ilia valoro.
//! Ni ne konas la konkretan tipon de nia valoro dum kompila tempo, do ni devas uzi rultempan reflektadon anstataŭe.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Funkciigilo por iu ajn tipo, kiu efektivigas Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Provu konverti nian valoron al `String`.
//!     // Se sukcesas, ni volas eligi la longon de la Ŝnuro same kiel ĝian valoron.
//!     // Se ne, ĝi estas alia tipo: simple presu ĝin senornama.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ĉi tiu funkcio volas elsaluti sian parametron antaŭ ol labori kun ĝi.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... faru iun alian laboron
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Ajna trait
///////////////////////////////////////////////////////////////////////////////

/// trait por kopii dinamikan tajpadon.
///
/// Plej multaj specoj efektivigas `Any`.Tamen iu ajn tipo, kiu enhavas ne "statikan" referencon, ne.
/// Vidu la [module-level documentation][mod] por pli da detaloj.
///
/// [mod]: crate::any
// Ĉi tiu trait ne estas nesekura, kvankam ni fidas je la specifaĵoj de ĝia sola impl-a `type_id`-funkcio en nesekura kodo (ekz. `downcast`).Kutime tio estus problemo, sed ĉar la sola impl de `Any` estas kovrila efektivigo, neniu alia kodo povas efektivigi `Any`.
//
// Ni povus kredinde igi ĉi tiun trait nesekura-ĝi ne kaŭzus rompiĝon, ĉar ni regas ĉiujn efektivigojn-sed ni elektas ne fari tion, ĉar tio ne vere necesas kaj povas konfuzi uzantojn pri la distingo de nesekuraj traits kaj nesekuraj metodoj (t.e. `type_id` ankoraŭ estus sekure telefonebla, sed ni probable volus indiki kiel tian en dokumentado).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Akiras la `TypeId` de `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Etendaĵmetodoj por Ajna trait-objektoj.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Certigu, ke la rezulto de ekz. Kunigo de fadeno povas esti presita kaj tial uzata kun `unwrap`.
// Majo eventuale ne plu bezonos se forsendo funkcias kun supertuto.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Liveras `true` se la boksita tipo estas la sama kiel `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Akiru `TypeId` de la tipo kun kiu ĉi tiu funkcio estas kreita.
        let t = TypeId::of::<T>();

        // Akiru `TypeId` de la tipo en la objekto trait (`self`).
        let concrete = self.type_id();

        // Komparu ambaŭ 'TypeId`s pri egaleco.
        t == concrete
    }

    /// Liveras ian referencon al la boksita valoro se ĝi estas de tipo `T`, aŭ `None` se ĝi ne estas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SEKURECO: nur kontrolis, ĉu ni celas la ĝustan tipon, kaj ni povas fidi
            // tio kontrolas pri memora sekureco ĉar ni efektivigis Iu ajn por ĉiuj specoj;neniu alia implico povas ekzisti, ĉar ili konfliktus kun nia impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Liveras iun ŝanĝeblan referencon al la boksita valoro se ĝi estas de tipo `T`, aŭ `None` se ĝi ne estas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SEKURECO: nur kontrolis, ĉu ni celas la ĝustan tipon, kaj ni povas fidi
            // tio kontrolas pri memora sekureco ĉar ni efektivigis Iu ajn por ĉiuj specoj;neniu alia implico povas ekzisti, ĉar ili konfliktus kun nia impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Antaŭen al la metodo difinita sur la tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Antaŭen al la metodo difinita sur la tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Antaŭen al la metodo difinita sur la tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Antaŭen al la metodo difinita sur la tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Antaŭen al la metodo difinita sur la tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Antaŭen al la metodo difinita sur la tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID kaj ĝiaj metodoj
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` reprezentas tutmondan unikan identigilon por tipo.
///
/// Ĉiu `TypeId` estas maldiafana objekto, kiu ne permesas inspekti tion, kio enhavas, sed permesas bazajn operaciojn kiel klonado, komparo, presado kaj montrado.
///
///
/// `TypeId` nuntempe disponeblas nur por specoj atribuitaj al `'static`, sed ĉi tiu limigo eble estos forigita en la future.
///
/// Dum `TypeId` efektivigas `Hash`, `PartialOrd` kaj `Ord`, indas rimarki, ke la hakiloj kaj mendado varias inter eldonoj de Rust.
/// Gardu vin fidi ilin interne de via kodo!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Liveras la `TypeId` de la tipo kun kiu ĉi tiu ĝenerala funkcio estis kreita.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Liveras la nomon de tipo kiel ĉena tranĉaĵo.
///
/// # Note
///
/// Ĉi tio estas destinita por diagnoza uzo.
/// La ĝustaj enhavoj kaj formato de la redaktita ĉeno ne estas specifitaj, krom esti plej bona peno-priskribo de la tipo.
/// Ekzemple, inter la ĉenoj, kiujn `type_name::<Option<String>>()` povus redoni, estas `"Option<String>"` kaj `"std::option::Option<std::string::String>"`.
///
///
/// La redonita ĉeno ne rajtas esti konsiderata kiel unika identigilo de tipo, ĉar multaj tipoj povas mapi al la sama tipo-nomo.
/// Simile, ne garantias, ke ĉiuj partoj de tipo aperos en la redonita ĉeno: ekzemple, dumvivaj specifiloj nuntempe ne estas inkluzivitaj.
/// Krome la eligo povas ŝanĝiĝi inter versioj de la kompililo.
///
/// La nuna efektivigo uzas la saman infrastrukturon kiel kompilaj diagnozoj kaj debuginfo, sed ĉi tio ne estas garantiita.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Liveras la nomon de la tipo de la indikita-valoro kiel ĉena tranĉaĵo.
/// Ĉi tio estas la sama kiel `type_name::<T>()`, sed uzeblas kie la speco de variablo ne facile haveblas.
///
/// # Note
///
/// Ĉi tio estas destinita por diagnoza uzo.La ĝustaj enhavoj kaj formato de la ĉeno ne estas specifitaj, krom esti plej bona peno-priskribo de la tipo.
/// Ekzemple, `type_name_of_val::<Option<String>>(None)` povus redoni `"Option<String>"` aŭ `"std::option::Option<std::string::String>"`, sed ne `"foobar"`.
///
/// Krome la eligo povas ŝanĝiĝi inter versioj de la kompililo.
///
/// Ĉi tiu funkcio ne solvas objektojn trait, kio signifas, ke `type_name_of_val(&7u32 as &dyn Debug)` eble redonos `"dyn Debug"`, sed ne `"u32"`.
///
/// La tipa nomo ne devas esti konsiderata unika identigilo de tipo;
/// pluraj tipoj povas dividi la saman tipan nomon.
///
/// La nuna efektivigo uzas la saman infrastrukturon kiel kompilaj diagnozoj kaj debuginfo, sed ĉi tio ne estas garantiita.
///
/// # Examples
///
/// Presas la defaŭltajn entjerajn kaj flosajn specojn.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}