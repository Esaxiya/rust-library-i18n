//! Difinas utf8-eraran tipon.

use crate::fmt;

/// Eraroj, kiuj povas okazi dum provo interpreti sinsekvon de [`u8`] kiel ĉeno.
///
/// Kiel tia, la `from_utf8`-familio de funkcioj kaj metodoj por kaj [`String`] s kaj [`&str`] s uzas ĉi tiun eraron, ekzemple.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// La metodoj de ĉi tiu erara tipo povas esti uzataj por krei funkciojn similajn al `String::from_utf8_lossy` sen asigni amason da memoro:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Liveras la indekson en la donita ĉeno ĝis kiu validis UTF-8.
    ///
    /// Ĝi estas la maksimuma indekso tia, ke `from_utf8(&input[..index])` redonos `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::str;
    ///
    /// // iuj nevalidaj bajtoj, en vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 redonas Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // la dua bajto ne validas ĉi tie
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Provizas pli da informoj pri la fiasko:
    ///
    /// * `None`: la fino de la enigo estis atingita neatendite.
    ///   `self.valid_up_to()` estas 1 ĝis 3 bajtoj de la fino de la enigo.
    ///   Se bajta fluo (kiel dosiero aŭ reta ingo) malkodiĝas laŭgrade, tio povus esti valida `char` kies UTF-8-bajta sinsekvo ampleksas plurajn pecojn.
    ///
    ///
    /// * `Some(len)`: neatendita bajto estis renkontita.
    ///   La longo donita estas tiu de la nevalida bajta sinsekvo, kiu komenciĝas ĉe la indekso donita de `valid_up_to()`.
    ///   Malkodado rekomenciĝu post tiu sinsekvo (post enmetado de [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) en kazo de perda malkodado.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Eraro revenis dum analizado de `bool` uzanta [`from_str`] malsukcesas
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}