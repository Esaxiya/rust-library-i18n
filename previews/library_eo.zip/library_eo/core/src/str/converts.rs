//! Manieroj krei `str` de bitokta tranĉaĵo.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Konvertas tranĉaĵon de bajtoj al ĉena tranĉaĵo.
///
/// Ĉena tranĉaĵo ([`&str`]) estas farita de bajtoj ([`u8`]), kaj bajta tranĉaĵo ([`&[u8]`][byteslice]) estas farita de bajtoj, do ĉi tiu funkcio konvertiĝas inter la du.
/// Ne ĉiuj bajtaj tranĉaĵoj estas validaj ĉenaj tranĉaĵoj, tamen: [`&str`] postulas, ke ĝi validas UTF-8.
/// `from_utf8()` kontrolas por certigi, ke la bajtoj validas UTF-8, kaj poste faras la konvertiĝon.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Se vi certas, ke la bajta tranĉaĵo estas valida UTF-8, kaj vi ne volas provoki la superkoston de la valideco-kontrolo, ekzistas nesekura versio de ĉi tiu funkcio, [`from_utf8_unchecked`], kiu havas la saman konduton sed preterlasas la kontrolon.
///
///
/// Se vi bezonas `String` anstataŭ `&str`, konsideru [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Ĉar vi povas stakigi `[u8; N]`, kaj vi povas preni [`&[u8]`][byteslice] de ĝi, ĉi tiu funkcio estas unu maniero havi stakan ĉenon.Estas ekzemplo pri tio en la sekva ekzempla sekcio.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Liveras `Err` se la tranĉaĵo ne estas UTF-8 kun priskribo kial la provizita tranĉaĵo ne estas UTF-8.
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// use std::str;
///
/// // iuj bajtoj, en vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Ni scias, ke ĉi tiuj bajtoj validas, do simple uzu `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Malĝustaj bajtoj:
///
/// ```
/// use std::str;
///
/// // iuj nevalidaj bajtoj, en vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Vidu la dokumentojn por [`Utf8Error`] por pliaj detaloj pri la specoj de resendindaj eraroj.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // iuj bajtoj, en stak-asignita tabelo
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Ni scias, ke ĉi tiuj bajtoj validas, do simple uzu `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SEKURECO: Nur validis validon.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Konvertas ŝanĝeblan tranĉaĵon de bajtoj al ŝanĝebla ĉena tranĉaĵo.
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" kiel ŝanĝebla vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Ĉar ni scias, ke ĉi tiuj bajtoj validas, ni povas uzi `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Malĝustaj bajtoj:
///
/// ```
/// use std::str;
///
/// // Iuj nevalidaj bajtoj en ŝanĝebla vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Vidu la dokumentojn por [`Utf8Error`] por pliaj detaloj pri la specoj de resendindaj eraroj.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SEKURECO: Nur validis validon.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Konvertas tranĉaĵon de bajtoj al ĉena tranĉaĵo sen kontroli, ke la ĉeno enhavas validan UTF-8.
///
/// Vidu la sekuran version, [`from_utf8`], por pliaj informoj.
///
/// # Safety
///
/// Ĉi tiu funkcio estas nesekura ĉar ĝi ne kontrolas, ke la bajtoj transdonitaj al ĝi estas validaj UTF-8.
/// Se ĉi tiu limo estas malobservita, nedifinitaj kondutoj rezultas, ĉar la resto de Rust supozas, ke [`&str`] estas validaj UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// use std::str;
///
/// // iuj bajtoj, en vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SEKURECO: la alvokanto devas garantii, ke la bajtoj `v` validas UTF-8.
    // Ankaŭ dependas de `&str` kaj `&[u8]` havantaj la saman aranĝon.
    unsafe { mem::transmute(v) }
}

/// Konvertas tranĉaĵon de bajtoj al ĉena tranĉaĵo sen kontroli, ke la ĉeno enhavas validan UTF-8;ŝanĝebla versio.
///
///
/// Vidu la neŝanĝeblan version [`from_utf8_unchecked()`] por pliaj informoj.
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SEKURECO: la alvokanto devas garantii, ke la bajtoj `v`
    // validas UTF-8, do la rolantaro al `*mut str` estas sekura.
    // Ankaŭ la montrila malreferenco estas sekura ĉar tiu montrilo venas de referenco, kiu estas garantiita esti valida por skriboj.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}