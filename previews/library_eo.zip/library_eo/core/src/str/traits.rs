//! Efektivigoj de Trait por `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Efektivigas ordigon de kordoj.
///
/// Kordoj estas ordigitaj [lexicographically](Ord#lexicographical-comparison) laŭ iliaj bajtaj valoroj.
/// Ĉi tio ordigas unikodajn kodajn punktojn laŭ iliaj pozicioj en la kodaj diagramoj.
/// Ĉi tio ne nepre samas kiel "alphabetical"-ordo, kiu varias laŭ lingvo kaj loka loko.
/// Ordigi ĉenojn laŭ kulture akceptitaj normoj postulas lok-specifajn datumojn ekster la amplekso de la `str`-tipo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Efektivigas komparajn operaciojn sur kordoj.
///
/// Ŝnuroj estas komparitaj [lexicographically](Ord#lexicographical-comparison) per siaj bajtaj valoroj.
/// Ĉi tio komparas unikodajn kodpunktojn laŭ iliaj pozicioj en la kodaj diagramoj.
/// Ĉi tio ne nepre samas kiel "alphabetical"-ordo, kiu varias laŭ lingvo kaj loka loko.
/// Kompari ĉenojn laŭ kulture akceptitaj normoj postulas lok-specifajn datumojn ekster la amplekso de la `str`-tipo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Efektivigas subĉenajn tranĉaĵojn per sintakso `&self[..]` aŭ `&mut self[..]`.
///
/// Liveras tranĉaĵon de la tuta ĉeno, te, redonas `&self` aŭ `&mut self`.Ekvivalenta al `&memo [0 ..
/// len] `aŭ`&mut mem [0 ..
/// len]`.
/// Male al aliaj indeksaj operacioj, ĉi tio neniam povas panic.
///
/// Ĉi tiu operacio estas *O*(1).
///
/// Antaŭ 1.20.0, ĉi tiuj indeksaj operacioj ankoraŭ subtenis rektan efektivigon de `Index` kaj `IndexMut`.
///
/// Ekvivalenta al `&self[0 .. len]` aŭ `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Efektivigas subĉenajn tranĉaĵojn per sintakso `&self[begin .. end]` aŭ `&mut self[begin .. end]`.
///
/// Liveras tranĉaĵon de la donita ĉeno el la bajta intervalo [`begin`, `end`).
///
/// Ĉi tiu operacio estas *O*(1).
///
/// Antaŭ 1.20.0, ĉi tiuj indeksaj operacioj ankoraŭ subtenis rektan efektivigon de `Index` kaj `IndexMut`.
///
/// # Panics
///
/// Panics se `begin` aŭ `end` ne montras al la komenca bajta ofseto de signo (kiel difinita de `is_char_boundary`), se `begin > end`, aŭ se `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ĉi tiuj faros panic:
/// // bajto 2 kuŝas ene de `ö`:
/// // &s [2 ..3];
///
/// // bajto 8 kuŝas ene de `老`&s [1 ..
/// // 8];
///
/// // bajto 100 estas ekster la ĉeno&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEKURECO: ĵus kontrolis, ke `start` kaj `end` estas sur limo de signoj,
            // kaj ni sendas sekuran referencon, do la revenvaloro ankaŭ estos unu.
            // Ni ankaŭ kontrolis karajn limojn, do ĉi tio validas UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEKURECO: ĵus kontrolis, ke `start` kaj `end` estas sur limo de signoj.
            // Ni scias, ke la montrilo estas unika, ĉar ni akiris ĝin de `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SEKURECO: la alvokanto garantias, ke `self` estas en limoj de `slice`
        // kiu kontentigas ĉiujn kondiĉojn por `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SEKURECO: vidu komentojn por `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary kontrolas, ke la indekso estas en [0, .len()] ne povas reuzi `get` kiel supre, pro NLL-problemo
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEKURECO: ĵus kontrolis, ke `start` kaj `end` estas sur limo de signoj,
            // kaj ni sendas sekuran referencon, do la revenvaloro ankaŭ estos unu.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Efektivigas subĉenajn tranĉaĵojn per sintakso `&self[.. end]` aŭ `&mut self[.. end]`.
///
/// Liveras tranĉaĵon de la donita ĉeno el la bajta intervalo [`0`, `end`).
/// Ekvivalenta al `&self[0 .. end]` aŭ `&mut self[0 .. end]`.
///
/// Ĉi tiu operacio estas *O*(1).
///
/// Antaŭ 1.20.0, ĉi tiuj indeksaj operacioj ankoraŭ subtenis rektan efektivigon de `Index` kaj `IndexMut`.
///
/// # Panics
///
/// Panics se `end` ne montras al la komenca bajta ofseto de signo (kiel difinita de `is_char_boundary`), aŭ se `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SEKURECO: ĵus kontrolis, ke `end` estas sur limo de signoj,
            // kaj ni sendas sekuran referencon, do la revenvaloro ankaŭ estos unu.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SEKURECO: ĵus kontrolis, ke `end` estas sur limo de signoj,
            // kaj ni sendas sekuran referencon, do la revenvaloro ankaŭ estos unu.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SEKURECO: ĵus kontrolis, ke `end` estas sur limo de signoj,
            // kaj ni sendas sekuran referencon, do la revenvaloro ankaŭ estos unu.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Efektivigas subĉenajn tranĉaĵojn per sintakso `&self[begin ..]` aŭ `&mut self[begin ..]`.
///
/// Liveras tranĉaĵon de la donita ĉeno el la bajta intervalo [`begin`, `len`).Ekvivalenta al `&mem [komenci ..
/// len] `aŭ`&mut self [komenci ..
/// len]`.
///
/// Ĉi tiu operacio estas *O*(1).
///
/// Antaŭ 1.20.0, ĉi tiuj indeksaj operacioj ankoraŭ subtenis rektan efektivigon de `Index` kaj `IndexMut`.
///
/// # Panics
///
/// Panics se `begin` ne montras al la komenca bajta ofseto de signo (kiel difinita de `is_char_boundary`), aŭ se `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SEKURECO: ĵus kontrolis, ke `start` estas sur limo de signoj,
            // kaj ni sendas sekuran referencon, do la revenvaloro ankaŭ estos unu.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SEKURECO: ĵus kontrolis, ke `start` estas sur limo de signoj,
            // kaj ni sendas sekuran referencon, do la revenvaloro ankaŭ estos unu.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SEKURECO: la alvokanto garantias, ke `self` estas en limoj de `slice`
        // kiu kontentigas ĉiujn kondiĉojn por `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SEKURECO: identa al `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SEKURECO: ĵus kontrolis, ke `start` estas sur limo de signoj,
            // kaj ni sendas sekuran referencon, do la revenvaloro ankaŭ estos unu.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Efektivigas subĉenajn tranĉaĵojn per sintakso `&self[begin ..= end]` aŭ `&mut self[begin ..= end]`.
///
/// Liveras tranĉaĵon de la donita ĉeno el la bajta gamo [`begin`, `end`].Ekvivalenta al `&self [begin .. end + 1]` aŭ `&mut self[begin .. end + 1]`, krom se `end` havas la maksimuman valoron por `usize`.
///
/// Ĉi tiu operacio estas *O*(1).
///
/// # Panics
///
/// Panics se `begin` ne montras al la komenca bajta ofseto de signo (kiel difinita de `is_char_boundary`), se `end` ne montras al la fina bajta ofseto de signo (`end + 1` estas aŭ komenca bajta ofseto aŭ egala al `len`), se `begin > end`, aŭ se `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Efektivigas subĉenajn tranĉaĵojn per sintakso `&self[..= end]` aŭ `&mut self[..= end]`.
///
/// Liveras tranĉaĵon de la donita ĉeno el la bajta gamo [0, `end`].
/// Ekvivalenta al `&self [0 .. end + 1]`, krom se `end` havas la maksimuman valoron por `usize`.
///
/// Ĉi tiu operacio estas *O*(1).
///
/// # Panics
///
/// Panics se `end` ne montras al la fina bajta ofseto de signo (`end + 1` estas aŭ komenca bajta ofseto kiel difinita de `is_char_boundary`, aŭ egala al `len`), aŭ se `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analizi valoron de ĉeno
///
/// La metodo [`from_str`] de 'FromStr' estas ofte uzata implicite, per la metodo [`parse`] de [`str`].
/// Vidu la dokumentaron de [`analizi`] por ekzemploj.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` ne havas vivdaŭran parametron, kaj tial vi povas mem analizi specojn, kiuj ne enhavas vivdaŭran parametron.
///
/// Alivorte, vi povas analizi `i32` kun `FromStr`, sed ne `&i32`.
/// Vi povas analizi strukturon, kiu enhavas `i32`, sed ne unu, kiu enhavas `&i32`.
///
/// # Examples
///
/// Baza efektivigo de `FromStr` ĉe ekzempla `Point`-tipo:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// La rilata eraro, kiu povas esti redonita de analizado.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analizas ĉenon `s` por redoni tian valoron.
    ///
    /// Se analizo sukcesas, redonu la valoron ene de [`Ok`], alie kiam la ĉeno estas malformata redonu eraron specifan al la interna [`Err`].
    /// La erara tipo estas specifa por efektivigo de la trait.
    ///
    /// # Examples
    ///
    /// Baza uzado kun [`i32`], tipo kiu efektivigas `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analizu `bool` de ĉeno.
    ///
    /// Donas `Result<bool, ParseBoolError>`, ĉar `s` povas aŭ ne efektive esti analizebla.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Notu, en multaj kazoj, la `.parse()`-metodo ĉe `str` pli taŭgas.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}