#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future reprezentas nesinkronan komputadon.
///
/// future estas valoro, kiu eble ankoraŭ ne finis komputadon.
/// Ĉi tiu speco de "asynchronous value" ebligas ke fadeno daŭre faru utilan laboron dum ĝi atendas la haveblon de la valoro.
///
///
/// # La `poll`-metodo
///
/// La kerna metodo de future, `poll`,*provas* solvi la future en finan valoron.
/// Ĉi tiu metodo ne blokas se la valoro ne estas preta.
/// Anstataŭe, la nuna tasko estas planita esti vekita kiam eblas progresi per "sondado" denove.
/// La `context` transdonita al la metodo `poll` povas provizi [`Waker`], kiu estas tenilo por veki la nunan taskon.
///
/// Kiam vi uzas future, vi ĝenerale ne vokos `poll` rekte, sed anstataŭe `.await` la valoron.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// La speco de valoro produktita ĉe kompletiĝo.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Provu solvi la future al fina valoro, registrante la aktualan taskon por vekiĝo se la valoro ankoraŭ ne haveblas.
    ///
    /// # Reveno de valoro
    ///
    /// Ĉi tiu funkcio redonas:
    ///
    /// - [`Poll::Pending`] se la future ankoraŭ ne estas preta
    /// - [`Poll::Ready(val)`] kun la rezulto `val` de ĉi tiu future se ĝi sukcese finiĝis.
    ///
    /// Post kiam future finiĝis, klientoj ne devas `poll` ĝin denove.
    ///
    /// Kiam future ankoraŭ ne estas preta, `poll` redonas `Poll::Pending` kaj stokas klonon de la [`Waker`] kopiita de la nuna [`Context`].
    /// Ĉi tiu [`Waker`] tiam vekiĝas post kiam la future povas progresi.
    /// Ekzemple, future atendanta, ke socket fariĝu legebla, vokus `.clone()` sur la [`Waker`] kaj konservus ĝin.
    /// Kiam signalo alvenas aliloke indikante ke la ingo estas legebla, [`Waker::wake`] estas vokita kaj la tasko de la ingo future estas vekita.
    /// Post kiam tasko vekiĝis, ĝi devas provi `poll` la future denove, kiu eble aŭ ne povas produkti finan valoron.
    ///
    /// Notu, ke ĉe pluraj alvokoj al `poll`, nur la [`Waker`] de la [`Context`] pasita al la plej freŝa alvoko devas esti planita por ricevi vekiĝon.
    ///
    /// # Rultempaj karakterizaĵoj
    ///
    /// Futures sole estas *inertaj*;ili devas esti "aktive" enketitaj por progresi, kio signifas, ke ĉiufoje kiam la nuna tasko vekiĝas, ĝi devas aktive reveturi "atendante futures, pri kiu ĝi ankoraŭ interesiĝas.
    ///
    /// La funkcio `poll` ne estas vokata ree en streĉa buklo-anstataŭe ĝi devas esti vokita nur kiam la future indikas, ke ĝi pretas progresi (vokante `wake()`).
    /// Se vi konas la `poll(2)` aŭ `select(2)`-programojn pri Unix, indas rimarki, ke futures kutime *ne* suferas la samajn problemojn de "all wakeups must poll all events";ili pli similas al `epoll(4)`.
    ///
    /// Efektivigo de `poll` devas strebi reveni rapide, kaj ne devas bloki.Reveni rapide malebligas nenecese ŝtopi fadenojn aŭ eventajn buklojn.
    /// Se anticipe oni scias, ke alvoko al `poll` eble daŭros iom da tempo, la laboro devas esti malŝarĝita al fadena grupo (aŭ io simila) por certigi, ke `poll` povas reveni rapide.
    ///
    /// # Panics
    ///
    /// Post kiam future finiĝis (redonis `Ready` de `poll`), voki sian `poll`-metodon denove povas panic, blokiĝi por ĉiam aŭ kaŭzi aliajn specojn de problemoj;la `Future` trait ne postulas postulojn pri la efikoj de tia alvoko.
    /// Tamen, ĉar la `poll`-metodo ne estas markita `unsafe`, la kutimaj reguloj de Rust validas: vokoj neniam devas kaŭzi nedifinitan konduton (memora koruptado, malĝusta uzo de `unsafe`-funkcioj, aŭ simile), sendepende de la stato de future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}