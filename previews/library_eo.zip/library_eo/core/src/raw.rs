#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Enhavas strukturajn difinojn por la aranĝo de enmetitaj specoj de kompililo.
//!
//! Ili povas esti uzataj kiel celoj de transmutoj en nesekura kodo por manipuli la krudajn reprezentojn rekte.
//!
//!
//! Ilia difino ĉiam kongruu kun la ABI difinita en `rustc_middle::ty::layout`.
//!

/// La reprezento de objekto trait kiel `&dyn SomeTrait`.
///
/// Ĉi tiu strukturo havas la saman aranĝon kiel specoj kiel `&dyn SomeTrait` kaj `Box<dyn AnotherTrait>`.
///
/// `TraitObject` estas garantiita egali aranĝojn, sed ĝi ne estas la speco de objektoj trait (ekz. la kampoj ne estas rekte alireblaj ĉe `&dyn SomeTrait`) nek ĝi regas tiun aranĝon (ŝanĝi la difinon ne ŝanĝos la aranĝon de `&dyn SomeTrait`).
///
/// Ĝi estas nur desegnita por esti uzata de nesekura kodo, kiu bezonas manipuli la malaltnivelajn detalojn.
///
/// Estas neniu maniero referenci ĉiujn trait-objektojn senmarke, do la sola maniero krei tiajn valorojn estas kun funkcioj kiel [`std::mem::transmute`][transmute].
/// Simile, la sola maniero krei veran trait-objekton de `TraitObject`-valoro estas kun `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Sintezi trait-objekton kun misagorditaj tipoj-unu, kie la tabelo ne respondas al la speco de la valoro, al kiu montras la datuma montrilo-tre probable kondukos al nedifinita konduto.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // ekzemplo trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // lasu la kompililon fari trait-objekton
/// let object: &dyn Foo = &value;
///
/// // rigardu la krudan reprezentadon
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // la datuma montrilo estas la adreso de `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // konstruu novan objekton, montrante al alia `i32`, zorgante uzi la `i32`-vtablon de `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // ĝi devas funkcii same kiel se ni konstruus trait-objekton el `other_value` rekte
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}