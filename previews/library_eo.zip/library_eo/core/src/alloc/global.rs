use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Memoro-atribuilo, kiu povas esti registrita kiel defaŭlta de la norma biblioteko per la `#[global_allocator]`-atributo.
///
/// Iuj metodoj postulas, ke membloko estu *aktuale atribuita* per asignilo.Ĉi tio signifas, ke:
///
/// * la komenca adreso por tiu memorbloko antaŭe estis resendita per antaŭa voko al asignometodo kiel ekzemple `alloc`, kaj
///
/// * la memora bloko ne estis poste repartikigita, kie blokoj estas repartikigitaj aŭ per pasado al repartiga metodo kiel ekzemple `dealloc` aŭ per transdono al reasignada metodo, kiu redonas nenulan montrilon.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// La `GlobalAlloc` trait estas `unsafe` trait pro multaj kialoj, kaj efektivigantoj devas certigi, ke ili aliĝas al ĉi tiuj kontraktoj:
///
/// * Ĝi estas nedifinita konduto se tutmondaj asigniloj malstreĉiĝas.Ĉi tiu limigo povas esti nuligita en la future, sed nuntempe panic de iuj el ĉi tiuj funkcioj povas konduki al memora sekureco.
///
/// * `Layout` demandoj kaj kalkuloj ĝenerale devas esti ĝustaj.Alvokantoj de ĉi tiu trait rajtas fidi la kontraktojn difinitajn per ĉiu metodo, kaj efektivigantoj devas certigi, ke tiaj kontraktoj restas veraj.
///
/// * Vi eble ne dependas de asignoj efektive okazantaj, eĉ se ekzistas eksplicitaj amasoj de atribuoj en la fonto.
/// La optimumigilo povas detekti neuzatajn asignojn, kiujn ĝi povas aŭ tute forigi aŭ movi al la stako kaj tiel neniam alvoki la asignilon.
/// La optimumigilo eble plue supozas, ke asigno estas neeraripova, do kodo, kiu antaŭe malsukcesis pro misfunkciadoj de asignanto, nun povas subite funkcii, ĉar la optimumigilo laboris ĉirkaŭ la bezono de asigno.
/// Pli konkrete, la sekva kodekzemplo estas maltaŭga, sendepende de tio, ĉu via laŭmenda asignilo permesas kalkuli kiom da asignoj okazis.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Notu, ke la supre menciitaj optimumigoj ne estas la sola aplikebla optimumigo.Vi eble ĝenerale ne dependas de amasiĝaj atribuoj, se ili povas esti forigitaj sen ŝanĝi la konduton de la programo.
///   Ĉu asignoj okazas aŭ ne ne estas parto de la programo-konduto, eĉ se ĝi povus esti detektita per asignilo, kiu spuras asignojn per presado aŭ alie havante kromefikojn.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Asignu memoron kiel priskribis la donita `layout`.
    ///
    /// Redonas montrilon al nove asignita memoro, aŭ nul por indiki asignan fiaskon.
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio estas nesekura, ĉar nedifinita konduto povas rezulti, se la alvokanto ne certigas, ke `layout` havas nenulan grandecon.
    ///
    /// (Etendaĵaj subtrajtoj povus doni pli specifajn limojn al konduto, ekz. Garantii gardostarantan adreson aŭ nulan montrilon responde al nulgranda asignopeto.)
    ///
    /// La asignita bloko de memoro povas aŭ ne esti pravalorizita.
    ///
    /// # Errors
    ///
    /// Reveni nulan montrilon indikas, ke aŭ memoro estas elĉerpita aŭ `layout` ne plenumas la limojn de ĉi tiu atribuilo aŭ vicigo.
    ///
    /// Efektivigoj estas kuraĝigitaj reveni nulan pro memora elĉerpiĝo anstataŭ ĉesigi, sed ĉi tio ne estas strikta postulo.
    /// (Specife: estas *laŭleĝe* efektivigi ĉi tiun trait sur suba denaska asigna biblioteko, kiu ĉesigas memore elĉerpiĝon.)
    ///
    /// Klientoj dezirantaj ĉesigi komputadon responde al atribua eraro estas kuraĝigitaj nomi la funkcion [`handle_alloc_error`], anstataŭ rekte alvoki `panic!` aŭ simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Disdividu la memoroblokon ĉe la donita montrilo `ptr` kun la donita `layout`.
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio estas nesekura ĉar nedifinita konduto povas rezulti se la alvokanto ne certigas ĉiujn jenojn:
    ///
    ///
    /// * `ptr` devas indiki blokon de memoro nuntempe asignita per ĉi tiu asignilo,
    ///
    /// * `layout` devas esti la sama aranĝo, kiu estis uzata por atribui tiun blokon de memoro.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Kondutas kiel `alloc`, sed ankaŭ certigas, ke la enhavo estas nuligita antaŭ ol esti redonita.
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio estas nesekura pro la samaj kialoj kiel `alloc`.
    /// Tamen la asignita bloko de memoro estas garantiita esti pravalorizita.
    ///
    /// # Errors
    ///
    /// Reveni nulan montrilon indikas, ke aŭ memoro estas elĉerpita aŭ `layout` ne plenumas la limojn aŭ vicigajn limojn de asignilo, same kiel en `alloc`.
    ///
    /// Klientoj dezirantaj ĉesigi komputadon responde al atribua eraro estas kuraĝigitaj nomi la funkcion [`handle_alloc_error`], anstataŭ rekte alvoki `panic!` aŭ simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SEKURECO: la sekureca kontrakto por `alloc` devas esti konfirmita de la alvokanto.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SEKURECO: ĉar asigno sukcesis, la regiono de `ptr`
            // de grandeco `size` estas garantiita esti valida por skriboj.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Malpligrandiĝu aŭ kreskigu blokon de memoro al la donita `new_size`.
    /// La blokon priskribas la donita montrilo `ptr` kaj `layout`.
    ///
    /// Se ĉi tio redonas nenulan montrilon, tiam posedo de la memora bloko aludita de `ptr` estas transdonita al ĉi tiu atribuilo.
    /// La memoro eble aŭ ne estis dislokigita, kaj devus esti konsiderata kiel neuzebla (krom se kompreneble ĝi estis transdonita al la alvokanto denove per la revenvaloro de ĉi tiu metodo).
    /// La nova memora bloko estas asignita kun `layout`, sed kun la `size` ĝisdatigita al `new_size`.
    /// Ĉi tiu nova aranĝo estu uzata kiam vi repartigas la novan memorblokon per `dealloc`.
    /// La gamo `0..min(layout.size(), new_size) 'de la nova memora bloko estas garantiita havi la samajn valorojn kiel la originala bloko.
    ///
    /// Se ĉi tiu metodo revenas nula, tiam posedo de la memora bloko ne estis transdonita al ĉi tiu atribuilo, kaj la enhavo de la memora bloko estas senŝanĝa.
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio estas nesekura ĉar nedifinita konduto povas rezulti se la alvokanto ne certigas ĉiujn jenojn:
    ///
    /// * `ptr` devas esti aktuale asignita per ĉi tiu asignilo,
    ///
    /// * `layout` devas esti la sama aranĝo, kiu estis uzata por asigni tiun blokon de memoro,
    ///
    /// * `new_size` devas esti pli granda ol nulo.
    ///
    /// * `new_size`, kiam rondigita al la plej proksima oblo de `layout.align()`, ne devas superflui (t.e., la rondigita valoro devas esti malpli ol `usize::MAX`).
    ///
    /// (Etendaĵaj subtrajtoj povus doni pli specifajn limojn al konduto, ekz. Garantii gardostarantan adreson aŭ nulan montrilon responde al nulgranda asignopeto.)
    ///
    /// # Errors
    ///
    /// Revenas nula se la nova aranĝo ne plenumas la grandajn kaj vicajn limojn de la atribuilo, aŭ se reasignado alie malsukcesas.
    ///
    /// Efektivigoj estas kuraĝigitaj reveni nulaj pro memora elĉerpiĝo anstataŭ paniki aŭ ĉesigi, sed ĉi tio ne estas strikta postulo.
    /// (Specife: estas *laŭleĝe* efektivigi ĉi tiun trait sur suba denaska asigna biblioteko, kiu ĉesigas memore elĉerpiĝon.)
    ///
    /// Klientoj dezirantaj ĉesigi komputadon kiel respondo al reasigna eraro estas kuraĝigitaj nomi la funkcion [`handle_alloc_error`], anstataŭ rekte alvoki `panic!` aŭ simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SEKURECO: la alvokanto devas certigi, ke la `new_size` ne superfluas.
        // `layout.align()` devenas de `Layout` kaj do estas garantiita esti valida.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SEKURECO: la alvokanto devas certigi, ke `new_layout` estas pli granda ol nulo.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SEKURECO: la antaŭe asignita bloko ne povas interkovri la nove asignitan blokon.
            // La sekureca kontrakto por `dealloc` devas esti konfirmita de la alvokanto.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}