use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Dum ĉi tiu funkcio estas uzata en unu loko kaj ĝia efektivigo povus esti enlinia, la antaŭaj provoj fari tion rustc pli malrapida:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Aranĝo de bloko de memoro.
///
/// Kazo de `Layout` priskribas apartan aranĝon de memoro.
/// Vi konstruas `Layout` kiel enigaĵon por doni al asignilo.
///
/// Ĉiuj enpaĝigoj havas asociitan grandecon kaj potencon de du vicoj.
///
/// (Notu, ke enpaĝigoj *ne* bezonas havi diversnulan grandecon, kvankam `GlobalAlloc` postulas, ke ĉiuj memorpetoj estu malnulaj.
/// Alvokanto devas aŭ certigi, ke tiaj kondiĉoj estas plenumitaj, uzi specifajn asignilojn kun pli malstriktaj postuloj, aŭ uzi la pli malseveran `Allocator`-interfacon.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // grandeco de la petita bloko de memoro, mezurita per bajtoj.
    size_: usize,

    // vicigo de la petita bloko de memoro, mezurita per bajtoj.
    // ni certigas, ke ĉi tio ĉiam estas potenco de du, ĉar API kiel `posix_memalign` postulas ĝin kaj estas racia limo trudi al Aranĝaj konstruistoj.
    //
    //
    // (Tamen ni analoge ne postulas `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Konstruas `Layout` de donitaj `size` kaj `align`, aŭ redonas `LayoutError` se iuj el la sekvaj kondiĉoj ne estas plenumitaj:
    ///
    /// * `align` ne devas esti nula,
    ///
    /// * `align` devas esti potenco de du,
    ///
    /// * `size`, kiam rondigita al la plej proksima oblo de `align`, ne devas superflui (te la rondigita valoro devas esti malpli ol aŭ egala al `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (potenco de du implicas vicigi!=0.)

        // Rondigita grandeco estas:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Ni scias de supre, ke vicigi!=0.
        // Se aldono (vicigi, 1) ne superfluas, tiam rondigo estos bone.
        //
        // Male,&-masking kun! (Align, 1) subtrahos nur malmultajn ordojn.
        // Tiel se superfluaĵo okazas kun la sumo, la&-masko ne povas subtrahi sufiĉe por malfari tiun superfluaĵon.
        //
        //
        // Supre implicas, ke kontroli sumigan superfluon estas kaj necesa kaj sufiĉa.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SEKURECO: la kondiĉoj por `from_size_align_unchecked` estis
        // kontrolita supre.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Kreas aranĝon, preterirante ĉiujn kontrolojn.
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio estas nesekura, ĉar ĝi ne kontrolas la antaŭkondiĉojn de [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SEKURECO: la alvokanto devas certigi, ke `align` estas pli granda ol nulo.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// La minimuma grandeco en bajtoj por memora bloko de ĉi tiu aranĝo.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// La minimuma bajta vicigo por memora bloko de ĉi tiu aranĝo.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Konstruas `Layout` taŭgan por teni valoron de tipo `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SEKURECO: la vicigo estas garantiita de Rust por esti potenco de du kaj
        // la kombinaĵo grandeco + vicigo garantias kongrui en nia adresspaco.
        // Rezulte uzu la senkontrolan konstruilon ĉi tie por eviti enmeti kodon kiu panics se ĝi ne estas sufiĉe bone optimumigita.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produktas aranĝon priskribantan diskon, kiu povus esti uzata por atribui subtenan strukturon por `T` (kiu povus esti trait aŭ alia nedimensia tipo kiel tranĉaĵo).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SEKURECO: vidu racion en `new` pri kial ĉi tio uzas la nesekuran varianton
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produktas aranĝon priskribantan diskon, kiu povus esti uzata por atribui subtenan strukturon por `T` (kiu povus esti trait aŭ alia nedimensia tipo kiel tranĉaĵo).
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio estas sekure alvokebla nur se sekvas la jenaj kondiĉoj:
    ///
    /// - Se `T` estas `Sized`, ĉi tiu funkcio estas ĉiam sekure alvokebla.
    /// - Se la nedimensia vosto de `T` estas:
    ///     - a [slice], tiam la longo de la tranĉaĵa vosto devas esti intialigita entjero, kaj la grandeco de la *tuta valoro*(dinamika vosta longo + statike grandigita prefikso) devas kongrui en `isize`.
    ///     - a [trait object], tiam la vtabla parto de la montrilo devas montri validan vtablon por la tipo `T` akirita per malgrandiga kohereco, kaj la grandeco de la *tuta valoro*(dinamika vostolongo + statike grandigita prefikso) devas kongrui en `isize`.
    ///
    ///     - (unstable) [extern type], tiam ĉi tiu funkcio estas ĉiam sekura telefonebla, sed panic aŭ alimaniere redonas la malĝustan valoron, ĉar la aranĝo de la ekstera tipo ne estas konata.
    ///     Ĉi tiu estas la sama konduto kiel [`Layout::for_value`] rilate al ekstera tipa vosto.
    ///     - alie, konservative ne rajtas nomi ĉi tiun funkcion.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SEKURECO: ni pasas laŭ la antaŭkondiĉoj de ĉi tiuj funkcioj al la alvokanto
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SEKURECO: vidu racion en `new` pri kial ĉi tio uzas la nesekuran varianton
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Kreas `NonNull` pendantan, sed bone vicigitan por ĉi tiu Aranĝo.
    ///
    /// Rimarku, ke la montrila valoro eble reprezentas validan montrilon, kio signifas, ke ĉi tio ne rajtas esti uzata kiel sentinela valoro "not yet initialized".
    /// Tipoj, kiuj pigre atribuas, devas spuri inicialigon per iuj aliaj rimedoj.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SEKURECO: vicigi estas garantiita esti nula
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Kreas aranĝon priskribantan la rekordon, kiu povas teni valoron de la sama aranĝo kiel `self`, sed kiu ankaŭ estas vicigita al vicigo `align` (mezurita en bajtoj).
    ///
    ///
    /// Se `self` jam plenumas la preskribitan vicigon, tiam redonas `self`.
    ///
    /// Notu, ke ĉi tiu metodo ne aldonas remburaĵon al la ĝenerala grandeco, sendepende de tio, ĉu la revenita aranĝo havas alian vicigon.
    /// Alivorte, se `K` havas grandecon 16, `K.align_to(32)`*ankoraŭ* havos grandecon 16.
    ///
    /// Liveras eraron se la kombinaĵo de `self.size()` kaj la donita `align` malobservas la kondiĉojn listigitajn en [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Liveras la kvanton da kompletigo, kiun ni devas enmeti post `self` por certigi, ke la sekva adreso plenumos `align` (mezurita en bajtoj).
    ///
    /// ekz., se `self.size()` estas 9, tiam `self.padding_needed_for(4)` redonas 3, ĉar tio estas la minimuma nombro da bajtoj da kompletigo necesaj por akiri 4-vicigitan adreson (supozante, ke la responda memora bloko komenciĝas ĉe 4-vicigita adreso).
    ///
    ///
    /// La revenvaloro de ĉi tiu funkcio havas nenian signifon se `align` ne estas potenco de du.
    ///
    /// Notu, ke la utileco de la redonita valoro postulas, ke `align` estu malpli ol aŭ egala al la vicigo de la komenca adreso por la tuta asignita bloko de memoro.Unu maniero por kontentigi ĉi tiun limon estas certigi `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Rondigita valoro estas:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // kaj tiam ni redonas la kompletigan diferencon: `len_rounded_up - len`.
        //
        // Ni uzas modulan aritmetikon tra:
        //
        // 1. align estas garantiita esti> 0, do align, 1 ĉiam validas.
        //
        // 2.
        // `len + align - 1` povas superflui maksimume `align - 1`, do la&-masko kun `!(align - 1)` certigos, ke en kazo de superfluo, `len_rounded_up` mem estos 0.
        //
        //    Tiel la redonita kompletigo, aldonita al `len`, donas 0, kiu banale kontentigas la vicigon `align`.
        //
        // (Kompreneble provoj asigni blokojn de memoro, kies grandeco kaj remburaĵo superflue laŭ la supra maniero devas kaŭzi la atribuilon doni eraron ĉiuokaze.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Kreas aranĝon rondigante la grandecon de ĉi tiu aranĝo ĝis multoblo de la aranĝo de la aranĝo.
    ///
    ///
    /// Ĉi tio samvaloras aldoni la rezulton de `padding_needed_for` al la nuna grandeco de la aranĝo.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Ĉi tio ne povas superflui.Citante el la senvaria aranĝo:
        // > `size`, kiam rondigita al la plej proksima oblo de `align`,
        // > ne devas superflui (te la rondigita valoro devas esti malpli ol
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Kreas aranĝon priskribantan la rekordon por `n`-kazoj de `self`, kun taŭga kvanto da remburaĵo inter ĉiu por certigi, ke ĉiu kazo ricevas sian petitan grandecon kaj vicigon.
    /// Sukcese redonas `(k, offs)` kie `k` estas la aranĝo de la tabelo kaj `offs` estas la distanco inter la komenco de ĉiu elemento en la tabelo.
    ///
    /// Ĉe aritmetika superfluo, redonas `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Ĉi tio ne povas superflui.Citante el la senvaria aranĝo:
        // > `size`, kiam rondigita al la plej proksima oblo de `align`,
        // > ne devas superflui (te la rondigita valoro devas esti malpli ol
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SEKURECO: self.align estas jam konata kiel valida kaj alloc_size estis
        // remburita jam.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Kreas aranĝon priskribantan la rekordon por `self` sekvita de `next`, inkluzive de iu necesa remburaĵo por certigi, ke `next` estos ĝuste vicigita, sed *neniu posta remburaĵo*.
    ///
    /// Por egali C-prezentan aranĝon `repr(C)`, vi devas telefoni al `pad_to_align` post etendo de la aranĝo kun ĉiuj kampoj.
    /// (Neniel kongruas kun la apriora `repr(Rust)`, as it is unspecified.)-reprezenta aranĝo Rust
    ///
    /// Notu, ke la vicigo de la rezulta aranĝo estos la maksimumo de tiuj de `self` kaj `next`, por certigi vicigon de ambaŭ partoj.
    ///
    /// Liveras `Ok((k, offset))`, kie `k` estas aranĝo de la kunligita rekordo kaj `offset` estas la relativa loko, en bajtoj, de la komenco de la `next` enigita ene de la kunligita rekordo (supozante ke la disko mem komenciĝas per ofseto 0).
    ///
    ///
    /// Ĉe aritmetika superfluo, redonas `LayoutError`.
    ///
    /// # Examples
    ///
    /// Por kalkuli la aranĝon de `#[repr(C)]`-strukturo kaj la kompensojn de la kampoj de la aranĝoj de ĝiaj kampoj:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Memoru fini per `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // provu, ke ĝi funkcias
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Kreas aranĝon priskribantan la rekordon por `n`-kazoj de `self`, sen remburaĵo inter ĉiu kazo.
    ///
    /// Rimarku, ke male al `repeat`, `repeat_packed` ne garantias, ke la ripetaj okazoj de `self` estos ĝuste vicigitaj, eĉ se antaŭfiksita kazo de `self` estas ĝuste vicigita.
    /// Alivorte, se la aranĝo redonita de `repeat_packed` estas uzata por atribui tabelon, ĝi ne garantias, ke ĉiuj elementoj en la tabelo estos ĝuste vicigitaj.
    ///
    /// Ĉe aritmetika superfluo, redonas `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Kreas aranĝon priskribantan la rekordon por `self` sekvita de `next` sen aldona kompletigo inter ambaŭ.
    /// Ĉar neniu remburaĵo estas enmetita, la vicigo de `next` estas senrilata, kaj tute ne estas enigita * en la rezultan aranĝon.
    ///
    ///
    /// Ĉe aritmetika superfluo, redonas `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Kreas aranĝon priskribantan la rekordon por `[T; n]`.
    ///
    /// Ĉe aritmetika superfluo, redonas `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// La parametroj donitaj al `Layout::from_size_align` aŭ iu alia `Layout`-konstruilo ne kontentigas ĝiajn dokumentitajn limojn.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (Ni bezonas ĉi tion por laŭflua impl de trait Eraro)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}