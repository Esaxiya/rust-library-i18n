//! API-asignoj de memoro

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// La `AllocError`-eraro indikas atribuan malsukceson, kiu eble kaŭzas rimedon elĉerpitan aŭ al io malĝusta kiam kombinas la donitajn enirajn argumentojn kun ĉi tiu asignilo.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (Ni bezonas ĉi tion por laŭflua impl de trait Eraro)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Efektivigo de `Allocator` povas asigni, kreski, ŝrumpi kaj transdoni arbitrajn blokojn de datumoj priskribitaj per [`Layout`][].
///
/// `Allocator` estas desegnita por esti efektivigita sur ZST-oj, referencoj aŭ inteligentaj montriloj ĉar havi asignilon kiel `MyAlloc([u8; N])` ne povas esti movita, sen ĝisdatigi la montrilojn al la asignita memoro.
///
/// Male al [`GlobalAlloc`][], nul-grandaj asignoj estas permesitaj en `Allocator`.
/// Se suba asignilo ne subtenas ĉi tion (kiel jemalloc) aŭ redonas nulan montrilon (kiel `libc::malloc`), ĉi tio devas esti kaptita de la efektivigo.
///
/// ### Nuntempe asignita memoro
///
/// Iuj metodoj postulas, ke membloko estu *aktuale atribuita* per asignilo.Ĉi tio signifas, ke:
///
/// * la komencan adreson por tiu memora bloko antaŭe redonis [`allocate`], [`grow`] aŭ [`shrink`], kaj
///
/// * la memora bloko ne estis poste disdividita, kie blokoj estas aŭ disdoklokitaj rekte per transiro al [`deallocate`] aŭ estis ŝanĝitaj per transdono al [`grow`] aŭ [`shrink`], kiu redonas `Ok`.
///
/// Se `grow` aŭ `shrink` redonis `Err`, la pasita montrilo restas valida.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Memorado
///
/// Iuj el la metodoj postulas, ke aranĝo *kongruas* kun memora bloko.
/// Kion ĝi signifas por aranĝo al "fit" memora bloko signifas (aŭ ekvivalente, por memora bloko al "fit" aranĝo) estas, ke la jenaj kondiĉoj devas plenumi:
///
/// * La bloko devas esti asignita kun la sama vicigo kiel [`layout.align()`], kaj
///
/// * La provizita [`layout.size()`] devas esti en la gamo `min ..= max`, kie:
///   - `min` estas la grandeco de la aranĝo plej ĵuse uzata por asigni la blokon, kaj
///   - `max` estas la plej nova reala grandeco resendita de [`allocate`], [`grow`] aŭ [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Memoraj blokoj resenditaj de asignilo devas montri al valida memoro kaj konservi sian validecon ĝis la instanco kaj ĉiuj ĝiaj klonoj falos,
///
/// * klonado aŭ movado de la asignilo ne rajtas nuligi memoroblokojn resenditajn de ĉi tiu asignilo.Klonita asignilo devas konduti kiel la sama asignilo, kaj
///
/// * iu ajn montrilo al memora bloko, kiu estas [*currently allocated*], povas esti transdonita al iu ajn alia metodo de la atribuilo.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Provoj atribui blokon de memoro.
    ///
    /// Sukcese redonas [`NonNull<[u8]>`][NonNull] kun la grandeco kaj vicigaj garantioj de `layout`.
    ///
    /// La resendita bloko eble havas pli grandan grandecon ol specifita de `layout.size()`, kaj eble aŭ ne havas ĝian enhavon inicialigita.
    ///
    /// # Errors
    ///
    /// Revenanta `Err` indikas, ke aŭ memoro estas elĉerpita aŭ `layout` ne plenumas la limojn aŭ vicigojn de asignilo.
    ///
    /// Efektivigoj estas instigitaj redoni `Err` pro memora elĉerpiĝo anstataŭ paniki aŭ ĉesigi, sed ĉi tio ne estas strikta postulo.
    /// (Specife: estas *laŭleĝe* efektivigi ĉi tiun trait sur suba denaska asigna biblioteko, kiu ĉesigas memore elĉerpiĝon.)
    ///
    /// Klientoj dezirantaj ĉesigi komputadon responde al atribua eraro estas kuraĝigitaj nomi la funkcion [`handle_alloc_error`], anstataŭ rekte alvoki `panic!` aŭ simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Kondutas kiel `allocate`, sed ankaŭ certigas, ke la redonita memoro estas nul-komencita.
    ///
    /// # Errors
    ///
    /// Revenanta `Err` indikas, ke aŭ memoro estas elĉerpita aŭ `layout` ne plenumas la limojn aŭ vicigojn de asignilo.
    ///
    /// Efektivigoj estas instigitaj redoni `Err` pro memora elĉerpiĝo anstataŭ paniki aŭ ĉesigi, sed ĉi tio ne estas strikta postulo.
    /// (Specife: estas *laŭleĝe* efektivigi ĉi tiun trait sur suba denaska asigna biblioteko, kiu ĉesigas memore elĉerpiĝon.)
    ///
    /// Klientoj dezirantaj ĉesigi komputadon responde al atribua eraro estas kuraĝigitaj nomi la funkcion [`handle_alloc_error`], anstataŭ rekte alvoki `panic!` aŭ simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SEKURECO: `alloc` redonas validan memorblokon
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Deallocates la memoro referencita de `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` devas signifi blokon de memoro [*currently allocated*] per ĉi tiu asignilo, kaj
    /// * `layout` ĉu [*fit*] devas tiu bloko de memoro.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Provoj etendi la memorblokon.
    ///
    /// Liveras novan [`NonNull<[u8]>`][NonNull] enhavantan montrilon kaj la efektivan grandecon de la asignita memoro.La montrilo taŭgas por teni datumojn priskribitajn de `new_layout`.
    /// Por plenumi ĉi tion, la atribuilo povas etendi la atribuon referencitan de `ptr` por kongrui kun la nova aranĝo.
    ///
    /// Se ĉi tio redonas `Ok`, tiam posedo de la memora bloko aludita de `ptr` estas transdonita al ĉi tiu asignilo.
    /// La memoro eble estis liberigita aŭ ne, kaj ĝi devas esti konsiderata kiel neuzebla krom se ĝi estis transdonita denove al la alvokanto per la revenvaloro de ĉi tiu metodo.
    ///
    /// Se ĉi tiu metodo redonas `Err`, tiam posedo de la memora bloko ne estis transdonita al ĉi tiu atribuilo, kaj la enhavo de la memora bloko estas senŝanĝa.
    ///
    /// # Safety
    ///
    /// * `ptr` devas signifi blokon de memoro [*currently allocated*] per ĉi tiu asignilo.
    /// * `old_layout` ĉu [*fit*] devas tiu memora bloko (La argumento `new_layout` ne bezonas ĝustigi ĝin.).
    /// * `new_layout.size()` devas esti pli granda aŭ egala al `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Liveras `Err` se la nova aranĝo ne plenumas la grandecojn kaj vicigajn limojn de la atribuilo de la asignilo, aŭ se kreskado alie malsukcesas.
    ///
    /// Efektivigoj estas instigitaj redoni `Err` pro memora elĉerpiĝo anstataŭ paniki aŭ ĉesigi, sed ĉi tio ne estas strikta postulo.
    /// (Specife: estas *laŭleĝe* efektivigi ĉi tiun trait sur suba denaska asigna biblioteko, kiu ĉesigas memore elĉerpiĝon.)
    ///
    /// Klientoj dezirantaj ĉesigi komputadon responde al atribua eraro estas kuraĝigitaj nomi la funkcion [`handle_alloc_error`], anstataŭ rekte alvoki `panic!` aŭ simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SEKURECO: ĉar `new_layout.size()` devas esti pli granda ol aŭ egala al
        // `old_layout.size()`, ambaŭ la malnova kaj nova memora asigno validas por legaĵoj kaj skriboj por `old_layout.size()`-bitokoj.
        // Ankaŭ, ĉar la malnova asigno ankoraŭ ne estis transdokumentita, ĝi ne povas interkovri `new_ptr`.
        // Tiel, la alvoko al `copy_nonoverlapping` estas sekura.
        // La sekureca kontrakto por `dealloc` devas esti konfirmita de la alvokanto.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Kondutas kiel `grow`, sed ankaŭ certigas, ke la novaj enhavoj estas nuligitaj antaŭ ol esti redonitaj.
    ///
    /// La memora bloko enhavos la sekvan enhavon post sukcesa alvoko al
    /// `grow_zeroed`:
    ///   * Bajtoj `0..old_layout.size()` estas konservitaj de la originala atribuo.
    ///   * Bajtoj `old_layout.size()..old_size` aŭ konserviĝos aŭ nuliĝos, depende de la efektiviga atribuilo.
    ///   `old_size` rilatas al la grandeco de la memora bloko antaŭ la `grow_zeroed`-alvoko, kiu povas esti pli granda ol la grandeco kiu estis origine petita kiam ĝi estis asignita.
    ///   * Bajtoj `old_size..new_size` estas nuligitaj.`new_size` rilatas al la grandeco de la memora bloko redonita de la alvoko `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` devas signifi blokon de memoro [*currently allocated*] per ĉi tiu asignilo.
    /// * `old_layout` ĉu [*fit*] devas tiu memora bloko (La argumento `new_layout` ne bezonas ĝustigi ĝin.).
    /// * `new_layout.size()` devas esti pli granda aŭ egala al `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Liveras `Err` se la nova aranĝo ne plenumas la grandecojn kaj vicigajn limojn de la atribuilo de la asignilo, aŭ se kreskado alie malsukcesas.
    ///
    /// Efektivigoj estas instigitaj redoni `Err` pro memora elĉerpiĝo anstataŭ paniki aŭ ĉesigi, sed ĉi tio ne estas strikta postulo.
    /// (Specife: estas *laŭleĝe* efektivigi ĉi tiun trait sur suba denaska asigna biblioteko, kiu ĉesigas memore elĉerpiĝon.)
    ///
    /// Klientoj dezirantaj ĉesigi komputadon responde al atribua eraro estas kuraĝigitaj nomi la funkcion [`handle_alloc_error`], anstataŭ rekte alvoki `panic!` aŭ simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SEKURECO: ĉar `new_layout.size()` devas esti pli granda ol aŭ egala al
        // `old_layout.size()`, ambaŭ la malnova kaj nova memora asigno validas por legaĵoj kaj skriboj por `old_layout.size()`-bitokoj.
        // Ankaŭ, ĉar la malnova asigno ankoraŭ ne estis transdokumentita, ĝi ne povas interkovri `new_ptr`.
        // Tiel, la alvoko al `copy_nonoverlapping` estas sekura.
        // La sekureca kontrakto por `dealloc` devas esti konfirmita de la alvokanto.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Provoj malgrandigi la memorblokon.
    ///
    /// Liveras novan [`NonNull<[u8]>`][NonNull] enhavantan montrilon kaj la efektivan grandecon de la asignita memoro.La montrilo taŭgas por teni datumojn priskribitajn de `new_layout`.
    /// Por plenumi ĉi tion, la atribuilo eble malpliigos la atribuon referencitan de `ptr` por kongrui kun la nova aranĝo.
    ///
    /// Se ĉi tio redonas `Ok`, tiam posedo de la memora bloko aludita de `ptr` estas transdonita al ĉi tiu asignilo.
    /// La memoro eble estis liberigita aŭ ne, kaj ĝi devas esti konsiderata kiel neuzebla krom se ĝi estis transdonita denove al la alvokanto per la revenvaloro de ĉi tiu metodo.
    ///
    /// Se ĉi tiu metodo redonas `Err`, tiam posedo de la memora bloko ne estis transdonita al ĉi tiu atribuilo, kaj la enhavo de la memora bloko estas senŝanĝa.
    ///
    /// # Safety
    ///
    /// * `ptr` devas signifi blokon de memoro [*currently allocated*] per ĉi tiu asignilo.
    /// * `old_layout` ĉu [*fit*] devas tiu memora bloko (La argumento `new_layout` ne bezonas ĝustigi ĝin.).
    /// * `new_layout.size()` devas esti pli malgranda aŭ egala al `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Liveras `Err` se la nova aranĝo ne plenumas la grandecojn kaj vicigajn limojn de la atribuilo de la atribuilo, aŭ se la ŝrumpado alie malsukcesas.
    ///
    /// Efektivigoj estas instigitaj redoni `Err` pro memora elĉerpiĝo anstataŭ paniki aŭ ĉesigi, sed ĉi tio ne estas strikta postulo.
    /// (Specife: estas *laŭleĝe* efektivigi ĉi tiun trait sur suba denaska asigna biblioteko, kiu ĉesigas memore elĉerpiĝon.)
    ///
    /// Klientoj dezirantaj ĉesigi komputadon responde al atribua eraro estas kuraĝigitaj nomi la funkcion [`handle_alloc_error`], anstataŭ rekte alvoki `panic!` aŭ simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SEKURECO: ĉar `new_layout.size()` devas esti pli malalta ol aŭ egala al
        // `old_layout.size()`, ambaŭ la malnova kaj nova memora asigno validas por legaĵoj kaj skriboj por `new_layout.size()`-bitokoj.
        // Ankaŭ, ĉar la malnova asigno ankoraŭ ne estis transdokumentita, ĝi ne povas interkovri `new_ptr`.
        // Tiel, la alvoko al `copy_nonoverlapping` estas sekura.
        // La sekureca kontrakto por `dealloc` devas esti konfirmita de la alvokanto.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Kreas "by reference"-adaptilon por ĉi tiu kazo de `Allocator`.
    ///
    /// La resendita adaptilo ankaŭ efektivigas `Allocator` kaj simple pruntos ĉi tion.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SEKURECO: la sekureca kontrakto devas esti konfirmita de la alvokanto
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEKURECO: la sekureca kontrakto devas esti konfirmita de la alvokanto
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEKURECO: la sekureca kontrakto devas esti konfirmita de la alvokanto
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEKURECO: la sekureca kontrakto devas esti konfirmita de la alvokanto
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}