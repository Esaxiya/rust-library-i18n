//! La `Clone` trait por tipoj, kiuj ne povas esti "implicite kopiitaj".
//!
//! En Rust, iuj simplaj tipoj estas "implicitly copyable" kaj kiam vi atribuas ilin aŭ pasigas ilin kiel argumentojn, la ricevilo ricevos kopion, lasante la originalan valoron modloko.
//! Ĉi tiuj tipoj ne bezonas atribuon por kopii kaj ne havas finigilojn (t.e. ili ne enhavas posedatajn skatolojn aŭ efektivigas [`Drop`]), do la kompililo konsideras ilin malmultekostaj kaj sekuraj kopii.
//!
//! Por aliaj tipoj kopioj devas esti eksplicite faritaj per konvencio efektivigante la [`Clone`] trait kaj vokante la [`clone`]-metodon.
//!
//! [`clone`]: Clone::clone
//!
//! Baza uzekzemplo:
//!
//! ```
//! let s = String::new(); // Korda tipo efektivigas Klonon
//! let copy = s.clone(); // do ni povas kloni ĝin
//! ```
//!
//! Por facile efektivigi la Klonon trait, vi povas ankaŭ uzi `#[derive(Clone)]`.Ekzemplo:
//!
//! ```
//! #[derive(Clone)] // ni aldonas la Klonan trait al Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // kaj nun ni povas kloni ĝin!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Ofta trait por la kapablo eksplicite kopii objekton.
///
/// Diferencas de [`Copy`] pro tio, ke [`Copy`] estas implica kaj ekstreme malmultekosta, dum `Clone` estas ĉiam eksplicita kaj eble aŭ ne povas esti multekosta.
/// Por plenumi ĉi tiujn karakterizaĵojn, Rust ne permesas al vi realigi [`Copy`], sed vi rajtas realigi `Clone` kaj plenumi arbitran kodon.
///
/// Ĉar `Clone` estas pli ĝenerala ol [`Copy`], vi povas aŭtomate fari ion ajn [`Copy`] ankaŭ `Clone`.
///
/// ## Derivable
///
/// Ĉi tiu trait uzeblas kun `#[derive]` se ĉiuj kampoj estas `Clone`.La `derive`d efektivigo de [`Clone`] vokas [`clone`] sur ĉiu kampo.
///
/// [`clone`]: Clone::clone
///
/// Por senmarka strukturo, `#[derive]` efektivigas `Clone` kondiĉe aldonante ligitan `Clone` sur senmarkaj parametroj.
///
/// ```
/// // `derive` efektivigas Klonon por Legado<T>kiam T estas Klono.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Kiel mi povas efektivigi `Clone`?
///
/// Tipoj [`Copy`] devas havi bagatelan efektivigon de `Clone`.Pli formale:
/// se `T: Copy`, `x: T` kaj `y: &T`, tiam `let x = y.clone();` estas ekvivalenta al `let x = *y;`.
/// Manaj efektivigoj devas zorgi por subteni ĉi tiun invarianton;tamen nesekura kodo ne devas fidi ĝin por certigi memoran sekurecon.
///
/// Ekzemplo estas ĝenerala strukturo tenanta funkcian montrilon.En ĉi tiu kazo, la efektivigo de `Clone` ne povas esti "derivita" d, sed povas esti efektivigita kiel:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Pliaj efektivigiloj
///
/// Aldone al la [implementors listed below][impls], la sekvaj specoj ankaŭ efektivigas `Clone`:
///
/// * Funkciaj erospecoj (t.e. la apartaj specoj difinitaj por ĉiu funkcio)
/// * Funkciaj montriloj (ekz., `fn() -> i32`)
/// * Araj tipoj, por ĉiuj grandecoj, se la ero-speco ankaŭ efektivigas `Clone` (ekz. `[i32; 123456]`)
/// * Opoj, se ĉiu ero ankaŭ efektivigas `Clone` (ekz. `()`, `(i32, bool)`)
/// * Fermaj specoj, se ili kaptas neniun valoron de la medio aŭ se ĉiuj tiaj kaptitaj valoroj efektivigas `Clone` mem.
///   Notu, ke variabloj kaptitaj per komuna referenco ĉiam efektivigas `Clone` (eĉ se la referenco ne faras ĝin), dum variabloj kaptitaj per ŝanĝebla referenco neniam efektivigas `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Liveras kopion de la valoro.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str efektivigas Klonon
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Plenumas kopion-asignon de `source`.
    ///
    /// `a.clone_from(&b)` estas ekvivalenta al `a = b.clone()` en funkcio, sed povas esti anstataŭigita por reuzi la rimedojn de `a` por eviti nenecesajn atribuojn.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Eligu makroon generantan impl de la trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ĉi tiuj strukturoj estas uzataj nur de#[derive] por aserti, ke ĉiu ero de tipo efektivigas Klonon aŭ Kopion.
//
//
// Ĉi tiuj strukturoj neniam devas aperi en uzanta kodo.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Efektivigoj de `Clone` por primitivaj tipoj.
///
/// Efektivigoj, kiuj ne povas esti priskribitaj en Rust, estas efektivigitaj en `traits::SelectionContext::copy_clone_conditions()` en `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Komunaj referencoj povas esti klonitaj, sed ŝanĝeblaj referencoj *ne povas*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Komunaj referencoj povas esti klonitaj, sed ŝanĝeblaj referencoj *ne povas*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}