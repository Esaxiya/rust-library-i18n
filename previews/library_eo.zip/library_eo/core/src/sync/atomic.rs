//! Atomaj tipoj
//!
//! Atomspecoj disponigas primitivan komunmemoran komunikadon inter fadenoj, kaj estas la konstrubriketoj de aliaj samtempaj specoj.
//!
//! Ĉi tiu modulo difinas atomajn versiojn de elektita nombro de primitivaj specoj, inkluzive [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], ktp.
//! Atomaj tipoj prezentas operaciojn, kiuj, kiam ili estas ĝuste uzataj, sinkronigas ĝisdatigojn inter fadenoj.
//!
//! Ĉiu metodo prenas [`Ordering`], kiu reprezentas la forton de la memora baro por tiu operacio.Ĉi tiuj mendoj samas al la [C++20 atomic orderings][1].Por pliaj informoj vidu la [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atomaj variabloj estas sekuraj dividi inter fadenoj (ili efektivigas [`Sync`]) sed ili mem ne provizas la mekanismon por dividi kaj sekvas la [threading model](../../../std/thread/index.html#the-threading-model) de Rust.
//!
//! La plej ofta maniero dividi atomvariablon estas meti ĝin en [`Arc`][arc] (komune montrita atomreferenc-kalkulita).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atomaj tipoj povas esti stokitaj en statikaj variabloj, pravalorizitaj per la konstantaj inicializiloj kiel [`AtomicBool::new`].Atoma statiko estas ofte uzata por maldiligenta tutmonda komencigo.
//!
//! # Portability
//!
//! Ĉiuj atomspecoj en ĉi tiu modulo estas garantiitaj esti [lock-free] se ili haveblas.Ĉi tio signifas, ke ili ne interne akiras tutmondan mutex.Atomaj specoj kaj operacioj ne certas esti senatendaj.
//! Ĉi tio signifas, ke operacioj kiel `fetch_or` povas esti efektivigitaj per kompar-kaj-interŝanĝa buklo.
//!
//! Atomaj operacioj povas esti efektivigitaj ĉe la instrukcia tavolo kun pli grandgrandaj atomoj.Ekzemple iuj platformoj uzas 4-bajtajn atomajn instrukciojn por efektivigi `AtomicI8`.
//! Rimarku, ke ĉi tiu kopiado ne devas efiki al ĝusteco de kodo, ĝi estas nur io konsciebla.
//!
//! La atomaj tipoj en ĉi tiu modulo eble ne haveblas sur ĉiuj platformoj.La atomaj specoj ĉi tie estas tamen vaste haveblaj, kaj ĝenerale povas fidi ekzistadon.Iuj rimarkindaj esceptoj estas:
//!
//! * PowerPC kaj MIPS-platformoj kun 32-bitaj montriloj ne havas `AtomicU64` aŭ `AtomicI64`-specojn.
//! * ARM platformoj kiel `armv5te`, kiuj ne estas por Linux, nur provizas `load` kaj `store`-operaciojn, kaj ne subtenas Komparu kaj Interŝanĝu (CAS)-operaciojn, kiel `swap`, `fetch_add`, ktp.
//! Aldone ĉe Linux, ĉi tiuj CAS-operacioj estas efektivigitaj per [operating system support], kiu eble venas kun rendimento-puno.
//! * ARM celoj kun `thumbv6m` nur provizas `load` kaj `store`-operaciojn, kaj ne subtenas Komparu kaj Interŝanĝu (CAS)-operaciojn, kiel `swap`, `fetch_add`, ktp.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Notu, ke future-platformoj povas esti aldonitaj, kiuj ankaŭ ne subtenas iujn atomajn operaciojn.Maksimume portebla kodo volos atenti pri kiuj atomaj specoj estas uzataj.
//! `AtomicUsize` kaj `AtomicIsize` estas ĝenerale la plej porteblaj, sed eĉ tiam ili ne haveblas ĉie.
//! Por referenco, la `std`-biblioteko postulas montrilon-grandan atomaron, kvankam `core` ne.
//!
//! Nuntempe vi devos uzi `#[cfg(target_arch)]` ĉefe por kondiĉe kompili kodon kun atomoj.Ankaŭ ekzistas malstabila `#[cfg(target_has_atomic)]`, kiu povas esti stabiligita en la future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Simpla ŝlosilo:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Atendu, ke la alia fadeno liberigu la seruron
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Konservu tutmondan kalkulon de vivaj fadenoj:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Bulea tipo, kiu povas esti sekure dividita inter fadenoj.
///
/// Ĉi tiu tipo havas la saman memoran reprezentadon kiel [`bool`].
///
/// **Noto**: Ĉi tiu tipo estas havebla nur sur platformoj, kiuj subtenas atomajn ŝarĝojn kaj butikojn de `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Kreas `AtomicBool` komencitan al `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send estas implicite efektivigita por AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Kruda montrila tipo, kiu povas esti sekure dividita inter fadenoj.
///
/// Ĉi tiu tipo havas la saman memoran reprezentadon kiel `*mut T`.
///
/// **Noto**: Ĉi tiu tipo disponeblas nur sur platformoj, kiuj subtenas atomajn ŝarĝojn kaj magazenojn de montriloj.
/// Ĝia grandeco dependas de la grandeco de la cela montrilo.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Kreas nulan `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atomaj memordoj
///
/// Memoroj specifas la manieron, ke atomaj operacioj sinkronigas memoron.
/// En ĝia plej malforta [`Ordering::Relaxed`], nur la memoro rekte tuŝita de la operacio estas sinkronigita.
/// Aliflanke, butiko-ŝarĝa paro de [`Ordering::SeqCst`]-operacioj sinkronigas alian memoron, aldone konservante totalan ordon de tiaj operacioj tra ĉiuj fadenoj.
///
///
/// La memoraj mendoj de Rust estas [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Por pliaj informoj vidu la [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Neniuj ordigaj limoj, nur atomaj operacioj.
    ///
    /// Korespondas al [`memory_order_relaxed`] en C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Se kunligite kun butiko, ĉiuj antaŭaj operacioj ordiĝas antaŭ iu ajn ŝarĝo de ĉi tiu valoro kun [`Acquire`] (aŭ pli forta) mendado.
    ///
    /// Precipe ĉiuj antaŭaj skribaĵoj videblas al ĉiuj fadenoj, kiuj plenumas [`Acquire`] (aŭ pli fortan) ŝarĝon de ĉi tiu valoro.
    ///
    /// Rimarku, ke uzi ĉi tiun mendadon por operacio, kiu kombinas ŝarĝojn kaj butikojn, kondukas al ŝarĝa operacio [`Relaxed`]!
    ///
    /// Ĉi tiu mendado aplikeblas nur por operacioj, kiuj povas stoki butikon.
    ///
    /// Korespondas al [`memory_order_release`] en C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Kune kun ŝarĝo, se la ŝarĝita valoro estis skribita per butika operacio kun [`Release`] (aŭ pli forta) mendado, tiam ĉiuj postaj operacioj fariĝas ordigitaj post tiu butiko.
    /// Aparte, ĉiuj postaj ŝarĝoj vidos datumojn skribitajn antaŭ la butiko.
    ///
    /// Rimarku, ke uzi ĉi tiun mendadon por operacio, kiu kombinas ŝarĝojn kaj butikojn, kondukas al butika operacio [`Relaxed`]!
    ///
    /// Ĉi tiu mendado aplikeblas nur por operacioj, kiuj povas plenumi ŝarĝon.
    ///
    /// Korespondas al [`memory_order_acquire`] en C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Havas la efikojn de [`Acquire`] kaj [`Release`] kune:
    /// Por ŝarĝoj ĝi uzas [`Acquire`]-mendadon.Por butikoj ĝi uzas la mendadon [`Release`].
    ///
    /// Rimarku, ke en la kazo de `compare_and_swap`, eblas, ke la operacio finas neniun butikon kaj tial ĝi havas nur [`Acquire`]-mendadon.
    ///
    /// Tamen `AcqRel` neniam plenumos [`Relaxed`]-alirojn.
    ///
    /// Ĉi tiu mendado aplikeblas nur por operacioj, kiuj kombinas ambaŭ ŝarĝojn kaj butikojn.
    ///
    /// Korespondas al [`memory_order_acq_rel`] en C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Ŝatas ["Akiri"]/["Eldoni"]/[`AcqRel"](por ŝarĝo, vendejo kaj ŝarĝo-kun-vendejo respektive) kun la aldona garantio, ke ĉiuj fadenoj vidas ĉiujn sinsekvajn konsekvencajn operaciojn en la sama ordo. .
    ///
    ///
    /// Korespondas al [`memory_order_seq_cst`] en C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] komenciĝis al `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Kreas novan `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Liveras ŝanĝeblan referencon al la suba [`bool`].
    ///
    /// Ĉi tio estas sekura, ĉar la ŝanĝebla referenco garantias, ke neniuj aliaj fadenoj samtempe aliras la atomajn datumojn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SEKURECO: la ŝanĝebla referenco garantias unikan posedon.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Akiru atomaliron al `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SEKURECO: la ŝanĝebla referenco garantias unikan posedon, kaj
        // vicigo de ambaŭ `bool` kaj `Self` estas 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Konsumas la atoman kaj redonas la enhavitan valoron.
    ///
    /// Ĉi tio estas sekura, ĉar preterpasi `self` per valoro garantias, ke neniuj aliaj fadenoj samtempe aliras la atomajn datumojn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Ŝarĝas valoron de la bool.
    ///
    /// `load` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.
    /// Eblaj valoroj estas [`SeqCst`], [`Acquire`] kaj [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` estas [`Release`] aŭ [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SEKURECO: ajnaj datumaj vetkuroj estas malhelpataj de atomaj internaj kaj krudaj
        // montrilo enmetita validas ĉar ni ricevis ĝin de referenco.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Stokas valoron en la bool.
    ///
    /// `store` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.
    /// Eblaj valoroj estas [`SeqCst`], [`Release`] kaj [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` estas [`Acquire`] aŭ [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SEKURECO: ajnaj datumaj vetkuroj estas malhelpataj de atomaj internaj kaj krudaj
        // montrilo enmetita validas ĉar ni ricevis ĝin de referenco.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Stokas valoron en la bool, redonante la antaŭan valoron.
    ///
    /// `swap` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
    /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
    ///
    ///
    /// **Note:** Ĉi tiu metodo disponeblas nur en platformoj, kiuj subtenas atomajn operaciojn en `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Stokas valoron en la [`bool`] se la nuna valoro samas al la `current`-valoro.
    ///
    /// La revenvaloro estas ĉiam la antaŭa valoro.Se ĝi egalas al `current`, tiam la valoro estis ĝisdatigita.
    ///
    /// `compare_and_swap` ankaŭ prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.
    /// Rimarku, ke eĉ uzante [`AcqRel`], la operacio povus malsukcesi kaj do simple plenumi `Acquire`-ŝarĝon, sed ne havi `Release`-semantikon.
    /// Uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`] se ĝi okazas, kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
    ///
    /// **Note:** Ĉi tiu metodo disponeblas nur en platformoj, kiuj subtenas atomajn operaciojn en `u8`.
    ///
    /// # Migrante al `compare_exchange` kaj `compare_exchange_weak`
    ///
    /// `compare_and_swap` estas ekvivalenta al `compare_exchange` kun la sekva mapado por memordoj:
    ///
    /// Originala |Sukceso |Malsukceso
    /// -------- | ------- | -------
    /// Malstreĉita |Malstreĉita |Malstreĉita Akiri |Akiri |Akiri Liberigon |Liberigo |Malstreĉita AcqRel |AcqRel |Akiru SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` rajtas fiaske fuŝe eĉ kiam la komparo sukcesas, kio permesas al la kompililo generi pli bonan kunigokodon kiam la komparo kaj interŝanĝo estas uzataj en buklo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Stokas valoron en la [`bool`] se la nuna valoro samas al la `current`-valoro.
    ///
    /// La revenvaloro estas rezulto indikanta ĉu la nova valoro estis skribita kaj enhavanta la antaŭan valoron.
    /// Sukcese ĉi tiu valoro estas garantiita egala al `current`.
    ///
    /// `compare_exchange` prenas du [`Ordering`]-argumentojn por priskribi la memorordon de ĉi tiu operacio.
    /// `success` priskribas la bezonatan mendadon por la legado-modifo-skribado, kiu okazas se la komparo kun `current` sukcesas.
    /// `failure` priskribas la bezonatan mendadon por la ŝarĝa operacio okazanta kiam la komparo malsukcesas.
    /// Uzi [`Acquire`] kiel sukcesa mendado igas la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la sukcesan ŝarĝon [`Relaxed`].
    ///
    /// La malsukcesa mendado povas esti nur [`SeqCst`], [`Acquire`] aŭ [`Relaxed`] kaj devas esti ekvivalenta aŭ pli malforta ol la sukcesa mendado.
    ///
    /// **Note:** Ĉi tiu metodo disponeblas nur en platformoj, kiuj subtenas atomajn operaciojn en `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Stokas valoron en la [`bool`] se la nuna valoro samas al la `current`-valoro.
    ///
    /// Male al [`AtomicBool::compare_exchange`], ĉi tiu funkcio rajtas fuŝe fiaski eĉ kiam la komparo sukcesas, kio povas rezultigi pli efikan kodon en iuj platformoj.
    ///
    /// La revenvaloro estas rezulto indikanta ĉu la nova valoro estis skribita kaj enhavanta la antaŭan valoron.
    ///
    /// `compare_exchange_weak` prenas du [`Ordering`]-argumentojn por priskribi la memorordon de ĉi tiu operacio.
    /// `success` priskribas la bezonatan mendadon por la legado-modifo-skribado, kiu okazas se la komparo kun `current` sukcesas.
    /// `failure` priskribas la bezonatan mendadon por la ŝarĝa operacio okazanta kiam la komparo malsukcesas.
    /// Uzi [`Acquire`] kiel sukcesa mendado igas la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la sukcesan ŝarĝon [`Relaxed`].
    /// La malsukcesa mendado povas esti nur [`SeqCst`], [`Acquire`] aŭ [`Relaxed`] kaj devas esti ekvivalenta aŭ pli malforta ol la sukcesa mendado.
    ///
    /// **Note:** Ĉi tiu metodo disponeblas nur en platformoj, kiuj subtenas atomajn operaciojn en `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logika "and" kun bulea valoro.
    ///
    /// Elfaras logikan "and"-operacion sur la aktuala valoro kaj la argumento `val`, kaj agordas la novan valoron al la rezulto.
    ///
    /// Liveras la antaŭan valoron.
    ///
    /// `fetch_and` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
    /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
    ///
    ///
    /// **Note:** Ĉi tiu metodo disponeblas nur en platformoj, kiuj subtenas atomajn operaciojn en `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logika "nand" kun bulea valoro.
    ///
    /// Elfaras logikan "nand"-operacion sur la aktuala valoro kaj la argumento `val`, kaj agordas la novan valoron al la rezulto.
    ///
    /// Liveras la antaŭan valoron.
    ///
    /// `fetch_nand` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
    /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
    ///
    ///
    /// **Note:** Ĉi tiu metodo disponeblas nur en platformoj, kiuj subtenas atomajn operaciojn en `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Ni ne povas uzi atom_nand ĉi tie ĉar ĝi povas rezultigi bool kun malvalida valoro.
        // Ĉi tio okazas ĉar la atoma operacio estas farita kun 8-bita entjero interne, kiu starigus la suprajn 7 bitojn.
        //
        // Do ni simple uzas fetch_xor aŭ swap anstataŭe.
        if val {
            // ! (x&true)== !x Ni devas inversigi la bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==vera Ni devas agordi bool al vera.
            //
            self.swap(true, order)
        }
    }

    /// Logika "or" kun bulea valoro.
    ///
    /// Elfaras logikan "or"-operacion sur la aktuala valoro kaj la argumento `val`, kaj agordas la novan valoron al la rezulto.
    ///
    /// Liveras la antaŭan valoron.
    ///
    /// `fetch_or` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
    /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
    ///
    ///
    /// **Note:** Ĉi tiu metodo disponeblas nur en platformoj, kiuj subtenas atomajn operaciojn en `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logika "xor" kun bulea valoro.
    ///
    /// Elfaras logikan "xor"-operacion sur la aktuala valoro kaj la argumento `val`, kaj agordas la novan valoron al la rezulto.
    ///
    /// Liveras la antaŭan valoron.
    ///
    /// `fetch_xor` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
    /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
    ///
    ///
    /// **Note:** Ĉi tiu metodo disponeblas nur en platformoj, kiuj subtenas atomajn operaciojn en `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Redonas ŝanĝeblan montrilon al la suba [`bool`].
    ///
    /// Fari ne-atomajn legadojn kaj skribojn sur la rezulta entjero povas esti datuma vetkuro.
    /// Ĉi tiu metodo estas plejparte utila por FFI, kie la funkcio-subskribo povas uzi `*mut bool` anstataŭ `&AtomicBool`.
    ///
    /// Reveni `*mut`-montrilon de komuna referenco al ĉi tiu atomo estas sekura ĉar la atomaj tipoj funkcias kun interna ŝanĝebleco.
    /// Ĉiuj modifoj de atomo ŝanĝas la valoron per komuna referenco, kaj povas fari ĝin sekure kondiĉe ke ili uzas atomajn operaciojn.
    /// Ĉiu uzo de la redonita kruda montrilo postulas `unsafe`-blokon kaj tamen devas subteni la saman limigon: operacioj sur ĝi devas esti atomaj.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Elprenas la valoron kaj aplikas al ĝi funkcion, kiu redonas laŭvolan novan valoron.Liveras `Result` de `Ok(previous_value)` se la funkcio redonis `Some(_)`, alie `Err(previous_value)`.
    ///
    /// Note: Ĉi tio eble nomos la funkcion plurfoje se la valoro intertempe ŝanĝiĝis de aliaj fadenoj, kondiĉe ke la funkcio redonas `Some(_)`, sed la funkcio estos aplikita nur unufoje al la konservita valoro.
    ///
    ///
    /// `fetch_update` prenas du [`Ordering`]-argumentojn por priskribi la memorordon de ĉi tiu operacio.
    /// La unua priskribas la bezonatan mendadon por kiam la operacio finfine sukcesas dum la dua priskribas la bezonatan mendadon por ŝarĝoj.
    /// Ĉi tiuj respondas respektive al la sukcesaj kaj malsukcesaj mendoj de [`AtomicBool::compare_exchange`].
    ///
    /// Uzi [`Acquire`] kiel sukcesa mendado faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] igas la finan sukcesan ŝarĝon [`Relaxed`].
    /// La ŝarĝa mendado de (failed) povas esti nur [`SeqCst`], [`Acquire`] aŭ [`Relaxed`] kaj devas esti ekvivalenta aŭ pli malforta ol la sukcesa mendado.
    ///
    /// **Note:** Ĉi tiu metodo disponeblas nur en platformoj, kiuj subtenas atomajn operaciojn en `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Kreas novan `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Liveras ŝanĝeblan referencon al la suba montrilo.
    ///
    /// Ĉi tio estas sekura, ĉar la ŝanĝebla referenco garantias, ke neniuj aliaj fadenoj samtempe aliras la atomajn datumojn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Akiru atomaliron al montrilo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - la ŝanĝebla referenco garantias unikan posedon.
        //  - la vicigo de `*mut T` kaj `Self` samas sur ĉiuj platformoj subtenataj de rust, kiel konfirmite supre.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Konsumas la atoman kaj redonas la enhavitan valoron.
    ///
    /// Ĉi tio estas sekura, ĉar preterpasi `self` per valoro garantias, ke neniuj aliaj fadenoj samtempe aliras la atomajn datumojn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Ŝarĝas valoron de la montrilo.
    ///
    /// `load` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.
    /// Eblaj valoroj estas [`SeqCst`], [`Acquire`] kaj [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` estas [`Release`] aŭ [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Stokas valoron en la montrilon.
    ///
    /// `store` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.
    /// Eblaj valoroj estas [`SeqCst`], [`Release`] kaj [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` estas [`Acquire`] aŭ [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Stokas valoron en la montrilon, redonante la antaŭan valoron.
    ///
    /// `swap` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
    /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
    ///
    ///
    /// **Note:** Ĉi tiu metodo disponeblas nur sur platformoj, kiuj subtenas atomajn operaciojn per montriloj.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Stokas valoron en la montrilon se la nuna valoro samas al la `current`-valoro.
    ///
    /// La revenvaloro estas ĉiam la antaŭa valoro.Se ĝi egalas al `current`, tiam la valoro estis ĝisdatigita.
    ///
    /// `compare_and_swap` ankaŭ prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.
    /// Rimarku, ke eĉ uzante [`AcqRel`], la operacio povus malsukcesi kaj do simple plenumi `Acquire`-ŝarĝon, sed ne havi `Release`-semantikon.
    /// Uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`] se ĝi okazas, kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
    ///
    /// **Note:** Ĉi tiu metodo disponeblas nur sur platformoj, kiuj subtenas atomajn operaciojn per montriloj.
    ///
    /// # Migrante al `compare_exchange` kaj `compare_exchange_weak`
    ///
    /// `compare_and_swap` estas ekvivalenta al `compare_exchange` kun la sekva mapado por memordoj:
    ///
    /// Originala |Sukceso |Malsukceso
    /// -------- | ------- | -------
    /// Malstreĉita |Malstreĉita |Malstreĉita Akiri |Akiri |Akiri Liberigon |Liberigo |Malstreĉita AcqRel |AcqRel |Akiru SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` rajtas fiaske fuŝe eĉ kiam la komparo sukcesas, kio permesas al la kompililo generi pli bonan kunigokodon kiam la komparo kaj interŝanĝo estas uzataj en buklo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Stokas valoron en la montrilon se la nuna valoro samas al la `current`-valoro.
    ///
    /// La revenvaloro estas rezulto indikanta ĉu la nova valoro estis skribita kaj enhavanta la antaŭan valoron.
    /// Sukcese ĉi tiu valoro estas garantiita egala al `current`.
    ///
    /// `compare_exchange` prenas du [`Ordering`]-argumentojn por priskribi la memorordon de ĉi tiu operacio.
    /// `success` priskribas la bezonatan mendadon por la legado-modifo-skribado, kiu okazas se la komparo kun `current` sukcesas.
    /// `failure` priskribas la bezonatan mendadon por la ŝarĝa operacio okazanta kiam la komparo malsukcesas.
    /// Uzi [`Acquire`] kiel sukcesa mendado igas la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la sukcesan ŝarĝon [`Relaxed`].
    ///
    /// La malsukcesa mendado povas esti nur [`SeqCst`], [`Acquire`] aŭ [`Relaxed`] kaj devas esti ekvivalenta aŭ pli malforta ol la sukcesa mendado.
    ///
    /// **Note:** Ĉi tiu metodo disponeblas nur sur platformoj, kiuj subtenas atomajn operaciojn per montriloj.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Stokas valoron en la montrilon se la nuna valoro samas al la `current`-valoro.
    ///
    /// Male al [`AtomicPtr::compare_exchange`], ĉi tiu funkcio rajtas fuŝe fiaski eĉ kiam la komparo sukcesas, kio povas rezultigi pli efikan kodon en iuj platformoj.
    ///
    /// La revenvaloro estas rezulto indikanta ĉu la nova valoro estis skribita kaj enhavanta la antaŭan valoron.
    ///
    /// `compare_exchange_weak` prenas du [`Ordering`]-argumentojn por priskribi la memorordon de ĉi tiu operacio.
    /// `success` priskribas la bezonatan mendadon por la legado-modifo-skribado, kiu okazas se la komparo kun `current` sukcesas.
    /// `failure` priskribas la bezonatan mendadon por la ŝarĝa operacio okazanta kiam la komparo malsukcesas.
    /// Uzi [`Acquire`] kiel sukcesa mendado igas la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la sukcesan ŝarĝon [`Relaxed`].
    /// La malsukcesa mendado povas esti nur [`SeqCst`], [`Acquire`] aŭ [`Relaxed`] kaj devas esti ekvivalenta aŭ pli malforta ol la sukcesa mendado.
    ///
    /// **Note:** Ĉi tiu metodo disponeblas nur sur platformoj, kiuj subtenas atomajn operaciojn per montriloj.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SEKURECO: Ĉi tiu eneca estas nesekura ĉar ĝi funkcias per kruda montrilo
        // sed ni certe scias, ke la montrilo validas (ni ĵus akiris ĝin de `UnsafeCell`, kiun ni havas per referenco) kaj la atoma operacio mem permesas al ni sekure mutacii la enhavon de `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Elprenas la valoron kaj aplikas al ĝi funkcion, kiu redonas laŭvolan novan valoron.Liveras `Result` de `Ok(previous_value)` se la funkcio redonis `Some(_)`, alie `Err(previous_value)`.
    ///
    /// Note: Ĉi tio eble nomos la funkcion plurfoje se la valoro intertempe ŝanĝiĝis de aliaj fadenoj, kondiĉe ke la funkcio redonas `Some(_)`, sed la funkcio estos aplikita nur unufoje al la konservita valoro.
    ///
    ///
    /// `fetch_update` prenas du [`Ordering`]-argumentojn por priskribi la memorordon de ĉi tiu operacio.
    /// La unua priskribas la bezonatan mendadon por kiam la operacio finfine sukcesas dum la dua priskribas la bezonatan mendadon por ŝarĝoj.
    /// Ĉi tiuj respondas respektive al la sukcesaj kaj malsukcesaj mendoj de [`AtomicPtr::compare_exchange`].
    ///
    /// Uzi [`Acquire`] kiel sukcesa mendado faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] igas la finan sukcesan ŝarĝon [`Relaxed`].
    /// La ŝarĝa mendado de (failed) povas esti nur [`SeqCst`], [`Acquire`] aŭ [`Relaxed`] kaj devas esti ekvivalenta aŭ pli malforta ol la sukcesa mendado.
    ///
    /// **Note:** Ĉi tiu metodo disponeblas nur sur platformoj, kiuj subtenas atomajn operaciojn per montriloj.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Konvertas `bool` en `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Ĉi tiu makroo finiĝas neuzata en iuj arkitekturoj.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Entjera tipo, kiu povas esti sekure dividita inter fadenoj.
        ///
        /// Ĉi tiu tipo havas la saman memoran reprezenton kiel la suba entjera tipo, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Por pli pri la diferencoj inter atomaj tipoj kaj ne-atomaj specoj kaj informoj pri la porteblo de ĉi tiu tipo, bonvolu vidi la [module-level documentation].
        ///
        ///
        /// **Note:** Ĉi tiu tipo estas disponebla nur en platformoj, kiuj subtenas atomajn ŝarĝojn kaj butikojn de [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Atoma entjero komencita al `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Sendo estas implicite efektivigita.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Kreas novan atoman entjeron.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Liveras ŝanĝeblan referencon al la suba entjero.
            ///
            /// Ĉi tio estas sekura, ĉar la ŝanĝebla referenco garantias, ke neniuj aliaj fadenoj samtempe aliras la atomajn datumojn.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// let mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// aserti_ek! (iuj_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - la ŝanĝebla referenco garantias unikan posedon.
                //  - la vicigo de `$int_type` kaj `Self` samas, kiel promesis $cfg_align kaj kontrolis supre.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Konsumas la atoman kaj redonas la enhavitan valoron.
            ///
            /// Ĉi tio estas sekura, ĉar preterpasi `self` per valoro garantias, ke neniuj aliaj fadenoj samtempe aliras la atomajn datumojn.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Ŝarĝas valoron de la atoma entjero.
            ///
            /// `load` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.
            /// Eblaj valoroj estas [`SeqCst`], [`Acquire`] kaj [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics se `order` estas [`Release`] aŭ [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Stokas valoron en la atoma entjero.
            ///
            /// `store` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.
            ///  Eblaj valoroj estas [`SeqCst`], [`Release`] kaj [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics se `order` estas [`Acquire`] aŭ [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Stokas valoron en la atoman entjeron, redonante la antaŭan valoron.
            ///
            /// `swap` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
            /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
            ///
            ///
            /// **Noto**: Ĉi tiu metodo haveblas nur sur platformoj, kiuj subtenas atomajn operaciojn
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Stokas valoron en la atoman entjeron se la nuna valoro samas al la `current`-valoro.
            ///
            /// La revenvaloro estas ĉiam la antaŭa valoro.Se ĝi egalas al `current`, tiam la valoro estis ĝisdatigita.
            ///
            /// `compare_and_swap` ankaŭ prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.
            /// Rimarku, ke eĉ uzante [`AcqRel`], la operacio povus malsukcesi kaj do simple plenumi `Acquire`-ŝarĝon, sed ne havi `Release`-semantikon.
            ///
            /// Uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`] se ĝi okazas, kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
            ///
            /// **Noto**: Ĉi tiu metodo haveblas nur sur platformoj, kiuj subtenas atomajn operaciojn
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migrante al `compare_exchange` kaj `compare_exchange_weak`
            ///
            /// `compare_and_swap` estas ekvivalenta al `compare_exchange` kun la sekva mapado por memordoj:
            ///
            /// Originala |Sukceso |Malsukceso
            /// -------- | ------- | -------
            /// Malstreĉita |Malstreĉita |Malstreĉita Akiri |Akiri |Akiri Liberigon |Liberigo |Malstreĉita AcqRel |AcqRel |Akiru SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` rajtas fiaske fuŝe eĉ kiam la komparo sukcesas, kio permesas al la kompililo generi pli bonan kunigokodon kiam la komparo kaj interŝanĝo estas uzataj en buklo.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Stokas valoron en la atoman entjeron se la nuna valoro samas al la `current`-valoro.
            ///
            /// La revenvaloro estas rezulto indikanta ĉu la nova valoro estis skribita kaj enhavanta la antaŭan valoron.
            /// Sukcese ĉi tiu valoro estas garantiita egala al `current`.
            ///
            /// `compare_exchange` prenas du [`Ordering`]-argumentojn por priskribi la memorordon de ĉi tiu operacio.
            /// `success` priskribas la bezonatan mendadon por la legado-modifo-skribado, kiu okazas se la komparo kun `current` sukcesas.
            /// `failure` priskribas la bezonatan mendadon por la ŝarĝa operacio okazanta kiam la komparo malsukcesas.
            /// Uzi [`Acquire`] kiel sukcesa mendado igas la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la sukcesan ŝarĝon [`Relaxed`].
            ///
            /// La malsukcesa mendado povas esti nur [`SeqCst`], [`Acquire`] aŭ [`Relaxed`] kaj devas esti ekvivalenta aŭ pli malforta ol la sukcesa mendado.
            ///
            /// **Noto**: Ĉi tiu metodo haveblas nur sur platformoj, kiuj subtenas atomajn operaciojn
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Stokas valoron en la atoman entjeron se la nuna valoro samas al la `current`-valoro.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ĉi tiu funkcio rajtas fuŝe fiaski eĉ kiam la komparo sukcesas, kio povas rezultigi pli efikan kodon en iuj platformoj.
            /// La revenvaloro estas rezulto indikanta ĉu la nova valoro estis skribita kaj enhavanta la antaŭan valoron.
            ///
            /// `compare_exchange_weak` prenas du [`Ordering`]-argumentojn por priskribi la memorordon de ĉi tiu operacio.
            /// `success` priskribas la bezonatan mendadon por la legado-modifo-skribado, kiu okazas se la komparo kun `current` sukcesas.
            /// `failure` priskribas la bezonatan mendadon por la ŝarĝa operacio okazanta kiam la komparo malsukcesas.
            /// Uzi [`Acquire`] kiel sukcesa mendado igas la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la sukcesan ŝarĝon [`Relaxed`].
            ///
            /// La malsukcesa mendado povas esti nur [`SeqCst`], [`Acquire`] aŭ [`Relaxed`] kaj devas esti ekvivalenta aŭ pli malforta ol la sukcesa mendado.
            ///
            /// **Noto**: Ĉi tiu metodo haveblas nur sur platformoj, kiuj subtenas atomajn operaciojn
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// let mut old= val.load(Ordering::Relaxed);
            /// buklo {lasu novan=malnovan * 2;
            ///     kongrui kun val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Aldonas al la aktuala valoro, redonante la antaŭan valoron.
            ///
            /// Ĉi tiu operacio ĉirkaŭfluas.
            ///
            /// `fetch_add` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
            /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
            ///
            ///
            /// **Noto**: Ĉi tiu metodo haveblas nur sur platformoj, kiuj subtenas atomajn operaciojn
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Subtrahas de la nuna valoro, redonante la antaŭan valoron.
            ///
            /// Ĉi tiu operacio ĉirkaŭfluas.
            ///
            /// `fetch_sub` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
            /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
            ///
            ///
            /// **Noto**: Ĉi tiu metodo haveblas nur sur platformoj, kiuj subtenas atomajn operaciojn
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" kun la nuna valoro.
            ///
            /// Elfaras bitan "and"-operacion sur la aktuala valoro kaj la argumento `val`, kaj agordas la novan valoron al la rezulto.
            ///
            /// Liveras la antaŭan valoron.
            ///
            /// `fetch_and` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
            /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
            ///
            ///
            /// **Noto**: Ĉi tiu metodo haveblas nur sur platformoj, kiuj subtenas atomajn operaciojn
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" kun la nuna valoro.
            ///
            /// Elfaras bitan "nand"-operacion sur la aktuala valoro kaj la argumento `val`, kaj agordas la novan valoron al la rezulto.
            ///
            /// Liveras la antaŭan valoron.
            ///
            /// `fetch_nand` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
            /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
            ///
            ///
            /// **Noto**: Ĉi tiu metodo haveblas nur sur platformoj, kiuj subtenas atomajn operaciojn
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" kun la nuna valoro.
            ///
            /// Elfaras bitan "or"-operacion sur la aktuala valoro kaj la argumento `val`, kaj agordas la novan valoron al la rezulto.
            ///
            /// Liveras la antaŭan valoron.
            ///
            /// `fetch_or` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
            /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
            ///
            ///
            /// **Noto**: Ĉi tiu metodo haveblas nur sur platformoj, kiuj subtenas atomajn operaciojn
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" kun la nuna valoro.
            ///
            /// Elfaras bitan "xor"-operacion sur la aktuala valoro kaj la argumento `val`, kaj agordas la novan valoron al la rezulto.
            ///
            /// Liveras la antaŭan valoron.
            ///
            /// `fetch_xor` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
            /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
            ///
            ///
            /// **Noto**: Ĉi tiu metodo haveblas nur sur platformoj, kiuj subtenas atomajn operaciojn
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Elprenas la valoron kaj aplikas al ĝi funkcion, kiu redonas laŭvolan novan valoron.Liveras `Result` de `Ok(previous_value)` se la funkcio redonis `Some(_)`, alie `Err(previous_value)`.
            ///
            /// Note: Ĉi tio eble nomos la funkcion plurfoje se la valoro intertempe ŝanĝiĝis de aliaj fadenoj, kondiĉe ke la funkcio redonas `Some(_)`, sed la funkcio estos aplikita nur unufoje al la konservita valoro.
            ///
            ///
            /// `fetch_update` prenas du [`Ordering`]-argumentojn por priskribi la memorordon de ĉi tiu operacio.
            /// La unua priskribas la bezonatan mendadon por kiam la operacio finfine sukcesas dum la dua priskribas la bezonatan mendadon por ŝarĝoj.Ĉi tiuj respondas al la sukcesaj kaj malsukcesaj mendoj de
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Uzi [`Acquire`] kiel sukcesa mendado faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] igas la finan sukcesan ŝarĝon [`Relaxed`].
            /// La ŝarĝa mendado de (failed) povas esti nur [`SeqCst`], [`Acquire`] aŭ [`Relaxed`] kaj devas esti ekvivalenta aŭ pli malforta ol la sukcesa mendado.
            ///
            /// **Noto**: Ĉi tiu metodo haveblas nur sur platformoj, kiuj subtenas atomajn operaciojn
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Ordo: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Ordo: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maksimumo kun la nuna valoro.
            ///
            /// Trovas la maksimumon de la aktuala valoro kaj la argumento `val`, kaj agordas la novan valoron al la rezulto.
            ///
            /// Liveras la antaŭan valoron.
            ///
            /// `fetch_max` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
            /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
            ///
            ///
            /// **Noto**: Ĉi tiu metodo haveblas nur sur platformoj, kiuj subtenas atomajn operaciojn
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// lasu stangon=42;
            /// lasu max_foo=foo.fetch_max (stango, Ordering::SeqCst).max(bar);
            /// aserti! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimumo kun la nuna valoro.
            ///
            /// Trovas la minimumon de la aktuala valoro kaj la argumento `val`, kaj agordas la novan valoron al la rezulto.
            ///
            /// Liveras la antaŭan valoron.
            ///
            /// `fetch_min` prenas [`Ordering`]-argumenton, kiu priskribas la memorordon de ĉi tiu operacio.Ĉiuj mendaj reĝimoj eblas.
            /// Notu, ke uzi [`Acquire`] faras la butikon parto de ĉi tiu operacio [`Relaxed`], kaj uzi [`Release`] faras la ŝarĝan parton [`Relaxed`].
            ///
            ///
            /// **Noto**: Ĉi tiu metodo haveblas nur sur platformoj, kiuj subtenas atomajn operaciojn
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// lasu stangon=12;
            /// lasu min_foo=foo.fetch_min (stango, Ordering::SeqCst).min(bar);
            /// aserti_ek! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKURECO: datumaj vetkuroj estas malhelpataj de atomaj internuloj.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Redonas ŝanĝeblan montrilon al la suba entjero.
            ///
            /// Fari ne-atomajn legadojn kaj skribojn sur la rezulta entjero povas esti datuma vetkuro.
            /// Ĉi tiu metodo estas plejparte utila por FFI, kie la funkcio-subskribo povas uzi
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Reveni `*mut`-montrilon de komuna referenco al ĉi tiu atomo estas sekura ĉar la atomaj tipoj funkcias kun interna ŝanĝebleco.
            /// Ĉiuj modifoj de atomo ŝanĝas la valoron per komuna referenco, kaj povas fari ĝin sekure kondiĉe ke ili uzas atomajn operaciojn.
            /// Ĉiu uzo de la redonita kruda montrilo postulas `unsafe`-blokon kaj tamen devas subteni la saman limigon: operacioj sur ĝi devas esti atomaj.
            ///
            ///
            /// # Examples
            ///
            /// "" ignori (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SEKURECO: Sekura kondiĉe ke `my_atomic_op` estas atoma.
            /// nesekura {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Liveras la antaŭan valoron (kiel __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Liveras la antaŭan valoron (kiel __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// redonas la maksimuman valoron (subskribita komparo)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// redonas la minimuman valoron (subskribita komparo)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// redonas la maksimuman valoron (sennoma komparo)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// redonas la valoron min (sennoma komparo)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Atoma barilo.
///
/// Depende de la specifa ordo, barilo malhelpas la kompililon kaj CPU reordigi iujn specojn de memoraj operacioj ĉirkaŭ ĝi.
/// Tio kreas sinkronigajn rilatojn inter ĝi kaj atomaj operacioj aŭ bariloj en aliaj fadenoj.
///
/// Barilo 'A', kiu havas (almenaŭ) [`Release`] ordigante semantikon, sinkronigas kun barilo 'B' kun (almenaŭ) [`Acquire`]-semantiko, se kaj nur se ekzistas operacioj X kaj Y, ambaŭ funkciantaj sur iu atomobjekto 'M' tia, ke A estas sekvencita antaŭe X, Y estas sinkronigita antaŭ ol B kaj Y observas la ŝanĝon al M.
/// Ĉi tio provizas antaŭan dependecon inter A kaj B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atomaj operacioj kun [`Release`] aŭ [`Acquire`]-semantiko ankaŭ povas sinkronigi kun barilo.
///
/// Barilo, kiu havas [`SeqCst`]-mendadon, krom havi kaj [`Acquire`] kaj [`Release`]-semantikon, partoprenas la tutmondan programordon de la aliaj [`SeqCst`]-operacioj kaj/aŭ bariloj.
///
/// Akceptas mendojn [`Acquire`], [`Release`], [`AcqRel`] kaj [`SeqCst`].
///
/// # Panics
///
/// Panics se `order` estas [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Reciproka ekskluda primitivulo bazita sur spinkluzo.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Atendu ĝis la malnova valoro estas `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Ĉi tiu barilo sinkronigas-kun butiko en `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SEKURECO: uzi atombarilon estas sekure.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Kompila membarilo.
///
/// `compiler_fence` ne elsendas ajnan maŝinkodon, sed limigas la specojn de memoro, ke la kompililo rajtas fari.Specife, depende de la donita [`Ordering`]-semantiko, la kompililo povas esti malpermesita movi legaĵojn aŭ skribojn de antaŭ aŭ post la alvoko al la alia flanko de la alvoko al `compiler_fence`.Notu, ke ĝi **ne** malebligas al la *aparataro* fari tian reordigon.
///
/// Ĉi tio ne estas problemo en unu-fadena ekzekuta kunteksto, sed kiam aliaj fadenoj povas modifi memoron samtempe, necesas pli fortaj sinkronigaj primitivuloj kiel [`fence`].
///
/// La reordigo malebligita de la malsamaj ordigaj semantikoj estas:
///
///  - kun [`SeqCst`], neniu reordigo de legaĵoj kaj skriboj trans ĉi tiu punkto estas permesita.
///  - kun [`Release`], antaŭaj legadoj kaj skriboj ne povas esti movitaj preter postaj skriboj.
///  - kun [`Acquire`], postaj legadoj kaj skriboj ne povas esti antaŭitaj antaŭ antaŭaj legaĵoj.
///  - kun [`AcqRel`], ambaŭ ĉi-supraj reguloj estas plenumataj.
///
/// `compiler_fence` ĝenerale utilas nur por malebligi ke fadeno kuregas *kun si mem*.Tio estas, se donita fadeno plenumas unu kodopecon, kaj tiam estas interrompita, kaj komencas ekzekuti kodon aliloke (dum ankoraŭ en la sama fadeno, kaj koncipe ankoraŭ sur la sama kerno).En tradiciaj programoj, tio povas okazi nur kiam signal-pritraktanto estas registrita.
/// En pli malaltnivela kodo, tiaj situacioj ankaŭ povas ekesti dum pritraktado de interrompoj, kiam efektivigado de verdaj fadenoj kun antaŭpreno, ktp.
/// Scivolemaj legantoj estas kuraĝigitaj legi la diskuton de la kerno Linux pri [memory barriers].
///
/// # Panics
///
/// Panics se `order` estas [`Relaxed`].
///
/// # Examples
///
/// Sen `compiler_fence`, la `assert_eq!` en sekva kodo *ne* garantias sukcesi, malgraŭ ĉio okazanta en unu fadeno.
/// Por vidi kial, memoru, ke la kompililo rajtas interŝanĝi la butikojn al `IMPORTANT_VARIABLE` kaj `IS_READ`, ĉar ambaŭ estas `Ordering::Relaxed`.Se jes, kaj la signalprizorganto estas alvokita tuj post kiam `IS_READY` estas ĝisdatigita, tiam la signalprizorganto vidos `IS_READY=1`, sed `IMPORTANT_VARIABLE=0`.
/// Uzi `compiler_fence`-rimedojn kontraŭ ĉi tiu situacio.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // malebligi ke antaŭaj skriboj estu movitaj preter ĉi tiu punkto
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SEKURECO: uzi atombarilon estas sekure.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Signalas la procesoron, ke ĝi estas ene de okupata-atendata spino-buklo ("spino-seruro").
///
/// Ĉi tiu funkcio estas malrekomendata favore al [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}