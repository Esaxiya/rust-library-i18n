//! Tipoj, kiuj fiksas datumojn al ĝia loko en memoro.
//!
//! Iafoje estas utile havi objektojn garantiitajn ne moviĝi, en la senco ke ilia lokado en memoro ne ŝanĝiĝas, kaj tiel oni povas fidi ĝin.
//! Ĉefa ekzemplo de tia scenaro estus konstruado de memreferencaj strukturoj, ĉar movi objekton kun montriloj al si mem malvalidigos ilin, kio povus kaŭzi nedifinitan konduton.
//!
//! Je alta nivelo, [`Pin<P>`] certigas, ke la punkto de iu ajn montrila tipo `P` havas stabilan lokon en memoro, kio signifas, ke ĝi ne povas esti movita aliloken kaj ĝia memoro ne povas esti transdistribuita ĝis ĝi falos.Ni diras, ke la punkto estas "pinned".Aferoj fariĝas pli subtilaj kiam oni diskutas pri tipoj, kiuj kombinas alpinglitajn kun ne-alpinglitaj datumoj;[see below](#projections-and-structural-pinning) por pli da detaloj.
//!
//! Defaŭlte ĉiuj specoj en Rust estas moveblaj.
//! Rust permesas preterpasi ĉiujn tipojn laŭvalore, kaj oftaj inteligentaj specoj kiel [`Box<T>`] kaj `&mut T` permesas anstataŭigi kaj movi la valorojn, kiujn ili enhavas: vi povas eliri el [`Box<T>`], aŭ vi povas uzi [`mem::swap`].
//! [`Pin<P>`] envolvas montrilon tipo `P`, do [`Pin ']` <`[` Skatolo`]`<T>> `funkcias simile al regula
//!
//! [`Box<T>`]: when a [`Pin ']` <`[` Skatolo`]`<T>> `falas, do ankaŭ ĝia enhavo, kaj la memoro malaperas
//!
//! deallocated.Simile, ["Pin"] "<&mut T>" tre similas al `&mut T`.Tamen [`Pin<P>`] ne lasas klientojn efektive akiri [`Box<T>`] aŭ `&mut T` al alpinglitaj datumoj, kio implicas, ke vi ne povas uzi operaciojn kiel [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` bezonas `&mut T`, sed ni ne povas akiri ĝin.
//!     // Ni estas blokitaj, ni ne povas interŝanĝi la enhavon de ĉi tiuj referencoj.
//!     // Ni povus uzi `Pin::get_unchecked_mut`, sed tio estas nesekura pro kialo:
//!     // ni ne rajtas uzi ĝin por movi aĵojn el la `Pin`.
//! }
//! ```
//!
//! Indas ripeti, ke [`Pin<P>`]*ne* ŝanĝas la fakton, ke kompililo Rust konsideras ĉiujn specojn moveblaj.[`mem::swap`] restas vokinda por iu `T`.Anstataŭe, [`Pin<P>`] malebligas movadon de iuj *valoroj*(montritaj per montriloj kun [`Pin<P>`]) malebligante voki metodojn, kiuj postulas `&mut T` sur ili (kiel [`mem::swap`]).
//!
//! [`Pin<P>`] povas esti uzata por envolvi iun ajn montrilon tipo `P`, kaj kiel tia ĝi interagas kun [`Deref`] kaj [`DerefMut`].[`Pin<P>`] kie `P: Deref` devas esti konsiderata kiel "`P`-style pointer" al alpinglita `P::Target`-do, ["Stifto"] "<" [`Skatolo"] `<T>>`estas posedata montrilo al alpinglita `T`, kaj [`Pin ']`<`[`Rc`]`<T>> `estas referenc-kalkulita montrilo al alpinglita `T`.
//! Por ĝusteco, [`Pin<P>`] dependas de la efektivigoj de [`Deref`] kaj [`DerefMut`] por ne eliri el ilia `self`-parametro, kaj nur iam redoni montrilon al alpinglitaj datumoj kiam ili estas vokitaj al alpinglita montrilo.
//!
//! # `Unpin`
//!
//! Multaj tipoj estas ĉiam libere moveblaj, eĉ kiam alpinglitaj, ĉar ili ne dependas de havado de stabila adreso.Ĉi tio inkluzivas ĉiujn bazajn tipojn (kiel [`bool`], [`i32`] kaj referencoj) kaj ankaŭ tipojn konsistantajn nur el ĉi tiuj tipoj.Tipoj, kiuj ne zorgas pri alpinglado, efektivigas la [`Unpin`]-aŭtomatan trait, kiu nuligas la efikon de [`Pin<P>`].
//! Por `T: Unpin`, [`Pin ']` <`[` Skatolo`]`<T>> `kaj [`Box<T>`] funkcias idente, same kiel [` Pin`]`<&mut T>` kaj `&mut T`.
//!
//! Notu, ke alpingli kaj [`Unpin`] nur influas la pintan tipon `P::Target`, ne la montrilon de tipo `P` mem, kiu envolvis sin en [`Pin<P>`].Ekzemple, ĉu [`Box<T>`] estas aŭ ne [`Unpin`] havas nenian efikon sur la konduto de [`Pin ']` <`[` Box'] `<T>>`(ĉi tie, `T` estas la indikita tipo).
//!
//! # Ekzemplo: memreferenca strukturo
//!
//! Antaŭ ol eniri pli da detaloj por klarigi la garantiojn kaj elektojn asociitajn kun `Pin<T>`, ni diskutas iujn ekzemplojn pri kiel ĝi povus esti uzata.
//! Bonvolu [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Ĉi tio estas memreferenca strukturo ĉar la tranĉa kampo montras al la datuma kampo.
//! // Ni ne povas informi la kompilanton pri tio per normala referenco, ĉar ĉi tiu ŝablono ne povas esti priskribita per la kutimaj pruntaj reguloj.
//! //
//! // Anstataŭe ni uzas krudan montrilon, kvankam oni scias, ke ĝi ne estas nula, ĉar ni scias, ke ĝi montras al la ĉeno.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Por certigi, ke la datumoj ne moviĝas kiam la funkcio revenas, ni metas ilin en la amason, kie ĝi restos dum la vivo de la objekto, kaj la sola maniero aliri ĝin estus per montrilo al ĝi.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // ni nur kreas la montrilon post kiam la datumoj estas en loko, alie ĝi jam moviĝos antaŭ ol ni eĉ komencos
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // ni scias, ke tio estas sekura, ĉar modifi kampon ne movas la tutan strukturon
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // La montrilo devas indiki la ĝustan lokon, kondiĉe ke la strukt ne moviĝis.
//! //
//! // Dume ni rajtas movi la montrilon.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Ĉar nia tipo ne efektivigas Unpin, ĉi tio malsukcesos kompili:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Ekzemplo: trudema duoble ligita listo
//!
//! En truda duoble ligita listo, la kolekto fakte ne asignas la memoron por la elementoj mem.
//! Asigno estas kontrolita de la klientoj, kaj elementoj povas vivi sur staka kadro, kiu vivas pli mallonge ol la kolekto.
//!
//! Por funkciigi ĉi tiun elementon, ĉiu elemento havas montrilojn al sia antaŭulo kaj posteulo en la listo.Elementoj povas esti aldonitaj nur kiam ili estas alpinglitaj, ĉar movi la elementojn ĉirkaŭe malvalidigus la montrilojn.Cetere, la [`Drop`]-efektivigo de ligita listo-elemento flikos la montrilojn de sia antaŭulo kaj posteulo por forigi sin de la listo.
//!
//! Decide ni devas povi fidi, ke oni vokas [`drop`].Se elemento povus esti dislokigita aŭ alie nuligita sen voki [`drop`], la montriloj en ĝin de ĝiaj najbaraj elementoj iĝus malvalidaj, kio rompus la datuman strukturon.
//!
//! Tial, alpingli ankaŭ venas kun rilato kun ['guto]].
//!
//! # `Drop` guarantee
//!
//! La celo de alpinglado estas povi fidi je la lokigo de iuj datumoj en memoro.
//! Por funkciigi ĉi tion, ne nur movi la datumojn estas limigita;ankaŭ disdoni, reuzi aŭ alimaniere nuligi la memoron uzitan por stoki la datumojn ankaŭ estas limigita.
//! Konkrete, por alpinglitaj datumoj vi devas konservi la senvarianton, ke *ĝia memoro ne malvalidiĝos aŭ reuziĝos de la momento, kiam ĝi estas alpinglita ĝis kiam [`drop`] estas vokita*.Nur post kiam [`drop`] revenas aŭ panics, la memoro povas esti reuzata.
//!
//! Memoro povas esti "invalidated" per dislokigo, sed ankaŭ anstataŭigi [`Some(v)`] per [`None`], aŭ voki [`Vec::set_len`] al "kill" iujn elementojn for de vector.Ĝi povas esti reuzata uzante [`ptr::write`] por anstataŭigi ĝin sen unue nomi la detruanton.Nenio el ĉi tio estas permesita por alpinglitaj datumoj sen voki [`drop`].
//!
//! Ĉi tio estas ĝuste la speco de garantio, ke la trudema ligita listo de la antaŭa sekcio devas funkcii ĝuste.
//!
//! Rimarku, ke ĉi tiu garantio *ne* signifas, ke memoro ne likas!Ankoraŭ estas tute bone ne iam telefoni al [`drop`] per alpinglita elemento (ekz. Vi ankoraŭ povas telefoni al [`mem::forget`] per [`Pinglo]]` <`[` Kesto`]`<T>> `).En la ekzemplo de la duoble ligita listo, tiu elemento simple restus en la listo.Tamen vi ne rajtas liberigi aŭ reuzi la stokadon *sen voki [`faligi`]*.
//!
//! # `Drop` implementation
//!
//! Se via tipo uzas alpingladon (kiel la du supraj ekzemploj), vi devas zorgi dum efektivigo de [`Drop`].La funkcio [`drop`] prenas `&mut self`, sed tio nomiĝas *eĉ se via tipo antaŭe estis alpinglita*!Estas kvazaŭ la kompililo aŭtomate nomis [`Pin::get_unchecked_mut`].
//!
//! Ĉi tio neniam povas kaŭzi problemon pri sekura kodo, ĉar efektivigi tipon, kiu dependas de alpinglado, bezonas nesekuran kodon, sed atentu, ke decidi uzi pinping en via tipo (ekzemple per efektivigo de iu operacio sur [`Pin ']` <&Self> `aŭ [` Pin '] `<&mut Self>`) havas konsekvencojn ankaŭ por via [`Drop`]-efektivigo: se elemento de via tipo povus esti alpinglita, vi devas trakti [`Drop`] kiel implicite prenante [`Pin`]`<&mut Mem>`.
//!
//!
//! Ekzemple, vi povus efektivigi `Drop` jene:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` estas en ordo, ĉar ni scias, ke ĉi tiu valoro neniam plu estas uzata post falo.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Fakta faliga kodo iras ĉi tien.
//!         }
//!     }
//! }
//! ```
//!
//! La funkcio `inner_drop` havas la tipon, kiun [`drop`]*devas* havi, do tio certigas, ke vi ne hazarde uzas `self`/`this` en maniero, kiu estas en konflikto kun alpinglado.
//!
//! Cetere, se via tipo estas `#[repr(packed)]`, la kompililo aŭtomate movos kampojn por povi faligi ilin.Ĝi eĉ povus fari tion por kampoj, kiuj hazarde estas sufiĉe vicigitaj.Sekve de tio vi ne povas uzi alpingli kun `#[repr(packed)]`-speco.
//!
//! # Projekcioj kaj Struktura Alpinglado
//!
//! Laborante kun alpinglitaj strukturoj, ekestas la demando, kiel oni povas aliri la kampojn de tiu strukturo en metodo, kiu prenas nur ['Pin'] `<&mut Struct>`.
//! La kutima aliro estas skribi helpajn metodojn (tiel nomatajn *projekciojn*), kiuj turnas [`Pin ']` <&mut Struct> `al referenco al la kampo, sed kian tipon tiu referenco devas havi?Ĉu ĝi estas [`Pin ']`<&mut Field>`aŭ `&mut Field`?
//! La sama demando aperas kun la kampoj de `enum`, kaj ankaŭ kiam oni konsideras container/wrapper-specojn kiel [`Vec<T>`], [`Box<T>`] aŭ [`RefCell<T>`].
//! (Ĉi tiu demando validas por ambaŭ ŝanĝeblaj kaj komunaj referencoj, ni nur uzas la pli oftan kazon de ŝanĝeblaj referencoj ĉi tie por ilustri.)
//!
//! Rezultas, ke efektive dependas de la aŭtoro de la datuma strukturo decidi ĉu la alpinglita projekcio por specifa kampo transformas [`Pin ']` <&mut Struct> `en [` Pin'] `<&mut Field>` aŭ `&mut Field`.Tamen estas iuj limoj, kaj la plej grava limo estas *consistency*:
//! ĉiu kampo povas esti *aŭ* projekciita al alpinglita referenco,*aŭ* forigi alpingladon kiel parton de la projekcio.
//! Se ambaŭ estas faritaj por la sama kampo, tio verŝajne estos malbona!
//!
//! Kiel aŭtoro de datuma strukturo, vi devas decidi por ĉiu kampo ĉu alpingli "propagates" al ĉi tiu kampo aŭ ne.
//! Alpingli disvastiĝantan ankaŭ nomiĝas "structural", ĉar ĝi sekvas la strukturon de la tipo.
//! En la sekvaj subsekcioj, ni priskribas la konsiderojn, kiuj devas esti faritaj por ambaŭ elektoj.
//!
//! ## Alpingli *ne estas* struktura por `field`
//!
//! Eble ŝajnas kontraŭintuicia, ke la kampo de alpinglita strukturo eble ne estas alpinglita, sed tio efektive estas la plej facila elekto: se [[Pinglo]] "<&mut Kampo>" neniam estas kreita, nenio povas fuŝiĝi!Do, se vi decidas, ke iu kampo ne havas strukturan alpingladon, vi nur devas certigi, ke vi neniam kreas alpinglitan referencon al tiu kampo.
//!
//! Kampoj sen struktura alpinglado eble havas projekcian metodon, kiu igas ['Pin'] `<&mut Struct>` en `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Ĉi tio estas en ordo, ĉar `field` neniam estas konsiderata alpinglita.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Vi povas ankaŭ `impl Unpin for Struct`*eĉ se* la tipo de `field` ne estas [`Unpin`].Kion tiu tipo pensas pri alpinglado, tio ne gravas kiam neniu [`Pin ']` <&mut Field> `iam estas kreita.
//!
//! ## Alpingli *estas* struktura por `field`
//!
//! La alia eblo estas decidi, ke alpingli estas "structural" por `field`, kio signifas, ke se la strukturo estas alpinglita, do la kampo ankaŭ estas.
//!
//! Ĉi tio permesas skribi projekcion, kiu kreas [`Pin ']` <&mut Field> `, tiel atestante, ke la kampo estas alpinglita:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Ĉi tio estas en ordo, ĉar `field` estas alpinglita kiam `self` estas.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Tamen struktura alpinglado venas kun kelkaj kromaj postuloj:
//!
//! 1. La strukturo devas esti nur [`Unpin`] se ĉiuj strukturaj kampoj estas [`Unpin`].Ĉi tio estas la apriora, sed [`Unpin`] estas sekura trait, do kiel aŭtoro de la strukturo estas via respondeco *ne* aldoni ion kiel `impl<T> Unpin for Struct<T>`.
//! (Rimarku, ke aldono de projekcia operacio postulas nesekuran kodon, do la fakto, ke [`Unpin`] estas sekura trait, ne rompas la principon, ke vi nur devas zorgi pri iu ajn el ĉi tio, se vi uzas "nesekura".)
//! 2. La detruanto de la strukt ne rajtas movi strukturajn kampojn el sia argumento.Ĉi tiu estas la ĝusta punkto, kiu aperis en la [previous section][drop-impl]: `drop` prenas `&mut self`, sed la strukturo (kaj do ĝiaj kampoj) eble estis alpinglita antaŭe.
//!     Vi devas garantii, ke vi ne movas kampon ene de via [`Drop`]-efektivigo.
//!     Aparte, kiel antaŭe klarigite, ĉi tio signifas, ke via strukturo devas *ne* esti `#[repr(packed)]`.
//!     Vidu tiun sekcion pri kiel verki [`drop`] tiel, ke la kompililo povas helpi vin ne hazarde rompi alpingladon.
//! 3. Vi devas certigi, ke vi subtenas la [`Drop` guarantee][drop-guarantee]:
//!     post kiam via strukturo estas alpinglita, la memoro kiu enhavas la enhavon ne estas anstataŭigita aŭ transdokumentita sen voki la detruilojn de la enhavo.
//!     Ĉi tio povas esti malfacila, kiel atestas [`VecDeque<T>`]: la detruanto de [`VecDeque<T>`] povas malsukcesi voki [`drop`] sur ĉiuj elementoj se unu el la detruantoj panics.Ĉi tio malobservas la [`Drop`]-garantion, ĉar ĝi povas konduki al dislokigo de elementoj sen nomado de ilia detruanto.([`VecDeque<T>`] havas neniujn alpinglajn projekciojn, do ĉi tio ne kaŭzas malfortikecon.)
//! 4. Vi devas ne oferti aliajn operaciojn, kiuj povus kaŭzi movadon de datumoj el la strukturaj kampoj, kiam via tipo estas alpinglita.Ekzemple, se la strukturo enhavas [`Option<T>`] kaj estas "preni"-simila operacio kun tipo `fn(Pin<&mut Struct<T>>) -> Option<T>`, tiu operacio povas esti uzata por movi `T` el alpinglita `Struct<T>`-kio signifas ke alpingli ne povas esti struktura por la kampo tenanta ĉi tion datumoj.
//!
//!     Por pli kompleksa ekzemplo de movado de datumoj el alpinglita tipo, imagu ĉu [`RefCell<T>`] havis metodon `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Tiam ni povus fari la jenon:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Ĉi tio estas katastrofa, ĝi signifas, ke ni unue povas fiksi la enhavon de la [`RefCell<T>`] (uzante `RefCell::get_pin_mut`) kaj poste movi tiun enhavon per la ŝanĝebla referenco, kiun ni akiris poste.
//!
//! ## Examples
//!
//! Por tipo kiel [`Vec<T>`], ambaŭ ebloj (strukturaj alpingloj aŭ ne) havas sencon.
//! [`Vec<T>`] kun struktura alpinglado povus havi `get_pin`/`get_pin_mut`-metodojn por akiri alpinglitajn referencojn al elementoj.Tamen ĝi povus *ne* permesi voki [`pop`][Vec::pop] sur alpinglita [`Vec<T>`] ĉar tio movus la (strukture alpinglitan) enhavon!Ĝi ankaŭ ne povus permesi [`push`][Vec::push], kiu povus reasigni kaj tiel ankaŭ movi la enhavon.
//!
//! [`Vec<T>`] sen struktura alpinglado povus `impl<T> Unpin for Vec<T>`, ĉar la enhavo neniam estas alpinglita kaj la [`Vec<T>`] mem bonas ankaŭ esti movita.
//! Tiutempe alpingli tute ne efikas sur la vector.
//!
//! En la norma biblioteko, montrilspecoj ĝenerale ne havas strukturan alpingladon, kaj tiel ili ne ofertas alpinglajn projekciojn.Jen kial `Box<T>: Unpin` validas por ĉiuj `T`.
//! Ĝi havas sencon fari ĉi tion por montriloj, ĉar movado de la `Box<T>` fakte ne movas la `T`: la [`Box<T>`] povas esti libere movebla (alinome `Unpin`) eĉ se la `T` ne estas.Fakte eĉ [`Pin ']` <`[` Skatolo`]`<T>> `kaj [` Pin '] `<&mut T>` ĉiam estas [`Unpin`] mem, pro la sama kialo: ilia enhavo (la `T`) estas alpinglita, sed la montriloj mem povas esti movitaj sen movi la alpinglitajn datumojn.
//! Ambaŭ por [`Box<T>`] kaj [`Pin ']` <`[` Skatolo`]`<T>> `, ĉu la enhavo estas alpinglita estas tute sendependa de ĉu la montrilo estas alpinglita, kio signifas ke alpingli estas *ne* struktura.
//!
//! Kiam vi efektivigas [`Future`]-kombinilon, vi kutime bezonos strukturan alpingladon por la nestita futures, ĉar vi devas akiri alpinglitajn referencojn al ili por nomi [`poll`].
//! Sed se via kombinilo enhavas iujn aliajn datumojn, kiuj ne bezonas esti alpinglitaj, vi povas igi tiujn kampojn ne strukturaj kaj do libere aliri ilin kun ŝanĝebla referenco eĉ kiam vi simple havas [`Pin ']` <&mut Self> `(tia kiel en via propra [`poll`]-efektivigo).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Alpinglita montrilo.
///
/// Ĉi tio estas envolvaĵo ĉirkaŭ speco de montrilo, kiu faras tiun montrilon "pin" sia valoro modloko, malebligante la valoron referencitan de tiu montrilo moviĝi, krom se ĝi efektivigas [`Unpin`].
///
///
/// *Vidu la [`pin` module]-dokumentaron por klarigo pri alpinglado.*
///
/// [`pin` module]: self
///
// Note: la `Clone`-derivaĵo sube kaŭzas malsanecon, ĉar eblas efektivigi ĝin
// `Clone` por ŝanĝeblaj referencoj.
// Vidu <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> por pli da detaloj.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// La jenaj efektivigoj ne estas derivitaj por eviti solidajn problemojn.
// `&self.pointer` ne estu alirebla por nefidaj trait-efektivigoj.
//
// Vidu <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> por pli da detaloj.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Konstruu novan `Pin<P>` ĉirkaŭ montrilo al iuj datumoj de tipo, kiu efektivigas [`Unpin`].
    ///
    /// Male al `Pin::new_unchecked`, ĉi tiu metodo estas sekura ĉar la montrilo `P` malreferencas al [`Unpin`]-tipo, kiu nuligas la alpinglajn garantiojn.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SEKURECO: la valoro indikita estas `Unpin`, kaj do havas neniujn postulojn
        // ĉirkaŭ alpinglado.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Malvolvas ĉi tiun `Pin<P>` redonante la suban montrilon.
    ///
    /// Ĉi tio postulas, ke la datumoj ene de ĉi tiu `Pin` estas [`Unpin`], por ke ni povu ignori la alpinglajn invariantojn kiam ni malvolvas ĝin.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Konstruu novan `Pin<P>` ĉirkaŭ referenco al iuj datumoj de tipo, kiu eble efektivigos `Unpin` aŭ ne.
    ///
    /// Se `pointer` malreferencas al `Unpin`-tipo, `Pin::new` estu uzata anstataŭe.
    ///
    /// # Safety
    ///
    /// Ĉi tiu konstruilo estas nesekura ĉar ni ne povas garantii, ke la datumoj indikitaj de `pointer` estas alpinglitaj, kio signifas, ke la datumoj ne estos movitaj aŭ ĝia stokado nuligita ĝis kiam ili falos.
    /// Se la konstruita `Pin<P>` ne garantias, ke la datumoj, kiujn `P` montras, estas alpinglitaj, tio estas malobservo de la API-kontrakto kaj povas konduki al nedifinita konduto en postaj (safe)-operacioj.
    ///
    /// Uzante ĉi tiun metodon, vi faras promise pri la `P::Deref` kaj `P::DerefMut`-efektivigoj, se ili ekzistas.
    /// Plej grave, ili ne devas eliri el siaj argumentoj `self`: `Pin::as_mut` kaj `Pin::as_ref` vokos `DerefMut::deref_mut` kaj `Deref::deref`*sur la alpinglita montrilo* kaj atendas, ke ĉi tiuj metodoj subtenos la alpinglajn invariantojn.
    /// Cetere, vokante ĉi tiun metodon, vi promesas, ke la referenco al `P`-malplenumoj ne estos elpelita;precipe ne devas esti eble akiri `&mut P::Target` kaj poste eliri el tiu referenco (uzante, ekzemple [`mem::swap`]).
    ///
    ///
    /// Ekzemple, voki `Pin::new_unchecked` sur `&'a mut T` estas nesekura ĉar dum vi povas alpingli ĝin dum la donita vivdaŭro `'a`, vi havas nenian kontrolon pri tio, ĉu ĝi estas tenata alpinglita post kiam `'a` finiĝas:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Ĉi tio devas signifi, ke la punkto `a` neniam plu povas moviĝi.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // La adreso de `a` ŝanĝiĝis al staka fendo de "b", do `a` moviĝis kvankam ni antaŭe alpinglis ĝin!Ni malobservis la alpinglan API-kontrakton.
    /////
    /// }
    /// ```
    ///
    /// Valoro, post kiam alpinglita, devas resti alpinglita por ĉiam (krom se ĝia tipo efektivigas `Unpin`).
    ///
    /// Simile voki `Pin::new_unchecked` per `Rc<T>` estas nesekura ĉar povus esti kaŝnomoj al la samaj datumoj ne submetitaj al la alpinglaj limigoj:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Ĉi tio devas signifi, ke la poentulo neniam plu povas moviĝi.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Nun, se `x` estis la sola referenco, ni havas ŝanĝeblan referencon al datumoj, kiujn ni alpinglis supre, kiujn ni povus uzi por movi ĝin kiel ni vidis en la antaŭa ekzemplo.
    ///     // Ni malobservis la alpinglan API-kontrakton.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Akiras alpinglitan komunan referencon de ĉi tiu alpinglita montrilo.
    ///
    /// Ĉi tio estas ĝenerala metodo por iri de `&Pin<Pointer<T>>` al `Pin<&T>`.
    /// Ĝi estas sekura ĉar, kiel parto de la kontrakto de `Pin::new_unchecked`, la poento ne povas moviĝi post kiam `Pin<Pointer<T>>` kreiĝis.
    ///
    /// "Malicious" efektivigoj de `Pointer::Deref` estas same ekskluditaj de la kontrakto de `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SEKURECO: vidu dokumentadon pri ĉi tiu funkcio
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Malvolvas ĉi tiun `Pin<P>` redonante la suban montrilon.
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio estas nesekura.Vi devas garantii, ke vi daŭre traktos la montrilon `P` kiel alpinglitan post kiam vi nomos ĉi tiun funkcion, por ke la invariantoj de la tipo `Pin` estu konfirmitaj.
    /// Se la kodo uzanta la rezultan `P` ne plu konservas la alpinglajn invariantojn, tio estas malobservo de la API-kontrakto kaj povas konduki al nedifinita konduto en postaj (safe)-operacioj.
    ///
    ///
    /// Se la subaj datumoj estas [`Unpin`], anstataŭe oni uzu [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Akiras alpinglitan ŝanĝeblan referencon de ĉi tiu alpinglita montrilo.
    ///
    /// Ĉi tio estas ĝenerala metodo por iri de `&mut Pin<Pointer<T>>` al `Pin<&mut T>`.
    /// Ĝi estas sekura ĉar, kiel parto de la kontrakto de `Pin::new_unchecked`, la poento ne povas moviĝi post kiam `Pin<Pointer<T>>` kreiĝis.
    ///
    /// "Malicious" efektivigoj de `Pointer::DerefMut` estas same ekskluditaj de la kontrakto de `Pin::new_unchecked`.
    ///
    /// Ĉi tiu metodo estas utila dum multaj vokoj al funkcioj, kiuj konsumas la alpinglitan tipon.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // fari ion
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` konsumas `self`, do reprenu la `Pin<&mut Self>` per `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SEKURECO: vidu dokumentadon pri ĉi tiu funkcio
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Atribuas novan valoron al la memoro malantaŭ la alpinglita referenco.
    ///
    /// Ĉi tio anstataŭigas alpinglitajn datumojn, sed tio estas en ordo: ĝia detruilo funkcias antaŭ ol esti anstataŭigita, do neniu alpingla garantio malobservas.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Konstruas novan pinglon per mapado de la interna valoro.
    ///
    /// Ekzemple, se vi volus akiri `Pin` de kampo de io, vi povus uzi ĉi tion por aliri al tiu kampo en unu linio de kodo.
    /// Tamen estas pluraj gotchaj kun ĉi tiuj "pinning projections";
    /// vidu la dokumentaron [`pin` module] por pliaj detaloj pri tiu temo.
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio estas nesekura.
    /// Vi devas garantii, ke la datumoj, kiujn vi redonas, ne moviĝos tiel longe, kiel la argumenta valoro ne moviĝos (ekzemple, ĉar ĝi estas unu el la kampoj de tiu valoro), kaj ankaŭ ke vi ne moviĝas el la argumento, kiun vi ricevas al la interna funkcio.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SEKURECO: la sekureca kontrakto por `new_unchecked` devas esti
        // konfirmita de la alvokanto.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Akiras komunan referencon el pinglo.
    ///
    /// Ĉi tio estas sekura, ĉar ne eblas eliri el komuna referenco.
    /// Eble ŝajnas, ke ĉi tie temas pri interna ŝanĝebleco: fakte *eblas* movi `T` el `&RefCell<T>`.
    /// Tamen tio ne estas problemo kondiĉe ke ne ekzistas ankaŭ `Pin<&T>` montranta la samajn datumojn, kaj `RefCell<T>` ne permesas krei alpinglitan referencon al ĝia enhavo.
    ///
    /// Vidu la diskuton pri ["pinning projections"] por pliaj detaloj.
    ///
    /// Note: `Pin` ankaŭ efektivigas `Deref` al la celo, kiu povas esti uzata por aliri la internan valoron.
    /// Tamen, `Deref` nur provizas referencon, kiu vivas tiel longe kiel la pruntepreno de la `Pin`, ne la vivdaŭro de la `Pin` mem.
    /// Ĉi tiu metodo permesas transformi la `Pin` en referencon kun la sama vivo kiel la originala `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Konvertas ĉi tiun `Pin<&mut T>` en `Pin<&T>` kun la sama vivdaŭro.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Akiras ŝanĝeblan referencon al la datumoj ene de ĉi tiu `Pin`.
    ///
    /// Ĉi tio postulas, ke la datumoj ene de ĉi tiu `Pin` estas `Unpin`.
    ///
    /// Note: `Pin` ankaŭ efektivigas `DerefMut` al la datumoj, kiuj povas esti uzataj por aliri la internan valoron.
    /// Tamen, `DerefMut` nur provizas referencon, kiu vivas tiel longe kiel la pruntepreno de la `Pin`, ne la vivdaŭro de la `Pin` mem.
    ///
    /// Ĉi tiu metodo permesas transformi la `Pin` en referencon kun la sama vivo kiel la originala `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Akiras ŝanĝeblan referencon al la datumoj ene de ĉi tiu `Pin`.
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio estas nesekura.
    /// Vi devas garantii, ke vi neniam movos la datumojn el la ŝanĝebla referenco, kiun vi ricevas, kiam vi vokas ĉi tiun funkcion, por ke la invariantoj de la `Pin`-tipo estu konfirmitaj.
    ///
    ///
    /// Se la subaj datumoj estas `Unpin`, anstataŭe oni uzu `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Konstruu novan pinglon per mapado de la interna valoro.
    ///
    /// Ekzemple, se vi volus akiri `Pin` de kampo de io, vi povus uzi ĉi tion por aliri al tiu kampo en unu linio de kodo.
    /// Tamen estas pluraj gotchaj kun ĉi tiuj "pinning projections";
    /// vidu la dokumentaron [`pin` module] por pliaj detaloj pri tiu temo.
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio estas nesekura.
    /// Vi devas garantii, ke la datumoj, kiujn vi redonas, ne moviĝos tiel longe, kiel la argumenta valoro ne moviĝos (ekzemple, ĉar ĝi estas unu el la kampoj de tiu valoro), kaj ankaŭ ke vi ne moviĝas el la argumento, kiun vi ricevas al la interna funkcio.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SEKURECO: la alvokanto respondecas pri ne movado de la
        // valoro el ĉi tiu referenco.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SEKURECO: ĉar la valoro de `this` estas garantiita ne havi
        // transloĝiĝis, ĉi tiu alvoko al `new_unchecked` estas sekura.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Akiru alpinglitan referencon de statika referenco.
    ///
    /// Ĉi tio estas sekura, ĉar `T` estas pruntita por la `'static`-vivo, kiu neniam finiĝas.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SEKURECO: La 'statika prunto garantias, ke la datumoj ne estos
        // moved/invalidated ĝis ĝi falos (kio neniam estas).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Akiru alpinglitan ŝanĝeblan referencon de statika ŝanĝebla referenco.
    ///
    /// Ĉi tio estas sekura, ĉar `T` estas pruntita por la `'static`-vivo, kiu neniam finiĝas.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SEKURECO: La 'statika prunto garantias, ke la datumoj ne estos
        // moved/invalidated ĝis ĝi falos (kio neniam estas).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: ĉi tio signifas, ke iu ajn impl de `CoerceUnsized`, kiu permesas devigon de
// tipo, kiu implicas `Deref<Target=impl !Unpin>` al tipo, kiu implicas `Deref<Target=Unpin>`, estas malbona.
// Iu ajn tia programo probable estus malbona pro aliaj kialoj, do ni nur bezonas zorgi, ke ili ne surteriĝu en std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}