//! Difinas la `IntoIter` posedatan ripetilon por tabeloj.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Kromvalora [array]-ripetilo.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Jen la tabelo, kiun ni ripetas.
    ///
    /// Elementoj kun indekso `i` kie `alive.start <= i < alive.end` ankoraŭ ne donis kaj estas validaj tabelaj eniroj.
    /// Elementoj kun indicoj `i < alive.start` aŭ `i >= alive.end` jam estis donitaj kaj ne plu alireblas!Tiuj mortaj elementoj povus eĉ esti en tute seniniciata stato!
    ///
    ///
    /// Do la invariantoj estas:
    /// - `data[alive]` vivas (te enhavas validajn elementojn)
    /// - `data[..alive.start]` kaj `data[alive.end..]` mortis (te la elementoj jam estis legitaj kaj ne plu tuŝeblas!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// La elementoj en `data` ankoraŭ ne donitaj.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Kreas novan ripetilon super la donita `array`.
    ///
    /// *Noto*: ĉi tiu metodo povus esti malrekomendata en la future, post [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // La speco de `value` estas ĉi tie `i32`, anstataŭ `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SEKURECO: La transmuto ĉi tie efektive estas sekura.La dokumentoj de `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` estas garantiita havi la saman grandecon kaj vicon
        // > kiel `T`.
        //
        // La dokumentoj eĉ montras transmuton de tabelo de `MaybeUninit<T>` al tabelo de `T`.
        //
        //
        // Per tio, ĉi tiu inicialigo kontentigas la invariantojn.

        // FIXME(LukasKalbertodt): efektive uzu `mem::transmute` ĉi tie, post kiam ĝi funkcias kun konst generikoj:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Ĝis tiam ni povas uzi `mem::transmute_copy` por krei laŭbitan kopion kiel alian tipon, tiam forgesi `array` por ke ĝi ne estu faligita.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Liveras neŝanĝeblan tranĉaĵon de ĉiuj elementoj, kiuj ankoraŭ ne estis donitaj.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SEKURECO: Ni scias, ke ĉiuj elementoj ene de `alive` estas ĝuste pravalorizitaj.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Liveras ŝanĝeblan tranĉaĵon de ĉiuj elementoj, kiuj ankoraŭ ne estis donitaj.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SEKURECO: Ni scias, ke ĉiuj elementoj ene de `alive` estas ĝuste pravalorizitaj.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Akiru la sekvan indekson de antaŭe.
        //
        // Pliigi `alive.start` per 1 konservas la senvarian rilaton al `alive`.
        // Tamen, pro ĉi tiu ŝanĝo, dum mallonga tempo, la viva zono ne plu estas `data[alive]`, sed `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Legu la elementon el la tabelo.
            // SEKURECO: `idx` estas indekso en la antaŭan "alive"-regionon de la
            // tabelo.Legi ĉi tiun elementon signifas, ke `data[idx]` estas rigardata kiel mortinta nun (te ne tuŝu).
            // Ĉar `idx` estis la komenco de la viva zono, la viva zono nun estas `data[alive]` denove, restarigante ĉiujn invariantojn.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Akiru la sekvan indekson de la malantaŭo.
        //
        // Malpliigi `alive.end` per 1 konservas la senvarian rilaton al `alive`.
        // Tamen, pro ĉi tiu ŝanĝo, dum mallonga tempo, la viva zono ne plu estas `data[alive]`, sed `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Legu la elementon el la tabelo.
            // SEKURECO: `idx` estas indekso en la antaŭan "alive"-regionon de la
            // tabelo.Legi ĉi tiun elementon signifas, ke `data[idx]` estas rigardata kiel mortinta nun (te ne tuŝu).
            // Ĉar `idx` estis la fino de la viva zono, la viva zono nun estas `data[alive]` denove, restarigante ĉiujn invariantojn.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SEKURECO: Ĉi tio estas sekura: `as_mut_slice` redonas ĝuste la subtranĉaĵon
        // de elementoj, kiuj ankoraŭ ne estis elŝovitaj kaj kiuj restas forĵetotaj.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Neniam subfluos pro la senvaria `vivo.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// La ripetanto ja raportas la ĝustan longon.
// La nombro de "alive"-elementoj (kiuj ankoraŭ estos donitaj) estas la longo de la gamo `alive`.
// Ĉi tiu gamo estas malpliigita laŭ longo en aŭ `next` aŭ `next_back`.
// Ĝi estas ĉiam malpliigita per 1 en tiuj metodoj, sed nur se `Some(_)` estas redonita.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Notu, ni ne vere bezonas egali la saman vivan intervalon, do ni povas simple kloni en ofseto 0 sendepende de kie estas `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klonu ĉiujn vivajn elementojn.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Skribu klonon en la novan tabelon, tiam ĝisdatigu ĝian vivan gamon.
            // Se klonado de panics, ni ĝuste faligos la antaŭajn erojn.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Presu nur la elementojn ankoraŭ ne ceditajn: ni ne povas aliri la donitajn elementojn plu.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}