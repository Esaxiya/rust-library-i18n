//! Senpagaj funkcioj por krei `&[T]` kaj `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Formas tranĉaĵon el montrilo kaj longo.
///
/// La argumento `len` estas la nombro de **elementoj**, ne la nombro de bajtoj.
///
/// # Safety
///
/// Konduto estas nedifinita se iuj el la sekvaj kondiĉoj estas malobservitaj:
///
/// * `data` devas esti [valid] por legoj por `len * mem::size_of::<T>()` multaj bajtoj, kaj ĝi devas esti ĝuste vicigita.Ĉi tio signifas precipe:
///
///     * La tuta memora teritorio de ĉi tiu tranĉaĵo devas esti enhavita ene de unu asignita objekto!
///       Tranĉaĵoj neniam povas ampleksi multoblajn asignitajn objektojn.Vidu [below](#incorrect-usage) por ekzemplo malĝuste ne konsiderante ĉi tion.
///     * `data` devas esti nenula kaj vicigita eĉ por nul-longaj tranĉaĵoj.
///     Unu kialo por tio estas, ke enum-aranĝaj optimumigoj povas dependi de referencoj (inkluzive de tranĉaĵoj de iu ajn longo) vicigataj kaj nulaj por distingi ilin de aliaj datumoj.
///     Vi povas akiri montrilon uzeblan kiel `data` por nul-longaj tranĉaĵoj per [`NonNull::dangling()`].
///
/// * `data` devas montri al `len` sinsekve konvene komencigitaj valoroj de tipo `T`.
///
/// * La memoro referencita de la redonita tranĉaĵo ne rajtas esti mutaciita dum la daŭro de la tuta vivo `'a`, krom ene de `UnsafeCell`.
///
/// * La totala grandeco `len * mem::size_of::<T>()` de la tranĉaĵo devas esti ne pli granda ol `isize::MAX`.
///   Vidu la sekurecan dokumentaron de [`pointer::offset`].
///
/// # Caveat
///
/// La vivdaŭro por la revenita tranĉaĵo estas konkludita el ĝia uzado.
/// Por preventi neintencitan misuzon, oni sugestas ligi la vivdaŭron al iu ajn fonta vivdaŭro sekura en la kunteksto, ekzemple provizante helpan funkcion prenantan la vivdaŭron de gastiganta valoro por la tranĉaĵo, aŭ per eksplicita komentado
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifesti tranĉaĵon por unu elemento
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Malĝusta uzado
///
/// La sekva `join_slices`-funkcio estas **maltaŭga** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // La supera aserto certigas, ke `fst` kaj `snd` estas apudaj, sed ili povus ankoraŭ esti enhavitaj ene de _different allocated objects_, en kies kazo krei ĉi tiun tranĉaĵon estas nedifinita konduto.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` kaj `b` estas malsamaj asignitaj objektoj ...
///     let a = 42;
///     let b = 27;
///     // ... kiu tamen povas esti aranĝita apude en memoro: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Elfaras la saman funkciecon kiel [`from_raw_parts`], krom ke ŝanĝebla tranĉaĵo estas redonita.
///
/// # Safety
///
/// Konduto estas nedifinita se iuj el la sekvaj kondiĉoj estas malobservitaj:
///
/// * `data` devas esti [valid] por ambaŭ legaĵoj kaj skriboj por `len * mem::size_of::<T>()` multaj bajtoj, kaj ĝi devas esti ĝuste vicigita.Ĉi tio signifas precipe:
///
///     * La tuta memora teritorio de ĉi tiu tranĉaĵo devas esti enhavita ene de unu asignita objekto!
///       Tranĉaĵoj neniam povas ampleksi multoblajn asignitajn objektojn.
///     * `data` devas esti nenula kaj vicigita eĉ por nul-longaj tranĉaĵoj.
///     Unu kialo por tio estas, ke enum-aranĝaj optimumigoj povas dependi de referencoj (inkluzive de tranĉaĵoj de iu ajn longo) vicigataj kaj nulaj por distingi ilin de aliaj datumoj.
///
///     Vi povas akiri montrilon uzeblan kiel `data` por nul-longaj tranĉaĵoj per [`NonNull::dangling()`].
///
/// * `data` devas montri al `len` sinsekve konvene komencigitaj valoroj de tipo `T`.
///
/// * La memoro referencita de la revenita tranĉaĵo ne rajtas esti alirita per iu ajn alia montrilo (ne derivita de la revenita valoro) dum la daŭro de la tuta vivo `'a`.
///   Ambaŭ legaj kaj skribaj aliroj estas malpermesitaj.
///
/// * La totala grandeco `len * mem::size_of::<T>()` de la tranĉaĵo devas esti ne pli granda ol `isize::MAX`.
///   Vidu la sekurecan dokumentaron de [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Konvertas referencon al T en tranĉaĵo 1 (sen kopii).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Konvertas referencon al T en tranĉaĵo 1 (sen kopii).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}