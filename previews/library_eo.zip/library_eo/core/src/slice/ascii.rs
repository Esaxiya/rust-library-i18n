//! Operacioj pri ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Kontrolas ĉu ĉiuj bajtoj en ĉi tiu tranĉaĵo estas ene de la ASCII-intervalo.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Kontrolas, ke du tranĉaĵoj estas ASCII-usklecema matĉo.
    ///
    /// Sama kiel `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, sed sen asignado kaj kopiado de provizoraj tempoj.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Konvertas ĉi tiun tranĉaĵon al sia ASCII-majuskla ekvivalento modloko.
    ///
    /// Askiaj literoj 'a' al 'z' estas mapitaj al 'A' al 'Z', sed ne-ASCII-literoj estas senŝanĝaj.
    ///
    /// Por redoni novan majusklan valoron sen modifi la ekzistantan, uzu [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Konvertas ĉi tiun tranĉaĵon al sia ASCII minuskla ekvivalento surloke.
    ///
    /// Askiaj literoj 'A' al 'Z' estas mapitaj al 'a' al 'z', sed ne-ASCII-literoj estas senŝanĝaj.
    ///
    /// Por redoni novan minusklan valoron sen modifi la ekzistantan, uzu [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Liveras `true` se iu bajto en la vorto `v` estas nonascii (>=128).
/// Snarfed de `../str/mod.rs`, kiu faras ion similan por utf8-validado.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimumigita ASCII-testo, kiu uzos uzokutimajn operaciojn anstataŭ bitokajn operaciojn (kiam eble).
///
/// La algoritmo, kiun ni uzas ĉi tie, estas sufiĉe simpla.Se `s` estas tro mallonga, ni nur kontrolas ĉiun bajton kaj finos ĝin.Alie:
///
/// - Legu la unuan vorton kun senalinea ŝarĝo.
/// - Vicigu la montrilon, legu postajn vortojn ĝis fino kun vicigitaj ŝarĝoj.
/// - Legu la lastan `usize` de `s` kun senalinea ŝarĝo.
///
/// Se iu el ĉi tiuj ŝarĝoj produktas ion, por kio `contains_nonascii` (above) revenas vera, tiam ni scias, ke la respondo estas malvera.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Se ni gajnus ion ajn per la samtempa efektivigo, reiru al skalara buklo.
    //
    // Ni ankaŭ faras ĉi tion por arkitekturoj, kie `size_of::<usize>()` ne sufiĉas por `usize`, ĉar ĝi estas stranga kazo edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Ni ĉiam legas la unuan vorton senaliniigita, kio signifas, ke `align_offset` estas
    // 0, ni denove legus la saman valoron por la vicigita legado.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SEKURECO: Ni kontrolas `len < USIZE_SIZE` supre.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Ni kontrolis ĉi tion supre, iom implicite.
    // Notu, ke `offset_to_aligned` estas aŭ `align_offset` aŭ `USIZE_SIZE`, ambaŭ estas eksplicite kontrolitaj supre.
    //
    debug_assert!(offset_to_aligned <= len);

    // SEKURECO: word_ptr estas la uzata ptr (taŭge vicigita), kiun ni uzas por legi la
    // meza bloko de la tranĉaĵo.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` estas la bajta indekso de `word_ptr`, uzata por buklokontroloj.
    let mut byte_pos = offset_to_aligned;

    // Paranoia kontrolo pri vicigo, ĉar ni faros amason da senaliniigitaj ŝarĝoj.
    // Praktike ĉi tio tamen maleblus krom cimo en `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Legu postajn vortojn ĝis la lasta vicigita vorto, ekskludante la lastan vicigitan vorton farenda en vostkontrolo poste, por certigi, ke vosto ĉiam estas unu `usize` maksimume al ekstra branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Saneco kontrolu, ke la legado estas limigita
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Kaj ke niaj supozoj pri `byte_pos` validas.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SEKURECO: Ni scias, ke `word_ptr` estas ĝuste vicigita (pro
        // "align_offset"), kaj ni scias, ke ni havas sufiĉe da bajtoj inter `word_ptr` kaj la fino
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SEKURECO: Ni scias tiun `byte_pos <= len - USIZE_SIZE`, kio signifas tion
        // post ĉi tiu `add`, `word_ptr` estos maksimume unu-preter-la-fina.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Saneca kontrolo por certigi, ke vere restas nur unu `usize`.
    // Ĉi tio estu garantiita de nia bukla kondiĉo.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SEKURECO: Ĉi tio dependas de `len >= USIZE_SIZE`, kiun ni kontrolas ĉe la komenco.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}