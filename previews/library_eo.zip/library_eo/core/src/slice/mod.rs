// ignore-tidy-filelength

//! Tranĉaĵo-administrado kaj manipulado.
//!
//! Por pli da detaloj vidu [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Pura efektivigo de rust memchr, prenita de rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Ĉi tiu funkcio estas publika nur ĉar ne ekzistas alia maniero por testi pezan amason.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Liveras la nombron de elementoj en la tranĉaĵo.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SEKURECO: konstanta sono ĉar ni transmutacias la longokampon kiel uzuzo (kiu ĝi devas esti)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SEKURECO: ĉi tio estas sekura ĉar `&[T]` kaj `FatPtr<T>` havas la saman aranĝon.
            // Nur `std` povas doni ĉi tiun garantion.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Anstataŭigu per `crate::ptr::metadata(self)` kiam tio estas stabila.
            // Ekde ĉi tiu skribado ĉi tio kaŭzas "Const-stable functions can only call other const-stable functions"-eraron.
            //

            // SEKURECO: Aliri la valoron de la `PtrRepr`-unio estas sekura ĉar * const T
            // kaj PtrComponents<T>havas la samajn memorajn aranĝojn.
            // Nur std povas doni ĉi tiun garantion.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Liveras `true` se la tranĉaĵo havas longon de 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Liveras la unuan elementon de la tranĉaĵo, aŭ `None` se ĝi estas malplena.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Redonas ŝanĝeblan montrilon al la unua elemento de la tranĉaĵo, aŭ `None` se ĝi estas malplena.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Liveras la unuan kaj ĉiujn ceterajn elementojn de la tranĉaĵo, aŭ `None` se ĝi estas malplena.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Liveras la unuan kaj ĉiujn ceterajn elementojn de la tranĉaĵo, aŭ `None` se ĝi estas malplena.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Liveras la lastan kaj ĉiujn ceterajn elementojn de la tranĉaĵo, aŭ `None` se ĝi estas malplena.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Liveras la lastan kaj ĉiujn ceterajn elementojn de la tranĉaĵo, aŭ `None` se ĝi estas malplena.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Liveras la lastan elementon de la tranĉaĵo, aŭ `None` se ĝi estas malplena.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Redonas ŝanĝeblan montrilon al la lasta ero en la tranĉaĵo.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Liveras referencon al elemento aŭ subtranĉaĵo depende de la speco de indekso.
    ///
    /// - Se donita pozicio, redonas referencon al la elemento ĉe tiu pozicio aŭ `None` se ekster limoj.
    ///
    /// - Se donita intervalo, redonas la subtranĉon respondan al tiu intervalo, aŭ `None` se ekster limoj.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Liveras ŝanĝeblan referencon al elemento aŭ subtranĉaĵo depende de la speco de indekso (vidu [`get`]) aŭ `None` se la indekso estas ekster limoj.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Liveras referencon al elemento aŭ subtranĉaĵo, sen fari kontrolon de limoj.
    ///
    /// Por sekura alternativo vidu [`get`].
    ///
    /// # Safety
    ///
    /// Voki ĉi tiun metodon kun ekster-lima indekso estas *[nedifinita konduto]* eĉ se la rezulta referenco ne estas uzata.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SEKURECO: la alvokanto devas plenumi plej multajn sekurecajn postulojn por `get_unchecked`;
        // la tranĉaĵo estas nerefektebla ĉar `self` estas sekura referenco.
        // La revenita montrilo estas sekura, ĉar la iloj de `SliceIndex` devas garantii, ke ĝi estas.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Liveras ŝanĝeblan referencon al elemento aŭ subtranĉaĵo, sen fari limon.
    ///
    /// Por sekura alternativo vidu [`get_mut`].
    ///
    /// # Safety
    ///
    /// Voki ĉi tiun metodon kun ekster-lima indekso estas *[nedifinita konduto]* eĉ se la rezulta referenco ne estas uzata.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SEKURECO: la alvokanto devas plenumi la sekurecajn postulojn por `get_unchecked_mut`;
        // la tranĉaĵo estas nerefektebla ĉar `self` estas sekura referenco.
        // La revenita montrilo estas sekura, ĉar la iloj de `SliceIndex` devas garantii, ke ĝi estas.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Redonas krudan montrilon al la bufro de la tranĉaĵo.
    ///
    /// La alvokanto devas certigi, ke la tranĉaĵo superas la montrilon, kiun ĉi tiu funkcio redonas, alie ĝi finos montrante rubon.
    ///
    /// La alvokanto devas ankaŭ certigi, ke la memoro al kiu montras la montrilo (non-transitively) neniam estas skribita (krom ene de `UnsafeCell`) per ĉi tiu montrilo aŭ iu ajn montrilo derivita de ĝi.
    /// Se vi bezonas mutigi la enhavon de la tranĉaĵo, uzu [`as_mut_ptr`].
    ///
    /// Modifi la ujon aluditan per ĉi tiu tranĉaĵo povas kaŭzi reaklokigon de sia bufro, kio ankaŭ malvalidigus iujn indikojn al ĝi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Liveras nesekuran ŝanĝeblan montrilon al la bufro de la tranĉaĵo.
    ///
    /// La alvokanto devas certigi, ke la tranĉaĵo superas la montrilon, kiun ĉi tiu funkcio redonas, alie ĝi finos montrante rubon.
    ///
    /// Modifi la ujon aluditan per ĉi tiu tranĉaĵo povas kaŭzi reaklokigon de sia bufro, kio ankaŭ malvalidigus iujn indikojn al ĝi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Liveras la du krudajn montrilojn tra la tranĉaĵo.
    ///
    /// La revenita intervalo estas duone malfermita, kio signifas, ke la fina montrilo montras *unu preter* la lastan elementon de la tranĉaĵo.
    /// Tiel, malplena tranĉaĵo estas reprezentita per du egalaj montriloj, kaj la diferenco inter la du montriloj reprezentas la grandecon de la tranĉaĵo.
    ///
    /// Vidu [`as_ptr`] por avertoj pri uzado de ĉi tiuj montriloj.La fina montrilo bezonas ekstran singardemon, ĉar ĝi ne montras validan elementon en la tranĉaĵo.
    ///
    /// Ĉi tiu funkcio estas utila por interagi kun fremdaj interfacoj, kiuj uzas du montrilojn por raporti al vico da elementoj en memoro, kiel oftas en C++ .
    ///
    ///
    /// Povas ankaŭ esti utile kontroli ĉu montrilo al elemento rilatas al elemento de ĉi tiu tranĉaĵo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SEKURECO: La `add` ĉi tie estas sekura, ĉar:
        //
        //   - Ambaŭ montriloj estas parto de la sama objekto, ĉar ankaŭ indiki rekte preter la objekto.
        //
        //   - La grandeco de la tranĉaĵo neniam estas pli granda ol isize::MAX-bitokoj, kiel notite ĉi tie:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Estas neniu envolvaĵo implikita, ĉar tranĉaĵoj ne envolvas preter la fino de la adresspaco.
        //
        // Vidu la dokumentadon de pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Liveras la du nesekurajn ŝanĝeblajn montrilojn tra la tranĉaĵo.
    ///
    /// La revenita intervalo estas duone malfermita, kio signifas, ke la fina montrilo montras *unu preter* la lastan elementon de la tranĉaĵo.
    /// Tiel, malplena tranĉaĵo estas reprezentita per du egalaj montriloj, kaj la diferenco inter la du montriloj reprezentas la grandecon de la tranĉaĵo.
    ///
    /// Vidu [`as_mut_ptr`] por avertoj pri uzado de ĉi tiuj montriloj.
    /// La fina montrilo bezonas ekstran singardemon, ĉar ĝi ne montras validan elementon en la tranĉaĵo.
    ///
    /// Ĉi tiu funkcio estas utila por interagi kun fremdaj interfacoj, kiuj uzas du montrilojn por raporti al vico da elementoj en memoro, kiel oftas en C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SEKURECO: Vidu supre as_ptr_range() por kial `add` ĉi tie estas sekura.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Interŝanĝas du elementojn en la tranĉaĵo.
    ///
    /// # Arguments
    ///
    /// * a, La indekso de la unua elemento
    /// * b, La indekso de la dua elemento
    ///
    /// # Panics
    ///
    /// Panics se `a` aŭ `b` estas ekster limoj.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Ne povas preni du ŝanĝeblajn pruntojn de unu vector, do anstataŭe uzu krudajn montrilojn.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SEKURECO: `pa` kaj `pb` estis kreitaj de sekuraj ŝanĝeblaj referencoj kaj referenco
        // al elementoj en la tranĉaĵo kaj tial estas garantiitaj esti validaj kaj vicigitaj.
        // Notu, ke aliri la elementojn malantaŭ `a` kaj `b` estas kontrolita kaj faros panic kiam ekster limoj.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Inversigas la ordon de elementoj en la tranĉaĵo, en loko.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Por tre malgrandaj tipoj, ĉiuj individuaj legoj en la normala vojo efikas malbone.
        // Ni povas fari pli bone, donante efikan senalian load/store, ŝarĝante pli grandan blokon kaj renversante registron.
        //

        // Ideale LLVM farus ĉi tion por ni, ĉar ĝi scias pli bone ol ni, ĉu nealinearaj legaĵoj efikas (ĉar tio ŝanĝiĝas inter malsamaj versioj de ARM, ekzemple) kaj kia estus la plej bona ero.
        // Bedaŭrinde, ekde LLVM 4.0 (2017-05) ĝi nur malvolvas la buklon, do ni devas fari tion mem.
        // (Hipotezo: inversigo ĝenas ĉar la flankoj povas esti vicigitaj malsame-estos, kiam la longo estas nepara-do ne eblas elsendi antaŭ-kaj postludojn uzi tute vicigitan SIMD meze.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Uzu la internan llvm.bswap por inversigi u8-ojn en uzokutimo
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SEKURECO: Estas kelkaj aferoj kontroleblaj ĉi tie:
                //
                // - Notu, ke `chunk` estas aŭ 4 aŭ 8 pro la cfg-kontrolo supre.Do `chunk - 1` estas pozitiva.
                // - Indeksado kun indekso `i` estas bona kiel la bukla kontrolo garantias
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indeksi kun indekso `ln - i - chunk = ln - (i + chunk)` estas bone:
                //   - `i + chunk > 0` estas banale vera.
                //   - La bukla kontrolo garantias:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, tiel subtraho ne subfluas.
                // - La vokoj `read_unaligned` kaj `write_unaligned` bonas:
                //   - `pa` montras al indekso `i` kie `i < ln / 2 - (chunk - 1)` (vidu supre) kaj `pb` montras al indekso `ln - i - chunk`, do ambaŭ estas almenaŭ `chunk` multajn bajtojn for de la fino de `self`.
                //
                //   - Ĉiu inicialigita memoro validas `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Uzu rotacii-post-16 por inversigi u16-ojn en u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SEKURECO: senalinea u32 legeblas de `i` se `i + 1 < ln`
                // (kaj evidente `i < ln`), ĉar ĉiu elemento estas 2 bajtoj kaj ni legas 4.
                //
                // `i + chunk - 1 < ln / 2` # dum kondiĉo
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Ĉar ĝi estas malpli ol la longo dividita per 2, tiam ĝi devas esti inter limoj.
                //
                // Ĉi tio ankaŭ signifas, ke la kondiĉo `0 < i + chunk <= ln` estas ĉiam respektata, certigante ke la montrilo `pb` povas esti uzata sekure.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SEKURECO: `i` malpli ol duono de la longo de la tranĉaĵo do
            // aliri `i` kaj `ln - i - 1` estas sekura (`i` komenciĝas je 0 kaj ne iros pli ol `ln / 2 - 1`).
            // La rezultaj montriloj `pa` kaj `pb` estas do validaj kaj vicigitaj, kaj legeblas kaj skribas al.
            //
            //
            unsafe {
                // Nesekura interŝanĝo por eviti la limojn kontroli sekuran interŝanĝon.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Redonas ripeton super la tranĉaĵo.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Liveras ripetilon, kiu permesas modifi ĉiun valoron.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Liveras ripetilon super ĉiuj apudaj windows de longo `size`.
    /// La windows interkovras.
    /// Se la tranĉaĵo estas pli mallonga ol `size`, la ripetilo ne redonas valorojn.
    ///
    /// # Panics
    ///
    /// Panics se `size` estas 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se la tranĉaĵo estas pli mallonga ol `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Liveras ripetilon super `chunk_size`-elementoj de la tranĉaĵo samtempe, ekde la komenco de la tranĉaĵo.
    ///
    /// La blokoj estas tranĉaĵoj kaj ne interkovras.Se `chunk_size` ne dividas la longon de la tranĉaĵo, tiam la lasta bloko ne havos longon `chunk_size`.
    ///
    /// Vidu [`chunks_exact`] por varianto de ĉi tiu ripetilo, kiu redonas pecojn de ĉiam ekzakte `chunk_size`-elementoj, kaj [`rchunks`] por la sama ripetilo, sed ekde la fino de la tranĉaĵo.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` estas 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Liveras ripetilon super `chunk_size`-elementoj de la tranĉaĵo samtempe, ekde la komenco de la tranĉaĵo.
    ///
    /// La blokoj estas ŝanĝeblaj tranĉaĵoj, kaj ne interkovras.Se `chunk_size` ne dividas la longon de la tranĉaĵo, tiam la lasta bloko ne havos longon `chunk_size`.
    ///
    /// Vidu [`chunks_exact_mut`] por varianto de ĉi tiu ripetilo, kiu redonas pecojn de ĉiam ekzakte `chunk_size`-elementoj, kaj [`rchunks_mut`] por la sama ripetilo, sed ekde la fino de la tranĉaĵo.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` estas 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Liveras ripetilon super `chunk_size`-elementoj de la tranĉaĵo samtempe, ekde la komenco de la tranĉaĵo.
    ///
    /// La blokoj estas tranĉaĵoj kaj ne interkovras.
    /// Se `chunk_size` ne dividas la longon de la tranĉaĵo, tiam la lastaj ĝis `chunk_size-1`-elementoj estos preterlasitaj kaj povas esti elprenitaj de la `remainder`-funkcio de la ripetilo.
    ///
    ///
    /// Pro ke ĉiu ero havas precize `chunk_size`-elementojn, la kompililo ofte povas optimumigi la rezultan kodon pli bone ol en la kazo de [`chunks`].
    ///
    /// Vidu [`chunks`] por varianto de ĉi tiu ripetilo, kiu ankaŭ redonas la reston kiel pli malgrandan parton, kaj [`rchunks_exact`] por la sama ripetilo, sed ekde la fino de la tranĉaĵo.
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` estas 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Liveras ripetilon super `chunk_size`-elementoj de la tranĉaĵo samtempe, ekde la komenco de la tranĉaĵo.
    ///
    /// La blokoj estas ŝanĝeblaj tranĉaĵoj, kaj ne interkovras.
    /// Se `chunk_size` ne dividas la longon de la tranĉaĵo, tiam la lastaj ĝis `chunk_size-1`-elementoj estos preterlasitaj kaj povas esti elprenitaj de la `into_remainder`-funkcio de la ripetilo.
    ///
    ///
    /// Pro ke ĉiu ero havas precize `chunk_size`-elementojn, la kompililo ofte povas optimumigi la rezultan kodon pli bone ol en la kazo de [`chunks_mut`].
    ///
    /// Vidu [`chunks_mut`] por varianto de ĉi tiu ripetilo, kiu ankaŭ redonas la reston kiel pli malgrandan parton, kaj [`rchunks_exact_mut`] por la sama ripetilo, sed ekde la fino de la tranĉaĵo.
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` estas 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Disigas la tranĉaĵon en tranĉaĵon de 'N`-elementaj tabeloj, supozante ke ne restas.
    ///
    ///
    /// # Safety
    ///
    /// Ĉi tio eble nomiĝas nur kiam
    /// - La tranĉaĵo fendas precize en pecojn de 'N`-elemento (alinome `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SEKURECO: 1-elementaj pecoj neniam restas
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SEKURECO: La tranĉa longo (6) estas oblo de 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Ĉi tiuj estus senvaloraj:
    /// // lasu pecojn: &[[_;5]]= slice.as_chunks_unchecked()//La tranĉa longo ne estas oblo de 5 lasitaj pecoj:&[[_;0]]= slice.as_chunks_unchecked()//Nul-longaj pecoj neniam rajtas
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SEKURECO: Nia antaŭkondiĉo estas ĝuste tio, kio necesas por nomi ĉi tion
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SEKURECO: Ni enmetas tranĉaĵon `new_len * N`-elementojn en
        // tranĉaĵo `new_len` multaj `N`-elementoj.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Disigas la tranĉaĵon en tranĉaĵon de 'N`-elementaj tabeloj, komencante komence de la tranĉaĵo, kaj restan tranĉaĵon kun longo strikte malpli ol `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` estas 0. Ĉi tiu kontrolo plej verŝajne ŝanĝiĝos al kompila tempo-eraro antaŭ ol ĉi tiu metodo stabiliĝos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SEKURECO: Ni jam panikiĝis kontraŭ nulo, kaj certigis nin per konstruado
        // ke la longo de la subtranĉaĵo estas oblo de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Disigas la tranĉaĵon en tranĉaĵon 'N`-elementaj tabeloj, komencante ĉe la fino de la tranĉaĵo, kaj restan tranĉaĵon kun longo strikte malpli ol `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` estas 0. Ĉi tiu kontrolo plej verŝajne ŝanĝiĝos al kompila tempo-eraro antaŭ ol ĉi tiu metodo stabiliĝos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SEKURECO: Ni jam panikiĝis kontraŭ nulo, kaj certigis nin per konstruado
        // ke la longo de la subtranĉaĵo estas oblo de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Liveras ripetilon super `N`-elementoj de la tranĉaĵo samtempe, ekde la komenco de la tranĉaĵo.
    ///
    /// La blokoj estas arreferencoj kaj ne interkovras.
    /// Se `N` ne dividas la longon de la tranĉaĵo, tiam la lastaj ĝis `N-1`-elementoj estos preterlasitaj kaj povas esti elprenitaj de la `remainder`-funkcio de la ripetilo.
    ///
    ///
    /// Ĉi tiu metodo estas la konst ĝenerala ekvivalento de [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics se `N` estas 0. Ĉi tiu kontrolo plej verŝajne ŝanĝiĝos al kompila tempo-eraro antaŭ ol ĉi tiu metodo stabiliĝos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Disigas la tranĉaĵon en tranĉaĵon de 'N`-elementaj tabeloj, supozante ke ne restas.
    ///
    ///
    /// # Safety
    ///
    /// Ĉi tio eble nomiĝas nur kiam
    /// - La tranĉaĵo fendas precize en pecojn de 'N`-elemento (alinome `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SEKURECO: 1-elementaj pecoj neniam restas
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SEKURECO: La tranĉa longo (6) estas oblo de 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Ĉi tiuj estus senvaloraj:
    /// // lasu pecojn: &[[_;5]]= slice.as_chunks_unchecked_mut()//La tranĉa longo ne estas oblo de 5 lasitaj pecoj:&[[_;0]]= slice.as_chunks_unchecked_mut()//Nul-longaj pecoj neniam rajtas
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SEKURECO: Nia antaŭkondiĉo estas ĝuste tio, kio necesas por nomi ĉi tion
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SEKURECO: Ni enmetas tranĉaĵon `new_len * N`-elementojn en
        // tranĉaĵo `new_len` multaj `N`-elementoj.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Disigas la tranĉaĵon en tranĉaĵon de 'N`-elementaj tabeloj, komencante komence de la tranĉaĵo, kaj restan tranĉaĵon kun longo strikte malpli ol `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` estas 0. Ĉi tiu kontrolo plej verŝajne ŝanĝiĝos al kompila tempo-eraro antaŭ ol ĉi tiu metodo stabiliĝos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SEKURECO: Ni jam panikiĝis kontraŭ nulo, kaj certigis nin per konstruado
        // ke la longo de la subtranĉaĵo estas oblo de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Disigas la tranĉaĵon en tranĉaĵon 'N`-elementaj tabeloj, komencante ĉe la fino de la tranĉaĵo, kaj restan tranĉaĵon kun longo strikte malpli ol `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` estas 0. Ĉi tiu kontrolo plej verŝajne ŝanĝiĝos al kompila tempo-eraro antaŭ ol ĉi tiu metodo stabiliĝos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SEKURECO: Ni jam panikiĝis kontraŭ nulo, kaj certigis nin per konstruado
        // ke la longo de la subtranĉaĵo estas oblo de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Liveras ripetilon super `N`-elementoj de la tranĉaĵo samtempe, ekde la komenco de la tranĉaĵo.
    ///
    /// La blokoj estas ŝanĝeblaj tabaj referencoj kaj ne interkovras.
    /// Se `N` ne dividas la longon de la tranĉaĵo, tiam la lastaj ĝis `N-1`-elementoj estos preterlasitaj kaj povas esti elprenitaj de la `into_remainder`-funkcio de la ripetilo.
    ///
    ///
    /// Ĉi tiu metodo estas la konst ĝenerala ekvivalento de [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics se `N` estas 0. Ĉi tiu kontrolo plej verŝajne ŝanĝiĝos al kompila tempo-eraro antaŭ ol ĉi tiu metodo stabiliĝos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Liveras ripetilon superkovrantan windows de `N`-elementoj de tranĉaĵo, ekde la komenco de la tranĉaĵo.
    ///
    ///
    /// Ĉi tiu estas la konst ĝenerala ekvivalento de [`windows`].
    ///
    /// Se `N` estas pli granda ol la grandeco de la tranĉaĵo, ĝi redonos neniun windows.
    ///
    /// # Panics
    ///
    /// Panics se `N` estas 0.
    /// Ĉi tiu kontrolo plej verŝajne ŝanĝiĝos al kompila tempo-eraro antaŭ ol ĉi tiu metodo stabiliĝos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Liveras ripetilon super `chunk_size`-elementoj de la tranĉaĵo samtempe, ekde la fino de la tranĉaĵo.
    ///
    /// La blokoj estas tranĉaĵoj kaj ne interkovras.Se `chunk_size` ne dividas la longon de la tranĉaĵo, tiam la lasta bloko ne havos longon `chunk_size`.
    ///
    /// Vidu [`rchunks_exact`] por varianto de ĉi tiu ripeto, kiu redonas pecojn de ĉiam ekzakte `chunk_size`-elementoj, kaj [`chunks`] por la sama ripeto, sed ekde la komenco de la tranĉaĵo.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` estas 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Liveras ripetilon super `chunk_size`-elementoj de la tranĉaĵo samtempe, ekde la fino de la tranĉaĵo.
    ///
    /// La blokoj estas ŝanĝeblaj tranĉaĵoj, kaj ne interkovras.Se `chunk_size` ne dividas la longon de la tranĉaĵo, tiam la lasta bloko ne havos longon `chunk_size`.
    ///
    /// Vidu [`rchunks_exact_mut`] por varianto de ĉi tiu ripeto, kiu redonas pecojn de ĉiam ekzakte `chunk_size`-elementoj, kaj [`chunks_mut`] por la sama ripeto, sed ekde la komenco de la tranĉaĵo.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` estas 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Liveras ripetilon super `chunk_size`-elementoj de la tranĉaĵo samtempe, ekde la fino de la tranĉaĵo.
    ///
    /// La blokoj estas tranĉaĵoj kaj ne interkovras.
    /// Se `chunk_size` ne dividas la longon de la tranĉaĵo, tiam la lastaj ĝis `chunk_size-1`-elementoj estos preterlasitaj kaj povas esti elprenitaj de la `remainder`-funkcio de la ripetilo.
    ///
    /// Pro ke ĉiu ero havas precize `chunk_size`-elementojn, la kompililo ofte povas optimumigi la rezultan kodon pli bone ol en la kazo de [`chunks`].
    ///
    /// Vidu [`rchunks`] por varianto de ĉi tiu ripetilo, kiu ankaŭ redonas la reston kiel pli malgrandan parton, kaj [`chunks_exact`] por la sama ripetilo, sed ekde la komenco de la tranĉaĵo.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` estas 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Liveras ripetilon super `chunk_size`-elementoj de la tranĉaĵo samtempe, ekde la fino de la tranĉaĵo.
    ///
    /// La blokoj estas ŝanĝeblaj tranĉaĵoj, kaj ne interkovras.
    /// Se `chunk_size` ne dividas la longon de la tranĉaĵo, tiam la lastaj ĝis `chunk_size-1`-elementoj estos preterlasitaj kaj povas esti elprenitaj de la `into_remainder`-funkcio de la ripetilo.
    ///
    /// Pro ke ĉiu ero havas precize `chunk_size`-elementojn, la kompililo ofte povas optimumigi la rezultan kodon pli bone ol en la kazo de [`chunks_mut`].
    ///
    /// Vidu [`rchunks_mut`] por varianto de ĉi tiu ripetilo, kiu ankaŭ redonas la reston kiel pli malgrandan parton, kaj [`chunks_exact_mut`] por la sama ripetilo, sed ekde la komenco de la tranĉaĵo.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` estas 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Liveras ripetilon super la tranĉaĵo produktante ne-imbrikitajn kurojn de elementoj uzantaj la predikaton por apartigi ilin.
    ///
    /// La predikato estas vokata de du elementoj sekvantaj sin, ĝi signifas, ke la predikato estas vokita sur `slice[0]` kaj `slice[1]` poste sur `slice[1]` kaj `slice[2]` ktp.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ĉi tiu metodo povas esti uzata por ĉerpi la ordigitajn subklikojn:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Liveras ripetilon super la tranĉaĵo produktante ne-imbrikitajn ŝanĝeblajn kurojn de elementoj uzantaj la predikaton por apartigi ilin.
    ///
    /// La predikato estas vokata de du elementoj sekvantaj sin, ĝi signifas, ke la predikato estas vokita sur `slice[0]` kaj `slice[1]` poste sur `slice[1]` kaj `slice[2]` ktp.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ĉi tiu metodo povas esti uzata por ĉerpi la ordigitajn subklikojn:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Dividas unu tranĉaĵon en du ĉe indekso.
    ///
    /// La unua enhavos ĉiujn indeksojn de `[0, mid)` (ekskludante la indekson `mid` mem) kaj la dua enhavos ĉiujn indeksojn de `[mid, len)` (ekskludante la indekson `len` mem).
    ///
    ///
    /// # Panics
    ///
    /// Panics se `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SEKURECO: `[ptr; mid]` kaj `[mid; len]` estas en `self`, kiu
        // plenumas la postulojn de `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Dividas unu ŝanĝeblan tranĉaĵon en du ĉe indekso.
    ///
    /// La unua enhavos ĉiujn indeksojn de `[0, mid)` (ekskludante la indekson `mid` mem) kaj la dua enhavos ĉiujn indeksojn de `[mid, len)` (ekskludante la indekson `len` mem).
    ///
    ///
    /// # Panics
    ///
    /// Panics se `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SEKURECO: `[ptr; mid]` kaj `[mid; len]` estas en `self`, kiu
        // plenumas la postulojn de `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Dividas unu tranĉaĵon en du ĉe indekso, sen fari limon.
    ///
    /// La unua enhavos ĉiujn indeksojn de `[0, mid)` (ekskludante la indekson `mid` mem) kaj la dua enhavos ĉiujn indeksojn de `[mid, len)` (ekskludante la indekson `len` mem).
    ///
    ///
    /// Por sekura alternativo vidu [`split_at`].
    ///
    /// # Safety
    ///
    /// Voki ĉi tiun metodon kun ekster-lima indekso estas *[nedifinita konduto]* eĉ se la rezulta referenco ne estas uzata.La alvokanto devas certigi tiun `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SEKURECO: Alvokanto devas kontroli tiun `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Dividas unu ŝanĝeblan tranĉaĵon en du ĉe indekso, sen limigi kontrolon.
    ///
    /// La unua enhavos ĉiujn indeksojn de `[0, mid)` (ekskludante la indekson `mid` mem) kaj la dua enhavos ĉiujn indeksojn de `[mid, len)` (ekskludante la indekson `len` mem).
    ///
    ///
    /// Por sekura alternativo vidu [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Voki ĉi tiun metodon kun ekster-lima indekso estas *[nedifinita konduto]* eĉ se la rezulta referenco ne estas uzata.La alvokanto devas certigi tiun `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SEKURECO: Alvokanto devas kontroli tiun `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` kaj `[mid; len]` ne interkovras, do redoni ŝanĝeblan referencon bonas.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Liveras ripetilon super subklakoj apartigitaj per elementoj, kiuj kongruas kun `pred`.
    /// La kongrua elemento ne estas enhavita en la subklicoj.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se la unua elemento kongruas, malplena tranĉaĵo estos la unua ero resendita de la ripetilo.
    /// Simile, se la lasta elemento en la tranĉaĵo kongruas, malplena tranĉaĵo estos la lasta ero resendita de la ripetilo:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se du egalitaj elementoj estas rekte apudaj, malplena tranĉaĵo ĉeestos inter ili:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Liveras ripetilon super ŝanĝeblaj subklakoj apartigitaj per elementoj egalaj al `pred`.
    /// La kongrua elemento ne estas enhavita en la subklicoj.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Liveras ripetilon super subklakoj apartigitaj per elementoj, kiuj kongruas kun `pred`.
    /// La kongrua elemento estas enhavita en la fino de la antaŭa subtranĉaĵo kiel finilo.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se la lasta elemento de la tranĉaĵo kongruas, tiu elemento estos konsiderata kiel finilo de la antaŭa tranĉaĵo.
    ///
    /// Tiu tranĉaĵo estos la lasta ero resendita de la ripetilo.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Liveras ripetilon super ŝanĝeblaj subklakoj apartigitaj per elementoj egalaj al `pred`.
    /// La kongrua elemento estas enhavita en la antaŭa subtranĉaĵo kiel finaĵo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Liveras ripetilon super subtranĉoj apartigitaj per elementoj egalaj al `pred`, komencante ĉe la fino de la tranĉaĵo kaj funkciante malantaŭen.
    /// La kongrua elemento ne estas enhavita en la subklicoj.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kiel ĉe `split()`, se la unua aŭ lasta elemento kongruas, malplena tranĉaĵo estos la unua (aŭ lasta) ero resendita de la ripetilo.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Liveras ripetilon super ŝanĝeblaj subtranĉoj apartigitaj per elementoj egalaj al `pred`, komencante ĉe la fino de la tranĉaĵo kaj funkciante malantaŭen.
    /// La kongrua elemento ne estas enhavita en la subklicoj.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Liveras ripetilon super subtranĉoj apartigitaj per elementoj, kiuj kongruas kun `pred`, limigita al redono de maksimume `n`-eroj.
    /// La kongrua elemento ne estas enhavita en la subklicoj.
    ///
    /// La lasta elemento resendita, se entute, enhavos la reston de la tranĉaĵo.
    ///
    /// # Examples
    ///
    /// Presu la tranĉaĵon dividita unufoje per nombroj divideblaj per 3 (t.e. `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Liveras ripetilon super subtranĉoj apartigitaj per elementoj, kiuj kongruas kun `pred`, limigita al redono de maksimume `n`-eroj.
    /// La kongrua elemento ne estas enhavita en la subklicoj.
    ///
    /// La lasta elemento resendita, se entute, enhavos la reston de la tranĉaĵo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Liveras ripetilon super subtranĉoj apartigitaj per elementoj, kiuj kongruas kun `pred` limigita al redono de maksimume `n`-eroj.
    /// Ĉi tio komenciĝas ĉe la fino de la tranĉaĵo kaj funkcias malantaŭen.
    /// La kongrua elemento ne estas enhavita en la subklicoj.
    ///
    /// La lasta elemento resendita, se entute, enhavos la reston de la tranĉaĵo.
    ///
    /// # Examples
    ///
    /// Presu la tranĉaĵon dividita unufoje, komencante de la fino, per nombroj divideblaj per 3 (te `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Liveras ripetilon super subtranĉoj apartigitaj per elementoj, kiuj kongruas kun `pred` limigita al redono de maksimume `n`-eroj.
    /// Ĉi tio komenciĝas ĉe la fino de la tranĉaĵo kaj funkcias malantaŭen.
    /// La kongrua elemento ne estas enhavita en la subklicoj.
    ///
    /// La lasta elemento resendita, se entute, enhavos la reston de la tranĉaĵo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Liveras `true` se la tranĉaĵo enhavas elementon kun la donita valoro.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Se vi ne havas `&T`, sed nur `&U` tia ke `T: Borrow<U>` (ekz
    /// `Ŝnuro: Prunti<str>`), vi povas uzi `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // tranĉaĵo `String`
    /// assert!(v.iter().any(|e| e == "hello")); // serĉu per `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Liveras `true` se `needle` estas prefikso de la tranĉaĵo.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Ĉiam redonas `true` se `needle` estas malplena tranĉaĵo:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Liveras `true` se `needle` estas sufikso de la tranĉaĵo.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Ĉiam redonas `true` se `needle` estas malplena tranĉaĵo:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Liveras subtranĉon kun la prefikso forigita.
    ///
    /// Se la tranĉaĵo komenciĝas per `prefix`, redonas la subtranĉon post la prefikso, envolvita en `Some`.
    /// Se `prefix` estas malplena, simple redonas la originalan tranĉaĵon.
    ///
    /// Se la tranĉaĵo ne komenciĝas per `prefix`, redonas `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ĉi tiu funkcio bezonos reverkadon se kaj kiam SlicePattern fariĝos pli kompleksa.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Liveras subtranĉon kun la sufikso forigita.
    ///
    /// Se la tranĉaĵo finiĝas per `suffix`, redonas la subtranĉon antaŭ la sufikso, envolvita en `Some`.
    /// Se `suffix` estas malplena, simple redonas la originalan tranĉaĵon.
    ///
    /// Se la tranĉaĵo ne finiĝas per `suffix`, redonas `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ĉi tiu funkcio bezonos reverkadon se kaj kiam SlicePattern fariĝos pli kompleksa.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Duuma serĉas ĉi tiun ordigitan tranĉaĵon por donita elemento.
    ///
    /// Se la valoro troviĝas, [`Result::Ok`] estas redonita, enhavanta la indekson de la kongrua elemento.
    /// Se estas multaj matĉoj, tiam iu ajn el la matĉoj povus esti redonita.
    /// Se la valoro ne troviĝas, [`Result::Err`] estas redonita, enhavanta la indekson, kie kongrua elemento povus esti enmetita konservante ordigitan ordon.
    ///
    ///
    /// Vidu ankaŭ [`binary_search_by`], [`binary_search_by_key`] kaj [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Serĉas serion de kvar elementoj.
    /// La unua troviĝas, kun unike decidita pozicio;la dua kaj tria ne troviĝas;la kvara povus egali iun ajn pozicion en `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Se vi volas enmeti eron al ordigita vector, konservante ordigon:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Duuma serĉas ĉi tiun ordigitan tranĉaĵon kun komparila funkcio.
    ///
    /// La komparila funkcio devas efektivigi ordon kongruan kun la ordigo de la suba tranĉaĵo, redonante ordokodon, kiu indikas ĉu ĝia argumento estas `Less`, `Equal` aŭ `Greater` la dezirata celo.
    ///
    ///
    /// Se la valoro troviĝas, [`Result::Ok`] estas redonita, enhavanta la indekson de la kongrua elemento.Se estas multaj matĉoj, tiam iu ajn el la matĉoj povus esti redonita.
    /// Se la valoro ne troviĝas, [`Result::Err`] estas redonita, enhavanta la indekson, kie kongrua elemento povus esti enmetita konservante ordigitan ordon.
    ///
    /// Vidu ankaŭ [`binary_search`], [`binary_search_by_key`] kaj [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Serĉas serion de kvar elementoj.La unua troviĝas, kun unike decidita pozicio;la dua kaj tria ne troviĝas;la kvara povus egali iun ajn pozicion en `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SEKURECO: la alvoko estas sendanĝera per jenaj invariantoj:
            // - `mid >= 0`
            // - `mid < size`: `mid` estas limigita per `[left; right)` ligita.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // La kialo, kial ni uzas if/else-kontrolfluon anstataŭ kongruon, estas ĉar kongruo reordigas komparajn operaciojn, kio estas perfekta.
            //
            // Jen x86 asm por u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Duuma serĉas ĉi tiun ordigitan tranĉaĵon kun ŝlosila eltira funkcio.
    ///
    /// Supozas, ke la tranĉaĵo estas ordigita laŭ la ŝlosilo, ekzemple kun [`sort_by_key`] uzanta la saman ŝlosilan ekstraktan funkcion.
    ///
    /// Se la valoro troviĝas, [`Result::Ok`] estas redonita, enhavanta la indekson de la kongrua elemento.
    /// Se estas multaj matĉoj, tiam iu ajn el la matĉoj povus esti redonita.
    /// Se la valoro ne troviĝas, [`Result::Err`] estas redonita, enhavanta la indekson, kie kongrua elemento povus esti enmetita konservante ordigitan ordon.
    ///
    ///
    /// Vidu ankaŭ [`binary_search`], [`binary_search_by`] kaj [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Serĉas serion de kvar elementoj en tranĉaĵo de paroj ordigitaj laŭ iliaj duaj elementoj.
    /// La unua troviĝas, kun unike decidita pozicio;la dua kaj tria ne troviĝas;la kvara povus egali iun ajn pozicion en `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links estas permesita ĉar `slice::sort_by_key` estas en crate `alloc`, kaj kiel tia ankoraŭ ne ekzistas dum konstruado de `core`.
    //
    // ligoj al laŭflua crate: #74481.Ĉar primitivuloj estas dokumentitaj nur en libstd (#73423), ĉi tio neniam kondukas al rompitaj ligoj praktike.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Ordigas la tranĉaĵon, sed eble ne konservas la ordon de egalaj elementoj.
    ///
    /// Ĉi tiu speco estas malstabila (t.e., povas reordigi egalajn elementojn), surloke (t.e., ne asignas), kaj *O*(*n*\*log(* n*)) plej malbone.
    ///
    /// # Nuna efektivigo
    ///
    /// La nuna algoritmo baziĝas sur [pattern-defeating quicksort][pdqsort] de Orson Peters, kiu kombinas la rapidan averaĝan kazon de hazarda rapidokvanto kun la rapida plej malbona kazo de pakaĵeto, atingante linian tempon sur tranĉaĵoj kun iuj ŝablonoj.
    /// Ĝi uzas iom da hazardo por eviti degeneritajn kazojn, sed kun fiksa seed por ĉiam doni determinisman konduton.
    ///
    /// Ĝi estas tipe pli rapida ol stabila ordigo, krom en kelkaj specialaj kazoj, ekz., Kiam la tranĉaĵo konsistas el pluraj interligitaj ordigitaj vicoj.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Ordigas la tranĉaĵon kun komparila funkcio, sed eble ne konservas la ordon de egalaj elementoj.
    ///
    /// Ĉi tiu speco estas malstabila (t.e., povas reordigi egalajn elementojn), surloke (t.e., ne asignas), kaj *O*(*n*\*log(* n*)) plej malbone.
    ///
    /// La komparila funkcio devas difini totalan mendadon de la elementoj en la tranĉaĵo.Se la mendado ne estas totala, la ordo de la elementoj estas nespecifita.Ordo estas totala ordo se ĝi estas (por ĉiuj `a`, `b` kaj `c`):
    ///
    /// * totala kaj kontraŭsimetria: ĝuste unu el `a < b`, `a == b` aŭ `a > b` estas vera, kaj
    /// * transitiva, `a < b` kaj `b < c` implicas `a < c`.La samo devas esti valida por ambaŭ `==` kaj `>`.
    ///
    /// Ekzemple, dum [`f64`] ne efektivigas [`Ord`] ĉar `NaN != NaN`, ni povas uzi `partial_cmp` kiel nia ordiga funkcio, kiam ni scias, ke la tranĉaĵo ne enhavas `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Nuna efektivigo
    ///
    /// La nuna algoritmo baziĝas sur [pattern-defeating quicksort][pdqsort] de Orson Peters, kiu kombinas la rapidan averaĝan kazon de hazarda rapidokvanto kun la rapida plej malbona kazo de pakaĵeto, atingante linian tempon sur tranĉaĵoj kun iuj ŝablonoj.
    /// Ĝi uzas iom da hazardo por eviti degeneritajn kazojn, sed kun fiksa seed por ĉiam doni determinisman konduton.
    ///
    /// Ĝi estas tipe pli rapida ol stabila ordigo, krom en kelkaj specialaj kazoj, ekz., Kiam la tranĉaĵo konsistas el pluraj interligitaj ordigitaj vicoj.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // inversa ordigo
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Ordigas la tranĉaĵon per ŝlosila eltira funkcio, sed eble ne konservas la ordon de egalaj elementoj.
    ///
    /// Ĉi tiu speco estas malstabila (t.e., povas reordigi egalajn elementojn), surloke (t.e. ne asignas), kaj *O*(m\* * n *\* log(*n*)) plej malbone, kie la ŝlosila funkcio estas *O*(*m*).
    ///
    /// # Nuna efektivigo
    ///
    /// La nuna algoritmo baziĝas sur [pattern-defeating quicksort][pdqsort] de Orson Peters, kiu kombinas la rapidan averaĝan kazon de hazarda rapidokvanto kun la rapida plej malbona kazo de pakaĵeto, atingante linian tempon sur tranĉaĵoj kun iuj ŝablonoj.
    /// Ĝi uzas iom da hazardo por eviti degeneritajn kazojn, sed kun fiksa seed por ĉiam doni determinisman konduton.
    ///
    /// Pro sia ŝlosila vokanta strategio, [`sort_unstable_by_key`](#method.sort_unstable_by_key) probable estos pli malrapida ol [`sort_by_cached_key`](#method.sort_by_cached_key) en kazoj, kie la ŝlosila funkcio multekostas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Reordigu la tranĉaĵon tiel, ke la elemento ĉe `index` troviĝas ĉe sia fina ordigita pozicio.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Reordigu la tranĉaĵon per komparila funkcio tia ke la elemento ĉe `index` estas ĉe sia fina ordigita pozicio.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Reordigu la tranĉaĵon per klava eltira funkcio tia, ke la elemento ĉe `index` troviĝas ĉe sia fina ordigita pozicio.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Reordigu la tranĉaĵon tiel, ke la elemento ĉe `index` troviĝas ĉe sia fina ordigita pozicio.
    ///
    /// Ĉi tiu reordigo havas la aldonan econ, ke iu ajn valoro ĉe pozicio `i < index` estos malpli ol aŭ egala al iu ajn valoro ĉe pozicio `j > index`.
    /// Aldone, ĉi tiu ordigo estas malstabila (t.e.
    /// ajna nombro da egalaj elementoj povas finiĝi ĉe pozicio `index`), surloke (t.e.
    /// ne asignas), kaj *O*(*n*) plej malbone.
    /// Ĉi tiu funkcio ankaŭ estas/konata kiel "kth element" en aliaj bibliotekoj.
    /// Ĝi redonas triopon de la jenaj valoroj: ĉiuj elementoj malpli ol tiu ĉe la donita indekso, la valoro ĉe la donita indekso, kaj ĉiuj elementoj pli grandaj ol tiu ĉe la donita indekso.
    ///
    ///
    /// # Nuna efektivigo
    ///
    /// La nuna algoritmo baziĝas sur la rapidelekta parto de la sama kvikta algoritmo uzata por [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kiam `index >= len()`, kio signifas, ke ĝi ĉiam panics sur malplenaj tranĉaĵoj.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Trovu la medianon
    /// v.select_nth_unstable(2);
    ///
    /// // Ni nur garantias, ke la tranĉaĵo estos unu el la sekvaj, laŭ nia maniero ordigi la specifan indekson.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reordigu la tranĉaĵon per komparila funkcio tia ke la elemento ĉe `index` estas ĉe sia fina ordigita pozicio.
    ///
    /// Ĉi tiu ordigo havas la aldonan econ, ke ia valoro ĉe pozicio `i < index` estos malpli ol aŭ egala al iu ajn valoro ĉe pozicio `j > index` uzanta la komparan funkcion.
    /// Aldone, ĉi tiu ordigo estas malstabila (t.e. ĉiu nombro da egalaj elementoj povas finiĝi ĉe pozicio `index`), surloke (t.e. ne asignas), kaj *O*(*n*) plej malbonkaze.
    /// Ĉi tiu funkcio ankaŭ estas konata kiel "kth element" en aliaj bibliotekoj.
    /// Ĝi redonas triopon de la jenaj valoroj: ĉiuj elementoj malpli ol tiu ĉe la donita indekso, la valoro ĉe la donita indekso, kaj ĉiuj elementoj pli grandaj ol tiu ĉe la donita indekso, uzante la provizitan komparan funkcion.
    ///
    ///
    /// # Nuna efektivigo
    ///
    /// La nuna algoritmo baziĝas sur la rapidelekta parto de la sama kvikta algoritmo uzata por [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kiam `index >= len()`, kio signifas, ke ĝi ĉiam panics sur malplenaj tranĉaĵoj.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Trovu la medianon kvazaŭ la tranĉaĵo estus ordigita laŭ descenda sinsekvo.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Ni nur garantias, ke la tranĉaĵo estos unu el la sekvaj, laŭ nia maniero ordigi la specifan indekson.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reordigu la tranĉaĵon per klava eltira funkcio tia, ke la elemento ĉe `index` troviĝas ĉe sia fina ordigita pozicio.
    ///
    /// Ĉi tiu ordigo havas la aldonan econ, ke iu ajn valoro ĉe pozicio `i < index` estos malpli ol aŭ egala al iu ajn valoro ĉe pozicio `j > index` uzanta la klavan ekstraktan funkcion.
    /// Aldone, ĉi tiu ordigo estas malstabila (t.e. ĉiu nombro da egalaj elementoj povas finiĝi ĉe pozicio `index`), surloke (t.e. ne asignas), kaj *O*(*n*) plej malbonkaze.
    /// Ĉi tiu funkcio ankaŭ estas konata kiel "kth element" en aliaj bibliotekoj.
    /// Ĝi redonas triopon de la jenaj valoroj: ĉiuj elementoj malpli ol tiu ĉe la donita indekso, la valoro ĉe la donita indekso, kaj ĉiuj elementoj pli grandaj ol tiu ĉe la donita indekso, uzante la provizitan ŝlosilan ekstraktan funkcion.
    ///
    ///
    /// # Nuna efektivigo
    ///
    /// La nuna algoritmo baziĝas sur la rapidelekta parto de la sama kvikta algoritmo uzata por [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kiam `index >= len()`, kio signifas, ke ĝi ĉiam panics sur malplenaj tranĉaĵoj.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Redonu la medianon kvazaŭ la tabelo estus ordigita laŭ absoluta valoro.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Ni nur garantias, ke la tranĉaĵo estos unu el la sekvaj, laŭ nia maniero ordigi la specifan indekson.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Movas ĉiujn sinsekvajn ripetajn elementojn al la fino de la tranĉaĵo laŭ la efektivigo de [`PartialEq`] trait.
    ///
    ///
    /// Liveras du tranĉaĵojn.La unua enhavas neniujn sinsekvajn ripetajn elementojn.
    /// La dua enhavas ĉiujn kopiojn en neniu specifa ordo.
    ///
    /// Se la tranĉaĵo estas ordigita, la unua revenita tranĉaĵo enhavas neniujn duplikatojn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Movas ĉiujn krom la unuajn sinsekvajn elementojn al la fino de la tranĉaĵo kontentigante antaŭfiksitan egalrilaton.
    ///
    /// Liveras du tranĉaĵojn.La unua enhavas neniujn sinsekvajn ripetajn elementojn.
    /// La dua enhavas ĉiujn kopiojn en neniu specifa ordo.
    ///
    /// La funkcio `same_bucket` ricevas referencojn al du elementoj de la tranĉaĵo kaj devas determini ĉu la elementoj egalas.
    /// La elementoj estas pasitaj en kontraŭa ordo de sia ordo en la tranĉaĵo, do se `same_bucket(a, b)` redonas `true`, `a` moviĝas ĉe la fino de la tranĉaĵo.
    ///
    ///
    /// Se la tranĉaĵo estas ordigita, la unua revenita tranĉaĵo enhavas neniujn duplikatojn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Kvankam ni havas ŝanĝeblan referencon al `self`, ni ne povas fari *arbitrajn* ŝanĝojn.La `same_bucket`-alvokoj povus panic, do ni devas certigi, ke la tranĉaĵo estas ĉiam valida.
        //
        // La maniero kiel ni traktas ĉi tion estas per uzado de interŝanĝoj;ni ripetas ĉiujn elementojn, interŝanĝante dum ni iras tiel, ke fine la elementoj, kiujn ni volas konservi, estas antaŭaj, kaj tiuj, kiujn ni volas malakcepti, estas malantaŭe.
        // Ni tiam povas dividi la tranĉaĵon.
        // Ĉi tiu operacio ankoraŭ estas `O(n)`.
        //
        // Ekzemplo: Ni komencas en ĉi tiu stato, kie `r` reprezentas "sekva
        // legu "kaj `w` reprezentas" sekvan_verki ".
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Komparante self[r] kontraŭ mem [w-1], ĉi tio ne estas duplikato, do ni interŝanĝas self[r] kaj self[w] (sen efiko kiel r==w) kaj poste pliigas ambaŭ r kaj w, lasante nin kun:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Komparante self[r] kontraŭ mem [w-1], ĉi tiu valoro estas duplikato, do ni pliigas `r` sed lasas ĉion alian senŝanĝa:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Komparante self[r] kontraŭ mem [w-1], ĉi tio ne estas duplikato, do interŝanĝu self[r] kaj self[w] kaj antaŭeniru r kaj w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Ne duplikato, ripetu:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplikato, advance r. End de tranĉaĵo.Disigi ĉe w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SEKURECO: la kondiĉo `while` garantias `next_read` kaj `next_write`
        // estas malpli ol `len`, do estas ene de `self`.
        // `prev_ptr_write` montras unu elementon antaŭ `ptr_write`, sed `next_write` komenciĝas per 1, do `prev_ptr_write` neniam estas malpli ol 0 kaj estas ene de la tranĉaĵo.
        // Ĉi tio plenumas la postulojn por dereferenci `ptr_read`, `prev_ptr_write` kaj `ptr_write`, kaj por uzi `ptr.add(next_read)`, `ptr.add(next_write - 1)` kaj `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` estas ankaŭ pliigita maksimume unufoje po buklo maksimume signifante ke neniu elemento estas transsaltita kiam ĝi eble devos esti interŝanĝita.
        //
        // `ptr_read` kaj `prev_ptr_write` neniam montras al la sama elemento.Ĉi tio necesas por ke `&mut *ptr_read`, `&mut* prev_ptr_write` estu sekuraj.
        // La klarigo simple estas, ke `next_read >= next_write` ĉiam veras, do ankaŭ `next_read > next_write - 1`.
        //
        //
        //
        //
        //
        unsafe {
            // Evitu limojn kontroli per krudaj montriloj.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Movas ĉiujn krom sinsekvajn elementojn ĝis la fino de la tranĉaĵo, kiu solvas al la sama ŝlosilo.
    ///
    ///
    /// Liveras du tranĉaĵojn.La unua enhavas neniujn sinsekvajn ripetajn elementojn.
    /// La dua enhavas ĉiujn kopiojn en neniu specifa ordo.
    ///
    /// Se la tranĉaĵo estas ordigita, la unua revenita tranĉaĵo enhavas neniujn duplikatojn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Rotacias la tranĉaĵon modloke tiel, ke la unuaj `mid`-elementoj de la tranĉaĵo moviĝas ĝis la fino dum la lastaj `self.len() - mid`-elementoj moviĝas al la antaŭo.
    /// Post voki `rotate_left`, la elemento antaŭe ĉe indekso `mid` fariĝos la unua elemento en la tranĉaĵo.
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio estos panic se `mid` estas pli granda ol la longo de la tranĉaĵo.Notu, ke `mid == self.len()` faras _not_ panic kaj estas senoperacia rotacio.
    ///
    /// # Complexity
    ///
    /// Prenas linian (en `self.len()`)-tempo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Turnado de subtranĉaĵo:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SEKURECO: La gamo `[p.add(mid) - mid, p.add(mid) + k)` estas banale
        // valida por legado kaj skribado, kiel postulas `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Rotacias la tranĉaĵon modloke tiel, ke la unuaj `self.len() - k`-elementoj de la tranĉaĵo moviĝas ĝis la fino dum la lastaj `k`-elementoj moviĝas al la antaŭo.
    /// Post voki `rotate_right`, la elemento antaŭe ĉe indekso `self.len() - k` fariĝos la unua elemento en la tranĉaĵo.
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio estos panic se `k` estas pli granda ol la longo de la tranĉaĵo.Notu, ke `k == self.len()` faras _not_ panic kaj estas senoperacia rotacio.
    ///
    /// # Complexity
    ///
    /// Prenas linian (en `self.len()`)-tempo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Rotacii subtranĉon:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SEKURECO: La gamo `[p.add(mid) - mid, p.add(mid) + k)` estas banale
        // valida por legado kaj skribado, kiel postulas `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Plenigas `self` per elementoj per klonado de `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Plenigas `self` kun elementoj redonitaj ripetante fermon.
    ///
    /// Ĉi tiu metodo uzas fermon por krei novajn valorojn.Se vi preferas [`Clone`] donitan valoron, uzu [`fill`].
    /// Se vi volas uzi [`Default`] trait por generi valorojn, vi povas pasi [`Default::default`] kiel argumenton.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kopias la elementojn de `src` en `self`.
    ///
    /// La longo de `src` devas esti la sama kiel `self`.
    ///
    /// Se `T` efektivigas `Copy`, povas esti pli elstare uzi [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio estos panic se la du tranĉaĵoj havas malsamajn longojn.
    ///
    /// # Examples
    ///
    /// Klonado de du elementoj de tranĉaĵo en alian:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Ĉar la tranĉaĵoj devas havi la saman longon, ni tranĉas la fontan tranĉaĵon de kvar elementoj al du.
    /// // Ĝi estos panic se ni ne faros ĉi tion.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust plenumas, ke nur povas esti unu ŝanĝebla referenco sen senŝanĝaj referencoj al aparta datumo en aparta amplekso.
    /// Pro ĉi tio, provi uzi `clone_from_slice` sur unu tranĉaĵo rezultigos kompila fiasko:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Por ĉirkaŭiri ĉi tion, ni povas uzi [`split_at_mut`] por krei du apartajn subtranĉaĵojn el tranĉaĵo:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kopias ĉiujn elementojn de `src` en `self`, uzante memcpy.
    ///
    /// La longo de `src` devas esti la sama kiel `self`.
    ///
    /// Se `T` ne efektivigas `Copy`, uzu [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio estos panic se la du tranĉaĵoj havas malsamajn longojn.
    ///
    /// # Examples
    ///
    /// Kopiante du elementojn de tranĉaĵo en alian:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Ĉar la tranĉaĵoj devas havi la saman longon, ni tranĉas la fontan tranĉaĵon de kvar elementoj al du.
    /// // Ĝi estos panic se ni ne faros ĉi tion.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust plenumas, ke nur povas esti unu ŝanĝebla referenco sen senŝanĝaj referencoj al aparta datumo en aparta amplekso.
    /// Pro ĉi tio, provi uzi `copy_from_slice` sur unu tranĉaĵo rezultigos kompila fiasko:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Por ĉirkaŭiri ĉi tion, ni povas uzi [`split_at_mut`] por krei du apartajn subtranĉaĵojn el tranĉaĵo:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // La kodvojo panic estis metita en malvarman funkcion por ne ŝveligi la alvokejon.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SEKURECO: `self` validas por `self.len()`-elementoj laŭdifine, kaj `src` estis
        // kontrolita por havi la saman longon.
        // La tranĉaĵoj ne povas interkovri ĉar ŝanĝeblaj referencoj estas ekskluzivaj.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kopias elementojn de unu parto de la tranĉaĵo al alia parto de si mem, uzante memmove.
    ///
    /// `src` estas la gamo ene de `self` por kopii.
    /// `dest` estas la komenca indekso de la intervalo ene de `self` al kiu kopii, kiu havos la saman longon kiel `src`.
    /// La du gamoj povas interkovri.
    /// La finoj de la du gamoj devas esti malpli ol aŭ egalaj al `self.len()`.
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio estos panic se iu intervalo superas la finon de la tranĉaĵo, aŭ se la fino de `src` estas antaŭ la komenco.
    ///
    ///
    /// # Examples
    ///
    /// Kopiante kvar bajtojn ene de tranĉaĵo:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SEKURECO: la kondiĉoj por `ptr::copy` ĉiuj estis kontrolitaj supre,
        // same kiel tiuj por `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Interŝanĝas ĉiujn elementojn en `self` kun tiuj en `other`.
    ///
    /// La longo de `other` devas esti la sama kiel `self`.
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio estos panic se la du tranĉaĵoj havas malsamajn longojn.
    ///
    /// # Example
    ///
    /// Interŝanĝante du elementojn trans tranĉaĵoj:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust plenumas, ke nur povas esti unu ŝanĝebla referenco al specifa datumo en aparta amplekso.
    ///
    /// Pro ĉi tio, provi uzi `swap_with_slice` sur unu tranĉaĵo rezultigos kompila fiasko:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Por ĉirkaŭiri ĉi tion, ni povas uzi [`split_at_mut`] por krei du apartajn ŝanĝeblajn subtranĉaĵojn el tranĉaĵo:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SEKURECO: `self` validas por `self.len()`-elementoj laŭdifine, kaj `src` estis
        // kontrolita por havi la saman longon.
        // La tranĉaĵoj ne povas interkovri ĉar ŝanĝeblaj referencoj estas ekskluzivaj.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funkcio por kalkuli longojn de la meza kaj posta tranĉaĵo por `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Kion ni faros pri `rest` estas ekscii, kian oblon de `U`s ni povas meti en plej malaltan nombron de`T`s.
        //
        // Kaj kiom da `T` ni bezonas por ĉiu tia "multiple".
        //
        // Konsideru ekzemple T=u8 U=u16.Tiam ni povas meti 1 U en 2 Ts.Simpla.
        // Nun konsideru ekzemple kazon, kie grandeco_de: :<T>=16, grandeco_de::<U>=24.</u>
        // Ni povas meti 2 Us anstataŭ ĉiu 3 Ts en la `rest`-tranĉaĵon.
        // Iom pli komplike.
        //
        // Formulo por kalkuli ĉi tion estas:
        //
        // Ni= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Vastigita kaj simpligita:
        //
        // Ni=grandeco_de: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=grandeco_de::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Feliĉe ĉar ĉio ĉi estas konstante pritaksita ... agado ĉi tie ne gravas!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // ripeta algoritmo de stein Ni tamen faru ĉi tiun `const fn` (kaj revenu al rekursiva algoritmo se ni faros ĝin) ĉar fidi je llvm por konstanti ĉion ĉi estas ... nu, ĝi malkomfortigas min.
            //
            //

            // SEKURECO: `a` kaj `b` estas kontrolitaj kiel ne-nulaj valoroj.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // forigu ĉiujn faktorojn de 2 de b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SEKURECO: `b` estas kontrolita por esti nula.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Armitaj per ĉi tiu scio, ni povas trovi kiom da `U`s ni povas kongrui!
        let us_len = self.len() / ts * us;
        // Kaj kiom da `T` estos en la posta tranĉaĵo!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmutu la tranĉaĵon al tranĉaĵo de alia tipo, certigante ke vicigo de la tipoj konserviĝu.
    ///
    /// Ĉi tiu metodo dividas la tranĉaĵon en tri apartajn tranĉaĵojn: prefikso, ĝuste vicigita meza tranĉaĵo de nova tipo, kaj la sufiksa tranĉaĵo.
    /// La metodo eble igos la mezan tranĉaĵon la plej granda longo ebla por donita tipo kaj eniga tranĉaĵo, sed nur la agado de via algoritmo devas dependi de tio, ne de ĝia ĝusteco.
    ///
    /// Estas allaseble ke ĉiuj eniraj datumoj estu redonitaj kiel prefikso aŭ sufikso tranĉaĵo.
    ///
    /// Ĉi tiu metodo havas nenian celon kiam aŭ eniga elemento `T` aŭ eliga elemento `U` estas nul-grandaj kaj redonos la originalan tranĉaĵon sen dividi ion.
    ///
    /// # Safety
    ///
    /// Ĉi tiu metodo estas esence `transmute` rilate al la elementoj en la revenita meza tranĉaĵo, do ĉiuj kutimaj avertoj rilate al `transmute::<T, U>` ankaŭ validas ĉi tie.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Notu, ke plejparto de ĉi tiu funkcio estos konstante taksata,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // pritraktu ZST-ojn speciale, kio estas-tute ne pritraktu ilin.
            return (self, &[], &[]);
        }

        // Unue, trovu en kiu punkto ni disiĝas inter la unua kaj la dua tranĉaĵo.
        // Facila kun ptr.align_offset.
        let ptr = self.as_ptr();
        // SEKURECO: Vidu la `align_to_mut`-metodon por la detala sekureca komento.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SEKURECO: nun `rest` estas definitive vicigita, do `from_raw_parts` sube estas en ordo,
            // ĉar la alvokanto garantias, ke ni povas transmutacii `T` al `U` sekure.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmutu la tranĉaĵon al tranĉaĵo de alia tipo, certigante ke vicigo de la tipoj konserviĝu.
    ///
    /// Ĉi tiu metodo dividas la tranĉaĵon en tri apartajn tranĉaĵojn: prefikso, ĝuste vicigita meza tranĉaĵo de nova tipo, kaj la sufiksa tranĉaĵo.
    /// La metodo eble igos la mezan tranĉaĵon la plej granda longo ebla por donita tipo kaj eniga tranĉaĵo, sed nur la agado de via algoritmo devas dependi de tio, ne de ĝia ĝusteco.
    ///
    /// Estas allaseble ke ĉiuj eniraj datumoj estu redonitaj kiel prefikso aŭ sufikso tranĉaĵo.
    ///
    /// Ĉi tiu metodo havas nenian celon kiam aŭ eniga elemento `T` aŭ eliga elemento `U` estas nul-grandaj kaj redonos la originalan tranĉaĵon sen dividi ion.
    ///
    /// # Safety
    ///
    /// Ĉi tiu metodo estas esence `transmute` rilate al la elementoj en la revenita meza tranĉaĵo, do ĉiuj kutimaj avertoj rilate al `transmute::<T, U>` ankaŭ validas ĉi tie.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Notu, ke plejparto de ĉi tiu funkcio estos konstante taksata,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // pritraktu ZST-ojn speciale, kio estas-tute ne pritraktu ilin.
            return (self, &mut [], &mut []);
        }

        // Unue, trovu en kiu punkto ni disiĝas inter la unua kaj la dua tranĉaĵo.
        // Facila kun ptr.align_offset.
        let ptr = self.as_ptr();
        // SEKURECO: Ĉi tie ni certigas, ke ni uzos vicigitajn montrilojn por U por la
        // cetero de la metodo.Ĉi tio fariĝas preterpasante montrilon al&[T] kun vicigo celita por U.
        // `crate::ptr::align_offset` estas vokita per ĝuste vicigita kaj valida montrilo `ptr` (ĝi venas de referenco al `self`) kaj kun grandeco kiu estas potenco de du (ĉar ĝi venas de la vicigo por U), kontentigante siajn sekurecajn limojn.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Ni ne povas uzi `rest` denove post ĉi tio, tio nuligus sian kaŝnomon `mut_ptr`!SEKURECO: vidu komentojn por `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Kontrolas ĉu la elementoj de ĉi tiu tranĉaĵo estas ordigitaj.
    ///
    /// Tio estas, por ĉiu elemento `a` kaj ĝia sekva elemento `b`, `a <= b` devas teni.Se la tranĉaĵo donas ekzakte nul aŭ unu elementon, `true` estas redonita.
    ///
    /// Notu, ke se `Self::Item` estas nur `PartialOrd`, sed ne `Ord`, la supra difino implicas, ke ĉi tiu funkcio redonas `false` se iuj du sinsekvaj eroj ne kompareblas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Kontrolas ĉu la elementoj de ĉi tiu tranĉaĵo estas ordigitaj per la donita komparila funkcio.
    ///
    /// Anstataŭ uzi `PartialOrd::partial_cmp`, ĉi tiu funkcio uzas la donitan `compare`-funkcion por determini la ordon de du elementoj.
    /// Krom tio, ĝi ekvivalentas al [`is_sorted`];vidu ĝian dokumentadon por pliaj informoj.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Kontrolas ĉu la elementoj de ĉi tiu tranĉaĵo estas ordigitaj per la donita ŝlosila eltira funkcio.
    ///
    /// Anstataŭ kompari rekte la elementojn de la tranĉaĵo, ĉi tiu funkcio komparas la klavojn de la elementoj, kiel determinite de `f`.
    /// Krom tio, ĝi ekvivalentas al [`is_sorted`];vidu ĝian dokumentadon por pliaj informoj.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Liveras la indekson de la dispartiga punkto laŭ la donita predikato (la indekso de la unua elemento de la dua subdisko).
    ///
    /// Oni supozas, ke la tranĉaĵo estas dispartigita laŭ la donita predikato.
    /// Ĉi tio signifas, ke ĉiuj elementoj, por kiuj la predikato redonas veron, estas ĉe la komenco de la tranĉaĵo kaj ĉiuj elementoj, por kiuj la predikato redonas falsan, estas ĉe la fino.
    ///
    /// Ekzemple, [7, 15, 3, 5, 4, 12, 6] estas dispartigita sub la predikato x% 2!=0 (ĉiuj neparaj nombroj estas ĉe la komenco, ĉiuj eĉ ĉe la fino).
    ///
    /// Se ĉi tiu tranĉaĵo ne estas dispartigita, la revenita rezulto estas nespecifita kaj sensenca, ĉar ĉi tiu metodo plenumas specon de duuma serĉo.
    ///
    /// Vidu ankaŭ [`binary_search`], [`binary_search_by`] kaj [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SEKURECO: Kiam `left < right`, `left <= mid < right`.
            // Tial `left` ĉiam pliiĝas kaj `right` ĉiam malpliiĝas, kaj iu el ili estas elektita.Ambaŭkaze `left <= right` estas kontenta.Tial se `left < right` en paŝo, `left <= right` estas kontenta en la sekva paŝo.
            //
            // Do tiel longe kiel `left != right`, `0 <= left < right <= len` estas kontenta kaj se ĉi tiu kazo ankaŭ `0 <= mid < len` estas kontenta.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Ni devas eksplicite tranĉi ilin laŭ la sama longo
        // por faciligi la optimumigilon forigi kontroladon.
        // Sed ĉar ĝi ne povas fidi, ni ankaŭ havas eksplicitan specialiĝon por T: Kopii.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Kreas malplenan tranĉaĵon.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Kreas ŝanĝeblan malplenan tranĉaĵon.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Ŝablonoj en tranĉaĵoj, nuntempe nur uzataj de `strip_prefix` kaj `strip_suffix`.
/// Ĉe punkto future, ni esperas ĝeneraligi `core::str::Pattern` (kiu dum la verkado limiĝas al `str`) al tranĉaĵoj, kaj tiam ĉi tiu trait estos anstataŭigita aŭ aboliciita.
///
pub trait SlicePattern {
    /// La elementospeco de la egalita tranĉaĵo.
    type Item;

    /// Nuntempe la konsumantoj de `SlicePattern` bezonas tranĉaĵon.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}