// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Turnas la gamon `[mid-left, mid+right)` tia, ke la elemento ĉe `mid` fariĝas la unua elemento.Ekvivalente, turnas la gamon `left`-elementojn maldekstren aŭ `right`-elementojn dekstren.
///
/// # Safety
///
/// La specifita intervalo devas esti valida por legado kaj skribado.
///
/// # Algorithm
///
/// Algoritmo 1 estas uzata por malgrandaj valoroj de `left + right` aŭ por granda `T`.
/// La elementoj moviĝas al siaj finaj pozicioj unu post la alia ekde `mid - left` kaj progresante per `right`-paŝoj modulo `left + right`, tia ke nur unu portempa bezono.
/// Fine, ni alvenas reen al `mid - left`.
/// Tamen, se `gcd(left + right, right)` ne estas 1, la supraj paŝoj transsaltis elementojn.
/// Ekzemple:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Bonŝance la nombro de transsaltitaj elementoj inter finitaj elementoj ĉiam egalas, do ni povas simple kompensi nian komencan pozicion kaj fari pli da ĉirkaŭvojoj (la totala nombro da ĉirkaŭvojoj estas la `gcd(left + right, right)` value).
///
/// La fina rezulto estas, ke ĉiuj elementoj finiĝas unufoje kaj nur unufoje.
///
/// Algoritmo 2 estas uzata se `left + right` estas granda sed `min(left, right)` estas sufiĉe malgranda por kongrui al staka bufro.
/// La `min(left, right)`-elementoj estas kopiitaj sur la bufron, `memmove` estas aplikita al la aliaj, kaj tiuj sur la bufro estas movitaj reen en la truon ĉe la kontraŭa flanko de kie ili estiĝis.
///
/// Algoritmoj, kiuj povas esti vektorigitaj, superas ĉi-supre post kiam `left + right` fariĝos sufiĉe granda.
/// Algoritmo 1 povas esti vektorigita per blokado kaj plenumado de multaj ĉirkaŭvojoj samtempe, sed estas tro malmultaj ĉirkaŭvojoj averaĝe ĝis `left + right` estas grandega, kaj la plej malbona kazo de ununura ĉirkaŭvojo ĉiam estas tie.
/// Anstataŭe, algoritmo 3 uzas ripetan interŝanĝadon de `min(left, right)`-elementoj ĝis pli malgranda rotacia problemo restas.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// kiam `left < right` la interŝanĝo okazas maldekstre anstataŭe.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. la subaj algoritmoj povas malsukcesi se ĉi tiuj kazoj ne estas kontrolitaj
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritmo 1 Microbenchmarks indikas, ke la averaĝa agado por hazardaj ŝanĝoj estas pli bona ĝis ĉirkaŭ `left + right == 32`, sed la plej malbona kazo funkcias eĉ ĉirkaŭ 16.
            // 24 estis elektita kiel meza tero.
            // Se la grandeco de `T` estas pli granda ol 4 `usize`s, ĉi tiu algoritmo ankaŭ superas aliajn algoritmojn.
            //
            //
            let x = unsafe { mid.sub(left) };
            // komenco de unua raŭndo
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` troveblas antaŭmane kalkulante `gcd(left + right, right)`, sed estas pli rapide fari unu buklon, kiu kalkulas la GCD kiel kromefikon, tiam farante la reston de la bloko
            //
            //
            let mut gcd = right;
            // komparnormoj malkaŝas, ke pli rapide interŝanĝas provizorojn tute anstataŭ legi unu provizoran unufoje, kopii malantaŭen, kaj poste verki tiun provizoran ĉe la fino mem.
            // Ĉi tio eble kaŭzas la fakton, ke interŝanĝi aŭ anstataŭigi provizorajn tempojn uzas nur unu memoradreson en la buklo anstataŭ bezoni administri du.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // anstataŭ pliigi `i` kaj poste kontroli ĉu ĝi estas ekster la limoj, ni kontrolas ĉu `i` iros ekster la limojn ĉe la sekva pliigo.
                // Ĉi tio malebligas ĉian envolvaĵon de montriloj aŭ `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // fino de unua raŭndo
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ĉi tiu kondicionalo devas esti ĉi tie se `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // fini la blokon per pli da rondoj
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ne estas nulgranda tipo, do estas bone dividi per ĝia grandeco.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritmo 2 La `[T; 0]` ĉi tie devas certigi, ke ĉi tio taŭge vicas por T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritmo 3 Estas alternativa maniero interŝanĝi, kiu implicas trovi, kie estus la lasta interŝanĝo de ĉi tiu algoritmo, kaj interŝanĝi uzante tiun lastan parton anstataŭ interŝanĝi apudajn pecojn kiel ĉi tiu algoritmo faras, sed ĉi tiu maniero estas ankoraŭ pli rapida.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritmo 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}