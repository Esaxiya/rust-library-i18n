//! Tranĉaĵa ordigo
//!
//! Ĉi tiu modulo enhavas ordigan algoritmon bazitan sur la ŝablona malvenka rapideco de Orson Peters, publikigita ĉe: <https://github.com/orlp/pdqsort>
//!
//!
//! Malstabila ordigo kongruas kun libcore ĉar ĝi ne asignas memoron, male al nia stabila ordiga efektivigo.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Se faligita, kopioj de `src` en `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SEKURECO: Ĉi tio estas helpa klaso.
        //          Bonvolu raporti al ĝia uzado por ĝusteco.
        //          Nome oni devas esti certa, ke `src` kaj `dst` ne interkovras kiel postulas `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Ŝovas la unuan elementon dekstren ĝis ĝi renkontas pli grandan aŭ egalan elementon.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SEKURECO: La nesekuraj operacioj sube implicas indeksadon sen limigita ĉeko (`get_unchecked` kaj `get_unchecked_mut`)
    // kaj kopiado de memoro (`ptr::copy_nonoverlapping`).
    //
    // a.Indeksado:
    //  1. Ni kontrolis la grandecon de la tabelo al>=2.
    //  2. La tuta indeksado, kiun ni faros, estas ĉiam maksimume inter {0 <= index < len}.
    //
    // b.Memorokopiado
    //  1. Ni akiras montrilojn al referencoj, kiuj certas esti validaj.
    //  2. Ili ne povas interkovri ĉar ni akiras montrilojn al diferencaj indicoj de la tranĉaĵo.
    //     Nome `i` kaj `i-1`.
    //  3. Se la tranĉaĵo estas ĝuste vicigita, la elementoj estas ĝuste vicigitaj.
    //     Estas la respondeco de la alvokanto certigi, ke la tranĉaĵo estas ĝuste vicigita.
    //
    // Vidu komentojn sube por pliaj detaloj.
    unsafe {
        // Se la unuaj du elementoj estas malordaj ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Legu la unuan elementon en stak-asignitan variablon.
            // Se sekva kompara operacio panics, `hole` falos kaj aŭtomate skribos la elementon en la tranĉaĵon.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Movu `i`-th elementon unu lokon maldekstren, tiel movante la truon dekstren.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` falas kaj tiel kopias `tmp` en la restantan truon en `v`.
        }
    }
}

/// Ŝovas la lastan elementon maldekstren ĝis ĝi renkontas pli malgrandan aŭ egalan elementon.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SEKURECO: La nesekuraj operacioj sube implicas indeksadon sen limigita ĉeko (`get_unchecked` kaj `get_unchecked_mut`)
    // kaj kopiado de memoro (`ptr::copy_nonoverlapping`).
    //
    // a.Indeksado:
    //  1. Ni kontrolis la grandecon de la tabelo al>=2.
    //  2. La tuta indeksado, kiun ni faros, estas ĉiam maksimume inter `0 <= index < len-1`.
    //
    // b.Memorokopiado
    //  1. Ni akiras montrilojn al referencoj, kiuj certas esti validaj.
    //  2. Ili ne povas interkovri ĉar ni akiras montrilojn al diferencaj indicoj de la tranĉaĵo.
    //     Nome `i` kaj `i+1`.
    //  3. Se la tranĉaĵo estas ĝuste vicigita, la elementoj estas ĝuste vicigitaj.
    //     Estas la respondeco de la alvokanto certigi, ke la tranĉaĵo estas ĝuste vicigita.
    //
    // Vidu komentojn sube por pliaj detaloj.
    unsafe {
        // Se la lastaj du elementoj estas malordaj ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Legu la lastan elementon en stak-asignitan variablon.
            // Se sekva kompara operacio panics, `hole` falos kaj aŭtomate skribos la elementon en la tranĉaĵon.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Movu i-i elementon unu lokon dekstren, tiel movante la truon maldekstren.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` falas kaj tiel kopias `tmp` en la restantan truon en `v`.
        }
    }
}

/// Parte ordigas tranĉaĵon per ŝovo de kelkaj eksterordaj elementoj ĉirkaŭe.
///
/// Liveras `true` se la tranĉaĵo estas ordigita fine.Ĉi tiu funkcio estas *O*(*n*) plej malbona kazo.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maksimuma nombro de apudaj eksterordaj paroj, kiuj ŝanĝiĝos.
    const MAX_STEPS: usize = 5;
    // Se la tranĉaĵo estas pli mallonga ol ĉi tio, ne ŝanĝu iujn elementojn.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SEKURECO: Ni jam eksplicite faris la limigitan kontroladon per `i < len`.
        // Ĉiuj niaj postaj indeksoj estas nur en la gamo `0 <= index < len`
        unsafe {
            // Trovu la sekvan paron de apudaj malordaj elementoj.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Ĉu ni finis?
        if i == len {
            return true;
        }

        // Ne ŝanĝu elementojn sur mallongaj tabeloj, tio havas rendimentan koston.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Interŝanĝu la trovitan paron de elementoj.Ĉi tio metas ilin en ĝustan ordon.
        v.swap(i - 1, i);

        // Ŝovu la pli malgrandan elementon maldekstren.
        shift_tail(&mut v[..i], is_less);
        // Ŝovu la pli grandan elementon dekstren.
        shift_head(&mut v[i..], is_less);
    }

    // Ne sukcesis ordigi la tranĉaĵon laŭ la limigita nombro da paŝoj.
    false
}

/// Ordigas tranĉaĵon uzante enmetan ordigon, kiu estas *O*(*n*^ 2) plej malbona.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Ordigas `v` uzante peze, kio garantias *O*(*n*\*log(* n*)) plej malbone.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ĉi tiu duuma amaso respektas la senvarian `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Infanoj de `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Elektu la pli grandan infanon.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Ĉesu se la senvaria validas ĉe `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Interŝanĝu `node` kun la pli granda infano, movu unu paŝon malsupren kaj daŭrigu kribri.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Konstruu la amason laŭ linea tempo.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Popmaksimumaj elementoj de la amaso.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Dispartigas `v` en elementojn pli malgrandajn ol `pivot`, sekvitajn de elementoj pli grandaj aŭ egalaj al `pivot`.
///
///
/// Liveras la nombron de elementoj pli malgrandaj ol `pivot`.
///
/// Dispartigado estas plenumata laŭbloke por minimumigi la koston de branĉaj operacioj.
/// Ĉi tiu ideo estas prezentita en la [BlockQuicksort][pdf]-papero.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Nombro de elementoj en tipa bloko.
    const BLOCK: usize = 128;

    // La dispartiga algoritmo ripetas la jenajn paŝojn ĝis finiĝo:
    //
    // 1. Spuri blokon de la maldekstra flanko por identigi elementojn pli grandajn ol aŭ egalajn al la pivoto.
    // 2. Spuri blokon de la dekstra flanko por identigi elementojn pli malgrandajn ol la pivoto.
    // 3. Interŝanĝu la identigitajn elementojn inter la maldekstra kaj dekstra flanko.
    //
    // Ni konservas la jenajn variablojn por bloko de elementoj:
    //
    // 1. `block` - Nombro de elementoj en la bloko.
    // 2. `start` - Komencu montrilon en la tabelon `offsets`.
    // 3. `end` - Fina montrilo en la tabelon `offsets`.
    // 4. `kompensoj, Indeksoj de malordaj elementoj ene de la bloko.

    // La aktuala bloko maldekstre (de `l` ĝis `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // La aktuala bloko dekstre (de `r.sub(block_r)` to `r`).
    // SEKURECO: La dokumentoj por .add() specife mencias, ke `vec.as_ptr().add(vec.len())` ĉiam estas sekura
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Kiam ni ricevos VLA-ojn, provu krei unu aron da longo `min(v.len(), 2 * BLOCK) `prefere
    // ol du fiks-grandecaj tabeloj de longo `BLOCK`.VLA-oj povus esti pli kaŝmemoraj.

    // Liveras la nombron de elementoj inter montriloj `l` (inclusive) kaj `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Ni finis kun dispartigo bloko post bloko kiam `l` kaj `r` proksimiĝas.
        // Poste ni faras iom da komplika laboro por dividi la ceterajn elementojn inter.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Nombro de ceteraj elementoj (ankoraŭ ne kompare kun la pivoto).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Ĝustigu blokajn grandecojn tiel, ke la maldekstra kaj dekstra bloko ne interkovru, sed perfekte vicu por kovri la tutan restantan breĉon.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Spuri `block_l`-elementojn de la maldekstra flanko.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SEKURECO: La nesekuraj operacioj sube implikas la uzadon de la `offset`.
                //         Laŭ la kondiĉoj postulitaj de la funkcio, ni kontentigas ilin ĉar:
                //         1. `offsets_l` estas stak-asignita, kaj tiel konsiderata aparta asignita objekto.
                //         2. La funkcio `is_less` redonas `bool`.
                //            Casteti `bool` neniam superfluos `isize`.
                //         3. Ni garantiis, ke `block_l` estos `<= BLOCK`.
                //            Krome, `end_l` estis komence agordita al la komenca montrilo de `offsets_`, kiu estis deklarita sur la stako.
                //            Tiel ni scias, ke eĉ en la plej malbona kazo (ĉiuj alvokoj de `is_less` revenas falsaj) ni nur maksimume 1 bajto preterpasos la finon.
                //        Alia nesekura operacio ĉi tie malreferencas `elem`.
                //        Tamen `elem` estis komence la komenca montrilo al la tranĉaĵo, kiu ĉiam validas.
                unsafe {
                    // Senbranĉa komparo.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Spuri `block_r`-elementojn de la dekstra flanko.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SEKURECO: La nesekuraj operacioj sube implikas la uzadon de la `offset`.
                //         Laŭ la kondiĉoj postulitaj de la funkcio, ni kontentigas ilin ĉar:
                //         1. `offsets_r` estas stak-asignita, kaj tiel konsiderata aparta asignita objekto.
                //         2. La funkcio `is_less` redonas `bool`.
                //            Casteti `bool` neniam superfluos `isize`.
                //         3. Ni garantiis, ke `block_r` estos `<= BLOCK`.
                //            Krome, `end_r` estis komence agordita al la komenca montrilo de `offsets_`, kiu estis deklarita sur la stako.
                //            Tiel, ni scias, ke eĉ en la plej malbona kazo (ĉiuj alvokoj de `is_less` revenas vera) ni nur maksimume 1 bajto preterpasos la finon.
                //        Alia nesekura operacio ĉi tie malreferencas `elem`.
                //        Tamen `elem` komence `1 *sizeof(T)` pasis la finon kaj ni malpliigas ĝin per `1* sizeof(T)` antaŭ ol aliri ĝin.
                //        Krome, `block_r` estis asertita esti malpli ol `BLOCK` kaj `elem` do maksimume montros al la komenco de la tranĉaĵo.
                unsafe {
                    // Senbranĉa komparo.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Nombro de malordaj elementoj interŝanĝeblaj inter la maldekstra kaj dekstra flanko.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Anstataŭ interŝanĝi unu paron tiutempe, estas pli efike plenumi ciklan permutaĵon.
            // Ĉi tio ne strikte ekvivalentas al interŝanĝo, sed produktas similan rezulton uzante malpli da memoraj operacioj.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Ĉiuj eksterordaj elementoj en la maldekstra bloko estis movitaj.Iru al la sekva bloko.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Ĉiuj eksterordaj elementoj en la dekstra bloko estis movitaj.Movu al la antaŭa bloko.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Nur nun restas maksimume unu bloko (aŭ maldekstre aŭ dekstre) kun malordaj elementoj, kiujn necesas movi.
    // Tiaj ceteraj elementoj povas esti simple ŝanĝitaj al la fino ene de sia bloko.
    //

    if start_l < end_l {
        // La maldekstra bloko restas.
        // Movu ĝiajn ceterajn malordajn elementojn al la ekstrema dekstro.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // La ĝusta bloko restas.
        // Movu ĝiajn ceterajn malordajn elementojn al la ekstrema maldekstro.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nenio alia por fari, ni finis.
        width(v.as_mut_ptr(), l)
    }
}

/// Dispartigas `v` en elementojn pli malgrandajn ol `v[pivot]`, sekvitajn de elementoj pli grandaj aŭ egalaj al `v[pivot]`.
///
///
/// Liveras opon de:
///
/// 1. Nombro de elementoj malpli granda ol `v[pivot]`.
/// 2. Vere se `v` jam estis dispartigita.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Metu la pivoton komence de tranĉaĵo.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Legu la pivoton en stak-asignitan variablon por efikeco.
        // Se sekva kompara operacio panics, la pivoto aŭtomate estos reskribita en la tranĉaĵon.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Trovu la unuan paron de malordaj elementoj.
        let mut l = 0;
        let mut r = v.len();

        // SEKURECO: La sekureco sube implicas indeksadon de tabelo.
        // Por la unua: Ni jam faras la limojn kontrolante ĉi tie per `l < r`.
        // Por la dua: Ni komence havas `l == 0` kaj `r == v.len()` kaj ni kontrolis tiun `l < r` ĉe ĉiu indeksa operacio.
        //                     De ĉi tie ni scias, ke `r` devas esti almenaŭ `r == l`, kiu montriĝis valida ekde la unua.
        unsafe {
            // Trovu la unuan elementon pli grandan aŭ egalan al la pivoto.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Trovu la lastan elementon pli malgrandan ol la pivoto.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` eliras el amplekso kaj skribas la pivoton (kiu estas stak-asignita variablo) reen en la tranĉaĵon, kie ĝi origine estis.
        // Ĉi tiu paŝo estas kritika por certigi sekurecon!
        //
    };

    // Metu la pivoton inter la du vandoj.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Dispartigas `v` en elementojn egalajn al `v[pivot]` sekvitaj de elementoj pli grandaj ol `v[pivot]`.
///
/// Liveras la nombron de elementoj egala al la pivoto.
/// Oni supozas, ke `v` ne enhavas elementojn pli malgrandajn ol la pivoto.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Metu la pivoton komence de tranĉaĵo.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Legu la pivoton en stak-asignitan variablon por efikeco.
    // Se sekva kompara operacio panics, la pivoto aŭtomate estos reskribita en la tranĉaĵon.
    // SEKURECO: La montrilo ĉi tie validas ĉar ĝi estas akirita de referenco al tranĉaĵo.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Nun dispartigu la tranĉaĵon.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SEKURECO: La sekureco sube implicas indeksadon de tabelo.
        // Por la unua: Ni jam faras la limojn kontrolante ĉi tie per `l < r`.
        // Por la dua: Ni komence havas `l == 0` kaj `r == v.len()` kaj ni kontrolis tiun `l < r` ĉe ĉiu indeksa operacio.
        //                     De ĉi tie ni scias, ke `r` devas esti almenaŭ `r == l`, kiu montriĝis valida ekde la unua.
        unsafe {
            // Trovu la unuan elementon pli grandan ol la pivoto.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Trovu la lastan elementon egala al la pivoto.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Ĉu ni finis?
            if l >= r {
                break;
            }

            // Interŝanĝu la trovitan paron de malordaj elementoj.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Ni trovis `l`-elementojn egalajn al la pivoto.Aldonu 1 por kalkuli la pivoton mem.
    l + 1

    // `_pivot_guard` eliras el amplekso kaj skribas la pivoton (kiu estas stak-asignita variablo) reen en la tranĉaĵon, kie ĝi origine estis.
    // Ĉi tiu paŝo estas kritika por certigi sekurecon!
}

/// Disvastigas iujn elementojn ĉirkaŭe por provi rompi ŝablonojn, kiuj povus kaŭzi malekvilibrajn vandojn en rapideco.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom-nombrogeneratoro de la "Xorshift RNGs"-papero de George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Prenu hazardajn nombrojn modulo ĉi tiu nombro.
        // La nombro kongruas al `usize` ĉar `len` ne estas pli granda ol `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Iuj pivotaj kandidatoj troviĝos proksime de ĉi tiu indekso.Ni randomigu ilin.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Generi hazardan nombron modulo `len`.
            // Tamen, por eviti multekostajn operaciojn, ni unue prenas ĝin modulo potenco de du, kaj poste malpliiĝas per `len` ĝis ĝi eniras la gamon `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` estas garantiita esti malpli ol `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Elektas pivoton en `v` kaj redonas la indekson kaj `true` se la tranĉaĵo probable jam estas aranĝita.
///
/// Elementoj en `v` povus esti reordigitaj en la procezo.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minimuma longo por elekti la mezan-de-medianan metodon.
    // Pli mallongaj tranĉaĵoj uzas la simplan mezumon de tri metodo.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maksimuma nombro de interŝanĝoj plenumeblaj en ĉi tiu funkcio.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tri indicoj proksime al kiuj ni elektos pivoton.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Kalkulas la tutan nombron de interŝanĝoj, kiujn ni faros dum ordigado de indicoj.
    let mut swaps = 0;

    if len >= 8 {
        // Interŝanĝaj indicoj tiel ke `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Interŝanĝaj indicoj tiel ke `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Trovas la medianon de `v[a - 1], v[a], v[a + 1]` kaj stokas la indekson en `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Trovu medianojn en la ĉirkaŭaĵoj de `a`, `b` kaj `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Trovu la medianon inter `a`, `b` kaj `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // La maksimuma nombro da interŝanĝoj estis plenumita.
        // Probable la tranĉaĵo malpliiĝas aŭ plejparte malaltiĝas, do inversigo probable helpos ordigi ĝin pli rapide.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Ordigas `v` rekursie.
///
/// Se la tranĉaĵo havis antaŭulon en la originala tabelo, ĝi estas specifita kiel `pred`.
///
/// `limit` estas la nombro de permesataj malekvilibraj subdiskoj antaŭ ol ŝanĝi al `heapsort`.
/// Se nulo, ĉi tiu funkcio tuj ŝanĝiĝos al malpeza.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tranĉaĵoj ĝis ĉi tiu longo estas ordigitaj per enmeta ordigo.
    const MAX_INSERTION: usize = 20;

    // Vere se la lasta dispartigo estis sufiĉe ekvilibra.
    let mut was_balanced = true;
    // Vere se la lasta dispartigo ne miksis elementojn (la tranĉaĵo jam estis dispartigita).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Tre mallongaj tranĉaĵoj ordiĝas per enmetita ordigo.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Se tro multaj malbonaj pivotaj elektoj estis faritaj, simple reiru al pakaĵeto por garantii `O(n * log(n))` plej malbonan.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Se la lasta dispartigo estis malekvilibra, provu rompi ŝablonojn en la tranĉaĵo intermiksante iujn elementojn ĉirkaŭe.
        // Espereble ni elektos pli bonan pivoton ĉi-foje.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Elektu pivoton kaj provu diveni ĉu la tranĉaĵo jam estas aranĝita.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Se la lasta dispartigo estis dece ekvilibrigita kaj ne miksis elementojn, kaj se pivota elekto antaŭdiras, ke la tranĉaĵo probable jam estas aranĝita ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Provu identigi plurajn malordajn elementojn kaj ŝanĝi ilin al ĝustaj pozicioj.
            // Se la tranĉaĵo finiĝos tute ordigita, ni finis.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Se la elektita pivoto egalas al la antaŭulo, tiam ĝi estas la plej malgranda elemento en la tranĉaĵo.
        // Dispartigu la tranĉaĵon en elementojn egalajn al kaj elementoj pli grandaj ol la pivoto.
        // Ĉi tiu kazo kutime trafas kiam la tranĉaĵo enhavas multajn duplikatajn elementojn.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Daŭre ordigu elementojn pli grandajn ol la pivoto.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Dispartigu la tranĉaĵon.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Dividu la tranĉaĵon en `left`, `pivot` kaj `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Ripetu en la pli mallongan flankon nur por minimumigi la tutan nombron de rekursivaj alvokoj kaj konsumi malpli da staka spaco.
        // Tiam nur daŭrigu per la pli longa flanko (ĉi tio similas al vosta rekursio).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Ordigas `v` uzante ŝablonon venkantan rapidan, kiu estas *O*(*n*\*log(* n*)) plej malbona.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ordigo havas neniun sencan konduton ĉe nulgrandaj specoj.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Limigu la nombron de malekvilibraj subdiskoj al `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Por tranĉaĵoj ĝis ĉi tiu longo probable pli rapide simple ordigi ilin.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Elektu pivoton
        let (pivot, _) = choose_pivot(v, is_less);

        // Se la elektita pivoto egalas al la antaŭulo, tiam ĝi estas la plej malgranda elemento en la tranĉaĵo.
        // Dispartigu la tranĉaĵon en elementojn egalajn al kaj elementoj pli grandaj ol la pivoto.
        // Ĉi tiu kazo kutime trafas kiam la tranĉaĵo enhavas multajn duplikatajn elementojn.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Se ni preterpasis nian indekson, tiam ni bonas.
                if mid > index {
                    return;
                }

                // Alie, daŭre ordigu elementojn pli grandajn ol la pivoto.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Dividu la tranĉaĵon en `left`, `pivot` kaj `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Se mid==indekso, tiam ni finis, ĉar partition() garantiis, ke ĉiuj elementoj post mid estas pli grandaj ol egalaj al mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Ordigo havas neniun sencan konduton ĉe nulgrandaj specoj.Fari nenion.
    } else if index == v.len() - 1 {
        // Trovu maksimuman elementon kaj metu ĝin en la lastan pozicion de la tabelo.
        // Ni rajtas uzi `unwrap()` ĉi tie, ĉar ni scias, ke v ne devas esti malplena.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Trovu min-elementon kaj metu ĝin en la unuan pozicion de la tabelo.
        // Ni rajtas uzi `unwrap()` ĉi tie, ĉar ni scias, ke v ne devas esti malplena.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}