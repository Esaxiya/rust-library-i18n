//! Makrooj uzataj de ripetantoj de tranĉaĵo.

// Enlinia estas_malplena kaj len faras grandegan agadon
macro_rules! is_empty {
    // La maniero kiel ni kodas la longon de ZST-ripetilo, ĉi tio funkcias kaj por ZST kaj ne-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Por forigi iujn limajn kontrolojn (vidu `position`), ni kalkulas la longon laŭ iom neatendita maniero.
// (Provita de `codegen/slice-position-bound-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // ni foje estas uzataj ene de nesekura bloko

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Ĉi tiu _cannot_ uzas `unchecked_sub` ĉar ni dependas de envolvaĵo por reprezenti la longon de longaj ZST-tranĉaĵaj ripetiloj.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Ni scias, ke `start <= end`, do povas fari pli bone ol `offset_from`, kiu bezonas subskribon.
            // Starigante taŭgajn flagojn ĉi tie, ni povas diri al LLVM ĉi tion, kio helpas ĝin forigi limojn.
            // SEKURECO: Laŭ la tipo senvaria, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Dirante ankaŭ al LLVM, ke la montriloj estas apartaj per ekzakta oblo de la tipa grandeco, ĝi povas optimumigi `len() == 0` ĝis `start == end` anstataŭ `(end - start) < size`.
            //
            // SEKURECO: Per la tipo senvaria, la montriloj estas vicigitaj tiel la
            //         distanco inter ili devas esti oblo de pointee-grandeco
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// La komuna difino de la `Iter` kaj `IterMut`-ripetiloj
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Liveras la unuan elementon kaj movas la komencon de la ripetilo antaŭen per 1.
        // Tre plibonigas rendimenton kompare kun enlinia funkcio.
        // La ripetilo ne rajtas esti malplena.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Redonas la lastan elementon kaj movas la finon de la ripetilo malantaŭen per 1.
        // Tre plibonigas rendimenton kompare kun enlinia funkcio.
        // La ripetilo ne rajtas esti malplena.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Ŝrumpas la ripetilon kiam T estas ZST, movante la finon de la ripetilo malantaŭen per `n`.
        // `n` ne devas superi `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Helpa funkcio por krei tranĉaĵon de la ripetilo.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SEKURECO: la ripetilo estis kreita el tranĉaĵo kun montrilo
                // `self.ptr` kaj longo `len!(self)`.
                // Ĉi tio garantias, ke ĉiuj antaŭkondiĉoj por `from_raw_parts` estas plenumitaj.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Helpa funkcio por antaŭenigi la komencon de la ripetilo per `offset`-elementoj, redonante la malnovan komencon.
            //
            // Nesekura ĉar la ofseto ne devas superi `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SEKURECO: la alvokanto garantias, ke `offset` ne superas `self.len()`,
                    // do ĉi tiu nova montrilo estas ene de `self` kaj tiel garantias esti nenula.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Helpa funkcio por movi la finon de la ripetilo malantaŭen per `offset`-elementoj, redonante la novan finon.
            //
            // Nesekura ĉar la ofseto ne devas superi `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SEKURECO: la alvokanto garantias, ke `offset` ne superas `self.len()`,
                    // kiu garantias ne superverŝi `isize`.
                    // Ankaŭ la rezulta montrilo estas en limoj de `slice`, kiu plenumas la aliajn postulojn por `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // povus esti efektivigita per tranĉaĵoj, sed ĉi tio evitas limojn

                // SEKURECO: `assume`-alvokoj estas sekuraj ekde la komenca montrilo de tranĉaĵo
                // devas esti nenula, kaj tranĉaĵoj super ne-ZST-oj devas havi ankaŭ nenulan finmontrilon.
                // La alvoko al `next_unchecked!` estas sekura ĉar ni kontrolas ĉu la ripeto estas malplena unue.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ĉi tiu ripetilo nun estas malplena.
                    if mem::size_of::<T>() == 0 {
                        // Ni devas fari ĝin tiel, ĉar `ptr` eble neniam estos 0, sed `end` povus esti (pro envolvado).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SEKURECO: fino ne povas esti 0 se T ne estas ZST ĉar ptr ne estas 0 kaj fino>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SEKURECO: Ni estas en limoj.`post_inc_start` faras la ĝustan aferon eĉ por ZST-oj.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Ni anstataŭigas la defaŭltan efektivigon, kiu uzas `try_fold`, ĉar ĉi tiu simpla efektivigo generas malpli da LLVM-IR kaj pli rapide kompileblas.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Ni anstataŭigas la defaŭltan efektivigon, kiu uzas `try_fold`, ĉar ĉi tiu simpla efektivigo generas malpli da LLVM-IR kaj pli rapide kompileblas.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Ni anstataŭigas la defaŭltan efektivigon, kiu uzas `try_fold`, ĉar ĉi tiu simpla efektivigo generas malpli da LLVM-IR kaj pli rapide kompileblas.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Ni anstataŭigas la defaŭltan efektivigon, kiu uzas `try_fold`, ĉar ĉi tiu simpla efektivigo generas malpli da LLVM-IR kaj pli rapide kompileblas.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Ni anstataŭigas la defaŭltan efektivigon, kiu uzas `try_fold`, ĉar ĉi tiu simpla efektivigo generas malpli da LLVM-IR kaj pli rapide kompileblas.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Ni anstataŭigas la defaŭltan efektivigon, kiu uzas `try_fold`, ĉar ĉi tiu simpla efektivigo generas malpli da LLVM-IR kaj pli rapide kompileblas.
            // Ankaŭ la `assume` evitas liman kontrolon.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SEKURECO: ni estas garantiitaj esti limigitaj per la bukla senvaria:
                        // kiam `i >= n`, `self.next()` redonas `None` kaj la buklo rompiĝas.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Ni anstataŭigas la defaŭltan efektivigon, kiu uzas `try_fold`, ĉar ĉi tiu simpla efektivigo generas malpli da LLVM-IR kaj pli rapide kompileblas.
            // Ankaŭ la `assume` evitas liman kontrolon.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SEKURECO: `i` devas esti pli malalta ol `n` ĉar ĝi komenciĝas ĉe `n`
                        // kaj nur malpliiĝas.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SEKURECO: la alvokanto devas garantii, ke `i` estas en limo de
                // la suba tranĉaĵo, do `i` ne povas superflui `isize`, kaj la revenitaj referencoj estas garantiitaj rilati al elemento de la tranĉaĵo kaj tiel garantiitaj por esti validaj.
                //
                // Notu ankaŭ, ke la alvokanto ankaŭ garantias, ke oni neniam plu vokos nin per la sama indekso, kaj ke neniuj aliaj metodoj, kiuj aliros ĉi tiun subklikon, estas nomataj, do validas, ke la resendita referenco estu ŝanĝebla en la kazo de
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // povus esti efektivigita per tranĉaĵoj, sed ĉi tio evitas limojn

                // SEKURECO: `assume`-alvokoj estas sekuraj, ĉar la komenca montrilo de tranĉaĵo devas esti nula,
                // kaj tranĉaĵoj super ne-ZST-oj ankaŭ devas havi ne-nulan finmontrilon.
                // La alvoko al `next_back_unchecked!` estas sekura ĉar ni kontrolas ĉu la ripeto estas malplena unue.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ĉi tiu ripetilo nun estas malplena.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SEKURECO: Ni estas en limoj.`pre_dec_end` faras la ĝustan aferon eĉ por ZST-oj.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}