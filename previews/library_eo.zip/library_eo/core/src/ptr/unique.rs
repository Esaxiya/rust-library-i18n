use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Envolvaĵo ĉirkaŭ kruda nenula `*mut T`, kiu indikas, ke la posedanto de ĉi tiu envolvaĵo posedas la referencon.
/// Utila por konstrui abstraktadojn kiel `Box<T>`, `Vec<T>`, `String` kaj `HashMap<K, V>`.
///
/// Male al `*mut T`, `Unique<T>` kondutas "as if" ĝi estis kazo de `T`.
/// Ĝi efektivigas `Send`/`Sync` se `T` estas `Send`/`Sync`.
/// Ĝi ankaŭ implicas tiajn fortajn kaŝnomajn garantiojn, kiujn kazo de `T` povas atendi:
/// la referenco de la montrilo ne devas esti modifita sen unika vojo al sia propra Unika.
///
/// Se vi ne scias, ĉu estas ĝuste uzi `Unique` por viaj celoj, konsideru uzi `NonNull`, kiu havas pli malfortan semantikon.
///
///
/// Male al `*mut T`, la montrilo devas ĉiam esti nenula, eĉ se la montrilo neniam estas malreferencita.
/// Ĉi tio estas tiel, ke enumeroj povas uzi ĉi tiun malpermesitan valoron kiel diskriminanton-`Option<Unique<T>>` havas la saman grandecon kiel `Unique<T>`.
/// Tamen la montrilo eble ankoraŭ pendas se ĝi ne estas malreferencita.
///
/// Male al `*mut T`, `Unique<T>` estas kunvarianta super `T`.
/// Ĉi tio ĉiam devas esti ĝusta por iu ajn tipo, kiu subtenas la kaŝnomajn postulojn de Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ĉi tiu markilo ne havas konsekvencojn por varianco, sed necesas
    // por dropck komprenu, ke ni logike posedas `T`.
    //
    // Por detaloj, vidu:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` montriloj estas `Send` se `T` estas `Send` ĉar la datumoj, kiujn ili referencas, estas senvaloraj.
/// Notu, ke ĉi tiu aliasa invarianto ne estas devigita de la tipa sistemo;la abstraktaĵo uzanta la `Unique` devas plenumi ĝin.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` montriloj estas `Sync` se `T` estas `Sync` ĉar la datumoj, kiujn ili referencas, estas senvaloraj.
/// Notu, ke ĉi tiu aliasa invarianto ne estas devigita de la tipa sistemo;la abstraktaĵo uzanta la `Unique` devas plenumi ĝin.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Kreas novan `Unique` pendantan, sed bone vicigitan.
    ///
    /// Ĉi tio utilas por pravalorizi tipojn, kiuj pigre asignas, kiel `Vec::new` faras.
    ///
    /// Rimarku, ke la montrila valoro eble reprezentas validan montrilon al `T`, kio signifas, ke ĉi tio ne rajtas esti uzata kiel sentinela valoro "not yet initialized".
    /// Tipoj, kiuj pigre atribuas, devas spuri inicialigon per iuj aliaj rimedoj.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SEKURECO: mem::align_of() redonas validan ne-nulan montrilon.La
        // kondiĉoj por voki new_unchecked() estas tiel respektataj.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Kreas novan `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` devas esti nenula.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SEKURECO: la alvokanto devas garantii, ke `ptr` estas nenula.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Kreas novan `Unique` se `ptr` estas nenula.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SEKURECO: La montrilo jam estas kontrolita kaj ne estas nula.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Akiras la subestan montrilon `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Diferencigas la enhavon.
    ///
    /// La rezulta vivdaŭro nepre mem devos konduti "as if", ĝi efektive estus kazo de T pruntita.
    /// Se necesas pli longa (unbound)-vivo, uzu `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SEKURECO: la alvokanto devas garantii, ke `self` plenumas ĉiujn
        // postuloj por referenco.
        unsafe { &*self.as_ptr() }
    }

    /// Reciproke malreferencas la enhavon.
    ///
    /// La rezulta vivdaŭro nepre mem devos konduti "as if", ĝi efektive estus kazo de T pruntita.
    /// Se necesas pli longa (unbound)-vivo, uzu `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SEKURECO: la alvokanto devas garantii, ke `self` plenumas ĉiujn
        // postuloj por ŝanĝebla referenco.
        unsafe { &mut *self.as_ptr() }
    }

    /// Castetas al montrilo de alia tipo.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SEKURECO: Unique::new_unchecked() kreas novan unikan kaj bezonatan
        // la donita montrilo ne estu nula.
        // Ĉar ni preterpasas memon kiel montrilon, ĝi ne povas esti nula.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SEKURECO: ŝanĝebla referenco ne povas esti nula
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}