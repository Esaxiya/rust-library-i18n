#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Provizas la montrilan metadatenan tipon de iu ajn indikita tipo.
///
/// # Montrilo metadatenoj
///
/// Krudaj montriloj kaj referencaj tipoj en Rust povas esti pensataj kiel faritaj el du partoj:
/// datuma montrilo, kiu enhavas la memoran adreson de la valoro, kaj iujn metadatenojn.
///
/// Por statikmezaj specoj (kiuj efektivigas la `Sized` traits) same kiel por `extern`-specoj, montriloj laŭdire estas "maldikaj": metadatenoj estas nul-grandaj kaj ĝia tipo estas `()`.
///
///
/// Montriloj al [dynamically-sized types][dst] laŭdire estas "larĝaj" aŭ "grasaj", ili havas nedimensiajn metadatenojn:
///
/// * Por strukturoj, kies lasta kampo estas DST, metadatenoj estas la metadatenoj de la lasta kampo
/// * Por la `str`-speco, metadatenoj estas la longo en bajtoj kiel `usize`
/// * Por tranĉaĵospecoj kiel `[T]`, metadatenoj estas la longo en eroj kiel `usize`
/// * Por trait-objektoj kiel `dyn SomeTrait`, metadatenoj estas [`DynMetadata<Self>`][DynMetadata] (ekz. `DynMetadata<dyn SomeTrait>`)
///
/// En la future, la lingvo Rust povas akiri novajn specojn de tipoj, kiuj havas malsamajn montrilajn metadatenojn.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # La `Pointee` trait
///
/// La punkto de ĉi tiu trait estas ĝia `Metadata`-rilata tipo, kiu estas `()` aŭ `usize` aŭ `DynMetadata<_>` kiel priskribite supre.
/// Ĝi aŭtomate efektiviĝas por ĉiu tipo.
/// Oni povas supozi, ke ĝi estas efektivigita en ĝenerala kunteksto, eĉ sen responda bendo.
///
/// # Usage
///
/// Krudaj montriloj povas esti malkonstruitaj en la datuman adreson kaj metadatenajn erojn per sia [`to_raw_parts`]-metodo.
///
/// Alternative, metadatenoj sole povas esti ĉerpitaj per la funkcio [`metadata`].
/// Referenco povas esti pasita al [`metadata`] kaj implicite devigita.
///
/// Montrilo (possibly-wide) povas kunmetiĝi de sia adreso kaj metadatenoj per [`from_raw_parts`] aŭ [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// La tipo por metadatenoj en montriloj kaj referencoj al `Self`.
    #[lang = "metadata_type"]
    // NOTE: Konservu trait bounds en `static_assert_expected_bounds_for_metadata`
    //
    // en `library/core/src/ptr/metadata.rs` sinkronigita kun tiuj ĉi tie:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Montriloj al tipoj efektivigantaj ĉi tiun trait-kaŝnomon estas "maldikaj".
///
/// Ĉi tio inkluzivas statike 'Grandigitajn' tipojn kaj `extern`-specojn.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: ĉu ne stabiligu ĉi tion antaŭ ol trait-kaŝnomoj stabilas en la lingvo?
pub trait Thin = Pointee<Metadata = ()>;

/// Ĉerpu la metadatenan komponanton de montrilo.
///
/// Valoroj de tipo `*mut T`, `&T` aŭ `&mut T` povas esti transdonitaj rekte al ĉi tiu funkcio, ĉar ili implicite devigas al `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SEKURECO: Aliri la valoron de la `PtrRepr`-unio estas sekura ĉar * const T
    // kaj PtrComponents<T>havas la samajn memorajn aranĝojn.
    // Nur std povas doni ĉi tiun garantion.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Formas krudan montrilon (possibly-wide) de datuma adreso kaj metadatenoj.
///
/// Ĉi tiu funkcio estas sekura, sed la revenita montrilo ne nepre estas sekura al malreferenco.
/// Por tranĉaĵoj, vidu la dokumentadon de [`slice::from_raw_parts`] pri sekurecaj postuloj.
/// Por trait-objektoj, la metadatenoj devas veni de montrilo al la sama subesta forigita tipo.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SEKURECO: Aliri la valoron de la `PtrRepr`-unio estas sekura ĉar * const T
    // kaj PtrComponents<T>havas la samajn memorajn aranĝojn.
    // Nur std povas doni ĉi tiun garantion.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Elfaras la saman funkcion kiel [`from_raw_parts`], krom ke kruda `*mut`-montrilo estas redonita, kontraste al kruda `* const`-montrilo.
///
///
/// Vidu la dokumentadon de [`from_raw_parts`] por pli da detaloj.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SEKURECO: Aliri la valoron de la `PtrRepr`-unio estas sekura ĉar * const T
    // kaj PtrComponents<T>havas la samajn memorajn aranĝojn.
    // Nur std povas doni ĉi tiun garantion.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Manlibro necesas por eviti `T: Copy` ligita.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Manlibro necesas por eviti `T: Clone` ligita.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// La metadatenoj por `Dyn = dyn SomeTrait` trait objektospeco.
///
/// Ĝi estas montrilo al vtable (virtuala voktablo), kiu reprezentas ĉiujn necesajn informojn por manipuli la konkretan tipon stokitan ene de trait-objekto.
/// La tabelo precipe ĝi enhavas:
///
/// * tajpu grandecon
/// * tajpu vicigon
/// * montrilo al la `drop_in_place`-impl de la tipo (povas esti sen-opa por simpla-malnova-datumo)
/// * montriloj al ĉiuj metodoj por la speca efektivigo de la trait
///
/// Rimarku, ke la unuaj tri estas specialaj, ĉar ili necesas por asigni, faligi kaj repartigi iun ajn trait-objekton.
///
/// Eblas nomi ĉi tiun strukturon per tipo-parametro, kiu ne estas objekto `dyn` trait (ekzemple `DynMetadata<u64>`) sed ne akiri sencan valoron de tiu strukturo.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// La komuna prefikso de ĉiuj tabeloj.Ĝin sekvas funkciaj montriloj por metodoj trait.
///
/// Privata efektiviga detalo de `DynMetadata::size_of` ktp.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Liveras la grandecon de la tipo asociita kun ĉi tiu tabelo.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Liveras la vicigon de la tipo asociita kun ĉi tiu tabelo.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Redonas la grandecon kaj vicigon kune kiel `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SEKURECO: la kompililo elsendis ĉi tiun tabelon por konkreta tipo Rust kiu
        // estas konata havi validan aranĝon.Sama racio kiel en `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Manaj iloj necesas por eviti `Dyn: $Trait`-limojn.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}