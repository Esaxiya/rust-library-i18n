use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` sed nula kaj kunvarianta.
///
/// Ĉi tio ofte estas la ĝusta afero uzi dum konstruado de datumstrukturoj per krudaj montriloj, sed finfine pli danĝere uzebla pro ĝiaj aldonaj ecoj.Se vi ne certas, ĉu vi uzu `NonNull<T>`, simple uzu `*mut T`!
///
/// Male al `*mut T`, la montrilo devas ĉiam esti nenula, eĉ se la montrilo neniam estas malreferencita.Ĉi tio estas tiel, ke enumeroj povas uzi ĉi tiun malpermesitan valoron kiel diskriminanton-`Option<NonNull<T>>` havas la saman grandecon kiel `* mut T`.
/// Tamen la montrilo eble ankoraŭ pendas se ĝi ne estas malreferencita.
///
/// Male al `*mut T`, `NonNull<T>` estis elektita por esti kunvarianta super `T`.Ĉi tio ebligas uzi `NonNull<T>` dum konstruado de kunvariantaj specoj, sed enkondukas la riskon de malsaneco se ĝi estas uzata en tipo, kiu fakte ne devus esti kunvarianta.
/// (La kontraŭa elekto estis farita por `*mut T` kvankam teknike la malsaneco povus esti kaŭzita nur de nomado de nesekuraj funkcioj.)
///
/// Kvarianco ĝustas por plej sekuraj abstraktadoj, kiel `Box`, `Rc`, `Arc`, `Vec` kaj `LinkedList`.Ĉi tio estas la kazo ĉar ili provizas publikan API, kiu sekvas la normalajn komunajn XOR-ŝanĝeblajn regulojn de Rust.
///
/// Se via tipo ne povas sekure kunvarianti, vi devas certigi, ke ĝi enhavas iun aldonan kampon por doni nevarianton.Ofte ĉi tiu kampo estos [`PhantomData`]-speco kiel `PhantomData<Cell<T>>` aŭ `PhantomData<&'a mut T>`.
///
/// Rimarku, ke `NonNull<T>` havas `From`-ekzemplon por `&T`.Tamen ĉi tio ne ŝanĝas la fakton, ke mutacii per (montrilo derivita de) komuna referenco estas nedifinita konduto krom se la mutacio okazas ene de [`UnsafeCell<T>`].La samo validas por krei ŝanĝeblan referencon de komuna referenco.
///
/// Kiam vi uzas ĉi tiun `From`-ekzemplon sen `UnsafeCell<T>`, estas via respondeco certigi, ke `as_mut` neniam estas vokita, kaj `as_ptr` neniam estas uzata por mutacio.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` montriloj ne estas `Send` ĉar la datumoj, kiujn ili referencas, povas esti kaŝnomaj.
// NB, ĉi tiu impl estas nenecesa, sed devas doni pli bonajn erarmesaĝojn.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` montriloj ne estas `Sync` ĉar la datumoj, kiujn ili referencas, povas esti kaŝnomaj.
// NB, ĉi tiu impl estas nenecesa, sed devas doni pli bonajn erarmesaĝojn.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Kreas novan `NonNull` pendantan, sed bone vicigitan.
    ///
    /// Ĉi tio utilas por pravalorizi tipojn, kiuj pigre asignas, kiel `Vec::new` faras.
    ///
    /// Rimarku, ke la montrila valoro eble reprezentas validan montrilon al `T`, kio signifas, ke ĉi tio ne rajtas esti uzata kiel sentinela valoro "not yet initialized".
    /// Tipoj, kiuj pigre atribuas, devas spuri inicialigon per iuj aliaj rimedoj.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SEKURECO: mem::align_of() redonas nulan uzokutimon, kiu tiam estas gisita
        // al * mut T.
        // Tial `ptr` ne estas nula kaj la kondiĉoj por voki new_unchecked() estas respektataj.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Liveras komunajn referencojn al la valoro.Kontraste al [`as_ref`], ĉi tio ne postulas, ke la valoro devas esti pravalorizita.
    ///
    /// Por la ŝanĝebla ekvivalento vidu [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Vokante ĉi tiun metodon, vi devas certigi, ke ĉio el la sekvaj estas vera:
    ///
    /// * La montrilo devas esti ĝuste vicigita.
    ///
    /// * Ĝi devas esti "dereferencable" en la senco difinita en [the module documentation].
    ///
    /// * Vi devas plenumi la kaŝnomajn regulojn de Rust, ĉar la redonita vivdaŭro `'a` estas arbitre elektita kaj ne nepre reflektas la realan vivdaŭron de la datumoj.
    ///
    ///   Aparte, dum la daŭro de ĉi tiu vivo, la memoro, al kiu montras la montrilo, ne devas mutiĝi (krom ene de `UnsafeCell`).
    ///
    /// Ĉi tio validas eĉ se la rezulto de ĉi tiu metodo estas neuzata!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SEKURECO: la alvokanto devas garantii, ke `self` plenumas ĉiujn
        // postuloj por referenco.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Liveras unikajn referencojn al la valoro.Kontraste al [`as_mut`], ĉi tio ne postulas, ke la valoro devas esti pravalorizita.
    ///
    /// Por la komuna ekvivalento vidu [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Vokante ĉi tiun metodon, vi devas certigi, ke ĉio el la sekvaj estas vera:
    ///
    /// * La montrilo devas esti ĝuste vicigita.
    ///
    /// * Ĝi devas esti "dereferencable" en la senco difinita en [the module documentation].
    ///
    /// * Vi devas plenumi la kaŝnomajn regulojn de Rust, ĉar la redonita vivdaŭro `'a` estas arbitre elektita kaj ne nepre reflektas la realan vivdaŭron de la datumoj.
    ///
    ///   Aparte, dum la daŭro de ĉi tiu vivo, la memoro, kiun la montrilo montras, ne rajtas aliri (legi aŭ skribi) per iu ajn alia montrilo.
    ///
    /// Ĉi tio validas eĉ se la rezulto de ĉi tiu metodo estas neuzata!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SEKURECO: la alvokanto devas garantii, ke `self` plenumas ĉiujn
        // postuloj por referenco.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Kreas novan `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` devas esti nenula.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SEKURECO: la alvokanto devas garantii, ke `ptr` estas nenula.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Kreas novan `NonNull` se `ptr` estas nenula.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SEKURECO: La montrilo jam estas kontrolita kaj ne estas nula
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Elfaras la saman funkcion kiel [`std::ptr::from_raw_parts`], krom ke `NonNull`-montrilo estas redonita, kontraste al kruda `*const`-montrilo.
    ///
    ///
    /// Vidu la dokumentadon de [`std::ptr::from_raw_parts`] por pli da detaloj.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SEKURECO: La rezulto de `ptr::from::raw_parts_mut` estas nenula ĉar `data_address` estas.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Malkombinu (eble larĝan) montrilon en adresajn kaj metadatenajn erojn.
    ///
    /// La montrilo povas poste esti rekonstruita per [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Akiras la subestan montrilon `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Liveras komunan referencon al la valoro.Se la valoro povas esti neinicialigita, anstataŭe oni uzu [`as_uninit_ref`].
    ///
    /// Por la ŝanĝebla ekvivalento vidu [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Vokante ĉi tiun metodon, vi devas certigi, ke ĉio el la sekvaj estas vera:
    ///
    /// * La montrilo devas esti ĝuste vicigita.
    ///
    /// * Ĝi devas esti "dereferencable" en la senco difinita en [the module documentation].
    ///
    /// * La montrilo devas montri al pravalorizita kazo de `T`.
    ///
    /// * Vi devas plenumi la kaŝnomajn regulojn de Rust, ĉar la redonita vivdaŭro `'a` estas arbitre elektita kaj ne nepre reflektas la realan vivdaŭron de la datumoj.
    ///
    ///   Aparte, dum la daŭro de ĉi tiu vivo, la memoro, al kiu montras la montrilo, ne devas mutiĝi (krom ene de `UnsafeCell`).
    ///
    /// Ĉi tio validas eĉ se la rezulto de ĉi tiu metodo estas neuzata!
    /// (La parto pri pravalorizado ankoraŭ ne estas plene decidita, sed ĝis ĝi fariĝos, la sola sekura aliro estas certigi, ke ili efektive estas pravalorizitaj.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SEKURECO: la alvokanto devas garantii, ke `self` plenumas ĉiujn
        // postuloj por referenco.
        unsafe { &*self.as_ptr() }
    }

    /// Liveras unikan referencon al la valoro.Se la valoro povas esti neinicialigita, anstataŭe oni uzu [`as_uninit_mut`].
    ///
    /// Por la komuna ekvivalento vidu [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Vokante ĉi tiun metodon, vi devas certigi, ke ĉio el la sekvaj estas vera:
    ///
    /// * La montrilo devas esti ĝuste vicigita.
    ///
    /// * Ĝi devas esti "dereferencable" en la senco difinita en [the module documentation].
    ///
    /// * La montrilo devas montri al pravalorizita kazo de `T`.
    ///
    /// * Vi devas plenumi la kaŝnomajn regulojn de Rust, ĉar la redonita vivdaŭro `'a` estas arbitre elektita kaj ne nepre reflektas la realan vivdaŭron de la datumoj.
    ///
    ///   Aparte, dum la daŭro de ĉi tiu vivo, la memoro, kiun la montrilo montras, ne rajtas aliri (legi aŭ skribi) per iu ajn alia montrilo.
    ///
    /// Ĉi tio validas eĉ se la rezulto de ĉi tiu metodo estas neuzata!
    /// (La parto pri pravalorizado ankoraŭ ne estas plene decidita, sed ĝis ĝi fariĝos, la sola sekura aliro estas certigi, ke ili efektive estas pravalorizitaj.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SEKURECO: la alvokanto devas garantii, ke `self` plenumas ĉiujn
        // postuloj por ŝanĝebla referenco.
        unsafe { &mut *self.as_ptr() }
    }

    /// Castetas al montrilo de alia tipo.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SEKURECO: `self` estas montrilo `NonNull`, kiu estas nepre nenula
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Kreas nenulan krudan tranĉaĵon de maldika montrilo kaj longo.
    ///
    /// La argumento `len` estas la nombro de **elementoj**, ne la nombro de bajtoj.
    ///
    /// Ĉi tiu funkcio estas sekura, sed malreferenci la redonan valoron estas nesekura.
    /// Vidu la dokumentadon de [`slice::from_raw_parts`] por sekurecaj postuloj.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // kreu tranĉaĵan montrilon komencante per montrilo al la unua elemento
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Notu, ke ĉi tiu ekzemplo artefarite montras uzon de ĉi tiu metodo, sed `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SEKURECO: `data` estas montrilo `NonNull`, kiu estas nepre nenula
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Liveras la longon de ne-nula kruda tranĉaĵo.
    ///
    /// La redonita valoro estas la nombro de **elementoj**, ne la nombro de bajtoj.
    ///
    /// Ĉi tiu funkcio estas sekura, eĉ kiam la ne-nula kruda tranĉaĵo ne povas esti referencita al tranĉaĵo ĉar la montrilo ne havas validan adreson.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Redonas nenulan montrilon al la bufro de la tranĉaĵo.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SEKURECO: Ni scias, ke `self` estas nenula.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Redonas krudan montrilon al la bufro de la tranĉaĵo.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Liveras komunan referencon al tranĉaĵo de eble neinicialigitaj valoroj.Kontraste al [`as_ref`], ĉi tio ne postulas, ke la valoro devas esti pravalorizita.
    ///
    /// Por la ŝanĝebla ekvivalento vidu [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Vokante ĉi tiun metodon, vi devas certigi, ke ĉio el la sekvaj estas vera:
    ///
    /// * La montrilo devas esti [valid] por legoj por `ptr.len() * mem::size_of::<T>()` multaj bajtoj, kaj ĝi devas esti ĝuste vicigita.Ĉi tio signifas precipe:
    ///
    ///     * La tuta memora teritorio de ĉi tiu tranĉaĵo devas esti enhavita ene de unu asignita objekto!
    ///       Tranĉaĵoj neniam povas ampleksi multoblajn asignitajn objektojn.
    ///
    ///     * La montrilo devas esti vicigita eĉ por nul-longaj tranĉaĵoj.
    ///     Unu kialo por tio estas, ke enum-aranĝaj optimumigoj povas dependi de referencoj (inkluzive de tranĉaĵoj de iu ajn longo) vicigataj kaj nulaj por distingi ilin de aliaj datumoj.
    ///
    ///     Vi povas akiri montrilon uzeblan kiel `data` por nul-longaj tranĉaĵoj per [`NonNull::dangling()`].
    ///
    /// * La totala grandeco `ptr.len() * mem::size_of::<T>()` de la tranĉaĵo devas esti ne pli granda ol `isize::MAX`.
    ///   Vidu la sekurecan dokumentaron de [`pointer::offset`].
    ///
    /// * Vi devas plenumi la kaŝnomajn regulojn de Rust, ĉar la redonita vivdaŭro `'a` estas arbitre elektita kaj ne nepre reflektas la realan vivdaŭron de la datumoj.
    ///   Aparte, dum la daŭro de ĉi tiu vivo, la memoro, al kiu montras la montrilo, ne devas mutiĝi (krom ene de `UnsafeCell`).
    ///
    /// Ĉi tio validas eĉ se la rezulto de ĉi tiu metodo estas neuzata!
    ///
    /// Vidu ankaŭ [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Liveras unikan referencon al tranĉaĵo de eble neinicialigitaj valoroj.Kontraste al [`as_mut`], ĉi tio ne postulas, ke la valoro devas esti pravalorizita.
    ///
    /// Por la komuna ekvivalento vidu [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Vokante ĉi tiun metodon, vi devas certigi, ke ĉio el la sekvaj estas vera:
    ///
    /// * La montrilo devas esti [valid] por legoj kaj skriboj por `ptr.len() * mem::size_of::<T>()` multaj bajtoj, kaj ĝi devas esti ĝuste vicigita.Ĉi tio signifas precipe:
    ///
    ///     * La tuta memora teritorio de ĉi tiu tranĉaĵo devas esti enhavita ene de unu asignita objekto!
    ///       Tranĉaĵoj neniam povas ampleksi multoblajn asignitajn objektojn.
    ///
    ///     * La montrilo devas esti vicigita eĉ por nul-longaj tranĉaĵoj.
    ///     Unu kialo por tio estas, ke enum-aranĝaj optimumigoj povas dependi de referencoj (inkluzive de tranĉaĵoj de iu ajn longo) vicigataj kaj nulaj por distingi ilin de aliaj datumoj.
    ///
    ///     Vi povas akiri montrilon uzeblan kiel `data` por nul-longaj tranĉaĵoj per [`NonNull::dangling()`].
    ///
    /// * La totala grandeco `ptr.len() * mem::size_of::<T>()` de la tranĉaĵo devas esti ne pli granda ol `isize::MAX`.
    ///   Vidu la sekurecan dokumentaron de [`pointer::offset`].
    ///
    /// * Vi devas plenumi la kaŝnomajn regulojn de Rust, ĉar la redonita vivdaŭro `'a` estas arbitre elektita kaj ne nepre reflektas la realan vivdaŭron de la datumoj.
    ///   Aparte, dum la daŭro de ĉi tiu vivo, la memoro, kiun la montrilo montras, ne rajtas aliri (legi aŭ skribi) per iu ajn alia montrilo.
    ///
    /// Ĉi tio validas eĉ se la rezulto de ĉi tiu metodo estas neuzata!
    ///
    /// Vidu ankaŭ [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Ĉi tio estas sekura, ĉar `memory` validas por legadoj kaj skriboj por `memory.len()` multaj bajtoj.
    /// // Notu, ke voki `memory.as_mut()` ne estas permesita ĉi tie, ĉar la enhavo eble ne komenciĝas.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Liveras krudan montrilon al elemento aŭ subtranĉaĵo, sen fari kontrolon de limoj.
    ///
    /// Voki ĉi tiun metodon kun ekster-lima indekso aŭ kiam `self` ne estas nereferebla estas *[nedifinita konduto]* eĉ se la rezulta montrilo ne estas uzata.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SEKURECO: la alvokanto certigas, ke `self` estas nereferencebla kaj `index` en-limigita.
        // Sekve, la rezulta montrilo ne povas esti NULA.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SEKURECO: Unika montrilo ne povas esti nula, do la kondiĉoj por
        // new_unchecked() estas respektataj.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SEKURECO: ŝanĝebla referenco ne povas esti nula.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SEKURECO: Referenco ne povas esti nula, do la kondiĉoj por
        // new_unchecked() estas respektataj.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}