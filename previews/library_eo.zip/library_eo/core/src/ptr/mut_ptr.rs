use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Liveras `true` se la montrilo estas nula.
    ///
    /// Rimarku, ke nedimensiaj tipoj havas multajn eblajn nulajn montrilojn, ĉar nur la kruda datuma montrilo estas konsiderata, ne ilia longo, vtabelo, ktp.
    /// Sekve, du montriloj nulaj eble ankoraŭ ne komparas egale unu al la alia.
    ///
    /// ## Konduto dum konst-takso
    ///
    /// Kiam ĉi tiu funkcio estas uzata dum konst-taksado, ĝi eble redonos `false` por montriloj, kiuj rezultas esti nulaj dum rultempo.
    /// Specife, kiam montrilo al iu memoro estas kompensita preter siaj limoj tiel, ke la rezulta montrilo estas nula, la funkcio ankoraŭ redonos `false`.
    ///
    /// CTFE ne povas scii la absolutan pozicion de tiu memoro, do ni ne povas scii ĉu la montrilo estas nula aŭ ne.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Komparu per rolantaro al maldika montrilo, do dikaj montriloj nur konsideras sian "data"-parton por nuleco.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Castetas al montrilo de alia tipo.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Malkombinu (eble larĝan) montrilon en adresajn kaj metadatenajn erojn.
    ///
    /// La montrilo povas poste esti rekonstruita per [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Liveras `None` se la montrilo estas nula, aŭ alia redonas komunan referencon al la valoro envolvita en `Some`.Se la valoro eble ne komenciĝas, anstataŭe oni uzu [`as_uninit_ref`].
    ///
    /// Por la ŝanĝebla ekvivalento vidu [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Vokante ĉi tiun metodon, vi devas certigi, ke *aŭ* la montrilo estas NULA *aŭ* ĉiuj jenaj estas veraj:
    ///
    /// * La montrilo devas esti ĝuste vicigita.
    ///
    /// * Ĝi devas esti "dereferencable" en la senco difinita en [the module documentation].
    ///
    /// * La montrilo devas montri al pravalorizita kazo de `T`.
    ///
    /// * Vi devas plenumi la kaŝnomajn regulojn de Rust, ĉar la redonita vivdaŭro `'a` estas arbitre elektita kaj ne nepre reflektas la realan vivdaŭron de la datumoj.
    ///   Aparte, dum la daŭro de ĉi tiu vivo, la memoro, al kiu montras la montrilo, ne devas mutiĝi (krom ene de `UnsafeCell`).
    ///
    /// Ĉi tio validas eĉ se la rezulto de ĉi tiu metodo estas neuzata!
    /// (La parto pri pravalorizado ankoraŭ ne estas plene decidita, sed ĝis ĝi fariĝos, la sola sekura aliro estas certigi, ke ili efektive estas pravalorizitaj.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Nula senkontrola versio
    ///
    /// Se vi certas, ke la montrilo neniam povas esti nula kaj serĉas ian `as_ref_unchecked`, kiu redonas la `&T` anstataŭ `Option<&T>`, sciu, ke vi povas malreferenci la montrilon rekte.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SEKURECO: la alvokanto devas garantii, ke `self` validas por
        // referenco se ĝi ne estas nula.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Liveras `None` se la montrilo estas nula, aŭ alia redonas komunan referencon al la valoro envolvita en `Some`.
    /// Kontraste al [`as_ref`], ĉi tio ne postulas, ke la valoro devas esti pravalorizita.
    ///
    /// Por la ŝanĝebla ekvivalento vidu [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Vokante ĉi tiun metodon, vi devas certigi, ke *aŭ* la montrilo estas NULA *aŭ* ĉiuj jenaj estas veraj:
    ///
    /// * La montrilo devas esti ĝuste vicigita.
    ///
    /// * Ĝi devas esti "dereferencable" en la senco difinita en [the module documentation].
    ///
    /// * Vi devas plenumi la kaŝnomajn regulojn de Rust, ĉar la redonita vivdaŭro `'a` estas arbitre elektita kaj ne nepre reflektas la realan vivdaŭron de la datumoj.
    ///
    ///   Aparte, dum la daŭro de ĉi tiu vivo, la memoro, al kiu montras la montrilo, ne devas mutiĝi (krom ene de `UnsafeCell`).
    ///
    /// Ĉi tio validas eĉ se la rezulto de ĉi tiu metodo estas neuzata!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas garantii, ke `self` plenumas ĉiujn
        // postuloj por referenco.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Kalkulas la ofseton de montrilo.
    ///
    /// `count` estas en unuoj de T;ekz. `count` de 3 reprezentas montrilan ofseton de `3 * size_of::<T>()`-bitokoj.
    ///
    /// # Safety
    ///
    /// Se iu el la jenaj kondiĉoj estas malobservita, la rezulto estas Nedifinita Konduto:
    ///
    /// * Kaj la komenca kaj rezulta montrilo devas esti aŭ en limoj aŭ unu bajto preter la fino de la sama asignita objekto.
    /// Notu, ke en Rust, ĉiu (stack-allocated)-variablo estas konsiderata aparta asignita objekto.
    ///
    /// * La komputita ofseto,**en bajtoj**, ne povas superflui `isize`.
    ///
    /// * La ofseto en limoj ne povas fidi je "wrapping around" la adresspaco.Tio estas, la senfina-preciza sumo,**en bitokoj**, devas kongrui kun uzokutimo.
    ///
    /// La kompililo kaj norma biblioteko ĝenerale provas certigi, ke asignoj neniam atingas grandecon, kie ofseto zorgas.
    /// Ekzemple, `Vec` kaj `Box` certigas, ke ili neniam asignas pli ol `isize::MAX`-bitokojn, do `vec.as_ptr().add(vec.len())` ĉiam estas sekura.
    ///
    /// Plej multaj platformoj principe eĉ ne povas konstrui tian asignon.
    /// Ekzemple, neniu konata 64-bita platformo iam povas servi peton por 2 <sup>63</sup> bajtoj pro paĝtablaj limigoj aŭ dividado de la adresspaco.
    /// Tamen iuj 32-bitaj kaj 16-bitaj platformoj povas sukcese servi peton por pli ol `isize::MAX`-bitokoj kun aferoj kiel Fizika Adresa Etendaĵo.
    ///
    /// Kiel tia, memoro akirita rekte de atribuiloj aŭ memoraj mapitaj dosieroj *eble* estas tro granda por pritrakti ĉi tiun funkcion.
    ///
    /// Pripensu uzi anstataŭe [`wrapping_offset`] se ĉi tiuj limoj malfacilas kontentigi.
    /// La sola avantaĝo de ĉi tiu metodo estas, ke ĝi ebligas pli agresemajn tradukilojn.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `offset`.
        // La akirita montrilo validas por skriboj ĉar la alvokanto devas garantii ke ĝi montras al la sama asignita objekto kiel `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Kalkulas la ofseton de montrilo per envolva aritmetiko.
    /// `count` estas en unuoj de T;ekz. `count` de 3 reprezentas montrilan ofseton de `3 * size_of::<T>()`-bitokoj.
    ///
    /// # Safety
    ///
    /// Ĉi tiu operacio mem ĉiam estas sekura, sed uzi la rezultan montrilon ne estas.
    ///
    /// La rezulta montrilo restas ligita al la sama asignita objekto, al kiu montras `self`.
    /// Ĝi *ne* povas esti uzata por aliri alian asignitan objekton.Notu, ke en Rust, ĉiu (stack-allocated)-variablo estas konsiderata aparta asignita objekto.
    ///
    /// Alivorte, `let z = x.wrapping_offset((y as isize) - (x as isize))`*ne* igas `z` same kiel `y` eĉ se ni supozas, ke `T` havas grandecon `1` kaj ne ekzistas superfluaĵo: `z` ankoraŭ estas ligita al la objekto al kiu `x` estas ligita, kaj malreferencado ĝi estas Nedifinita Konduto krom se `x` kaj `y`-punkto en la saman asignitan objekton.
    ///
    /// Kompare kun [`offset`], ĉi tiu metodo esence prokrastas la postulon resti ene de la sama asignita objekto: [`offset`] estas tuja Nedifinita Konduto dum transiro de objektaj limoj;`wrapping_offset` produktas montrilon sed tamen kondukas al Nedifinita Konduto se montrilo malreferenciĝas kiam ĝi estas ekster la limoj de la objekto al kiu ĝi estas ligita.
    /// [`offset`] povas esti pli bone optimumigita kaj estas tiel preferinda en rendimento-sentema kodo.
    ///
    /// La malfrua ĉeko nur konsideras la valoron de la montrilo, kiu estis malreferencita, ne la interajn valorojn uzitajn dum la komputado de la fina rezulto.
    /// Ekzemple, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` estas ĉiam la sama kiel `x`.Alivorte, lasi la asignitan objekton kaj poste reeniri ĝin poste estas permesita.
    ///
    /// Se vi bezonas transiri objektajn limojn, ĵetu la montrilon al entjero kaj faru la aritmetikon tie.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // Ripetu uzante krudan montrilon per pliigoj de du elementoj
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SEKURECO: la interna `arith_offset` ne havas antaŭkondiĉojn por esti vokita.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Liveras `None` se la montrilo estas nula, aŭ alia redonas unikan referencon al la valoro envolvita en `Some`.Se la valoro eble ne komenciĝas, anstataŭe oni uzu [`as_uninit_mut`].
    ///
    /// Por la komuna ekvivalento vidu [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Vokante ĉi tiun metodon, vi devas certigi, ke *aŭ* la montrilo estas NULA *aŭ* ĉiuj jenaj estas veraj:
    ///
    /// * La montrilo devas esti ĝuste vicigita.
    ///
    /// * Ĝi devas esti "dereferencable" en la senco difinita en [the module documentation].
    ///
    /// * La montrilo devas montri al pravalorizita kazo de `T`.
    ///
    /// * Vi devas plenumi la kaŝnomajn regulojn de Rust, ĉar la redonita vivdaŭro `'a` estas arbitre elektita kaj ne nepre reflektas la realan vivdaŭron de la datumoj.
    ///   Aparte, dum la daŭro de ĉi tiu vivo, la memoro, kiun la montrilo montras, ne rajtas aliri (legi aŭ skribi) per iu ajn alia montrilo.
    ///
    /// Ĉi tio validas eĉ se la rezulto de ĉi tiu metodo estas neuzata!
    /// (La parto pri pravalorizado ankoraŭ ne estas plene decidita, sed ĝis ĝi fariĝos, la sola sekura aliro estas certigi, ke ili efektive estas pravalorizitaj.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Ĝi presos: "[4, 2, 3]".
    /// ```
    ///
    /// # Nula senkontrola versio
    ///
    /// Se vi certas, ke la montrilo neniam povas esti nula kaj serĉas ian `as_mut_unchecked`, kiu redonas la `&mut T` anstataŭ `Option<&mut T>`, sciu, ke vi povas malreferenci la montrilon rekte.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Ĝi presos: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // SEKURECO: la alvokanto devas garantii, ke `self` validas por
        // ŝanĝebla referenco se ĝi ne estas nula.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Liveras `None` se la montrilo estas nula, aŭ alia redonas unikan referencon al la valoro envolvita en `Some`.
    /// Kontraste al [`as_mut`], ĉi tio ne postulas, ke la valoro devas esti pravalorizita.
    ///
    /// Por la komuna ekvivalento vidu [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Vokante ĉi tiun metodon, vi devas certigi, ke *aŭ* la montrilo estas NULA *aŭ* ĉiuj jenaj estas veraj:
    ///
    /// * La montrilo devas esti ĝuste vicigita.
    ///
    /// * Ĝi devas esti "dereferencable" en la senco difinita en [the module documentation].
    ///
    /// * Vi devas plenumi la kaŝnomajn regulojn de Rust, ĉar la redonita vivdaŭro `'a` estas arbitre elektita kaj ne nepre reflektas la realan vivdaŭron de la datumoj.
    ///
    ///   Aparte, dum la daŭro de ĉi tiu vivo, la memoro, kiun la montrilo montras, ne rajtas aliri (legi aŭ skribi) per iu ajn alia montrilo.
    ///
    /// Ĉi tio validas eĉ se la rezulto de ĉi tiu metodo estas neuzata!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas garantii, ke `self` plenumas ĉiujn
        // postuloj por referenco.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Liveras, ĉu du montriloj certas esti egalaj.
    ///
    /// Dum rultempo ĉi tiu funkcio kondutas kiel `self == other`.
    /// Tamen, en iuj kuntekstoj (ekz. Kompilotempa pritakso), ne ĉiam eblas determini egalecon de du montriloj, do ĉi tiu funkcio eble malĝuste redonos `false` por montriloj, kiuj poste efektive egalas.
    ///
    /// Sed kiam ĝi redonas `true`, la montriloj certas esti egalaj.
    ///
    /// Ĉi tiu funkcio estas la spegulo de [`guaranteed_ne`], sed ne ĝia inversa.Estas montriloj, por kiuj ambaŭ funkcioj redonas `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// La revenvaloro povas ŝanĝiĝi depende de la versio de la kompililo kaj nesekura kodo eble ne dependas de la rezulto de ĉi tiu funkcio por solideco.
    /// Oni sugestas uzi ĉi tiun funkcion nur por plibonigoj de rendimento, kiam falsaj `false` redonas valorojn per ĉi tiu funkcio ne influas la rezulton, sed nur la agadon.
    /// La konsekvencoj de uzado de ĉi tiu metodo por igi rultempan kaj kompiltempan kodon konduti malsame ne estis esploritaj.
    /// Ĉi tiu metodo ne estu uzata por enkonduki tiajn diferencojn, kaj ĝi ankaŭ ne estu stabiligita antaŭ ol ni pli bone komprenos ĉi tiun aferon.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Liveras ĉu du montriloj estas neegalaj.
    ///
    /// Dum rultempo ĉi tiu funkcio kondutas kiel `self != other`.
    /// Tamen, en iuj kuntekstoj (ekz. Kompilotempa taksado), ne ĉiam eblas determini la malegalecon de du montriloj, do ĉi tiu funkcio eble malĝuste redonos `false` por montriloj, kiuj poste efektive malegalas.
    ///
    /// Sed kiam ĝi redonas `true`, la montriloj estas neegalaj.
    ///
    /// Ĉi tiu funkcio estas la spegulo de [`guaranteed_eq`], sed ne ĝia inversa.Estas montriloj, por kiuj ambaŭ funkcioj redonas `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// La revenvaloro povas ŝanĝiĝi depende de la versio de la kompililo kaj nesekura kodo eble ne dependas de la rezulto de ĉi tiu funkcio por solideco.
    /// Oni sugestas uzi ĉi tiun funkcion nur por plibonigoj de rendimento, kiam falsaj `false` redonas valorojn per ĉi tiu funkcio ne influas la rezulton, sed nur la agadon.
    /// La konsekvencoj de uzado de ĉi tiu metodo por igi rultempan kaj kompiltempan kodon konduti malsame ne estis esploritaj.
    /// Ĉi tiu metodo ne estu uzata por enkonduki tiajn diferencojn, kaj ĝi ankaŭ ne estu stabiligita antaŭ ol ni pli bone komprenos ĉi tiun aferon.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Kalkulas la distancon inter du montriloj.La redonita valoro estas en unuoj de T: la distanco en bajtoj estas dividita per `mem::size_of::<T>()`.
    ///
    /// Ĉi tiu funkcio estas la inverso de [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Se iu el la jenaj kondiĉoj estas malobservita, la rezulto estas Nedifinita Konduto:
    ///
    /// * Kaj la komenca kaj alia montrilo devas esti aŭ limigitaj aŭ unu bajto preter la fino de la sama asignita objekto.
    /// Notu, ke en Rust, ĉiu (stack-allocated)-variablo estas konsiderata aparta asignita objekto.
    ///
    /// * Ambaŭ montriloj devas esti *derivitaj de* montrilo al la sama objekto.
    ///   (Vidu sube por ekzemplo.)
    ///
    /// * La distanco inter la montriloj, en bajtoj, devas esti ĝusta oblo de la grandeco de `T`.
    ///
    /// * La distanco inter la montriloj,**en bajtoj**, ne povas superverŝi `isize`.
    ///
    /// * La distanco inter limoj ne povas dependi de "wrapping around" la adresspaco.
    ///
    /// Rust-specoj neniam estas pli grandaj ol `isize::MAX` kaj Rust-atribuoj neniam ĉirkaŭas la adresan spacon, do du montriloj ene de iu valoro de iu Rust-tipo `T` ĉiam kontentigos la lastajn du kondiĉojn.
    ///
    /// La norma biblioteko ankaŭ ĝenerale certigas, ke atribuoj neniam atingas grandecon, kie kompenso zorgas.
    /// Ekzemple, `Vec` kaj `Box` certigas, ke ili neniam asignas pli ol `isize::MAX`-bitokojn, do `ptr_into_vec.offset_from(vec.as_ptr())` ĉiam plenumas la lastajn du kondiĉojn.
    ///
    /// Plej multaj platformoj principe eĉ ne povas konstrui tiel grandan asignon.
    /// Ekzemple, neniu konata 64-bita platformo iam povas servi peton por 2 <sup>63</sup> bajtoj pro paĝtablaj limigoj aŭ dividado de la adresspaco.
    /// Tamen iuj 32-bitaj kaj 16-bitaj platformoj povas sukcese servi peton por pli ol `isize::MAX`-bitokoj kun aferoj kiel Fizika Adresa Etendaĵo.
    /// Kiel tia, memoro akirita rekte de atribuiloj aŭ memoraj mapitaj dosieroj *eble* estas tro granda por pritrakti ĉi tiun funkcion.
    /// (Notu, ke [`offset`] kaj [`add`] ankaŭ havas similan limon kaj do ankaŭ ne povas esti uzataj ĉe tiom grandaj asignoj.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio panics se `T` estas Nulgranda Tipo ("ZST").
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Malĝusta* uzado:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Faru ptr2_ alia "alias" de ptr2, sed derivita de ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Ĉar ptr2_other kaj ptr2 devenas de montriloj al malsamaj objektoj, komputi ilian ofseton estas nedifinita konduto, kvankam ili montras al la sama adreso!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Nedifinita Konduto
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Kalkulas la ofseton de montrilo (komforto por `.offset(count as isize)`).
    ///
    /// `count` estas en unuoj de T;ekz. `count` de 3 reprezentas montrilan ofseton de `3 * size_of::<T>()`-bitokoj.
    ///
    /// # Safety
    ///
    /// Se iu el la jenaj kondiĉoj estas malobservita, la rezulto estas Nedifinita Konduto:
    ///
    /// * Kaj la komenca kaj rezulta montrilo devas esti aŭ en limoj aŭ unu bajto preter la fino de la sama asignita objekto.
    /// Notu, ke en Rust, ĉiu (stack-allocated)-variablo estas konsiderata aparta asignita objekto.
    ///
    /// * La komputita ofseto,**en bajtoj**, ne povas superflui `isize`.
    ///
    /// * La ofseto en limoj ne povas fidi je "wrapping around" la adresspaco.Tio estas, la senfina precizeca sumo devas kongrui en `usize`.
    ///
    /// La kompililo kaj norma biblioteko ĝenerale provas certigi, ke asignoj neniam atingas grandecon, kie ofseto zorgas.
    /// Ekzemple, `Vec` kaj `Box` certigas, ke ili neniam asignas pli ol `isize::MAX`-bitokojn, do `vec.as_ptr().add(vec.len())` ĉiam estas sekura.
    ///
    /// Plej multaj platformoj principe eĉ ne povas konstrui tian asignon.
    /// Ekzemple, neniu konata 64-bita platformo iam povas servi peton por 2 <sup>63</sup> bajtoj pro paĝtablaj limigoj aŭ dividado de la adresspaco.
    /// Tamen iuj 32-bitaj kaj 16-bitaj platformoj povas sukcese servi peton por pli ol `isize::MAX`-bitokoj kun aferoj kiel Fizika Adresa Etendaĵo.
    ///
    /// Kiel tia, memoro akirita rekte de atribuiloj aŭ memoraj mapitaj dosieroj *eble* estas tro granda por pritrakti ĉi tiun funkcion.
    ///
    /// Konsideru uzi [`wrapping_add`] anstataŭe se ĉi tiuj limoj malfacilas kontentigi.
    /// La sola avantaĝo de ĉi tiu metodo estas, ke ĝi ebligas pli agresemajn tradukilojn.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Kalkulas la ofseton de montrilo (komforto por `.offset ((kalkulu kiel isize).wrapping_neg())`).
    ///
    /// `count` estas en unuoj de T;ekz. `count` de 3 reprezentas montrilan ofseton de `3 * size_of::<T>()`-bitokoj.
    ///
    /// # Safety
    ///
    /// Se iu el la jenaj kondiĉoj estas malobservita, la rezulto estas Nedifinita Konduto:
    ///
    /// * Kaj la komenca kaj rezulta montrilo devas esti aŭ en limoj aŭ unu bajto preter la fino de la sama asignita objekto.
    /// Notu, ke en Rust, ĉiu (stack-allocated)-variablo estas konsiderata aparta asignita objekto.
    ///
    /// * La komputita ofseto ne povas superi `isize::MAX`**bajtojn**.
    ///
    /// * La ofseto en limoj ne povas fidi je "wrapping around" la adresspaco.Tio estas, la senfina precizeca sumo devas kongrui kun uzokutimo.
    ///
    /// La kompililo kaj norma biblioteko ĝenerale provas certigi, ke asignoj neniam atingas grandecon, kie ofseto zorgas.
    /// Ekzemple, `Vec` kaj `Box` certigas, ke ili neniam asignas pli ol `isize::MAX`-bitokojn, do `vec.as_ptr().add(vec.len()).sub(vec.len())` ĉiam estas sekura.
    ///
    /// Plej multaj platformoj principe eĉ ne povas konstrui tian asignon.
    /// Ekzemple, neniu konata 64-bita platformo iam povas servi peton por 2 <sup>63</sup> bajtoj pro paĝtablaj limigoj aŭ dividado de la adresspaco.
    /// Tamen iuj 32-bitaj kaj 16-bitaj platformoj povas sukcese servi peton por pli ol `isize::MAX`-bitokoj kun aferoj kiel Fizika Adresa Etendaĵo.
    ///
    /// Kiel tia, memoro akirita rekte de atribuiloj aŭ memoraj mapitaj dosieroj *eble* estas tro granda por pritrakti ĉi tiun funkcion.
    ///
    /// Pripensu uzi anstataŭe [`wrapping_sub`] se ĉi tiuj limoj malfacilas kontentigi.
    /// La sola avantaĝo de ĉi tiu metodo estas, ke ĝi ebligas pli agresemajn tradukilojn.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Kalkulas la ofseton de montrilo per envolva aritmetiko.
    /// (oportuno por `.wrapping_offset(count as isize)`)
    ///
    /// `count` estas en unuoj de T;ekz. `count` de 3 reprezentas montrilan ofseton de `3 * size_of::<T>()`-bitokoj.
    ///
    /// # Safety
    ///
    /// Ĉi tiu operacio mem ĉiam estas sekura, sed uzi la rezultan montrilon ne estas.
    ///
    /// La rezulta montrilo restas ligita al la sama asignita objekto, al kiu montras `self`.
    /// Ĝi *ne* povas esti uzata por aliri alian asignitan objekton.Notu, ke en Rust, ĉiu (stack-allocated)-variablo estas konsiderata aparta asignita objekto.
    ///
    /// Alivorte, `let z = x.wrapping_add((y as usize) - (x as usize))`*ne* igas `z` same kiel `y` eĉ se ni supozas, ke `T` havas grandecon `1` kaj ne ekzistas superfluaĵo: `z` ankoraŭ estas ligita al la objekto al kiu `x` estas ligita, kaj malreferencado ĝi estas Nedifinita Konduto krom se `x` kaj `y`-punkto en la saman asignitan objekton.
    ///
    /// Kompare kun [`add`], ĉi tiu metodo esence prokrastas la postulon resti ene de la sama asignita objekto: [`add`] estas tuja Nedifinita Konduto dum transiro de objektaj limoj;`wrapping_add` produktas montrilon sed tamen kondukas al Nedifinita Konduto se montrilo malreferenciĝas kiam ĝi estas ekster la limoj de la objekto al kiu ĝi estas ligita.
    /// [`add`] povas esti pli bone optimumigita kaj estas tiel preferinda en rendimento-sentema kodo.
    ///
    /// La malfrua ĉeko nur konsideras la valoron de la montrilo, kiu estis malreferencita, ne la interajn valorojn uzitajn dum la komputado de la fina rezulto.
    /// Ekzemple, `x.wrapping_add(o).wrapping_sub(o)` estas ĉiam la sama kiel `x`.Alivorte, lasi la asignitan objekton kaj poste reeniri ĝin poste estas permesita.
    ///
    /// Se vi bezonas transiri objektajn limojn, ĵetu la montrilon al entjero kaj faru la aritmetikon tie.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // Ripetu uzante krudan montrilon per pliigoj de du elementoj
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Ĉi tiu buklo presas "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Kalkulas la ofseton de montrilo per envolva aritmetiko.
    /// (komforto por `.wrapping_offset ((kalkulu kiel isize).wrapping_neg())`)
    ///
    /// `count` estas en unuoj de T;ekz. `count` de 3 reprezentas montrilan ofseton de `3 * size_of::<T>()`-bitokoj.
    ///
    /// # Safety
    ///
    /// Ĉi tiu operacio mem ĉiam estas sekura, sed uzi la rezultan montrilon ne estas.
    ///
    /// La rezulta montrilo restas ligita al la sama asignita objekto, al kiu montras `self`.
    /// Ĝi *ne* povas esti uzata por aliri alian asignitan objekton.Notu, ke en Rust, ĉiu (stack-allocated)-variablo estas konsiderata aparta asignita objekto.
    ///
    /// Alivorte, `let z = x.wrapping_sub((x as usize) - (y as usize))`*ne* igas `z` same kiel `y` eĉ se ni supozas, ke `T` havas grandecon `1` kaj ne ekzistas superfluaĵo: `z` ankoraŭ estas ligita al la objekto al kiu `x` estas ligita, kaj malreferencado ĝi estas Nedifinita Konduto krom se `x` kaj `y`-punkto en la saman asignitan objekton.
    ///
    /// Kompare kun [`sub`], ĉi tiu metodo esence prokrastas la postulon resti ene de la sama asignita objekto: [`sub`] estas tuja Nedifinita Konduto dum transiro de objektaj limoj;`wrapping_sub` produktas montrilon sed tamen kondukas al Nedifinita Konduto se montrilo malreferenciĝas kiam ĝi estas ekster la limoj de la objekto al kiu ĝi estas ligita.
    /// [`sub`] povas esti pli bone optimumigita kaj estas tiel preferinda en rendimento-sentema kodo.
    ///
    /// La malfrua ĉeko nur konsideras la valoron de la montrilo, kiu estis malreferencita, ne la interajn valorojn uzitajn dum la komputado de la fina rezulto.
    /// Ekzemple, `x.wrapping_add(o).wrapping_sub(o)` estas ĉiam la sama kiel `x`.Alivorte, lasi la asignitan objekton kaj poste reeniri ĝin poste estas permesita.
    ///
    /// Se vi bezonas transiri objektajn limojn, ĵetu la montrilon al entjero kaj faru la aritmetikon tie.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // Ripetu uzante krudan montrilon per pliigoj de du elementoj (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Ĉi tiu buklo presas "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Agordas la montrilan valoron al `ptr`.
    ///
    /// Se `self` estas (fat)-montrilo al malgrandigita tipo, ĉi tiu operacio nur influos la montrilan parton, dum por (thin)-montriloj al grandaj specoj, ĉi tio efikas kiel simpla tasko.
    ///
    /// La rezulta montrilo havos devenon de `val`, te por dika montrilo, ĉi tiu operacio estas semantike la sama kiel krei novan grasan montrilon kun la datuma montrila valoro de `val` sed la metadatenoj de `self`.
    ///
    ///
    /// # Examples
    ///
    /// Ĉi tiu funkcio estas ĉefe utila por permesi bajt-punktan montrilan aritmetikon sur eble grasaj montriloj:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // presos "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // SEKURECO: En kazo de maldika montrilo, ĉi tiuj operacioj estas identaj
        // al simpla tasko.
        // Kaze de grasa montrilo, kun la aktuala enpaĝiga enpaĝiga enpaĝigo, la unua kampo de tia montrilo ĉiam estas la datuma montrilo, kiu same estas atribuita.
        //
        unsafe { *thin = val };
        self
    }

    /// Legas la valoron de `self` sen movi ĝin.
    /// Ĉi tio lasas la memoron en `self` senŝanĝa.
    ///
    /// Vidu [`ptr::read`] por sekurecaj zorgoj kaj ekzemploj.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por ``.
        unsafe { read(self) }
    }

    /// Prezentas volatilan legadon de la valoro de `self` sen movi ĝin.Ĉi tio lasas la memoron en `self` senŝanĝa.
    ///
    /// Volatilaj operacioj celas agi sur I/O-memoro, kaj estas garantiitaj ne esti eliziitaj aŭ reordigitaj de la kompililo tra aliaj volatilaj operacioj.
    ///
    ///
    /// Vidu [`ptr::read_volatile`] por sekurecaj zorgoj kaj ekzemploj.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Legas la valoron de `self` sen movi ĝin.
    /// Ĉi tio lasas la memoron en `self` senŝanĝa.
    ///
    /// Male al `read`, la montrilo povas esti senalinia.
    ///
    /// Vidu [`ptr::read_unaligned`] por sekurecaj zorgoj kaj ekzemploj.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kopias `count * size_of<T>`-bitokojn de `self` al `dest`.
    /// La fonto kaj celloko eble interkovras.
    ///
    /// NOTE: ĉi tio havas la *saman* argumentordon kiel [`ptr::copy`].
    ///
    /// Vidu [`ptr::copy`] por sekurecaj zorgoj kaj ekzemploj.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kopias `count * size_of<T>`-bitokojn de `self` al `dest`.
    /// La fonto kaj celloko eble *ne* interkovras.
    ///
    /// NOTE: ĉi tio havas la *saman* argumentordon kiel [`ptr::copy_nonoverlapping`].
    ///
    /// Vidu [`ptr::copy_nonoverlapping`] por sekurecaj zorgoj kaj ekzemploj.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kopias `count * size_of<T>`-bitokojn de `src` al `self`.
    /// La fonto kaj celloko eble interkovras.
    ///
    /// NOTE: ĉi tio havas la argumenton *kontraŭa* de [`ptr::copy`].
    ///
    /// Vidu [`ptr::copy`] por sekurecaj zorgoj kaj ekzemploj.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Kopias `count * size_of<T>`-bitokojn de `src` al `self`.
    /// La fonto kaj celloko eble *ne* interkovras.
    ///
    /// NOTE: ĉi tio havas la argumenton *kontraŭa* de [`ptr::copy_nonoverlapping`].
    ///
    /// Vidu [`ptr::copy_nonoverlapping`] por sekurecaj zorgoj kaj ekzemploj.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Ekzekutas la detruanton (se ekzistas) de la indikita valoro.
    ///
    /// Vidu [`ptr::drop_in_place`] por sekurecaj zorgoj kaj ekzemploj.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Anstataŭigas memorlokon kun la donita valoro sen legi aŭ faligi la malnovan valoron.
    ///
    ///
    /// Vidu [`ptr::write`] por sekurecaj zorgoj kaj ekzemploj.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `write`.
        unsafe { write(self, val) }
    }

    /// Vokas memset sur la specifa montrilo, agordante `count * size_of::<T>()`-bitokojn da memoro ekde `self` al `val`.
    ///
    ///
    /// Vidu [`ptr::write_bytes`] por sekurecaj zorgoj kaj ekzemploj.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Elfaras volatilan skribon de memora loko kun la donita valoro sen legi aŭ faligi la malnovan valoron.
    ///
    /// Volatilaj operacioj celas agi sur I/O-memoro, kaj estas garantiitaj ne esti eliziitaj aŭ reordigitaj de la kompililo tra aliaj volatilaj operacioj.
    ///
    ///
    /// Vidu [`ptr::write_volatile`] por sekurecaj zorgoj kaj ekzemploj.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Anstataŭigas memorlokon kun la donita valoro sen legi aŭ faligi la malnovan valoron.
    ///
    ///
    /// Male al `write`, la montrilo povas esti senalinia.
    ///
    /// Vidu [`ptr::write_unaligned`] por sekurecaj zorgoj kaj ekzemploj.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Anstataŭigas la valoron ĉe `self` per `src`, redonante la malnovan valoron, sen faligi ambaŭ.
    ///
    ///
    /// Vidu [`ptr::replace`] por sekurecaj zorgoj kaj ekzemploj.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `replace`.
        unsafe { replace(self, src) }
    }

    /// Interŝanĝas la valorojn ĉe du ŝanĝeblaj samspecaj lokoj, sen ankaŭ seninicialigi.
    /// Ili eble interkovras, male al `mem::swap`, kiu alimaniere samvaloras.
    ///
    /// Vidu [`ptr::swap`] por sekurecaj zorgoj kaj ekzemploj.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `swap`.
        unsafe { swap(self, with) }
    }

    /// Kalkulas la ofseton, kiu devas esti aplikita al la montrilo por fari ĝin vicigita al `align`.
    ///
    /// Se ne eblas vicigi la montrilon, la efektivigo redonas `usize::MAX`.
    /// Estas permesate, ke la efektivigo *ĉiam* redonu `usize::MAX`.
    /// Nur la agado de via algoritmo povas dependi de akirado de uzebla ofseto ĉi tie, ne de ĝia ĝusteco.
    ///
    /// La ofseto estas esprimita per nombro da `T`-elementoj, kaj ne per bajtoj.La resendita valoro povas esti uzata kun la metodo `wrapping_add`.
    ///
    /// Estas neniuj garantioj, ke kompensado de la montrilo ne superfluos aŭ preterpasos la atribuon, kiun la montrilo montras.
    ///
    /// Ĝi dependas de la alvokanto certigi, ke la redonita ofseto estas ĝusta en ĉiuj terminoj krom vicigo.
    ///
    /// # Panics
    ///
    /// La funkcio panics se `align` ne estas potenco de du.
    ///
    /// # Examples
    ///
    /// Alirante apud `u8` kiel `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // dum la montrilo povas esti vicigita per `offset`, ĝi montrus ekster la asigno
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SEKURECO: `align` estas kontrolita por esti potenco de 2 supre
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Liveras la longon de kruda tranĉaĵo.
    ///
    /// La redonita valoro estas la nombro de **elementoj**, ne la nombro de bajtoj.
    ///
    /// Ĉi tiu funkcio estas sekura, eĉ kiam la kruda tranĉaĵo ne povas esti ĵetita al tranĉa referenco ĉar la montrilo estas nula aŭ senalinea.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SEKURECO: ĉi tio estas sekura ĉar `*const [T]` kaj `FatPtr<T>` havas la saman aranĝon.
            // Nur `std` povas doni ĉi tiun garantion.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Redonas krudan montrilon al la bufro de la tranĉaĵo.
    ///
    /// Ĉi tio ekvivalentas al ĵetado de `self` al `*mut T`, sed pli tajpa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Liveras krudan montrilon al elemento aŭ subtranĉaĵo, sen fari kontrolon de limoj.
    ///
    /// Voki ĉi tiun metodon kun ekster-lima indekso aŭ kiam `self` ne estas nereferebla estas *[nedifinita konduto]* eĉ se la rezulta montrilo ne estas uzata.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SEKURECO: la alvokanto certigas, ke `self` estas nereferencebla kaj `index` en-limigita.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Liveras `None` se la montrilo estas nula, aŭ alia redonas dividitan tranĉaĵon al la valoro envolvita en `Some`.
    /// Kontraste al [`as_ref`], ĉi tio ne postulas, ke la valoro devas esti pravalorizita.
    ///
    /// Por la ŝanĝebla ekvivalento vidu [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Vokante ĉi tiun metodon, vi devas certigi, ke *aŭ* la montrilo estas NULA *aŭ* ĉiuj jenaj estas veraj:
    ///
    /// * La montrilo devas esti [valid] por legoj por `ptr.len() * mem::size_of::<T>()` multaj bajtoj, kaj ĝi devas esti ĝuste vicigita.Ĉi tio signifas precipe:
    ///
    ///     * La tuta memora teritorio de ĉi tiu tranĉaĵo devas esti enhavita ene de unu asignita objekto!
    ///       Tranĉaĵoj neniam povas ampleksi multoblajn asignitajn objektojn.
    ///
    ///     * La montrilo devas esti vicigita eĉ por nul-longaj tranĉaĵoj.
    ///     Unu kialo por tio estas, ke enum-aranĝaj optimumigoj povas dependi de referencoj (inkluzive de tranĉaĵoj de iu ajn longo) vicigataj kaj nulaj por distingi ilin de aliaj datumoj.
    ///
    ///     Vi povas akiri montrilon uzeblan kiel `data` por nul-longaj tranĉaĵoj per [`NonNull::dangling()`].
    ///
    /// * La totala grandeco `ptr.len() * mem::size_of::<T>()` de la tranĉaĵo devas esti ne pli granda ol `isize::MAX`.
    ///   Vidu la sekurecan dokumentaron de [`pointer::offset`].
    ///
    /// * Vi devas plenumi la kaŝnomajn regulojn de Rust, ĉar la redonita vivdaŭro `'a` estas arbitre elektita kaj ne nepre reflektas la realan vivdaŭron de la datumoj.
    ///   Aparte, dum la daŭro de ĉi tiu vivo, la memoro, al kiu montras la montrilo, ne devas mutiĝi (krom ene de `UnsafeCell`).
    ///
    /// Ĉi tio validas eĉ se la rezulto de ĉi tiu metodo estas neuzata!
    ///
    /// Vidu ankaŭ [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Liveras `None` se la montrilo estas nula, aŭ alie redonas unikan tranĉaĵon al la valoro envolvita en `Some`.
    /// Kontraste al [`as_mut`], ĉi tio ne postulas, ke la valoro devas esti pravalorizita.
    ///
    /// Por la komuna ekvivalento vidu [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Vokante ĉi tiun metodon, vi devas certigi, ke *aŭ* la montrilo estas NULA *aŭ* ĉiuj jenaj estas veraj:
    ///
    /// * La montrilo devas esti [valid] por legoj kaj skriboj por `ptr.len() * mem::size_of::<T>()` multaj bajtoj, kaj ĝi devas esti ĝuste vicigita.Ĉi tio signifas precipe:
    ///
    ///     * La tuta memora teritorio de ĉi tiu tranĉaĵo devas esti enhavita ene de unu asignita objekto!
    ///       Tranĉaĵoj neniam povas ampleksi multoblajn asignitajn objektojn.
    ///
    ///     * La montrilo devas esti vicigita eĉ por nul-longaj tranĉaĵoj.
    ///     Unu kialo por tio estas, ke enum-aranĝaj optimumigoj povas dependi de referencoj (inkluzive de tranĉaĵoj de iu ajn longo) vicigataj kaj nulaj por distingi ilin de aliaj datumoj.
    ///
    ///     Vi povas akiri montrilon uzeblan kiel `data` por nul-longaj tranĉaĵoj per [`NonNull::dangling()`].
    ///
    /// * La totala grandeco `ptr.len() * mem::size_of::<T>()` de la tranĉaĵo devas esti ne pli granda ol `isize::MAX`.
    ///   Vidu la sekurecan dokumentaron de [`pointer::offset`].
    ///
    /// * Vi devas plenumi la kaŝnomajn regulojn de Rust, ĉar la redonita vivdaŭro `'a` estas arbitre elektita kaj ne nepre reflektas la realan vivdaŭron de la datumoj.
    ///   Aparte, dum la daŭro de ĉi tiu vivo, la memoro, kiun la montrilo montras, ne rajtas aliri (legi aŭ skribi) per iu ajn alia montrilo.
    ///
    /// Ĉi tio validas eĉ se la rezulto de ĉi tiu metodo estas neuzata!
    ///
    /// Vidu ankaŭ [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SEKURECO: la alvokanto devas konfirmi la sekurecan kontrakton por `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Egaleco por montriloj
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}