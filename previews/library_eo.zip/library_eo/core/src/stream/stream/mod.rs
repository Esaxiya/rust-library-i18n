use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Interfaco por trakti nesinkronajn ripetilojn.
///
/// Ĉi tiu estas la ĉefa rivereto trait.
/// Por pli pri la koncepto de riveretoj ĝenerale, bonvolu vidi la [module-level documentation].
/// Precipe vi eble volas scii kiel [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// La speco de eroj donitaj de la rivereto.
    type Item;

    /// Provu eltiri la sekvan valoron de ĉi tiu rivereto, registrante la aktualan taskon por veki se la valoro ankoraŭ ne haveblas, kaj redonas `None` se la rivereto estas elĉerpita.
    ///
    /// # Reveno de valoro
    ///
    /// Ekzistas pluraj eblaj revenvaloroj, ĉiu indikante klaran fluostaton:
    ///
    /// - `Poll::Pending` signifas, ke la sekva valoro de ĉi tiu rivereto ankoraŭ ne estas preta.Efektivigoj certigos, ke la aktuala tasko estos sciigita kiam la sekva valoro eble estos preta.
    ///
    /// - `Poll::Ready(Some(val))` signifas, ke la rivereto sukcese produktis valoron, `val`, kaj povas produkti pliajn valorojn dum postaj `poll_next`-alvokoj.
    ///
    /// - `Poll::Ready(None)` signifas, ke la rivereto finiĝis, kaj `poll_next` ne devas esti alvokita denove.
    ///
    /// # Panics
    ///
    /// Post kiam rivereto finiĝis (redonita `Ready(None)` from `poll_next`), vokanta sian `poll_next`-metodon denove povas panic, blokiĝi por ĉiam aŭ kaŭzi aliajn specojn de problemoj; la `Stream` trait ne postulas postulojn pri la efikoj de tia alvoko.
    ///
    /// Tamen, ĉar la `poll_next`-metodo ne estas markita `unsafe`, la kutimaj reguloj de Rust validas: vokoj neniam devas kaŭzi nedifinitan konduton (memora koruptado, malĝusta uzo de `unsafe`-funkcioj, aŭ simile), sendepende de la stato de la rivereto.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Liveras la limojn sur la restanta longo de la rivereto.
    ///
    /// Specife, `size_hint()` redonas opon, kie la unua elemento estas la malsupra rando, kaj la dua elemento estas la supra rando.
    ///
    /// La dua duono de la resendita opo estas [`Opcio`]`<`[`uzigi`] `>`.
    /// [`None`] ĉi tie signifas, ke aŭ ne estas konata supra rando, aŭ la supra rando estas pli granda ol [`usize`].
    ///
    /// # Efektivigaj notoj
    ///
    /// Ne estas devigite, ke flua efektivigo donas la deklaritan nombron da elementoj.Kaleza fluo povas doni malpli ol la malsupra rando aŭ pli ol la supra rando de elementoj.
    ///
    /// `size_hint()` ĉefe celas esti uzata por optimumigoj kiel rezervado de spaco por la elementoj de la rivereto, sed ne devas esti fidinda ekz. preterlasi kontrolojn de limoj en nesekura kodo.
    /// Malĝusta efektivigo de `size_hint()` ne devas konduki al malobservoj de memoro-sekureco.
    ///
    /// Dirite, la efektivigo devas doni ĝustan takson, ĉar alie ĝi estus malobservo de la protokolo de trait.
    ///
    /// La apriora efektivigo redonas `(0,` ['Neniu`]`)` kiu estas ĝusta por iu ajn rivereto.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}