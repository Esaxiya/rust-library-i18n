//! Komponebla nesinkrona ripeto.
//!
//! Se futures estas nesinkronaj valoroj, tiam riveretoj estas nesinkronaj ripetiloj.
//! Se vi troviĝis kun iu nesinkrona kolekto, kaj bezonis fari operacion pri la elementoj de tiu kolekto, vi rapide renkontos 'streams'.
//! Riveretoj estas tre uzataj en idioma nesinkrona Rust-kodo, do indas konatiĝi kun ili.
//!
//! Antaŭ ol klarigi pli, ni parolu pri kiel strukturiĝas ĉi tiu modulo:
//!
//! # Organization
//!
//! Ĉi tiu modulo estas plejparte organizita laŭ tipo:
//!
//! * [Traits] estas la kerna parto: ĉi tiuj traits difinas kiajn riveretojn ekzistas kaj kion vi povas fari per ili.La metodoj de ĉi tiuj traits indas meti iom da kroma studotempo.
//! * Funkcioj provizas iujn helpajn manierojn krei iujn bazajn fluojn.
//! * Strukturoj ofte estas la revenaj specoj de la diversaj metodoj sur traits de ĉi tiu modulo.Vi kutime volas rigardi la metodon, kiu kreas la `struct`, anstataŭ la `struct` mem.
//! Por pli da detaloj pri kial, vidu '[Efektiviganta Rojo](#efektiviganta-rivereto)'.
//!
//! [Traits]: #traits
//!
//! Jen ĝi!Ni fosu en riveretojn.
//!
//! # Stream
//!
//! La koro kaj animo de ĉi tiu modulo estas la [`Stream`] trait.La kerno de [`Stream`] aspektas tiel:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Male al `Iterator`, `Stream` distingas inter la [`poll_next`]-metodo uzata dum efektivigado de `Stream`, kaj (to-be-implemented) `next`-metodo uzata dum konsumado de rivereto.
//!
//! Konsumantoj de `Stream` bezonas nur konsideri `next`, kiu kiam vokita, redonas future kiu donas `Option<Stream::Item>`.
//!
//! La future redonita de `next` donos `Some(Item)` kondiĉe ke ekzistas elementoj, kaj post kiam ĉiuj elĉerpiĝos, donos `None` por indiki ke ripeto finiĝis.
//! Se ni atendas ion nesinkronan por solvi, la future atendos ĝis la rivereto estos preta cedi denove.
//!
//! Individuaj riveretoj povas elekti rekomenci ripeton, kaj tiel voki `next` denove eble eble eventuale donos `Some(Item)` denove iam.
//!
//! La plena difino de [`Stream`] inkluzivas ankaŭ multajn aliajn metodojn, sed ili estas defaŭltaj metodoj, konstruitaj aldone al [`poll_next`], do vi ricevas ilin senpage.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Efektiviga Rojo
//!
//! Krei propran rivereton implicas du paŝojn: krei `struct` por teni la staton de la rivereto, kaj poste efektivigi [`Stream`] por tiu `struct`.
//!
//! Ni kreu rivereton nomatan `Counter`, kiu kalkulas de `1` al `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Unue, la strukturo:
//!
//! /// Rivereto, kiu kalkulas de unu ĝis kvin
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ni volas, ke nia kalkulo komencu per unu, do ni aldonu new()-metodon por helpi.
//! // Ĉi tio ne strikte necesas, sed konvenas.
//! // Notu, ke ni startas `count` je nulo, ni vidos kial en `poll_next()`'s-efektivigo sube.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Poste ni efektivigas `Stream` por nia `Counter`:
//!
//! impl Stream for Counter {
//!     // ni kalkulos kun uzokutimo
//!     type Item = usize;
//!
//!     // poll_next() estas la sola bezonata metodo
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Pliigu nian kalkulon.Jen kial ni komencis je nulo.
//!         self.count += 1;
//!
//!         // Kontrolu ĉu ni finis kalkuli aŭ ne.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Riveretoj estas *pigraj*.Ĉi tio signifas, ke nur krei rivereton ne multe _do_.Nenio vere okazas ĝis vi vokas `next`.
//! Ĉi tio estas foje fonto de konfuzo kiam oni kreas rivereton nur por ĝiaj kromefikoj.
//! La kompililo avertos nin pri tia konduto:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;