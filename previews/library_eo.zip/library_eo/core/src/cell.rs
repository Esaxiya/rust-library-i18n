//! Interŝanĝeblaj ŝanĝeblaj ujoj.
//!
//! Memora sekureco de Rust baziĝas sur ĉi tiu regulo: Donita objekto `T`, nur eblas havi unu el la jenaj:
//!
//! - Havante plurajn neŝanĝeblajn referencojn (`&T`) al la objekto (ankaŭ konata kiel **kaŝnomo**).
//! - Havanta unu ŝanĝeblan referencon ("&mut T") al la objekto (ankaŭ konata kiel **ŝanĝebleco**).
//!
//! Ĉi tion plenumas la Rust-kompililo.Tamen estas situacioj, kie ĉi tiu regulo ne estas sufiĉe fleksebla.Foje necesas havi multajn referencojn al objekto kaj tamen mutacii ĝin.
//!
//! Interŝanĝeblaj ŝanĝeblaj ujoj ekzistas por permesi ŝanĝeblecon en kontrolita maniero, eĉ en ĉeesto de kaŝnomo.Ambaŭ [`Cell<T>`] kaj [`RefCell<T>`] permesas fari tion unufadene.
//! Tamen nek `Cell<T>` nek `RefCell<T>` estas fadenaj sekuraj (ili ne efektivigas [`Sync`]).
//! Se vi bezonas fari alinomadon kaj mutacion inter multaj fadenoj, eblas uzi [`Mutex<T>`], [`RwLock<T>`] aŭ [`atomic`]-specojn.
//!
//! Valoroj de la `Cell<T>` kaj `RefCell<T>`-specoj povas esti mutaciitaj per komunaj referencoj (t.e.
//! la komuna `&T`-speco), dum la plej multaj Rust-specoj povas esti mutaciitaj nur per unikaj ("&mut T") referencoj.
//! Ni diras, ke `Cell<T>` kaj `RefCell<T>` provizas 'internan ŝanĝeblecon', kontraste kun tipaj tipoj de Rust, kiuj montras 'hereditan ŝanĝeblecon'.
//!
//! Ĉelaj tipoj havas du gustojn: `Cell<T>` kaj `RefCell<T>`.`Cell<T>` efektivigas internan ŝanĝeblecon movante valorojn en kaj ekster la `Cell<T>`.
//! Por uzi referencojn anstataŭ valorojn, oni devas uzi la `RefCell<T>`-tipon, akirante skriban seruron antaŭ mutacii.`Cell<T>` provizas metodojn por retrovi kaj ŝanĝi la nunan internan valoron:
//!
//!  - Por tipoj, kiuj efektivigas [`Copy`], la metodo [`get`](Cell::get) reprenas la nunan internan valoron.
//!  - Por tipoj, kiuj efektivigas [`Default`], la [`take`](Cell::take)-metodo anstataŭigas la nunan internan valoron per [`Default::default()`] kaj redonas la anstataŭigitan valoron.
//!  - Por ĉiuj specoj, la [`replace`](Cell::replace)-metodo anstataŭigas la nunan internan valoron kaj redonas la anstataŭigitan valoron kaj la [`into_inner`](Cell::into_inner)-metodo konsumas la `Cell<T>` kaj redonas la internan valoron.
//!  Aldone, la [`set`](Cell::set)-metodo anstataŭigas la internan valoron, faligante la anstataŭigitan valoron.
//!
//! `RefCell<T>` uzas la vivdaŭrojn de Rust por efektivigi "dinamikan pruntadon", procezon per kiu oni povas pretendi provizoran, ekskluzivan, ŝanĝeblan aliron al la interna valoro.
//! Prunteprenas por `RefCell<T>`s estas spuritaj 'dum rultempo', male al la denaskaj referencaj tipoj de Rust, kiuj estas tute spuritaj statike, dum kompila tempo.
//! Ĉar `RefCell<T>`-pruntoj estas dinamikaj, eblas provi prunti valoron, kiu jam estas reciproke pruntita;kiam ĉi tio okazas, ĝi rezultigas fadenon panic.
//!
//! # Kiam elekti internan ŝanĝeblecon
//!
//! La pli ofta hereda ŝanĝebleco, kie oni devas havi unikan aliron mutacii valoron, estas unu el la ŝlosilaj lingvaj elementoj, kiuj ebligas al Rust forte rezoni pri montrilo-alinomado, statike malebligante kraŝajn erarojn.
//! Pro tio, oni preferas hereditan ŝanĝeblecon, kaj interna ŝanĝebleco estas io de lasta rimedo.
//! Ĉar ĉeltipoj ebligas mutacion, kie ĝi alie estus malpermesita, estas okazoj, kiam interna ŝanĝebleco povus taŭgi, aŭ eĉ *devas* esti uzata, ekz.
//!
//! * Enkondukante ŝanĝeblecon 'inside' de io neŝanĝebla
//! * Efektivigaj detaloj de logike neŝanĝeblaj metodoj.
//! * Mutaciaj efektivigoj de [`Clone`].
//!
//! ## Enkondukante ŝanĝeblecon 'inside' de io neŝanĝebla
//!
//! Multaj komunaj inteligentaj montriloj, inkluzive [`Rc<T>`] kaj [`Arc<T>`], provizas ujojn kloneblajn kaj divideblajn inter pluraj partioj.
//! Ĉar la enhavitaj valoroj povas esti multoblaj, ili povas esti pruntitaj nur per `&`, ne `&mut`.
//! Sen ĉeloj tute ne povus mutacii datumojn ene de ĉi tiuj inteligentaj montriloj.
//!
//! Estas tre ofte tiam enmeti `RefCell<T>` en komunajn montrilojn por reenkonduki ŝanĝeblecon:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Kreu novan blokon por limigi la amplekson de la dinamika pruntepreno
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Notu, ke se ni ne lasus la antaŭan prunton de la kaŝmemoro elflui, la posta pruntepreno kaŭzus dinamikan fadenon panic.
//!     //
//!     // Ĉi tio estas la ĉefa danĝero de uzado de `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Notu, ke ĉi tiu ekzemplo uzas `Rc<T>` kaj ne `Arc<T>`.`RefCell<T>`estas por unufadenaj scenaroj.Konsideru uzi [`RwLock<T>`] aŭ [`Mutex<T>`] se vi bezonas komunan ŝanĝeblecon en plurfadena situacio.
//!
//! ## Efektivigaj detaloj de logike neŝanĝeblaj metodoj
//!
//! Foje povas esti dezirinde ne elmontri en API, ke mutacio okazas "under the hood".
//! Ĉi tio povas esti ĉar logike la operacio estas neŝanĝebla, sed ekz. Konservado devigas la efektivigon plenumi mutacion;aŭ ĉar vi devas uzi mutacion por efektivigi metodon trait, kiu estis origine difinita por preni `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Multekosta komputado iras ĉi tien
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mutaciaj efektivigoj de `Clone`
//!
//! Ĉi tio estas simple speciala, sed ofta kazo de la antaŭa: kaŝi ŝanĝeblecon por operacioj, kiuj ŝajnas esti neŝanĝeblaj.
//! Oni atendas, ke la metodo [`clone`](Clone::clone) ne ŝanĝos la fontan valoron, kaj estas deklarita preni `&self`, ne `&mut self`.
//! Tial iu ajn mutacio okazanta en la `clone`-metodo devas uzi ĉeltipojn.
//! Ekzemple, [`Rc<T>`] konservas siajn referencajn kalkulojn ene de `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Ŝanĝebla memora loko.
///
/// # Examples
///
/// En ĉi tiu ekzemplo, vi povas vidi, ke `Cell<T>` ebligas mutacion ene de neŝanĝebla strukturo.
/// Alivorte, ĝi ebligas "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ERARO: `my_struct` estas neŝanĝebla
/// // my_struct.regular_field =nova_valoro;
///
/// // Funkcias: kvankam `my_struct` estas neŝanĝebla, `special_field` estas `Cell`,
/// // kiu ĉiam povas esti mutaciita
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Vidu la [module-level documentation](self) por pli.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Kreas `Cell<T>`, kun la valoro `Default` por T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Kreas novan `Cell` enhavantan la donitan valoron.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Agordas la enhavitan valoron.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Interŝanĝas la valorojn de du ĉeloj.
    /// Diferenco kun `std::mem::swap` estas, ke ĉi tiu funkcio ne bezonas `&mut`-referencon.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SEKURECO: Ĉi tio povas esti riska se vokita de apartaj fadenoj, sed `Cell`
        // estas `!Sync` do ĉi tio ne okazos.
        // Ĉi tio ankaŭ ne malvalidigos iujn montrilojn, ĉar `Cell` certigas, ke nenio alia celos iun ajn el ĉi tiuj `Ĉeloj`.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Anstataŭigas la enhavitan valoron per `val`, kaj redonas la malnovan enhavan valoron.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SEKURECO: Ĉi tio povas kaŭzi datumajn vetkurojn se vokita de aparta fadeno
        // sed `Cell` estas `!Sync` do ĉi tio ne okazos.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Malvolvas la valoron.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Liveras kopion de la enhavita valoro.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SEKURECO: Ĉi tio povas kaŭzi datumajn vetkurojn se vokita de aparta fadeno
        // sed `Cell` estas `!Sync` do ĉi tio ne okazos.
        unsafe { *self.value.get() }
    }

    /// Ĝisdatigas la enhavitan valoron per funkcio kaj redonas la novan valoron.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Redonas krudan montrilon al la subaj datumoj en ĉi tiu ĉelo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Liveras ŝanĝeblan referencon al la subaj datumoj.
    ///
    /// Ĉi tiu alvoko pruntas `Cell` mutable (dum kompila tempo), kio garantias, ke ni posedas la solan referencon.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Redonas `&Cell<T>` de `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SEKURECO: `&mut` certigas unikan aliron.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Prenas la valoron de la ĉelo, lasante `Default::default()` en sia loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Redonas `&[Cell<T>]` de `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SEKURECO: `Cell<T>` havas la saman memoran aranĝon kiel `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Ŝanĝebla memora loko kun dinamike kontrolitaj pruntaj reguloj
///
/// Vidu la [module-level documentation](self) por pli.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Eraro resendita de [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Eraro resendita de [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Pozitivaj valoroj reprezentas la nombron de `Ref` aktiva.Negativaj valoroj reprezentas la nombron de `RefMut` aktiva.
// Multoblaj "RefMut" povas esti aktivaj samtempe nur se ili rilatas al apartaj, ne imbrikitaj eroj de `RefCell` (ekz., Diversaj gamoj de tranĉaĵo).
//
// `Ref` kaj `RefMut` estas ambaŭ du vortoj grandecaj, do probable neniam ekzistos sufiĉe da "Ref" aŭ "RefMut" por superflui duonon de la `usize`-gamo.
// Tiel, `BorrowFlag` probable neniam superfluos aŭ subfluos.
// Tamen tio ne estas garantio, ĉar patologia programo povus plurfoje krei kaj poste mem::forget-Ref`s aŭ`RefMut`s.
// Tiel, ĉiu kodo devas eksplicite kontroli superfluon kaj subfluon por eviti nesekurecon, aŭ almenaŭ konduti ĝuste en la okazo, se superfluo aŭ subfluo okazas (ekz. Vidu BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Kreas novan `RefCell` enhavantan `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Konsumas la `RefCell`, redonante la envolvitan valoron.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Ĉar ĉi tiu funkcio prenas `self` (la `RefCell`) laŭ valoro, la kompililo statike kontrolas, ke ĝi ne estas nuntempe pruntita.
        //
        self.value.into_inner()
    }

    /// Anstataŭigas la envolvitan valoron per nova, redonante la malnovan valoron, sen deinicialigi ambaŭ.
    ///
    ///
    /// Ĉi tiu funkcio respondas al [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics se la valoro estas nun pruntita.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Anstataŭigas la envolvitan valoron per nova kalkulita de `f`, redonante la malnovan valoron, sen deinicialigi ambaŭ.
    ///
    ///
    /// # Panics
    ///
    /// Panics se la valoro estas nun pruntita.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Interŝanĝas la envolvitan valoron de `self` kun la envolvita valoro de `other`, sen seninicialigi unu.
    ///
    ///
    /// Ĉi tiu funkcio respondas al [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics se la valoro en ambaŭ `RefCell` estas nuntempe pruntita.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Neŝanĝeble pruntas la envolvitan valoron.
    ///
    /// La pruntepreno daŭras ĝis la redonita `Ref` eliras.
    /// Multoblaj neŝanĝeblaj pruntoj povas esti elprenitaj samtempe.
    ///
    /// # Panics
    ///
    /// Panics se la valoro estas nuntempe reciproke pruntita.
    /// Por senpanika varianto, uzu [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Ekzemplo de panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Neŝanĝeble pruntas la envolvitan valoron, redonante eraron, se la valoro estas nuntempe reciproke pruntita.
    ///
    ///
    /// La pruntepreno daŭras ĝis la redonita `Ref` eliras.
    /// Multoblaj neŝanĝeblaj pruntoj povas esti elprenitaj samtempe.
    ///
    /// Ĉi tiu estas la senpanika varianto de [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SEKURECO: `BorrowRef` certigas, ke ekzistas nur neŝanĝebla aliro
            // al la valoro dum pruntita.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Reciproke prunteprenas la envolvitan valoron.
    ///
    /// La prunto daŭras ĝis la redonita `RefMut` aŭ ĉiuj "RefMut" derivitaj de ĝi eliras.
    ///
    /// La valoro ne prunteblas dum ĉi tiu prunto estas aktiva.
    ///
    /// # Panics
    ///
    /// Panics se la valoro estas nun pruntita.
    /// Por senpanika varianto, uzu [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Ekzemplo de panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Reciproke prunteprenas la envolvitan valoron, redonante eraron se la valoro estas nun pruntita.
    ///
    ///
    /// La prunto daŭras ĝis la redonita `RefMut` aŭ ĉiuj "RefMut" derivitaj de ĝi eliras.
    /// La valoro ne prunteblas dum ĉi tiu prunto estas aktiva.
    ///
    /// Ĉi tiu estas la senpanika varianto de [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SEKURECO: `BorrowRef` garantias unikan aliron.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Redonas krudan montrilon al la subaj datumoj en ĉi tiu ĉelo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Liveras ŝanĝeblan referencon al la subaj datumoj.
    ///
    /// Ĉi tiu alvoko pruntas `RefCell` mutable (dum kompila tempo) do ne necesas dinamikaj kontroloj.
    ///
    /// Tamen estu singarda: ĉi tiu metodo atendas, ke `self` estos ŝanĝebla, kio ĝenerale ne okazas dum uzado de `RefCell`.
    ///
    /// Rigardu la metodon [`borrow_mut`] anstataŭe se `self` ne estas ŝanĝebla.
    ///
    /// Ankaŭ bonvolu konscii, ke ĉi tiu metodo estas nur por specialaj cirkonstancoj kaj kutime ne estas tio, kion vi volas.
    /// En kazo de dubo, uzu anstataŭe [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Malfaru la efikon de likitaj gardistoj sur la prunta stato de la `RefCell`.
    ///
    /// Ĉi tiu alvoko estas simila al [`get_mut`] sed pli specialigita.
    /// Ĝi pruntas `RefCell` muteble por certigi, ke neniuj pruntoj ekzistas kaj poste restarigas la ŝtatan spuradon de komunaj pruntoj.
    /// Ĉi tio gravas, se iuj pruntoj de `Ref` aŭ `RefMut` estis likitaj.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Neŝanĝeble pruntas la envolvitan valoron, redonante eraron, se la valoro estas nuntempe reciproke pruntita.
    ///
    /// # Safety
    ///
    /// Male al `RefCell::borrow`, ĉi tiu metodo estas nesekura ĉar ĝi ne redonas `Ref`, tiel lasante la pruntan flagon netuŝita.
    /// Reciproke pruntepreni la `RefCell` dum la referenco resendita per ĉi tiu metodo vivas estas nedifinita konduto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SEKURECO: Ni kontrolas, ke neniu aktive skribas nun, sed jes
            // la respondeco de la alvokanto certigi, ke neniu skribu ĝis la resendita referenco ne plu estos uzata.
            // Ankaŭ, `self.value.get()` rilatas al la valoro posedata de `self` kaj tiel garantias esti valida dum la tuta vivo de `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Prenas la envolvitan valoron, lasante `Default::default()` en sia loko.
    ///
    /// # Panics
    ///
    /// Panics se la valoro estas nun pruntita.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics se la valoro estas nuntempe reciproke pruntita.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Kreas `RefCell<T>`, kun la valoro `Default` por T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics se la valoro en ambaŭ `RefCell` estas nuntempe pruntita.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics se la valoro en ambaŭ `RefCell` estas nuntempe pruntita.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics se la valoro en ambaŭ `RefCell` estas nuntempe pruntita.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics se la valoro en ambaŭ `RefCell` estas nuntempe pruntita.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics se la valoro en ambaŭ `RefCell` estas nuntempe pruntita.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics se la valoro en ambaŭ `RefCell` estas nuntempe pruntita.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics se la valoro en ambaŭ `RefCell` estas nuntempe pruntita.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Kreskanta pruntepreno povas rezultigi nelegan valoron (<=0) en ĉi tiuj kazoj:
            // 1. Ĝi estis <0, te estas skribaj pruntoj, do ni ne povas permesi legitan prunton pro la referencaj aliasaj reguloj de Rust
            // 2.
            // Ĝi estis isize::MAX (la maksimuma kvanto de legantaj pruntoj) kaj ĝi superfluis en isize::MIN (la maksimuma kvanto de skribaj pruntoj) do ni ne povas permesi plian legitan prunton ĉar isize ne povas reprezenti tiom multe da legitaj pruntoj (ĉi tio povas okazi nur se vi mem::forget pli ol malgranda konstanta kvanto de `Ref`s, kio ne estas bona praktiko)
            //
            //
            //
            //
            None
        } else {
            // Pliigi prunton povas rezultigi legvaloron (> 0) en ĉi tiuj kazoj:
            // 1. Ĝi estis=0, te ĝi ne estis pruntita, kaj ni prenas la unuan legitan prunton
            // 2. Ĝi estis> 0 kaj <isize::MAX, t.e.
            // estis legitaj pruntoj, kaj isize estas sufiĉe granda por reprezenti havi ankoraŭ unu legitan prunton
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Ĉar ĉi tiu Ref ekzistas, ni scias, ke la prunta flago estas prunta prunto.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Malhelpu la prunteprenilon superflui en skriban prunteprenon.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Envolvas pruntitan referencon al valoro en `RefCell`-skatolo.
/// Envolva tipo por nemuteble pruntita valoro de `RefCell<T>`.
///
/// Vidu la [module-level documentation](self) por pli.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopias `Ref`.
    ///
    /// La `RefCell` jam estas senmove pruntita, do ĉi tio ne povas malsukcesi.
    ///
    /// Ĉi tio estas rilata funkcio, kiu devas esti uzata kiel `Ref::clone(...)`.
    /// Efektivigo de `Clone` aŭ metodo malhelpus la ĝeneraligitan uzon de `r.borrow().clone()` por kloni la enhavon de `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Faras novan `Ref` por ero de la pruntitaj datumoj.
    ///
    /// La `RefCell` jam estas senmove pruntita, do ĉi tio ne povas malsukcesi.
    ///
    /// Ĉi tio estas rilata funkcio, kiu devas esti uzata kiel `Ref::map(...)`.
    /// Metodo malhelpus samnomajn metodojn en la enhavo de `RefCell` uzata per `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Faras novan `Ref` por nedeviga ero de la pruntitaj datumoj.
    /// La originala gardisto estas redonita kiel `Err(..)` se la fermo redonas `None`.
    ///
    /// La `RefCell` jam estas senmove pruntita, do ĉi tio ne povas malsukcesi.
    ///
    /// Ĉi tio estas rilata funkcio, kiu devas esti uzata kiel `Ref::filter_map(...)`.
    /// Metodo malhelpus samnomajn metodojn en la enhavo de `RefCell` uzata per `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Disigas `Ref` en multoblajn "Ref" por malsamaj eroj de la pruntitaj datumoj.
    ///
    /// La `RefCell` jam estas senmove pruntita, do ĉi tio ne povas malsukcesi.
    ///
    /// Ĉi tio estas rilata funkcio, kiu devas esti uzata kiel `Ref::map_split(...)`.
    /// Metodo malhelpus samnomajn metodojn en la enhavo de `RefCell` uzata per `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Konverti al referenco al la subaj datumoj.
    ///
    /// La subesta `RefCell` neniam plu povas esti reciproke prunteprenita kaj ĉiam aperos jam neŝanĝeble pruntita.
    ///
    /// Ne estas bona ideo liki pli ol konstantan nombron da referencoj.
    /// La `RefCell` povas esti neŝanĝeble pruntita denove se entute nur pli malgranda nombro da likoj okazis.
    ///
    /// Ĉi tio estas rilata funkcio, kiu devas esti uzata kiel `Ref::leak(...)`.
    /// Metodo malhelpus samnomajn metodojn en la enhavo de `RefCell` uzata per `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Forgesante ĉi tiun Ref, ni certigas, ke la pruntepreno en la RefCell ne povas reiri al UNUSED dum la vivo `'b`.
        // Rekomenci la referencan spuran staton postulus unikan referencon al la pruntita RefCell.
        // Neniuj pliaj ŝanĝeblaj referencoj povas esti kreitaj de la originala ĉelo.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Faras novan `RefMut` por ero de la pruntitaj datumoj, ekz. Enum-varianto.
    ///
    /// La `RefCell` jam estas reciproke pruntita, do ĉi tio ne povas malsukcesi.
    ///
    /// Ĉi tio estas rilata funkcio, kiu devas esti uzata kiel `RefMut::map(...)`.
    /// Metodo malhelpus samnomajn metodojn en la enhavo de `RefCell` uzata per `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): ripari pruntkontrolon
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Faras novan `RefMut` por nedeviga ero de la pruntitaj datumoj.
    /// La originala gardisto estas redonita kiel `Err(..)` se la fermo redonas `None`.
    ///
    /// La `RefCell` jam estas reciproke pruntita, do ĉi tio ne povas malsukcesi.
    ///
    /// Ĉi tio estas rilata funkcio, kiu devas esti uzata kiel `RefMut::filter_map(...)`.
    /// Metodo malhelpus samnomajn metodojn en la enhavo de `RefCell` uzata per `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): ripari pruntkontrolon
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SEKURECO: funkcio tenas ekskluzivan referencon dum la daŭro
        // de ĝia alvoko tra `orig`, kaj la montrilo estas nur de-referencita ene de la funkcio-alvoko neniam permesante la ekskluzivan referencon eskapi.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SEKURECO: same kiel supre.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Disigas `RefMut` en multoblajn "RefMut"-ojn por diversaj eroj de la pruntitaj datumoj.
    ///
    /// La suba `RefCell` restos mutue pruntita ĝis ambaŭ resenditaj "RefMut" eliros ekster la amplekson.
    ///
    /// La `RefCell` jam estas reciproke pruntita, do ĉi tio ne povas malsukcesi.
    ///
    /// Ĉi tio estas rilata funkcio, kiu devas esti uzata kiel `RefMut::map_split(...)`.
    /// Metodo malhelpus samnomajn metodojn en la enhavo de `RefCell` uzata per `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Konverti al ŝanĝebla referenco al la subaj datumoj.
    ///
    /// La subesta `RefCell` ne povas esti pruntita de denove kaj ĉiam aperos jam reciproke pruntita, igante la revenitan referencon la sola al la interno.
    ///
    ///
    /// Ĉi tio estas rilata funkcio, kiu devas esti uzata kiel `RefMut::leak(...)`.
    /// Metodo malhelpus samnomajn metodojn en la enhavo de `RefCell` uzata per `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Forgesante ĉi tiun BorrowRefMut, ni certigas, ke la pruntepreno en la RefCell ne povas reiri al UNUSED dum la tuta vivo `'b`.
        // Rekomenci la referencan spuran staton postulus unikan referencon al la pruntita RefCell.
        // Neniuj pliaj referencoj povas esti kreitaj de la originala ĉelo ene de tiu vivo, kio faras la aktualan prunteprenon la sola referenco por la cetera vivo.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Male al BorrowRefMut::clone, nova estas vokita krei la komencan
        // ŝanĝebla referenco, kaj tial devas esti nuntempe neniuj ekzistantaj referencoj.
        // Tiel, dum klono pliigas la ŝanĝeblan rekalkulon, ĉi tie ni eksplicite permesas nur iri de UNUSED al UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Klonas `BorrowRefMut`.
    //
    // Ĉi tio validas nur se ĉiu `BorrowRefMut` estas uzata por spuri ŝanĝeblan referencon al klara, ne koincidanta gamo de la originala objekto.
    //
    // Ĉi tio ne estas en Klona programo, tiel ke kodo ne nomas tion implicite.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Malhelpu la prunteprenilon subflui.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Envolva tipo por reciproke pruntita valoro de `RefCell<T>`.
///
/// Vidu la [module-level documentation](self) por pli.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// La kerna primitivulo por interna ŝanĝebleco en Rust.
///
/// Se vi havas referencon `&T`, tiam kutime en Rust la kompililo plenumas optimumigojn bazitajn sur la scio, ke `&T` montras al neŝanĝeblaj datumoj.Mutacii tiujn datumojn, ekzemple per kaŝnomo aŭ per transmutacio de `&T` en `&mut T`, estas konsiderata nedifinita konduto.
/// `UnsafeCell<T>` eligo de la neŝanĝebla garantio por `&T`: komuna referenco `&UnsafeCell<T>` povas indiki datumojn mutaciantajn.Ĉi tio nomiĝas "interior mutability".
///
/// Ĉiuj aliaj specoj, kiuj permesas internan ŝanĝeblecon, kiel `Cell<T>` kaj `RefCell<T>`, interne uzas `UnsafeCell` por envolvi siajn datumojn.
///
/// Rimarku, ke nur la neŝanĝebla garantio por komunaj referencoj estas trafita de `UnsafeCell`.La unika garantio por ŝanĝeblaj referencoj ne influas.Ekzistas *neniu* laŭleĝa maniero akiri kaŝnomon `&mut`, eĉ ne kun `UnsafeCell<T>`.
///
/// La API `UnsafeCell` mem estas teknike tre simpla: [`.get()`] donas al vi krudan montrilon `*mut T` al ĝia enhavo.Dependas de _you_ kiel la abstrakta projektisto uzi ĝuste tiun krudan montrilon.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// La precizaj Rust-kaŝnomaj reguloj iom fluas, sed la ĉefaj punktoj ne estas disputigaj:
///
/// - Se vi kreas sekuran referencon kun vivdaŭro `'a` (aŭ `&T` aŭ `&mut T`-referenco) alirebla per sekura kodo (ekzemple, ĉar vi redonis ĝin), tiam vi ne rajtas aliri la datumojn iel ajn kontraŭan al tiu referenco por la resto de `'a`.
/// Ekzemple, ĉi tio signifas, ke se vi prenas la `*mut T` de `UnsafeCell<T>` kaj ĵetas ĝin al `&T`, tiam la datumoj en `T` devas resti neŝanĝeblaj (modulo iuj ajn `UnsafeCell`-datumoj trovitaj ene de `T`, kompreneble) ĝis la vivdaŭro de tiu referenco.
/// Simile, se vi kreas `&mut T`-referencon liberigitan al sekura kodo, tiam vi ne rajtas aliri la datumojn ene de la `UnsafeCell` ĝis tiu referenco eksvalidiĝos.
///
/// - Ĉiam vi devas eviti datumajn vetkurojn.Se pluraj fadenoj havas aliron al la sama `UnsafeCell`, tiam iuj skriboj devas havi taŭgan okaz-antaŭan rilaton al ĉiuj aliaj aliroj (aŭ uzi atomojn).
///
/// Por helpi kun taŭga projektado, la jenaj scenaroj estas eksplicite deklaritaj laŭleĝaj por unu-fadena kodo:
///
/// 1. `&T`-referenco povas esti liberigita al sekura kodo kaj tie ĝi povas kunekzisti kun aliaj `&T`-referencoj, sed ne kun `&mut T`
///
/// 2. `&mut T`-referenco povas esti liberigita al sekura kodo kondiĉe ke nek alia `&mut T` nek `&T` kunekzistas kun ĝi.`&mut T` devas ĉiam esti unika.
///
/// Notu, ke dum mutado de la enhavo de `&UnsafeCell<T>` (eĉ dum aliaj `&UnsafeCell<T>`-referencoj kaŝnomo la ĉelo) estas en ordo (kondiĉe ke vi plenumu la suprajn invariantojn alimaniere), tamen estas nedifinita konduto havi plurajn `&mut UnsafeCell<T>`-kaŝnomojn.
/// Tio estas, `UnsafeCell` estas envolvaĵo desegnita por havi specialan interagon kun _shared_ accesses (_i.e._, per referenco `&UnsafeCell<_>`);ekzistas neniu ajn magio traktante _exclusive_ accesses (_e.g._, per `&mut UnsafeCell<_>`): nek la ĉelo nek la envolvita valoro povas esti kaŝnomitaj dum la daŭro de tiu `&mut`-prunto.
///
/// Ĉi tion montras la aliro [`.get_mut()`], kiu estas _safe_ getter, kiu donas `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Jen ekzemplo montranta kiel muŝi la enhavon de `UnsafeCell<_>` malgraŭ ke ekzistas multaj referencoj kaŝnomantaj la ĉelon:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Akiru plurajn/dividitajn referencojn al la sama `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SEKURECO: ene de ĉi tiu amplekso ne ekzistas aliaj referencoj al la enhavo de `x`,
///     // do nia estas efike unika.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- prunti-+
///     *p1_exclusive += 27; // |
/// } // <---------- ne povas preterpasi ĉi tiun punkton -------------------+
///
/// unsafe {
///     // SEKURECO: ene de ĉi tiu amplekso neniu atendas havi ekskluzivan aliron al la enhavo de `x`,
///     // do ni povas havi multajn komunajn alirojn samtempe.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// La sekva ekzemplo montras la fakton, ke ekskluziva aliro al `UnsafeCell<T>` implicas ekskluzivan aliron al ĝia `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // kun ekskluzivaj aliroj,
///                         // `UnsafeCell` estas travidebla senoperacia envolvaĵo, do ne necesas `unsafe` ĉi tie.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Akiru kompilotemp-kontrolitan unikan referencon al `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Kun ekskluziva referenco, ni povas mutacii la enhavon senpage.
/// *p_unique.get_mut() = 0;
/// // Aŭ, ekvivalente:
/// x = UnsafeCell::new(0);
///
/// // Kiam ni posedas la valoron, ni povas ĉerpi la enhavon senpage.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Konstruas novan ekzemplon de `UnsafeCell`, kiu envolvos la specifan valoron.
    ///
    ///
    /// Ĉiu aliro al la interna valoro per metodoj estas `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Malvolvas la valoron.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Akiras ŝanĝeblan montrilon al la envolvita valoro.
    ///
    /// Ĉi tio povas esti ĵetita al ia ajn montrilo.
    /// Certigu, ke la aliro estas unika (sen aktivaj referencoj, ŝanĝeblaj aŭ ne) kiam vi ĵetas al `&mut T`, kaj certigu, ke neniuj mutacioj aŭ ŝanĝeblaj kaŝnomoj okazas kiam vi ĵetas al `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Ni povas simple ĵeti la montrilon de `UnsafeCell<T>` al `T` pro #[repr(transparent)].
        // Ĉi tio ekspluatas la specialan staton de libstd, ne ekzistas garantio por uzanta kodo, ke ĉi tio funkcios en versioj future de la kompililo!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Liveras ŝanĝeblan referencon al la subaj datumoj.
    ///
    /// Ĉi tiu alvoko pruntas la `UnsafeCell` mutable (dum kompila tempo), kio garantias, ke ni posedas la solan referencon.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Akiras ŝanĝeblan montrilon al la envolvita valoro.
    /// La diferenco al [`get`] estas, ke ĉi tiu funkcio akceptas krudan montrilon, kiu estas utila por eviti krei provizorajn referencojn.
    ///
    /// La rezulto povas esti ĵetita al ia ajn montrilo.
    /// Certigu, ke la aliro estas unika (neniuj aktivaj referencoj, ŝanĝeblaj aŭ ne) kiam vi ĵetas al `&mut T`, kaj certigu, ke ne ekzistas mutacioj aŭ ŝanĝeblaj kaŝnomoj, kiam vi ĵetas al `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Laŭpaŝa inicialigo de `UnsafeCell` postulas `raw_get`, ĉar voki `get` necesus krei referencon al neinicialigitaj datumoj:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Ni povas simple ĵeti la montrilon de `UnsafeCell<T>` al `T` pro #[repr(transparent)].
        // Ĉi tio ekspluatas la specialan staton de libstd, ne ekzistas garantio por uzanta kodo, ke ĉi tio funkcios en versioj future de la kompililo!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Kreas `UnsafeCell`, kun la valoro `Default` por T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}