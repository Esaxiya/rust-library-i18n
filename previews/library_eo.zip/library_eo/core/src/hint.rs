#![stable(feature = "core_hint", since = "1.27.0")]

//! Konsiloj al kompililo, kiuj efikas kiel kodo devas esti elsendita aŭ optimumigita.
//! Konsiloj povas esti kompila tempo aŭ rultempo.

use crate::intrinsics;

/// Informas la kompililon, ke ĉi tiu punkto en la kodo ne estas atingebla, ebligante pliajn optimumigojn.
///
/// # Safety
///
/// Atingi ĉi tiun funkcion estas tute *nedifinita konduto*(UB).Aparte, la kompililo supozas, ke ĉio UB neniam devas okazi, kaj tial forigos ĉiujn branĉojn, kiuj alvokas `unreachable_unchecked()`.
///
/// Kiel ĉiuj kazoj de UB, se ĉi tiu supozo montriĝas malĝusta, t.e., la `unreachable_unchecked()`-alvoko estas efektive atingebla inter ĉiuj eblaj kontrolfluoj, la kompililo aplikos la malĝustan optimumigan strategion, kaj eble eĉ eĉ koruptos ŝajne senrilatan kodon, kaŭzante malfacila-elpurigi problemojn.
///
///
/// Uzu ĉi tiun funkcion nur kiam vi povas pruvi, ke la kodo neniam nomos ĝin.
/// Alie konsideru uzi la [`unreachable!`]-makroon, kiu ne permesas optimumigojn sed panic kiam ekzekutita.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` estas ĉiam pozitiva (ne nula), tial `checked_div` neniam redonos `None`.
/////
///     // Tial, la alia branch estas neatingebla.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SEKURECO: la sekureca kontrakto por `intrinsics::unreachable` devas
    // estu konfirmita de la alvokanto.
    unsafe { intrinsics::unreachable() }
}

/// Sendas maŝinan instrukcion por signali al la procesoro, ke ĝi funkcias en okupata-atendata spino-buklo ("spino-seruro").
///
/// Ricevinte la spin-buklan signalon, la procesoro povas optimumigi sian konduton per ekzemple ŝparado de potenco aŭ interŝanĝo de hyper-fadenoj.
///
/// Ĉi tiu funkcio diferencas de [`thread::yield_now`], kiu rekte cedas al la planilo de la sistemo, dum `spin_loop` ne interagas kun la operaciumo.
///
/// Ofta uzokazo por `spin_loop` efektivigas saltitan optimisman ŝpinadon en CAS-buklo en sinkronigaj primitivuloj.
/// Por eviti problemojn kiel prioritatan inversion, oni forte rekomendas, ke la spina buklo finiĝu post finita kvanto da ripetoj kaj taŭga bloka programado fariĝu.
///
///
/// **Noto**: Sur platformoj, kiuj ne subtenas ricevi spin-loop-aludojn, ĉi tiu funkcio tute ne faras ion.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Komuna atoma valoro, kiun fadenoj uzos por kunordigi
/// let live = Arc::new(AtomicBool::new(false));
///
/// // En fona fadeno ni eventuale agordos la valoron
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Faru iom da laboro, tiam vivigu la valoron
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Reen al nia nuna fadeno, ni atendas la agordon de la valoro
/// while !live.load(Ordering::Acquire) {
///     // La spino-buklo estas aludo al la CPU, kiun ni atendas, sed probable ne tre longe
/////
///     hint::spin_loop();
/// }
///
/// // La valoro nun estas agordita
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SEKURECO: la `cfg`-attr certigas, ke ni plenumas ĉi tion nur ĉe x86-celoj.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SEKURECO: la `cfg`-attr certigas, ke ni plenumas ĉi tion nur ĉe x86_64-celoj.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SEKURECO: la `cfg`-attr certigas, ke ni plenumas ĉi tion nur ĉe aarch64-celoj.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SEKURECO: la `cfg`-attr certigas, ke ni plenumas ĉi tion nur per armaj celoj
            // kun subteno por la v6-funkcio.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Identa funkcio, kiu *__ sugestas __* al la kompililo, ke ĝi estu maksimume pesimisma pri tio, kion `black_box` povus fari.
///
/// Male al [`std::convert::identity`], Rust-kompililo estas kuraĝigita supozi, ke `black_box` povas uzi `dummy` laŭ iu ajn valida maniero, al kiu Rust-kodo rajtas sen enkonduki nedifinitan konduton en la vokanta kodo.
///
/// Ĉi tiu posedaĵo igas `black_box` utila por skribi kodon, en kiu iuj optimumigoj ne estas dezirataj, kiel komparnormoj.
///
/// Rimarku tamen, ke `black_box` estas nur (kaj nur povas esti) provizita laŭ "best-effort".La amplekso en kiu ĝi povas bloki optimumigojn povas varii depende de la platformo kaj koda gen-backend uzita.
/// Programoj neniel povas fidi je `black_box` por *ĝusteco*.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Ni bezonas "use" la argumenton iel LLVM ne povas introspekti, kaj pri celoj, kiuj subtenas ĝin, ni povas kutime utiligi enlinian asembleon por fari ĉi tion.
    // La interpreto de LLVM pri interreta aro estas, ke ĝi estas, nu, nigra skatolo.
    // Ĉi tio ne estas la plej bonega efektivigo, ĉar ĝi probable maloptimigas pli ol ni volas, sed ĝi estas ĝis nun sufiĉe bona.
    //
    //

    #[cfg(not(miri))] // Ĉi tio estas nur aludo, do bonas preterlasi Miri.
    // SEKURECO: la enlinia aro estas sen-operacia.
    unsafe {
        // FIXME: Ne eblas uzi `asm!` ĉar ĝi ne subtenas MIPS kaj aliajn arkitekturojn.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}