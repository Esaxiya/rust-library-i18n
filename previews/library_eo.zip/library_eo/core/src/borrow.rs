//! Modulo por labori kun pruntitaj datumoj.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait por pruntado de datumoj.
///
/// En Rust, estas ofte provizi malsamajn reprezentojn de tipo por malsamaj uzokazoj.
/// Ekzemple, stoka loko kaj administrado por valoro povas esti specife elektitaj kiel taŭgaj por aparta uzo per montriloj kiel [`Box<T>`] aŭ [`Rc<T>`].
/// Krom ĉi tiuj ĝeneralaj envolvaĵoj uzeblaj kun iu ajn tipo, iuj tipoj provizas laŭvolajn facetojn provizantajn eble multekostajn funkciojn.
/// Ekzemplo por tia tipo estas [`String`], kiu aldonas la kapablon etendi ĉenon al la baza [`str`].
/// Ĉi tio postulas konservi aldonajn informojn nenecesajn por simpla neŝanĝebla ĉeno.
///
/// Ĉi tiuj tipoj donas aliron al la subaj datumoj per referencoj al la speco de tiuj datumoj.Oni diras, ke ili estas 'pruntitaj kiel' tiaj.
/// Ekzemple, [`Box<T>`] povas esti pruntita kiel `T` dum [`String`] povas esti pruntita kiel `str`.
///
/// Tipoj esprimas, ke ili povas esti pruntitaj kiel ia tipo `T` per efektivigo de `Borrow<T>`, donante referencon al `T` en la metodo [`borrow`] de la trait.Tipo estas senpaga pruntepreni kiel pluraj malsamaj tipoj.
/// Se ĝi volas mutule pruntepreni kiel la tipo-permesante modifi la subajn datumojn, ĝi povas aldone efektivigi [`BorrowMut<T>`].
///
/// Plue, kiam oni provizas efektivigojn por aldonaj traits, necesas pripensi ĉu ili kondutu idente al tiuj de la suba tipo kiel konsekvenco de agado kiel reprezento de tiu suba tipo.
/// Ĝenerala kodo kutime uzas `Borrow<T>` kiam ĝi dependas de la identa konduto de ĉi tiuj aldonaj efektivigoj de trait.
/// Ĉi tiuj traits probable aperos kiel aldonaj trait bounds.
///
/// Aparte `Eq`, `Ord` kaj `Hash` devas esti ekvivalentaj por pruntitaj kaj posedataj valoroj: `x.borrow() == y.borrow()` devas doni la saman rezulton kiel `x == y`.
///
/// Se ĝenerala kodo nur bezonas funkcii por ĉiuj specoj, kiuj povas doni referencon al rilata tipo `T`, ofte estas pli bone uzi [`AsRef<T>`], ĉar pli da tipoj povas sekure efektivigi ĝin.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Kiel kolekto de datumoj, [`HashMap<K, V>`] posedas ambaŭ klavojn kaj valorojn.Se la realaj datumoj de la ŝlosilo estas envolvitaj en ia speco, tamen tamen devas esti eble serĉi valoron per referenco al la datumoj de la ŝlosilo.
/// Ekzemple, se la ŝlosilo estas ĉeno, tiam ĝi probable estas stokita kun la haŝiŝa mapo kiel [`String`], dum devus esti eble serĉi per [`&str`][`str`].
/// Tiel, `insert` bezonas funkcii sur `String` dum `get` bezonas povi uzi `&str`.
///
/// Iomete simpligitaj, la koncernaj partoj de `HashMap<K, V>` aspektas tiel:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // kampoj preterlasitaj
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// La tuta haŝiŝa mapo estas ĝenerala super ŝlosila tipo `K`.Ĉar ĉi tiuj klavoj estas konservitaj kun la haka mapo, ĉi tiu tipo devas posedi la datumojn de la ŝlosilo.
/// Enmetante ŝlosil-valoran paron, la mapo ricevas tian `K` kaj bezonas trovi la ĝustan hakitan rubujon kaj kontroli ĉu la ŝlosilo jam ĉeestas surbaze de tiu `K`.Ĝi do postulas `K: Hash + Eq`.
///
/// Se vi serĉas valoron en la mapo, tamen devi doni referencon al `K` kiel la serĉa ŝlosilo postulus ĉiam krei tian posedatan valoron.
/// Por ĉenaj klavoj, ĉi tio signifus ke `String`-valoro devas esti kreita nur por la serĉo de kazoj, kie nur `str` estas havebla.
///
/// Anstataŭe, la `get`-metodo estas ĝenerala super la speco de la subaj esencaj datumoj, nomitaj `Q` en la supra subskribo de metodo.Ĝi diras, ke `K` pruntas kiel `Q` postulante tiun `K: Borrow<Q>`.
/// Plie postulante `Q: Hash + Eq`, ĝi signalas la postulon, ke `K` kaj `Q` havas efektivigojn de la `Hash` kaj `Eq` traits, kiuj donas identajn rezultojn.
///
/// La efektivigo de `get` dependas precipe de identaj efektivigoj de `Hash` per determinado de la haŝa sitelo de la ŝlosilo vokante `Hash::hash` sur la `Q`-valoro kvankam ĝi enigis la ŝlosilon surbaze de la haŝiŝa valoro kalkulita de la `K`-valoro.
///
///
/// Kiel konsekvenco, la haŝiŝa mapo rompiĝas se `K` envolvanta `Q`-valoron produktas malsaman haŝiŝon ol `Q`.Ekzemple, imagu, ke vi havas tipon, kiu envolvas ĉenon, sed komparas ASCII-literojn ignorante ilian majusklon:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Ĉar du egalaj valoroj bezonas produkti la saman haŝan valoron, la efektivigo de `Hash` ankaŭ devas ignori ASCII-kazon:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Ĉu `CaseInsensitiveString` povas efektivigi `Borrow<str>`?Ĝi certe povas doni referencon al ĉena tranĉaĵo per sia enhavita posedata ĉeno.
/// Sed ĉar ĝia `Hash`-efektivigo malsamas, ĝi kondutas malsame ol `str` kaj tial fakte ne devas efektivigi `Borrow<str>`.
/// Se ĝi volas permesi al aliaj aliron al la suba `str`, ĝi povas fari tion per `AsRef<str>`, kiu ne havas kromajn postulojn.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Neŝanĝeble pruntas de posedata valoro.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait por reciproke pruntado de datumoj.
///
/// Kiel kunulo al [`Borrow<T>`] ĉi tiu trait permesas tipon prunti kiel suba tipo per provizo de ŝanĝebla referenco.
/// Vidu [`Borrow<T>`] por pliaj informoj pri pruntepreno kiel alia tipo.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Reciproke prunteprenas de posedata valoro.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}