//! Traits por konvertiĝoj inter tipoj.
//!
//! La traits en ĉi tiu modulo provizas manieron konverti de unu tipo al alia tipo.
//! Ĉiu trait servas malsaman celon:
//!
//! - Efektivigu la [`AsRef`] trait por malmultekostaj referenc-al-referencaj konvertiĝoj
//! - Efektivigu la [`AsMut`] trait por malmultekostaj ŝanĝeblaj ŝanĝeblaj al ŝanĝeblaj
//! - Efektivigu la [`From`] trait por konsumi valor-al-valorajn konvertiĝojn
//! - Efektivigu la [`Into`] trait por konsumi valor-al-valorajn konvertiĝojn al tipoj ekster la nuna crate
//! - La [`TryFrom`] kaj [`TryInto`] traits kondutas kiel [`From`] kaj [`Into`], sed devas esti efektivigitaj kiam la konvertiĝo povas fiaski.
//!
//! La traits en ĉi tiu modulo estas ofte uzata kiel trait bounds por ĝeneralaj funkcioj tiel, ke al argumentoj de multaj specoj estas subtenataj.Vidu la dokumentadon de ĉiu trait por ekzemploj.
//!
//! Kiel aŭtoro de biblioteko, vi ĉiam preferu efektivigi [`From<T>`][`From`] aŭ [`TryFrom<T>`][`TryFrom`] anstataŭ [`Into<U>`][`Into`] aŭ [`TryInto<U>`][`TryInto`], ĉar [`From`] kaj [`TryFrom`] provizas pli grandan flekseblecon kaj ofertas ekvivalentajn [`Into`] aŭ [`TryInto`]-efektivigojn senpage, danke al kovrila efektivigo en la norma biblioteko.
//! Se vi celas version antaŭ Rust 1.41, eble necesas efektivigi [`Into`] aŭ [`TryInto`] rekte kiam vi konvertas al tipo ekster la nuna crate.
//!
//! # Senmarkaj Efektivigoj
//!
//! - [`AsRef`] kaj [`AsMut`]-aŭtomata malreferenco se la interna tipo estas referenco
//! - ['De'] `<U>por T` implicas [`En ']`</u><T><U>por U`</u>
//! - ['TryFrom`]` <U>por T`implicas [` TryInto`]`</u><T><U>por U`</u>
//! - [`From`] kaj [`Into`] estas refleksivaj, kio signifas, ke ĉiuj specoj povas `into` mem kaj `from` mem
//!
//! Vidu ĉiun trait por uzaj ekzemploj.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// La identa funkcio.
///
/// Du aferoj gravas rimarkindaj pri ĉi tiu funkcio:
///
/// - Ĝi ne ĉiam ekvivalentas al fermo kiel `|x| x`, ĉar la fermo eble devigos `x` en alian tipon.
///
/// - Ĝi movas la enigaĵon `x` transdonitan al la funkcio.
///
/// Kvankam eble ŝajnas strange havi funkcion, kiu nur redonas la enigon, estas iuj interesaj uzoj.
///
///
/// # Examples
///
/// Uzi `identity` por fari nenion en sinsekvo de aliaj interesaj funkcioj:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Ni ŝajnigu, ke aldoni unu estas interesa funkcio.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Uzi `identity` kiel bazan kazon "do nothing" en kondicionalo:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Faru pli interesajn aferojn ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Uzante `identity` por konservi la `Some`-variantojn de ripetilo de `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Kutimis fari malmultekostan referencon al referenco.
///
/// Ĉi tiu trait similas al [`AsMut`], kiu estas uzata por konverti inter ŝanĝeblaj referencoj.
/// Se vi bezonas fari multekostan konvertiĝon, estas pli bone efektivigi [`From`] kun tipo `&T` aŭ skribi laŭmendan funkcion.
///
/// `AsRef` havas la saman subskribon kiel [`Borrow`], sed [`Borrow`] diferencas en malmultaj aspektoj:
///
/// - Male al `AsRef`, [`Borrow`] havas litkovrilon por iu `T`, kaj povas esti uzata por akcepti aŭ referencon aŭ valoron.
/// - [`Borrow`] ankaŭ postulas, ke [`Hash`], [`Eq`] kaj [`Ord`] por pruntita valoro ekvivalentas al tiuj de la posedata valoro.
/// Tial, se vi volas prunti nur unu kampon de strukturo, vi povas efektivigi `AsRef`, sed ne [`Borrow`].
///
/// **Note: Ĉi tiu trait ne devas malsukcesi **.Se la konvertiĝo povas malsukcesi, uzu specialan metodon, kiu redonas [`Option<T>`] aŭ [`Result<T, E>`].
///
/// # Senmarkaj Efektivigoj
///
/// - `AsRef` aŭtomataj malreferencoj se la interna tipo estas referenco aŭ ŝanĝebla referenco (ekz.: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Uzante trait bounds ni povas akcepti argumentojn de malsamaj tipoj kondiĉe ke ili povas esti konvertitaj al la specifa tipo `T`.
///
/// Ekzemple: Kreante ĝeneralan funkcion, kiu prenas `AsRef<str>`, ni esprimas, ke ni volas akcepti ĉiujn referencojn konverteblajn al [`&str`] kiel argumento.
/// Ĉar ambaŭ [`String`] kaj [`&str`] efektivigas `AsRef<str>` ni povas akcepti ambaŭ kiel eniga argumento.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Faras la konvertiĝon.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Kutimis fari malmultekostan ŝanĝeblan referencan konvertiĝon.
///
/// Ĉi tiu trait estas simila al [`AsRef`] sed uzata por konverti inter ŝanĝeblaj referencoj.
/// Se vi bezonas fari multekostan konvertiĝon, estas pli bone efektivigi [`From`] kun tipo `&mut T` aŭ skribi laŭmendan funkcion.
///
/// **Note: Ĉi tiu trait ne devas malsukcesi **.Se la konvertiĝo povas malsukcesi, uzu specialan metodon, kiu redonas [`Option<T>`] aŭ [`Result<T, E>`].
///
/// # Senmarkaj Efektivigoj
///
/// - `AsMut` aŭtomataj malreferencoj se la interna tipo estas ŝanĝebla referenco (ekz.: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Uzante `AsMut` kiel trait bound por ĝenerala funkcio ni povas akcepti ĉiujn ŝanĝeblajn referencojn konverteblajn al tipo `&mut T`.
/// Ĉar [`Box<T>`] efektivigas `AsMut<T>` ni povas skribi funkcion `add_one` kiu prenas ĉiujn argumentojn konverteblajn al `&mut u64`.
/// Ĉar [`Box<T>`] efektivigas `AsMut<T>`, `add_one` ankaŭ akceptas argumentojn de tipo `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Faras la konvertiĝon.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Valoro-al-valora konvertiĝo, kiu konsumas la enigan valoron.La malo de [`From`].
///
/// Oni evitu efektivigi [`Into`] kaj anstataŭe efektivigu [`From`].
/// Efektivigo de [`From`] aŭtomate provizas unu per efektivigo de [`Into`] danke al la kovrila efektivigo en la norma biblioteko.
///
/// Preferu uzi [`Into`] super [`From`] kiam vi specifas trait bounds sur ĝenerala funkcio por certigi, ke specoj, kiuj nur efektivigas [`Into`], povas esti uzataj ankaŭ.
///
/// **Note: Ĉi tiu trait ne devas malsukcesi **.Se la konvertiĝo povas malsukcesi, uzu [`TryInto`].
///
/// # Senmarkaj Efektivigoj
///
/// - ['De'] `<T>ĉar U` implicas `Into<U> for T`
/// - [`Into`] estas refleksiva, kio signifas, ke `Into<T> for T` estas efektivigita
///
/// # Efektivigo de [`Into`] por konvertiĝoj al eksteraj tipoj en malnovaj versioj de Rust
///
/// Antaŭ Rust 1.41, se la celloko ne estis parto de la nuna crate, vi ne povus efektivigi [`From`] rekte.
/// Ekzemple, prenu ĉi tiun kodon:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Ĉi tio malsukcesos kompili en pli malnovaj versioj de la lingvo, ĉar la orfaj reguloj de Rust kutimis esti iomete pli striktaj.
/// Por preteriri ĉi tion, vi povus efektivigi [`Into`] rekte:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Gravas kompreni, ke [`Into`] ne provizas efektivigon de [`From`] (kiel [`From`] faras kun [`Into`]).
/// Sekve, vi ĉiam provu efektivigi [`From`] kaj poste fali reen al [`Into`] se [`From`] ne povas esti efektivigita.
///
/// # Examples
///
/// [`String`] iloj ["En"] "<` [`Vec`]`<`[`u8`] `>>`:
///
/// Por esprimi, ke ni volas ke ĝenerala funkcio akceptu ĉiujn argumentojn transformeblajn al specifa tipo `T`, ni povas uzi trait bound de [`Into`]`<T>`.
///
/// Ekzemple: La funkcio `is_hello` prenas ĉiujn argumentojn transformeblajn en [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Faras la konvertiĝon.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Uzita por fari valor-al-valorajn konvertiĝojn dum konsumado de la eniga valoro.Ĝi estas la reciproka de [`Into`].
///
/// Oni ĉiam preferu efektivigi `From` anstataŭ [`Into`] ĉar efektivigi `From` aŭtomate provizas unu kun efektivigo de [`Into`] danke al la litokovra efektivigo en la norma biblioteko.
///
///
/// Efektivigu [`Into`] nur celante version antaŭ Rust 1.41 kaj konvertante al tipo ekster la nuna crate.
/// `From` ne povis fari ĉi tiajn konvertiĝojn en antaŭaj versioj pro la orfaj reguloj de Rust.
/// Vidu [`Into`] por pli da detaloj.
///
/// Preferu uzi [`Into`] anstataŭ uzi `From` kiam specifas trait bounds sur ĝenerala funkcio.
/// Tiel, specoj, kiuj rekte efektivigas [`Into`], povas esti uzataj ankaŭ kiel argumentoj.
///
/// La `From` ankaŭ estas tre utila dum plenumado de eraroj.Kiam oni konstruas funkcion kapablan malsukcesi, la revena tipo ĝenerale estos de la formo `Result<T, E>`.
/// La `From` trait simpligas eraran traktadon, permesante al funkcio redoni unu eraran tipon, kiu enkapsuligas plurajn erarajn specojn.Vidu la sekcion "Examples" kaj [the book][book] por pli da detaloj.
///
/// **Note: Ĉi tiu trait ne devas malsukcesi **.Se la konvertiĝo povas malsukcesi, uzu [`TryFrom`].
///
/// # Senmarkaj Efektivigoj
///
/// - `From<T> for U` implicas ['En'] `<U>por T`</u>
/// - `From` estas refleksiva, kio signifas, ke `From<T> for T` estas efektivigita
///
/// # Examples
///
/// [`String`] iloj `From<&str>`:
///
/// Eksplicita konvertiĝo de `&str` al Ŝnuro fariĝas jene:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Dum plenumado de eraroj ofte utilas efektivigi `From` por via propra erara tipo.
/// Konvertante subajn erarajn specojn al nia propra laŭmenda erara tipo, kiu enkapsuligas la suban eraran tipon, ni povas redoni unu eraran tipon sen perdi informojn pri la suba kaŭzo.
/// La '?'-operatoro aŭtomate konvertas la suban eraran tipon al nia laŭmenda erara tipo vokante `Into<CliError>::into`, kiu estas aŭtomate provizita dum efektivigo de `From`.
/// La kompililo tiam konkludas, kiun efektivigon de `Into` oni uzu.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Faras la konvertiĝon.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Provita konvertiĝo, kiu konsumas `self`, kiu povas esti aŭ ne multekosta.
///
/// Bibliotekaj aŭtoroj kutime ne rekte efektivigu ĉi tiun trait, sed prefere efektivigu la [`TryFrom`] trait, kiu ofertas pli grandan flekseblecon kaj provizas samvaloran `TryInto`-efektivigon senpage, danke al kovrila efektivigo en la norma biblioteko.
/// Por pliaj informoj pri tio, vidu la dokumentaron por [`Into`].
///
/// # Efektiviganta `TryInto`
///
/// Ĉi tio suferas la samajn limigojn kaj rezonadon kiel efektivigado de [`Into`], vidu tie por detaloj.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// La tipo revenis en kazo de konverta eraro.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Faras la konvertiĝon.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Simplaj kaj sekuraj tipaj konvertiĝoj, kiuj eble malsukcese regas en iuj cirkonstancoj.Ĝi estas la reciproka de [`TryInto`].
///
/// Ĉi tio estas utila kiam vi faras tipan konvertiĝon, kiu eble banale sukcesas, sed eble bezonas specialan pritraktadon.
/// Ekzemple, ekzistas neniu maniero konverti [`i64`] en [`i32`] uzante la [`From`] trait, ĉar [`i64`] povas enhavi valoron, kiun [`i32`] ne povas reprezenti kaj do la konvertiĝo perdus datumojn.
///
/// Ĉi tio povus esti pritraktita per detranĉado de la [`i64`] al [`i32`] (esence donante la valoron de la [`i64`] modulo [`i32::MAX`]) aŭ simple redonante [`i32::MAX`], aŭ per iu alia metodo.
/// La [`From`] trait estas celita por perfektaj konvertiĝoj, do la `TryFrom` trait informas la programiston kiam tipa konvertiĝo povus fali kaj lasas ilin decidi kiel pritrakti ĝin.
///
/// # Senmarkaj Efektivigoj
///
/// - `TryFrom<T> for U` implicas ['TryInto`]` <U>por T`</u>
/// - [`try_from`] estas refleksiva, kio signifas, ke `TryFrom<T> for T` estas efektivigita kaj ne povas malsukcesi-la rilata `Error`-tipo por nomi `T::try_from()` laŭ valoro de tipo `T` estas [`Infallible`].
/// Kiam la [`!`]-tipo estas stabiligita [`Infallible`] kaj [`!`] estos ekvivalentaj.
///
/// `TryFrom<T>` povas esti efektivigita jene:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Kiel priskribite, [`i32`] efektivigas "TryFrom <" [`i64"] ">`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Silente detranĉas `big_number`, postulas detekti kaj pritrakti la detranĉon post la fakto.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Liveras eraron ĉar `big_number` estas tro granda por enigi `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Liveras `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// La tipo revenis en kazo de konverta eraro.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Faras la konvertiĝon.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERAJ IMPLS
////////////////////////////////////////////////////////////////////////////////

// Kiel levas super&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Kiel levoj super &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): anstataŭigu la suprajn impls por&/&mut kun la sekva pli ĝenerala:
// // Kiel levoj super Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Grandigita> AsRef <U>por D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut levas super &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): anstataŭigu la supran impl por &mut per la sekva pli ĝenerala:
// // AsMut levas super DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Grandigita> AsMut <U>por D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// De implicas En
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// De (kaj tiel Into) estas refleksiva
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Stabileca noto:** Ĉi tiu programo ankoraŭ ne ekzistas, sed ni estas "reserving space" por aldoni ĝin en la future.
/// Vidu [rust-lang/rust#64715][#64715] por detaloj.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): faru principan riparon anstataŭe.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom implicas TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Seneraraj konvertiĝoj estas semantike ekvivalentaj al eraraj konvertiĝoj kun neloĝata erarspeco.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// KONKRETOJ IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// LA SENERARA ERARO TIPO
////////////////////////////////////////////////////////////////////////////////

/// La erara tipo por eraroj, kiuj neniam povas okazi.
///
/// Ĉar ĉi tiu enumo ne havas varianton, tia valoro neniam povas efektive ekzisti.
/// Ĉi tio povas esti utila por ĝeneralaj APIoj, kiuj uzas [`Result`] kaj parametras la eraran tipon, por indiki, ke la rezulto ĉiam estas [`Ok`].
///
/// Ekzemple, la [`TryFrom`] trait (konvertiĝo, kiu redonas [`Result`]) havas ĝeneralan efektivigon por ĉiuj specoj, kie ekzistas inversa [`Into`]-efektivigo.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future-kongruo
///
/// Ĉi tiu enum havas la saman rolon kiel [the `!`“never”type][never], kiu estas malstabila en ĉi tiu versio de Rust.
/// Kiam `!` stabiliĝas, ni planas igi `Infallible` tipo kaŝnomo al ĝi:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... kaj eventuale malrekomendas `Infallible`.
///
/// Tamen estas unu kazo, ke `!`-sintakso povas esti uzata antaŭ ol `!` estas stabiligita kiel plenkreska tipo: en la pozicio de revena tipo de funkcio.
/// Specife, estas eblaj efektivigoj por du malsamaj funkciaj montriloj:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Kun `Infallible` estas enum, ĉi tiu kodo validas.
/// Tamen kiam `Infallible` fariĝos kaŝnomo por la never type, la du `impl`s komencos interkovri kaj tial estos malpermesitaj de la koheraj reguloj de la lingvo trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}