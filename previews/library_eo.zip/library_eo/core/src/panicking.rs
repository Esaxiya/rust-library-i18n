//! Panic subteno por libcore
//!
//! La kerna biblioteko ne povas difini panikon, sed ĝi *deklaras* paniki.
//! Ĉi tio signifas, ke la funkcioj ene de libcore estas permesitaj al panic, sed por esti utila kontraŭflua crate devas difini panikon por libcore uzi.
//! La nuna interfaco por panikiĝi estas:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Ĉi tiu difino ebligas panikon kun iu ajn ĝenerala mesaĝo, sed ĝi ne permesas malsukcesi kun `Box<Any>`-valoro.
//! (`PanicInfo` nur enhavas `&(dyn Any + Send)`, por kiu ni plenigas imititan valoron en `PanicInfo: : internal_constructor`.) La kialo de tio estas, ke libcore ne rajtas atribui.
//!
//!
//! Ĉi tiu modulo enhavas kelkajn aliajn panikajn funkciojn, sed ĉi tiuj estas nur la necesaj langobjektoj por la kompililo.Ĉiuj panics estas enkanaligitaj per ĉi tiu funkcio.
//! La efektiva simbolo estas deklarita per la `#[panic_handler]`-atributo.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// La suba efektivigo de la `panic!`-makroo de libcore kiam neniu formatado estas uzata.
#[cold]
// neniam enliniu krom se panic_immediate_abort evitas kodan ŝvelon ĉe la alvokaj retejoj laŭeble
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // bezonata de kodegeno por panic ĉe superfluaĵo kaj aliaj `Assert`-MIR-finaĵoj
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Uzu Arguments::new_v1 anstataŭ format_args! ("{}", Expr) por eble redukti grandecon supre.
    // La formato_args!makroo uzas Str's Display trait por skribi expr, kiu nomas Formatter::pad, kiu devas akomodi kordotranĉadon kaj kompletigon (kvankam neniu uzas ĉi tie).
    //
    // Uzi Arguments::new_v1 povas permesi al la kompililo preterlasi Formatter::pad de la eliga duuma, ŝparante ĝis kelkaj kilobajtoj.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // bezonata por konst-taksita panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // bezonata de kodegeno por panic ĉe aliro OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// La suba efektivigo de la `panic!`-makroo de libcore kiam formatado estas uzata.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NOTO Ĉi tiu funkcio neniam transiras la limon de FFI;ĝi estas Rust-al-Rust-alvoko, kiu solviĝas al la `#[panic_handler]`-funkcio.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SEKURECO: `panic_impl` estas difinita en sekura Rust-kodo kaj tiel estas sekure telefonebla.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Interna funkcio por makrooj `assert_eq!` kaj `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}