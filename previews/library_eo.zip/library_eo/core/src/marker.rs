//! Primitivaj traits kaj tipoj reprezentantaj bazajn ecojn de tipoj.
//!
//! Rust-specoj povas esti klasifikitaj en diversaj utilaj manieroj laŭ siaj internaj ecoj.
//! Ĉi tiuj klasifikoj estas reprezentataj kiel traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tipoj transdoneblaj trans fadenaj limoj.
///
/// Ĉi tiu trait aŭtomate efektiviĝas kiam la kompililo determinas, ke ĝi taŭgas.
///
/// Ekzemplo de ne-senda tipo estas la referenca kalkula montrilo [`rc::Rc`][`Rc`].
/// Se du fadenoj provas kloni [`Rc`]-ojn, kiuj montras al la sama referenc-kalkulita valoro, ili eble provos ĝisdatigi la referencan kalkulon samtempe, kio estas [undefined behavior][ub] ĉar [`Rc`] ne uzas atomajn operaciojn.
///
/// Ĝia kuzo [`sync::Arc`][arc] uzas atomajn operaciojn (farante iom da supre) kaj do estas `Send`.
///
/// Vidu [the Nomicon](../../nomicon/send-and-sync.html) por pli da detaloj.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tipoj kun konstanta grandeco konata en kompila tempo.
///
/// Ĉiuj tipaj parametroj havas implican baron de `Sized`.La speciala sintakso `?Sized` uzeblas por forigi ĉi tiun binditan se ĝi ne taŭgas.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // strukt FooUse(Foo<[i32]>);//eraro: Grandeco ne estas efektivigita por [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// La sola escepto estas la implica `Self`-speco de trait.
/// trait ne havas implican `Sized`-ligon ĉar tio estas malkongrua kun [trait objekto] s kie, laŭdifine, trait bezonas labori kun ĉiuj eblaj efektivigiloj, kaj tiel povus esti ajna grandeco.
///
///
/// Kvankam Rust lasos vin ligi `Sized` al trait, vi ne povos uzi ĝin por formi trait-objekton poste:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // lasu y: &dyn Bar= &Impl;//eraro: la trait `Bar` ne povas esti transformita en objekton
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // por Defaŭlto, ekzemple, kiu postulas ke `[T]: !Default` estu taksebla
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tipoj, kiuj povas esti "unsized" al dinamike granda tipo.
///
/// Ekzemple, la granda tabelspeco `[i8; 2]` efektivigas `Unsize<[i8]>` kaj `Unsize<dyn fmt::Debug>`.
///
/// Ĉiuj efektivigoj de `Unsize` estas provizitaj aŭtomate de la kompililo.
///
/// `Unsize` estas efektivigita por:
///
/// - `[T; N]` estas `Unsize<[T]>`
/// - `T` estas `Unsize<dyn Trait>` kiam `T: Trait`
/// - `Foo<..., T, ...>` estas `Unsize<Foo<..., U, ...>>` se:
///   - `T: Unsize<U>`
///   - Foo estas strukturo
///   - Nur la lasta kampo de `Foo` havas tipon kun `T`
///   - `T` ne apartenas al la speco de iuj aliaj kampoj
///   - `Bar<T>: Unsize<Bar<U>>`, se la lasta kampo de `Foo` havas tipon `Bar<T>`
///
/// `Unsize` estas uzata kune kun [`ops::CoerceUnsized`] por permesi al "user-defined"-ujoj kiel [`Rc`] enhavi dinamik-grandajn specojn.
/// Vidu la [DST coercion RFC][RFC982] kaj [the nomicon entry on coercion][nomicon-coerce] por pli da detaloj.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Bezonata trait por konstantoj uzataj en ŝablonaj kongruoj.
///
/// Ĉiu tipo, kiu derivas `PartialEq`, aŭtomate efektivigas ĉi tiun trait, * sendepende de tio, ĉu ĝiaj tipo-parametroj efektivigas `Eq`.
///
/// Se `const`-ero enhavas ian tipon, kiu ne efektivigas ĉi tiun trait, tiam tiu tipo ĉu (1.) ne efektivigas `PartialEq` (kio signifas, ke la konstanto ne provizos tiun komparan metodon, kiu koda generacio supozas, ke ĝi estas disponebla), aŭ (2.), ĝi efektivigas *sian propran* versio de `PartialEq` (kiun ni supozas ne konformas al struktura-egaleca komparo).
///
///
/// En iu el la du supraj scenaroj, ni malakceptas uzadon de tia konstanto en ŝablona kongruo.
///
/// Vidu ankaŭ la [structural match RFC][RFC1445] kaj [issue 63438], kiuj motivis migri de atribut-bazita projekto al ĉi tiu trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Bezonata trait por konstantoj uzataj en ŝablonaj kongruoj.
///
/// Ĉiu tipo, kiu derivas `Eq`, aŭtomate efektivigas ĉi tiun trait, * sendepende de tio, ĉu ĝiaj tipaj parametroj efektivigas `Eq`.
///
/// Ĉi tio estas hako por ĉirkaŭiri limon en nia tipa sistemo.
///
/// # Background
///
/// Ni volas postuli, ke specoj de kontroloj uzataj en ŝablonaj kongruoj havu la atributon `#[derive(PartialEq, Eq)]`.
///
/// En pli ideala mondo, ni povus kontroli tiun postulon nur kontrolante, ke la donita tipo efektivigas kaj la `StructuralPartialEq` trait *kaj* la `Eq` trait.
/// Tamen vi povas havi ADTojn, kiuj *faras*`derive(PartialEq, Eq)`, kaj estu kazo, kiun ni volas, ke la kompililo akceptu, kaj tamen la tipo de la konstanto malsukcesas efektivigi `Eq`.
///
/// Nome tia kazo:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (La problemo en la supra kodo estas, ke `Wrap<fn(&())>` ne efektivigas `PartialEq`, nek `Eq`, ĉar `por <'a> fn(&'a _)` does not implement those traits.)
///
/// Sekve, ni ne povas fidi je naiva kontrolo por `StructuralPartialEq` kaj nura `Eq`.
///
/// Kiel hako por ĉirkaŭiri ĉi tion, ni uzas du apartajn traits injektitajn de ĉiu el la du derivas (`#[derive(PartialEq)]` kaj `#[derive(Eq)]`) kaj kontrolas, ke ambaŭ ĉeestas kiel parto de struktura kongrua kontrolo.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Specoj, kies valoroj povas esti duplikataj simple kopiante bitojn.
///
/// Defaŭlte, variaj ligoj havas 'movu semantikon.'Alivorte:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` translokiĝis al `y`, kaj do ne uzeblas
///
/// // println! ("{: ?}", x);//eraro: uzo de movita valoro
/// ```
///
/// Tamen, se tipo efektivigas `Copy`, ĝi anstataŭe havas 'kopian semantikon':
///
/// ```
/// // Ni povas krei `Copy`-efektivigon.
/// // `Clone` ankaŭ necesas, ĉar ĝi estas supertraito de `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` estas kopio de `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Gravas noti, ke en ĉi tiuj du ekzemploj la sola diferenco estas, ĉu vi rajtas aliri `x` post la tasko.
/// Sub la kapuĉo, kaj kopio kaj movo povas rezultigi kopiojn de bitoj en memoro, kvankam ĉi tio foje estas optimumigita for.
///
/// ## Kiel mi povas efektivigi `Copy`?
///
/// Estas du manieroj efektivigi `Copy` en via tipo.La plej simpla estas uzi `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Vi ankaŭ povas efektivigi `Copy` kaj `Clone` permane:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Estas malgranda diferenco inter ambaŭ: la `derive`-strategio ankaŭ metos `Copy`-binditan sur tipajn parametrojn, kio ne ĉiam estas dezirata.
///
/// ## Kio estas la diferenco inter `Copy` kaj `Clone`?
///
/// Kopioj okazas implicite, ekzemple kiel parto de tasko `y = x`.La konduto de `Copy` ne estas troŝarĝebla;ĝi ĉiam estas simpla iom saĝa kopio.
///
/// Klonado estas eksplicita ago, `x.clone()`.La efektivigo de [`Clone`] povas provizi iun ajn specan konduton necesan por kopii valorojn sekure.
/// Ekzemple, la efektivigo de [`Clone`] por [`String`] bezonas kopii la pint-al-ŝnuran bufron en la amaso.
/// Simpla laŭbita kopio de [`String`]-valoroj nur kopius la montrilon, kondukante al duobla liberigo laŭ la linio.
/// Tial [`String`] estas [`Clone`] sed ne `Copy`.
///
/// [`Clone`] estas supertraito de `Copy`, do ĉio, kio estas `Copy`, devas ankaŭ efektivigi [`Clone`].
/// Se tipo estas `Copy`, tiam ĝia efektivigo [`Clone`] bezonas nur redoni `*self` (vidu la ekzemplon supre).
///
/// ## Kiam mia tipo povas esti `Copy`?
///
/// Tipo povas efektivigi `Copy` se ĉiuj ĝiaj komponentoj efektivigas `Copy`.Ekzemple, ĉi tiu strukturo povas esti `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Struct povas esti `Copy`, kaj [`i32`] estas `Copy`, tial `Point` rajtas esti `Copy`.
/// Kontraste konsideru
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// La strukturo `PointList` ne povas efektivigi `Copy`, ĉar [`Vec<T>`] ne estas `Copy`.Se ni provas krei `Copy`-efektivigon, ni ricevos eraron:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Komunaj referencoj (`&T`) ankaŭ estas `Copy`, do tipo povas esti `Copy`, eĉ kiam ĝi enhavas komunajn referencojn de tipoj `T`, kiuj estas *ne*`Copy`.
/// Konsideru la jenan strukturon, kiu povas efektivigi `Copy`, ĉar ĝi enhavas nur *komunan referencon* al nia ne-Kopio tipo `PointList` de supre:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Kiam *mia* tipo ne povas esti `Copy`?
///
/// Iuj tipoj ne kopieblas sekure.Ekzemple, kopii `&mut T` kreus alinomatan ŝanĝeblan referencon.
/// Kopii [`String`] duobligus respondecon pri administrado de la bufro de [[String]], kio kondukas al duobla senpaga.
///
/// Ĝeneraligante ĉi-lastan kazon, iu ajn tipo efektiviganta [`Drop`] ne povas esti `Copy`, ĉar ĝi administras iun rimedon krom siaj propraj [`size_of::<T>`]-bitokoj.
///
/// Se vi provas efektivigi `Copy` sur strukturo aŭ enumo enhavanta ne-kopiajn datumojn, vi ricevos la eraron [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kiam *mia* tipo estu `Copy`?
///
/// Ĝenerale dirite, se via tipo _can_ efektivigas `Copy`, ĝi devas.
/// Memoru, tamen, ke efektivigado de `Copy` estas parto de la publika API de via tipo.
/// Se la tipo povus fariĝi ne-Kopio en la future, povus esti prudente preterlasi la `Copy`-efektivigon nun, por eviti rompiĝantan API-ŝanĝon.
///
/// ## Pliaj efektivigiloj
///
/// Aldone al la [implementors listed below][impls], la sekvaj specoj ankaŭ efektivigas `Copy`:
///
/// * Funkciaj erospecoj (t.e. la apartaj specoj difinitaj por ĉiu funkcio)
/// * Funkciaj montriloj (ekz., `fn() -> i32`)
/// * Araj tipoj, por ĉiuj grandecoj, se la ero-speco ankaŭ efektivigas `Copy` (ekz. `[i32; 123456]`)
/// * Opoj, se ĉiu ero ankaŭ efektivigas `Copy` (ekz. `()`, `(i32, bool)`)
/// * Fermaj specoj, se ili kaptas neniun valoron de la medio aŭ se ĉiuj tiaj kaptitaj valoroj efektivigas `Copy` mem.
///   Notu, ke variabloj kaptitaj per komuna referenco ĉiam efektivigas `Copy` (eĉ se la referenco ne faras ĝin), dum variabloj kaptitaj per ŝanĝebla referenco neniam efektivigas `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Ĉi tio permesas kopii tipon, kiu ne efektivigas `Copy` pro malkontentaj vivlimoj (kopii `A<'_>` kiam nur `A<'static>: Copy` kaj `A<'_>: Clone`).
// Ni havas ĉi tiun atributon ĉi tie nuntempe nur ĉar ekzistas sufiĉe multaj ekzistantaj specialaĵoj pri `Copy`, kiuj jam ekzistas en la norma biblioteko, kaj ekzistas neniu maniero sekure havi ĉi tiun konduton nun.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Eligu makroon generantan impl de la trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tipoj, por kiuj estas sekure dividi referencojn inter fadenoj.
///
/// Ĉi tiu trait aŭtomate efektiviĝas kiam la kompililo determinas, ke ĝi taŭgas.
///
/// La preciza difino estas: tipo `T` estas [`Sync`] se kaj nur se `&T` estas [`Send`].
/// Alivorte, se ne ekzistas eblo de [undefined behavior][ub] (inkluzive de datumaj vetkuroj) dum pasado de `&T`-referencoj inter fadenoj.
///
/// Kiel oni atendus, primitivaj specoj kiel [`u8`] kaj [`f64`] estas ĉiuj [`Sync`], kaj tiel estas simplaj entutaj tipoj enhavantaj ilin, kiel opoj, strukturoj kaj enumoj.
/// Pli da ekzemploj de bazaj [`Sync`]-specoj inkluzivas "immutable"-specojn kiel `&T`, kaj tiujn kun simpla hereda ŝanĝebleco, kiel [`Box<T>`][box], [`Vec<T>`][vec] kaj plej multaj aliaj kolektaj specoj.
///
/// (Senmarkaj parametroj devas esti [`Sync`] por ke ilia ujo estu [`Sync`].)
///
/// Iom surpriza sekvo de la difino estas, ke `&mut T` estas `Sync` (se `T` estas `Sync`) kvankam ŝajnas, ke tio povus provizi nesinkronigitan mutacion.
/// La lertaĵo estas, ke ŝanĝebla referenco malantaŭ komuna referenco (tio estas, `& &mut T`) fariĝas nurlegebla, kvazaŭ ĝi estus `& &T`.
/// Tial ne ekzistas risko pri datuma vetkuro.
///
/// Tipoj, kiuj ne estas `Sync`, estas tiuj, kiuj havas "interior mutability" en ne-fadena sekura formo, kiel [`Cell`][cell] kaj [`RefCell`][refcell].
/// Ĉi tiuj tipoj permesas mutacion de sia enhavo eĉ per neŝanĝebla, komuna referenco.
/// Ekzemple la `set`-metodo sur [`Cell<T>`][cell] prenas `&self`, do ĝi bezonas nur komunan referencon [`&Cell<T>`][cell].
/// La metodo plenumas neniun sinkronigon, tiel [`Cell`][cell] ne povas esti `Sync`.
///
/// Alia ekzemplo de ne-sincera tipo estas la referenca kalkula montrilo [`Rc`][rc].
/// Konsiderante iun ajn referencon [`&Rc<T>`][rc], vi povas kloni novan [`Rc<T>`][rc], modifante la referencajn kalkulojn ne-atome.
///
/// Por kazoj, kiam oni bezonas faden-sekuran internan ŝanĝeblecon, Rust provizas [atomic data types], kaj ankaŭ eksplicitan ŝlosadon per [`sync::Mutex`][mutex] kaj [`sync::RwLock`][rwlock].
/// Ĉi tiuj tipoj certigas, ke ia ajn mutacio ne povas kaŭzi datumajn vetkurojn, tial la tipoj estas `Sync`.
/// Same, [`sync::Arc`][arc] provizas fadenan sekuran analogon de [`Rc`][rc].
///
/// Ĉiuj specoj kun interna ŝanĝebleco devas ankaŭ uzi la envolvaĵon [`cell::UnsafeCell`][unsafecell] ĉirkaŭ la value(s), kiu povas esti mutaciita per komuna referenco.
/// Malsukcesi fari ĉi tion estas [undefined behavior][ub].
/// Ekzemple, [`transmute`][transmute]-ing de `&T` al `&mut T` estas malvalida.
///
/// Vidu [the Nomicon][nomicon-send-and-sync] por pli da detaloj pri `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): post kiam subteno por aldoni notojn en `rustc_on_unimplemented` alvenas en beta, kaj ĝi estis etendita por kontroli ĉu fermo estas ie ajn en la postula ĉeno, etendu ĝin kiel tia (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nulgranda tipo uzata por marki aferojn, kiujn "act like" ili posedas `T`.
///
/// Aldonado de `PhantomData<T>`-kampo al via tipo diras al la kompililo, ke via tipo funkcias kvazaŭ ĝi konservas valoron de tipo `T`, kvankam ĝi ne vere funkcias.
/// Ĉi tiuj informoj estas uzataj dum komputado de iuj sekurecaj ecoj.
///
/// Por pli profunda klarigo pri kiel uzi `PhantomData<T>`, bonvolu vidi [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Terura noto 👻👻👻
///
/// Kvankam ili ambaŭ havas timigajn nomojn, `PhantomData` kaj "fantomaj tipoj" rilatas, sed ne identas.Fantoma tipo-parametro estas simple tipo-parametro, kiu neniam estas uzata.
/// En Rust, ĉi tio ofte kaŭzas la kompililon plendi, kaj la solvo estas aldoni "dummy"-uzon per `PhantomData`.
///
/// # Examples
///
/// ## Neuzataj dumvivaj parametroj
///
/// Eble la plej ofta uzokazo por `PhantomData` estas strukturo, kiu havas neuzatan dumvivan parametron, tipe kiel parto de iu nesekura kodo.
/// Ekzemple, jen strukt `Slice`, kiu havas du montrilojn de tipo `*const T`, supozeble montrantaj al tabelo ie:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// La intenco estas, ke la subaj datumoj validas nur dum la tuta vivo `'a`, do `Slice` ne devas postvivi `'a`.
/// Tamen ĉi tiu intenco ne estas esprimita en la kodo, ĉar ne ekzistas uzoj de la dumviva `'a` kaj tial ne estas klare, al kiuj datumoj ĝi aplikiĝas.
/// Ni povas korekti tion dirante al la kompililo agi *kvazaŭ* la strukturo `Slice` enhavus referencon `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Ĉi tio ankaŭ siavice postulas la komentadon `T: 'a`, indikante ke iuj referencoj en `T` validas dum la tuta vivo `'a`.
///
/// Kiam vi pravalorizas `Slice`, vi simple donas la valoron `PhantomData` por la kampo `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Neuzataj tipparametroj
///
/// Iafoje okazas, ke vi havas neuzatajn tipajn parametrojn, kiuj indikas al kia datumaro strukt estas "tied", kvankam tiuj datumoj ne efektive troviĝas en la struct mem.
/// Jen ekzemplo, kie ĉi tio okazas kun [FFI].
/// La fremda interfaco uzas tenilojn de tipo `*mut ()` por raporti al Rust-valoroj de malsamaj tipoj.
/// Ni spuras la tipon Rust per fantoma tipo-parametro sur la strukt `ExternalResource`, kiu envolvas tenilon.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Posedo kaj faliga kontrolo
///
/// Aldonado de kampo de tipo `PhantomData<T>` indikas, ke via tipo posedas datumojn de tipo `T`.Ĉi tio laŭvice implicas, ke kiam via tipo falas, ĝi povas faligi unu aŭ plurajn kazojn de la tipo `T`.
/// Ĉi tio koncernas la [drop check]-analizon de la kompililo Rust.
///
/// Se via strukturo fakte *ne posedas* la datumojn de tipo `T`, estas pli bone uzi referencan tipon, kiel `PhantomData<&'a T>` (ideally) aŭ `PhantomData<*const T>` (se neniu vivdaŭro validas), por ne indiki posedon.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Kompila-interna trait kutimis indiki la specon de enum-diskriminantoj.
///
/// Ĉi tiu trait estas aŭtomate efektivigita por ĉiu tipo kaj ne aldonas garantiojn al [`mem::Discriminant`].
/// Estas **nedifinita konduto** transmutiĝi inter `DiscriminantKind::Discriminant` kaj `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// La tipo de la diskriminanto, kiu devas kontentigi la trait bounds postulitan de `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Kompila-interna trait kutimis determini ĉu tipo enhavas ian `UnsafeCell` interne, sed ne per malrekta direkto.
///
/// Ĉi tio efikas, ekzemple, ĉu `static` de tiu tipo estas metita en nurlegeblan statikan memoron aŭ skribeblan statikan memoron.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Tipoj, kiuj povas sekure moviĝi post esti alpinglitaj.
///
/// Rust mem havas neniun nocion de nemoveblaj specoj, kaj konsideras movojn (ekz. Per tasko aŭ [`mem::replace`]) ĉiam sekuraj.
///
/// La tipo [`Pin`][Pin] estas uzata anstataŭe por malebligi movojn tra la tipa sistemo.Montriloj `P<T>` envolvitaj en la envolvaĵo [`Pin<P<T>>`][Pin] ne povas esti movitaj eksteren.
/// Vidu la [`pin` module]-dokumentaron por pliaj informoj pri alpinglado.
///
/// Efektivigi la `Unpin` trait por `T` ĉesigas la limojn alpingli la tipon, kio tiam permesas movi `T` el [`Pin<P<T>>`][Pin] kun funkcioj kiel [`mem::replace`].
///
///
/// `Unpin` tute ne havas sekvon por ne-alpinglitaj datumoj.
/// Aparte, [`mem::replace`] feliĉe movas `!Unpin`-datumojn (ĝi funkcias por iu `&mut T`, ne nur kiam `T: Unpin`).
/// Tamen vi ne povas uzi [`mem::replace`] sur datumoj envolvitaj en [`Pin<P<T>>`][Pin] ĉar vi ne povas akiri la `&mut T`, kiun vi bezonas por tio, kaj *tio* estas tio, kio funkcias ĉi tiun sistemon.
///
/// Do ĉi tio ekzemple povas esti farita nur ĉe tipoj efektivigantaj `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Ni bezonas ŝanĝeblan referencon por voki `mem::replace`.
/// // Ni povas akiri tian referencon per (implicitly) alvokante `Pin::deref_mut`, sed tio eblas nur ĉar `String` efektivigas `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Ĉi tiu trait estas aŭtomate efektivigita por preskaŭ ĉiu tipo.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Markila tipo, kiu ne efektivigas `Unpin`.
///
/// Se tipo enhavas `PhantomPinned`, ĝi ne efektivigos `Unpin` defaŭlte.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Efektivigoj de `Copy` por primitivaj tipoj.
///
/// Efektivigoj, kiuj ne povas esti priskribitaj en Rust, estas efektivigitaj en `traits::SelectionContext::copy_clone_conditions()` en `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Komunaj referencoj povas esti kopiitaj, sed ŝanĝeblaj referencoj *ne povas*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}