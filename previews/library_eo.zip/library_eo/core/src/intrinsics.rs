//! Kompililo interna.
//!
//! La respondaj difinoj estas en `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! La respondaj konst efektivigoj estas en `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsics
//!
//! Note: iuj ajn ŝanĝoj al la konstanteco de internuloj devas esti diskutitaj kun la lingva teamo.
//! Ĉi tio inkluzivas ŝanĝojn en la stabileco de la konstanteco.
//!
//! Por fari internan uzeblan dum kompila tempo, oni bezonas kopii la efektivigon de <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> al `compiler/rustc_mir/src/interpret/intrinsics.rs` kaj aldoni `#[rustc_const_unstable(feature = "foo", issue = "01234")]` al la interna.
//!
//!
//! Se interna estas supozeble uzata de `const fn` kun `rustc_const_stable`-atributo, ankaŭ la propra atributo devas esti `rustc_const_stable`.
//! Tia ŝanĝo ne estu farita sen T-lang-konsulto, ĉar ĝi bakas trajton en la lingvon, kiu ne povas esti reproduktita en uzanta kodo sen kompilila subteno.
//!
//! # Volatiles
//!
//! La volatilaj internaĵoj provizas operaciojn intencitajn por agi sur I/O-memoro, kiuj estas garantiitaj ne reordigitaj de la kompililo tra aliaj volatilaj internaj.Vidu la dokumentaron pri LLVM pri [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! La atomaj internoj provizas oftajn atomajn operaciojn sur maŝinaj vortoj, kun multnombraj eblaj memordoj.Ili obeas la saman semantikon kiel C++ 11.Vidu la dokumentaron pri LLVM pri [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Rapida renovigo pri memordono:
//!
//! * Akiri, baron por akiri seruron.Postaj legaĵoj kaj skribaĵoj okazas post la baro.
//! * Liberigo, baro por liberigi seruron.Antaŭaj legaĵoj kaj skribaĵoj okazas antaŭ la baro.
//! * Sinsekve konsekvencaj, sinsekve konsekvencaj operacioj estas garantiitaj okazi en ordo.Ĉi tiu estas la norma reĝimo por labori kun atomaj tipoj kaj ekvivalentas al `volatile` de Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Ĉi tiuj importadoj estas uzataj por simpligi ligojn intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SEKURECO: vidu `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, ĉi tiuj internaj programoj prenas krudajn montrilojn, ĉar ili mutas kaŝnomitan memoron, kiu ne validas por `&` aŭ `&mut`.
    //

    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-specoj per la `compare_exchange`-metodo per pasigado de [`Ordering::SeqCst`] kiel ambaŭ la `success` kaj `failure`-parametroj.
    ///
    /// Ekzemple, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-specoj per la `compare_exchange`-metodo per pasigado de [`Ordering::Acquire`] kiel ambaŭ la `success` kaj `failure`-parametroj.
    ///
    /// Ekzemple, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `compare_exchange`-metodo per pasigado de [`Ordering::Release`] kiel la `success` kaj [`Ordering::Relaxed`] kiel la `failure`-parametroj.
    /// Ekzemple, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `compare_exchange`-metodo per pasigado de [`Ordering::AcqRel`] kiel la `success` kaj [`Ordering::Acquire`] kiel la `failure`-parametroj.
    /// Ekzemple, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-specoj per la `compare_exchange`-metodo per pasigado de [`Ordering::Relaxed`] kiel ambaŭ la `success` kaj `failure`-parametroj.
    ///
    /// Ekzemple, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `compare_exchange`-metodo per pasigado de [`Ordering::SeqCst`] kiel la `success` kaj [`Ordering::Relaxed`] kiel la `failure`-parametroj.
    /// Ekzemple, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `compare_exchange`-metodo per pasigado de [`Ordering::SeqCst`] kiel la `success` kaj [`Ordering::Acquire`] kiel la `failure`-parametroj.
    /// Ekzemple, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `compare_exchange`-metodo per pasigado de [`Ordering::Acquire`] kiel la `success` kaj [`Ordering::Relaxed`] kiel la `failure`-parametroj.
    /// Ekzemple, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `compare_exchange`-metodo per pasigado de [`Ordering::AcqRel`] kiel la `success` kaj [`Ordering::Relaxed`] kiel la `failure`-parametroj.
    /// Ekzemple, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-specoj per la `compare_exchange_weak`-metodo per pasigado de [`Ordering::SeqCst`] kiel ambaŭ la `success` kaj `failure`-parametroj.
    ///
    /// Ekzemple, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-specoj per la `compare_exchange_weak`-metodo per pasigado de [`Ordering::Acquire`] kiel ambaŭ la `success` kaj `failure`-parametroj.
    ///
    /// Ekzemple, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `compare_exchange_weak`-metodo per pasigado de [`Ordering::Release`] kiel la `success` kaj [`Ordering::Relaxed`] kiel la `failure`-parametroj.
    /// Ekzemple, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `compare_exchange_weak`-metodo per pasigado de [`Ordering::AcqRel`] kiel la `success` kaj [`Ordering::Acquire`] kiel la `failure`-parametroj.
    /// Ekzemple, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-specoj per la `compare_exchange_weak`-metodo per pasigado de [`Ordering::Relaxed`] kiel ambaŭ la `success` kaj `failure`-parametroj.
    ///
    /// Ekzemple, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `compare_exchange_weak`-metodo per pasigado de [`Ordering::SeqCst`] kiel la `success` kaj [`Ordering::Relaxed`] kiel la `failure`-parametroj.
    /// Ekzemple, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `compare_exchange_weak`-metodo per pasigado de [`Ordering::SeqCst`] kiel la `success` kaj [`Ordering::Acquire`] kiel la `failure`-parametroj.
    /// Ekzemple, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `compare_exchange_weak`-metodo per pasigado de [`Ordering::Acquire`] kiel la `success` kaj [`Ordering::Relaxed`] kiel la `failure`-parametroj.
    /// Ekzemple, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stokas valoron se la nuna valoro samas al la `old`-valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `compare_exchange_weak`-metodo per pasigado de [`Ordering::AcqRel`] kiel la `success` kaj [`Ordering::Relaxed`] kiel la `failure`-parametroj.
    /// Ekzemple, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Ŝarĝas la nunan valoron de la montrilo.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `load`-metodo pasante [`Ordering::SeqCst`] kiel `order`.
    /// Ekzemple, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Ŝarĝas la nunan valoron de la montrilo.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `load`-metodo pasante [`Ordering::Acquire`] kiel `order`.
    /// Ekzemple, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Ŝarĝas la nunan valoron de la montrilo.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `load`-metodo pasante [`Ordering::Relaxed`] kiel `order`.
    /// Ekzemple, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Stokas la valoron ĉe la specifa memora loko.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `store`-metodo pasante [`Ordering::SeqCst`] kiel `order`.
    /// Ekzemple, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Stokas la valoron ĉe la specifa memora loko.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `store`-metodo pasante [`Ordering::Release`] kiel `order`.
    /// Ekzemple, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Stokas la valoron ĉe la specifa memora loko.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `store`-metodo pasante [`Ordering::Relaxed`] kiel `order`.
    /// Ekzemple, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Stokas la valoron ĉe la specifa memora loko, redonante la malnovan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `swap`-metodo pasante [`Ordering::SeqCst`] kiel `order`.
    /// Ekzemple, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stokas la valoron ĉe la specifa memora loko, redonante la malnovan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `swap`-metodo pasante [`Ordering::Acquire`] kiel `order`.
    /// Ekzemple, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stokas la valoron ĉe la specifa memora loko, redonante la malnovan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `swap`-metodo pasante [`Ordering::Release`] kiel `order`.
    /// Ekzemple, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stokas la valoron ĉe la specifa memora loko, redonante la malnovan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `swap`-metodo pasante [`Ordering::AcqRel`] kiel `order`.
    /// Ekzemple, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stokas la valoron ĉe la specifa memora loko, redonante la malnovan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `swap`-metodo pasante [`Ordering::Relaxed`] kiel `order`.
    /// Ekzemple, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Aldonas al la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_add`-metodo pasante [`Ordering::SeqCst`] kiel `order`.
    /// Ekzemple, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aldonas al la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_add`-metodo pasante [`Ordering::Acquire`] kiel `order`.
    /// Ekzemple, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aldonas al la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_add`-metodo pasante [`Ordering::Release`] kiel `order`.
    /// Ekzemple, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aldonas al la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_add`-metodo pasante [`Ordering::AcqRel`] kiel `order`.
    /// Ekzemple, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aldonas al la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_add`-metodo pasante [`Ordering::Relaxed`] kiel `order`.
    /// Ekzemple, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Subtrahu de la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_sub`-metodo pasante [`Ordering::SeqCst`] kiel `order`.
    /// Ekzemple, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtrahu de la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_sub`-metodo pasante [`Ordering::Acquire`] kiel `order`.
    /// Ekzemple, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtrahu de la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_sub`-metodo pasante [`Ordering::Release`] kiel `order`.
    /// Ekzemple, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtrahu de la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_sub`-metodo pasante [`Ordering::AcqRel`] kiel `order`.
    /// Ekzemple, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtrahu de la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_sub`-metodo pasante [`Ordering::Relaxed`] kiel `order`.
    /// Ekzemple, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bito kaj kun la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_and`-metodo pasante [`Ordering::SeqCst`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bito kaj kun la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_and`-metodo pasante [`Ordering::Acquire`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bito kaj kun la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_and`-metodo pasante [`Ordering::Release`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bito kaj kun la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_and`-metodo pasante [`Ordering::AcqRel`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bito kaj kun la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_and`-metodo pasante [`Ordering::Relaxed`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pice bite nand kun la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`AtomicBool`]-speco per la `fetch_nand`-metodo pasante [`Ordering::SeqCst`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pice bite nand kun la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`AtomicBool`]-speco per la `fetch_nand`-metodo pasante [`Ordering::Acquire`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pice bite nand kun la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`AtomicBool`]-speco per la `fetch_nand`-metodo pasante [`Ordering::Release`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pice bite nand kun la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`AtomicBool`]-speco per la `fetch_nand`-metodo pasante [`Ordering::AcqRel`] kiel la `order`.
    /// Ekzemple, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pice bite nand kun la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`AtomicBool`]-speco per la `fetch_nand`-metodo pasante [`Ordering::Relaxed`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bito aŭ kun la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_or`-metodo pasante [`Ordering::SeqCst`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bito aŭ kun la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_or`-metodo pasante [`Ordering::Acquire`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bito aŭ kun la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_or`-metodo pasante [`Ordering::Release`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bito aŭ kun la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_or`-metodo pasante [`Ordering::AcqRel`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bito aŭ kun la nuna valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_or`-metodo pasante [`Ordering::Relaxed`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pecite xor kun la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_xor`-metodo pasante [`Ordering::SeqCst`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pecite xor kun la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_xor`-metodo pasante [`Ordering::Acquire`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pecite xor kun la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_xor`-metodo pasante [`Ordering::Release`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pecite xor kun la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_xor`-metodo pasante [`Ordering::AcqRel`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pecite xor kun la aktuala valoro, redonante la antaŭan valoron.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas ĉe la [`atomic`]-specoj per la `fetch_xor`-metodo pasante [`Ordering::Relaxed`] kiel `order`.
    /// Ekzemple, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimumo kun la aktuala valoro per subskribita komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-subskribitaj entjeraj tipoj per la `fetch_max`-metodo pasante [`Ordering::SeqCst`] kiel `order`.
    /// Ekzemple, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumo kun la aktuala valoro per subskribita komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-subskribitaj entjeraj tipoj per la `fetch_max`-metodo pasante [`Ordering::Acquire`] kiel `order`.
    /// Ekzemple, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumo kun la aktuala valoro per subskribita komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-subskribitaj entjeraj tipoj per la `fetch_max`-metodo pasante [`Ordering::Release`] kiel `order`.
    /// Ekzemple, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumo kun la aktuala valoro per subskribita komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-subskribitaj entjeraj tipoj per la `fetch_max`-metodo pasante [`Ordering::AcqRel`] kiel `order`.
    /// Ekzemple, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumo kun la nuna valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-subskribitaj entjeraj tipoj per la `fetch_max`-metodo pasante [`Ordering::Relaxed`] kiel `order`.
    /// Ekzemple, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimumo kun la aktuala valoro per subskribita komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-subskribitaj entjeraj tipoj per la `fetch_min`-metodo pasante [`Ordering::SeqCst`] kiel `order`.
    /// Ekzemple, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumo kun la aktuala valoro per subskribita komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-subskribitaj entjeraj tipoj per la `fetch_min`-metodo pasante [`Ordering::Acquire`] kiel `order`.
    /// Ekzemple, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumo kun la aktuala valoro per subskribita komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-subskribitaj entjeraj tipoj per la `fetch_min`-metodo pasante [`Ordering::Release`] kiel `order`.
    /// Ekzemple, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumo kun la aktuala valoro per subskribita komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-subskribitaj entjeraj tipoj per la `fetch_min`-metodo pasante [`Ordering::AcqRel`] kiel `order`.
    /// Ekzemple, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumo kun la aktuala valoro per subskribita komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-subskribitaj entjeraj tipoj per la `fetch_min`-metodo pasante [`Ordering::Relaxed`] kiel `order`.
    /// Ekzemple, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimumo kun la aktuala valoro per sennoma komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-sennomaj entjeraj tipoj per la `fetch_min`-metodo pasante [`Ordering::SeqCst`] kiel `order`.
    /// Ekzemple, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumo kun la aktuala valoro per sennoma komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-sennomaj entjeraj tipoj per la `fetch_min`-metodo pasante [`Ordering::Acquire`] kiel `order`.
    /// Ekzemple, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumo kun la aktuala valoro per sennoma komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-sennomaj entjeraj tipoj per la `fetch_min`-metodo pasante [`Ordering::Release`] kiel `order`.
    /// Ekzemple, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumo kun la aktuala valoro per sennoma komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-sennomaj entjeraj tipoj per la `fetch_min`-metodo pasante [`Ordering::AcqRel`] kiel `order`.
    /// Ekzemple, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumo kun la aktuala valoro per sennoma komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-sennomaj entjeraj tipoj per la `fetch_min`-metodo pasante [`Ordering::Relaxed`] kiel `order`.
    /// Ekzemple, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimumo kun la aktuala valoro per sennoma komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-sennomaj entjeraj tipoj per la `fetch_max`-metodo pasante [`Ordering::SeqCst`] kiel `order`.
    /// Ekzemple, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumo kun la aktuala valoro per sennoma komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-sennomaj entjeraj tipoj per la `fetch_max`-metodo pasante [`Ordering::Acquire`] kiel `order`.
    /// Ekzemple, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumo kun la aktuala valoro per sennoma komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-sennomaj entjeraj tipoj per la `fetch_max`-metodo pasante [`Ordering::Release`] kiel `order`.
    /// Ekzemple, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumo kun la aktuala valoro per sennoma komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-sennomaj entjeraj tipoj per la `fetch_max`-metodo pasante [`Ordering::AcqRel`] kiel `order`.
    /// Ekzemple, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumo kun la aktuala valoro per sennoma komparo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas havebla ĉe la [`atomic`]-sennomaj entjeraj tipoj per la `fetch_max`-metodo pasante [`Ordering::Relaxed`] kiel `order`.
    /// Ekzemple, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// La propra `prefetch` estas aludo al la kodgenerilo por enmeti antaŭprograman instrukcion se subtenite;alie, ĝi estas senoperativa operacio.
    /// Prefetches havas neniun efikon al la konduto de la programo, sed povas ŝanĝi ĝiajn agadajn karakterizaĵojn.
    ///
    /// La argumento `locality` devas esti konstanta entjero kaj estas tempa loka specifilo, kiu iras de (0), sen loko, ĝis (3), tre loka konservado en kaŝmemoro.
    ///
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// La propra `prefetch` estas aludo al la kodgenerilo por enmeti antaŭprograman instrukcion se subtenite;alie, ĝi estas senoperativa operacio.
    /// Prefetches havas neniun efikon al la konduto de la programo, sed povas ŝanĝi ĝiajn agadajn karakterizaĵojn.
    ///
    /// La argumento `locality` devas esti konstanta entjero kaj estas tempa loka specifilo, kiu iras de (0), sen loko, ĝis (3), tre loka konservado en kaŝmemoro.
    ///
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// La propra `prefetch` estas aludo al la kodgenerilo por enmeti antaŭprograman instrukcion se subtenite;alie, ĝi estas senoperativa operacio.
    /// Prefetches havas neniun efikon al la konduto de la programo, sed povas ŝanĝi ĝiajn agadajn karakterizaĵojn.
    ///
    /// La argumento `locality` devas esti konstanta entjero kaj estas tempa loka specifilo, kiu iras de (0), sen loko, ĝis (3), tre loka konservado en kaŝmemoro.
    ///
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// La propra `prefetch` estas aludo al la kodgenerilo por enmeti antaŭprograman instrukcion se subtenite;alie, ĝi estas senoperativa operacio.
    /// Prefetches havas neniun efikon al la konduto de la programo, sed povas ŝanĝi ĝiajn agadajn karakterizaĵojn.
    ///
    /// La argumento `locality` devas esti konstanta entjero kaj estas tempa loka specifilo, kiu iras de (0), sen loko, ĝis (3), tre loka konservado en kaŝmemoro.
    ///
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Atoma barilo.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas en [`atomic::fence`] per [`Ordering::SeqCst`] kiel `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Atoma barilo.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas en [`atomic::fence`] per [`Ordering::Acquire`] kiel `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Atoma barilo.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas en [`atomic::fence`] per [`Ordering::Release`] kiel `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Atoma barilo.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas en [`atomic::fence`] per [`Ordering::AcqRel`] kiel `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Memorkombilo nur kompilebla.
    ///
    /// Memoraj aliroj neniam estos ordigitaj trans ĉi tiun baron de la kompililo, sed neniuj instrukcioj estos elsenditaj por ĝi.
    /// Ĉi tio taŭgas por operacioj sur la sama fadeno, kiuj povas esti malhelpataj, kiel interagado kun signalaj prizorgantoj.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas en [`atomic::compiler_fence`] per [`Ordering::SeqCst`] kiel `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Memorkombilo nur kompilebla.
    ///
    /// Memoraj aliroj neniam estos ordigitaj trans ĉi tiun baron de la kompililo, sed neniuj instrukcioj estos elsenditaj por ĝi.
    /// Ĉi tio taŭgas por operacioj sur la sama fadeno, kiuj povas esti malhelpataj, kiel interagado kun signalaj prizorgantoj.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas en [`atomic::compiler_fence`] per [`Ordering::Acquire`] kiel `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Memorkombilo nur kompilebla.
    ///
    /// Memoraj aliroj neniam estos ordigitaj trans ĉi tiun baron de la kompililo, sed neniuj instrukcioj estos elsenditaj por ĝi.
    /// Ĉi tio taŭgas por operacioj sur la sama fadeno, kiuj povas esti malhelpataj, kiel interagado kun signalaj prizorgantoj.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas en [`atomic::compiler_fence`] per [`Ordering::Release`] kiel `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Memorkombilo nur kompilebla.
    ///
    /// Memoraj aliroj neniam estos ordigitaj trans ĉi tiun baron de la kompililo, sed neniuj instrukcioj estos elsenditaj por ĝi.
    /// Ĉi tio taŭgas por operacioj sur la sama fadeno, kiuj povas esti malhelpataj, kiel interagado kun signalaj prizorgantoj.
    ///
    /// La stabiligita versio de ĉi tiu propra disponeblas en [`atomic::compiler_fence`] per [`Ordering::AcqRel`] kiel `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magio interna, kiu derivas sian signifon de atributoj ligitaj al la funkcio.
    ///
    /// Ekzemple, datumfluo uzas ĉi tion por injekti statikajn asertojn, tiel ke `rustc_peek(potentially_uninitialized)` efektive kontrolus, ke datumfluo efektive kalkulis, ke ĝi estas neinicialigita en tiu punkto en la kontrolfluo.
    ///
    ///
    /// Ĉi tiu propra ne devas esti uzata ekster la kompililo.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Ĉesigas la plenumon de la procezo.
    ///
    /// Pli uzebla kaj stabila versio de ĉi tiu operacio estas [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informas la optimumigilon, ke ĉi tiu punkto en la kodo ne estas atingebla, ebligante pliajn optimumigojn.
    ///
    /// NB, ĉi tio tre diferencas de la makroo `unreachable!()`: Kontraste kun la makroo, kiun panics kiam ĝi plenumas, estas *nedifinita konduto* atingi kodon markitan per ĉi tiu funkcio.
    ///
    ///
    /// La stabiligita versio de ĉi tiu propra estas [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informas la optimumiganton, ke kondiĉo estas ĉiam vera.
    /// Se la kondiĉo estas falsa, la konduto estas nedifinita.
    ///
    /// Neniu kodo estas generita por ĉi tiu propra, sed la optimumigilo provos konservi ĝin (kaj ĝian staton) inter enirpermesiloj, kiuj povas malhelpi optimumigon de ĉirkaŭa kodo kaj malpliigi rendimenton.
    /// Ĝi ne estu uzata se la invarianto povas esti malkovrita de la optimumigilo memstare, aŭ se ĝi ne ebligas signifajn optimumigojn.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Aludoj al la kompililo, ke branch-kondiĉo probable veras.
    /// Liveras la valoron transdonitan al ĝi.
    ///
    /// Ajna uzo krom kun `if`-asertoj probable ne efikos.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Aludoj al la kompililo, ke branch-kondiĉo probable estas falsa.
    /// Liveras la valoron transdonitan al ĝi.
    ///
    /// Ajna uzo krom kun `if`-asertoj probable ne efikos.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Ekzekutas rompopunktan kaptilon, por inspektado de erarserĉilo.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    pub fn breakpoint();

    /// La grandeco de tipo en bajtoj.
    ///
    /// Pli specife, ĉi tio estas la ofseto en bajtoj inter pluaj samspecaj eroj, inkluzive de viciga kompletigo.
    ///
    ///
    /// La stabiligita versio de ĉi tiu propra estas [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// La minimuma vicigo de tipo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// La preferata vicigo de tipo.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// La grandeco de la referenca valoro en bajtoj.
    ///
    /// La stabiligita versio de ĉi tiu propra estas [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// La postulata vicigo de la referenca valoro.
    ///
    /// La stabiligita versio de ĉi tiu propra estas [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Akiras statikan ĉenan tranĉaĵon enhavantan la nomon de tipo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Akiras identigilon, kiu estas tutmonde unika al la specifa tipo.
    /// Ĉi tiu funkcio redonos la saman valoron por tipo sendepende de kiu ajn crate ĝi estas alvokita.
    ///
    ///
    /// La stabiligita versio de ĉi tiu propra estas [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Gardisto por nesekuraj funkcioj, kiuj neniam povas esti plenumitaj se `T` estas neloĝata:
    /// Ĉi tio statike aŭ panic, aŭ faros nenion.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Gardisto por nesekuraj funkcioj, kiuj neniam povas esti plenumitaj se `T` ne permesas nul-inicialigon: Ĉi tio statike aŭ panic, aŭ faros nenion.
    ///
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    pub fn assert_zero_valid<T>();

    /// Gardisto por nesekuraj funkcioj, kiuj neniam povas esti plenumitaj se `T` havas malvalidajn bitajn ŝablonojn: Ĉi tio statike aŭ panic, aŭ faros nenion.
    ///
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    pub fn assert_uninit_valid<T>();

    /// Akiras referencon al statika `Location` indikanta kie ĝi estis vokita.
    ///
    /// Pripensu uzi anstataŭe [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Forigas valoron ekster la amplekso sen lanĉi gutgluon.
    ///
    /// Ĉi tio ekzistas nur por [`mem::forget_unsized`];normala `forget` uzas `ManuallyDrop` anstataŭe.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterpretas la bitojn de valoro de unu tipo kiel alia tipo.
    ///
    /// Ambaŭ tipoj devas havi la saman grandecon.
    /// Nek la originalo, nek la rezulto, povas esti [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` semantike ekvivalentas al iombita movo de unu tipo en alian.Ĝi kopias la bitojn de la fonta valoro en la celan valoron, tiam forgesas la originalon.
    /// Ĝi samvaloras al C's `memcpy` sub la kapuĉo, same kiel `transmute_copy`.
    ///
    /// Ĉar `transmute` estas kromvalora operacio, vicigo de la *transmutitaj valoroj mem* ne zorgas.
    /// Kiel kun iu ajn alia funkcio, la kompililo jam certigas, ke ambaŭ `T` kaj `U` estas ĝuste vicigitaj.
    /// Tamen, dum transmutado de valoroj, kiuj *montras aliloke*(kiel montriloj, referencoj, skatoloj ...), la alvokanto devas certigi taŭgan vicigon de la montritaj valoroj.
    ///
    /// `transmute` estas **nekredeble** nesekura.Estas multe da manieroj kaŭzi [undefined behavior][ub] per ĉi tiu funkcio.`transmute` devas esti la absoluta lasta rimedo.
    ///
    /// La [nomicon](../../nomicon/transmutes.html) havas aldonan dokumentadon.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Estas kelkaj aferoj, por kiuj `transmute` vere utilas.
    ///
    /// Transformi montrilon en funkcian montrilon.Ĉi tio estas *ne* portebla al maŝinoj, kie funkciaj montriloj kaj datumaj montriloj havas malsamajn grandecojn.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Plilongigi vivdaŭron, aŭ mallongigi senŝanĝan vivdaŭron.Ĉi tio estas progresinta, tre nesekura Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ne malesperu: multaj uzoj de `transmute` atingeblas per aliaj rimedoj.
    /// Malsupre estas oftaj aplikoj de `transmute`, kiuj povas esti anstataŭigitaj per pli sekuraj konstruaĵoj.
    ///
    /// Turni krudan bytes(`&[u8]`) al `u32`, `f64`, ktp:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // uzu `u32::from_ne_bytes` anstataŭe
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // aŭ uzu `u32::from_le_bytes` aŭ `u32::from_be_bytes` por specifi la endianecon
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Transformi montrilon al `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Uzu `as`-rolantaron anstataŭe
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Transformi `*mut T` en `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Uzu anstataŭprunton anstataŭe
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Transformi `&mut T` en `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Nun kunmetu `as` kaj reborrowing, rimarku, ke la ĉeno de `as` `as` ne estas transitiva
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Transformi `&str` en `&[u8]`:
    ///
    /// ```
    /// // ĉi tio ne estas bona maniero fari ĉi tion.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Vi povus uzi `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Aŭ, simple uzu bajtan ĉenon, se vi regas la ĉenon laŭvorte
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Transformi `Vec<&T>` en `Vec<Option<&T>>`.
    ///
    /// Por transmutacii la internan tipon de la enhavo de ujo, vi devas certiĝi ne malobservi iujn el la invariantoj de la ujo.
    /// Por `Vec`, ĉi tio signifas, ke ambaŭ la grandeco *kaj vicigo* de la internaj tipoj devas kongrui.
    /// Aliaj ujoj povus dependi de la grandeco de la tipo, vicigo aŭ eĉ de la `TypeId`, tiaokaze transmutado tute ne eblus sen malobservi la ujajn invariantojn.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // klonu la vector ĉar ni reuzos ilin poste
    /// let v_clone = v_orig.clone();
    ///
    /// // Uzante transmuton: ĉi tio dependas de la nespecifita datuma aranĝo de `Vec`, kio estas malbona ideo kaj povus kaŭzi Nedifinitan Konduton.
    /////
    /// // Tamen ĝi estas ne-kopia.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Jen la sugestita, sekura maniero.
    /// // Ĝi tamen kopias la tutan vector en novan tabelon.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ĉi tiu estas la taŭga senkopia, nesekura maniero de "transmuting" a `Vec`, sen fidi la datuman aranĝon.
    /// // Anstataŭ laŭvorte voki `transmute`, ni plenumas montrilon, sed rilate al konverti la originalan internan tipon (`&i32`) al la nova (`Option<&i32>`), ĉi tio havas la samajn avertojn.
    /////
    /// // Krom la supre donitaj informoj, konsultu ankaŭ la dokumentaron [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Ĝisdatigu ĉi tion kiam vec_into_raw_parts estas stabiligita.
    ///     // Certigu, ke la originala vector ne falas.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Efektiviganta `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Estas multaj manieroj fari ĉi tion, kaj estas multaj problemoj kun la sekva (transmute)-maniero.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // unue: transmute ne estas tajpa;ĉio, kion ĝi kontrolas, estas ke T kaj
    ///         // U estas samgrandaj.
    ///         // Due, ĝuste ĉi tie, vi havas du ŝanĝeblajn referencojn al la sama memoro.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ĉi tio forigas la tipajn sekurecajn problemojn;`&mut *`* nur *donos al vi `&mut T` de `&mut T` aŭ `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // tamen vi ankoraŭ havas du ŝanĝeblajn referencojn al la sama memoro.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Tiel la norma biblioteko faras ĝin.
    /// // Ĉi tiu estas la plej bona metodo, se vi bezonas fari ion tian
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Ĉi tio nun havas tri ŝanĝeblajn referencojn direktitajn al la sama memoro.`slice`, la valoro ret.0, kaj la valoro ret.1.
    ///         // `slice` neniam estas uzata post `let ptr = ...`, do oni povas trakti ĝin kiel "dead", kaj tial vi havas nur du verajn ŝanĝeblajn tranĉaĵojn.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Dum ĉi tio stabiligas la internan konstanton, ni havas iom da kutimo en konst fn
    // kontroloj, kiuj malebligas ĝian uzon ene de `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Liveras `true` se la efektiva tipo donita kiel `T` postulas faligan gluon;redonas `false` se la efektiva tipo provizita por `T` efektivigas `Copy`.
    ///
    ///
    /// Se la efektiva tipo nek postulas faligan gluon nek efektivigas `Copy`, tiam la revenvaloro de ĉi tiu funkcio estas nespecifita.
    ///
    /// La stabiligita versio de ĉi tiu propra estas [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Kalkulas la ofseton de montrilo.
    ///
    /// Ĉi tio estas efektivigita kiel interna por eviti konvertiĝon al kaj de entjero, ĉar la konvertiĝo forĵetus kaŝnomajn informojn.
    ///
    /// # Safety
    ///
    /// Ambaŭ la komenca kaj rezulta montrilo devas esti aŭ en limoj aŭ unu bajto preter la fino de asignita objekto.
    /// Se ĉiu montrilo estas ekster limoj aŭ okazas aritmetika superfluaĵo, tiam plia uzo de la redonita valoro rezultigos nedifinitan konduton.
    ///
    ///
    /// La stabiligita versio de ĉi tiu propra estas [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Kalkulas la ofseton de montrilo, eble envolvanta.
    ///
    /// Ĉi tio estas efektivigita kiel interna por eviti konvertiĝon al kaj de entjero, ĉar la konvertiĝo malhelpas iujn optimumigojn.
    ///
    /// # Safety
    ///
    /// Male al la `offset`-interna, ĉi tiu propra ne limigas la rezultan montrilon al punkto aŭ unu bajto preter la fino de asignita objekto, kaj ĝi envolvas kun du-komplementa aritmetiko.
    /// La rezulta valoro ne nepre validas por esti uzata por vere aliri memoron.
    ///
    /// La stabiligita versio de ĉi tiu propra estas [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ekvivalenta al la taŭga `llvm.memcpy.p0i8.0i8.*`-interna, kun grandeco de `count`*`size_of::<T>()` kaj vicigo de
    ///
    /// `min_align_of::<T>()`
    ///
    /// La volatila parametro estas agordita al `true`, do ĝi ne estos optimumigita krom se grandeco egalas al nulo.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekvivalenta al la taŭga `llvm.memmove.p0i8.0i8.*`-interna, kun grandeco de `count* size_of::<T>()` kaj vicigo de
    ///
    /// `min_align_of::<T>()`
    ///
    /// La volatila parametro estas agordita al `true`, do ĝi ne estos optimumigita krom se grandeco egalas al nulo.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekvivalenta al la taŭga `llvm.memset.p0i8.*`-interna, kun grandeco de `count* size_of::<T>()` kaj vicigo de `min_align_of::<T>()`.
    ///
    ///
    /// La volatila parametro estas agordita al `true`, do ĝi ne estos optimumigita krom se grandeco egalas al nulo.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Elfaras volatilan ŝarĝon de la montrilo `src`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Elfaras volatilan butikon al la montrilo `dst`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Elfaras volatilan ŝarĝon de la montrilo `src` La montrilo ne devas esti vicigita.
    ///
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Elfaras volatilan butikon al la montrilo `dst`.
    /// La montrilo ne devas esti vicigita.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Liveras la kvadratan radikon de `f32`
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Liveras la kvadratan radikon de `f64`
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Altigas `f32` al entjera potenco.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Altigas `f64` al entjera potenco.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Liveras la sinon de `f32`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Liveras la sinon de `f64`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Redonas la kosinuso de `f32`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Redonas la kosinuso de `f64`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Altigas `f32` al `f32`-potenco.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Altigas `f64` al `f64`-potenco.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Liveras la eksponenton de `f32`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Liveras la eksponenton de `f64`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Revenas 2 levita al la potenco de `f32`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Revenas 2 levita al la potenco de `f64`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Liveras la naturan logaritmon de `f32`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Liveras la naturan logaritmon de `f64`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Liveras la bazan 10-logaritmon de `f32`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Liveras la bazan 10-logaritmon de `f64`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Liveras la bazan 2-logaritmon de `f32`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Liveras la bazan 2-logaritmon de `f64`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Liveras `a * b + c` por `f32`-valoroj.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Liveras `a * b + c` por `f64`-valoroj.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Liveras la absolutan valoron de `f32`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Liveras la absolutan valoron de `f64`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Liveras la minimumon de du `f32`-valoroj.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Liveras la minimumon de du `f64`-valoroj.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Liveras la maksimumon de du `f32`-valoroj.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Liveras la maksimumon de du `f64`-valoroj.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopias la signon de `y` al `x` por `f32`-valoroj.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopias la signon de `y` al `x` por `f64`-valoroj.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Liveras la plej grandan entjeron malpli ol aŭ egala al `f32`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Liveras la plej grandan entjeron malpli ol aŭ egala al `f64`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Liveras la plej malgrandan entjeron pli grandan ol egala al `f32`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Liveras la plej malgrandan entjeron pli grandan ol egala al `f64`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Liveras la entjeran parton de `f32`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Liveras la entjeran parton de `f64`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Liveras la plej proksiman entjeron al `f32`.
    /// Povas kaŭzi malprecizan glitkoman escepton se la argumento ne estas entjero.
    pub fn rintf32(x: f32) -> f32;
    /// Liveras la plej proksiman entjeron al `f64`.
    /// Povas kaŭzi malprecizan glitkoman escepton se la argumento ne estas entjero.
    pub fn rintf64(x: f64) -> f64;

    /// Liveras la plej proksiman entjeron al `f32`.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Liveras la plej proksiman entjeron al `f64`.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Liveras la plej proksiman entjeron al `f32`.Rondas duonvoje kazojn for de nulo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Liveras la plej proksiman entjeron al `f64`.Rondas duonvoje kazojn for de nulo.
    ///
    /// La stabiligita versio de ĉi tiu propra estas
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Flosa aldono, kiu permesas optimumigojn bazitajn sur algebraj reguloj.
    /// Povas supozi ke enigoj estas finiaj.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Ŝveba subtraho, kiu permesas optimumigojn bazitajn sur algebraj reguloj.
    /// Povas supozi ke enigoj estas finiaj.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Multfoja multipliko kiu permesas optimumigojn bazitajn sur algebraj reguloj.
    /// Povas supozi ke enigoj estas finiaj.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Flosila divido, kiu permesas optimumigojn bazitajn sur algebraj reguloj.
    /// Povas supozi ke enigoj estas finiaj.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Ŝveba resto, kiu permesas optimumigojn bazitajn sur algebraj reguloj.
    /// Povas supozi ke enigoj estas finiaj.
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Konvertu per fptoui/fptosi de LLVM, kiu eble revenos nedifinebla por valoroj ekster gamo
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabiligita kiel [`f32::to_int_unchecked`] kaj [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Liveras la nombron de bitoj metitaj en entjera tipo `T`
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `count_ones`-metodo.
    /// Ekzemple,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Liveras la nombron de gvidaj malmetitaj bitoj (zeroes) en entjera tipo `T`.
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `leading_zeros`-metodo.
    /// Ekzemple,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` kun valoro `0` redonos la bitlarĝon de `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Kiel `ctlz`, sed ekstreme nesekura ĉar ĝi redonas `undef` kiam donita `x` kun valoro `0`.
    ///
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Liveras la nombron de postaj malmetitaj bitoj (zeroes) en entjera tipo `T`.
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `trailing_zeros`-metodo.
    /// Ekzemple,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` kun valoro `0` redonos la bitlarĝon de `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Kiel `cttz`, sed ekstreme nesekura ĉar ĝi redonas `undef` kiam donita `x` kun valoro `0`.
    ///
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Inversigas la bitokojn en entjera tipo `T`.
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `swap_bytes`-metodo.
    /// Ekzemple,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Inversigas la bitojn en entjera tipo `T`.
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `reverse_bits`-metodo.
    /// Ekzemple,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Elfaras kontrolitan entjeran aldonon.
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `overflowing_add`-metodo.
    /// Ekzemple,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Elfaras kontrolitan entjeran subtrahon
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `overflowing_sub`-metodo.
    /// Ekzemple,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Realigas kontrolitan entjeran multiplikon
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `overflowing_mul`-metodo.
    /// Ekzemple,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Faras ĝustan dividon, rezultigante nedifinitan konduton kie `x % y != 0` aŭ `y == 0` aŭ `x == T::MIN && y == -1`
    ///
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Elfaras senkontrolan dividon, rezultigante nedifinitan konduton kie `y == 0` aŭ `x == T::MIN && y == -1`
    ///
    ///
    /// Sekuraj envolvaĵoj por ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `checked_div`-metodo.
    /// Ekzemple,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Liveras la reston de senkontrola divido, rezultigante nedifinitan konduton kiam `y == 0` aŭ `x == T::MIN && y == -1`
    ///
    ///
    /// Sekuraj envolvaĵoj por ĉi tiu interna estas haveblaj ĉe la entjeraj primitivuloj per la `checked_rem`-metodo.
    /// Ekzemple,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Elfaras senkontrolan maldekstran movon, rezultigante nedifinitan konduton kiam `y < 0` aŭ `y >= N`, kie N estas la larĝo de T en bitoj.
    ///
    ///
    /// Sekuraj envolvaĵoj por ĉi tiu interna estas haveblaj ĉe la entjeraj primitivuloj per la `checked_shl`-metodo.
    /// Ekzemple,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Elfaras senkontrolan dekstran ŝanĝon, rezultigante nedifinitan konduton kiam `y < 0` aŭ `y >= N`, kie N estas la larĝo de T en bitoj.
    ///
    ///
    /// Sekuraj envolvaĵoj por ĉi tiu interna estas haveblaj ĉe la entjeraj primitivuloj per la `checked_shr`-metodo.
    /// Ekzemple,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Liveras la rezulton de senkontrola aldono, rezultigante nedifinitan konduton kiam `x + y > T::MAX` aŭ `x + y < T::MIN`.
    ///
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Liveras la rezulton de senkontrola subtraho, rezultigante nedifinitan konduton kiam `x - y > T::MAX` aŭ `x - y < T::MIN`.
    ///
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Liveras la rezulton de senkontrola multipliko, rezultigante nedifinitan konduton kiam `x *y > T::MAX` aŭ `x* y < T::MIN`.
    ///
    ///
    /// Ĉi tiu propra ne havas stabilan samrangon.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Faras rotacii maldekstren.
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `rotate_left`-metodo.
    /// Ekzemple,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Faras rotacii dekstren.
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `rotate_right`-metodo.
    /// Ekzemple,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Liveras (a + b) mod 2 <sup>N</sup>, kie N estas la larĝo de T en bitoj.
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `wrapping_add`-metodo.
    /// Ekzemple,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Liveras (a, b) mod 2 <sup>N</sup>, kie N estas la larĝo de T en bitoj.
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `wrapping_sub`-metodo.
    /// Ekzemple,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Liveras (a * b) mod 2 <sup>N</sup>, kie N estas la larĝo de T en bitoj.
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `wrapping_mul`-metodo.
    /// Ekzemple,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Komputas `a + b`, saturante je nombraj limoj.
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `saturating_add`-metodo.
    /// Ekzemple,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Komputas `a - b`, saturante je nombraj limoj.
    ///
    /// La stabiligitaj versioj de ĉi tiu propra estas haveblaj ĉe la entjeraj primitivuloj per la `saturating_sub`-metodo.
    /// Ekzemple,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Liveras la valoron de la diskriminanto por la varianto en 'v';
    /// se `T` ne havas diskriminanton, redonas `0`.
    ///
    /// La stabiligita versio de ĉi tiu propra estas [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Redonas la nombron da variantoj de la tipo `T` gisita al `usize`;
    /// se `T` ne havas variantojn, redonas `0`.Neloĝataj variantoj estos kalkulitaj.
    ///
    /// La stabiligebla versio de ĉi tiu propra estas [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// "try catch"-konstruo de Rust, kiu alvokas la funkcian montrilon `try_fn` per la datuma montrilo `data`.
    ///
    /// La tria argumento estas funkcio nomata se panic okazas.
    /// Ĉi tiu funkcio prenas la datuman montrilon kaj montrilon al la cel-specifa escepta objekto, kiu estis kaptita.
    ///
    /// Por pliaj informoj vidu la fonton de la kompililo kaj ankaŭ la kapta efektivigo de std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Elsendas `!nontemporal`-butikon laŭ LLVM (vidu iliajn dokumentojn).
    /// Verŝajne neniam fariĝos stabila.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Vidu dokumentadon de `<*const T>::offset_from` por detaloj.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Vidu dokumentadon de `<*const T>::guaranteed_eq` por detaloj.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Vidu dokumentadon de `<*const T>::guaranteed_ne` por detaloj.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Asigni ĉe kompila tempo.Ne devas esti vokita dum rultempo.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Iuj funkcioj estas difinitaj ĉi tie, ĉar ili hazarde disponeblis en ĉi tiu modulo sur stabila.
// Vidu <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` ankaŭ eniras ĉi tiun kategorion, sed ĝi ne povas esti envolvita pro la kontrolo, ke `T` kaj `U` havas la saman grandecon.)
//

/// Kontrolas ĉu `ptr` estas ĝuste vicigita rilate al `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopias `count *size_of::<T>()`-bitokojn de `src` al `dst`.La fonto kaj celloko devas* ne * koincidi.
///
/// Por regionoj de memoro, kiuj povus koincidi, uzu anstataŭe [`copy`].
///
/// `copy_nonoverlapping` semantike ekvivalentas al C's [`memcpy`], sed kun la argumentordo ŝanĝita.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Konduto estas nedifinita se iuj el la sekvaj kondiĉoj estas malobservitaj:
///
/// * `src` devas esti [valid] por legoj de `count * size_of::<T>()`-bitokoj.
///
/// * `dst` devas esti [valid] por skriboj de `count * size_of::<T>()`-bitokoj.
///
/// * Kaj `src` kaj `dst` devas esti ĝuste vicigitaj.
///
/// * La regiono de memoro komenciĝanta ĉe `src` kun grandeco de `count *
///   grandeco_de: :<T>() `bajtoj devas *ne* koincidi kun la regiono de memoro komenciĝanta ĉe `dst` kun la sama grandeco.
///
/// Kiel [`read`], `copy_nonoverlapping` kreas laŭbitan kopion de `T`, sendepende de ĉu `T` estas [`Copy`].
/// Se `T` ne estas [`Copy`], uzi *ambaŭ* la valorojn en la regiono komenciĝanta ĉe `*src` kaj la regiono komenciĝanta ĉe `* dst` povas [violate memory safety][read-ownership].
///
///
/// Notu, ke eĉ se la efike kopiita grandeco (`count * size_of: :<T>()`) estas `0`, la montriloj devas esti neniel kaj ĝuste vicigitaj.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Mane efektivigi [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Movas ĉiujn elementojn de `src` en `dst`, lasante `src` malplena.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Certigu, ke `dst` havas sufiĉe da kapablo por enteni ĉion `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // La alvoko al kompenso ĉiam estas sekura ĉar `Vec` neniam asignos pli ol `isize::MAX`-bitokojn.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Tranĉu `src` sen faligi ĝian enhavon.
///         // Ni faras ĉi tion unue, por eviti problemojn, se io pli sube panics.
///         src.set_len(0);
///
///         // La du regionoj ne povas interkovri ĉar ŝanĝeblaj referencoj ne kaŝnomas, kaj du malsamaj vectors ne povas posedi la saman memoron.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Informu `dst`, ke ĝi nun enhavas la enhavon de `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Faru ĉi tiujn kontrolojn nur dum rula tempo
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ne panikiĝas por malpliigi kodegenan efikon.
        abort();
    }*/

    // SEKURECO: la sekureca kontrakto por `copy_nonoverlapping` devas esti
    // konfirmita de la alvokanto.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopias `count * size_of::<T>()`-bitokojn de `src` al `dst`.La fonto kaj celloko eble interkovras.
///
/// Se la fonto kaj celloko *neniam* interkovros, anstataŭe oni povas uzi [`copy_nonoverlapping`].
///
/// `copy` semantike ekvivalentas al C's [`memmove`], sed kun la argumentordo ŝanĝita.
/// Kopiado okazas kvazaŭ la bajtoj estus kopiitaj de `src` al portempa tabelo kaj poste kopiitaj de la tabelo al `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Konduto estas nedifinita se iuj el la sekvaj kondiĉoj estas malobservitaj:
///
/// * `src` devas esti [valid] por legoj de `count * size_of::<T>()`-bitokoj.
///
/// * `dst` devas esti [valid] por skriboj de `count * size_of::<T>()`-bitokoj.
///
/// * Kaj `src` kaj `dst` devas esti ĝuste vicigitaj.
///
/// Kiel [`read`], `copy` kreas laŭbitan kopion de `T`, sendepende de ĉu `T` estas [`Copy`].
/// Se `T` ne estas [`Copy`], uzi ambaŭ valorojn en la regiono komenciĝanta ĉe `*src` kaj la regiono komenciĝanta ĉe `* dst` povas [violate memory safety][read-ownership].
///
///
/// Notu, ke eĉ se la efike kopiita grandeco (`count * size_of: :<T>()`) estas `0`, la montriloj devas esti neniel kaj ĝuste vicigitaj.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Efike kreu Rust vector de nesekura bufro:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` devas esti ĝuste vicigita laŭ sia tipo kaj nula.
/// /// * `ptr` devas esti valida por legaĵoj de `elts`-apudaj elementoj de tipo `T`.
/// /// * Tiuj elementoj ne devas esti uzataj post nomi ĉi tiun funkcion krom se `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SEKURECO: Nia antaŭkondiĉo certigas, ke la fonto estas vicigita kaj valida,
///     // kaj `Vec::with_capacity` certigas, ke ni havas uzeblan spacon por skribi ilin.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SEKURECO: Ni kreis ĝin kun tiom multe pli frue,
///     // kaj la antaŭa `copy` pravalorizis ĉi tiujn elementojn.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Faru ĉi tiujn kontrolojn nur dum rula tempo
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ne panikiĝas por malpliigi kodegenan efikon.
        abort();
    }*/

    // SEKURECO: la sekureca kontrakto por `copy` devas esti konfirmita de la alvokanto.
    unsafe { copy(src, dst, count) }
}

/// Metas `count * size_of::<T>()`-bitokojn da memoro ekde `dst` ĝis `val`.
///
/// `write_bytes` estas simila al C's [`memset`], sed starigas `count * size_of::<T>()`-bitokojn al `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Konduto estas nedifinita se iuj el la sekvaj kondiĉoj estas malobservitaj:
///
/// * `dst` devas esti [valid] por skriboj de `count * size_of::<T>()`-bitokoj.
///
/// * `dst` devas esti ĝuste vicigita.
///
/// Aldone, la alvokanto devas certigi, ke skribi `count * size_of::<T>()`-bitokojn al la donita regiono de memoro rezultigas validan valoron de `T`.
/// Uzi regionon de memoro tajpita kiel `T`, kiu enhavas malvalidan valoron de `T`, estas nedifinita konduto.
///
/// Notu, ke eĉ se la efike kopiita grandeco (`count * size_of: :<T>()`) estas `0`, la montrilo devas esti nula kaj taŭge vicigita.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Krei nevalidan valoron:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Ellasas la antaŭe tenitan valoron anstataŭigante la `Box<T>` per nula montrilo.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Je ĉi tiu punkto, uzi aŭ faligi `v` rezultigas nedifinitan konduton.
/// // drop(v); // ERROR
///
/// // Eĉ filtras `v` "uses" ĝin, kaj tial estas nedifinita konduto.
/// // mem::forget(v); // ERROR
///
/// // Fakte `v` estas malvalida laŭ bazaj tipaj aranĝaj invariantoj, do *iu ajn* operacio tuŝanta ĝin estas nedifinita konduto.
/////
/// // lasu v2 =v;//ERARO
///
/// unsafe {
///     // Ni anstataŭ enmetu validan valoron
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Nun la skatolo bonas
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SEKURECO: la sekureca kontrakto por `write_bytes` devas esti konfirmita de la alvokanto.
    unsafe { write_bytes(dst, val, count) }
}