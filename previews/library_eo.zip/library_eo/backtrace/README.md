# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Biblioteko por akiri malantaŭajn spurojn dum rultempo por Rust.
Ĉi tiu biblioteko celas plibonigi la subtenon de la norma biblioteko per provizado de programa interfaco kun kiu labori, sed ĝi ankaŭ subtenas simple facile presi la aktualan malantaŭan spuron kiel panics de libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Por simple kapti malantaŭan spuron kaj prokrasti traktadon pri ĝi ĝis posta tempo, vi povas uzi la pintnivelan `Backtrace`-tipon.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Se vi tamen ŝatus pli krudan aliron al la efektiva spura funkcio, vi povas uzi la funkciojn `trace` kaj `resolve` rekte.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Solvu ĉi tiun instrukcian montrilon al simbolo-nomo
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // daŭre iru al la sekva kadro
    });
}
```

# License

Ĉi tiu projekto estas rajtigita sub iu ajn el

 * Permesilo Apache, Versio 2.0, ([LICENSE-APACHE](LICENSE-APACHE) aŭ http://www.apache.org/licenses/LICENSE-2.0)
 * MIT-permesilo ([LICENSE-MIT](LICENSE-MIT) aŭ http://opensource.org/licenses/MIT)

laŭ via elekto.

### Contribution

Krom se vi eksplicite deklaras alie, iu ajn kontribuo intence prezentita por esti inkluzivita en backtrace-rs de vi, kiel difinita en la permesilo Apache-2.0, estos duoble aprobita kiel supre, sen aldonaj kondiĉoj aŭ kondiĉoj.







