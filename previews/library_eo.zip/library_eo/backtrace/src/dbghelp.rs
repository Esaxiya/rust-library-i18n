//! Modulo por helpi administri dbghelp-ligojn sur Windows
//!
//! Malantaŭaj spuroj sur Windows (almenaŭ por MSVC) plejparte funkcias per `dbghelp.dll` kaj la diversaj funkcioj, kiujn ĝi enhavas.
//! Ĉi tiuj funkcioj estas nuntempe ŝarĝitaj *dinamike* anstataŭ ligi al `dbghelp.dll` statike.
//! Ĉi tion nuntempe faras la norma biblioteko (kaj teorie necesas tie), sed estas penado helpi redukti la statikajn dll-dependecojn de biblioteko, ĉar malantaŭaj spuroj estas kutime sufiĉe laŭvolaj.
//!
//! Dirite, `dbghelp.dll` preskaŭ ĉiam sukcese ŝarĝas Windows.
//!
//! Rimarku tamen, ke ĉar ni ŝarĝas ĉi tiun subtenon dinamike, ni ne povas efektive uzi la krudajn difinojn en `winapi`, sed ni prefere devas mem difini la funkcio-montrilojn kaj uzi tion.
//! Ni ne vere volas okupiĝi pri duobligado de winapi, do ni havas Cargo-funkcion `verify-winapi`, kiu asertas, ke ĉiuj ligiloj kongruas kun tiuj en winapi kaj ĉi tiu funkcio estas ebligita ĉe CI.
//!
//! Fine vi rimarkos ĉi tie, ke la DLL por `dbghelp.dll` neniam estas malŝarĝita, kaj tio estas nuntempe intenca.
//! La penso estas, ke ni povas tutmonde konservi ĝin kaj uzi ĝin inter vokoj al la API, evitante multekostan loads/unloads.
//! Se ĉi tio estas problemo por likaj detektiloj aŭ io simila, ni povas transiri la ponton kiam ni alvenos tien.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Laboru ĉirkaŭ `SymGetOptions` kaj `SymSetOptions` ne ĉeestante en winapi mem.
// Alie ĉi tio estas uzata nur kiam ni duoble kontrolas tipojn kontraŭ winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Ankoraŭ ne difinita en winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Ĉi tio estas difinita en winapi, sed ĝi estas malĝusta (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Ankoraŭ ne difinita en winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Ĉi tiu makroo estas uzata por difini `Dbghelp`-strukturon, kiu interne enhavas ĉiujn funkciojn, kiujn ni povus ŝarĝi.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// La ŝarĝita DLL por `dbghelp.dll`
            dll: HMODULE,

            // Ĉiun funkcian montrilon por ĉiu funkcio ni povus uzi
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Komence ni ne ŝarĝis la DLL
            dll: 0 as *mut _,
            // Komence ĉiuj funkcioj estas agorditaj al nulo por diri, ke ili devas esti dinamike ŝarĝitaj.
            //
            $($name: 0,)*
        };

        // Komforta tajpado por ĉiu funkcio-tipo.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Provoj malfermi `dbghelp.dll`.
            /// Liveras sukceson se ĝi funkcias aŭ eraro se `LoadLibraryW` malsukcesas.
            ///
            /// Panics se biblioteko jam estas ŝarĝita.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funkcio por ĉiu metodo, kiun ni ŝatus uzi.
            // Kiam ĝi estas vokita, ĝi aŭ legos la kaŝmemoran funkcion aŭ ŝarĝos ĝin kaj redonos la ŝarĝitan valoron.
            // Ŝarĝoj estas asertitaj por sukcesi.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Konvena prokurilo uzi la purigajn serurojn por referenci al dbghelp-funkcioj.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Komencu ĉian subtenon necesan por aliri `dbghelp`-API-funkciojn de ĉi tiu crate.
///
///
/// Notu, ke ĉi tiu funkcio estas **sekura**, ĝi interne havas sian propran sinkronigon.
/// Notu ankaŭ, ke estas sekure nomi ĉi tiun funkcion plurfoje rekursie.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Unue ni devas fari estas sinkronigi ĉi tiun funkcion.Ĉi tio povas esti nomata samtempe de aliaj fadenoj aŭ rekursie ene de unu fadeno.
        // Notu, ke ĝi estas pli malfacila ol tio, ĉar tio, kion ni uzas ĉi tie, `dbghelp`,*ankaŭ*, devas esti sinkronigita kun ĉiuj aliaj alvokantoj al `dbghelp` en ĉi tiu procezo.
        //
        // Tipe ne ekzistas tiom multaj vokoj al `dbghelp` ene de la sama procezo kaj ni verŝajne povas sekure supozi, ke ni estas la solaj alirantaj ĝin.
        // Tamen estas unu ĉefa alia uzanto, kiun ni devas zorgi pri tio, kio estas ironie ni mem, sed en la norma biblioteko.
        // La norma biblioteko Rust dependas de ĉi tiu crate por malantaŭa spuro, kaj ĉi tiu crate ankaŭ ekzistas ĉe crates.io.
        // Ĉi tio signifas, ke se la norma biblioteko presas malantaŭan spuron panic, ĝi eble kuregas kun ĉi tiu crate venanta de crates.io, kaŭzante apartajn difektojn.
        //
        // Por helpi solvi ĉi tiun sinkronigan problemon, ni uzas ĉi tie Vindozan specifan lertaĵon (ĝi ja estas Vindozo-specifa limigo pri sinkronigado).
        // Ni kreas *sesi-lokan* nomatan mutex por protekti ĉi tiun alvokon.
        // La intenco ĉi tie estas, ke la norma biblioteko kaj ĉi tiu crate ne devas dividi Rust-nivelajn APIojn por sinkronigi ĉi tie, sed anstataŭe povas funkcii malantaŭ la kulisoj por certigi, ke ili sinkronigas unu kun la alia.
        //
        // Tiel, kiam ĉi tiu funkcio estas nomata per la norma biblioteko aŭ per crates.io, ni povas esti certaj, ke la sama mutex estas akirita.
        //
        // Do ĉio estas diri, ke la unua afero, kiun ni faras ĉi tie, estas ni atomece krei `HANDLE`, kiu estas nomata mutex ĉe Windows.
        // Ni iomete sinkronigas kun aliaj fadenoj, kiuj dividas ĉi tiun funkcion specife, kaj certigas, ke nur unu tenilo estas kreita per ekzemplo de ĉi tiu funkcio.
        // Notu, ke la tenilo neniam estas fermita post kiam ĝi estas konservita en la tutmonda.
        //
        // Post kiam ni vere ŝlosos, ni simple akiros ĝin, kaj nia `Init`-tenilo, kiun ni disdonos, respondecos faligi ĝin eventuale.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Bone, phew!Nun, kiam ni ĉiuj sekure sinkronigas, ni efektive komencu prilabori ĉion.
        // Unue ni devas certigi, ke `dbghelp.dll` efektive estas ŝarĝita en ĉi tiu procezo.
        // Ni faras tion dinamike por eviti statikan dependecon.
        // Ĉi tio historie estis farita por ĉirkaŭiri strangajn ligajn aferojn kaj celas igi binarojn iom pli porteblaj, ĉar ĉi tio plejparte estas nur elpuriga ilo.
        //
        //
        // Post kiam ni malfermis `dbghelp.dll`, ni devas voki kelkajn komencajn funkciojn en ĝi, kaj tio estas detala pli sube.
        // Tamen ni faras tion nur unufoje, do ni havas tutmondan bulean indikantan ĉu ni jam finis aŭ ne.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Certigu, ke la flago `SYMOPT_DEFERRED_LOADS` estas agordita, ĉar laŭ la propraj dokumentoj de MSVC pri ĉi tio: "This is the fastest, most efficient way to use the symbol handler.", do ni faru tion!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Fakte pravalorizi simbolojn per MSVC.Notu, ke ĉi tio povas malsukcesi, sed ni ignoras ĝin.
        // Ne estas multe da antaŭa arto por ĉi tio mem, sed LLVM interne ŝajnas ignori la revenan valoron ĉi tie kaj unu el la purigaj bibliotekoj en LLVM presas timigan averton, se ĉi tio malsukcesas, sed esence ignoras ĝin longtempe.
        //
        //
        // Unu kazo, kiu multe aperas por Rust, estas, ke la norma biblioteko kaj ĉi tiu crate ĉe crates.io ambaŭ volas konkurenci por `SymInitializeW`.
        // La norma biblioteko historie volis pravalorizi tiam purigon plejofte, sed nun, kiam ĝi uzas ĉi tiun crate, tio signifas, ke iu unue komencos kaj la alia reprenos tiun pravalorizon.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}