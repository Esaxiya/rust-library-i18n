use core::ffi::c_void;
use core::fmt;

/// Inspektas la nunan alvokstakon, transdonante ĉiujn aktivajn kadrojn en la fermitan provizitan por kalkuli stakspuron.
///
/// Ĉi tiu funkcio estas la laborĉevalo de ĉi tiu biblioteko kalkulante la stakajn spurojn por programo.La donita fermo `cb` estas donitaj kazoj de `Frame`, kiuj reprezentas informojn pri tiu alvoko-kadro sur la stako.
/// La fermo donas kadrojn desupre (plej laste nomataj funkcioj unue).
///
/// La revenvaloro de la fermo estas indiko ĉu la malantaŭa spuro devas daŭri.Revena valoro de `false` finos la malantaŭan spuron kaj revenos tuj.
///
/// Post kiam `Frame` estos akirita, vi probable volos telefoni al `backtrace::resolve` por konverti la `ip` (instrukcian montrilon) aŭ simbolan adreson al `Symbol`, per kiu oni povas lerni la nomon kaj/aŭ dosiernomon/linian numeron.
///
///
/// Rimarku, ke ĉi tio estas relative malaltnivela funkcio kaj se vi ŝatus, ekzemple, kapti malantaŭan spuron por inspekti poste, tiam la tipo `Backtrace` eble pli taŭgas.
///
/// # Bezonataj funkcioj
///
/// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
///
/// # Panics
///
/// Ĉi tiu funkcio strebas neniam panic, sed se la `cb` provizis panics, tiam iuj platformoj devigos duoblan panic ĉesigi la procezon.
/// Iuj platformoj uzas C-bibliotekon, kiu interne uzas revokojn, kiujn oni ne povas malvolvi, do panikiĝi de `cb` povas provoki interrompon.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // daŭrigu la malantaŭan spuron
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Sama kiel `trace`, nur nesekura, ĉar ĝi estas nesinkronigita.
///
/// Ĉi tiu funkcio ne havas sinkronigajn garantiojn, sed estas disponebla kiam la `std`-funkcio de ĉi tiu crate ne estas kompilita.
/// Vidu la funkcion `trace` por pli da dokumentado kaj ekzemploj.
///
/// # Panics
///
/// Vidu informojn pri `trace` pri averto pri paniko de `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait reprezentanta unu kadron de malantaŭa spuro, cedis al la `trace`-funkcio de ĉi tiu crate.
///
/// La fermo de la spurfunkcio estos donita kadroj, kaj la kadro estas preskaŭ sendita ĉar la subesta efektivigo ne ĉiam estas konata ĝis rultempo.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Liveras la nunan instrukcian montrilon de ĉi tiu kadro.
    ///
    /// Ĉi tio kutime estas la sekva instrukcio plenumebla en la kadro, sed ne ĉiuj efektivigoj listigas ĉi tion kun 100% precizeco (sed ĝi estas ĝenerale sufiĉe proksima).
    ///
    ///
    /// Oni rekomendas transdoni ĉi tiun valoron al `backtrace::resolve` por igi ĝin en simbolan nomon.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Liveras la nunan stakmontrilon de ĉi tiu kadro.
    ///
    /// Se backend ne povas rekuperi la stakan montrilon por ĉi tiu kadro, nul-montrilo estas redonita.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Liveras la komencan simboladreson de la kadro de ĉi tiu funkcio.
    ///
    /// Ĉi tio provos rebobeni la instrukcian montrilon redonitan de `ip` al la komenco de la funkcio, redonante tiun valoron.
    ///
    /// En iuj kazoj, tamen backends nur redonos `ip` de ĉi tiu funkcio.
    ///
    /// La redonita valoro iam povas esti uzata se `backtrace::resolve` malsukcesis sur la `ip` donita supre.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Liveras la bazan adreson de la modulo al kiu la kadro apartenas.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Ĉi tio devas veni unue, por certigi, ke Miri prioritatas super la gastiga platformo
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // nur uzata en dbghelp simbolas
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}