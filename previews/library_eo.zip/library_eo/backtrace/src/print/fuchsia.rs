use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr prenas revokon, kiu ricevos montrilon dl_phdr_info por ĉiu DSO ligita al la procezo.
    // dl_iterate_phdr ankaŭ certigas, ke la dinamika ligilo estas ŝlosita de komenco ĝis fino de la ripeto.
    // Se la revoko redonas nenulan valoron, la ripeto finiĝas frue.
    // 'data' estos pasigita kiel la tria argumento al la revoko de ĉiu alvoko.
    // 'size' donas la grandecon de la dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Ni devas analizi la konstruan identigilon kaj iujn bazajn programajn titolajn datumojn, kio signifas, ke ni bezonas ankaŭ iom da aĵoj de la ELF-specifo.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Nun ni devas reprodukti, iom post iom, la strukturon de la tipo dl_phdr_info uzata de la nuna dinamika ligilo de fuksio.
// Chromium ankaŭ havas ĉi tiun ABI-limon kaj krampon.
// Finfine ni ŝatus movi ĉi tiujn kazojn por uzi elf-serĉadon, sed ni bezonus provizi tion en la SDK kaj tio ankoraŭ ne estis farita.
//
// Tiel ni (kaj ili) estas blokitaj devante uzi ĉi tiun metodon, kiu kaŭzas striktan kupladon kun la fuksia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Ni havas neniun manieron scii kontroli ĉu e_phoff kaj e_phnum validas.
    // libc devas certigi ĉi tion por ni, do sekure estas formi tranĉaĵon ĉi tie.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr reprezentas 64-bitan ELF-programkapon en la endianeco de la cela arkitekturo.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr reprezentas validan ELF-programkapon kaj ĝian enhavon.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Ni havas neniun manieron kontroli ĉu p_addr aŭ p_memsz validas.
    // La libc de Fuksio analizas la notojn unue tamen tial, ĉar ili estas ĉi tie, tiuj kaplinioj devas esti validaj.
    //
    // NoteIter ne postulas la subajn datumojn validaj sed ĝi postulas la limojn por esti validaj.
    // Ni fidas, ke libc certigis, ke ĉi tio estas la kazo por ni ĉi tie.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// La notospeco por konstruaj identigiloj.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr reprezentas titolon de ELF-noto en la fino de la celo.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Noto reprezentas ELF-noton (kaplinio + enhavo).
// La nomo restas kiel tranĉaĵo u8 ĉar ĝi ne ĉiam estas nuligita kaj rust faciligas sufiĉe por kontroli, ke la bajtoj kongruas ambaŭokaze.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter permesas vin sekure ripeti super nota segmento.
// Ĝi finiĝas tuj kiam eraro okazas aŭ ne plu estas notoj.
// Se vi ripetas pri nevalidaj datumoj, ĝi funkcios kvazaŭ neniu noto estus trovita.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Estas senvaria funkcio, ke la montrilo kaj grandeco donitaj signifas validan gamon da bajtoj, kiuj ĉiuj legeblas.
    // La enhavo de ĉi tiuj bajtoj povas esti io ajn krom la intervalo devas esti valida por ke ĉi tio estu sekura.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to alignes 'x' to 'to'-byte alignment assuming 'to' is a power of 2.
// Ĉi tio sekvas norman ŝablonon en C/C ++ ELF-analiza kodo, kie (x + to, 1)&-to estas uzataj.
// Rust ne lasas vin nei uzadon, do mi uzas
// 2's-kompleta konvertiĝo por amuzi tion.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 konsumas numerajn bajtojn de la tranĉaĵo (se ĉeestas) kaj aldone certigas, ke la fina tranĉaĵo estas ĝuste vicigita.
// Se aŭ la nombro de petitaj bitokoj estas tro granda aŭ la tranĉaĵo ne povas realordigi poste pro ne sufiĉe da ceteraj bajtoj ekzistantaj, Neniu estas redonita kaj la tranĉaĵo ne estas modifita.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Ĉi tiu funkcio havas neniujn realajn invariantojn, kiujn la alvokanto devas subteni krom eble ke 'bytes' estu vicigita por agado (kaj laŭ iuj arkitekturoj ĝusteco).
// La valoroj en la kampoj Elf_Nhdr povus esti sensencaĵoj sed ĉi tiu funkcio certigas nenion.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Ĉi tio estas sekura kondiĉe ke sufiĉas spaco kaj ni ĵus konfirmis, ke en la supre-aserto do ĉi tio ne devas esti nesekura.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Notu, ke sice_of: :<Elf_Nhdr>() estas ĉiam 4-bajta vicigita.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Kontrolu ĉu ni atingis la finon.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Ni transmutacias nhdr sed ni zorge konsideras la rezultan strukturon.
        // Ni ne fidas la namesz aŭ descsz kaj ni prenas neniujn nesekurajn decidojn laŭ la tipo.
        //
        // Do eĉ se ni elprenos kompletan rubon, ni tamen estu sekuraj.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Indikas, ke segmento estas plenumebla.
const PERM_X: u32 = 0b00000001;
/// Indikas, ke segmento estas skribebla.
const PERM_W: u32 = 0b00000010;
/// Indikas ke segmento estas legebla.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Reprezentas ELF-segmenton dum rultempo.
struct Segment {
    /// Donas la rultempan virtualan adreson de la enhavo de ĉi tiu segmento.
    addr: usize,
    /// Donas la memoran grandecon de la enhavo de ĉi tiu segmento.
    size: usize,
    /// Donas al la modulo virtualan adreson de ĉi tiu segmento per la ELF-dosiero.
    mod_rel_addr: usize,
    /// Donas la permesojn trovitajn en la ELF-dosiero.
    /// Ĉi tiuj permesoj tamen ne nepre estas la permesoj ĉe rultempa tempo.
    flags: Perm,
}

/// Lasas unu ripeti super Segmentoj de DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Reprezentas ELF DSO (Dinamika Komuna Objekto).
/// Ĉi tiu tipo referencas la datumojn konservitajn en la reala DSO anstataŭ fari sian propran kopion.
struct Dso<'a> {
    /// La dinamika ligilo ĉiam donas al ni nomon, eĉ se la nomo estas malplena.
    /// En la kazo de la ĉefa plenumebla ĉi tiu nomo estos malplena.
    /// Kaze de komuna objekto ĝi estos la nomo (vidu DT_SONAME).
    name: &'a str,
    /// Ĉe Fuksio preskaŭ ĉiuj ciferecaĵoj havas konstruajn identigilojn, sed ĉi tio ne estas strikta postulo.
    /// Neniu maniero egalas DSO-informojn kun vera ELF-dosiero poste se ne ekzistas build_id do ni postulas, ke ĉiu DSO havu unu ĉi tie.
    ///
    /// DSO-oj sen build_id estas ignorataj.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Redonas ripeton pri Segmentoj en ĉi tiu DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Ĉi tiuj eraroj kodas problemojn, kiuj aperas dum analizado de informoj pri ĉiu DSO.
///
enum Error {
    /// NameError signifas, ke eraro okazis dum konvertado de C-stila ĉeno en rust-ĉenon.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError signifas, ke ni ne trovis konstruan identigilon.
    /// Ĉi tio povus esti ĉar la DSO havis neniun konstru-identigilon aŭ ĉar la segmento enhavanta la konstru-identigilon estis misformita.
    ///
    BuildIDError,
}

/// Alvokas 'dso' aŭ 'error' por ĉiu DSO ligita al la procezo per la dinamika ligilo.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter, kiu havos unu el manĝmetodoj nomataj por ĉiu DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr certigas, ke info.name montros al valida loko.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Ĉi tiu funkcio presas la fuksian simboligan markon por ĉiuj informoj enhavitaj en DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}