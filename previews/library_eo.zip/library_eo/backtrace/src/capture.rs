use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Reprezento de posedata kaj memstara malantaŭa spuro.
///
/// Ĉi tiu strukturo povas esti uzata por kapti malantaŭan spuron ĉe diversaj punktoj de programo kaj poste uzi por inspekti, kio estis la malantaŭa spuro en tiu tempo.
///
///
/// `Backtrace` subtenas belan presadon de malantaŭaj spuroj per sia `Debug`-efektivigo.
///
/// # Bezonataj funkcioj
///
/// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Kadroj ĉi tie estas listigitaj de supre al malsupre de la stako
    frames: Vec<BacktraceFrame>,
    // La indico, kiun ni kredas, estas la efektiva komenco de la malantaŭa spuro, preterlasante kadrojn kiel `Backtrace::new` kaj `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Kaptita versio de kadro en malantaŭa spuro.
///
/// Ĉi tiu tipo estas redonita kiel listo de `Backtrace::frames` kaj reprezentas unu stakan kadron en kaptita malantaŭa spuro.
///
/// # Bezonataj funkcioj
///
/// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Kaptita versio de simbolo en malantaŭa spuro.
///
/// Ĉi tiu tipo estas redonita kiel listo de `BacktraceFrame::symbols` kaj reprezentas la metadatenojn de simbolo en malantaŭa spuro.
///
/// # Bezonataj funkcioj
///
/// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Kaptas malantaŭan spuron ĉe la vokloko de ĉi tiu funkcio, redonante posedatan reprezentantaron.
    ///
    /// Ĉi tiu funkcio utilas por reprezenti malantaŭan spuron kiel objekton en Rust.Ĉi tiu resendita valoro povas esti sendita trans fadenojn kaj presita aliloke, kaj la celo de ĉi tiu valoro estas esti tute memstara.
    ///
    /// Notu, ke sur iuj platformoj akiri plenan malantaŭan spuron kaj solvi ĝin povas esti ege multekoste.
    /// Se la kosto estas tro multe por via kandidatiĝo, oni rekomendas anstataŭe uzi `Backtrace::new_unresolved()`, kiu evitas la simbolan rezolucian paŝon (kiu plej ofte daŭras) kaj permesas prokrasti tion al posta dato.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Bezonataj funkcioj
    ///
    /// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // volas certigi, ke ĉi tie estas kadro forigebla
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Simile al `new` krom ke ĉi tio ne solvas iujn ajn simbolojn, ĉi tio simple kaptas la malantaŭan spuron kiel listo de adresoj.
    ///
    /// Poste oni povas nomi la funkcion `resolve` por solvi la simbolojn de ĉi tiu malantaŭa spuro en legeblajn nomojn.
    /// Ĉi tiu funkcio ekzistas ĉar la rezolucia procezo povas iafoje preni signifan kvanton de tempo dum iu ajn malantaŭa spuro nur nur malofte estas presita.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // neniuj nomoj de simboloj
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // simbolnomoj nun ĉeestas
    /// ```
    ///
    /// # Bezonataj funkcioj
    ///
    /// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
    ///
    ///
    ///
    #[inline(never)] // volas certigi, ke ĉi tie estas kadro forigebla
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Liveras la kadrojn de kiam ĉi tiu malantaŭa spuro estis kaptita.
    ///
    /// La unua eniro de ĉi tiu tranĉaĵo probable estas la funkcio `Backtrace::new`, kaj la lasta kadro probable estas io pri tio, kiel ĉi tiu fadeno aŭ la ĉefa funkcio komenciĝis.
    ///
    ///
    /// # Bezonataj funkcioj
    ///
    /// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Se ĉi tiu malantaŭa spuro estis kreita de `new_unresolved` tiam ĉi tiu funkcio solvos ĉiujn adresojn en la malantaŭa spuro al iliaj simbolaj nomoj.
    ///
    ///
    /// Se ĉi tiu malantaŭa spuro estis antaŭe solvita aŭ kreita per `new`, ĉi tiu funkcio faras nenion.
    ///
    /// # Bezonataj funkcioj
    ///
    /// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Sama kiel `Frame::ip`
    ///
    /// # Bezonataj funkcioj
    ///
    /// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Sama kiel `Frame::symbol_address`
    ///
    /// # Bezonataj funkcioj
    ///
    /// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Sama kiel `Frame::module_base_address`
    ///
    /// # Bezonataj funkcioj
    ///
    /// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Liveras la liston de simboloj, al kiuj respondas ĉi tiu kadro.
    ///
    /// Kutime estas nur unu simbolo por kadro, sed foje se kelkaj funkcioj estas enlinitaj en unu kadro, tiam pluraj simboloj estos redonitaj.
    /// La unua simbolo listigita estas la "innermost function", dum la lasta simbolo estas la plej ekstera (lasta alvokanto).
    ///
    /// Notu, ke se ĉi tiu kadro devenis de nesolvita malantaŭa spuro, tiam ĉi tio redonos malplenan liston.
    ///
    /// # Bezonataj funkcioj
    ///
    /// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Sama kiel `Symbol::name`
    ///
    /// # Bezonataj funkcioj
    ///
    /// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Sama kiel `Symbol::addr`
    ///
    /// # Bezonataj funkcioj
    ///
    /// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Sama kiel `Symbol::filename`
    ///
    /// # Bezonataj funkcioj
    ///
    /// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Sama kiel `Symbol::lineno`
    ///
    /// # Bezonataj funkcioj
    ///
    /// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Sama kiel `Symbol::colno`
    ///
    /// # Bezonataj funkcioj
    ///
    /// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Dum presado de vojoj ni provas nudigi la cwd se ĝi ekzistas, alie ni simple presas la vojon tia kia.
        // Notu, ke ni ankaŭ faras tion nur por la mallonga formato, ĉar se ĝi estas plena, ni supozeble volas presi ĉion.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}