use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Solvu adreson al simbolo, pasante la simbolon al la specifa fermo.
///
/// Ĉi tiu funkcio serĉos la donitan adreson en areoj kiel la loka simboltabelo, dinamika simboltabelo aŭ DWARF-elpurigaj informoj (depende de la aktivigita efektivigo) por trovi simbolojn por doni.
///
///
/// La fermo eble ne estas vokita se rezolucio ne povis plenumi, kaj ĝi ankaŭ povas esti vokita pli ol unufoje se temas pri enliniaj funkcioj.
///
/// Simboloj donitaj reprezentas la ekzekuton ĉe la specifa `addr`, redonante file/line-parojn por tiu adreso (se havebla).
///
/// Notu, ke se vi havas `Frame`, tiam estas rekomendinde uzi la funkcion `resolve_frame` anstataŭ ĉi tiu.
///
/// # Bezonataj funkcioj
///
/// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
///
/// # Panics
///
/// Ĉi tiu funkcio strebas neniam panic, sed se la `cb` provizis panics, tiam iuj platformoj devigos duoblan panic ĉesigi la procezon.
/// Iuj platformoj uzas C-bibliotekon, kiu interne uzas revokojn, kiujn oni ne povas malvolvi, do panikiĝi de `cb` povas provoki interrompon.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // nur rigardu la supran kadron
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Solvi antaŭe kaptitan kadron al simbolo, pasante la simbolon al la specifa fermo.
///
/// Ĉi tiu funkcio plenumas la saman funkcion kiel `resolve` krom ke ĝi prenas `Frame` kiel argumento anstataŭ adreso.
/// Ĉi tio povas permesi al iuj platformaj efektivigoj de malantaŭa spuro provizi pli precizajn simbolajn informojn aŭ informojn pri enliniaj kadroj ekzemple.
///
/// Oni rekomendas uzi ĉi tion se vi povas.
///
/// # Bezonataj funkcioj
///
/// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
///
/// # Panics
///
/// Ĉi tiu funkcio strebas neniam panic, sed se la `cb` provizis panics, tiam iuj platformoj devigos duoblan panic ĉesigi la procezon.
/// Iuj platformoj uzas C-bibliotekon, kiu interne uzas revokojn, kiujn oni ne povas malvolvi, do panikiĝi de `cb` povas provoki interrompon.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // nur rigardu la supran kadron
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP-valoroj de stakokadroj estas kutime (always?) la instrukcio *post* la alvoko, kiu estas la efektiva staka spuro.
// Simboligi ĉi tion kaŭzas, ke la filename/line-numero estas unu antaŭen kaj eble en la malplenon, se ĝi estas proksime al la fino de la funkcio.
//
// Ĉi tio ŝajnas baze ĉiam esti sur ĉiuj platformoj, do ni ĉiam subtrahas unu el solvita ip por solvi ĝin al la antaŭa voka instrukcio anstataŭ la instrukcio resendita al.
//
//
// Ideale ni ne farus ĉi tion.
// Ideale ni postulus alvokantojn de la `resolve`-APIoj ĉi tie mane fari la -1 kaj rakonti, ke ili volas lokajn informojn por la *antaŭa* instrukcio, ne la aktuala.
// Ideale ni ankaŭ elmontrus pri `Frame` se ni efektive estas la adreso de la sekva instrukcio aŭ la aktuala.
//
// Nuntempe kvankam ĉi tio estas sufiĉe niĉa zorgo, do ni nur interne ĉiam subtrahas unu.
// Konsumantoj devas daŭre labori kaj akiri sufiĉe bonajn rezultojn, do ni devas esti sufiĉe bonaj.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Sama kiel `resolve`, nur nesekura, ĉar ĝi estas nesinkronigita.
///
/// Ĉi tiu funkcio ne havas sinkronigajn garantiojn, sed estas disponebla kiam la `std`-funkcio de ĉi tiu crate ne estas kompilita.
/// Vidu la funkcion `resolve` por pli da dokumentado kaj ekzemploj.
///
/// # Panics
///
/// Vidu informojn pri `resolve` pri averto pri paniko de `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Sama kiel `resolve_frame`, nur nesekura, ĉar ĝi estas nesinkronigita.
///
/// Ĉi tiu funkcio ne havas sinkronigajn garantiojn, sed estas disponebla kiam la `std`-funkcio de ĉi tiu crate ne estas kompilita.
/// Vidu la funkcion `resolve_frame` por pli da dokumentado kaj ekzemploj.
///
/// # Panics
///
/// Vidu informojn pri `resolve_frame` pri averto pri paniko de `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait reprezentanta la distingivon de simbolo en dosiero.
///
/// Ĉi tiu trait estas donita kiel trait objekto al la fermo donita al la `backtrace::resolve`-funkcio, kaj ĝi estas preskaŭ sendita, ĉar ĝi ne scias, kiu efektivigo estas malantaŭ ĝi.
///
///
/// Simbolo povas doni kuntekstajn informojn pri funkcio, ekzemple la nomo, dosiernomo, linia numero, preciza adreso ktp.
/// Tamen ne ĉiuj informoj ĉiam haveblas en simbolo, do ĉiuj metodoj redonas `Option`.
///
///
pub struct Symbol {
    // TODO: ĉi tiu dumviva bendo devas esti daŭrigita fine al `Symbol`,
    // sed tio nuntempe estas rompa ŝanĝo.
    // Nuntempe tio estas sekura, ĉar `Symbol` estas ĉiam donita per referenco kaj ne povas esti klonita.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Liveras la nomon de ĉi tiu funkcio.
    ///
    /// La redonita strukturo povas esti uzata por pridemandi diversajn ecojn pri la simbolo-nomo:
    ///
    ///
    /// * La efektivigo de `Display` elpresos la senmakulan simbolon.
    /// * La kruda `str`-valoro de la simbolo estas alirebla (se ĝi validas utf-8).
    /// * La krudaj bajtoj por la simbolo-nomo estas alireblaj.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Liveras la komencan adreson de ĉi tiu funkcio.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Liveras la krudan dosiernomon kiel tranĉaĵo.
    /// Ĉi tio ĉefe utilas por `no_std`-medioj.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Liveras la kolumnombron por kie ĉi tiu simbolo nuntempe ruliĝas.
    ///
    /// Nur gimli nuntempe donas valoron ĉi tie kaj eĉ tiam nur se `filename` redonas `Some`, kaj do ĝi sekve submetiĝas al similaj avertoj.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Liveras la linian numeron por kie ĉi tiu simbolo nuntempe ekzekutas.
    ///
    /// Ĉi tiu revenvaloro estas tipe `Some` se `filename` redonas `Some`, kaj sekve submetiĝas al similaj avertoj.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Liveras la dosiernomon kie ĉi tiu funkcio estis difinita.
    ///
    /// Ĉi tio nuntempe nur haveblas kiam libbacktrace aŭ gimli estas uzataj (ekz
    /// unix aliaj platformoj) kaj kiam duuma estas kompilita kun debuginfo.
    /// Se neniu el ĉi tiuj kondiĉoj estas plenumita, tiam ĉi tio probable redonos `None`.
    ///
    /// # Bezonataj funkcioj
    ///
    /// Ĉi tiu funkcio postulas la `std`-funkcion de la `backtrace` crate por esti ebligita, kaj la `std`-funkcio estas ŝaltita defaŭlte.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Eble analizita C++ -simbolo, se analizi la mistraktitan simbolon kiel Rust malsukcesis.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Certigu konservi ĉi tiun nula grandeco, tiel ke la `cpp_demangle`-funkcio havas neniun koston kiam malŝaltita.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Envolvaĵo ĉirkaŭ simbolo-nomo por provizi ergonomiajn alirojn al la demangleita nomo, la krudaj bitokoj, la kruda ĉeno, ktp.
///
// Permesu mortan kodon por kiam la `cpp_demangle`-funkcio ne estas ebligita.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Kreas novan simbolnomon de la krudaj subaj bajtoj.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Liveras la krudan (mangled)-simbolnomon kiel `str` se la simbolo validas utf-8.
    ///
    /// Uzu la `Display`-efektivigon se vi volas la malimplikitan version.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Liveras la krudan simbolan nomon kiel listo de bajtoj
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Ĉi tio povas presi se la demanglita simbolo ne vere validas, do pritraktu la eraron ĉi tie gracie ne disvastigante ĝin eksteren.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Provu repreni tiun kaŝmemoron uzitan por simboli adresojn.
///
/// Ĉi tiu metodo provos liberigi iujn ajn tutmondajn datumajn strukturojn, kiuj alie estis konservitaj tutmonde aŭ en la fadeno, kiuj kutime reprezentas analizitajn DWARF-informojn aŭ similajn.
///
///
/// # Caveats
///
/// Dum ĉi tiu funkcio estas ĉiam disponebla, ĝi efektive faras nenion pri plej multaj efektivigoj.
/// Bibliotekoj kiel dbghelp aŭ libbacktrace ne provizas facilojn por transdoni ŝtaton kaj administri la asignitan memoron.
/// Nuntempe la `gimli-symbolize`-funkcio de ĉi tiu crate estas la sola funkcio, kie ĉi tiu funkcio efikas.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}