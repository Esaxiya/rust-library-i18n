//! Simbola strategio uzante la DWARF-analizantan kodon en libbacktrace.
//!
//! La libbacktrace C-biblioteko, tipe distribuata kun gcc, subtenas ne nur generi malantaŭan spuron (kiun ni fakte ne uzas) sed ankaŭ simbolas la malantaŭan spuron kaj pritraktas nanajn senararigajn informojn pri aferoj kiel enliniaj kadroj kaj kio ajn.
//!
//!
//! Ĉi tio estas relative komplika pro multaj diversaj zorgoj ĉi tie, sed la baza ideo estas:
//!
//! * Unue ni nomas `backtrace_syminfo`.Ĉi tio ricevas simbolajn informojn de la dinamika simbola tabelo, se ni povas.
//! * Poste ni nomas `backtrace_pcinfo`.Ĉi tio analizos debuginfo-tabelojn se ili disponeblas kaj permesos al ni retrovi informojn pri enliniaj kadroj, dosiernomoj, liniaj numeroj, ktp.
//!
//! Estas multaj trompoj pri enigi la nanajn tabelojn en libbacktrace, sed espereble ĝi ne estas la fino de la mondo kaj estas sufiĉe klara legante sube.
//!
//! Ĉi tiu estas la defaŭlta simboliga strategio por ne-MSVC kaj ne-OSX-platformoj.En libstd tamen ĉi tio estas la defaŭlta strategio por OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Se eble preferas la `function`-nomon, kiu venas de debuginfo kaj povas esti pli preciza por ekzemple enliniaj kadroj ekzemple.
                // Se tio ne ĉeestas, tamen reiru al la simbolo-tabela nomo specifita en `symname`.
                //
                // Notu, ke kelkfoje `function` povas senti iom malpli precize, ekzemple esti listigita kiel `try<i32,closure>` ne estas antaŭ `std::panicking::try::do_call`.
                //
                // Ne vere klaras kial, sed ĝenerale la nomo `function` ŝajnas pli ĝusta.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // faru nenion nuntempe
}

/// Tipo de la montrilo `data` pasis al `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Post kiam ĉi tiu revoko estas alvokita de `backtrace_syminfo` kiam ni komencas solvi, ni plu vokas `backtrace_pcinfo`.
    // La funkcio `backtrace_pcinfo` konsultos elpurigajn informojn kaj provos fari aferojn kiel rekuperi file/line-informojn kaj ankaŭ enliniajn kadrojn.
    // Rimarku tamen, ke `backtrace_pcinfo` povas malsukcesi aŭ ne fari multon se ne ekzistas debug-informoj, do se tio okazos, ni certe vokos la revokon kun almenaŭ unu simbolo de la `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Tipo de la montrilo `data` pasis al `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// La API libbacktrace subtenas krei ŝtaton, sed ĝi ne subtenas detrui ŝtaton.
// Mi persone konsideras ĉi tion, ke ŝtato estas kreota kaj poste vivos eterne.
//
// Mi tre ŝatus registri at_exit()-prizorgilon, kiu purigas ĉi tiun staton, sed libbacktrace donas neniun manieron fari tion.
//
// Kun ĉi tiuj limoj, ĉi tiu funkcio havas statike kaŝitan staton, kiu estas kalkulita la unuan fojon, kiam ĉi tio estas petita.
//
// Memoru, ke malantaŭa spurado ĉio okazas serie (unu tutmonda seruro).
//
// Rimarku la mankon de sinkronigado ĉi tie ŝuldiĝas al la postulo, ke `resolve` estas ekstere sinkronigita.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Ne ekzercu fadenajn sekurajn kapablojn de libbacktrace, ĉar ni ĉiam nomas ĝin samtempe.
        //
        0,
        error_cb,
        ptr::null_mut(), // neniuj kromaj datumoj
    );

    return STATE;

    // Rimarku, ke por ke libbacktrace entute funkciu, ĝi bezonas trovi la DWARF-elpurigajn informojn por la nuna efektivigebla.Ĝi kutime faras tion per kelkaj mekanismoj inkluzive, sed ne limigite al:
    //
    // * /proc/self/exe sur subtenataj platformoj
    // * La dosiernomo eksplicite eniris kreante staton
    //
    // La biblioteko libbacktrace estas granda tufo de C-kodo.Ĉi tio nature signifas, ke ĝi havas memorajn sekurecajn vundeblecojn, precipe dum traktado de misformita debuginfo.
    // Libstd renkontis multajn ĉi tiujn historie.
    //
    // Se /proc/self/exe estas uzata, ni povas kutime ignori ĉi tiujn, ĉar ni supozas, ke libbacktrace estas "mostly correct" kaj alie ne faras strangajn aferojn kun "attempted to be correct"-nana senarariga informo.
    //
    //
    // Se ni trapasas dosiernomon, tamen eblas sur iuj platformoj (kiel BSD-oj), kie malica aktoro povas kaŭzi arbitran dosieron en tiu loko.
    // Ĉi tio signifas, ke se ni diras al libbacktrace pri dosiernomo, ĝi eble uzas arbitran dosieron, eble kaŭzante apartajn difektojn.
    // Se ni tamen diras al libbacktrace ion, ĝi tamen faros nenion sur platformoj, kiuj ne subtenas vojojn kiel /proc/self/exe!
    //
    // Konsiderante ĉion, kion ni klopodas laŭeble *ne* pasigi en dosiernomo, sed ni devas sur platformoj, kiuj tute ne subtenas /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Notu, ke ideale ni uzus `std::env::current_exe`, sed ni ne povas postuli `std` ĉi tie.
            //
            // Uzu `_NSGetExecutablePath` por ŝarĝi la nunan plenumeblan vojon en statikan areon (kiu se ĝi estas tro malgranda, simple rezignu).
            //
            //
            // Rimarku, ke ni serioze fidas libbacktrace ĉi tie por ne morti pro koruptaj plenumeblaj, sed certe ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows havas reĝimon por malfermi dosierojn, kie post ĝia malfermo ĝi ne povas esti forigita.
            // Ĝenerale ni volas ĉi tie, ĉar ni volas certigi, ke nia efektivigeblo ne ŝanĝiĝas de sub ni, post kiam ni transdonas ĝin al libbacktrace, espereble mildigante la kapablon transdoni arbitrajn datumojn al libbacktrace (kiu eble estos mistraktita).
            //
            //
            // Konsiderante, ke ni iom dancas ĉi tie por provi igi ŝlosilon al nia propra bildo:
            //
            // * Atentu la nunan procezon, ŝarĝu ĝian dosiernomon.
            // * Malfermu dosieron al tiu dosiernomo kun la ĝustaj flagoj.
            // * Reŝargu la dosiernomon de la nuna procezo, certigante ke ĝi estas la sama
            //
            // Se ĉio pasas, ni teorie ja malfermis la dosieron de nia procezo kaj ni garantias, ke ĝi ne ŝanĝiĝos.FWIW aro de ĉi tio estas kopiita de libstd historie, do ĉi tio estas mia plej bona interpreto pri tio, kio okazis.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Ĉi tio loĝas en statika memoro por ke ni redonu ĝin ..
                static mut BUF: [i8; N] = [0; N];
                // ... kaj ĉi tio loĝas sur la stako ĉar ĝi estas provizora
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // intence ellasu `handle` ĉi tie, ĉar havi tiun malfermon devas konservi nian ŝlosilon al ĉi tiu dosiernomo.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Ni volas redoni tranĉaĵon nul-finitan, do se ĉio pleniĝis kaj ĝi egalas al la totala longo, tiam egaligu tion kun fiasko.
                //
                //
                // Alie reveninte sukceson certigu, ke la nul bajto estas inkluzivita en la tranĉaĵo.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // malantaŭspuraj eraroj estas nuntempe balaitaj sub la tapiŝo
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Voku la `backtrace_syminfo`-API, kiu (legante la kodon) devas telefoni al `syminfo_cb` precize unufoje (aŭ malsukcesi kun eraro supozeble).
    // Ni tiam pritraktas pli en la `syminfo_cb`.
    //
    // Notu, ke ni faras ĉi tion, ĉar `syminfo` konsultos la simboltabelon, trovante simbolajn nomojn eĉ se ne ekzistas senararigaj informoj en la duuma.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}