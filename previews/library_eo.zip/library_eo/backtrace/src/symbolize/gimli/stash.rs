// nur uzata ĉe Linux nun, do permesu mortan kodon aliloke
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Simpla arena asignilo por bajtaj bufroj.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Asignas bufron de la specifa grandeco kaj redonas ŝanĝeblan referencon al ĝi.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SEKURECO: ĉi tiu estas la sola funkcio, kiu iam konstruas ŝanĝeblan
        // referenco al `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SEKURECO: ni neniam forigas elementojn de `self.buffers`, do referenco
        // al la datumoj en iu ajn bufro vivos tiel longe kiel `self`.
        &mut buffers[i]
    }
}