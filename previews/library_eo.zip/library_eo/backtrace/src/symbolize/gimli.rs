//! Subteno por simbolado per la `gimli` crate ĉe crates.io
//!
//! Ĉi tiu estas la defaŭlta simboliga efektivigo por Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'Senmova vivdaŭro estas mensogo pri manko de subteno por memreferencaj strukturoj.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Konverti al 'statikaj vivdaŭroj, ĉar la simboloj devas prunti nur `map` kaj `stash` kaj ni konservas ilin sube.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Por ŝarĝi denaskajn bibliotekojn ĉe Windows, vidu iom da diskuto pri rust-lang/rust#71060 pri la diversaj strategioj ĉi tie.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW-bibliotekoj nuntempe ne subtenas ASLR (rust-lang/rust#16514), sed DLL-oj ankoraŭ povas translokiĝi en la adresspaco.
            // Ŝajnas, ke adresoj en elpurigaj informoj estas kvazaŭ ĉi tiu biblioteko estis ŝarĝita ĉe sia "image base", kiu estas kampo en ĝiaj kaplinioj de dosieroj COFF.
            // Ĉar jen tio, kion debuginfo ŝajnas listigi, ni analizas la simboltabelon kaj stokas adresojn kvazaŭ la biblioteko estus ŝarĝita ankaŭ ĉe "image base".
            //
            // La biblioteko eble tamen ne estas ŝarĝita ĉe "image base".
            // (supozeble io alia eble estos ŝarĝita tie?) Jen la kampo `bias` ekludas, kaj ni devas eltrovi la valoron de `bias` ĉi tie.Bedaŭrinde tamen ne estas klare kiel akiri ĉi tion de ŝarĝita modulo.
            // Ni tamen havas la efektivan ŝarĝadreson (`modBaseAddr`).
            //
            // Kiel iomete elpendaĵo, ni nun mapas la dosieron, legas la informojn de la kaplinio de dosiero, kaj poste faligas la mmap.Ĉi tio malŝparas, ĉar ni probable remalfermos la mapon poste, sed ĉi tio devas funkcii sufiĉe bone nuntempe.
            //
            // Post kiam ni havas la `image_base` (deziratan ŝarĝan lokon) kaj la `base_addr` (realan ŝarĝan lokon) ni povas plenigi la `bias` (diferenco inter la reala kaj dezirata) kaj tiam la dirita adreso de ĉiu segmento estas la `image_base`, ĉar tiel diras la dosiero.
            //
            //
            // Nuntempe ŝajnas, ke male al ELF/MachO ni povas kontentiĝi per unu segmento por biblioteko, uzante `modBaseSize` kiel la tutan grandecon.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS uzas la Mach-O dosierformaton kaj uzas DYLD-specifajn APIojn por ŝarĝi liston de denaskaj bibliotekoj, kiuj estas parto de la aplikaĵo.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Prenu la nomon de ĉi tiu biblioteko, kiu respondas al la vojo de kie ankaŭ ŝarĝi ĝin.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Ŝarĝu la bildan titolon de ĉi tiu biblioteko kaj delegu al `object` por analizi ĉiujn ŝarĝajn komandojn, por ke ni komprenu ĉiujn segmentojn implikitajn ĉi tie.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Ripetu la segmentojn kaj registru konatajn regionojn por segmentoj, kiujn ni trovas.
            // Aldone registru informojn pri tekstaj segmentoj por prilaborado poste, vidu komentojn sube.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Determinu la "slide" por ĉi tiu biblioteko, kiu finas esti la antaŭjuĝo, kiun ni uzas por ekscii, kie en memoraj objektoj estas ŝarĝitaj.
            // Ĉi tio tamen estas iom stranga komputado kaj estas la rezulto de provi kelkajn sovaĝajn aferojn kaj vidi, kio restas.
            //
            // La ĝenerala ideo estas, ke la `bias` plus segmento `stated_virtual_memory_address` estos kie en la efektiva adresspaco loĝas la segmento.
            // La alia afero, pri kiu ni fidas, tamen estas, ke vera adreso malpli la `bias` estas la indekso por serĉi en la simbolo-tabelo kaj debuginfo.
            //
            // Tamen rezultas, ke por sistemaj ŝarĝitaj bibliotekoj ĉi tiuj kalkuloj estas malĝustaj.Por denaskaj efektivigeblaj, tamen ĝi ŝajnas ĝusta.
            // Levante iom da logiko de la fonto de LLDB, ĝi havas iom da speciala ŝelo por la unua `__TEXT`-sekcio ŝarĝita de dosiero ofseto 0 kun nula grandeco.
            // Kial ajn, kiam ĉi tio ĉeestas, ĝi ŝajnas signifi, ke la simbolo-tabelo rilatas al nur la vmaddr-diapozicio por la biblioteko.
            // Se ĝi *ne* ĉeestas, tiam la simbolo-tabelo rilatas al la vmaddr-diapozitivo plus la dirita adreso de la segmento.
            //
            // Por trakti ĉi tiun situacion, se ni *ne* trovas tekstosekcion ĉe dosier-ofseta nulo, tiam ni pliigas la antaŭjuĝon per la dirita adreso de la unuaj tekstosekcioj kaj malpliigas ĉiujn diritajn adresojn ankaŭ per tiu kvanto.
            //
            // Tiel la simboltabelo ĉiam aperas rilate al la antaŭjuĝa kvanto de la biblioteko.
            // Ĉi tio ŝajnas havi la taŭgajn rezultojn por simboli per la simbola tablo.
            //
            // Sincere mi ne tute certas, ĉu tio pravas aŭ ĉu estas io alia, kiu devas indiki kiel fari ĉi tion.
            // Nuntempe kvankam ĉi tio ŝajnas funkcii sufiĉe bone (?) kaj ni ĉiam devus povi plibonigi ĉi tion laŭ la tempo, se necese.
            //
            // Por iuj pliaj informoj vidu #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Alia Unix (ekz
        // Linukso) platformoj uzas ELF kiel objekta dosierformato kaj tipe efektivigas API nomatan `dl_iterate_phdr` por ŝarĝi denaskajn bibliotekojn.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` devus esti validaj montriloj.
        // `vec` estu valida montrilo al `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ne denaske subtenas erarigajn informojn, sed la konstrua sistemo metos erarigajn informojn ĉe la vojo `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Ĉio alia devas uzi ELF, sed ne scias kiel ŝarĝi denaskajn bibliotekojn.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Ĉiuj konataj komunaj bibliotekoj ŝarĝitaj.
    libraries: Vec<Library>,

    /// Mapoj kaŝmemoras, kie ni konservas analizitajn nanajn informojn.
    ///
    /// Ĉi tiu listo havas fiksan kapaciton por sia tuta daŭro, kiu neniam pliiĝas.
    /// La `usize`-elemento de ĉiu paro estas indekso en `libraries` supre kie `usize::max_value()` reprezentas la nunan efektivigeblan.
    ///
    /// La `Mapping` estas responda analizita nana informo.
    ///
    /// Notu, ke ĉi tio estas esence kaŝmemoro LRU kaj ni ŝanĝos aferojn ĉi tie, dum ni simbolas adresojn.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segmentoj de ĉi tiu biblioteko ŝarĝitaj en memoro, kaj kie ili estas ŝarĝitaj.
    segments: Vec<LibrarySegment>,
    /// La "bias" de ĉi tiu biblioteko, kutime kie ĝi estas ŝarĝita en memoro.
    /// Ĉi tiu valoro aldoniĝas al la dirita adreso de ĉiu segmento por ricevi la efektivan virtualan memoradreson, en kiun la segmento estas ŝarĝita.
    /// Aldone ĉi tiu antaŭjuĝo estas subtrahita de realaj virtualaj memoradresoj por indeksi en debuginfo kaj la simboltabelo.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// La fiksita adreso de ĉi tiu segmento en la objekta dosiero.
    /// Ĉi tie fakte ne estas ŝarĝita la segmento, sed pli ĝuste ĉi tiu adreso plus la enhavanta biblioteko `bias` estas kie trovi ĝin.
    ///
    stated_virtual_memory_address: usize,
    /// La grandeco de ĉi tiu segmento en memoro.
    len: usize,
}

// nesekura ĉar ĉi tio devas esti ekstere sinkronigita
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // nesekura ĉar ĉi tio devas esti ekstere sinkronigita
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Tre malgranda, tre simpla LRU-kaŝmemoro por elpurigi informajn mapojn.
        //
        // La trafokvanto devas esti tre alta, ĉar la tipa stako ne krucas inter multaj komunaj bibliotekoj.
        //
        // La `addr2line::Context`-strukturoj estas sufiĉe multekostaj krei.
        // Ĝia kosto estas atendita esti amortizita per postaj `locate`-demandoj, kiuj utiligas la strukturojn konstruitajn konstruante `addr2line: : Context`s por akiri belajn rapidojn.
        //
        // Se ni ne havus ĉi tiun kaŝmemoron, tiu amortizo neniam okazus, kaj simboli malantaŭajn spurojn estus ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Unue provu, ĉu ĉi tiu `lib` havas iun segmenton enhavantan la `addr` (pritraktanta translokadon).Se ĉi tiu kontrolo pasas, ni povas daŭrigi sube kaj efektive traduki la adreson.
                //
                // Notu, ke ni uzas `wrapping_add` ĉi tie por eviti superfluaĵojn.Oni vidis sovaĝe, ke la komputila antaŭjuĝo SVMA + superfluas.
                // Ŝajnas iom strange, ke tio okazus, sed ne eblas fari multon pri ĝi krom probable simple ignori tiujn segmentojn, ĉar ili probable montras al la spaco.
                //
                // Ĉi tio origine aperis en rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Nun, kiam ni scias, ke `lib` enhavas `addr`, ni povas kompensi per la antaŭjuĝo por trovi la deklaritan virusan memoradreson.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invarianto: post ĉi tiu kondicionalo finiĝas sen frua reveno
        // de eraro, la kaŝmemora eniro por ĉi tiu vojo estas ĉe indekso 0.

        if let Some(idx) = idx {
            // Kiam la mapado estas jam en la kaŝmemoro, movu ĝin al la fronto.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Kiam la mapado ne estas en la kaŝmemoro, kreu novan mapadon, enmetu ĝin en la antaŭon de la kaŝmemoro, kaj elpelu la plej malnovan kaŝmemoran eniron se necese.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // ne liku la `'static`-vivdaŭron, certigu, ke ĝi celas nur nin mem
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Plilongigu la vivdaŭron de `sym` al `'static`, ĉar bedaŭrinde ni devas ĉi tie, sed ĝi ĉiam funkcias kiel referenco, do neniu referenco al ĝi devas esti daŭrigita preter ĉi tiu kadro ĉiuokaze.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Fine akiru kaŝmemoran mapadon aŭ kreu novan mapadon por ĉi tiu dosiero, kaj pritaksu la informojn pri DWARF por trovi la file/line/name por ĉi tiu adreso.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Ni povis lokalizi kadrajn informojn por ĉi tiu simbolo, kaj la kadro de "addr2line" interne havas ĉiujn malgravajn detalojn.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Ne povis trovi erarserĉajn informojn, sed ni trovis ilin en la simbola tabelo de la elfa plenumebla.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}