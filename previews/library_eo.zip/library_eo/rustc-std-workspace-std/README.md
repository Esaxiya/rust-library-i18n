# La `rustc-std-workspace-std` crate

Vidu dokumentaron por la `rustc-std-workspace-core` crate.