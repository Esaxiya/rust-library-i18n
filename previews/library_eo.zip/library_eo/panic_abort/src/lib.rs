//! Efektivigo de Rust panics per procezo ĉesigas
//!
//! Kompare kun la efektivigo per malvolviĝo, ĉi tiu crate estas *multe* pli simpla!Dirite, ĝi ne estas tiel diverstalenta, sed jen!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" la utila ŝarĝo kaj ŝimo al la koncerna ĉesigo sur la koncerna platformo.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // voki std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Ĉe Windows, uzu la procesor-specifan __fastfail-mekanismon.En Windows 8 kaj pli posta, ĉi tio finos la procezon tuj sen ekzekuti iujn en-procezajn esceptajn prizorgantojn.
            // En pli fruaj versioj de Windows, ĉi tiu sekvenco de instrukcioj estos traktita kiel alira malobservo, finante la procezon, sed sen nepre preteriri ĉiujn esceptojn.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ĉi tio estas la sama efektivigo kiel en `abort_internal` de libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Ĉi tio ... estas iom stranga.La tl; dr;estas ke ĉi tio estas postulata por ligi ĝuste, la pli longa klarigo estas sube.
//
// Ĝuste nun la ciferecaĵoj de libcore/libstd, kiujn ni sendas, estas ĉiuj kompilitaj per `-C panic=unwind`.Ĉi tio estas farita por certigi, ke la duumaĵoj maksimume kongruas kun tiom multe da situacioj kiel eble.
// La kompililo tamen postulas "personality function" por ĉiuj funkcioj kompilitaj kun `-C panic=unwind`.Ĉi tiu personeca funkcio estas malmultekodigita al la simbolo `rust_eh_personality` kaj estas difinita per la lango `eh_personality`.
//
// So...
// kial ne simple difini tiun langobjekton ĉi tie?Bona demando!La maniero ligi panic-rultempojn efektive estas iomete subtila, ĉar ili estas "sort of" en la butiko crate de la kompililo, sed efektive ligita nur se alia ne estas ligita.
//
// Ĉi tio finas signifante, ke ambaŭ ĉi crate kaj panic_unwind crate povas aperi en la butiko crate de la kompililo, kaj se ambaŭ difinas la `eh_personality`-lang-eron, tiam tio trafos eraron.
//
// Por trakti ĉi tion, la kompililo bezonas nur ke `eh_personality` estu difinita se la ligita rultempo de panic estas la malvolva rultempo, kaj alie ĝi ne necesas esti difinita (prave).
// En ĉi tiu kazo, tamen, ĉi tiu biblioteko nur difinas ĉi tiun simbolon do estas almenaŭ iom da personeco ie.
//
// Esence ĉi tiu simbolo estas nur difinita por konektiĝi al libcore/libstd-duumaĵoj, sed ĝi neniam devas esti vokita, ĉar ni tute ne ligas en malstreĉa rultempo.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Ĉe x86_64-pc-windows-gnu ni uzas nian propran personecan funkcion, kiu bezonas redoni `ExceptionContinueSearch` dum ni transdonas ĉiujn niajn kadrojn.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Simile al ĉi-supre, ĉi tio respondas al la `eh_catch_typeinfo`-langa ero uzata nur ĉe Emscripten nuntempe.
    //
    // Ĉar panics ne generas esceptojn kaj eksterlandaj esceptoj nuntempe estas UB kun -C panic=ĉesigi (kvankam ĉi tio povas esti ŝanĝota), iuj ajn vokoj de catch_unwind neniam uzos ĉi tiun tipinformon.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Ĉi tiuj du estas nomataj de niaj startaj objektoj ĉe i686-pc-windows-gnu, sed ili ne bezonas fari ion, do la korpoj estas nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}