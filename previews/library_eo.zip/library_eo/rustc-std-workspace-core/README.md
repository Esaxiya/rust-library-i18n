# La `rustc-std-workspace-core` crate

Ĉi tiu crate estas malplena kaj malplena crate, kiu simple dependas de `libcore` kaj reeksportas sian tutan enhavon.
La crate estas la kerno de rajtigi la norman bibliotekon dependi de crates de crates.io

Crates sur crates.io, ke la norma biblioteko dependas, bezonas dependi de la `rustc-std-workspace-core` crate de crates.io, kiu estas malplena.

Ni uzas `[patch]` por anstataŭigi ĝin al ĉi tiu crate en ĉi tiu deponejo.
Rezulte, crates sur crates.io tiros dependecon edge al `libcore`, la versio difinita en ĉi tiu deponejo.
Tio devas tiri ĉiujn dependajn randojn por certigi, ke Cargo konstruas crates sukcese!

Notu, ke crates ĉe crates.io devas dependi de ĉi tiu crate kun la nomo `core` por ke ĉio funkciu ĝuste.Por fari tion ili povas uzi:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Per la uzo de la klavo `package` la crate estas renomita al `core`, kio signifas, ke ĝi aspektos kiel

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

kiam Cargo alvokas la kompililon, kontentigante la implicitan `extern crate core`-direktivon injektitan de la kompililo.




