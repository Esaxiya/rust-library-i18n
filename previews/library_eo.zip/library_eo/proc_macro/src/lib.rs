//! Subtena biblioteko por makro-aŭtoroj kiam oni difinas novajn makroojn.
//!
//! Ĉi tiu biblioteko, provizita per la norma distribuo, provizas la tipojn konsumitajn en la interfacoj de laŭprocede difinitaj makro-difinoj kiel funkcio-similaj makrooj `#[proc_macro]`, makro-atributoj `#[proc_macro_attribute]` kaj kutimo derivas atributojn "#[proc_macro_derive]".
//!
//!
//! Vidu [the book] por pli.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Determinas ĉu proc_macro fariĝis alirebla por la aktuala programo.
///
/// La proc_macro crate estas nur uzata en la efektivigo de proceduraj makrooj.Ĉiuj funkcioj en ĉi tiu crate panic se alvokitaj de ekstere de procedura makroo, kiel de konstrua skripto aŭ unuotesto aŭ ordinara Rust-duuma.
///
/// Konsiderante Rust-bibliotekojn, kiuj estas desegnitaj por subteni kaj makroajn kaj ne-makroajn kazojn, `proc_macro::is_available()` provizas senpanikan manieron detekti ĉu la infrastrukturo necesa por uzi la API de proc_macro estas nuntempe havebla.
/// Liveras vera se alvokita de interne de procedura makroo, falsa se alvokita de iu ajn alia duuma.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// La ĉefa tipo provizita de ĉi tiu crate, reprezentanta abstraktan fluon de tokens, aŭ, pli specife, sinsekvon de token-arboj.
/// La tipo provizas interfacojn por ripeti tiujn token-arbojn kaj, male, kolekti kelkajn token-arbojn en unu rivereton.
///
///
/// Ĉi tio estas kaj la enigo kaj eligo de difinoj `#[proc_macro]`, `#[proc_macro_attribute]` kaj `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Eraro revenis de `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Liveras malplenan `TokenStream` enhavantan neniujn token-arbojn.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Kontrolas ĉu ĉi tiu `TokenStream` estas malplena.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Provoj rompi la ŝnuron en tokens kaj analizi tiujn tokens en token-rivereton.
/// Povas malsukcesi pro kelkaj kialoj, ekzemple, se la ĉeno enhavas malekvilibrajn limigilojn aŭ signojn ne ekzistantajn en la lingvo.
///
/// Ĉiuj tokens en la analizita rivereto ricevas `Span::call_site()`-streĉojn.
///
/// NOTE: iuj eraroj povas kaŭzi panics anstataŭ redoni `LexError`.Ni rezervas la rajton ŝanĝi ĉi tiujn erarojn en `LexError`s poste.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, la ponto nur provizas `to_string`, efektivigu `fmt::Display` bazitan sur ĝi (la inversigo de la kutima rilato inter ambaŭ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Presas la rivereton token kiel ĉenon, kiu supozeble estas senperde konvertebla reen en la saman rivereton token (modulo ampleksas), krom eble "TokenTree: : Group`s kun `Delimiter::None`-limigiloj kaj negativaj nombraj literoj.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Presas token en formo konvena por elpurigado.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Kreas token-rivereton enhavantan ununuran token-arbon.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Kolektas kelkajn token-arbojn en unu rivereton.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// "flattening"-operacio sur riveretoj token, kolektas arbojn token de multoblaj riveretoj token en unu rivereton.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Uzu optimumigitan efektivigon if/when ebla.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Publikaj efektivigaj detaloj por la `TokenStream`-tipo, kiel ripetoj.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Ripetanto pri "TokenTree`s de"TokenStream".
    /// La ripeto estas "shallow", ekz. La ripeto ne ripetiĝas en limigitajn grupojn, kaj redonas tutajn grupojn kiel token-arboj.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` akceptas arbitran tokens kaj disetendiĝas en `TokenStream` priskribanta la enigaĵon.
/// Ekzemple, `quote!(a + b)` produktos esprimon, kiu, kiam taksata, konstruas la `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Nekvotado estas farita per `$`, kaj funkcias per prenado de la ununura sekva ident kiel la nekomencita termino.
/// Por citi `$` mem, uzu `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Regiono de fontkodo, kune kun informoj pri makro-ekspansio.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Kreas novan `Diagnostic` kun la donita `message` ĉe la interspaco `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Interspaco kiu solvas ĉe la makro-difina retejo.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// La daŭro de la alvoko de la nuna procedura makroo.
    /// Identigiloj kreitaj per ĉi tiu interspaco estos solvitaj kvazaŭ ili estus skribitaj rekte ĉe la makroalvoka loko (alvoko-higieno) kaj alia kodo ĉe la makroalvoko ankaŭ povos referenci al ili.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Interspaco kiu reprezentas `macro_rules`-higienon, kaj foje solviĝas ĉe la makro-difina retejo (lokaj variabloj, etikedoj, `$crate`) kaj foje ĉe la makro-voka retejo (ĉio alia).
    ///
    /// La interspaca loko estas prenita de la alvoko.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// La originala fontodosiero al kiu ĉi tiu interspaco montras.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// La `Span` por la tokens en la antaŭa makro-ekspansio de kiu `self` estis generita, se entute.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// La interspaco por la originala fontkodo de kiu `self` estis generita.
    /// Se ĉi tiu `Span` ne estis generita de aliaj makro-ekspansioj, tiam la revenvaloro samas al `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Akiras la komencan line/column en la fontdosiero por ĉi tiu daŭro.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Akiras la finaĵon line/column en la fontdosiero por ĉi tiu daŭro.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Kreas novan amplekson ampleksantan `self` kaj `other`.
    ///
    /// Liveras `None` se `self` kaj `other` estas de malsamaj dosieroj.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Kreas novan interspacon kun la samaj line/column-informoj kiel `self` sed tio solvas simbolojn kvazaŭ ĝi estus ĉe `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Kreas novan interspacon kun la samnoma rezolucia konduto kiel `self` sed kun la line/column-informoj de `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Komparas al interspacoj por vidi ĉu ili egalas.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Liveras la fontotekston malantaŭ interspaco.
    /// Ĉi tio konservas la originalan fontkodon, inkluzive spacojn kaj komentojn.
    /// Ĝi redonas rezulton nur se la interspaco respondas al vera fontkodo.
    ///
    /// Note: La observebla rezulto de makroo devas dependi nur de la tokens kaj ne de ĉi tiu fontoteksto.
    ///
    /// La rezulto de ĉi tiu funkcio estas plej bona peno uzota nur por diagnozoj.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Presas interspacon en formo konvena por elpurigado.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Linio-kolumna paro reprezentanta la komencon aŭ finon de `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// La 1-indeksita linio en la fontodosiero sur kiu la interspaco komenciĝas aŭ finiĝas (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// La 0-indeksita kolumno (en UTF-8-signoj) en la fontodosiero sur kiu la interspaco komenciĝas aŭ finiĝas (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// La fontodosiero de donita `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Akiras la vojon al ĉi tiu fontdosiero.
    ///
    /// ### Note
    /// Se la koda interspaco asociita kun ĉi tiu `SourceFile` estis generita de ekstera makroo, ĉi tiu makroo, ĉi tio eble ne estas efektiva vojo sur la dosiersistemo.
    /// Uzu [`is_real`] por kontroli.
    ///
    /// Notu ankaŭ, ke eĉ se `is_real` redonas `true`, se `--remap-path-prefix` estis transdonita al la komandlinio, la vojo donita eble ne efektive validas.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Liveras `true` se ĉi tiu fontodosiero estas vera fontodosiero, kaj ne generita per ekstera makro-ekspansio.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Ĉi tio estas hako ĝis interkruraj interspacoj estas efektivigitaj kaj ni povas havi verajn fontdosierojn por interspacoj generitaj en eksteraj makrooj.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Ununura token aŭ limigita sinsekvo de token-arboj (ekz. `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Rojo token ĉirkaŭita de krampaj limigiloj.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Identigilo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Ununura interpunkcia signo (`+`, `,`, `$`, ktp.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Laŭvorta signo (`'a'`), ĉeno (`"hello"`), nombro (`2.3`), ktp.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Redonas la amplekson de ĉi tiu arbo, delegante al la `span`-metodo de la enhavita token aŭ limigita rivereto.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Agordas la interspacon por *nur ĉi tiu token*.
    ///
    /// Notu, ke se ĉi tiu token estas `Group`, tiam ĉi tiu metodo ne agordos la amplekson de ĉiu el la internaj tokens, ĉi tio simple delegos al la `set_span`-metodo de ĉiu varianto.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Presas arbon token en formo konvena por elpurigado.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ĉiu el ĉi tiuj havas la nomon en la struktura tipo en la derivita erarserĉado, do ne ĝenu vin per ekstra tavolo de malrekta
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, la ponto nur provizas `to_string`, efektivigu `fmt::Display` bazitan sur ĝi (la inversigo de la kutima rilato inter ambaŭ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Presas la arbon token kiel ĉeno, kiu supozeble estas senperda konvertebla reen en la saman arbon token (modulo etendiĝas), krom eble "TokenTree: : Group" kun `Delimiter::None`-limigiloj kaj negativaj nombraj literoj.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Limigita token-rivereto.
///
/// `Group` interne enhavas `TokenStream` ĉirkaŭatan de `Limigilo`.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Priskribas kiel sinsekvo de token-arboj estas limigita.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Implica limigilo, kiu povas ekzemple aperi ĉirkaŭ tokens venanta de "macro variable" `$var`.
    /// Gravas konservi prioritatojn de telefonistoj en kazoj kiel `$var * 3`, kie `$var` estas `1 + 2`.
    /// Implicaj limigiloj eble ne postvivos iradon kaj iradon de fluo token tra ĉeno.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Kreas novan `Group` kun la donita limigilo kaj token-rivereto.
    ///
    /// Ĉi tiu konstruilo starigos la interspacon por ĉi tiu grupo al `Span::call_site()`.
    /// Por ŝanĝi la interspacon, vi povas uzi la `set_span`-metodon sube.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Liveras la limigilon de ĉi tiu `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Liveras la `TokenStream` de tokens limigitaj en ĉi tiu `Group`.
    ///
    /// Notu, ke la redonita token-fluo ne inkluzivas la limigilon resenditan supre.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Redonas la amplekson por la limigiloj de ĉi tiu fluo token, ampleksanta la tutan `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Redonas la interspacon montrante al la komenca limigilo de ĉi tiu grupo.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Liveras la interspacon montrantan al la ferma limigilo de ĉi tiu grupo.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Agordas la amplekson por ĉi tiu "Grupo"-limigiloj, sed ne ĝian internan tokens.
    ///
    /// Ĉi tiu metodo **ne** agordos la amplekson de ĉiuj internaj tokens enhavataj de ĉi tiu grupo, sed ĝi prefere starigos la amplekson de la limigilo tokens je la nivelo de la `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, la ponto nur provizas `to_string`, efektivigu `fmt::Display` bazitan sur ĝi (la inversigo de la kutima rilato inter ambaŭ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Presas la grupon kiel ĉeno, kiu devas esti senperde konvertebla reen en la saman grupon (modulaj ampleksoj), krom eble "TokenTree: : Group" kun `Delimiter::None`-limigiloj.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` estas ununura interpunkcia signo kiel `+`, `-` aŭ `#`.
///
/// Multkarakteraj operatoroj kiel `+=` estas reprezentataj kiel du kazoj de `Punct` kun malsamaj formoj de `Spacing` redonitaj.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Ĉu al `Punct` tuj sekvas alia `Punct` aŭ sekvas alia token aŭ blanka spaco.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// ekz. `+` estas `Alone` en `+ =`, `+ident` aŭ `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// ekz. `+` estas `Joint` en `+=` aŭ `'#`.
    /// Aldone, simpla citaĵo `'` povas kuniĝi kun identigiloj por formi vivdaŭrojn `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Kreas novan `Punct` de la donita signo kaj interspaco.
    /// La argumento `ch` devas esti valida interpunkcia signo permesita de la lingvo, alie la funkcio estos panic.
    ///
    /// La redonita `Punct` havos la defaŭltan interspacon de `Span::call_site()`, kiu povas esti plue agordita per la `set_span`-metodo sube.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Liveras la valoron de ĉi tiu interpunkcia signo kiel `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Redonas la interspacon de ĉi tiu interpunkcia signo, indikante ĉu ĝi estas tuj sekvata de alia `Punct` en la rivereto token, do ili eble povas esti kombinitaj en plurkarakteran operatoron (`Joint`), aŭ ĝin sekvas iu alia token aŭ blanka spaco (`Alone`), do la funkciigisto certe finis.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Liveras la interspacon por ĉi tiu interpunkcia signo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Agordu la amplekson por ĉi tiu interpunkcia signo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, la ponto nur provizas `to_string`, efektivigu `fmt::Display` bazitan sur ĝi (la inversigo de la kutima rilato inter ambaŭ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Presas la interpunkcio-signon kiel ĉenon, kiu devas esti senperde konvertebla reen en la saman signon.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Identigilo (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Kreas novan `Ident` kun la donita `string` kaj ankaŭ la specifita `span`.
    /// La argumento `string` devas esti valida identigilo permesita de la lingvo (inkluzive ŝlosilvortojn, ekz. `self` aŭ `fn`).Alie, la funkcio estos panic.
    ///
    /// Notu, ke `span`, nuntempe en rustc, agordas la higienajn informojn por ĉi tiu identigilo.
    ///
    /// De ĉi tiu tempo `Span::call_site()` eksplicite elektas "call-site"-higienon signifante, ke identigiloj kreitaj per ĉi tiu interspaco estos solvitaj kvazaŭ ili estus skribitaj rekte ĉe la loko de la makro-alvoko, kaj alia kodo ĉe la makro-voka retejo povos referenci al ilin ankaŭ.
    ///
    ///
    /// Pli postaj interspacoj kiel `Span::def_site()` permesos elekti "definition-site"-higienon signifante ke identigiloj kreitaj per ĉi tiu interspaco estos solvitaj ĉe la loko de la makro-difino kaj alia kodo ĉe la makro-voka retejo ne povos referenci al ili.
    ///
    /// Pro la nuna graveco de higieno ĉi tiu konstruanto, male al aliaj tokens, postulas `Span` esti specifita ĉe konstruado.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Sama kiel `Ident::new`, sed kreas krudan identigilon (`r#ident`).
    /// La argumento `string` estu valida identigilo permesita de la lingvo (inkluzive ŝlosilvortojn, ekz. `fn`).
    /// Ŝlosilvortoj uzeblaj en vojsegmentoj (ekz
    /// `self`, "super") ne estas subtenataj, kaj kaŭzos panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Redonas la amplekson de ĉi tiu `Ident`, ampleksante la tutan ĉenon redonitan de [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Agordas la amplekson de ĉi tiu `Ident`, eble ŝanĝante ĝian higienan kuntekston.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, la ponto nur provizas `to_string`, efektivigu `fmt::Display` bazitan sur ĝi (la inversigo de la kutima rilato inter ambaŭ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Presas la identigilon kiel ĉeno, kiu devas esti senperde konvertebla reen en la saman identigilon.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Laŭvorta ĉeno (`"hello"`), bajta ĉeno (`b"hello"`), signo (`'a'`), bajta signo (`b'a'`), entjera aŭ glitkoma nombro kun aŭ sen sufikso (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Buleaj literoj kiel `true` kaj `false` ne apartenas ĉi tie, ili estas `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Kreas novan sufiksitan entjeran laŭvorton kun la specifa valoro.
        ///
        /// Ĉi tiu funkcio kreos entjeron kiel `1u32` kie la entjera valoro specifita estas la unua parto de la token kaj la integralo ankaŭ estas sufiksita ĉe la fino.
        /// Literaloj kreitaj de negativaj nombroj eble ne postvivas rondirojn tra `TokenStream` aŭ ŝnuroj kaj povas esti disigitaj en du tokens (`-` kaj pozitiva laŭvorta).
        ///
        ///
        /// Literaloj kreitaj per ĉi tiu metodo havas la `Span::call_site()`-interspacon defaŭlte, kiu povas esti agordita per la `set_span`-metodo sube.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Kreas novan nesufiksitan entjeran laŭvorton kun la specifa valoro.
        ///
        /// Ĉi tiu funkcio kreos entjeron kiel `1` kie la entjera valoro specifita estas la unua parto de la token.
        /// Neniu sufikso estas specifita sur ĉi tiu token, kio signifas, ke alvokoj kiel `Literal::i8_unsuffixed(1)` samvaloras al `Literal::u32_unsuffixed(1)`.
        /// Literaloj kreitaj de negativaj nombroj eble ne postvivas retropafojn tra `TokenStream` aŭ ŝnuroj kaj povas esti disigitaj en du tokens (`-` kaj pozitiva laŭvorta).
        ///
        ///
        /// Literaloj kreitaj per ĉi tiu metodo havas la `Span::call_site()`-interspacon defaŭlte, kiu povas esti agordita per la `set_span`-metodo sube.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Kreas novan nesufiksitan glitkoman laŭvortan.
    ///
    /// Ĉi tiu konstruilo similas al tiuj kiel `Literal::i8_unsuffixed`, kie la valoro de la flosilo estas elsendita rekte en la token sed neniu sufikso estas uzata, do oni povas konkludi, ke ĝi estas `f64` poste en la kompililo.
    ///
    /// Literaloj kreitaj de negativaj nombroj eble ne postvivas retropafojn tra `TokenStream` aŭ ŝnuroj kaj povas esti disigitaj en du tokens (`-` kaj pozitiva laŭvorta).
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio postulas, ke la specifita flosilo estu finia, ekzemple se ĝi estas malfinio aŭ NaN, ĉi tiu funkcio estos panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Kreas novan sufiksitan glitkoman laŭvortan.
    ///
    /// Ĉi tiu konstruilo kreos laŭvortan kiel `1.0f32` kie la specifa valoro estas la antaŭa parto de la token kaj `f32` estas la sufikso de la token.
    /// Ĉi tiu token ĉiam estos konkludita kiel `f32` en la kompililo.
    /// Literaloj kreitaj de negativaj nombroj eble ne postvivas retropafojn tra `TokenStream` aŭ ŝnuroj kaj povas esti disigitaj en du tokens (`-` kaj pozitiva laŭvorta).
    ///
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio postulas, ke la specifita flosilo estu finia, ekzemple se ĝi estas malfinio aŭ NaN, ĉi tiu funkcio estos panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Kreas novan nesufiksitan glitkoman laŭvortan.
    ///
    /// Ĉi tiu konstruilo similas al tiuj kiel `Literal::i8_unsuffixed`, kie la valoro de la flosilo estas elsendita rekte en la token sed neniu sufikso estas uzata, do oni povas konkludi, ke ĝi estas `f64` poste en la kompililo.
    ///
    /// Literaloj kreitaj de negativaj nombroj eble ne postvivas retropafojn tra `TokenStream` aŭ ŝnuroj kaj povas esti disigitaj en du tokens (`-` kaj pozitiva laŭvorta).
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio postulas, ke la specifita flosilo estu finia, ekzemple se ĝi estas malfinio aŭ NaN, ĉi tiu funkcio estos panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Kreas novan sufiksitan glitkoman laŭvortan.
    ///
    /// Ĉi tiu konstruilo kreos laŭvortan kiel `1.0f64` kie la specifa valoro estas la antaŭa parto de la token kaj `f64` estas la sufikso de la token.
    /// Ĉi tiu token ĉiam estos konkludita kiel `f64` en la kompililo.
    /// Literaloj kreitaj de negativaj nombroj eble ne postvivas retropafojn tra `TokenStream` aŭ ŝnuroj kaj povas esti disigitaj en du tokens (`-` kaj pozitiva laŭvorta).
    ///
    ///
    /// # Panics
    ///
    /// Ĉi tiu funkcio postulas, ke la specifita flosilo estu finia, ekzemple se ĝi estas malfinio aŭ NaN, ĉi tiu funkcio estos panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Ŝnuro laŭvorta.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Signo laŭvorta.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Bajta ĉeno laŭvorta.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Liveras la interspacon ampleksantan ĉi tiun laŭvortan.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Agordas la interspacon asociitan por ĉi tiu laŭvorta.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Liveras `Span` kiu estas subaro de `self.span()` enhavanta nur la fontajn bajtojn en la rango `range`.
    /// Liveras `None` se la pretendita tajlita interspaco estas ekster la limoj de `self`.
    ///
    // FIXME(SergioBenitez): kontrolu, ke la bajta gamo komenciĝas kaj finiĝas ĉe UTF-8-limo de la fonto.
    // alie, verŝajne panic okazos aliloke kiam la fonta teksto estos presita.
    // FIXME(SergioBenitez): la uzanto ne povas scii, al kio `self.span()` efektive mapas, do ĉi tiu metodo nuntempe nur povas esti nomata blinde.
    // Ekzemple, `to_string()` por la signo 'c' redonas "'\u{63}'";la uzanto neniel povas scii ĉu la fontoteksto estis 'c' aŭ ĉu ĝi estis '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) io simila al `Option::cloned`, sed por `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, la ponto nur provizas `to_string`, efektivigu `fmt::Display` bazitan sur ĝi (la inversigo de la kutima rilato inter ambaŭ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Presas la laŭvorton kiel ĉenon, kiu devas esti senperde konvertebla reen en la saman laŭvorton (krom ebla rondigo por glitkomaj literoj).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Spurita aliro al mediaj variabloj.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Rekuperu median variablon kaj aldonu ĝin por krei dependajn informojn.
    /// Konstrua sistemo ekzekutanta la kompililon scios, ke la variablo estis alirita dum kompilo, kaj povos reruligi la konstruon kiam la valoro de tiu variablo ŝanĝiĝos.
    ///
    /// Krom la dependeca spurado ĉi tiu funkcio devas esti ekvivalenta al `env::var` de la norma biblioteko, krom ke la argumento devas esti UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}