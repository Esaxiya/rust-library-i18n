//! मानक पुस्तकालय में Panic समर्थन।

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// panic के बारे में जानकारी प्रदान करने वाली संरचना।
///
/// `PanicInfo` संरचना को [`set_hook`] फ़ंक्शन द्वारा सेट किए गए panic hook में पास किया जाता है।
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic से संबद्ध पेलोड लौटाता है।
    ///
    /// यह आमतौर पर, लेकिन हमेशा नहीं, एक `&'static str` या [`String`] होगा।
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// यदि `core` crate (`std` से नहीं) से `panic!` मैक्रो का उपयोग स्वरूपण स्ट्रिंग और कुछ अतिरिक्त तर्कों के साथ किया गया था, तो वह संदेश उदाहरण के लिए [`fmt::write`] के साथ उपयोग करने के लिए तैयार है
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// यदि उपलब्ध हो, तो उस स्थान के बारे में जानकारी देता है जहां से panic की उत्पत्ति हुई थी।
    ///
    /// यह विधि वर्तमान में हमेशा [`Some`] लौटाएगी, लेकिन यह future संस्करणों में बदल सकती है।
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: यदि इसे कभी-कभी वापस करने के लिए बदल दिया जाता है
        // std::panicking::default_hook और std::panicking::begin_panic_fmt में उस मामले से निपटें।
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: हम downcast_ref का उपयोग नहीं कर सकते: :<String>() यहां
        // चूंकि स्ट्रिंग libcore में उपलब्ध नहीं है!
        // पेलोड एक स्ट्रिंग है जब `std::panic!` को कई तर्कों के साथ बुलाया जाता है, लेकिन उस स्थिति में संदेश भी उपलब्ध होता है।
        //

        self.location.fmt(formatter)
    }
}

/// एक संरचना जिसमें panic के स्थान के बारे में जानकारी होती है।
///
/// यह संरचना [`PanicInfo::location()`] द्वारा बनाई गई है।
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// समानता और क्रम के लिए तुलना फ़ाइल, लाइन, फिर कॉलम प्राथमिकता में की जाती है।
/// फ़ाइलों की तुलना स्ट्रिंग के रूप में की जाती है, न कि `Path` के रूप में, जो अनपेक्षित हो सकती है।
/// अधिक चर्चा के लिए [`Location: :file`]'s दस्तावेज़ देखें।
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// इस फ़ंक्शन के कॉलर का स्रोत स्थान लौटाता है।
    /// यदि उस फ़ंक्शन के कॉलर को एनोटेट किया गया है, तो उसका कॉल स्थान वापस कर दिया जाएगा, और इसी तरह स्टैक पर एक गैर-ट्रैक किए गए फ़ंक्शन बॉडी के भीतर पहली कॉल पर।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// वह [`Location`] लौटाता है जिस पर इसे कहा जाता है।
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// इस फ़ंक्शन की परिभाषा के भीतर से एक [`Location`] लौटाता है।
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // एक ही ट्रैक न किए गए फ़ंक्शन को किसी भिन्न स्थान पर चलाने से हमें वही परिणाम मिलता है
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ट्रैक किए गए फ़ंक्शन को किसी भिन्न स्थान पर चलाने से भिन्न मान उत्पन्न होता है
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// स्रोत फ़ाइल का नाम देता है जिससे panic उत्पन्न हुआ।
    ///
    /// # `&str`, नहीं `&Path` not
    ///
    /// लौटाया गया नाम संकलन प्रणाली पर एक स्रोत पथ को संदर्भित करता है, लेकिन इसे सीधे `&Path` के रूप में प्रस्तुत करने के लिए मान्य नहीं है।
    /// संकलित कोड सामग्री प्रदान करने वाले सिस्टम की तुलना में एक अलग `Path` कार्यान्वयन के साथ एक अलग सिस्टम पर चल सकता है और इस पुस्तकालय में वर्तमान में एक अलग "host path" प्रकार नहीं है।
    ///
    /// सबसे आश्चर्यजनक व्यवहार तब होता है जब "the same" फ़ाइल मॉड्यूल सिस्टम (आमतौर पर `#[path = "..."]` विशेषता या समान का उपयोग करके) में कई पथों के माध्यम से पहुंच योग्य होती है, जो इस फ़ंक्शन से भिन्न मान वापस करने के लिए समान कोड प्रतीत होता है।
    ///
    ///
    /// # Cross-compilation
    ///
    /// जब होस्ट प्लेटफ़ॉर्म और लक्ष्य प्लेटफ़ॉर्म भिन्न होते हैं, तो यह मान `Path::new` या इसी तरह के कंस्ट्रक्टर को पास करने के लिए उपयुक्त नहीं है।
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// वह पंक्ति संख्या देता है जिससे panic उत्पन्न हुआ है।
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// वह कॉलम लौटाता है जिससे panic उत्पन्न हुआ है।
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// एक आंतरिक trait जिसका उपयोग libstd द्वारा libstd से `panic_unwind` और अन्य panic रनटाइम में डेटा पास करने के लिए किया जाता है।
/// जल्द ही किसी भी समय स्थिर होने का इरादा नहीं है, उपयोग न करें।
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// सामग्री का पूर्ण स्वामित्व लें।
    /// वापसी प्रकार वास्तव में `Box<dyn Any + Send>` है, लेकिन हम libcore में `Box` का उपयोग नहीं कर सकते।
    ///
    /// इस विधि को कॉल करने के बाद, `self` में केवल कुछ डमी डिफ़ॉल्ट मान शेष हैं।
    /// इस विधि को दो बार कॉल करना, या इस विधि को कॉल करने के बाद `get` को कॉल करना, एक त्रुटि है।
    ///
    /// तर्क उधार लिया गया है क्योंकि panic रनटाइम (`__rust_start_panic`) केवल उधार लिया गया `dyn BoxMeUp` प्राप्त करता है।
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// बस सामग्री उधार लें।
    fn get(&mut self) -> &(dyn Any + Send);
}