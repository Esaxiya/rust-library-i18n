//! यह मॉड्यूल `Any` trait को लागू करता है, जो रनटाइम प्रतिबिंब के माध्यम से किसी भी `'static` प्रकार की गतिशील टाइपिंग को सक्षम बनाता है।
//!
//! `Any` `TypeId` प्राप्त करने के लिए स्वयं का उपयोग किया जा सकता है, और जब trait ऑब्जेक्ट के रूप में उपयोग किया जाता है तो इसमें अधिक सुविधाएं होती हैं।
//! `&dyn Any` (एक उधार ली गई trait ऑब्जेक्ट) के रूप में, इसमें `is` और `downcast_ref` विधियां हैं, यह जांचने के लिए कि निहित मान किसी दिए गए प्रकार का है, और एक प्रकार के रूप में आंतरिक मान का संदर्भ प्राप्त करने के लिए।
//! `&mut dyn Any` के रूप में, आंतरिक मान के लिए एक परिवर्तनीय संदर्भ प्राप्त करने के लिए `downcast_mut` विधि भी है।
//! `Box<dyn Any>` `downcast` विधि जोड़ता है, जो `Box<T>` में बदलने का प्रयास करता है।
//! पूर्ण विवरण के लिए [`Box`] दस्तावेज़ीकरण देखें।
//!
//! ध्यान दें कि `&dyn Any` यह परीक्षण करने के लिए सीमित है कि क्या मान एक निर्दिष्ट ठोस प्रकार का है, और इसका उपयोग यह परीक्षण करने के लिए नहीं किया जा सकता है कि कोई प्रकार trait लागू करता है या नहीं।
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # स्मार्ट पॉइंटर्स और `dyn Any`
//!
//! `Any` को trait ऑब्जेक्ट के रूप में उपयोग करते समय ध्यान में रखने के लिए व्यवहार का एक टुकड़ा, विशेष रूप से `Box<dyn Any>` या `Arc<dyn Any>` जैसे प्रकारों के साथ, यह है कि केवल `.type_id()` को मूल्य पर कॉल करने से *कंटेनर* का `TypeId` उत्पन्न होगा, न कि अंतर्निहित trait ऑब्जेक्ट।
//!
//! इसके बजाय स्मार्ट पॉइंटर को `&dyn Any` में परिवर्तित करके इसे टाला जा सकता है, जो ऑब्जेक्ट का `TypeId` लौटाएगा।
//! उदाहरण के लिए:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // आप इसे अधिक चाहते हैं:
//! let actual_id = (&*boxed).type_id();
//! // ... इस से:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! ऐसी स्थिति पर विचार करें जहां हम किसी फ़ंक्शन को दिए गए मान को लॉग आउट करना चाहते हैं।
//! हम उस मूल्य को जानते हैं जो हम डिबग को लागू करने पर काम कर रहे हैं, लेकिन हम इसके ठोस प्रकार को नहीं जानते हैं।हम कुछ प्रकार के लिए विशेष उपचार देना चाहते हैं: इस मामले में उनके मूल्य से पहले स्ट्रिंग मानों की लंबाई को प्रिंट करना।
//! संकलन समय पर हम अपने मूल्य के ठोस प्रकार को नहीं जानते हैं, इसलिए हमें इसके बजाय रनटाइम प्रतिबिंब का उपयोग करने की आवश्यकता है।
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // किसी भी प्रकार के लिए लॉगर फ़ंक्शन जो डीबग लागू करता है।
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // हमारे मान को `String` में बदलने का प्रयास करें।
//!     // सफल होने पर, हम स्ट्रिंग की लंबाई के साथ-साथ इसके मूल्य को भी आउटपुट करना चाहते हैं।
//!     // यदि नहीं, तो यह एक अलग प्रकार है: बस इसे बिना अलंकृत प्रिंट करें।
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // यह फ़ंक्शन इसके साथ काम करने से पहले इसके पैरामीटर को लॉग आउट करना चाहता है।
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ...कोई और काम करो
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// कोई भी trait
///////////////////////////////////////////////////////////////////////////////

/// गतिशील टाइपिंग का अनुकरण करने के लिए एक trait।
///
/// अधिकांश प्रकार `Any` लागू करते हैं।हालांकि, कोई भी प्रकार जिसमें गैर-`'स्थिर' संदर्भ होता है, वह नहीं होता है।
/// अधिक जानकारी के लिए [module-level documentation][mod] देखें।
///
/// [mod]: crate::any
// यह trait असुरक्षित नहीं है, हालांकि हम असुरक्षित कोड (जैसे, `downcast`) में इसके एकमात्र impl के `type_id` फ़ंक्शन की बारीकियों पर भरोसा करते हैं।आम तौर पर, यह एक समस्या होगी, लेकिन क्योंकि `Any` का एकमात्र अर्थ एक कंबल कार्यान्वयन है, कोई अन्य कोड `Any` को लागू नहीं कर सकता है।
//
// हम संभावित रूप से इस trait को असुरक्षित बना सकते हैं-यह टूटने का कारण नहीं बनता है, क्योंकि हम सभी कार्यान्वयन को नियंत्रित करते हैं-लेकिन हम ऐसा नहीं चुनते हैं क्योंकि यह वास्तव में आवश्यक नहीं है और असुरक्षित traits और असुरक्षित तरीकों के भेद के बारे में उपयोगकर्ताओं को भ्रमित कर सकता है (यानी, `type_id` अभी भी कॉल करने के लिए सुरक्षित होगा, लेकिन हम संभवतः दस्तावेज़ीकरण में इस तरह इंगित करना चाहेंगे)।
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` का `TypeId` मिलता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// किसी भी trait ऑब्जेक्ट के लिए एक्सटेंशन विधियां।
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// सुनिश्चित करें कि उदाहरण के लिए, एक धागे में शामिल होने का परिणाम मुद्रित किया जा सकता है और इसलिए `unwrap` के साथ प्रयोग किया जाता है।
// यदि डिस्पैच अपकास्टिंग के साथ काम करता है, तो अंततः इसकी आवश्यकता नहीं रह जाएगी।
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// यदि बॉक्सिंग प्रकार `T` के समान है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // उस प्रकार का `TypeId` प्राप्त करें जिसके साथ यह फ़ंक्शन तत्काल है।
        let t = TypeId::of::<T>();

        // trait ऑब्जेक्ट (`self`) में प्रकार का `TypeId` प्राप्त करें।
        let concrete = self.type_id();

        // समानता पर दोनों `TypeId` की तुलना करें।
        t == concrete
    }

    /// बॉक्स किए गए मान के लिए कुछ संदर्भ देता है यदि यह `T` प्रकार का है, या यदि नहीं है तो `None`।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // सुरक्षा: अभी जाँच की गई है कि क्या हम सही प्रकार की ओर इशारा कर रहे हैं, और हम इस पर भरोसा कर सकते हैं
            // जो स्मृति सुरक्षा की जांच करते हैं क्योंकि हमने सभी प्रकार के लिए Any लागू किया है;कोई अन्य निहितार्थ मौजूद नहीं हो सकता क्योंकि वे हमारे निहितार्थ के साथ संघर्ष करेंगे।
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// यदि यह `T` प्रकार का है, या `None` नहीं है तो बॉक्स किए गए मान के लिए कुछ परिवर्तनशील संदर्भ देता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // सुरक्षा: अभी जाँच की गई है कि क्या हम सही प्रकार की ओर इशारा कर रहे हैं, और हम इस पर भरोसा कर सकते हैं
            // जो स्मृति सुरक्षा की जांच करते हैं क्योंकि हमने सभी प्रकार के लिए Any लागू किया है;कोई अन्य निहितार्थ मौजूद नहीं हो सकता क्योंकि वे हमारे निहितार्थ के साथ संघर्ष करेंगे।
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` प्रकार पर परिभाषित विधि के लिए आगे।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` प्रकार पर परिभाषित विधि के लिए आगे।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` प्रकार पर परिभाषित विधि के लिए आगे।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` प्रकार पर परिभाषित विधि के लिए आगे।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` प्रकार पर परिभाषित विधि के लिए आगे।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` प्रकार पर परिभाषित विधि के लिए आगे।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// टाइपआईडी और इसके तरीके
///////////////////////////////////////////////////////////////////////////////

/// एक `TypeId` एक प्रकार के लिए विश्व स्तर पर अद्वितीय पहचानकर्ता का प्रतिनिधित्व करता है।
///
/// प्रत्येक `TypeId` एक अपारदर्शी वस्तु है जो अंदर क्या है इसका निरीक्षण करने की अनुमति नहीं देता है लेकिन क्लोनिंग, तुलना, प्रिंटिंग और दिखाने जैसे बुनियादी संचालन की अनुमति देता है।
///
///
/// एक `TypeId` वर्तमान में केवल उन प्रकारों के लिए उपलब्ध है जो `'static` से संबंधित हैं, लेकिन इस सीमा को future में हटाया जा सकता है।
///
/// जबकि `TypeId` `Hash`, `PartialOrd`, और `Ord` को लागू करता है, यह ध्यान देने योग्य है कि Rust रिलीज़ के बीच हैश और ऑर्डरिंग अलग-अलग होंगे।
/// अपने कोड के अंदर उन पर भरोसा करने से सावधान रहें!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// इस जेनेरिक फ़ंक्शन के साथ तत्काल किए गए प्रकार के `TypeId` को लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// एक प्रकार का नाम स्ट्रिंग स्लाइस के रूप में देता है।
///
/// # Note
///
/// यह नैदानिक उपयोग के लिए अभिप्रेत है।
/// लौटाए गए स्ट्रिंग की सटीक सामग्री और प्रारूप निर्दिष्ट नहीं है, इस प्रकार का सर्वोत्तम प्रयास विवरण होने के अलावा।
/// उदाहरण के लिए, `type_name::<Option<String>>()` वापस आने वाले स्ट्रिंग्स में `"Option<String>"` और `"std::option::Option<std::string::String>"` हैं।
///
///
/// लौटाई गई स्ट्रिंग को एक प्रकार का विशिष्ट पहचानकर्ता नहीं माना जाना चाहिए क्योंकि कई प्रकार एक ही प्रकार के नाम पर मैप कर सकते हैं।
/// इसी तरह, इस बात की कोई गारंटी नहीं है कि किसी प्रकार के सभी भाग लौटाए गए स्ट्रिंग में दिखाई देंगे: उदाहरण के लिए, आजीवन विनिर्देशक वर्तमान में शामिल नहीं हैं।
/// इसके अलावा, आउटपुट कंपाइलर के संस्करणों के बीच बदल सकता है।
///
/// वर्तमान कार्यान्वयन कंपाइलर डायग्नोस्टिक्स और डिबगइन्फो के समान बुनियादी ढांचे का उपयोग करता है, लेकिन इसकी गारंटी नहीं है।
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// एक स्ट्रिंग स्लाइस के रूप में पॉइंट-टू-वैल्यू के प्रकार का नाम देता है।
/// यह `type_name::<T>()` जैसा ही है, लेकिन इसका उपयोग वहां किया जा सकता है जहां एक चर का प्रकार आसानी से उपलब्ध नहीं है।
///
/// # Note
///
/// यह नैदानिक उपयोग के लिए अभिप्रेत है।स्ट्रिंग की सटीक सामग्री और प्रारूप निर्दिष्ट नहीं है, सिवाय इस प्रकार के सर्वोत्तम प्रयास विवरण के।
/// उदाहरण के लिए, `type_name_of_val::<Option<String>>(None)` `"Option<String>"` या `"std::option::Option<std::string::String>"` लौटा सकता है, लेकिन `"foobar"` नहीं।
///
/// इसके अलावा, आउटपुट कंपाइलर के संस्करणों के बीच बदल सकता है।
///
/// यह फ़ंक्शन trait ऑब्जेक्ट को हल नहीं करता है, जिसका अर्थ है कि `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` लौटा सकता है, लेकिन `"u32"` नहीं।
///
/// प्रकार के नाम को किसी प्रकार का विशिष्ट पहचानकर्ता नहीं माना जाना चाहिए;
/// एकाधिक प्रकार एक ही प्रकार का नाम साझा कर सकते हैं।
///
/// वर्तमान कार्यान्वयन कंपाइलर डायग्नोस्टिक्स और डिबगइन्फो के समान बुनियादी ढांचे का उपयोग करता है, लेकिन इसकी गारंटी नहीं है।
///
/// # Examples
///
/// डिफ़ॉल्ट पूर्णांक और फ्लोट प्रकार प्रिंट करता है।
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}