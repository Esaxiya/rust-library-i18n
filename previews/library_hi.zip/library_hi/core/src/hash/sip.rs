//! सिपहाश का कार्यान्वयन।

#![allow(deprecated)] // इस मॉड्यूल के प्रकार बहिष्कृत हैं

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// सिपहैश 1-3 का कार्यान्वयन।
///
/// यह वर्तमान में मानक पुस्तकालय द्वारा उपयोग किया जाने वाला डिफ़ॉल्ट हैशिंग फ़ंक्शन है (उदाहरण के लिए, `collections::HashMap` डिफ़ॉल्ट रूप से इसका उपयोग करता है)।
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// सिपहैश 2-4 का कार्यान्वयन।
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// सिपहैश 2-4 का कार्यान्वयन।
///
/// See: <https://131002.net/siphash/>
///
/// SipHash एक सामान्य-उद्देश्य हैशिंग फ़ंक्शन है: यह एक अच्छी गति (स्पूकी और सिटी के साथ प्रतिस्पर्धी) पर चलता है और मजबूत _keyed_ हैशिंग की अनुमति देता है।
///
/// यह आपको अपने हैश टेबल को एक मजबूत RNG, जैसे [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) से कुंजी करने देता है।
///
/// हालांकि SipHash एल्गोरिथम को आम तौर पर मजबूत माना जाता है, यह क्रिप्टोग्राफ़िक उद्देश्यों के लिए अभिप्रेत नहीं है।
/// जैसे, इस कार्यान्वयन के सभी क्रिप्टोग्राफ़िक उपयोग _strongly discouraged_ हैं।
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // हमने कितने बाइट संसाधित किए हैं
    state: State,  // हैश स्टेट
    tail: u64,     // असंसाधित बाइट्स ले
    ntail: usize,  // टेल में कितने बाइट मान्य होते हैं
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 और v1, v3 एल्गोरिथम में जोड़े में दिखाई देते हैं, और SipHash के सिमड कार्यान्वयन v02 और v13 के vectors का उपयोग करेंगे।
    //
    // उन्हें इस क्रम में संरचना में रखकर, संकलक केवल कुछ सिम ऑप्टिमाइज़ेशन को स्वयं ही उठा सकता है।
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// LE क्रम में बाइट स्ट्रीम से वांछित प्रकार का पूर्णांक लोड करता है।
/// `copy_nonoverlapping` का उपयोग संकलक को संभावित रूप से असंरेखित पते से लोड करने का सबसे कुशल तरीका उत्पन्न करने के लिए करता है।
///
///
/// असुरक्षित क्योंकि: i..i+size_of(int_ty) पर अनियंत्रित अनुक्रमण index
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// एक बाइट स्लाइस के 7 बाइट तक का उपयोग करके u64 लोड करता है।
/// यह अनाड़ी लगता है लेकिन (`load_int_le!` के माध्यम से) होने वाली `copy_nonoverlapping` कॉलों का आकार निश्चित होता है और `memcpy` को कॉल करने से बचें, जो गति के लिए अच्छा है।
///
///
/// असुरक्षित क्योंकि: प्रारंभ में अनियंत्रित अनुक्रमण..प्रारंभ+लेन
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // आउटपुट u64. में वर्तमान बाइट इंडेक्स (LSB से)
    let mut out = 0;
    if i + 3 < len {
        // सुरक्षा: `i`, `len` से बड़ा नहीं हो सकता, और कॉल करने वाले को गारंटी देनी चाहिए
        // कि अनुक्रमणिका start..start+len सीमा में है।
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // सुरक्षा: ऊपर के समान।
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // सुरक्षा: ऊपर के समान।
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// 0 पर सेट दो प्रारंभिक कुंजियों के साथ एक नया `SipHasher` बनाता है।
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// एक `SipHasher` बनाता है जो प्रदान की गई कुंजियों से बंद होता है।
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// 0 पर सेट दो प्रारंभिक कुंजियों के साथ एक नया `SipHasher13` बनाता है।
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// एक `SipHasher13` बनाता है जो प्रदान की गई कुंजियों से बंद होता है।
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: कोई पूर्णांक हैशिंग विधियाँ (`write_u *`, `write_i*`) परिभाषित नहीं हैं
    // इस प्रकार के लिए।
    // हम उन्हें जोड़ सकते हैं, librustc_data_structures/sip128.rs में `short_write` कार्यान्वयन की प्रतिलिपि बना सकते हैं, और `write_u *`/`write_i*` विधियों को `SipHasher`, `SipHasher13`, और `DefaultHasher` में जोड़ सकते हैं।
    //
    // यह कुछ बेंचमार्क पर संकलन गति को थोड़ा धीमा करने की कीमत पर, उन हैशर्स द्वारा पूर्णांक हैशिंग को बहुत तेज कर देगा।
    // विवरण के लिए #69152 देखें।
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // सुरक्षा: `cmp::min(length, needed)` `length` से अधिक नहीं होने की गारंटी है
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // बफर्ड टेल अब फ्लश हो गई है, नए इनपुट को प्रोसेस करें।
        let len = length - needed;
        let left = len & 0x7; // लेन% 8

        let mut i = needed;
        while i < len - left {
            // सुरक्षा: क्योंकि `len - left` 8 के नीचे का सबसे बड़ा गुणज है
            // `len`, और क्योंकि `i` `needed` से शुरू होता है जहां `len` `length - needed` है, `i + 8` `length` से कम या उसके बराबर होने की गारंटी है।
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // सुरक्षा: `i` अब `needed + len.div_euclid(8) * 8` है,
        // तो `i + left` = `needed + len` = `length`, जो कि परिभाषा के अनुसार `msg.len()` के बराबर है।
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// 0 पर सेट दो प्रारंभिक कुंजियों के साथ एक `Hasher<S>` बनाता है।
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}