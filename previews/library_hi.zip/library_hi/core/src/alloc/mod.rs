//! मेमोरी आवंटन एपीआई

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` त्रुटि एक आवंटन विफलता को इंगित करती है जो इस आवंटक के साथ दिए गए इनपुट तर्कों को जोड़ते समय संसाधन थकावट या कुछ गलत होने के कारण हो सकती है।
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (हमें trait त्रुटि के डाउनस्ट्रीम इम्प्लांट के लिए इसकी आवश्यकता है)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` का कार्यान्वयन [`Layout`][] के माध्यम से वर्णित डेटा के मनमाने ब्लॉकों को आवंटित, विकसित, सिकोड़ और हटा सकता है।
///
/// `Allocator` ZSTs, संदर्भ, या स्मार्ट पॉइंटर्स पर लागू करने के लिए डिज़ाइन किया गया है क्योंकि आवंटित स्मृति में पॉइंटर्स को अपडेट किए बिना `MyAlloc([u8; N])` जैसे आवंटक को स्थानांतरित नहीं किया जा सकता है।
///
/// [`GlobalAlloc`][] के विपरीत, `Allocator` में शून्य आकार के आवंटन की अनुमति है।
/// यदि कोई अंतर्निहित आवंटक इसका समर्थन नहीं करता है (जैसे जेमलोक) या एक शून्य सूचक (जैसे `libc::malloc`) लौटाता है, तो इसे कार्यान्वयन द्वारा पकड़ा जाना चाहिए।
///
/// ### वर्तमान में आवंटित स्मृति
///
/// कुछ विधियों के लिए एक आवंटक के माध्यम से मेमोरी ब्लॉक *वर्तमान में आवंटित* होना आवश्यक है।इस का मतलब है कि:
///
/// * उस मेमोरी ब्लॉक के लिए प्रारंभिक पता पहले [`allocate`], [`grow`], या [`shrink`] द्वारा लौटाया गया था, और
///
/// * मेमोरी ब्लॉक को बाद में डिलोकेट नहीं किया गया है, जहां ब्लॉक या तो सीधे [`deallocate`] को पास किए जा रहे हैं या [`grow`] या [`shrink`] को पास करके बदल दिए गए हैं जो `Ok` लौटाते हैं।
///
/// यदि `grow` या `shrink` ने `Err` लौटाया है, तो पारित सूचक वैध रहता है।
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### मेमोरी फिटिंग
///
/// कुछ विधियों के लिए आवश्यक है कि एक लेआउट *फिट* एक मेमोरी ब्लॉक।
/// "fit" के लिए एक मेमोरी ब्लॉक के लेआउट के लिए इसका क्या अर्थ है (या समकक्ष, एक मेमोरी ब्लॉक के लिए "fit" एक लेआउट के लिए) यह है कि निम्नलिखित शर्तें होनी चाहिए:
///
/// * ब्लॉक को [`layout.align()`] के समान संरेखण के साथ आवंटित किया जाना चाहिए, और
///
/// * प्रदान किया गया [`layout.size()`] `min ..= max` की श्रेणी में आना चाहिए, जहां:
///   - `min` हाल ही में ब्लॉक आवंटित करने के लिए उपयोग किए गए लेआउट का आकार है, और
///   - `max` [`allocate`], [`grow`], या [`shrink`] से लौटाया गया नवीनतम वास्तविक आकार है।
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * एक आवंटक से लौटाए गए मेमोरी ब्लॉक को वैध मेमोरी को इंगित करना चाहिए और उनकी वैधता को तब तक बनाए रखना चाहिए जब तक कि इंस्टेंस और उसके सभी क्लोन हटा नहीं दिए जाते,
///
/// * आवंटनकर्ता को क्लोन करना या स्थानांतरित करना इस आवंटक से लौटाए गए मेमोरी ब्लॉक को अमान्य नहीं करना चाहिए।एक क्लोन आवंटक को उसी आवंटक की तरह व्यवहार करना चाहिए, और
///
/// * मेमोरी ब्लॉक का कोई भी पॉइंटर जो कि [*currently allocated*] है, आवंटक के किसी अन्य तरीके से पास किया जा सकता है।
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// स्मृति के एक ब्लॉक को आवंटित करने का प्रयास।
    ///
    /// सफलता मिलने पर, `layout` के आकार और संरेखण गारंटी को पूरा करने वाला [`NonNull<[u8]>`][NonNull] लौटाता है।
    ///
    /// लौटाए गए ब्लॉक में `layout.size()` द्वारा निर्दिष्ट आकार से बड़ा आकार हो सकता है, और इसकी सामग्री प्रारंभ हो सकती है या नहीं भी हो सकती है।
    ///
    /// # Errors
    ///
    /// रिटर्निंग `Err` इंगित करता है कि या तो मेमोरी समाप्त हो गई है या `layout` आवंटक के आकार या संरेखण बाधाओं को पूरा नहीं करता है।
    ///
    /// कार्यान्वयन को प्रोत्साहित किया जाता है कि `Err` को घबराने या निरस्त करने के बजाय स्मृति थकावट पर वापस कर दिया जाए, लेकिन यह एक सख्त आवश्यकता नहीं है।
    /// (विशेष रूप से: इस trait को एक अंतर्निहित मूल आवंटन पुस्तकालय के ऊपर लागू करने के लिए यह *कानूनी* है जो स्मृति थकावट पर रोकता है।)
    ///
    /// आबंटन त्रुटि के जवाब में गणना को रद्द करने के इच्छुक ग्राहकों को सीधे `panic!` या इसी तरह का आह्वान करने के बजाय [`handle_alloc_error`] फ़ंक्शन को कॉल करने के लिए प्रोत्साहित किया जाता है।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` की तरह व्यवहार करता है, लेकिन यह भी सुनिश्चित करता है कि लौटाई गई मेमोरी शून्य-प्रारंभिक है।
    ///
    /// # Errors
    ///
    /// रिटर्निंग `Err` इंगित करता है कि या तो मेमोरी समाप्त हो गई है या `layout` आवंटक के आकार या संरेखण बाधाओं को पूरा नहीं करता है।
    ///
    /// कार्यान्वयन को प्रोत्साहित किया जाता है कि `Err` को घबराने या निरस्त करने के बजाय स्मृति थकावट पर वापस कर दिया जाए, लेकिन यह एक सख्त आवश्यकता नहीं है।
    /// (विशेष रूप से: इस trait को एक अंतर्निहित मूल आवंटन पुस्तकालय के ऊपर लागू करने के लिए यह *कानूनी* है जो स्मृति थकावट पर रोकता है।)
    ///
    /// आबंटन त्रुटि के जवाब में गणना को रद्द करने के इच्छुक ग्राहकों को सीधे `panic!` या इसी तरह का आह्वान करने के बजाय [`handle_alloc_error`] फ़ंक्शन को कॉल करने के लिए प्रोत्साहित किया जाता है।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // सुरक्षा: `alloc` एक वैध मेमोरी ब्लॉक लौटाता है
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` द्वारा संदर्भित मेमोरी को हटाता है।
    ///
    /// # Safety
    ///
    /// * `ptr` इस आवंटक के माध्यम से मेमोरी [*currently allocated*] के एक ब्लॉक को निरूपित करना चाहिए, और
    /// * `layout` मेमोरी के उस ब्लॉक को [*fit*] करना चाहिए।
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// मेमोरी ब्लॉक को बढ़ाने का प्रयास।
    ///
    /// एक नया [`NonNull<[u8]>`][NonNull] देता है जिसमें एक पॉइंटर और आवंटित मेमोरी का वास्तविक आकार होता है।सूचक `new_layout` द्वारा वर्णित डेटा रखने के लिए उपयुक्त है।
    /// इसे पूरा करने के लिए, आवंटक नए लेआउट को फिट करने के लिए `ptr` द्वारा संदर्भित आवंटन का विस्तार कर सकता है।
    ///
    /// यदि यह `Ok` लौटाता है, तो `ptr` द्वारा संदर्भित मेमोरी ब्लॉक का स्वामित्व इस आवंटक को स्थानांतरित कर दिया गया है।
    /// स्मृति मुक्त हो सकती है या नहीं भी हो सकती है, और इसे तब तक अनुपयोगी माना जाना चाहिए जब तक कि इसे इस पद्धति के वापसी मूल्य के माध्यम से फिर से कॉलर को स्थानांतरित नहीं किया जाता है।
    ///
    /// यदि यह विधि `Err` लौटाती है, तो मेमोरी ब्लॉक का स्वामित्व इस आवंटक को हस्तांतरित नहीं किया गया है, और मेमोरी ब्लॉक की सामग्री अपरिवर्तित है।
    ///
    /// # Safety
    ///
    /// * `ptr` इस आवंटक के माध्यम से मेमोरी [*currently allocated*] के एक ब्लॉक को निरूपित करना चाहिए।
    /// * `old_layout` मेमोरी के उस ब्लॉक को [*fit*] होना चाहिए (`new_layout` तर्क को इसे फिट करने की आवश्यकता नहीं है।)
    /// * `new_layout.size()` `old_layout.size()` से बड़ा या उसके बराबर होना चाहिए।
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// यदि नया लेआउट आवंटक के आकार और आवंटक के संरेखण बाधाओं को पूरा नहीं करता है, या यदि बढ़ना अन्यथा विफल हो जाता है, तो `Err` लौटाता है।
    ///
    /// कार्यान्वयन को प्रोत्साहित किया जाता है कि `Err` को घबराने या निरस्त करने के बजाय स्मृति थकावट पर वापस कर दिया जाए, लेकिन यह एक सख्त आवश्यकता नहीं है।
    /// (विशेष रूप से: इस trait को एक अंतर्निहित मूल आवंटन पुस्तकालय के ऊपर लागू करने के लिए यह *कानूनी* है जो स्मृति थकावट पर रोकता है।)
    ///
    /// आबंटन त्रुटि के जवाब में गणना को रद्द करने के इच्छुक ग्राहकों को सीधे `panic!` या इसी तरह का आह्वान करने के बजाय [`handle_alloc_error`] फ़ंक्शन को कॉल करने के लिए प्रोत्साहित किया जाता है।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // सुरक्षा: क्योंकि `new_layout.size()`. से बड़ा या उसके बराबर होना चाहिए
        // `old_layout.size()`, दोनों पुराने और नए मेमोरी आवंटन `old_layout.size()` बाइट्स के लिए पढ़ने और लिखने के लिए मान्य हैं।
        // साथ ही, क्योंकि पुराने आवंटन को अभी तक डिलीकेट नहीं किया गया था, यह `new_ptr` को ओवरलैप नहीं कर सकता है।
        // इस प्रकार, `copy_nonoverlapping` पर कॉल सुरक्षित है।
        // `dealloc` के सुरक्षा अनुबंध को कॉलर द्वारा बरकरार रखा जाना चाहिए।
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` की तरह व्यवहार करता है, लेकिन यह भी सुनिश्चित करता है कि नई सामग्री वापस आने से पहले शून्य पर सेट हो।
    ///
    /// एक सफल कॉल के बाद मेमोरी ब्लॉक में निम्नलिखित सामग्री होगी
    /// `grow_zeroed`:
    ///   * बाइट्स `0..old_layout.size()` मूल आवंटन से संरक्षित हैं।
    ///   * आवंटक कार्यान्वयन के आधार पर बाइट्स `old_layout.size()..old_size` को या तो संरक्षित या शून्य किया जाएगा।
    ///   `old_size` `grow_zeroed` कॉल से पहले मेमोरी ब्लॉक के आकार को संदर्भित करता है, जो उस आकार से बड़ा हो सकता है जिसे मूल रूप से आवंटित किए जाने पर अनुरोध किया गया था।
    ///   * बाइट्स `old_size..new_size` शून्य हैं।`new_size`, `grow_zeroed` कॉल द्वारा लौटाए गए मेमोरी ब्लॉक के आकार को संदर्भित करता है।
    ///
    /// # Safety
    ///
    /// * `ptr` इस आवंटक के माध्यम से मेमोरी [*currently allocated*] के एक ब्लॉक को निरूपित करना चाहिए।
    /// * `old_layout` मेमोरी के उस ब्लॉक को [*fit*] होना चाहिए (`new_layout` तर्क को इसे फिट करने की आवश्यकता नहीं है।)
    /// * `new_layout.size()` `old_layout.size()` से बड़ा या उसके बराबर होना चाहिए।
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// यदि नया लेआउट आवंटक के आकार और आवंटक के संरेखण बाधाओं को पूरा नहीं करता है, या यदि बढ़ना अन्यथा विफल हो जाता है, तो `Err` लौटाता है।
    ///
    /// कार्यान्वयन को प्रोत्साहित किया जाता है कि `Err` को घबराने या निरस्त करने के बजाय स्मृति थकावट पर वापस कर दिया जाए, लेकिन यह एक सख्त आवश्यकता नहीं है।
    /// (विशेष रूप से: इस trait को एक अंतर्निहित मूल आवंटन पुस्तकालय के ऊपर लागू करने के लिए यह *कानूनी* है जो स्मृति थकावट पर रोकता है।)
    ///
    /// आबंटन त्रुटि के जवाब में गणना को रद्द करने के इच्छुक ग्राहकों को सीधे `panic!` या इसी तरह का आह्वान करने के बजाय [`handle_alloc_error`] फ़ंक्शन को कॉल करने के लिए प्रोत्साहित किया जाता है।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // सुरक्षा: क्योंकि `new_layout.size()`. से बड़ा या उसके बराबर होना चाहिए
        // `old_layout.size()`, दोनों पुराने और नए मेमोरी आवंटन `old_layout.size()` बाइट्स के लिए पढ़ने और लिखने के लिए मान्य हैं।
        // साथ ही, क्योंकि पुराने आवंटन को अभी तक डिलीकेट नहीं किया गया था, यह `new_ptr` को ओवरलैप नहीं कर सकता है।
        // इस प्रकार, `copy_nonoverlapping` पर कॉल सुरक्षित है।
        // `dealloc` के सुरक्षा अनुबंध को कॉलर द्वारा बरकरार रखा जाना चाहिए।
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// मेमोरी ब्लॉक को सिकोड़ने का प्रयास।
    ///
    /// एक नया [`NonNull<[u8]>`][NonNull] देता है जिसमें एक पॉइंटर और आवंटित मेमोरी का वास्तविक आकार होता है।सूचक `new_layout` द्वारा वर्णित डेटा रखने के लिए उपयुक्त है।
    /// इसे पूरा करने के लिए, आवंटक नए लेआउट को फिट करने के लिए `ptr` द्वारा संदर्भित आवंटन को छोटा कर सकता है।
    ///
    /// यदि यह `Ok` लौटाता है, तो `ptr` द्वारा संदर्भित मेमोरी ब्लॉक का स्वामित्व इस आवंटक को स्थानांतरित कर दिया गया है।
    /// स्मृति मुक्त हो सकती है या नहीं भी हो सकती है, और इसे तब तक अनुपयोगी माना जाना चाहिए जब तक कि इसे इस पद्धति के वापसी मूल्य के माध्यम से फिर से कॉलर को स्थानांतरित नहीं किया जाता है।
    ///
    /// यदि यह विधि `Err` लौटाती है, तो मेमोरी ब्लॉक का स्वामित्व इस आवंटक को हस्तांतरित नहीं किया गया है, और मेमोरी ब्लॉक की सामग्री अपरिवर्तित है।
    ///
    /// # Safety
    ///
    /// * `ptr` इस आवंटक के माध्यम से मेमोरी [*currently allocated*] के एक ब्लॉक को निरूपित करना चाहिए।
    /// * `old_layout` मेमोरी के उस ब्लॉक को [*fit*] होना चाहिए (`new_layout` तर्क को इसे फिट करने की आवश्यकता नहीं है।)
    /// * `new_layout.size()` `old_layout.size()` से छोटा या उसके बराबर होना चाहिए।
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// यदि नया लेआउट आवंटक के आकार और आवंटक के संरेखण बाधाओं को पूरा नहीं करता है, या यदि सिकुड़ना अन्यथा विफल रहता है, तो `Err` लौटाता है।
    ///
    /// कार्यान्वयन को प्रोत्साहित किया जाता है कि `Err` को घबराने या निरस्त करने के बजाय स्मृति थकावट पर वापस कर दिया जाए, लेकिन यह एक सख्त आवश्यकता नहीं है।
    /// (विशेष रूप से: इस trait को एक अंतर्निहित मूल आवंटन पुस्तकालय के ऊपर लागू करने के लिए यह *कानूनी* है जो स्मृति थकावट पर रोकता है।)
    ///
    /// आबंटन त्रुटि के जवाब में गणना को रद्द करने के इच्छुक ग्राहकों को सीधे `panic!` या इसी तरह का आह्वान करने के बजाय [`handle_alloc_error`] फ़ंक्शन को कॉल करने के लिए प्रोत्साहित किया जाता है।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // सुरक्षा: क्योंकि `new_layout.size()` से कम या बराबर होना चाहिए
        // `old_layout.size()`, दोनों पुराने और नए मेमोरी आवंटन `new_layout.size()` बाइट्स के लिए पढ़ने और लिखने के लिए मान्य हैं।
        // साथ ही, क्योंकि पुराने आवंटन को अभी तक डिलीकेट नहीं किया गया था, यह `new_ptr` को ओवरलैप नहीं कर सकता है।
        // इस प्रकार, `copy_nonoverlapping` पर कॉल सुरक्षित है।
        // `dealloc` के सुरक्षा अनुबंध को कॉलर द्वारा बरकरार रखा जाना चाहिए।
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `Allocator` की इस आवृत्ति के लिए एक "by reference" एडेप्टर बनाता है।
    ///
    /// लौटा हुआ एडेप्टर भी `Allocator` को लागू करता है और बस इसे उधार लेगा।
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // सुरक्षा: कॉलर द्वारा सुरक्षा अनुबंध को बरकरार रखा जाना चाहिए
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // सुरक्षा: कॉलर द्वारा सुरक्षा अनुबंध को बरकरार रखा जाना चाहिए
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // सुरक्षा: कॉलर द्वारा सुरक्षा अनुबंध को बरकरार रखा जाना चाहिए
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // सुरक्षा: कॉलर द्वारा सुरक्षा अनुबंध को बरकरार रखा जाना चाहिए
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}