//! वैकल्पिक मान।
//!
//! टाइप [`Option`] एक वैकल्पिक मान का प्रतिनिधित्व करता है: प्रत्येक [`Option`] या तो [`Some`] है और इसमें एक मान, या [`None`] है, और नहीं है।
//! [`Option`] Rust कोड में प्रकार बहुत आम हैं, क्योंकि उनके कई उपयोग हैं:
//!
//! * प्रारंभिक मान
//! * उन कार्यों के लिए वापसी मान जो उनकी संपूर्ण इनपुट श्रेणी (आंशिक कार्यों) पर परिभाषित नहीं हैं
//! * अन्यथा साधारण त्रुटियों की रिपोर्ट करने के लिए वापसी मान, जहां [`None`] त्रुटि पर लौटाया जाता है
//! * वैकल्पिक संरचना क्षेत्र
//! * स्ट्रक्चर फ़ील्ड जिन्हें उधार दिया जा सकता है या "taken"
//! * वैकल्पिक फ़ंक्शन तर्क
//! * अशक्त संकेत
//! * कठिन परिस्थितियों से चीजों की अदला-बदली
//!
//! [`Option`] को आमतौर पर पैटर्न मिलान के साथ जोड़ा जाता है ताकि किसी मान की उपस्थिति को क्वेरी किया जा सके और कार्रवाई की जा सके, हमेशा [`None`] मामले के लिए लेखांकन।
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // फ़ंक्शन का वापसी मान एक विकल्प है
//! let result = divide(2.0, 3.0);
//!
//! // मान प्राप्त करने के लिए पैटर्न मिलान
//! match result {
//!     // विभाजन वैध था
//!     Some(x) => println!("Result: {}", x),
//!     // विभाजन अमान्य था
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: दिखाएं कि कैसे `Option` का प्रयोग अभ्यास में किया जाता है, कई विधियों के साथ
//
//! # विकल्प और संकेत ("nullable" संकेत)
//!
//! Rust के सूचक प्रकार हमेशा एक वैध स्थान की ओर इशारा करते हैं;कोई "null" संदर्भ नहीं हैं।इसके बजाय, Rust में *वैकल्पिक* पॉइंटर्स हैं, जैसे वैकल्पिक स्वामित्व वाला बॉक्स, [`Option`]`<`[`बॉक्स<T>`]`>`।
//!
//! निम्न उदाहरण [`i32`] का वैकल्पिक बॉक्स बनाने के लिए [`Option`] का उपयोग करता है।
//! ध्यान दें कि पहले आंतरिक [`i32`] मान का उपयोग करने के लिए, `check_optional` फ़ंक्शन को यह निर्धारित करने के लिए पैटर्न मिलान का उपयोग करने की आवश्यकता है कि क्या बॉक्स का मान है (यानी, यह [`Some(...)`][`Some`]) है या ([`None`]) नहीं है।
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust निम्न प्रकार `T` को अनुकूलित करने की गारंटी देता है जैसे कि [`Option<T>`] का आकार `T` के समान है:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` इस सूची में से किसी एक प्रकार की संरचना करें।
//!
//! यह आगे गारंटी है कि, उपरोक्त मामलों के लिए, कोई भी `T` से `Option<T>` और `Some::<T>(_)` से `T` के सभी मान्य मानों से [`mem::transmute`] कर सकता है (लेकिन `None::<T>` को `T` में ट्रांसमिट करना अपरिभाषित व्यवहार है)।
//!
//! # Examples
//!
//! [`Option`] पर मेल खाने वाला मूल पैटर्न:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // निहित स्ट्रिंग का संदर्भ लें
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // विकल्प को नष्ट करते हुए निहित स्ट्रिंग को हटा दें
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! लूप से पहले [`None`] पर परिणाम प्रारंभ करें:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // खोजने के लिए डेटा की एक सूची।
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // हम सबसे बड़े जानवर के नाम की खोज करने जा रहे हैं, लेकिन शुरुआत करने के लिए हमें अभी `None` मिला है।
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // अब हमें कुछ बड़े जानवर का नाम मिल गया है
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// `Option` प्रकार।अधिक के लिए [the module level documentation](self) देखें।
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// कोई मूल्य नहीं
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// कुछ मूल्य `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// कार्यान्वयन टाइप करें
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // निहित मूल्यों को क्वेरी करना
    /////////////////////////////////////////////////////////////////////////

    /// यदि विकल्प [`Some`] मान है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// यदि विकल्प [`None`] मान है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// यदि विकल्प दिए गए मान वाला [`Some`] मान है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // संदर्भों के साथ काम करने के लिए एडेप्टर
    /////////////////////////////////////////////////////////////////////////

    /// `&Option<T>` से `Option<&T>` में कनवर्ट करता है।
    ///
    /// # Examples
    ///
    /// मूल को संरक्षित करते हुए एक `Option<`[`String`]`>` को `Option<`[`usize`]`>` में बदल देता है।
    /// [`map`] विधि `self` तर्क को मान के आधार पर लेती है, मूल का उपभोग करती है, इसलिए यह तकनीक `as_ref` का उपयोग पहले मूल के अंदर मान के संदर्भ में `Option` लेने के लिए करती है।
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // सबसे पहले, `Option<String>` को `as_ref` के साथ `Option<&String>` पर कास्ट करें, फिर `map` के साथ *उस* का उपभोग करें, `text` को स्टैक पर छोड़ दें।
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// `&mut Option<T>` से `Option<&mut T>` में कनवर्ट करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// [`पिन`]`<&Option. से रूपांतरित होता है<T>>` से `विकल्प<`[`पिन`]`<&T>>` तक।
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // सुरक्षा: `x` को पिन किए जाने की गारंटी है क्योंकि यह `self`. से आता है
        // जिसे पिन किया गया है।
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// [`पिन`]`<&म्यूट विकल्प. से कनवर्ट करता है<T>>` से `विकल्प<`[`पिन`]`<&म्यूट टी>>`।
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // सुरक्षा: `get_unchecked_mut` का उपयोग `Option` को `self` के अंदर ले जाने के लिए कभी नहीं किया जाता है।
        // `x` पिन किए जाने की गारंटी है क्योंकि यह `self` से आता है जिसे पिन किया गया है।
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // निहित मूल्यों को प्राप्त करना
    /////////////////////////////////////////////////////////////////////////

    /// `self` मान का उपभोग करते हुए निहित [`Some`] मान लौटाता है।
    ///
    /// # Panics
    ///
    /// Panics यदि मान [`None`] है, तो `msg` द्वारा प्रदान किए गए कस्टम panic संदेश के साथ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// `self` मान का उपभोग करते हुए निहित [`Some`] मान लौटाता है।
    ///
    /// क्योंकि यह फ़ंक्शन panic हो सकता है, इसका उपयोग आमतौर पर हतोत्साहित किया जाता है।
    /// इसके बजाय, पैटर्न मिलान का उपयोग करना और [`None`] मामले को स्पष्ट रूप से संभालना पसंद करें, या [`unwrap_or`], [`unwrap_or_else`], या [`unwrap_or_default`] पर कॉल करें।
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics यदि स्व मान [`None`] के बराबर है।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// निहित [`Some`] मान या प्रदत्त डिफ़ॉल्ट लौटाता है।
    ///
    /// `unwrap_or` को दिए गए तर्कों का उत्सुकता से मूल्यांकन किया जाता है;यदि आप फ़ंक्शन कॉल का परिणाम पास कर रहे हैं, तो [`unwrap_or_else`] का उपयोग करने की अनुशंसा की जाती है, जिसका आलसी मूल्यांकन किया जाता है।
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// निहित [`Some`] मान लौटाता है या बंद होने से इसकी गणना करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// यह जाँचे बिना कि मान [`None`] नहीं है, `self` मान का उपभोग करते हुए निहित [`Some`] मान लौटाता है।
    ///
    ///
    /// # Safety
    ///
    /// [`None`] पर इस विधि को कॉल करना *[अपरिभाषित व्यवहार]* है।
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // अपरिभाषित व्यवहार!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // सुरक्षा: कॉलर द्वारा सुरक्षा अनुबंध को बरकरार रखा जाना चाहिए।
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // निहित मूल्यों को बदलना
    /////////////////////////////////////////////////////////////////////////

    /// किसी फ़ंक्शन को किसी निहित मान पर लागू करके `Option<T>` से `Option<U>` को मैप करता है।
    ///
    /// # Examples
    ///
    /// एक `Option<`[`String`]`>` को `Option<`[`usize`]`>` में परिवर्तित करता है, जो मूल का उपभोग करता है:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` स्वयं को *मूल्य से* लेता है, `maybe_some_string` का उपभोग करता है
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// किसी फ़ंक्शन को निहित मान (यदि कोई हो) पर लागू करता है, या प्रदत्त डिफ़ॉल्ट (यदि नहीं) देता है।
    ///
    /// `map_or` को दिए गए तर्कों का उत्सुकता से मूल्यांकन किया जाता है;यदि आप फ़ंक्शन कॉल का परिणाम पास कर रहे हैं, तो [`map_or_else`] का उपयोग करने की अनुशंसा की जाती है, जिसका आलसी मूल्यांकन किया जाता है।
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// किसी फ़ंक्शन को निहित मान (यदि कोई हो) पर लागू करता है, या एक डिफ़ॉल्ट (यदि नहीं) की गणना करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>` को [`Result<T, E>`] में बदल देता है, [`Some(v)`] से [`Ok(v)`] और [`None`] से [`Err(err)`] की मैपिंग करता है।
    ///
    /// `ok_or` को दिए गए तर्कों का उत्सुकता से मूल्यांकन किया जाता है;यदि आप फ़ंक्शन कॉल का परिणाम पास कर रहे हैं, तो [`ok_or_else`] का उपयोग करने की अनुशंसा की जाती है, जिसका आलसी मूल्यांकन किया जाता है।
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` को [`Result<T, E>`] में बदल देता है, [`Some(v)`] से [`Ok(v)`] और [`None`] से [`Err(err())`] की मैपिंग करता है।
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// विकल्प में `value` को प्रविष्ट करता है और फिर इसके लिए एक परिवर्तनशील संदर्भ देता है।
    ///
    /// यदि विकल्प में पहले से कोई मान है, तो पुराना मान हटा दिया जाता है।
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // सुरक्षा: ऊपर दिए गए कोड ने अभी-अभी विकल्प भरा है
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // इटरेटर कंस्ट्रक्टर
    /////////////////////////////////////////////////////////////////////////

    /// संभावित रूप से निहित मान पर एक पुनरावर्तक देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// संभावित रूप से निहित मान पर एक परिवर्तनीय पुनरावर्तक देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // मूल्यों पर बूलियन संचालन, उत्सुक और आलसी
    /////////////////////////////////////////////////////////////////////////

    /// यदि विकल्प [`None`] है, तो [`None`] लौटाता है, अन्यथा `optb` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// यदि विकल्प [`None`] है, तो [`None`] लौटाता है, अन्यथा `f` को लिपटे हुए मान के साथ कॉल करता है और परिणाम देता है।
    ///
    ///
    /// कुछ भाषाएं इस ऑपरेशन को फ्लैटमैप कहती हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// यदि विकल्प [`None`] है, तो [`None`] लौटाता है, अन्यथा `predicate` को रैप किए गए मान के साथ कॉल करता है और लौटाता है:
    ///
    ///
    /// - [`Some(t)`] यदि `predicate` `true` लौटाता है (जहाँ `t` लपेटा हुआ मान है), और
    /// - [`None`] यदि `predicate` `false` लौटाता है।
    ///
    /// यह फ़ंक्शन [`Iterator::filter()`] के समान कार्य करता है।
    /// आप कल्पना कर सकते हैं कि `Option<T>` एक या शून्य तत्वों पर एक पुनरावर्तक है।
    /// `filter()` आपको यह तय करने देता है कि किन तत्वों को रखना है।
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// यदि इसमें कोई मान है तो विकल्प लौटाता है, अन्यथा `optb` लौटाता है।
    ///
    /// `or` को दिए गए तर्कों का उत्सुकता से मूल्यांकन किया जाता है;यदि आप फ़ंक्शन कॉल का परिणाम पास कर रहे हैं, तो [`or_else`] का उपयोग करने की अनुशंसा की जाती है, जिसका आलसी मूल्यांकन किया जाता है।
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// यदि इसमें कोई मान है तो विकल्प लौटाता है, अन्यथा `f` को कॉल करता है और परिणाम देता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// [`Some`] लौटाता है यदि `self` में से एक, `optb`, [`Some`] है, अन्यथा [`None`] लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // प्रविष्टि-जैसे संचालन सम्मिलित करने के लिए यदि कोई नहीं है और एक संदर्भ वापस करें
    /////////////////////////////////////////////////////////////////////////

    /// विकल्प में `value` डालें यदि यह [`None`] है, तो निहित मान के लिए एक परिवर्तनशील संदर्भ देता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// विकल्प में डिफ़ॉल्ट मान सम्मिलित करता है यदि यह [`None`] है, तो निहित मान के लिए एक परिवर्तनशील संदर्भ देता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// `f` से परिकलित मान को विकल्प में सम्मिलित करता है यदि यह [`None`] है, तो निहित मान के लिए एक परिवर्तनशील संदर्भ देता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // सुरक्षा: `self` के लिए `None` वैरिएंट को `Some`. से बदल दिया गया होता
            // उपरोक्त कोड में भिन्नता।
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// विकल्प से मूल्य निकालता है, उसके स्थान पर एक [`None`] छोड़ता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// विकल्प में वास्तविक मान को पैरामीटर में दिए गए मान से बदल देता है, यदि मौजूद हो तो पुराने मान को वापस कर देता है, किसी एक को डीइनिशियलाइज़ किए बिना उसके स्थान पर [`Some`] छोड़ देता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// एक और `Option` के साथ ज़िप `self`।
    ///
    /// यदि `self`, `Some(s)` है और `other`, `Some(o)` है, तो यह विधि `Some((s, o))` लौटाती है।
    /// अन्यथा, `None` लौटा दिया जाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// ज़िप `self` और दूसरा `Option` फ़ंक्शन `f` के साथ।
    ///
    /// यदि `self`, `Some(s)` है और `other`, `Some(o)` है, तो यह विधि `Some(f(s, o))` लौटाती है।
    /// अन्यथा, `None` लौटा दिया जाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// विकल्प की सामग्री को कॉपी करके `Option<&T>` को `Option<T>` में मैप करें।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// विकल्प की सामग्री को कॉपी करके `Option<&mut T>` को `Option<T>` में मैप करें।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// विकल्प की सामग्री को क्लोन करके `Option<&T>` को `Option<T>` में मैप करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// विकल्प की सामग्री को क्लोन करके `Option<&mut T>` को `Option<T>` में मैप करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// [`None`] की अपेक्षा करते हुए `self` का उपभोग करता है और कुछ भी नहीं लौटाता है।
    ///
    /// # Panics
    ///
    /// Panics यदि मान एक [`Some`] है, जिसमें पारित संदेश और [`Some`] की सामग्री सहित panic संदेश है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // यह panic नहीं होगा, क्योंकि सभी कुंजियाँ अद्वितीय हैं।
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// [`None`] की अपेक्षा करते हुए `self` का उपभोग करता है और कुछ भी नहीं लौटाता है।
    ///
    /// # Panics
    ///
    /// Panics यदि मान एक [`Some`] है, तो कस्टम panic संदेश [`कुछ`] के मान द्वारा प्रदान किया गया है।
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // यह panic नहीं होगा, क्योंकि सभी कुंजियाँ अद्वितीय हैं।
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// निहित [`Some`] मान या डिफ़ॉल्ट लौटाता है
    ///
    /// `self` तर्क का उपभोग करता है, यदि [`Some`], निहित मान देता है, अन्यथा यदि [`None`], उस प्रकार के लिए [default value] लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// एक स्ट्रिंग को एक पूर्णांक में परिवर्तित करता है, खराब-निर्मित स्ट्रिंग्स को 0 (पूर्णांक के लिए डिफ़ॉल्ट मान) में बदल देता है।
    /// [`parse`] एक स्ट्रिंग को किसी अन्य प्रकार में कनवर्ट करता है जो [`FromStr`] लागू करता है, त्रुटि पर [`None`] लौटाता है।
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// `Option<T>` (या `&Option<T>`) से `Option<&T::Target>` में कनवर्ट करता है।
    ///
    /// मूल विकल्प को जगह में छोड़ देता है, मूल विकल्प के संदर्भ में एक नया बनाता है, इसके अतिरिक्त [`Deref`] के माध्यम से सामग्री को मजबूर करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// `Option<T>` (या `&mut Option<T>`) से `Option<&mut T::Target>` में कनवर्ट करता है।
    ///
    /// मूल `Option` को जगह में छोड़ देता है, एक नया बनाता है जिसमें आंतरिक प्रकार के `Deref::Target` प्रकार के लिए एक परिवर्तनीय संदर्भ होता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// [`Result`] के `Option` को `Option` के [`Result`] में स्थानांतरित करता है।
    ///
    /// [`None`] [`Ok`]`(`[`None`]`)` में मैप किया जाएगा।
    /// [`कुछ`]`(`[`ओके`]`(_))` और [`कुछ`]`(`[`इरेट`]`(_))` को [`ओके`]`में मैप किया जाएगा (`[`कुछ`]`(_))` और [`इरेट`]`(_)`।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// .expect() के कोड आकार को कम करने के लिए यह एक अलग फ़ंक्शन है।
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// .expect_none() के कोड आकार को कम करने के लिए यह एक अलग फ़ंक्शन है।
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Trait कार्यान्वयन
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// [`None`][Option::None] लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// संभावित रूप से निहित मूल्य पर एक उपभोग करने वाला पुनरावर्तक देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// `val` को नए `Some` में कॉपी करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// `&Option<T>` से `Option<&T>` में कनवर्ट करता है।
    ///
    /// # Examples
    ///
    /// मूल को संरक्षित करते हुए एक `Option<`[`String`]`>` को `Option<`[`usize`]`>` में बदल देता है।
    /// [`map`] विधि `self` तर्क को मान के आधार पर लेती है, मूल का उपभोग करती है, इसलिए यह तकनीक `as_ref` का उपयोग पहले मूल के अंदर मान के संदर्भ में `Option` लेने के लिए करती है।
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// `&mut Option<T>` से `Option<&mut T>`. में कनवर्ट करता है
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// विकल्प इटरेटर्स
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// [`Option`] के [`Some`] संस्करण के संदर्भ में एक पुनरावर्तक।
///
/// यदि [`Option`] एक [`Some`] है, तो इटरेटर एक मान देता है, अन्यथा कोई नहीं।
///
/// यह `struct` [`Option::iter`] फ़ंक्शन द्वारा बनाया गया है।
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// एक [`Option`] के [`Some`] संस्करण के एक परिवर्तनीय संदर्भ पर एक पुनरावर्तक।
///
/// यदि [`Option`] एक [`Some`] है, तो इटरेटर एक मान देता है, अन्यथा कोई नहीं।
///
/// यह `struct` [`Option::iter_mut`] फ़ंक्शन द्वारा बनाया गया है।
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// [`Option`] के [`Some`] वैरिएंट में मान से अधिक एक पुनरावर्तक।
///
/// यदि [`Option`] एक [`Some`] है, तो इटरेटर एक मान देता है, अन्यथा कोई नहीं।
///
/// यह `struct` [`Option::into_iter`] फ़ंक्शन द्वारा बनाया गया है।
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// प्रत्येक तत्व को [`Iterator`] में लेता है: यदि यह [`None`][Option::None] है, तो कोई और तत्व नहीं लिया जाता है, और [`None`][Option::None] वापस आ जाता है।
    /// यदि कोई [`None`][Option::None] नहीं होता है, तो प्रत्येक [`Option`] के मान वाला एक कंटेनर वापस कर दिया जाता है।
    ///
    /// # Examples
    ///
    /// यहां एक उदाहरण दिया गया है जो vector में प्रत्येक पूर्णांक को बढ़ाता है।
    /// हम `add` के चेक किए गए संस्करण का उपयोग करते हैं जो `None` लौटाता है जब गणना के परिणामस्वरूप अतिप्रवाह होता है।
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// जैसा कि आप देख सकते हैं, यह अपेक्षित, मान्य आइटम लौटाएगा।
    ///
    /// यहां एक और उदाहरण दिया गया है जो पूर्णांकों की दूसरी सूची से एक को घटाने की कोशिश करता है, इस बार अंडरफ्लो की जांच कर रहा है:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// चूंकि अंतिम तत्व शून्य है, यह अंडरफ्लो होगा।इस प्रकार, परिणामी मान `None` है।
    ///
    /// यहां पिछले उदाहरण पर एक भिन्नता है, यह दर्शाता है कि पहले `None` के बाद `iter` से कोई और तत्व नहीं लिया गया है।
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// चूंकि तीसरे तत्व के कारण अंडरफ्लो हुआ, इसलिए कोई और तत्व नहीं लिया गया, इसलिए `shared` का अंतिम मान 6 (= `3 + 2 + 1`) है, न कि 16।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): यह प्रदर्शन बग बंद होने पर इसे Iterator::scan से बदला जा सकता है।
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// त्रुटि प्रकार जो प्रयास ऑपरेटर (`?`) को `None` मान पर लागू करने के परिणामस्वरूप होता है।
/// यदि आप `x?` (जहाँ `x` एक `Option<T>` है) को अपने त्रुटि प्रकार में बदलने की अनुमति देना चाहते हैं, तो आप `YourErrorType` के लिए `impl From<NoneError>` लागू कर सकते हैं।
///
/// उस स्थिति में, `x?` एक फ़ंक्शन के भीतर जो `Result<_, YourErrorType>` लौटाता है, `None` मान को `Err` परिणाम में बदल देगा।
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// `Option<Option<T>>` से `Option<T>`. में कनवर्ट करता है
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// फ़्लैटनिंग एक समय में केवल एक स्तर के नेस्टिंग को हटाता है:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}