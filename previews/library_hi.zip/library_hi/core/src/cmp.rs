//! आदेश देने और तुलना करने के लिए कार्यक्षमता।
//!
//! इस मॉड्यूल में मूल्यों को क्रमबद्ध करने और तुलना करने के लिए विभिन्न उपकरण हैं।सारांश:
//!
//! * [`Eq`] और [`PartialEq`] traits हैं जो आपको क्रमशः मानों के बीच कुल और आंशिक समानता को परिभाषित करने की अनुमति देते हैं।
//! उन्हें लागू करने से `==` और `!=` ऑपरेटर्स ओवरलोड हो जाते हैं।
//! * [`Ord`] और [`PartialOrd`] traits हैं जो आपको क्रमशः मानों के बीच कुल और आंशिक क्रम को परिभाषित करने की अनुमति देते हैं।
//!
//! उन्हें लागू करने से `<`, `<=`, `>` और `>=` ऑपरेटर्स ओवरलोड हो जाते हैं।
//! * [`Ordering`] [`Ord`] और [`PartialOrd`] के मुख्य कार्यों द्वारा लौटाया गया एक एनम है, और एक ऑर्डरिंग का वर्णन करता है।
//! * [`Reverse`] एक संरचना है जो आपको आसानी से एक आदेश को उलटने की अनुमति देती है।
//! * [`max`] और [`min`] ऐसे कार्य हैं जो [`Ord`] का निर्माण करते हैं और आपको अधिकतम या न्यूनतम दो मान खोजने की अनुमति देते हैं।
//!
//! अधिक विवरण के लिए, सूची में प्रत्येक आइटम के संबंधित दस्तावेज़ देखें।
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait समानता तुलना के लिए जो [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) हैं।
///
/// यह trait आंशिक समानता की अनुमति देता है, उन प्रकारों के लिए जिनका पूर्ण तुल्यता संबंध नहीं है।
/// उदाहरण के लिए, फ़्लोटिंग पॉइंट नंबर `NaN != NaN` में, इसलिए फ़्लोटिंग पॉइंट प्रकार `PartialEq` लागू करते हैं लेकिन [`trait@Eq`] नहीं।
///
/// औपचारिक रूप से, समानता होनी चाहिए (सभी `a`, `b`, `c` प्रकार `A`, `B`, `C` के लिए):
///
/// - **सममित**: यदि `A: PartialEq<B>` और `B: PartialEq<A>`, तो **`a==b` का अर्थ है `b==a`**;तथा
///
/// - **सकर्मक**: यदि `A: PartialEq<B>` और `B: PartialEq<C>` और `A:
///   आंशिक समीकरण<C>`, फिर **`a==b`और `b == c` का अर्थ`a==c`** है।
///
/// ध्यान दें कि `B: PartialEq<A>` (symmetric) और `A: PartialEq<C>` (transitive) impls मौजूद होने के लिए बाध्य नहीं हैं, लेकिन ये आवश्यकताएं जब भी मौजूद होती हैं तब लागू होती हैं।
///
/// ## Derivable
///
/// इस trait को `#[derive]` के साथ इस्तेमाल किया जा सकता है।जब स्ट्रक्चर्स पर `व्युत्पन्न` होता है, तो दो उदाहरण समान होते हैं यदि सभी फ़ील्ड समान हैं, और यदि कोई फ़ील्ड समान नहीं हैं तो समान नहीं हैं।जब एनम पर `व्युत्पन्न` होता है, तो प्रत्येक संस्करण स्वयं के बराबर होता है और अन्य प्रकारों के बराबर नहीं होता है।
///
/// ## मैं `PartialEq` को कैसे कार्यान्वित कर सकता हूं?
///
/// `PartialEq` केवल [`eq`] पद्धति को लागू करने की आवश्यकता है;[`ne`] को डिफ़ॉल्ट रूप से इसके संदर्भ में परिभाषित किया गया है।[`ne`] के किसी भी मैनुअल कार्यान्वयन को * इस नियम का सम्मान करना चाहिए कि [`eq`] [`ne`] का सख्त उलटा है;वह है, `!(a == b)` अगर और केवल अगर `a != b`।
///
/// `PartialEq`, [`PartialOrd`], और [`Ord`] के कार्यान्वयन *एक दूसरे से सहमत* होने चाहिए।कुछ traits प्राप्त करके और दूसरों को मैन्युअल रूप से लागू करके गलती से उन्हें असहमत करना आसान है।
///
/// एक डोमेन के लिए एक उदाहरण कार्यान्वयन जिसमें दो पुस्तकों को एक ही पुस्तक माना जाता है यदि उनके आईएसबीएन मेल खाते हैं, भले ही प्रारूप भिन्न हों:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## मैं दो अलग-अलग प्रकारों की तुलना कैसे कर सकता हूं?
///
/// आप जिस प्रकार से तुलना कर सकते हैं उसे `PartialEq` के प्रकार पैरामीटर द्वारा नियंत्रित किया जाता है।
/// उदाहरण के लिए, आइए अपने पिछले कोड को थोड़ा संशोधित करें:
///
/// ```
/// // व्युत्पन्न उपकरण<BookFormat>==<BookFormat>तुलना
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // लागू<Book>==<BookFormat>तुलना
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // लागू<BookFormat>==<Book>तुलना
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book` को `impl PartialEq<BookFormat> for Book` में बदलकर, हम `BookFormat` की तुलना `Book` से करने की अनुमति देते हैं।
///
/// ऊपर की तरह की तुलना, जो संरचना के कुछ क्षेत्रों की उपेक्षा करती है, खतरनाक हो सकती है।यह आसानी से आंशिक तुल्यता संबंध के लिए आवश्यकताओं के अनपेक्षित उल्लंघन का कारण बन सकता है।
/// उदाहरण के लिए, यदि हमने `BookFormat` के लिए `PartialEq<Book>` के उपरोक्त कार्यान्वयन को रखा और `Book` के लिए `PartialEq<Book>` का कार्यान्वयन जोड़ा (या तो `#[derive]` के माध्यम से या पहले उदाहरण से मैन्युअल कार्यान्वयन के माध्यम से) तो परिणाम ट्रांज़िटिविटी का उल्लंघन करेगा:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// यह विधि `self` और `other` मानों के बराबर होने का परीक्षण करती है, और इसका उपयोग `==` द्वारा किया जाता है।
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// यह विधि `!=` के लिए परीक्षण करती है।
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// trait `PartialEq` का एक अर्थ उत्पन्न करने वाला मैक्रो व्युत्पन्न करें।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait समानता तुलना के लिए जो [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) हैं।
///
/// इसका मतलब है, कि `a == b` और `a != b` सख्त उलटा होने के अलावा, समानता होनी चाहिए (सभी `a`, `b` और `c` के लिए):
///
/// - reflexive: `a == a`;
/// - सममित: `a == b` का अर्थ है `b == a`;तथा
/// - सकर्मक: `a == b` और `b == c` का अर्थ है `a == c`।
///
/// इस गुण को संकलक द्वारा जाँचा नहीं जा सकता है, और इसलिए `Eq` का अर्थ [`PartialEq`] है, और इसमें कोई अतिरिक्त विधियाँ नहीं हैं।
///
/// ## Derivable
///
/// इस trait को `#[derive]` के साथ इस्तेमाल किया जा सकता है।
/// जब `व्युत्पन्न` d, क्योंकि `Eq` में कोई अतिरिक्त विधियाँ नहीं हैं, यह केवल संकलक को सूचित कर रहा है कि यह आंशिक तुल्यता संबंध के बजाय एक तुल्यता संबंध है।
///
/// ध्यान दें कि `derive` रणनीति के लिए आवश्यक है कि सभी फ़ील्ड `Eq` हों, जो हमेशा वांछित नहीं होता है।
///
/// ## मैं `Eq` को कैसे कार्यान्वित कर सकता हूं?
///
/// यदि आप `derive` रणनीति का उपयोग नहीं कर सकते हैं, तो निर्दिष्ट करें कि आपका प्रकार `Eq` लागू करता है, जिसमें कोई विधि नहीं है:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // इस पद्धति का उपयोग केवल#[व्युत्पन्न] द्वारा यह दावा करने के लिए किया जाता है कि एक प्रकार का प्रत्येक घटक#[व्युत्पन्न] स्वयं को लागू करता है, वर्तमान व्युत्पन्न आधारभूत संरचना का अर्थ है कि इस trait पर एक विधि का उपयोग किए बिना यह दावा करना लगभग असंभव है।
    //
    //
    // इसे कभी भी हाथ से लागू नहीं किया जाना चाहिए।
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// trait `Eq` का एक अर्थ उत्पन्न करने वाला मैक्रो व्युत्पन्न करें।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: इस संरचना का उपयोग केवल#[derive] to. द्वारा किया जाता है
// दावा करें कि एक प्रकार का प्रत्येक घटक Eq को लागू करता है।
//
// यह संरचना कभी भी उपयोगकर्ता कोड में प्रकट नहीं होनी चाहिए।
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// एक `Ordering` दो मानों के बीच तुलना का परिणाम है।
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// एक आदेश जहां एक तुलना मूल्य दूसरे से कम है।
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// एक आदेश जहां एक तुलना मूल्य दूसरे के बराबर है।
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// एक आदेश जहां एक तुलना मूल्य दूसरे से अधिक है।
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// यदि ऑर्डरिंग `Equal` वैरिएंट है तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// यदि ऑर्डरिंग `Equal` वैरिएंट नहीं है तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// यदि ऑर्डरिंग `Less` वैरिएंट है तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// यदि ऑर्डरिंग `Greater` वैरिएंट है तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// यदि ऑर्डरिंग या तो `Less` या `Equal` वैरिएंट है तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// यदि ऑर्डरिंग या तो `Greater` या `Equal` वैरिएंट है तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` को उलट देता है।
    ///
    /// * `Less` `Greater` हो जाता है।
    /// * `Greater` `Less` हो जाता है।
    /// * `Equal` `Equal` हो जाता है।
    ///
    /// # Examples
    ///
    /// बुनियादी व्यवहार:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// इस विधि का उपयोग तुलना को उलटने के लिए किया जा सकता है:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // सरणी को सबसे बड़े से सबसे छोटे में क्रमबद्ध करें।
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// चेन दो आदेश।
    ///
    /// `self` नहीं होने पर `self` लौटाता है।अन्यथा `other` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// दिए गए फ़ंक्शन के साथ ऑर्डरिंग को चेन करता है।
    ///
    /// `Equal` न होने पर `self` लौटाता है।
    /// अन्यथा `f` को कॉल करें और परिणाम लौटाएं।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// रिवर्स ऑर्डरिंग के लिए एक सहायक संरचना।
///
/// यह संरचना एक सहायक है जिसका उपयोग [`Vec::sort_by_key`] जैसे कार्यों के साथ किया जा सकता है और इसका उपयोग कुंजी के एक हिस्से को उलटने के लिए किया जा सकता है।
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait उन प्रकारों के लिए जो [total order](https://en.wikipedia.org/wiki/Total_order) बनाते हैं।
///
/// एक आदेश एक कुल आदेश है यदि यह (सभी `a`, `b` और `c` के लिए) है:
///
/// - कुल और असममित: बिल्कुल `a < b`, `a == b` या `a > b` में से एक सत्य है;तथा
/// - सकर्मक, `a < b` और `b < c` का अर्थ है `a < c`।`==` और `>` दोनों के लिए समान होना चाहिए।
///
/// ## Derivable
///
/// इस trait को `#[derive]` के साथ इस्तेमाल किया जा सकता है।
/// जब संरचनाओं पर `व्युत्पन्न` होता है, तो यह संरचना के सदस्यों के शीर्ष-से-नीचे घोषणा आदेश के आधार पर एक [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ऑर्डरिंग उत्पन्न करेगा।
///
/// जब एनमों पर `व्युत्पन्न` किया जाता है, तो वेरिएंट को उनके ऊपर से नीचे के भेदभावपूर्ण क्रम द्वारा क्रमबद्ध किया जाता है।
///
/// ## लेक्सिकोग्राफिक तुलना
///
/// लेक्सिकोग्राफिक तुलना निम्नलिखित गुणों के साथ एक ऑपरेशन है:
///  - दो अनुक्रमों की तुलना तत्व द्वारा तत्व से की जाती है।
///  - पहला बेमेल तत्व परिभाषित करता है कि कौन सा अनुक्रम दूसरे की तुलना में लेक्सिकोग्राफिक रूप से कम या बड़ा है।
///  - यदि एक अनुक्रम दूसरे का उपसर्ग है, तो छोटा अनुक्रम दूसरे की तुलना में शब्दावली से कम है।
///  - यदि दो अनुक्रमों में समान तत्व होते हैं और समान लंबाई के होते हैं, तो अनुक्रम शाब्दिक रूप से समान होते हैं।
///  - एक खाली अनुक्रम किसी भी गैर-रिक्त अनुक्रम से लेक्सिकोग्राफ़िक रूप से कम है।
///  - दो खाली अनुक्रम लेक्सिकोग्राफिक रूप से समान हैं।
///
/// ## मैं `Ord` को कैसे कार्यान्वित कर सकता हूं?
///
/// `Ord` यह आवश्यक है कि प्रकार भी [`PartialOrd`] और [`Eq`] हो (जिसके लिए [`PartialEq`] की आवश्यकता है)।
///
/// फिर आपको [`cmp`] के लिए एक कार्यान्वयन परिभाषित करना होगा।आपको अपने प्रकार के क्षेत्रों में [`cmp`] का उपयोग करना उपयोगी लग सकता है।
///
/// [`PartialEq`], [`PartialOrd`], और `Ord` के कार्यान्वयन *एक दूसरे से सहमत* होने चाहिए।
/// यानी, `a.cmp(b) == Ordering::Equal` अगर और केवल अगर `a == b` और `Some(a.cmp(b)) == a.partial_cmp(b)` सभी `a` और `b` के लिए।
/// कुछ traits प्राप्त करके और दूसरों को मैन्युअल रूप से लागू करके गलती से उन्हें असहमत करना आसान है।
///
/// यहां एक उदाहरण दिया गया है जहां आप `id` और `name` को छोड़कर केवल ऊंचाई के आधार पर लोगों को क्रमबद्ध करना चाहते हैं:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// यह विधि `self` और `other` के बीच एक [`Ordering`] लौटाती है।
    ///
    /// परंपरा के अनुसार, `self.cmp(&other)` सही होने पर अभिव्यक्ति `self <operator> other` से मेल खाने वाला क्रम देता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// तुलना करता है और अधिकतम दो मान देता है।
    ///
    /// यदि तुलना निर्धारित करती है कि वे बराबर हैं तो दूसरा तर्क देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// तुलना करता है और कम से कम दो मान देता है।
    ///
    /// पहला तर्क देता है अगर तुलना उन्हें बराबर होने के लिए निर्धारित करती है।
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// किसी मान को एक निश्चित अंतराल तक सीमित करें।
    ///
    /// यदि `self`, `max` से बड़ा है, तो `max` लौटाता है, और यदि `self`, `min` से कम है, तो `min` देता है।
    /// अन्यथा यह `self` लौटाता है।
    ///
    /// # Panics
    ///
    /// Panics अगर `min > max`।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// trait `Ord` का एक अर्थ उत्पन्न करने वाला मैक्रो व्युत्पन्न करें।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait मानों के लिए जिनकी तुलना सॉर्ट-ऑर्डर के लिए की जा सकती है।
///
/// तुलना सभी `a`, `b` और `c` के लिए संतुष्ट होनी चाहिए:
///
/// - विषमता: यदि `a < b` तो `!(a > b)`, साथ ही `a > b` का अर्थ `!(a < b)` है;तथा
/// - ट्रांजिटिविटी: `a < b` और `b < c` का अर्थ है `a < c`।`==` और `>` दोनों के लिए समान होना चाहिए।
///
/// ध्यान दें कि इन आवश्यकताओं का अर्थ है कि trait को स्वयं सममित और संक्रमणीय रूप से लागू किया जाना चाहिए: यदि `T: PartialOrd<U>` और `U: PartialOrd<V>` तो `U: PartialOrd<T>` और `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// इस trait को `#[derive]` के साथ इस्तेमाल किया जा सकता है।जब संरचनाओं पर `व्युत्पन्न` होता है, तो यह संरचना के सदस्यों के ऊपर-से-नीचे घोषणा आदेश के आधार पर एक शब्दावली आदेश तैयार करेगा।
/// जब एनमों पर `व्युत्पन्न` किया जाता है, तो वेरिएंट को उनके ऊपर से नीचे के भेदभावपूर्ण क्रम द्वारा क्रमबद्ध किया जाता है।
///
/// ## मैं `PartialOrd` को कैसे कार्यान्वित कर सकता हूं?
///
/// `PartialOrd` डिफ़ॉल्ट कार्यान्वयन से उत्पन्न अन्य के साथ, केवल [`partial_cmp`] विधि के कार्यान्वयन की आवश्यकता है।
///
/// हालांकि, उन प्रकारों के लिए दूसरों को अलग से लागू करना संभव है जिनके पास कुल आदेश नहीं है।
/// उदाहरण के लिए, फ्लोटिंग पॉइंट नंबरों के लिए, `NaN < 0 == false` और `NaN >= 0 == false` (cf.
/// आईईईई 754-2008 खंड 5.11)।
///
/// `PartialOrd` आपके प्रकार का [`PartialEq`] होना आवश्यक है।
///
/// [`PartialEq`], `PartialOrd`, और [`Ord`] के कार्यान्वयन *एक दूसरे से सहमत* होने चाहिए।
/// कुछ traits प्राप्त करके और दूसरों को मैन्युअल रूप से लागू करके गलती से उन्हें असहमत करना आसान है।
///
/// यदि आपका प्रकार [`Ord`] है, तो आप [`cmp`] का उपयोग करके [`partial_cmp`] को लागू कर सकते हैं:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// आपको अपने प्रकार के क्षेत्रों पर [`partial_cmp`] का उपयोग करना भी उपयोगी लग सकता है।
/// यहां `Person` प्रकारों का एक उदाहरण दिया गया है जिनके पास एक फ्लोटिंग-पॉइंट `height` फ़ील्ड है जो सॉर्टिंग के लिए उपयोग किया जाने वाला एकमात्र फ़ील्ड है:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// यदि कोई मौजूद है तो यह विधि `self` और `other` मानों के बीच ऑर्डरिंग लौटाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// जब तुलना असंभव है:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// यह विधि (`self` और `other` के लिए) से कम परीक्षण करती है और `<` ऑपरेटर द्वारा उपयोग की जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// यह विधि (`self` और `other` के लिए) से कम या उसके बराबर परीक्षण करती है और `<=` ऑपरेटर द्वारा उपयोग की जाती है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// यह विधि (`self` और `other` के लिए) से अधिक परीक्षण करती है और `>` ऑपरेटर द्वारा उपयोग की जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// यह विधि (`self` और `other` के लिए) से अधिक या उसके बराबर परीक्षण करती है और `>=` ऑपरेटर द्वारा उपयोग की जाती है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd` का एक अर्थ उत्पन्न करने वाला मैक्रो व्युत्पन्न करें।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// तुलना करता है और कम से कम दो मान देता है।
///
/// पहला तर्क देता है अगर तुलना उन्हें बराबर होने के लिए निर्धारित करती है।
///
/// आंतरिक रूप से [`Ord::min`] के लिए एक उपनाम का उपयोग करता है।
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// निर्दिष्ट तुलना फ़ंक्शन के संबंध में न्यूनतम दो मान देता है।
///
/// पहला तर्क देता है अगर तुलना उन्हें बराबर होने के लिए निर्धारित करती है।
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// वह तत्व लौटाता है जो निर्दिष्ट फ़ंक्शन से न्यूनतम मान देता है।
///
/// पहला तर्क देता है अगर तुलना उन्हें बराबर होने के लिए निर्धारित करती है।
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// तुलना करता है और अधिकतम दो मान देता है।
///
/// यदि तुलना निर्धारित करती है कि वे बराबर हैं तो दूसरा तर्क देता है।
///
/// आंतरिक रूप से [`Ord::max`] के लिए एक उपनाम का उपयोग करता है।
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// निर्दिष्ट तुलना फ़ंक्शन के संबंध में अधिकतम दो मान देता है।
///
/// यदि तुलना निर्धारित करती है कि वे बराबर हैं तो दूसरा तर्क देता है।
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// वह तत्व लौटाता है जो निर्दिष्ट फ़ंक्शन से अधिकतम मान देता है।
///
/// यदि तुलना निर्धारित करती है कि वे बराबर हैं तो दूसरा तर्क देता है।
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// आदिम प्रकारों के लिए PartialEq, Eq, PartialOrd और Ord का कार्यान्वयन
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // अधिक इष्टतम असेंबली उत्पन्न करने के लिए यहां आदेश महत्वपूर्ण है।
                    // अधिक जानकारी के लिए <https://github.com/rust-lang/rust/issues/63758> देखें।
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // i8 के लिए कास्टिंग और अंतर को ऑर्डरिंग में परिवर्तित करने से अधिक इष्टतम असेंबली उत्पन्न होती है।
            //
            // अधिक जानकारी के लिए <https://github.com/rust-lang/rust/issues/66780> देखें।
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // सुरक्षा: bool जैसा कि i8 0 या 1 लौटाता है, इसलिए अंतर कुछ और नहीं हो सकता है
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // और संकेत

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}