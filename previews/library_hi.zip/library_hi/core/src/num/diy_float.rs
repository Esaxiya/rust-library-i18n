//! विस्तारित परिशुद्धता "soft float", केवल आंतरिक उपयोग के लिए।

// यह मॉड्यूल केवल dec2flt और flt2dec के लिए है, और केवल कोरटेस्ट के कारण सार्वजनिक है।
// यह कभी भी स्थिर होने का इरादा नहीं है।
#![doc(hidden)]
#![unstable(
    feature = "core_private_diy_float",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

/// एक कस्टम 64-बिट फ़्लोटिंग पॉइंट प्रकार, जो `f * 2^e` का प्रतिनिधित्व करता है।
#[derive(Copy, Clone, Debug)]
#[doc(hidden)]
pub struct Fp {
    /// पूर्णांक मंटिसा।
    pub f: u64,
    /// आधार 2 में घातांक।
    pub e: i16,
}

impl Fp {
    /// अपने और `other` का सही गोल उत्पाद लौटाता है।
    pub fn mul(&self, other: &Fp) -> Fp {
        const MASK: u64 = 0xffffffff;
        let a = self.f >> 32;
        let b = self.f & MASK;
        let c = other.f >> 32;
        let d = other.f & MASK;
        let ac = a * c;
        let bc = b * c;
        let ad = a * d;
        let bd = b * d;
        let tmp = (bd >> 32) + (ad & MASK) + (bc & MASK) + (1 << 31) /* round */;
        let f = ac + (ad >> 32) + (bc >> 32) + (tmp >> 32);
        let e = self.e + other.e + 64;
        Fp { f, e }
    }

    /// खुद को सामान्य करता है ताकि परिणामी मंटिसा कम से कम `2^63` हो।
    pub fn normalize(&self) -> Fp {
        let mut f = self.f;
        let mut e = self.e;
        if f >> (64 - 32) == 0 {
            f <<= 32;
            e -= 32;
        }
        if f >> (64 - 16) == 0 {
            f <<= 16;
            e -= 16;
        }
        if f >> (64 - 8) == 0 {
            f <<= 8;
            e -= 8;
        }
        if f >> (64 - 4) == 0 {
            f <<= 4;
            e -= 4;
        }
        if f >> (64 - 2) == 0 {
            f <<= 2;
            e -= 2;
        }
        if f >> (64 - 1) == 0 {
            f <<= 1;
            e -= 1;
        }
        debug_assert!(f >= (1 >> 63));
        Fp { f, e }
    }

    /// साझा घातांक होने के लिए खुद को सामान्य करता है।
    /// यह केवल घातांक को कम कर सकता है (और इस प्रकार मंटिसा को बढ़ा सकता है)।
    pub fn normalize_to(&self, e: i16) -> Fp {
        let edelta = self.e - e;
        assert!(edelta >= 0);
        let edelta = edelta as usize;
        assert_eq!(self.f << edelta >> edelta, self.f);
        Fp { f: self.f << edelta, e }
    }
}