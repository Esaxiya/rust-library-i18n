//! 128-बिट अहस्ताक्षरित पूर्णांक प्रकार के लिए स्थिरांक।
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! नए कोड को सीधे आदिम प्रकार पर संबंधित स्थिरांक का उपयोग करना चाहिए।

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }