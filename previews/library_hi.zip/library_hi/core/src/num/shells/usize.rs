//! सूचक के आकार के अहस्ताक्षरित पूर्णांक प्रकार के लिए स्थिरांक।
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! नए कोड को सीधे आदिम प्रकार पर संबंधित स्थिरांक का उपयोग करना चाहिए।

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }