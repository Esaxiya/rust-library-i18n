//! 16-बिट हस्ताक्षरित पूर्णांक प्रकार के लिए स्थिरांक।
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! नए कोड को सीधे आदिम प्रकार पर संबंधित स्थिरांक का उपयोग करना चाहिए।

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }