//! सकारात्मक आईईईई 754 फ्लोट्स पर थोड़ा सा झुकाव।ऋणात्मक संख्याओं को संभाला नहीं जाता है और न ही संभालने की आवश्यकता होती है।
//! सामान्य चल बिन्दु संख्या के रूप में एक विहित प्रतिनिधित्व (frac, exp) ऐसी है कि मूल्य है 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) जहां एन बिट्स की संख्या है।
//!
//! सबनॉर्मल थोड़े अलग और अजीब होते हैं, लेकिन एक ही सिद्धांत लागू होता है।
//!
//! यहाँ, हालांकि, हम उन्हें f धनात्मक के साथ (sig, k) के रूप में निरूपित करते हैं, जैसे कि मान f * है
//! २ <sup>ई</sup> ."hidden bit" को स्पष्ट करने के अलावा, यह तथाकथित मंटिसा शिफ्ट द्वारा प्रतिपादक को बदलता है।
//!
//! दूसरे तरीके से कहें, तो आम तौर पर फ़्लोट्स को (1) के रूप में लिखा जाता है लेकिन यहाँ उन्हें (2) के रूप में लिखा जाता है:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! हम (1) को **आंशिक प्रतिनिधित्व** और (2) को **अभिन्न प्रतिनिधित्व** कहते हैं।
//!
//! इस मॉड्यूल में कई फ़ंक्शन केवल सामान्य संख्याओं को संभालते हैं।dec2flt रूटीन रूढ़िवादी रूप से बहुत छोटी और बहुत बड़ी संख्या के लिए सार्वभौमिक रूप से सही धीमा पथ (एल्गोरिदम एम) लेते हैं।
//! उस एल्गोरिदम को केवल next_float() की आवश्यकता होती है जो सबनॉर्मल और ज़ीरो को हैंडल करता है।
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// `f32` और `f64` के लिए मूल रूप से सभी रूपांतरण कोड को डुप्लिकेट करने से बचने के लिए एक सहायक trait।
///
/// यह क्यों आवश्यक है, इसके लिए मूल मॉड्यूल की दस्तावेज़ टिप्पणी देखें।
///
/// अन्य प्रकारों के लिए **कभी भी** लागू नहीं किया जाना चाहिए या dec2flt मॉड्यूल के बाहर उपयोग किया जाना चाहिए।
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` और `from_bits` द्वारा उपयोग किया जाने वाला प्रकार।
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// एक पूर्णांक के लिए एक कच्चा रूपांतरण करता है।
    fn to_bits(self) -> Self::Bits;

    /// एक पूर्णांक से एक कच्चा रूपांतरण करता है।
    fn from_bits(v: Self::Bits) -> Self;

    /// वह श्रेणी देता है जिसमें यह संख्या आती है।
    fn classify(self) -> FpCategory;

    /// मंटिसा, घातांक देता है और पूर्णांक के रूप में चिह्न लगाता है।
    fn integer_decode(self) -> (u64, i16, i8);

    /// फ्लोट को डिकोड करता है।
    fn unpack(self) -> Unpacked;

    /// एक छोटे से पूर्णांक से कास्ट करता है जिसे बिल्कुल प्रदर्शित किया जा सकता है।
    /// Panic यदि पूर्णांक का प्रतिनिधित्व नहीं किया जा सकता है, तो इस मॉड्यूल में अन्य कोड यह सुनिश्चित करता है कि ऐसा कभी न होने दें।
    fn from_int(x: u64) -> Self;

    /// पूर्व-गणना तालिका से मान 10 <sup>ई</sup> प्राप्त करता है।
    /// `e >= CEIL_LOG5_OF_MAX_SIG` के लिए Panics।
    fn short_fast_pow10(e: usize) -> Self;

    /// नाम क्या कहता है।
    /// जॉगलिंग इंट्रिनिक्स की तुलना में हार्ड कोड करना आसान है और उम्मीद है कि एलएलवीएम लगातार इसे फोल्ड करता है।
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // इनपुट के दशमलव अंकों पर एक रूढ़िवादी बाध्य जो अतिप्रवाह या शून्य उत्पन्न नहीं कर सकता या
    /// असामान्यसंभवतः अधिकतम सामान्य मान का दशमलव घातांक, इसलिए नाम।
    const MAX_NORMAL_DIGITS: usize;

    /// जब सबसे महत्वपूर्ण दशमलव अंक का स्थानीय मान इससे अधिक होता है, तो संख्या निश्चित रूप से अनंत तक गोल हो जाती है।
    ///
    const INF_CUTOFF: i64;

    /// जब सबसे महत्वपूर्ण दशमलव अंक का स्थानीय मान इससे कम होता है, तो संख्या निश्चित रूप से शून्य हो जाती है।
    ///
    const ZERO_CUTOFF: i64;

    /// घातांक में बिट्स की संख्या।
    const EXP_BITS: u8;

    /// महत्व में बिट्स की संख्या,*छिपे हुए बिट सहित*।
    const SIG_BITS: u8;

    /// महत्व में बिट्स की संख्या,*छिपे हुए बिट को छोड़कर*।
    const EXPLICIT_SIG_BITS: u8;

    /// भिन्नात्मक प्रतिनिधित्व में अधिकतम कानूनी प्रतिपादक।
    const MAX_EXP: i16;

    /// भिन्नात्मक प्रतिनिधित्व में न्यूनतम कानूनी प्रतिपादक, असामान्यताओं को छोड़कर।
    const MIN_EXP: i16;

    /// `MAX_EXP` अभिन्न प्रतिनिधित्व के लिए, यानी लागू किए गए बदलाव के साथ।
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` एन्कोडेड (यानी, ऑफ़सेट पूर्वाग्रह के साथ)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` अभिन्न प्रतिनिधित्व के लिए, यानी लागू किए गए बदलाव के साथ।
    const MIN_EXP_INT: i16;

    /// अभिन्न प्रतिनिधित्व में अधिकतम सामान्यीकृत महत्व।
    const MAX_SIG: u64;

    /// न्यूनतम सामान्यीकृत महत्व और अभिन्न प्रतिनिधित्व में।
    const MIN_SIG: u64;
}

// ज्यादातर #34344 के लिए एक वैकल्पिक हल।
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// मंटिसा, घातांक देता है और पूर्णांक के रूप में चिह्न लगाता है।
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // घातांक पूर्वाग्रह + मंटिसा शिफ्ट
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe अनिश्चित है कि क्या `as` सभी प्लेटफॉर्म पर सही ढंग से राउंड करता है।
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// मंटिसा, घातांक देता है और पूर्णांक के रूप में चिह्न लगाता है।
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // घातांक पूर्वाग्रह + मंटिसा शिफ्ट
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe अनिश्चित है कि क्या `as` सभी प्लेटफॉर्म पर सही ढंग से राउंड करता है।
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// एक `Fp` को निकटतम मशीन फ्लोट प्रकार में कनवर्ट करता है।
/// असामान्य परिणामों को संभालता नहीं है।
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 बिट है, इसलिए xe में 63. की मंटिसा शिफ्ट है
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// अर्ध-से-सम के साथ 64-बिट महत्व और T::SIG_BITS बिट्स को गोल करें।
/// घातांक अतिप्रवाह को संभालता नहीं है।
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // मंटिसा शिफ्ट समायोजित करें
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// सामान्यीकृत संख्याओं के लिए `RawFloat::unpack()` का व्युत्क्रम।
/// Panics यदि सामान्यीकृत संख्याओं के लिए महत्व या घातांक मान्य नहीं हैं।
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // छिपे हुए बिट को हटा दें
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // एक्सपोनेंट पूर्वाग्रह और मंटिसा शिफ्ट के लिए एक्सपोनेंट को समायोजित करें
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // साइन बिट को 0 ("+") पर छोड़ दें, हमारे सभी नंबर सकारात्मक हैं
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// एक असामान्य निर्माण करें।0 के मंटिसा की अनुमति है और शून्य का निर्माण करता है।
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // एन्कोडेड एक्सपोनेंट 0 है, साइन बिट 0 है, इसलिए हमें बस बिट्स को दोबारा परिभाषित करना होगा।
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// एक एफपी के साथ एक बिग्नम अनुमानित करें।हाफ-टू-ईवन के साथ 0.5 ULP के भीतर राउंड।
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // हमने इंडेक्स `start` से पहले सभी बिट्स को काट दिया, यानी, हम प्रभावी रूप से `start` की मात्रा से राइट-शिफ्ट करते हैं, इसलिए यह वह घातांक भी है जिसकी हमें आवश्यकता है।
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // काटे गए बिट्स के आधार पर राउंड (half-to-even)।
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// सबसे बड़ा फ़्लोटिंग पॉइंट नंबर तर्क से सख्ती से छोटा पाता है।
/// सबनॉर्मल, जीरो या एक्सपोनेंट अंडरफ्लो को हैंडल नहीं करता है।
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// तर्क से सख्ती से बड़ा सबसे छोटा फ़्लोटिंग पॉइंट नंबर खोजें।
// यह ऑपरेशन संतृप्त है, अर्थात, next_float(inf) ==inf.
// इस मॉड्यूल में अधिकांश कोड के विपरीत, यह फ़ंक्शन शून्य, सबनॉर्मल और इनफिनिटीज को हैंडल करता है।
// हालाँकि, यहाँ अन्य सभी कोड की तरह, यह NaN और ऋणात्मक संख्याओं से संबंधित नहीं है।
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // यह सच होने के लिए बहुत अच्छा लगता है, लेकिन यह काम करता है।
        // 0.0 सभी शून्य शब्द के रूप में एन्कोड किया गया है।सबनॉर्मल 0x000m...m हैं जहां m मंटिसा है।
        // विशेष रूप से, सबसे छोटा असामान्य 0x0...01 है और सबसे बड़ा 0x000F...F है।
        // सबसे छोटी सामान्य संख्या 0x0010...0 है, इसलिए यह कॉर्नर केस भी काम करता है।
        // यदि वृद्धि मंटिसा से अधिक हो जाती है, तो कैरी बिट घातांक को बढ़ा देता है जैसा हम चाहते हैं, और मंटिसा बिट्स शून्य हो जाते हैं।
        // छिपे हुए बिट सम्मेलन के कारण, यह भी वही है जो हम चाहते हैं!
        // अंत में, f64::MAX + 1=7eff...f + 1=7ff0...0= f64::INFINITY।
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}