//! दशमलव स्ट्रिंग्स को IEEE 754 बाइनरी फ़्लोटिंग पॉइंट नंबरों में कनवर्ट करना।
//!
//! # समस्या का विवरण
//!
//! हमें एक दशमलव स्ट्रिंग दिया गया है जैसे कि `12.34e56`।
//! इस स्ट्रिंग में इंटीग्रल (`12`), फ्रैक्शनल (`34`) और एक्सपोनेंट (`56`) भाग होते हैं।सभी भाग वैकल्पिक हैं और गायब होने पर शून्य के रूप में व्याख्या की जाती है।
//!
//! हम IEEE 754 फ्लोटिंग पॉइंट नंबर की तलाश करते हैं जो दशमलव स्ट्रिंग के सटीक मान के सबसे करीब हो।
//! यह सर्वविदित है कि कई दशमलव स्ट्रिंग्स में आधार दो में समाप्ति अभ्यावेदन नहीं होते हैं, इसलिए हम अंतिम स्थान पर (दूसरे शब्दों में, जितना संभव हो सके) 0.5 इकाइयों को गोल करते हैं।
//! टाई, दशमलव मान दो क्रमागत फ़्लोट्स के ठीक आधे-अधूरे होते हैं, जिन्हें हाफ-टू-ईवन रणनीति के साथ हल किया जाता है, जिसे बैंकर राउंडिंग भी कहा जाता है।
//!
//! कहने की जरूरत नहीं है, यह कार्यान्वयन जटिलता और सीपीयू चक्रों के संदर्भ में काफी कठिन है।
//!
//! # Implementation
//!
//! सबसे पहले, हम संकेतों को अनदेखा करते हैं।या यों कहें, हम इसे रूपांतरण प्रक्रिया की शुरुआत में ही हटा देते हैं और अंत में इसे फिर से लागू कर देते हैं।
//! यह सभी edge मामलों में सही है क्योंकि आईईईई फ्लोट शून्य के आसपास सममित हैं, एक को नकारते हुए बस पहले बिट को फ़्लिप करता है।
//!
//! फिर हम घातांक को समायोजित करके दशमलव बिंदु को हटाते हैं: संकल्पनात्मक रूप से, `12.34e56` `1234e54` में बदल जाता है, जिसे हम एक सकारात्मक पूर्णांक `f = 1234` और एक पूर्णांक `e = 54` के साथ वर्णित करते हैं।
//! `(f, e)` प्रतिनिधित्व का उपयोग पार्सिंग चरण के लगभग सभी कोड द्वारा किया जाता है।
//!
//! फिर हम मशीन के आकार के पूर्णांकों और छोटे, निश्चित आकार के फ्लोटिंग पॉइंट नंबरों (पहले `f32`/`f64`, फिर 64 बिट महत्व के साथ एक प्रकार, `Fp`) का उपयोग करके उत्तरोत्तर अधिक सामान्य और महंगे विशेष मामलों की एक लंबी श्रृंखला की कोशिश करते हैं।
//!
//! जब ये सभी विफल हो जाते हैं, तो हम बुलेट को काटते हैं और एक सरल लेकिन बहुत धीमी एल्गोरिथम का सहारा लेते हैं जिसमें पूरी तरह से `f * 10^e` की गणना करना और सर्वोत्तम सन्निकटन के लिए एक पुनरावृत्त खोज करना शामिल है।
//!
//! मुख्य रूप से, यह मॉड्यूल और इसके बच्चे इसमें वर्णित एल्गोरिदम को लागू करते हैं:
//! "How to Read Floating Point Numbers Accurately" विलियम डी द्वारा
//! क्लिंजर, ऑनलाइन उपलब्ध: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! इसके अलावा, कई सहायक कार्य हैं जो कागज में उपयोग किए जाते हैं लेकिन Rust (या कम से कम कोर में) में उपलब्ध नहीं हैं।
//! हमारा संस्करण अतिप्रवाह और अंडरफ्लो को संभालने की आवश्यकता और असामान्य संख्याओं को संभालने की इच्छा से अतिरिक्त रूप से जटिल है।
//! Bellerophon और Algorithm R में अतिप्रवाह, असामान्यताएं और अंतर्प्रवाह की समस्या है।
//! इनपुट महत्वपूर्ण क्षेत्र में आने से पहले हम रूढ़िवादी रूप से एल्गोरिदम एम (कागज के खंड 8 में वर्णित संशोधनों के साथ) पर स्विच करते हैं।
//!
//! एक अन्य पहलू जिस पर ध्यान देने की आवश्यकता है वह है ``RawFloat`` trait जिसके द्वारा लगभग सभी फ़ंक्शन पैरामीट्रिज्ड हैं।कोई सोच सकता है कि यह `f64` को पार्स करने और परिणाम को `f32` पर डालने के लिए पर्याप्त है।
//! दुर्भाग्य से यह वह दुनिया नहीं है जिसमें हम रहते हैं, और इसका बेस टू या हाफ-टू-ईवन राउंडिंग के उपयोग से कोई लेना-देना नहीं है।
//!
//! उदाहरण के लिए दो प्रकार `d2` और `d4` पर विचार करें जो दो दशमलव अंकों और चार दशमलव अंकों के साथ एक दशमलव प्रकार का प्रतिनिधित्व करते हैं और इनपुट के रूप में "0.01499" लेते हैं।आइए हाफ-अप राउंडिंग का उपयोग करें।
//! सीधे दो दशमलव अंकों पर जाने से `0.01` मिलता है, लेकिन यदि हम पहले चार अंकों का चक्कर लगाते हैं, तो हमें `0.0150` मिलता है, जिसे बाद में `0.02` तक गोल किया जाता है।
//! यही सिद्धांत अन्य परिचालनों पर भी लागू होता है, यदि आप 0.5 ULP सटीकता चाहते हैं तो आपको *सब कुछ* पूरी सटीकता और राउंड *बिल्कुल एक बार, अंत में*, सभी काटे गए बिट्स पर एक साथ विचार करके करने की आवश्यकता है।
//!
//! FIXME: हालांकि कुछ कोड दोहराव आवश्यक है, शायद कोड के कुछ हिस्सों को इस तरह से फेरबदल किया जा सकता है कि कम कोड डुप्लिकेट हो।
//! एल्गोरिदम के बड़े हिस्से फ्लोट प्रकार से आउटपुट से स्वतंत्र होते हैं, या केवल कुछ स्थिरांक तक पहुंच की आवश्यकता होती है, जिन्हें पैरामीटर के रूप में पारित किया जा सकता है।
//!
//! # Other
//!
//! रूपांतरण *कभी नहीं* panic होना चाहिए।
//! कोड में दावे और स्पष्ट panics हैं, लेकिन उन्हें कभी भी ट्रिगर नहीं किया जाना चाहिए और केवल आंतरिक विवेक जांच के रूप में कार्य करना चाहिए।किसी भी panics को एक बग माना जाना चाहिए।
//!
//! यूनिट परीक्षण हैं लेकिन वे शुद्धता सुनिश्चित करने में अपर्याप्त हैं, वे केवल संभावित त्रुटियों के एक छोटे प्रतिशत को कवर करते हैं।
//! अधिक व्यापक परीक्षण निर्देशिका `src/etc/test-float-parse` में Python स्क्रिप्ट के रूप में स्थित हैं।
//!
//! पूर्णांक अतिप्रवाह पर एक नोट: इस फ़ाइल के कई भाग दशमलव घातांक `e` के साथ अंकगणित करते हैं।
//! मुख्य रूप से, हम दशमलव बिंदु को चारों ओर स्थानांतरित करते हैं: पहले दशमलव अंक से पहले, अंतिम दशमलव अंक के बाद, और इसी तरह।अगर लापरवाही की गई तो यह ओवरफ्लो हो सकता है।
//! हम केवल पर्याप्त रूप से छोटे प्रतिपादकों को सौंपने के लिए पार्सिंग सबमॉड्यूल पर भरोसा करते हैं, जहां "sufficient" का अर्थ "such that the exponent +/- the number of decimal digits fits into a 64 bit integer" है।
//! बड़े घातांक स्वीकार किए जाते हैं, लेकिन हम उनके साथ अंकगणित नहीं करते हैं, वे तुरंत {positive,negative} {zero,infinity} में बदल जाते हैं।
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// इन दोनों के अपने-अपने परीक्षण हैं।
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// आधार 10 में एक स्ट्रिंग को एक फ्लोट में परिवर्तित करता है।
            /// एक वैकल्पिक दशमलव घातांक स्वीकार करता है।
            ///
            /// यह फ़ंक्शन स्ट्रिंग्स को स्वीकार करता है जैसे कि
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', या समकक्ष, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', या, समान रूप से, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// अग्रणी और अनुगामी व्हॉट्सएप एक त्रुटि का प्रतिनिधित्व करते हैं।
            ///
            /// # Grammar
            ///
            /// निम्नलिखित [EBNF] व्याकरण का पालन करने वाले सभी स्ट्रिंग्स के परिणामस्वरूप [`Ok`] लौटाया जाएगा:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # ज्ञात कीड़े
            ///
            /// कुछ स्थितियों में, कुछ तार जो एक वैध फ्लोट बनाने के बजाय एक त्रुटि लौटाते हैं।
            /// विवरण के लिए [issue #31407] देखें।
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, एक स्ट्रिंग
            ///
            /// # प्रतिलाभ की मात्रा
            ///
            /// `Err(ParseFloatError)` यदि स्ट्रिंग मान्य संख्या का प्रतिनिधित्व नहीं करती है।
            /// अन्यथा, `Ok(n)` जहां `n`, `src` द्वारा दर्शाया गया फ्लोटिंग-पॉइंट नंबर है।
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// एक त्रुटि जो एक फ्लोट को पार्स करते समय वापस की जा सकती है।
///
/// इस त्रुटि का उपयोग [`f32`] और [`f64`] के लिए [`FromStr`] कार्यान्वयन के लिए त्रुटि प्रकार के रूप में किया जाता है।
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// दशमलव स्ट्रिंग को चिह्न और शेष में विभाजित करता है, बाकी का निरीक्षण या सत्यापन किए बिना।
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // यदि स्ट्रिंग अमान्य है, तो हम कभी भी चिह्न का उपयोग नहीं करते हैं, इसलिए हमें यहां सत्यापन करने की आवश्यकता नहीं है।
        _ => (Sign::Positive, s),
    }
}

/// दशमलव स्ट्रिंग को फ़्लोटिंग पॉइंट नंबर में कनवर्ट करता है।
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// दशमलव-से-फ्लोट रूपांतरण के लिए मुख्य वर्कहॉर्स: सभी प्रीप्रोसेसिंग को ऑर्केस्ट्रेट करें और यह पता लगाएं कि कौन सा एल्गोरिदम वास्तविक रूपांतरण करना चाहिए।
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift दशमलव बिंदु से बाहर।
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 1280 बिट्स तक सीमित है, जो लगभग 385 दशमलव अंकों का अनुवाद करता है।
    // यदि हम इससे अधिक हो जाते हैं, तो हम दुर्घटनाग्रस्त हो जाएंगे, इसलिए हम बहुत करीब होने से पहले (10^10 के भीतर) त्रुटि निकाल देते हैं।
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // अब एक्सपोनेंट निश्चित रूप से 16 बिट में फिट बैठता है, जिसका उपयोग पूरे मुख्य एल्गोरिदम में किया जाता है।
    let e = e as i16;
    // FIXME ये सीमाएँ रूढ़िवादी हैं।
    // बेलेरोफ़ोन के विफलता मोड का अधिक सावधानीपूर्वक विश्लेषण इसे अधिक मामलों में बड़े पैमाने पर गति के लिए उपयोग करने की अनुमति दे सकता है।
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// जैसा लिखा है, यह बुरी तरह अनुकूलित करता है (#27130 देखें, हालांकि यह कोड के पुराने संस्करण को संदर्भित करता है)।
// `inline(always)` उसके लिए एक उपाय है।
// कुल मिलाकर केवल दो कॉल साइट हैं और यह कोड आकार को बदतर नहीं बनाती हैं।

/// जहां संभव हो वहां शून्य को पट्टी करें, तब भी जब इसके लिए घातांक बदलने की आवश्यकता हो
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // इन शून्यों को ट्रिम करने से कुछ भी नहीं बदलता है लेकिन तेज़ पथ (<15 अंक) सक्षम हो सकता है।
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // घातांक को तदनुसार समायोजित करते हुए प्रपत्र 0.0...x और x...0.0 की संख्याओं को सरल बनाएं।
    // यह हमेशा एक जीत नहीं हो सकता है (संभवतः कुछ संख्याओं को तेज़ पथ से बाहर धकेलता है), लेकिन यह अन्य भागों को महत्वपूर्ण रूप से सरल करता है (विशेषकर, मूल्य के परिमाण का अनुमान लगाते हुए)।
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// दिए गए दशमलव पर काम करते समय एल्गोरिथम R और एल्गोरिथम M द्वारा गणना किए जाने वाले सबसे बड़े मान के आकार (log10) पर एक त्वरित-और-गंदा ऊपरी बाउंड देता है।
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // हमें यहां अतिप्रवाह के बारे में बहुत अधिक चिंता करने की आवश्यकता नहीं है, trivial_cases() और पार्सर के लिए धन्यवाद, जो हमारे लिए सबसे चरम इनपुट को फ़िल्टर करता है।
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // मामले में e >=0, दोनों एल्गोरिदम `f * 10^e` के बारे में गणना करते हैं।
        // एल्गोरिथम आर इसके साथ कुछ जटिल गणना करने के लिए आगे बढ़ता है लेकिन हम इसे ऊपरी सीमा के लिए अनदेखा कर सकते हैं क्योंकि यह पहले से अंश को भी कम कर देता है, इसलिए हमारे पास वहां बहुत सारे बफर हैं।
        //
        f_len + (e as u64)
    } else {
        // यदि ई <0, एल्गोरिथम आर लगभग एक ही काम करता है, लेकिन एल्गोरिथम एम अलग है:
        // यह एक सकारात्मक संख्या k खोजने की कोशिश करता है जैसे कि `f << k / 10^e` एक इन-रेंज महत्व है।
        // इसका परिणाम लगभग `2^53 *f* 10^e` < `10^17 *f* 10^e` होगा।
        // इसे ट्रिगर करने वाला एक इनपुट 0.33...33 (375 x 3) है।
        f_len + e.unsigned_abs() + 17
    }
}

/// दशमलव अंकों को देखे बिना स्पष्ट ओवरफ्लो और अंडरफ्लो का पता लगाता है।
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // शून्य थे लेकिन वे simplify(). द्वारा छीन लिए गए थे
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // यह ceil(log10(the real value)) का अपरिष्कृत सन्निकटन है।
    // हमें यहां अतिप्रवाह के बारे में बहुत अधिक चिंता करने की आवश्यकता नहीं है क्योंकि इनपुट लंबाई छोटी है (कम से कम 2^64 की तुलना में) और पार्सर पहले से ही ऐसे घातांक को संभालता है जिसका निरपेक्ष मान 10^18 से अधिक है (जो अभी भी 10^19 छोटा है) 2^64)।
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}