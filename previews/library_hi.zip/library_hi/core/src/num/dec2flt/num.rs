//! बिग्नम के लिए उपयोगिता कार्य जो विधियों में बदलने के लिए बहुत अधिक समझ में नहीं आता है।

// FIXME इस मॉड्यूल का नाम थोड़ा दुर्भाग्यपूर्ण है, क्योंकि अन्य मॉड्यूल भी `core::num` आयात करते हैं।

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// परीक्षण करें कि क्या `ones_place` से कम महत्वपूर्ण सभी बिट्स को छोटा करने से 0.5 ULP से कम, बराबर या अधिक सापेक्ष त्रुटि आती है।
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 यूएलपी
        return Less;
    }
    // यदि सभी शेष बिट शून्य हैं, तो यह= 0.5 ULP है, अन्यथा > 0.5 यदि कोई और बिट नहीं हैं (हाफ_बिट==0), तो नीचे भी सही ढंग से समान लौटाता है।
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// केवल दशमलव अंकों वाली ASCII स्ट्रिंग को `u64` में कनवर्ट करता है।
///
/// अतिप्रवाह या अमान्य वर्णों के लिए जांच नहीं करता है, इसलिए यदि कॉलर सावधान नहीं है, तो परिणाम फर्जी है और panic (हालांकि यह `unsafe` नहीं होगा) हो सकता है।
/// इसके अतिरिक्त, खाली तारों को शून्य माना जाता है।
/// यह फ़ंक्शन मौजूद है क्योंकि
///
/// 1. `&[u8]` पर `FromStr` का उपयोग करने के लिए `from_utf8_unchecked` की आवश्यकता होती है, जो खराब है, और
/// 2. `integral.parse()` और `fractional.parse()` के परिणामों को एक साथ जोड़ना इस पूरे फ़ंक्शन की तुलना में अधिक जटिल है।
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ASCII अंकों की एक स्ट्रिंग को एक बिग्नम में परिवर्तित करता है।
///
/// `from_str_unchecked` की तरह, यह फ़ंक्शन गैर-अंकों को निकालने के लिए पार्सर पर निर्भर करता है।
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// एक बिग्नम को 64 बिट पूर्णांक में खोल देता है।Panics यदि संख्या बहुत बड़ी है।
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// बिट्स की एक श्रृंखला निकालता है।

/// इंडेक्स 0 सबसे कम महत्वपूर्ण बिट है और रेंज हमेशा की तरह आधा खुला है।
/// Panics अगर रिटर्न प्रकार में फिट होने से अधिक बिट्स निकालने के लिए कहा जाए।
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}