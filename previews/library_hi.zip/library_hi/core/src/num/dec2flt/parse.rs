//! फॉर्म की दशमलव स्ट्रिंग को मान्य और विघटित करना:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! दूसरे शब्दों में, मानक फ़्लोटिंग-पॉइंट सिंटैक्स, दो अपवादों के साथ: कोई संकेत नहीं, और "inf" और "NaN" की कोई हैंडलिंग नहीं।इन्हें ड्राइवर फ़ंक्शन (super::dec2flt) द्वारा नियंत्रित किया जाता है।
//!
//! हालांकि वैध इनपुट को पहचानना अपेक्षाकृत आसान है, इस मॉड्यूल को अनगिनत अमान्य विविधताओं को भी अस्वीकार करना पड़ता है, panic कभी नहीं, और कई जांच करता है कि अन्य मॉड्यूल बदले में panic (या अतिप्रवाह) पर निर्भर नहीं हैं।
//!
//! मामलों को बदतर बनाने के लिए, इनपुट पर एक ही पास में जो कुछ भी होता है।
//! इसलिए, कुछ भी संशोधित करते समय सावधान रहें, और अन्य मॉड्यूल के साथ दोबारा जांच करें।
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// दशमलव स्ट्रिंग के दिलचस्प भाग।
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// दशमलव घातांक, 18 से कम दशमलव अंक होने की गारंटी।
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// जाँचता है कि क्या इनपुट स्ट्रिंग एक वैध फ्लोटिंग पॉइंट नंबर है और यदि ऐसा है, तो इसमें इंटीग्रल पार्ट, फ्रैक्शनल पार्ट और एक्सपोनेंट का पता लगाएं।
/// संकेतों को संभालता नहीं है।
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e'. से पहले कोई अंक नहीं
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // हमें बिंदु से पहले या बाद में कम से कम एक अंक की आवश्यकता होती है।
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // भिन्नात्मक भाग के बाद अनुगामी कबाड़
            }
        }
        _ => Invalid, // पहले डिजिट स्ट्रिंग के बाद अनुगामी कबाड़
    }
}

/// दशमलव अंकों को पहले गैर-अंकीय वर्ण तक तराशता है।
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// घातांक निष्कर्षण और त्रुटि जाँच।
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // घातांक के बाद अनुगामी कबाड़
    }
    if number.is_empty() {
        return Invalid; // खाली घातांक
    }
    // इस बिंदु पर, हमारे पास निश्चित रूप से अंकों की एक मान्य स्ट्रिंग है।`i64` में डालना बहुत लंबा हो सकता है, लेकिन अगर यह इतना बड़ा है, तो इनपुट निश्चित रूप से शून्य या अनंत है।
    // चूंकि दशमलव अंकों में प्रत्येक शून्य केवल घातांक को +/-1 से समायोजित करता है, exp=10^18 पर इनपुट को 17 एक्साबाइट (!) शून्य होना चाहिए ताकि दूर से भी परिमित होने के करीब पहुंच सके।
    //
    // यह वास्तव में उपयोग का मामला नहीं है जिसे हमें पूरा करने की आवश्यकता है।
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}