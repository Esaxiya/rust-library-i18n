//! कस्टम मनमाना-सटीक संख्या (bignum) कार्यान्वयन।
//!
//! यह स्टैक मेमोरी की कीमत पर हीप आवंटन से बचने के लिए डिज़ाइन किया गया है।
//! सबसे अधिक इस्तेमाल किया जाने वाला बिग्नम प्रकार, `Big32x40`, 32 × 40=1,280 बिट्स द्वारा सीमित है और स्टैक मेमोरी के अधिकतम 160 बाइट्स लेगा।
//! यह सभी संभावित परिमित `f64` मानों को राउंड-ट्रिपिंग करने के लिए पर्याप्त से अधिक है।
//!
//! सिद्धांत रूप में विभिन्न इनपुट के लिए कई बिग्नम प्रकार होना संभव है, लेकिन हम कोड ब्लोट से बचने के लिए ऐसा नहीं करते हैं।
//!
//! प्रत्येक बिग्नम को अभी भी वास्तविक उपयोगों के लिए ट्रैक किया जाता है, इसलिए यह सामान्य रूप से कोई फर्क नहीं पड़ता।
//!

// यह मॉड्यूल केवल dec2flt और flt2dec के लिए है, और केवल कोरटेस्ट के कारण सार्वजनिक है।
// यह कभी भी स्थिर होने का इरादा नहीं है।
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// बिग्नम द्वारा आवश्यक अंकगणितीय संचालन।
pub trait FullOps: Sized {
    /// `(carry', v')` लौटाता है जैसे कि `carry' * 2^W + v' = self + other + carry`, जहां `W` `Self` में बिट्स की संख्या है।
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// `(carry', v')` लौटाता है जैसे कि `carry'*2^W + v' = self* other + carry`, जहां `W` `Self` में बिट्स की संख्या है।
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(carry', v')` लौटाता है जैसे कि `carry'*2^W + v' = self* other + other2 + carry`, जहां `W` `Self` में बिट्स की संख्या है।
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(quo, rem)` लौटाता है जैसे कि `borrow *2^W + self = quo* other + rem` और `0 <= rem < other`, जहां `W` `Self` में बिट्स की संख्या है।
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // यह अतिप्रवाह नहीं हो सकता;आउटपुट `0` और `2 * 2^nbits - 1` के बीच है।
                    // FIXME: क्या एलएलवीएम इसे एडीसी या समान में अनुकूलित करेगा?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // यह अतिप्रवाह नहीं हो सकता;
                    // आउटपुट `0` और `2^nbits * (2^nbits - 1)` के बीच है।
                    // FIXME: क्या एलएलवीएम इसे एडीसी या समान में अनुकूलित करेगा?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // यह अतिप्रवाह नहीं हो सकता;
                    // आउटपुट `0` और `2^nbits * (2^nbits - 1)` के बीच है।
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // यह अतिप्रवाह नहीं हो सकता;आउटपुट `0` और `other * (2^nbits - 1)` के बीच है।
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // इसे सक्षम करने के लिए RFC #521 देखें।
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// अंकों में प्रतिनिधित्व योग्य 5 की शक्तियों की तालिका।विशेष रूप से, सबसे बड़ा {u8, u16, u32} मान जो पांच की शक्ति है, साथ ही संबंधित एक्सपोनेंट भी है।
/// `mul_pow5` में प्रयुक्त।
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// स्टैक-आवंटित मनमाना-सटीक (निश्चित सीमा तक) पूर्णांक।
        ///
        /// यह दिए गए प्रकार ("digit") के एक निश्चित आकार के सरणी द्वारा समर्थित है।
        /// जबकि सरणी बहुत बड़ी नहीं है (आमतौर पर कुछ सौ बाइट्स), इसे लापरवाही से कॉपी करने से प्रदर्शन प्रभावित हो सकता है।
        ///
        /// इस प्रकार यह जानबूझकर `Copy` नहीं है।
        ///
        /// अतिप्रवाह के मामले में बिग्नम panic के लिए उपलब्ध सभी ऑपरेशन।
        /// कॉलर बड़े पर्याप्त प्रकार के बिग्नम का उपयोग करने के लिए ज़िम्मेदार है।
        pub struct $name {
            /// उपयोग में अधिकतम "digit" के लिए एक प्लस ऑफ़सेट।
            /// यह घटता नहीं है, इसलिए गणना क्रम से अवगत रहें।
            /// `base[size..]` शून्य होना चाहिए।
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` `a + b *2^W + c* 2^(2W) + ...` का प्रतिनिधित्व करता है जहां `W` अंक प्रकार में बिट्स की संख्या है।
            base: [$ty; $n],
        }

        impl $name {
            /// एक अंक से बिग्नम बनाता है।
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// `u64` मान से एक बिग्नम बनाता है।
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// आंतरिक अंकों को एक स्लाइस `[a, b, c, ...]` के रूप में लौटाता है जैसे कि संख्यात्मक मान `a + b *2^W + c* 2^(2W) + ...` है जहां `W` अंक प्रकार में बिट्स की संख्या है।
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// `i`-वें बिट देता है जहां बिट 0 सबसे कम महत्वपूर्ण है।
            /// दूसरे शब्दों में, वजन `2^i` के साथ बिट।
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// यदि बिग्नम शून्य है तो `true` लौटाता है।
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// इस मान का प्रतिनिधित्व करने के लिए आवश्यक बिट्स की संख्या देता है।
            /// ध्यान दें कि शून्य को 0 बिट्स की आवश्यकता माना जाता है।
            pub fn bit_length(&self) -> usize {
                // सबसे महत्वपूर्ण अंकों को छोड़ दें जो शून्य हैं।
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // कोई गैर-शून्य अंक नहीं हैं, अर्थात संख्या शून्य है।
                    return 0;
                }
                // इसे leading_zeros() और बिट शिफ्ट के साथ अनुकूलित किया जा सकता है, लेकिन यह शायद परेशानी के लायक नहीं है।
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// `other` को स्वयं में जोड़ता है और अपना स्वयं का परिवर्तनशील संदर्भ देता है।
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// `other` को स्वयं से घटाता है और अपना स्वयं का परिवर्तनशील संदर्भ देता है।
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// अंक-आकार के `other` से स्वयं को गुणा करता है और अपना स्वयं का परिवर्तनशील संदर्भ देता है।
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// स्वयं को `2^bits` से गुणा करता है और अपना स्वयं का परिवर्तनशील संदर्भ देता है।
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // `digits * digitbits` बिट्स द्वारा शिफ्ट करें
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // `bits` बिट्स द्वारा शिफ्ट करें
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [..digits] शून्य है, शिफ्ट करने की कोई आवश्यकता नहीं है
                }

                self.size = sz;
                self
            }

            /// स्वयं को `5^e` से गुणा करता है और अपना स्वयं का परिवर्तनशील संदर्भ देता है।
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // 2 ^ n पर बिल्कुल n अनुगामी शून्य हैं, और केवल प्रासंगिक अंक आकार दो की लगातार शक्तियाँ हैं, इसलिए यह तालिका के लिए अच्छी तरह से अनुकूल सूचकांक है।
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // जब तक संभव हो सबसे बड़ी एकल अंकों की शक्ति से गुणा करें ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... फिर शेष को समाप्त करें।
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` द्वारा वर्णित संख्या से स्वयं को गुणा करता है (जहां `W` अंक प्रकार में बिट्स की संख्या है) और अपना स्वयं का परिवर्तनशील संदर्भ देता है।
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // आंतरिक दिनचर्या।सबसे अच्छा काम करता है जब aa.len() <= bb.len()।
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// खुद को एक अंक-आकार के `other` से विभाजित करता है और अपना स्वयं का परिवर्तनशील संदर्भ *और* शेष देता है।
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// स्वयं को दूसरे बिग्नम से विभाजित करें, भागफल के साथ `q` और शेष के साथ `r` को अधिलेखित करें।
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // स्टुपिड स्लो base-2 लॉन्ग डिवीजन से लिया गया
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME लंबे विभाजन के लिए एक बड़े आधार ($ty) का उपयोग करता है।
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // q के बिट `i` को 1 पर सेट करें।
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// `Big32x40` के लिए अंक प्रकार।
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// यह केवल परीक्षण के लिए प्रयोग किया जाता है।
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}