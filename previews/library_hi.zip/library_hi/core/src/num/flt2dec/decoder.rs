//! फ्लोटिंग-पॉइंट मान को अलग-अलग भागों और त्रुटि श्रेणियों में डिकोड करता है।

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// डिकोड किया गया अहस्ताक्षरित परिमित मान, जैसे:
///
/// - मूल मान `mant * 2^exp` के बराबर है।
///
/// - `(mant - minus)*2^exp` से `(mant + plus)* 2^exp` तक की कोई भी संख्या मूल मान के बराबर होगी।
/// सीमा केवल तभी समावेशी होती है जब `inclusive`, `true` हो।
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// स्केल्ड मंटिसा।
    pub mant: u64,
    /// कम त्रुटि सीमा।
    pub minus: u64,
    /// ऊपरी त्रुटि सीमा।
    pub plus: u64,
    /// आधार 2 में साझा घातांक।
    pub exp: i16,
    /// सही है जब त्रुटि श्रेणी समावेशी है।
    ///
    /// आईईईई 754 में, यह सच है जब मूल मंटिसा भी था।
    pub inclusive: bool,
}

/// डीकोडेड अहस्ताक्षरित मूल्य।
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// अनंत, या तो सकारात्मक या नकारात्मक।
    Infinite,
    /// शून्य, या तो सकारात्मक या नकारात्मक।
    Zero,
    /// आगे डिकोड किए गए फ़ील्ड के साथ परिमित संख्याएँ।
    Finite(Decoded),
}

/// एक फ़्लोटिंग पॉइंट प्रकार जो `डीकोड` डी हो सकता है।
pub trait DecodableFloat: RawFloat + Copy {
    /// न्यूनतम सकारात्मक सामान्यीकृत मूल्य।
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// दिए गए फ़्लोटिंग पॉइंट नंबर से एक चिन्ह (नकारात्मक होने पर सही) और `FullDecoded` मान देता है।
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // पड़ोसी: (मंत, २, क्स्प)--(मंट, क्स्प)--(मंत + २, क्स्प)
            // Float::integer_decode हमेशा घातांक को संरक्षित करता है, इसलिए मंटिसा को असामान्यताओं के लिए बढ़ाया जाता है।
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // पड़ोसी: (अधिकतम, क्स्प, १)--(minnormmant, क्स्प)--(minnormmant + 1, क्स्प)
                // जहां मैक्समैंट=मिननॉर्ममेंट * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // पड़ोसी: (मंत, १, क्स्प)--(मंट, क्स्प)--(मंत + १, क्स्प)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}