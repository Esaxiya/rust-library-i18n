/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// जबकि यह व्यापक रूप से प्रलेखित है, यह सैद्धांतिक रूप से निजी है जिसे केवल परीक्षण के लिए सार्वजनिक किया जाता है।
// हमें बेनकाब मत करो।
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// अंक-पीढ़ी एल्गोरिदम।
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// न्यूनतम मोड के लिए आवश्यक बफर का न्यूनतम आकार।
///
/// यह प्राप्त करने के लिए थोड़ा गैर-तुच्छ है, लेकिन यह सबसे कम परिणाम वाले एल्गोरिदम को स्वरूपित करने से महत्वपूर्ण दशमलव अंकों की अधिकतम संख्या है।
///
/// सटीक सूत्र `ceil(# bits in mantissa * log_10 2 + 1)` है।
pub const MAX_SIG_DIGITS: usize = 17;

/// जब `d` में दशमलव अंक हों, तो अंतिम अंक बढ़ाएं और कैरी का प्रचार करें।
/// लंबाई बदलने पर अगला अंक लौटाता है।
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i+1..n] सभी नौ है
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 बढ़े हुए घातांक के साथ 1000..000 तक राउंड
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // एक खाली बफर राउंड अप (थोड़ा अजीब लेकिन उचित)
            Some(b'1')
        }
    }
}

/// स्वरूपित भाग।
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// शून्य अंकों की संख्या दी गई है।
    Zero(usize),
    /// 5 अंकों तक की एक शाब्दिक संख्या।
    Num(u16),
    /// दिए गए बाइट्स की शब्दशः प्रति।
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// दिए गए भाग की सटीक बाइट लंबाई लौटाता है।
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// आपूर्ति किए गए बफर में एक हिस्सा लिखता है।
    /// यदि बफ़र पर्याप्त नहीं है, तो लिखित बाइट्स की संख्या या `None` लौटाता है।
    /// (यह अभी भी बफर में आंशिक रूप से लिखित बाइट छोड़ सकता है; उस पर भरोसा न करें।)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// एक या अधिक भागों वाले स्वरूपित परिणाम।
/// इसे बाइट बफर में लिखा जा सकता है या आवंटित स्ट्रिंग में परिवर्तित किया जा सकता है।
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// एक बाइट टुकड़ा एक संकेत का प्रतिनिधित्व करता है, या तो `""`, `"-"` या `"+"`।
    pub sign: &'static str,
    /// स्वरूपित भागों को एक संकेत और वैकल्पिक शून्य पैडिंग के बाद प्रस्तुत किया जाना है।
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// संयुक्त स्वरूपित परिणाम की सटीक बाइट लंबाई देता है।
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// सभी स्वरूपित भागों को आपूर्ति किए गए बफर में लिखता है।
    /// यदि बफ़र पर्याप्त नहीं है, तो लिखित बाइट्स की संख्या या `None` लौटाता है।
    /// (यह अभी भी बफर में आंशिक रूप से लिखित बाइट छोड़ सकता है; उस पर भरोसा न करें।)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// दशमलव अंक `0.<...buf...> * 10^exp` को दशमलव रूप में कम से कम दिए गए भिन्नात्मक अंकों के साथ प्रारूपित करें।
///
/// परिणाम आपूर्ति किए गए भागों सरणी में संग्रहीत किया जाता है और लिखित भागों का एक टुकड़ा वापस कर दिया जाता है।
///
/// `frac_digits` `buf` में वास्तविक भिन्नात्मक अंकों की संख्या से कम हो सकता है;
/// इसे अनदेखा कर दिया जाएगा और पूर्ण अंक मुद्रित किए जाएंगे।इसका उपयोग केवल रेंडर किए गए अंकों के बाद अतिरिक्त शून्य प्रिंट करने के लिए किया जाता है।
/// इस प्रकार 0 के `frac_digits` का अर्थ है कि यह केवल दिए गए अंकों को प्रिंट करेगा और कुछ नहीं।
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // यदि अंतिम अंक की स्थिति पर प्रतिबंध है, तो `buf` को आभासी शून्य के साथ बाएं-गद्देदार माना जाता है।
    // आभासी शून्यों की संख्या, `nzeroes`, `max(0, exp + frac_digits - buf.len())` के बराबर है, ताकि अंतिम अंक `exp - buf.len() - nzeroes` की स्थिति `-frac_digits` से अधिक न हो:
    //
    //
    //                       |<-virtual->|
    //       |<----बफ---->|शून्य |ऍक्स्प
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10^expक्स्प 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` अतिप्रवाह से बचने के लिए प्रत्येक मामले के लिए व्यक्तिगत रूप से गणना की जाती है।
    //

    if exp <= 0 {
        // दशमलव बिंदु प्रदान किए गए अंकों से पहले है: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // सुरक्षा: हमने अभी `..4` तत्वों को इनिशियलाइज़ किया है।
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // सुरक्षा: हमने अभी `..3` तत्वों को इनिशियलाइज़ किया है।
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // दशमलव बिंदु प्रदान किए गए अंकों के अंदर है: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // सुरक्षा: हमने अभी `..4` तत्वों को इनिशियलाइज़ किया है।
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // सुरक्षा: हमने अभी `..3` तत्वों को इनिशियलाइज़ किया है।
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // दशमलव बिंदु प्रदान किए गए अंकों के बाद है: [1234][____0000] या [1234][__][.][__]।
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // सुरक्षा: हमने अभी `..4` तत्वों को इनिशियलाइज़ किया है।
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // सुरक्षा: हमने अभी `..2` तत्वों को इनिशियलाइज़ किया है।
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// दिए गए दशमलव अंक `0.<...buf...> * 10^exp` को कम से कम महत्वपूर्ण अंकों की दी गई संख्या के साथ घातीय रूप में प्रारूपित करता है।
///
/// जब `upper`, `true` है, तो घातांक के आगे `E` होगा;अन्यथा वह `e` है।
/// परिणाम आपूर्ति किए गए भागों सरणी में संग्रहीत किया जाता है और लिखित भागों का एक टुकड़ा वापस कर दिया जाता है।
///
/// `min_digits` `buf` में वास्तविक सार्थक अंकों की संख्या से कम हो सकता है;
/// इसे अनदेखा कर दिया जाएगा और पूर्ण अंक मुद्रित किए जाएंगे।इसका उपयोग केवल रेंडर किए गए अंकों के बाद अतिरिक्त शून्य प्रिंट करने के लिए किया जाता है।
/// इस प्रकार, `min_digits == 0` का अर्थ है कि यह केवल दिए गए अंकों को प्रिंट करेगा और कुछ नहीं।
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10^exp= 1.234 x 10^(exp-1)
    let exp = exp as i32 - 1; // क्स्प i16::MIN होने पर अंडरफ्लो से बचें
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // सुरक्षा: हमने अभी `..n + 2` तत्वों को इनिशियलाइज़ किया है।
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// स्वरूपण विकल्पों पर हस्ताक्षर करें।
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// केवल नकारात्मक गैर-शून्य मानों के लिए `-` प्रिंट करता है।
    Minus, // -inf -1 0 0 1 इन्फ नैन
    /// केवल किसी भी नकारात्मक मान (ऋणात्मक शून्य सहित) के लिए `-` प्रिंट करता है।
    MinusRaw, // -inf -1 -0 0 1 इन्फ नैन
    /// नकारात्मक गैर-शून्य मानों के लिए `-` प्रिंट करता है, या अन्यथा `+` प्रिंट करता है।
    MinusPlus, // -inf -1 +0 +0 +1 +इन्फ नैन
    /// किसी भी नकारात्मक मान (ऋणात्मक शून्य सहित), या `+` अन्यथा के लिए `-` प्रिंट करता है।
    MinusPlusRaw, // -inf -1 -0 +0 +1 +इंफ नैन
}

/// स्वरूपित किए जाने वाले चिह्न के अनुरूप स्थिर बाइट स्ट्रिंग लौटाता है।
/// यह या तो `""`, `"+"` या `"-"` हो सकता है।
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// दिए गए फ़्लोटिंग पॉइंट नंबर को दशमलव रूप में कम से कम दिए गए भिन्नात्मक अंकों के साथ स्वरूपित करता है।
/// दिए गए बाइट बफर को स्क्रैच के रूप में उपयोग करते समय परिणाम आपूर्ति किए गए भागों सरणी में संग्रहीत किया जाता है।
/// `upper` वर्तमान में अप्रयुक्त है, लेकिन गैर-परिमित मानों, यानी `inf` और `nan` के मामले को बदलने के लिए future निर्णय के लिए छोड़ दिया गया है।
///
/// प्रस्तुत किया जाने वाला पहला भाग हमेशा एक `Part::Sign` होता है (यदि कोई संकेत नहीं दिया जाता है तो यह एक खाली स्ट्रिंग हो सकता है)।
///
/// `format_shortest` अंतर्निहित अंक-पीढ़ी का कार्य होना चाहिए।
/// इसे बफर के उस हिस्से को वापस करना चाहिए जिसे उसने प्रारंभ किया था।
/// आप शायद इसके लिए `strategy::grisu::format_shortest` चाहेंगे।
///
/// `frac_digits` `v` में वास्तविक भिन्नात्मक अंकों की संख्या से कम हो सकता है;
/// इसे अनदेखा कर दिया जाएगा और पूर्ण अंक मुद्रित किए जाएंगे।इसका उपयोग केवल रेंडर किए गए अंकों के बाद अतिरिक्त शून्य प्रिंट करने के लिए किया जाता है।
/// इस प्रकार 0 के `frac_digits` का अर्थ है कि यह केवल दिए गए अंकों को प्रिंट करेगा और कुछ नहीं।
///
/// बाइट बफ़र कम से कम `MAX_SIG_DIGITS` बाइट लंबा होना चाहिए।
/// `frac_digits = 10` के साथ `[+][0.][0000][2][0000]` जैसे सबसे खराब स्थिति के कारण, कम से कम 4 भाग उपलब्ध होने चाहिए।
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // सुरक्षा: हमने अभी `..1` तत्वों को इनिशियलाइज़ किया है।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // सुरक्षा: हमने अभी `..1` तत्वों को इनिशियलाइज़ किया है।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // सुरक्षा: हमने अभी `..2` तत्वों को इनिशियलाइज़ किया है।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // सुरक्षा: हमने अभी `..1` तत्वों को इनिशियलाइज़ किया है।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// परिणामी घातांक के आधार पर दिए गए फ़्लोटिंग पॉइंट नंबर को दशमलव रूप या घातांक रूप में स्वरूपित करता है।
/// दिए गए बाइट बफर को स्क्रैच के रूप में उपयोग करते समय परिणाम आपूर्ति किए गए भागों सरणी में संग्रहीत किया जाता है।
/// `upper` गैर-परिमित मानों (`inf` और `nan`) या घातांक उपसर्ग (`e` या `E`) के मामले को निर्धारित करने के लिए उपयोग किया जाता है।
/// प्रस्तुत किया जाने वाला पहला भाग हमेशा एक `Part::Sign` होता है (यदि कोई संकेत नहीं दिया जाता है तो यह एक खाली स्ट्रिंग हो सकता है)।
///
/// `format_shortest` अंतर्निहित अंक-पीढ़ी का कार्य होना चाहिए।
/// इसे बफर के उस हिस्से को वापस करना चाहिए जिसे उसने प्रारंभ किया था।
/// आप शायद इसके लिए `strategy::grisu::format_shortest` चाहेंगे।
///
/// `dec_bounds` एक टपल `(lo, hi)` है जैसे कि संख्या केवल `10^lo <= V < 10^hi` होने पर दशमलव के रूप में स्वरूपित होती है।
/// ध्यान दें कि यह वास्तविक `v` के बजाय *स्पष्ट*`V` है!इस प्रकार घातांक रूप में कोई भी मुद्रित घातांक किसी भी भ्रम से बचने के लिए इस सीमा में नहीं हो सकता।
///
///
/// बाइट बफ़र कम से कम `MAX_SIG_DIGITS` बाइट लंबा होना चाहिए।
/// `[+][1][.][2345][e][-][6]` जैसे सबसे खराब स्थिति के कारण कम से कम 6 भाग उपलब्ध होने चाहिए।
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // सुरक्षा: हमने अभी `..1` तत्वों को इनिशियलाइज़ किया है।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // सुरक्षा: हमने अभी `..1` तत्वों को इनिशियलाइज़ किया है।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // सुरक्षा: हमने अभी `..1` तत्वों को इनिशियलाइज़ किया है।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// दिए गए डिकोड किए गए घातांक से परिकलित अधिकतम बफ़र आकार के लिए अपेक्षाकृत अपरिष्कृत सन्निकटन (ऊपरी सीमा) देता है।
///
/// सटीक सीमा है:
///
/// - जब `exp < 0`, अधिकतम लंबाई `ceil(log_10 (5^-exp * (2^64 - 1)))` है।
/// - जब `exp >= 0`, अधिकतम लंबाई `ceil(log_10 (2^exp * (2^64 - 1)))` है।
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)` से कम है, जो बदले में `20 + (1 + exp* log_10 x)` से कम है।
/// हम इस तथ्य का उपयोग करते हैं कि `log_10 2 < 5/16` और `log_10 5 < 12/16`, जो हमारे उद्देश्यों के लिए पर्याप्त है।
///
/// हमें यह क्यों चाहिये?`format_exact` फ़ंक्शन पूरे बफर को भर देगा जब तक कि अंतिम अंक प्रतिबंध तक सीमित न हो, लेकिन यह संभव है कि अनुरोधित अंकों की संख्या हास्यास्पद रूप से बड़ी हो (जैसे, 30,000 अंक)।
///
/// बफर का विशाल बहुमत शून्य से भरा होगा, इसलिए हम सभी बफर को पहले से आवंटित नहीं करना चाहते हैं।
/// नतीजतन, किसी दिए गए तर्क के लिए,
/// `f64` के लिए 826 बाइट बफर पर्याप्त होना चाहिए।सबसे खराब स्थिति के लिए वास्तविक संख्या के साथ इसकी तुलना करें: 770 बाइट्स (जब `exp = -1074`)।
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// महत्वपूर्ण अंकों की सटीक दी गई संख्या के साथ फ़्लोटिंग पॉइंट नंबर को घातीय रूप में दिए गए प्रारूप।
/// दिए गए बाइट बफर को स्क्रैच के रूप में उपयोग करते समय परिणाम आपूर्ति किए गए भागों सरणी में संग्रहीत किया जाता है।
/// `upper` घातांक उपसर्ग (`e` या `E`) के मामले को निर्धारित करने के लिए प्रयोग किया जाता है।
/// प्रस्तुत किया जाने वाला पहला भाग हमेशा एक `Part::Sign` होता है (यदि कोई संकेत नहीं दिया जाता है तो यह एक खाली स्ट्रिंग हो सकता है)।
///
/// `format_exact` अंतर्निहित अंक-पीढ़ी का कार्य होना चाहिए।
/// इसे बफर के उस हिस्से को वापस करना चाहिए जिसे उसने प्रारंभ किया था।
/// आप शायद इसके लिए `strategy::grisu::format_exact` चाहेंगे।
///
/// बाइट बफर कम से कम `ndigits` बाइट लंबा होना चाहिए जब तक कि `ndigits` इतना बड़ा न हो कि केवल निश्चित अंकों की संख्या ही लिखी जाएगी।
/// (`f64` के लिए टिपिंग पॉइंट लगभग 800 है, इसलिए 1000 बाइट्स पर्याप्त होने चाहिए।) `[+][1][.][2345][e][-][6]` जैसे सबसे खराब स्थिति के कारण कम से कम 6 भाग उपलब्ध होने चाहिए।
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // सुरक्षा: हमने अभी `..1` तत्वों को इनिशियलाइज़ किया है।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // सुरक्षा: हमने अभी `..1` तत्वों को इनिशियलाइज़ किया है।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // सुरक्षा: हमने अभी `..3` तत्वों को इनिशियलाइज़ किया है।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // सुरक्षा: हमने अभी `..1` तत्वों को इनिशियलाइज़ किया है।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// फ़्लोटिंग पॉइंट नंबर को दशमलव रूप में दिए गए प्रारूपों में भिन्नात्मक अंकों की संख्या के साथ।
/// दिए गए बाइट बफर को स्क्रैच के रूप में उपयोग करते समय परिणाम आपूर्ति किए गए भागों सरणी में संग्रहीत किया जाता है।
/// `upper` वर्तमान में अप्रयुक्त है, लेकिन गैर-परिमित मानों, यानी `inf` और `nan` के मामले को बदलने के लिए future निर्णय के लिए छोड़ दिया गया है।
/// प्रस्तुत किया जाने वाला पहला भाग हमेशा एक `Part::Sign` होता है (यदि कोई संकेत नहीं दिया जाता है तो यह एक खाली स्ट्रिंग हो सकता है)।
///
/// `format_exact` अंतर्निहित अंक-पीढ़ी का कार्य होना चाहिए।
/// इसे बफर के उस हिस्से को वापस करना चाहिए जिसे उसने प्रारंभ किया था।
/// आप शायद इसके लिए `strategy::grisu::format_exact` चाहेंगे।
///
/// बाइट बफर आउटपुट के लिए पर्याप्त होना चाहिए जब तक कि `frac_digits` इतना बड़ा न हो कि केवल निश्चित अंकों की संख्या ही लिखी जाएगी।
/// (`f64` के लिए टिपिंग बिंदु लगभग 800 है, और 1000 बाइट्स पर्याप्त होने चाहिए।) `frac_digits = 10` के साथ `[+][0.][0000][2][0000]` जैसे सबसे खराब स्थिति के कारण, कम से कम 4 भाग उपलब्ध होने चाहिए।
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // सुरक्षा: हमने अभी `..1` तत्वों को इनिशियलाइज़ किया है।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // सुरक्षा: हमने अभी `..1` तत्वों को इनिशियलाइज़ किया है।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // सुरक्षा: हमने अभी `..2` तत्वों को इनिशियलाइज़ किया है।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // सुरक्षा: हमने अभी `..1` तत्वों को इनिशियलाइज़ किया है।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // यह * संभव है कि `frac_digits` हास्यास्पद रूप से बड़ा हो।
            // `format_exact` इस मामले में अंकों का प्रतिपादन बहुत पहले समाप्त हो जाएगा, क्योंकि हम `maxlen` द्वारा सख्ती से सीमित हैं।
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // प्रतिबंध को पूरा नहीं किया जा सका, इसलिए इसे शून्य की तरह प्रस्तुत करना चाहिए, कोई फर्क नहीं पड़ता कि `exp` था।
                // इसमें यह मामला शामिल नहीं है कि प्रतिबंध अंतिम राउंड-अप के बाद ही पूरा किया गया है;यह `exp = limit + 1` के साथ एक नियमित मामला है।
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // सुरक्षा: हमने अभी `..2` तत्वों को इनिशियलाइज़ किया है।
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // सुरक्षा: हमने अभी `..1` तत्वों को इनिशियलाइज़ किया है।
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}