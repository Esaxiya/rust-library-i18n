//! लगभग प्रत्यक्ष (लेकिन थोड़ा अनुकूलित) Rust "फ्लोटिंग-पॉइंट नंबरों को जल्दी और सटीक रूप से प्रिंट करना" [^ 1] के चित्र 3 का अनुवाद।
//!
//!
//! [^1]: Burger, आरजी और डायबविग, आरके 1996। फ्लोटिंग-पॉइंट नंबर प्रिंट करना
//!   जल्दी और सही ढंग से।सिगप्लान नहीं।३१, ५ (मई. १९९६), १०८-११६।

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10^(2^n) के लिए `डिजिट` की पूर्व-गणना की गई सरणियाँ
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// केवल प्रयोग योग्य जब `x < 16 * scale`;`scaleN`, `scale.mul_small(N)` होना चाहिए
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// ड्रैगन के लिए सबसे छोटा मोड कार्यान्वयन।
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // प्रारूप के लिए `v` की संख्या ज्ञात है:
    // - `mant * 2^exp` के बराबर;
    // - मूल प्रकार में `(mant - 2 *minus)* 2^exp` से पहले;तथा
    // - मूल प्रकार में `(mant + 2 *plus)* 2^exp` के बाद।
    //
    // जाहिर है, `minus` और `plus` शून्य नहीं हो सकते।(अनंत के लिए, हम आउट-ऑफ-रेंज मानों का उपयोग करते हैं।) हम यह भी मानते हैं कि कम से कम एक अंक उत्पन्न होता है, अर्थात, `mant` शून्य भी नहीं हो सकता।
    //
    // इसका मतलब यह भी है कि `low = (mant - minus)*2^exp` और `high = (mant + plus)* 2^exp` के बीच की कोई भी संख्या इस सटीक फ़्लोटिंग पॉइंट नंबर पर मैप करेगी, जिसमें मूल मंटिसा सम (यानी, `!mant_was_odd`) होने पर सीमा शामिल है।
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` है
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)` को संतुष्ट करने वाले मूल इनपुट से `k_0` का अनुमान लगाएं।
    // तंग बाध्य `k` संतोषजनक `10^(k-1) < high <= 10^k` की गणना बाद में की जाती है।
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` को भिन्नात्मक रूप में परिवर्तित करें ताकि:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` को `10^k` से विभाजित करें।अब `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // फिक्सअप जब `mant + plus > scale` (या `>=`)।
    // हम वास्तव में `scale` को संशोधित नहीं कर रहे हैं, क्योंकि हम इसके बजाय प्रारंभिक गुणन को छोड़ सकते हैं।
    // अब `scale < mant + plus <= scale * 10` और हम अंक उत्पन्न करने के लिए तैयार हैं।
    //
    // ध्यान दें कि `d[0]` *शून्य हो सकता है, जब `scale - plus < mant < scale`.
    // इस मामले में राउंड-अप कंडीशन (नीचे `up`) तुरंत चालू हो जाएगी।
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // `scale` को 10. तक बढ़ाने के बराबर
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // अंक पीढ़ी के लिए कैश `(2, 4, 8) * scale`।
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // अपरिवर्तनीय, जहां `d[0..n-1]` अब तक उत्पन्न अंक हैं:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (इस प्रकार `mant / scale < 10`) जहां `d[i..j]` `d [i] * 10^(ji) + ... के लिए एक आशुलिपि है
        // + डी [जे-1] * 10 + एक्स 00 एक्स।

        // एक अंक उत्पन्न करें: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // यह संशोधित ड्रैगन एल्गोरिथम का सरलीकृत विवरण है।
        // कई मध्यवर्ती व्युत्पन्न और पूर्णता तर्क सुविधा के लिए छोड़े गए हैं।
        //
        // संशोधित इनवेरिएंट से शुरू करें, क्योंकि हमने `n` को अपडेट किया है:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // मान लें कि `d[0..n-1]`, `low` और `high` के बीच सबसे छोटा प्रतिनिधित्व है, अर्थात, `d[0..n-1]` निम्नलिखित दोनों को संतुष्ट करता है लेकिन `d[0..n-2]` नहीं करता है:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (जैविकता: अंक `v` के लिए गोल);तथा
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (अंतिम अंक सही है)।
        //
        // दूसरी शर्त `2 * mant <= scale` को सरल बनाती है।
        // `mant`, `low` और `high` के संदर्भ में इनवेरिएंट को हल करने से पहली शर्त का एक सरल संस्करण मिलता है: `-plus < mant < minus`.
        // `-plus < 0 <= mant` के बाद से, हमारे पास `mant < minus` और `2 * mant <= scale` होने पर सबसे छोटा प्रतिनिधित्व है।
        // (मूल मंटिसा सम होने पर पूर्व `mant <= minus` बन जाता है।)
        //
        // जब दूसरा (`2 * मंट> स्केल`) धारण नहीं करता है, तो हमें अंतिम अंक बढ़ाने की आवश्यकता होती है।
        // यह उस स्थिति को बहाल करने के लिए पर्याप्त है: हम पहले से ही जानते हैं कि अंक पीढ़ी `0 <= v / 10^(k-n) - d[0..n-1] < 1` की गारंटी देती है।
        // इस मामले में, पहली शर्त `-plus < mant - scale < minus` बन जाती है।
        // पीढ़ी के बाद `mant < scale` के बाद से, हमारे पास `scale < mant + plus` है।
        // (फिर से, यह `scale <= mant + plus` हो जाता है जब मूल मंटिसा सम होता है।)
        //
        // संक्षेप में:
        // - `down` (या `<=`) होने पर `down` को रोकें और गोल करें (अंकों को यथावत रखें)।
        // - `up` (या `<=`) होने पर `up` को रोकें और गोल करें (अंतिम अंक बढ़ाएं)।
        // - अन्यथा उत्पन्न करते रहें।
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // हमारे पास सबसे छोटा प्रतिनिधित्व है, गोल करने के लिए आगे बढ़ें

        // अपरिवर्तनीयों को पुनर्स्थापित करें।
        // यह एल्गोरिथम को हमेशा समाप्त करता है: `minus` और `plus` हमेशा बढ़ता है, लेकिन `mant` क्लिप्ड मॉड्यूलो `scale` है और `scale` तय है।
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // राउंडिंग अप तब होता है जब i) केवल राउंडिंग-अप कंडीशन को ट्रिगर किया गया था, या ii) दोनों स्थितियों को ट्रिगर किया गया था और टाई ब्रेकिंग राउंडिंग को प्राथमिकता देता है।
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // यदि गोल करने से लंबाई बदल जाती है, तो घातांक को भी बदलना चाहिए।
        // ऐसा लगता है कि इस स्थिति को संतुष्ट करना बहुत कठिन है (संभवतः असंभव), लेकिन हम यहां केवल सुरक्षित और सुसंगत हैं।
        //
        // सुरक्षा: हमने उस मेमोरी को ऊपर इनिशियलाइज़ किया है।
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // सुरक्षा: हमने उस मेमोरी को ऊपर इनिशियलाइज़ किया है।
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// ड्रैगन के लिए सटीक और निश्चित मोड कार्यान्वयन।
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)` को संतुष्ट करने वाले मूल इनपुट से `k_0` का अनुमान लगाएं।
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` को `10^k` से विभाजित करें।अब `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // फिक्सअप जब `mant + plus >= scale`, जहां `plus / scale = 10^-buf.len() / 2`.
    // निश्चित आकार के बिग्नम को रखने के लिए, हम वास्तव में `mant + floor(plus) >= scale` का उपयोग करते हैं।
    // हम वास्तव में `scale` को संशोधित नहीं कर रहे हैं, क्योंकि हम इसके बजाय प्रारंभिक गुणन को छोड़ सकते हैं।
    // फिर से सबसे छोटे एल्गोरिदम के साथ, `d[0]` शून्य हो सकता है लेकिन अंततः इसे गोल किया जाएगा।
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // `scale` को 10. तक बढ़ाने के बराबर
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // यदि हम अंतिम अंकों की सीमा के साथ काम कर रहे हैं, तो डबल राउंडिंग से बचने के लिए हमें वास्तविक रेंडरिंग से पहले बफर को छोटा करना होगा।
    //
    // ध्यान दें कि राउंड अप होने पर हमें बफर को फिर से बढ़ाना होगा!
    let mut len = if k < limit {
        // उफ़, हम *एक* अंक भी नहीं बना सकते।
        // यह तब संभव है, जब कहें, हमारे पास 9.5 जैसा कुछ है और इसे 10 तक गोल किया जा रहा है।
        // हम बाद के राउंडिंग-अप मामले के अपवाद के साथ एक खाली बफर लौटाते हैं, जो तब होता है जब `k == limit` और ठीक एक अंक का उत्पादन करना होता है।
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // अंक पीढ़ी के लिए कैश `(2, 4, 8) * scale`।
        // (यह महंगा हो सकता है, इसलिए बफर खाली होने पर उनकी गणना न करें।)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // निम्नलिखित अंक सभी शून्य हैं, हम यहीं रुकते हैं *नहीं* गोलाई करने का प्रयास करें!बल्कि, शेष अंक भरें।
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // सुरक्षा: हमने उस मेमोरी को ऊपर इनिशियलाइज़ किया है।
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // यदि हम अंकों के बीच में रुकते हैं, यदि निम्नलिखित अंक ठीक 5000 हैं..., तो पूर्व अंक की जाँच करें और सम को गोल करने का प्रयास करें (अर्थात, पूर्व अंक सम होने पर पूर्णांकन करने से बचें)।
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // सुरक्षा: `buf[len-1]` को इनिशियलाइज़ किया गया है।
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // यदि गोल करने से लंबाई बदल जाती है, तो घातांक को भी बदलना चाहिए।
        // लेकिन हमसे अंकों की एक निश्चित संख्या का अनुरोध किया गया है, इसलिए बफ़र में बदलाव न करें...
        // सुरक्षा: हमने उस मेमोरी को ऊपर इनिशियलाइज़ किया है।
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... जब तक कि हमें इसके बजाय निश्चित सटीकता का अनुरोध नहीं किया जाता है।
            // हमें यह भी जांचना होगा कि, यदि मूल बफ़र खाली था, तो अतिरिक्त अंक केवल तभी जोड़ा जा सकता है जब `k == limit` (edge केस)।
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // सुरक्षा: हमने उस मेमोरी को ऊपर इनिशियलाइज़ किया है।
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}