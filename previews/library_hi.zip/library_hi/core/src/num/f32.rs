//! `f32` एकल-सटीक फ़्लोटिंग पॉइंट प्रकार के लिए विशिष्ट स्थिरांक।
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! `consts` उप-मॉड्यूल में गणितीय रूप से महत्वपूर्ण संख्याएं प्रदान की जाती हैं।
//!
//! इस मॉड्यूल में सीधे परिभाषित स्थिरांक के लिए (`consts` उप-मॉड्यूल में परिभाषित लोगों से अलग), नए कोड को इसके बजाय सीधे `f32` प्रकार पर परिभाषित संबंधित स्थिरांक का उपयोग करना चाहिए।
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f32` के आंतरिक प्रतिनिधित्व का मूलांक या आधार।
/// इसके बजाय [`f32::RADIX`] का प्रयोग करें।
///
/// # Examples
///
/// ```rust
/// // पदावनत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // इरादा रास्ता
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// आधार 2 में सार्थक अंकों की संख्या।
/// इसके बजाय [`f32::MANTISSA_DIGITS`] का प्रयोग करें।
///
/// # Examples
///
/// ```rust
/// // पदावनत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // इरादा रास्ता
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// आधार 10 में सार्थक अंकों की अनुमानित संख्या।
/// इसके बजाय [`f32::DIGITS`] का प्रयोग करें।
///
/// # Examples
///
/// ```rust
/// // पदावनत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // इरादा रास्ता
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] `f32` के लिए मूल्य।
/// इसके बजाय [`f32::EPSILON`] का प्रयोग करें।
///
/// यह `1.0` और अगली बड़ी प्रतिनिधित्व योग्य संख्या के बीच का अंतर है।
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // पदावनत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // इरादा रास्ता
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// सबसे छोटा परिमित `f32` मान।
/// इसके बजाय [`f32::MIN`] का प्रयोग करें।
///
/// # Examples
///
/// ```rust
/// // पदावनत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // इरादा रास्ता
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// सबसे छोटा सकारात्मक सामान्य `f32` मान।
/// इसके बजाय [`f32::MIN_POSITIVE`] का प्रयोग करें।
///
/// # Examples
///
/// ```rust
/// // पदावनत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // इरादा रास्ता
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// सबसे बड़ा परिमित `f32` मान।
/// इसके बजाय [`f32::MAX`] का प्रयोग करें।
///
/// # Examples
///
/// ```rust
/// // पदावनत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // इरादा रास्ता
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// 2 घातांक की न्यूनतम संभव सामान्य शक्ति से एक अधिक।
/// इसके बजाय [`f32::MIN_EXP`] का प्रयोग करें।
///
/// # Examples
///
/// ```rust
/// // पदावनत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // इरादा रास्ता
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// 2 घातांक की अधिकतम संभव शक्ति।
/// इसके बजाय [`f32::MAX_EXP`] का प्रयोग करें।
///
/// # Examples
///
/// ```rust
/// // पदावनत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // इरादा रास्ता
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// 10 घातांक की न्यूनतम संभव सामान्य शक्ति।
/// इसके बजाय [`f32::MIN_10_EXP`] का प्रयोग करें।
///
/// # Examples
///
/// ```rust
/// // पदावनत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // इरादा रास्ता
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// 10 घातांक की अधिकतम संभव शक्ति।
/// इसके बजाय [`f32::MAX_10_EXP`] का प्रयोग करें।
///
/// # Examples
///
/// ```rust
/// // पदावनत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // इरादा रास्ता
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// नंबर (NaN) नहीं।
/// इसके बजाय [`f32::NAN`] का प्रयोग करें।
///
/// # Examples
///
/// ```rust
/// // पदावनत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // इरादा रास्ता
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// इन्फिनिटी (∞)।
/// इसके बजाय [`f32::INFINITY`] का प्रयोग करें।
///
/// # Examples
///
/// ```rust
/// // पदावनत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // इरादा रास्ता
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// नकारात्मक अनंत (−∞)।
/// इसके बजाय [`f32::NEG_INFINITY`] का प्रयोग करें।
///
/// # Examples
///
/// ```rust
/// // पदावनत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // इरादा रास्ता
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// बुनियादी गणितीय स्थिरांक।
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: cmath से गणितीय स्थिरांक से बदलें।

    /// आर्किमिडीज का स्थिरांक (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// पूर्ण चक्र स्थिरांक (τ)
    ///
    /// 2π के बराबर।
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// यूलर की संख्या (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// `f32` के आंतरिक प्रतिनिधित्व का मूलांक या आधार।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// आधार 2 में सार्थक अंकों की संख्या।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// आधार 10 में सार्थक अंकों की अनुमानित संख्या।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] `f32` के लिए मूल्य।
    ///
    /// यह `1.0` और अगली बड़ी प्रतिनिधित्व योग्य संख्या के बीच का अंतर है।
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// सबसे छोटा परिमित `f32` मान।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// सबसे छोटा सकारात्मक सामान्य `f32` मान।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// सबसे बड़ा परिमित `f32` मान।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// 2 घातांक की न्यूनतम संभव सामान्य शक्ति से एक अधिक।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// 2 घातांक की अधिकतम संभव शक्ति।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// 10 घातांक की न्यूनतम संभव सामान्य शक्ति।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// 10 घातांक की अधिकतम संभव शक्ति।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// नंबर (NaN) नहीं।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// इन्फिनिटी (∞)।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// नकारात्मक अनंत (−∞)।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// यदि यह मान `NaN` है तो `true` लौटाता है।
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): पोर्टेबिलिटी के बारे में चिंताओं के कारण `abs` सार्वजनिक रूप से लिबकोर में अनुपलब्ध है, इसलिए यह कार्यान्वयन आंतरिक रूप से निजी उपयोग के लिए है।
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// यदि यह मान धनात्मक अनंत या ऋणात्मक अनंत है, और अन्यथा `false` है तो `true` लौटाता है।
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// यदि यह संख्या न तो अनंत है और न ही `NaN` है, तो `true` लौटाता है।
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN को अलग से संभालने की कोई आवश्यकता नहीं है: यदि स्वयं NaN है, तो तुलना सही नहीं है, बिल्कुल वांछित।
        //
        self.abs_private() < Self::INFINITY
    }

    /// यदि संख्या [subnormal] है तो `true` लौटाता है।
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // `0` और `min` के बीच के मान असामान्य हैं।
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// यदि संख्या शून्य, अनंत, [subnormal], या `NaN` न हो तो `true` लौटाता है।
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // `0` और `min` के बीच के मान असामान्य हैं।
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// संख्या का फ़्लोटिंग पॉइंट श्रेणी देता है।
    /// यदि केवल एक संपत्ति का परीक्षण किया जा रहा है, तो इसके बजाय विशिष्ट विधेय का उपयोग करना आम तौर पर तेज़ होता है।
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// यदि `self` का धनात्मक चिह्न है, जिसमें `+0.0`, `NaN` धनात्मक चिह्न बिट और धनात्मक अनंत के साथ है, तो `true` लौटाता है।
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// यदि `self` में ऋणात्मक चिह्न है, जिसमें `-0.0`, `NaN` का ऋणात्मक चिह्न बिट और ऋणात्मक अनंत शामिल है, तो `true` लौटाता है।
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 कहता है: isSignMinus(x) सत्य है यदि और केवल यदि x में ऋणात्मक चिह्न है।
        // isSignMinus शून्य और NaN पर भी लागू होता है।
        self.to_bits() & 0x8000_0000 != 0
    }

    /// किसी संख्या का व्युत्क्रम (inverse) लेता है, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// रेडियन को डिग्री में बदलता है।
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // बेहतर सटीकता के लिए स्थिरांक का उपयोग करें।
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// डिग्री को रेडियन में बदलता है।
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// दो संख्याओं का अधिकतम लौटाता है।
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// यदि तर्कों में से एक NaN है, तो दूसरा तर्क वापस कर दिया जाता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// दो संख्याओं का न्यूनतम लौटाता है।
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// यदि तर्कों में से एक NaN है, तो दूसरा तर्क वापस कर दिया जाता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// यह मानते हुए कि मान परिमित है और उस प्रकार में फिट बैठता है, शून्य की ओर घूमता है और किसी भी आदिम पूर्णांक प्रकार में परिवर्तित होता है।
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// मान चाहिए:
    ///
    /// * `NaN` नहीं हो
    /// * अनंत नहीं हो
    /// * इसके भिन्नात्मक भाग को छोटा करने के बाद, रिटर्न प्रकार `Int` में प्रतिनिधित्व योग्य बनें
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // सुरक्षा: कॉल करने वाले को `FloatToInt::to_int_unchecked` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u32` में कच्चा रूपांतरण।
    ///
    /// यह वर्तमान में सभी प्लेटफॉर्म पर `transmute::<f32, u32>(self)` के समान है।
    ///
    /// इस ऑपरेशन की पोर्टेबिलिटी की कुछ चर्चा के लिए `from_bits` देखें (लगभग कोई समस्या नहीं है)।
    ///
    /// ध्यान दें कि यह फ़ंक्शन `as` कास्टिंग से अलग है, जो *संख्यात्मक* मान को संरक्षित करने का प्रयास करता है, न कि बिटवाइज़ मान को।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() कास्टिंग नहीं है!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // सुरक्षा: `u32` एक सादा पुराना डेटाटाइप है इसलिए हम इसे हमेशा ट्रांसम्यूट कर सकते हैं
        unsafe { mem::transmute(self) }
    }

    /// `u32` से कच्चा रूपांतरण।
    ///
    /// यह वर्तमान में सभी प्लेटफॉर्म पर `transmute::<u32, f32>(v)` के समान है।
    /// यह पता चला है कि यह अविश्वसनीय रूप से पोर्टेबल है, दो कारणों से:
    ///
    /// * सभी समर्थित प्लेटफॉर्म पर फ़्लोट्स और इंट की अंतहीनता समान है।
    /// * आईईईई-754 फ्लोट्स के बिट लेआउट को बहुत सटीक रूप से निर्दिष्ट करता है।
    ///
    /// हालाँकि एक चेतावनी है: IEEE-754 के 2008 संस्करण से पहले, NaN सिग्नलिंग बिट की व्याख्या कैसे करें, वास्तव में निर्दिष्ट नहीं किया गया था।
    /// अधिकांश प्लेटफ़ॉर्म (विशेषकर x86 और ARM) ने उस व्याख्या को चुना जिसे अंततः 2008 में मानकीकृत किया गया था, लेकिन कुछ ने (विशेषकर MIPS) नहीं किया।
    /// नतीजतन, MIPS पर सभी सिग्नलिंग NaN, x86 पर शांत NaN हैं, और इसके विपरीत।
    ///
    /// सिग्नलिंग-नेस क्रॉस-प्लेटफ़ॉर्म को संरक्षित करने की कोशिश करने के बजाय, यह कार्यान्वयन सटीक बिट्स को संरक्षित करने का पक्षधर है।
    /// इसका मतलब यह है कि NaN में एन्कोड किए गए किसी भी पेलोड को संरक्षित किया जाएगा, भले ही इस पद्धति का परिणाम नेटवर्क पर x86 मशीन से MIPS पर भेजा गया हो।
    ///
    ///
    /// यदि इस पद्धति के परिणामों को केवल उसी वास्तुकला द्वारा हेरफेर किया जाता है जो उन्हें उत्पन्न करता है, तो कोई पोर्टेबिलिटी चिंता का विषय नहीं है।
    ///
    /// यदि इनपुट NaN नहीं है, तो पोर्टेबिलिटी की कोई चिंता नहीं है।
    ///
    /// यदि आपको संकेतन (बहुत संभावना) की परवाह नहीं है, तो कोई पोर्टेबिलिटी चिंता नहीं है।
    ///
    /// ध्यान दें कि यह फ़ंक्शन `as` कास्टिंग से अलग है, जो *संख्यात्मक* मान को संरक्षित करने का प्रयास करता है, न कि बिटवाइज़ मान को।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // सुरक्षा: `u32` एक सादा पुराना डेटाटाइप है इसलिए हम इसे हमेशा से ट्रांसम्यूट कर सकते हैं
        // यह पता चला है कि एसएनएएन के साथ सुरक्षा के मुद्दे बहुत अधिक थे!हुर्रे!
        unsafe { mem::transmute(v) }
    }

    /// बड़े-एंडियन (network) बाइट क्रम में बाइट सरणी के रूप में इस फ़्लोटिंग पॉइंट नंबर की मेमोरी प्रस्तुति को वापस करें।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// इस फ़्लोटिंग पॉइंट नंबर के मेमोरी प्रतिनिधित्व को बाइट सरणी के रूप में छोटे-एंडियन बाइट क्रम में लौटाएं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// मूल बाइट क्रम में बाइट सरणी के रूप में इस फ़्लोटिंग पॉइंट नंबर की स्मृति प्रतिनिधित्व लौटाएं।
    ///
    /// चूंकि लक्ष्य प्लेटफ़ॉर्म की मूल अंतहीनता का उपयोग किया जाता है, पोर्टेबल कोड को इसके बजाय उपयुक्त के रूप में [`to_be_bytes`] या [`to_le_bytes`] का उपयोग करना चाहिए।
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// मूल बाइट क्रम में बाइट सरणी के रूप में इस फ़्लोटिंग पॉइंट नंबर की स्मृति प्रतिनिधित्व लौटाएं।
    ///
    ///
    /// [`to_ne_bytes`] जब भी संभव हो इस पर प्राथमिकता दी जानी चाहिए।
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // सुरक्षा: `f32` एक सादा पुराना डेटाटाइप है इसलिए हम इसे हमेशा ट्रांसम्यूट कर सकते हैं
        unsafe { &*(self as *const Self as *const _) }
    }

    /// बड़े एंडियन में बाइट सरणी के रूप में इसके प्रतिनिधित्व से एक फ़्लोटिंग पॉइंट मान बनाएं।
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// थोड़ा एंडियन में बाइट सरणी के रूप में इसके प्रतिनिधित्व से एक फ़्लोटिंग पॉइंट मान बनाएं।
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// देशी एंडियन में बाइट सरणी के रूप में इसके प्रतिनिधित्व से एक फ़्लोटिंग पॉइंट मान बनाएं।
    ///
    /// चूंकि लक्ष्य प्लेटफ़ॉर्म की मूल अंतहीनता का उपयोग किया जाता है, पोर्टेबल कोड संभवतः इसके बजाय [`from_be_bytes`] या [`from_le_bytes`] का उपयोग करना चाहता है।
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// स्वयं और अन्य मूल्यों के बीच एक आदेश देता है।
    /// फ़्लोटिंग पॉइंट नंबरों के बीच मानक आंशिक तुलना के विपरीत, यह तुलना हमेशा आईईईई 754 (2008 संशोधन) फ़्लोटिंग पॉइंट मानक में परिभाषित कुल ऑर्डर भविष्यवाणी के अनुसार ऑर्डरिंग उत्पन्न करती है।
    /// मूल्यों को निम्नलिखित क्रम में क्रमबद्ध किया गया है:
    /// - नकारात्मक शांत NaN
    /// - नकारात्मक संकेतन NaN
    /// - नकारात्मक अनंत in
    /// - नकारात्मक संख्या
    /// - नकारात्मक असामान्य संख्या
    /// - नकारात्मक शून्य
    /// - सकारात्मक शून्य
    /// - सकारात्मक असामान्य संख्या
    /// - सकारात्मक संख्या
    /// - सकारात्मक अनंत
    /// - सकारात्मक संकेतन NaN
    /// - सकारात्मक शांत NaN
    ///
    /// ध्यान दें कि यह फ़ंक्शन हमेशा `f32` के [`PartialOrd`] और [`PartialEq`] कार्यान्वयन से सहमत नहीं होता है।विशेष रूप से, वे नकारात्मक और सकारात्मक शून्य को समान मानते हैं, जबकि `total_cmp` नहीं।
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // नकारात्मक के मामले में, दो पूरक पूर्णांकों के समान लेआउट प्राप्त करने के लिए चिह्न को छोड़कर सभी बिट्स को फ़्लिप करें
        //
        // यह काम क्यों करता है?आईईईई 754 फ्लोट्स में तीन क्षेत्र होते हैं:
        // साइन बिट, एक्सपोनेंट और मंटिसा।संपूर्ण रूप से घातांक और मंटिसा फ़ील्ड के सेट में यह गुण होता है कि उनका बिटवाइज़ क्रम संख्यात्मक परिमाण के बराबर होता है जहाँ परिमाण परिभाषित किया जाता है।
        // परिमाण आमतौर पर NaN मानों पर परिभाषित नहीं होता है, लेकिन IEEE 754 TotalOrder NaN मानों को भी बिटवाइज़ क्रम का पालन करने के लिए परिभाषित करता है।यह डॉक्टर टिप्पणी में समझाया गया आदेश देता है।
        // हालांकि, परिमाण का प्रतिनिधित्व नकारात्मक और सकारात्मक संख्याओं के लिए समान है-केवल साइन बिट अलग है।
        // फ़्लोट्स को हस्ताक्षरित पूर्णांकों के रूप में आसानी से तुलना करने के लिए, हमें ऋणात्मक संख्याओं के मामले में घातांक और मंटिसा बिट्स को फ़्लिप करना होगा।
        // हम संख्याओं को प्रभावी रूप से "two's complement" रूप में परिवर्तित करते हैं।
        //
        // फ्लिपिंग करने के लिए, हम इसके खिलाफ एक मुखौटा और एक्सओआर बनाते हैं।
        // हम नकारात्मक-हस्ताक्षरित मानों से एक "all-ones except for the sign bit" मास्क की शाखा रहित गणना करते हैं: राइट शिफ्टिंग साइन-इन्टीजर को बढ़ाता है, इसलिए हम साइन बिट्स के साथ मास्क को "fill" करते हैं, और फिर एक और शून्य बिट को पुश करने के लिए अहस्ताक्षरित में कनवर्ट करते हैं।
        //
        // सकारात्मक मूल्यों पर, मुखौटा सभी शून्य है, इसलिए यह एक नो-ऑप है।
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// किसी मान को एक निश्चित अंतराल तक प्रतिबंधित करें जब तक कि वह NaN न हो।
    ///
    /// यदि `self`, `max` से बड़ा है, तो `max` लौटाता है, और यदि `self`, `min` से कम है, तो `min` देता है।
    /// अन्यथा यह `self` लौटाता है।
    ///
    /// ध्यान दें कि यह फ़ंक्शन NaN लौटाता है यदि प्रारंभिक मान NaN भी था।
    ///
    /// # Panics
    ///
    /// Panics अगर `min > max`, `min` NaN है, या `max` NaN है।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}