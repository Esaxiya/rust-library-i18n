macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// सबसे छोटा मान जिसे इस पूर्णांक प्रकार द्वारा दर्शाया जा सकता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// सबसे बड़ा मान जिसे इस पूर्णांक प्रकार द्वारा दर्शाया जा सकता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// इस पूर्णांक प्रकार का आकार बिट्स में।
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// किसी दिए गए आधार में स्ट्रिंग स्लाइस को पूर्णांक में कनवर्ट करता है।
        ///
        /// स्ट्रिंग के अंकों के बाद वैकल्पिक `+` चिह्न होने की उम्मीद है।
        ///
        /// अग्रणी और अनुगामी व्हॉट्सएप एक त्रुटि का प्रतिनिधित्व करते हैं।
        /// `radix` के आधार पर अंक इन वर्णों का एक सबसेट हैं:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// यह फ़ंक्शन panics यदि `radix` 2 से 36 की सीमा में नहीं है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` के द्विआधारी प्रतिनिधित्व में इकाइयों की संख्या देता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// `self` के द्विआधारी प्रतिनिधित्व में शून्य की संख्या देता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` के द्विआधारी प्रतिनिधित्व में अग्रणी शून्य की संख्या देता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// `self` के बाइनरी प्रतिनिधित्व में अनुगामी शून्य की संख्या देता है।
        ///
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// `self` के बाइनरी प्रतिनिधित्व में अग्रणी लोगों की संख्या देता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// `self` के द्विआधारी प्रतिनिधित्व में अनुगामी की संख्या देता है।
        ///
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// बिट्स को एक निर्दिष्ट राशि, `n` द्वारा बाईं ओर शिफ्ट करता है, परिणामी पूर्णांक के अंत में काटे गए बिट्स को लपेटता है।
        ///
        ///
        /// कृपया ध्यान दें कि यह `<<` शिफ्टिंग ऑपरेटर के समान ऑपरेशन नहीं है!
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// बिट्स को एक निर्दिष्ट राशि, `n` द्वारा दाईं ओर शिफ्ट करता है, छोटे बिट्स को परिणामी पूर्णांक की शुरुआत में लपेटता है।
        ///
        ///
        /// कृपया ध्यान दें कि यह `>>` शिफ्टिंग ऑपरेटर के समान ऑपरेशन नहीं है!
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// पूर्णांक के बाइट क्रम को उलट देता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// चलो एम= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// पूर्णांक में बिट्स के क्रम को उलट देता है।
        /// कम से कम महत्वपूर्ण बिट सबसे महत्वपूर्ण बिट बन जाता है, दूसरा कम से कम महत्वपूर्ण बिट दूसरा सबसे महत्वपूर्ण बिट बन जाता है, आदि।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// चलो एम= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// एक पूर्णांक को बड़े एंडियन से लक्ष्य की एंडियननेस में कनवर्ट करता है।
        ///
        /// बड़े एंडियन पर यह एक नो-ऑप है।
        /// छोटे एंडियन पर बाइट्स की अदला-बदली की जाती है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// अगर cfg!(target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } अन्य {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// एक पूर्णांक को छोटे एंडियन से लक्ष्य की अंतहीनता में परिवर्तित करता है।
        ///
        /// लिटिल एंडियन पर यह नो-ऑप है।
        /// बड़े एंडियन पर बाइट्स की अदला-बदली की जाती है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// अगर cfg!(target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } अन्य {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// लक्ष्य की अंतहीनता से `self` को बड़े एंडियन में परिवर्तित करता है।
        ///
        /// बड़े एंडियन पर यह एक नो-ऑप है।
        /// छोटे एंडियन पर बाइट्स की अदला-बदली की जाती है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// अगर cfg!(target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } और { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // या न होना?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// लक्ष्य की अंतहीनता से `self` को छोटे एंडियन में परिवर्तित करता है।
        ///
        /// लिटिल एंडियन पर यह नो-ऑप है।
        /// बड़े एंडियन पर बाइट्स की अदला-बदली की जाती है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// अगर cfg!(target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } और { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// पूर्णांक जोड़ की जाँच की।
        /// `self + rhs` की गणना करता है, अतिप्रवाह होने पर `None` लौटाता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// अनियंत्रित पूर्णांक जोड़।`self + rhs` की गणना करता है, यह मानते हुए कि अतिप्रवाह नहीं हो सकता है।
        /// इसका परिणाम अपरिभाषित व्यवहार में होता है जब
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // सुरक्षा: कॉल करने वाले को `unchecked_add` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// पूर्णांक घटाव की जाँच की।
        /// `self - rhs` की गणना करता है, अतिप्रवाह होने पर `None` लौटाता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// अनियंत्रित पूर्णांक घटाव।`self - rhs` की गणना करता है, यह मानते हुए कि अतिप्रवाह नहीं हो सकता है।
        /// इसका परिणाम अपरिभाषित व्यवहार में होता है जब
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // सुरक्षा: कॉल करने वाले को `unchecked_sub` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// पूर्णांक गुणन की जाँच की।
        /// `self * rhs` की गणना करता है, अतिप्रवाह होने पर `None` लौटाता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// अनियंत्रित पूर्णांक गुणन।`self * rhs` की गणना करता है, यह मानते हुए कि अतिप्रवाह नहीं हो सकता है।
        /// इसका परिणाम अपरिभाषित व्यवहार में होता है जब
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // सुरक्षा: कॉल करने वाले को `unchecked_mul` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// पूर्णांक विभाजन की जाँच की।
        /// `self / rhs` की गणना करता है, यदि `rhs == 0` `None` लौटाता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // सुरक्षा: शून्य से div को ऊपर चेक किया गया है और अहस्ताक्षरित प्रकारों का कोई अन्य नहीं है
                // विभाजन के लिए विफलता मोड
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// यूक्लिडियन डिवीजन की जाँच की।
        /// `self.div_euclid(rhs)` की गणना करता है, यदि `rhs == 0` `None` लौटाता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// चेक किया गया पूर्णांक शेष।
        /// `self % rhs` की गणना करता है, यदि `rhs == 0` `None` लौटाता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // सुरक्षा: शून्य से div को ऊपर चेक किया गया है और अहस्ताक्षरित प्रकारों का कोई अन्य नहीं है
                // विभाजन के लिए विफलता मोड
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// यूक्लिडियन मोडुलो की जाँच की।
        /// `self.rem_euclid(rhs)` की गणना करता है, यदि `rhs == 0` `None` लौटाता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// चेक किया गया निषेध।`-self` की गणना करता है, `None` लौटाता है जब तक कि `स्वयं==
        /// 0`.
        ///
        /// ध्यान दें कि किसी भी सकारात्मक पूर्णांक को नकारना अतिप्रवाह होगा।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// चेक की गई शिफ्ट लेफ्ट।
        /// `self << rhs` की गणना करता है, `None` लौटाता है यदि `rhs` `self` में बिट्स की संख्या से बड़ा या उसके बराबर है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// चेक शिफ्ट राइट।
        /// `self >> rhs` की गणना करता है, `None` लौटाता है यदि `rhs` `self` में बिट्स की संख्या से बड़ा या उसके बराबर है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// जाँच घातांक।
        /// `self.pow(exp)` की गणना करता है, अतिप्रवाह होने पर `None` लौटाता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // क्स्प!=0 के बाद से, अंत में क्स्प 1 होना चाहिए।
            // घातांक के अंतिम बिट के साथ अलग से डील करें, क्योंकि बाद में आधार को चुकता करना आवश्यक नहीं है और इससे अनावश्यक अतिप्रवाह हो सकता है।
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// संतृप्त पूर्णांक जोड़।
        /// `self + rhs` की गणना करता है, अतिप्रवाह के बजाय संख्यात्मक सीमा पर संतृप्त होता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// संतृप्त पूर्णांक घटाव।
        /// `self - rhs` की गणना करता है, अतिप्रवाह के बजाय संख्यात्मक सीमा पर संतृप्त होता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// संतृप्त पूर्णांक गुणन।
        /// `self * rhs` की गणना करता है, अतिप्रवाह के बजाय संख्यात्मक सीमा पर संतृप्त होता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// संतृप्त पूर्णांक घातांक।
        /// `self.pow(exp)` की गणना करता है, अतिप्रवाह के बजाय संख्यात्मक सीमा पर संतृप्त होता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// रैपिंग (modular) जोड़।
        /// प्रकार की सीमा के चारों ओर लपेटकर, `self + rhs` की गणना करता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// रैपिंग (modular) घटाव।
        /// प्रकार की सीमा के चारों ओर लपेटकर, `self - rhs` की गणना करता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// रैपिंग (modular) गुणन।
        /// प्रकार की सीमा के चारों ओर लपेटकर, `self * rhs` की गणना करता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// कृपया ध्यान दें कि यह उदाहरण पूर्णांक प्रकारों के बीच साझा किया गया है।
        /// जो बताता है कि यहाँ `u8` का उपयोग क्यों किया जाता है।
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// रैपिंग (modular) डिवीजन।`self / rhs` की गणना करता है।
        /// अहस्ताक्षरित प्रकारों पर लपेटा हुआ विभाजन सिर्फ सामान्य विभाजन है।
        /// कोई रास्ता नहीं लपेटना कभी हो सकता है।
        /// यह फ़ंक्शन मौजूद है, ताकि रैपिंग ऑपरेशंस में सभी परिचालनों का हिसाब लगाया जा सके।
        ///
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// यूक्लिडियन डिवीजन लपेटना।`self.div_euclid(rhs)` की गणना करता है।
        /// अहस्ताक्षरित प्रकारों पर लपेटा हुआ विभाजन सिर्फ सामान्य विभाजन है।
        /// कोई रास्ता नहीं लपेटना कभी हो सकता है।
        /// यह फ़ंक्शन मौजूद है, ताकि रैपिंग ऑपरेशंस में सभी परिचालनों का हिसाब लगाया जा सके।
        /// चूँकि, धनात्मक पूर्णांकों के लिए, विभाजन की सभी सामान्य परिभाषाएँ समान हैं, यह बिल्कुल `self.wrapping_div(rhs)` के बराबर है।
        ///
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// रैपिंग (modular) शेष।`self % rhs` की गणना करता है।
        /// अहस्ताक्षरित प्रकारों पर रैप्ड शेष गणना केवल नियमित शेष गणना है।
        ///
        /// कोई रास्ता नहीं लपेटना कभी हो सकता है।
        /// यह फ़ंक्शन मौजूद है, ताकि रैपिंग ऑपरेशंस में सभी परिचालनों का हिसाब लगाया जा सके।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// यूक्लिडियन मोडुलो लपेटना।`self.rem_euclid(rhs)` की गणना करता है।
        /// अहस्ताक्षरित प्रकारों पर लपेटा हुआ मॉड्यूलो गणना केवल नियमित शेष गणना है।
        /// कोई रास्ता नहीं लपेटना कभी हो सकता है।
        /// यह फ़ंक्शन मौजूद है, ताकि रैपिंग ऑपरेशंस में सभी परिचालनों का हिसाब लगाया जा सके।
        /// चूँकि, धनात्मक पूर्णांकों के लिए, विभाजन की सभी सामान्य परिभाषाएँ समान हैं, यह बिल्कुल `self.wrapping_rem(rhs)` के बराबर है।
        ///
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// रैपिंग (modular) निषेध।
        /// प्रकार की सीमा के चारों ओर लपेटकर, `-self` की गणना करता है।
        ///
        /// चूंकि अहस्ताक्षरित प्रकारों में नकारात्मक समकक्ष नहीं होते हैं, इसलिए इस फ़ंक्शन के सभी एप्लिकेशन रैप हो जाएंगे (`-0` को छोड़कर)।
        /// संबंधित हस्ताक्षरित प्रकार के अधिकतम से छोटे मानों के लिए परिणाम संबंधित हस्ताक्षरित मान को कास्ट करने के समान है।
        ///
        /// कोई भी बड़ा मान `MAX + 1 - (val - MAX - 1)` के बराबर होता है जहां `MAX` संबंधित हस्ताक्षरित प्रकार का अधिकतम होता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// कृपया ध्यान दें कि यह उदाहरण पूर्णांक प्रकारों के बीच साझा किया गया है।
        /// जो बताता है कि यहाँ `i8` का उपयोग क्यों किया जाता है।
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-मुक्त बिटवाइज़ शिफ्ट-लेफ्ट;
        /// `self << mask(rhs)` उत्पन्न करता है, जहां `mask` `rhs` के किसी भी उच्च-आदेश बिट्स को हटा देता है जो बदलाव को प्रकार की बिटविड्थ से अधिक होने का कारण बनता है।
        ///
        /// ध्यान दें कि यह रोटेट-लेफ्ट के समान *नहीं* है;रैपिंग शिफ्ट-लेफ्ट का आरएचएस एलएचएस से दूसरे छोर पर वापस किए जाने वाले बिट्स के बजाय, प्रकार की सीमा तक सीमित है।
        /// आदिम पूर्णांक प्रकार सभी एक [`rotate_left`](Self::rotate_left) फ़ंक्शन को लागू करते हैं, जो हो सकता है कि आप इसके बजाय क्या चाहते हैं।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // सुरक्षा: प्रकार के बिटसाइज़ द्वारा मास्किंग यह सुनिश्चित करता है कि हम शिफ्ट न हों
            // सीमा के बाहर
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-मुक्त बिटवाइज़ शिफ्ट-राइट;
        /// `self >> mask(rhs)` उत्पन्न करता है, जहां `mask` `rhs` के किसी भी उच्च-आदेश बिट्स को हटा देता है जो बदलाव को प्रकार की बिटविड्थ से अधिक होने का कारण बनता है।
        ///
        /// ध्यान दें कि यह रोटेट-राइट के समान *नहीं* है;रैपिंग शिफ्ट-राइट का आरएचएस एलएचएस से दूसरे छोर पर वापस किए जाने वाले बिट्स के बजाय, प्रकार की सीमा तक सीमित है।
        /// आदिम पूर्णांक प्रकार सभी एक [`rotate_right`](Self::rotate_right) फ़ंक्शन को लागू करते हैं, जो हो सकता है कि आप इसके बजाय क्या चाहते हैं।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // सुरक्षा: प्रकार के बिटसाइज़ द्वारा मास्किंग यह सुनिश्चित करता है कि हम शिफ्ट न हों
            // सीमा के बाहर
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// रैपिंग (modular) एक्सपोनेंटिएशन।
        /// प्रकार की सीमा के चारों ओर लपेटकर, `self.pow(exp)` की गणना करता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // क्स्प!=0 के बाद से, अंत में क्स्प 1 होना चाहिए।
            // घातांक के अंतिम बिट के साथ अलग से डील करें, क्योंकि बाद में आधार को चुकता करना आवश्यक नहीं है और इससे अनावश्यक अतिप्रवाह हो सकता है।
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs`. की गणना करता है
        ///
        /// एक बूलियन के साथ जोड़ का एक टपल देता है जो दर्शाता है कि अंकगणित अतिप्रवाह होगा या नहीं।
        /// यदि एक अतिप्रवाह हुआ होता तो लपेटा हुआ मान वापस कर दिया जाता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` की गणना करता है
        ///
        /// एक बूलियन के साथ घटाव का टपल लौटाता है जो दर्शाता है कि अंकगणितीय अतिप्रवाह होगा या नहीं।
        /// यदि एक अतिप्रवाह हुआ होता तो लपेटा हुआ मान वापस कर दिया जाता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` और `rhs` के गुणन की गणना करता है।
        ///
        /// एक बूलियन के साथ गुणन का टपल लौटाता है जो दर्शाता है कि अंकगणितीय अतिप्रवाह होगा या नहीं।
        /// यदि एक अतिप्रवाह हुआ होता तो लपेटा हुआ मान वापस कर दिया जाता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// कृपया ध्यान दें कि यह उदाहरण पूर्णांक प्रकारों के बीच साझा किया गया है।
        /// जो बताता है कि यहाँ `u32` का उपयोग क्यों किया जाता है।
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// जब `self` को `rhs` से विभाजित किया जाता है, तो भाजक की गणना करता है।
        ///
        /// एक बूलियन के साथ भाजक का टपल लौटाता है जो दर्शाता है कि अंकगणितीय अतिप्रवाह होगा या नहीं।
        /// ध्यान दें कि अहस्ताक्षरित पूर्णांकों के लिए अतिप्रवाह कभी नहीं होता है, इसलिए दूसरा मान हमेशा `false` होता है।
        ///
        /// # Panics
        ///
        /// यह फ़ंक्शन panic होगा यदि `rhs` 0 है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// यूक्लिडियन डिवीजन `self.div_euclid(rhs)` के भागफल की गणना करता है।
        ///
        /// एक बूलियन के साथ भाजक का टपल लौटाता है जो दर्शाता है कि अंकगणितीय अतिप्रवाह होगा या नहीं।
        /// ध्यान दें कि अहस्ताक्षरित पूर्णांकों के लिए अतिप्रवाह कभी नहीं होता है, इसलिए दूसरा मान हमेशा `false` होता है।
        /// चूँकि, धनात्मक पूर्णांकों के लिए, विभाजन की सभी सामान्य परिभाषाएँ समान हैं, यह बिल्कुल `self.overflowing_div(rhs)` के बराबर है।
        ///
        ///
        /// # Panics
        ///
        /// यह फ़ंक्शन panic होगा यदि `rhs` 0 है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// शेष की गणना करता है जब `self` को `rhs` से विभाजित किया जाता है।
        ///
        /// एक बूलियन के साथ विभाजित करने के बाद शेष का एक टपल देता है जो दर्शाता है कि अंकगणित अतिप्रवाह होगा या नहीं।
        /// ध्यान दें कि अहस्ताक्षरित पूर्णांकों के लिए अतिप्रवाह कभी नहीं होता है, इसलिए दूसरा मान हमेशा `false` होता है।
        ///
        /// # Panics
        ///
        /// यह फ़ंक्शन panic होगा यदि `rhs` 0 है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// यूक्लिडियन डिवीजन द्वारा शेष `self.rem_euclid(rhs)` की गणना करता है।
        ///
        /// एक बूलियन के साथ विभाजित करने के बाद मॉड्यूलो का एक टपल देता है जो दर्शाता है कि अंकगणित अतिप्रवाह होगा या नहीं।
        /// ध्यान दें कि अहस्ताक्षरित पूर्णांकों के लिए अतिप्रवाह कभी नहीं होता है, इसलिए दूसरा मान हमेशा `false` होता है।
        /// चूँकि, धनात्मक पूर्णांकों के लिए, विभाजन की सभी सामान्य परिभाषाएँ समान हैं, यह संक्रिया बिल्कुल `self.overflowing_rem(rhs)` के बराबर है।
        ///
        ///
        /// # Panics
        ///
        /// यह फ़ंक्शन panic होगा यदि `rhs` 0 है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// अतिप्रवाह फैशन में स्वयं को नकारता है।
        ///
        /// इस अहस्ताक्षरित मान के निषेध का प्रतिनिधित्व करने वाले मान को वापस करने के लिए रैपिंग ऑपरेशंस का उपयोग करके `!self + 1` लौटाता है।
        /// ध्यान दें कि सकारात्मक अहस्ताक्षरित मूल्यों के लिए अतिप्रवाह हमेशा होता है, लेकिन 0 को नकारना अतिप्रवाह नहीं होता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// `rhs` बिट्स द्वारा स्वयं को छोड़ दिया जाता है।
        ///
        /// बूलियन के साथ स्वयं के शिफ्ट किए गए संस्करण का एक टपल देता है जो दर्शाता है कि शिफ्ट मान बिट्स की संख्या से बड़ा या उसके बराबर था।
        /// यदि शिफ्ट मान बहुत बड़ा है, तो मान को (N-1) मास्क किया जाता है, जहां N बिट्स की संख्या है, और इस मान का उपयोग तब शिफ्ट करने के लिए किया जाता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// `rhs` बिट्स द्वारा स्वयं को दाईं ओर शिफ्ट करता है।
        ///
        /// बूलियन के साथ स्वयं के शिफ्ट किए गए संस्करण का एक टपल देता है जो दर्शाता है कि शिफ्ट मान बिट्स की संख्या से बड़ा या उसके बराबर था।
        /// यदि शिफ्ट मान बहुत बड़ा है, तो मान को (N-1) मास्क किया जाता है, जहां N बिट्स की संख्या है, और इस मान का उपयोग तब शिफ्ट करने के लिए किया जाता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// वर्ग द्वारा घातांक का उपयोग करते हुए, स्वयं को `exp` की घात तक बढ़ा देता है।
        ///
        /// एक bool के साथ घातांक का टपल लौटाता है जो दर्शाता है कि कोई अतिप्रवाह हुआ है या नहीं।
        ///
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, सच));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // अतिप्रवाह_मूल के परिणामों को संग्रहीत करने के लिए स्क्रैच स्थान।
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // क्स्प!=0 के बाद से, अंत में क्स्प 1 होना चाहिए।
            // घातांक के अंतिम बिट के साथ अलग से डील करें, क्योंकि बाद में आधार को चुकता करना आवश्यक नहीं है और इससे अनावश्यक अतिप्रवाह हो सकता है।
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// वर्ग द्वारा घातांक का उपयोग करते हुए, स्वयं को `exp` की घात तक बढ़ा देता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // क्स्प!=0 के बाद से, अंत में क्स्प 1 होना चाहिए।
            // घातांक के अंतिम बिट के साथ अलग से डील करें, क्योंकि बाद में आधार को चुकता करना आवश्यक नहीं है और इससे अनावश्यक अतिप्रवाह हो सकता है।
            //
            //
            acc * base
        }

        /// यूक्लिडियन डिवीजन करता है।
        ///
        /// चूँकि, धनात्मक पूर्णांकों के लिए, विभाजन की सभी सामान्य परिभाषाएँ समान हैं, यह बिल्कुल `self / rhs` के बराबर है।
        ///
        ///
        /// # Panics
        ///
        /// यह फ़ंक्शन panic होगा यदि `rhs` 0 है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// `self (mod rhs)` के कम से कम शेषफल की गणना करता है।
        ///
        /// चूँकि, धनात्मक पूर्णांकों के लिए, विभाजन की सभी सामान्य परिभाषाएँ समान हैं, यह बिल्कुल `self % rhs` के बराबर है।
        ///
        ///
        /// # Panics
        ///
        /// यह फ़ंक्शन panic होगा यदि `rhs` 0 है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// कुछ `k` के लिए यदि और केवल यदि `self == 2^k` हो तो `true` लौटाता है।
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // दो की अगली शक्ति से एक कम देता है।
        // (8u8 के लिए दो की अगली शक्ति 8u8 है और 6u8 के लिए यह 8u8 है)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // यह विधि अतिप्रवाह नहीं हो सकती है, क्योंकि `next_power_of_two` अतिप्रवाह मामलों में यह इसके बजाय प्रकार का अधिकतम मान लौटाता है, और 0 के लिए 0 लौटा सकता है।
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // सुरक्षा: क्योंकि `p > 0`, इसमें पूरी तरह से अग्रणी शून्य शामिल नहीं हो सकते।
            // इसका मतलब है कि बदलाव हमेशा इन-बाउंड होता है, और कुछ प्रोसेसर (जैसे कि इंटेल प्री-हैसवेल) में तर्क के गैर-शून्य होने पर अधिक कुशल ctlz इंट्रिनिक्स होता है।
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// `self` से अधिक या उसके बराबर दो की सबसे छोटी घात लौटाता है।
        ///
        /// जब रिटर्न वैल्यू ओवरफ्लो हो जाती है (यानी, टाइप `uN` के लिए `self > (1 << (N-1))`), यह डिबग मोड में panics है और रिटर्न वैल्यू रिलीज मोड में 0 से लिपटी है (एकमात्र स्थिति जिसमें विधि 0 वापस आ सकती है)।
        ///
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// `n` से अधिक या उसके बराबर दो की सबसे छोटी घात लौटाता है।
        /// यदि दो की अगली शक्ति प्रकार के अधिकतम मूल्य से अधिक है, तो `None` वापस आ जाता है, अन्यथा दो की शक्ति `Some` में लिपटी होती है।
        ///
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// `n` से अधिक या उसके बराबर दो की सबसे छोटी घात लौटाता है।
        /// यदि दो की अगली शक्ति प्रकार के अधिकतम मान से अधिक है, तो वापसी मान को `0` में लपेटा जाता है।
        ///
        ///
        /// # Examples
        ///
        /// मूल उपयोग:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// इस पूर्णांक के स्मृति प्रतिनिधित्व को बड़े-एंडियन (network) बाइट क्रम में बाइट सरणी के रूप में लौटाएं।
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// इस पूर्णांक के स्मृति प्रतिनिधित्व को छोटे-एंडियन बाइट क्रम में बाइट सरणी के रूप में लौटाएं।
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// मूल बाइट क्रम में बाइट सरणी के रूप में इस पूर्णांक के स्मृति प्रतिनिधित्व को वापस करें।
        ///
        /// चूंकि लक्ष्य प्लेटफ़ॉर्म की मूल अंतहीनता का उपयोग किया जाता है, पोर्टेबल कोड को इसके बजाय उपयुक्त के रूप में [`to_be_bytes`] या [`to_le_bytes`] का उपयोग करना चाहिए।
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     बाइट्स, अगर cfg!(target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } अन्य {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // सुरक्षा: ध्वनि स्थिरांक क्योंकि पूर्णांक सादे पुराने डेटाटाइप हैं इसलिए हम हमेशा कर सकते हैं
        // उन्हें बाइट्स के सरणियों में स्थानांतरित करें
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // सुरक्षा: पूर्णांक सादे पुराने डेटाटाइप हैं इसलिए हम उन्हें हमेशा ट्रांसम्यूट कर सकते हैं
            // बाइट्स की सरणियाँ
            unsafe { mem::transmute(self) }
        }

        /// मूल बाइट क्रम में बाइट सरणी के रूप में इस पूर्णांक के स्मृति प्रतिनिधित्व को वापस करें।
        ///
        ///
        /// [`to_ne_bytes`] जब भी संभव हो इस पर प्राथमिकता दी जानी चाहिए।
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// लेट बाइट्स= num.as_ne_bytes();
        /// assert_eq!(
        ///     बाइट्स, अगर cfg!(target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } अन्य {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // सुरक्षा: पूर्णांक सादे पुराने डेटाटाइप हैं इसलिए हम उन्हें हमेशा ट्रांसम्यूट कर सकते हैं
            // बाइट्स की सरणियाँ
            unsafe { &*(self as *const Self as *const _) }
        }

        /// बड़े एंडियन में बाइट सरणी के रूप में इसके प्रतिनिधित्व से एक देशी एंडियन पूर्णांक मान बनाएं।
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto का उपयोग करें;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * इनपुट=आराम;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// छोटे एंडियन में बाइट सरणी के रूप में इसके प्रतिनिधित्व से एक देशी एंडियन पूर्णांक मान बनाएं।
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto का उपयोग करें;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * इनपुट=आराम;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// देशी एंडियननेस में बाइट सरणी के रूप में इसके मेमोरी प्रतिनिधित्व से एक देशी एंडियन पूर्णांक मान बनाएं।
        ///
        /// चूंकि लक्ष्य प्लेटफ़ॉर्म की मूल अंतहीनता का उपयोग किया जाता है, पोर्टेबल कोड संभवतः इसके बजाय [`from_be_bytes`] या [`from_le_bytes`] का उपयोग करना चाहता है।
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } अन्य {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto का उपयोग करें;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * इनपुट=आराम;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // सुरक्षा: ध्वनि स्थिरांक क्योंकि पूर्णांक सादे पुराने डेटाटाइप हैं इसलिए हम हमेशा कर सकते हैं
        // उन्हें प्रसारित करें
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // सुरक्षा: पूर्णांक सादे पुराने डेटाटाइप हैं इसलिए हम उन्हें हमेशा ट्रांसमिट कर सकते हैं
            unsafe { mem::transmute(bytes) }
        }

        /// नए कोड का उपयोग करना पसंद करना चाहिए
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// सबसे छोटा मान देता है जिसे इस पूर्णांक प्रकार द्वारा दर्शाया जा सकता है।
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// नए कोड का उपयोग करना पसंद करना चाहिए
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// सबसे बड़ा मान देता है जिसे इस पूर्णांक प्रकार द्वारा दर्शाया जा सकता है।
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}