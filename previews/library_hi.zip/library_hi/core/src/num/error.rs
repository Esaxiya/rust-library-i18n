//! अभिन्न प्रकारों में रूपांतरण के लिए त्रुटि प्रकार।

use crate::convert::Infallible;
use crate::fmt;

/// त्रुटि प्रकार लौटाया गया जब एक चेक किया गया अभिन्न प्रकार रूपांतरण विफल हो जाता है।
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // यह सुनिश्चित करने के लिए जबरदस्ती करने के बजाय मिलान करें कि ऊपर `From<Infallible> for TryFromIntError` जैसा कोड काम करता रहेगा जब `Infallible` `!` का उपनाम बन जाएगा।
        //
        //
        match never {}
    }
}

/// एक त्रुटि जो एक पूर्णांक को पार्स करते समय वापस की जा सकती है।
///
/// इस त्रुटि का उपयोग [`i8::from_str_radix`] जैसे आदिम पूर्णांक प्रकारों पर `from_str_radix()` फ़ंक्शन के लिए त्रुटि प्रकार के रूप में किया जाता है।
///
/// # संभावित कारण
///
/// अन्य कारणों में, `ParseIntError` को स्ट्रिंग में अग्रणी या अनुगामी व्हाइटस्पेस के कारण फेंका जा सकता है, उदाहरण के लिए, जब इसे मानक इनपुट से प्राप्त किया जाता है।
///
/// [`str::trim()`] विधि का उपयोग यह सुनिश्चित करता है कि पार्सिंग से पहले कोई खाली स्थान न रहे।
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum विभिन्न प्रकार की त्रुटियों को संग्रहीत करने के लिए जो एक पूर्णांक को विफल करने का कारण बन सकता है।
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// पार्स किया जा रहा मान खाली है।
    ///
    /// अन्य कारणों के अलावा, इस प्रकार का निर्माण एक खाली स्ट्रिंग को पार्स करते समय किया जाएगा।
    Empty,
    /// इसके संदर्भ में एक अमान्य अंक है।
    ///
    /// अन्य कारणों के अलावा, गैर-ASCII चार वाले स्ट्रिंग को पार्स करते समय इस प्रकार का निर्माण किया जाएगा।
    ///
    /// इस प्रकार का निर्माण तब भी किया जाता है जब एक `+` या `-` एक स्ट्रिंग के भीतर या तो अपने आप में या किसी संख्या के बीच में खो जाता है।
    ///
    ///
    InvalidDigit,
    /// लक्ष्य पूर्णांक प्रकार में संग्रहीत करने के लिए पूर्णांक बहुत बड़ा है।
    PosOverflow,
    /// लक्ष्य पूर्णांक प्रकार में संग्रहीत करने के लिए पूर्णांक बहुत छोटा है।
    NegOverflow,
    /// मान शून्य था
    ///
    /// यह संस्करण तब उत्सर्जित होगा जब पार्सिंग स्ट्रिंग का मान शून्य होगा, जो गैर-शून्य प्रकारों के लिए अवैध होगा।
    ///
    Zero,
}

impl ParseIntError {
    /// एक पूर्णांक को पार्स करने में विफल होने का विस्तृत कारण आउटपुट करता है।
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}