//! पूर्णांक की परिभाषाएँ जो शून्य के बराबर नहीं जानी जाती हैं।

use crate::fmt;
use crate::ops::{BitOr, BitOrAssign, Div, Rem};
use crate::str::FromStr;

use super::from_str_radix;
use super::{IntErrorKind, ParseIntError};
use crate::intrinsics;

macro_rules! impl_nonzero_fmt {
    ( #[$stability: meta] ( $( $Trait: ident ),+ ) for $Ty: ident ) => {
        $(
            #[$stability]
            impl fmt::$Trait for $Ty {
                #[inline]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    self.get().fmt(f)
                }
            }
        )+
    }
}

macro_rules! nonzero_integers {
    ( $( #[$stability: meta] $Ty: ident($Int: ty); )+ ) => {
        $(
            /// एक पूर्णांक जिसे शून्य के बराबर नहीं जाना जाता है।
            ///
            /// यह कुछ मेमोरी लेआउट ऑप्टिमाइजेशन को सक्षम बनाता है।
            #[doc = concat!("For example, `Option<", stringify!($Ty), ">` is the same size as `", stringify!($Int), "`:")]
            /// ```rust
            /// std::mem::size_of का उपयोग करें;
            #[doc = concat!("assert_eq!(size_of::<Option<core::num::", stringify!($Ty), ">>(), size_of::<", stringify!($Int), ">());")]
            /// ```
            #[$stability]
            #[derive(Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
            #[repr(transparent)]
            #[rustc_layout_scalar_valid_range_start(1)]
            #[rustc_nonnull_optimization_guaranteed]
            pub struct $Ty($Int);

            impl $Ty {
                /// मान की जाँच किए बिना एक गैर-शून्य बनाता है।
                ///
                /// # Safety
                ///
                /// मान शून्य नहीं होना चाहिए।
                #[$stability]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                #[inline]
                pub const unsafe fn new_unchecked(n: $Int) -> Self {
                    // सुरक्षा: यह कॉलर द्वारा सुरक्षित होने की गारंटी है।
                    unsafe { Self(n) }
                }

                /// यदि दिया गया मान शून्य नहीं है, तो एक गैर-शून्य बनाता है।
                #[$stability]
                #[rustc_const_stable(feature = "const_nonzero_int_methods", since = "1.47.0")]
                #[inline]
                pub const fn new(n: $Int) -> Option<Self> {
                    if n != 0 {
                        // सुरक्षा: हमने अभी-अभी जाँच की है कि कहीं कोई `0` तो नहीं है
                        Some(unsafe { Self(n) })
                    } else {
                        None
                    }
                }

                /// मान को एक आदिम प्रकार के रूप में लौटाता है।
                #[$stability]
                #[inline]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                pub const fn get(self) -> $Int {
                    self.0
                }

            }

            #[stable(feature = "from_nonzero", since = "1.31.0")]
            impl From<$Ty> for $Int {
                #[doc = concat!("Converts a `", stringify!($Ty), "` into an `", stringify!($Int), "`")]
                #[inline]
                fn from(nonzero: $Ty) -> Self {
                    nonzero.0
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: Self) -> Self::Output {
                    // सुरक्षा: चूंकि `self` और `rhs` दोनों गैर-शून्य हैं, इसलिए
                    // बिटवाइज़ का परिणाम-या गैर-शून्य होगा।
                    unsafe { $Ty::new_unchecked(self.get() | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Int> for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: $Int) -> Self::Output {
                    // सुरक्षा: चूंकि `self` गैर-शून्य है, इसका परिणाम है
                    // बिटवाइज़-या गैर-शून्य होगा, चाहे `rhs` का मान कुछ भी हो।
                    //
                    unsafe { $Ty::new_unchecked(self.get() | rhs) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Ty> for $Int {
                type Output = $Ty;
                #[inline]
                fn bitor(self, rhs: $Ty) -> Self::Output {
                    // सुरक्षा: चूंकि `rhs` गैर-शून्य है, इसका परिणाम है
                    // बिटवाइज़-या गैर-शून्य होगा, चाहे `self` का मान कुछ भी हो।
                    //
                    unsafe { $Ty::new_unchecked(self | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: Self) {
                    *self = *self | rhs;
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign<$Int> for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: $Int) {
                    *self = *self | rhs;
                }
            }

            impl_nonzero_fmt! {
                #[$stability] (Debug, Display, Binary, Octal, LowerHex, UpperHex) for $Ty
            }
        )+
    }
}

nonzero_integers! {
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU8(u8);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU16(u16);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU32(u32);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU64(u64);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU128(u128);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroUsize(usize);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI8(i8);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI16(i16);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI32(i32);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI64(i64);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI128(i128);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroIsize(isize);
}

macro_rules! from_str_radix_nzint_impl {
    ($($t:ty)*) => {$(
        #[stable(feature = "nonzero_parse", since = "1.35.0")]
        impl FromStr for $t {
            type Err = ParseIntError;
            fn from_str(src: &str) -> Result<Self, Self::Err> {
                Self::new(from_str_radix(src, 10)?)
                    .ok_or(ParseIntError {
                        kind: IntErrorKind::Zero
                    })
            }
        }
    )*}
}

from_str_radix_nzint_impl! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize
NonZeroI8 NonZeroI16 NonZeroI32 NonZeroI64 NonZeroI128 NonZeroIsize }

macro_rules! nonzero_leading_trailing_zeros {
    ( $( $Ty: ident($Uint: ty) , $LeadingTestExpr:expr ;)+ ) => {
        $(
            impl $Ty {
                /// `self` के द्विआधारी प्रतिनिधित्व में अग्रणी शून्य की संख्या देता है।
                ///
                /// कई आर्किटेक्चर पर, यह फ़ंक्शन अंतर्निहित पूर्णांक प्रकार पर `leading_zeros()` से बेहतर प्रदर्शन कर सकता है, क्योंकि शून्य की विशेष हैंडलिंग से बचा जा सकता है।
                ///
                /// # Examples
                ///
                /// मूल उपयोग:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(", stringify!($LeadingTestExpr), ").unwrap();")]
                /// assert_eq!(n.leading_zeros(), 0);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn leading_zeros(self) -> u32 {
                    // सुरक्षा: चूंकि `self` शून्य नहीं हो सकता, इसलिए ctlz_nonzero. पर कॉल करना सुरक्षित है
                    unsafe { intrinsics::ctlz_nonzero(self.0 as $Uint) as u32 }
                }

                /// `self` के बाइनरी प्रतिनिधित्व में अनुगामी शून्य की संख्या देता है।
                ///
                /// कई आर्किटेक्चर पर, यह फ़ंक्शन अंतर्निहित पूर्णांक प्रकार पर `trailing_zeros()` से बेहतर प्रदर्शन कर सकता है, क्योंकि शून्य की विशेष हैंडलिंग से बचा जा सकता है।
                ///
                ///
                /// # Examples
                ///
                /// मूल उपयोग:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(0b0101000).unwrap();")]
                /// assert_eq!(n.trailing_zeros(), 3);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn trailing_zeros(self) -> u32 {
                    // सुरक्षा: चूंकि `self` शून्य नहीं हो सकता, इसलिए cttz_nonzero. पर कॉल करना सुरक्षित है
                    unsafe { intrinsics::cttz_nonzero(self.0 as $Uint) as u32 }
                }

            }
        )+
    }
}

nonzero_leading_trailing_zeros! {
    NonZeroU8(u8), u8::MAX;
    NonZeroU16(u16), u16::MAX;
    NonZeroU32(u32), u32::MAX;
    NonZeroU64(u64), u64::MAX;
    NonZeroU128(u128), u128::MAX;
    NonZeroUsize(usize), usize::MAX;
    NonZeroI8(u8), -1i8;
    NonZeroI16(u16), -1i16;
    NonZeroI32(u32), -1i32;
    NonZeroI64(u64), -1i64;
    NonZeroI128(u128), -1i128;
    NonZeroIsize(usize), -1isize;
}

macro_rules! nonzero_integers_div {
    ( $( $Ty: ident($Int: ty); )+ ) => {
        $(
            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Div<$Ty> for $Int {
                type Output = $Int;
                /// यह ऑपरेशन शून्य की ओर घूमता है, सटीक परिणाम के किसी भी भिन्नात्मक भाग को छोटा करता है, और panic नहीं कर सकता।
                ///
                #[inline]
                fn div(self, other: $Ty) -> $Int {
                    // सुरक्षा: शून्य से div की जाँच की जाती है क्योंकि `other` एक गैर-शून्य है,
                    // और MIN/-1 की जाँच की जाती है क्योंकि `self` एक अहस्ताक्षरित int है।
                    unsafe { crate::intrinsics::unchecked_div(self, other.get()) }
                }
            }

            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Rem<$Ty> for $Int {
                type Output = $Int;
                /// यह ऑपरेशन `n % d == n - (n / d) * d` को संतुष्ट करता है, और panic नहीं कर सकता।
                #[inline]
                fn rem(self, other: $Ty) -> $Int {
                    // सुरक्षा: शून्य से रेम की जाँच की जाती है क्योंकि `other` एक गैर-शून्य है,
                    // और MIN/-1 की जाँच की जाती है क्योंकि `self` एक अहस्ताक्षरित int है।
                    unsafe { crate::intrinsics::unchecked_rem(self, other.get()) }
                }
            }
        )+
    }
}

nonzero_integers_div! {
    NonZeroU8(u8);
    NonZeroU16(u16);
    NonZeroU32(u32);
    NonZeroU64(u64);
    NonZeroU128(u128);
    NonZeroUsize(usize);
}

macro_rules! nonzero_unsigned_is_power_of_two {
    ( $( $Ty: ident )+ ) => {
        $(
            impl $Ty {

                /// कुछ `k` के लिए यदि और केवल यदि `self == (1 << k)` हो तो `true` लौटाता है।
                ///
                /// कई आर्किटेक्चर पर, यह फ़ंक्शन अंतर्निहित पूर्णांक प्रकार पर `is_power_of_two()` से बेहतर प्रदर्शन कर सकता है, क्योंकि शून्य की विशेष हैंडलिंग से बचा जा सकता है।
                ///
                ///
                /// # Examples
                ///
                /// मूल उपयोग:
                ///
                /// ```
                /// #![feature(nonzero_is_power_of_two)]
                ///
                #[doc = concat!("let eight = std::num::", stringify!($Ty), "::new(8).unwrap();")]
                /// assert!(eight.is_power_of_two());
                #[doc = concat!("let ten = std::num::", stringify!($Ty), "::new(10).unwrap();")]
                /// assert!(!ten.is_power_of_two());
                /// ```
                #[unstable(feature = "nonzero_is_power_of_two", issue = "81106")]
                #[inline]
                pub const fn is_power_of_two(self) -> bool {
                    // LLVM 11 यहां देखे गए कार्यान्वयन के लिए `unchecked_sub(x, 1) & x == 0` को सामान्य करता है।
                    // मूल x86-64 लक्ष्य पर, यह शून्य जांच के लिए 3 निर्देश सहेजता है।
                    // x86_64 पर BMI1 के साथ, गैर-शून्य होने से यह `BLSR` को कोडजेन देता है, जो अंतर्निहित पूर्णांक प्रकार पर `POPCNT` कार्यान्वयन की तुलना में एक निर्देश बचाता है।
                    //

                    intrinsics::ctpop(self.get()) < 2
                }

            }
        )+
    }
}

nonzero_unsigned_is_power_of_two! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize }