#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// [Unicode](http://www.unicode.org/) का संस्करण जिस पर `char` और `str` विधियों के यूनिकोड भाग आधारित हैं।
///
/// यूनिकोड के नए संस्करण नियमित रूप से जारी किए जाते हैं और बाद में यूनिकोड के आधार पर मानक पुस्तकालय में सभी विधियों को अद्यतन किया जाता है।
/// इसलिए कुछ `char` और `str` विधियों का व्यवहार और इस स्थिरांक का मान समय के साथ बदलता रहता है।
/// इसे एक ब्रेकिंग बदलाव *नहीं* माना जाता है।
///
/// संस्करण क्रमांकन योजना को [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) में समझाया गया है।
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// liballoc में उपयोग के लिए, libstd में पुन: निर्यात नहीं किया गया।
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;