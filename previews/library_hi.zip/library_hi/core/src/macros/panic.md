Panics वर्तमान धागा।

यह प्रोग्राम को तुरंत समाप्त करने और प्रोग्राम के कॉलर को फीडबैक प्रदान करने की अनुमति देता है।
`panic!` जब कोई प्रोग्राम अप्राप्य स्थिति में पहुंचता है तो इसका उपयोग किया जाना चाहिए।

यह मैक्रो उदाहरण कोड और परीक्षणों में स्थितियों पर जोर देने का सही तरीका है।
`panic!` [`Option`][ounwrap] और [`Result`][runwrap] एनम दोनों की `unwrap` विधि के साथ निकटता से जुड़ा हुआ है।
दोनों कार्यान्वयन `panic!` को कॉल करते हैं जब वे [`None`] या [`Err`] वेरिएंट पर सेट होते हैं।

`panic!()` का उपयोग करते समय आप एक स्ट्रिंग पेलोड निर्दिष्ट कर सकते हैं, जिसे [`format!`] सिंटैक्स का उपयोग करके बनाया गया है।
panic को कॉलिंग Rust थ्रेड में इंजेक्ट करते समय उस पेलोड का उपयोग किया जाता है, जिससे थ्रेड पूरी तरह से panic हो जाता है।

डिफ़ॉल्ट `std` hook का व्यवहार, अर्थात
कोड जो panic लागू होने के बाद सीधे चलता है, `panic!()` कॉल की file/line/column जानकारी के साथ संदेश पेलोड को `stderr` पर प्रिंट करना है।

आप [`std::panic::set_hook()`] का उपयोग करके panic hook को ओवरराइड कर सकते हैं।
hook के अंदर एक panic को `&dyn Any + Send` के रूप में एक्सेस किया जा सकता है, जिसमें नियमित `panic!()` इनवोकेशन के लिए या तो `&str` या `String` होता है।
किसी अन्य प्रकार के मान के साथ panic के लिए, [`panic_any`] का उपयोग किया जा सकता है।

[`Result`] Enum अक्सर `panic!` मैक्रो का उपयोग करने की तुलना में त्रुटियों से उबरने के लिए एक बेहतर समाधान है।
इस मैक्रो का उपयोग बाहरी स्रोतों जैसे गलत मानों का उपयोग करके आगे बढ़ने से बचने के लिए किया जाना चाहिए।
त्रुटि प्रबंधन के बारे में विस्तृत जानकारी [book] में मिलती है।

संकलन के दौरान त्रुटियाँ उठाने के लिए मैक्रो [`compile_error!`] भी देखें।

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# वर्तमान कार्यान्वयन

यदि मुख्य थ्रेड panics यह आपके सभी थ्रेड्स को समाप्त कर देगा और आपके प्रोग्राम को कोड `101` के साथ समाप्त कर देगा।

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





