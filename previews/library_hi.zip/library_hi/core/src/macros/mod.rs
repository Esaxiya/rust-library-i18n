#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // कॉलर के संस्करण के आधार पर या तो `$crate::panic::panic_2015` या `$crate::panic::panic_2021` तक फैलता है।
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// दावा करता है कि दो व्यंजक एक दूसरे के बराबर हैं ([`PartialEq`] का प्रयोग करके)।
///
/// panic पर, यह मैक्रो व्यंजकों के मानों को उनके डिबग अभ्यावेदन के साथ प्रिंट करेगा।
///
///
/// [`assert!`] की तरह, इस मैक्रो का दूसरा रूप है, जहां एक कस्टम panic संदेश प्रदान किया जा सकता है।
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // नीचे दिए गए पुनर्उधार जानबूझकर किए गए हैं।
                    // उनके बिना, उधार के लिए स्टैक स्लॉट को मूल्यों की तुलना करने से पहले ही आरंभ किया जाता है, जिससे ध्यान देने योग्य धीमा हो जाता है।
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // नीचे दिए गए पुनर्उधार जानबूझकर किए गए हैं।
                    // उनके बिना, उधार के लिए स्टैक स्लॉट को मूल्यों की तुलना करने से पहले ही आरंभ किया जाता है, जिससे ध्यान देने योग्य धीमा हो जाता है।
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// दावा करता है कि दो व्यंजक एक दूसरे के बराबर नहीं हैं ([`PartialEq`] का प्रयोग करके)।
///
/// panic पर, यह मैक्रो व्यंजकों के मानों को उनके डिबग अभ्यावेदन के साथ प्रिंट करेगा।
///
///
/// [`assert!`] की तरह, इस मैक्रो का दूसरा रूप है, जहां एक कस्टम panic संदेश प्रदान किया जा सकता है।
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // नीचे दिए गए पुनर्उधार जानबूझकर किए गए हैं।
                    // उनके बिना, उधार के लिए स्टैक स्लॉट को मूल्यों की तुलना करने से पहले ही आरंभ किया जाता है, जिससे ध्यान देने योग्य धीमा हो जाता है।
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // नीचे दिए गए पुनर्उधार जानबूझकर किए गए हैं।
                    // उनके बिना, उधार के लिए स्टैक स्लॉट को मूल्यों की तुलना करने से पहले ही आरंभ किया जाता है, जिससे ध्यान देने योग्य धीमा हो जाता है।
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// दावा करता है कि रनटाइम पर एक बूलियन अभिव्यक्ति `true` है।
///
/// यदि प्रदान की गई अभिव्यक्ति का मूल्यांकन रनटाइम पर `true` पर नहीं किया जा सकता है, तो यह [`panic!`] मैक्रो का आह्वान करेगा।
///
/// [`assert!`] की तरह, इस मैक्रो का दूसरा संस्करण भी है, जहां एक कस्टम panic संदेश प्रदान किया जा सकता है।
///
/// # Uses
///
/// [`assert!`] के विपरीत, `debug_assert!` स्टेटमेंट केवल डिफ़ॉल्ट रूप से गैर-अनुकूलित बिल्ड में सक्षम होते हैं।
/// एक अनुकूलित बिल्ड `debug_assert!` स्टेटमेंट को तब तक निष्पादित नहीं करेगा जब तक कि `-C debug-assertions` को कंपाइलर को पास नहीं किया जाता है।
/// यह `debug_assert!` को उन चेकों के लिए उपयोगी बनाता है जो रिलीज बिल्ड में उपस्थित होने के लिए बहुत महंगे हैं लेकिन विकास के दौरान सहायक हो सकते हैं।
/// `debug_assert!` के विस्तार का परिणाम हमेशा टाइप चेक किया जाता है।
///
/// एक अनियंत्रित अभिकथन एक असंगत स्थिति में एक कार्यक्रम को चालू रखने की अनुमति देता है, जिसके अप्रत्याशित परिणाम हो सकते हैं लेकिन जब तक यह केवल सुरक्षित कोड में होता है, तब तक यह असुरक्षितता का परिचय नहीं देता है।
///
/// हालाँकि, अभिकथन की प्रदर्शन लागत सामान्य रूप से मापने योग्य नहीं है।
/// इस प्रकार [`assert!`] को `debug_assert!` से बदलने को केवल पूरी तरह से प्रोफाइलिंग के बाद ही प्रोत्साहित किया जाता है, और इससे भी महत्वपूर्ण बात यह है कि केवल सुरक्षित कोड में!
///
/// # Examples
///
/// ```
/// // इन अभिकथनों के लिए panic संदेश दिए गए व्यंजक का कठोर मान है।
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // एक बहुत ही सरल कार्य
/// debug_assert!(some_expensive_computation());
///
/// // एक कस्टम संदेश के साथ जोर दें
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// दावा करता है कि दो भाव एक दूसरे के बराबर हैं।
///
/// panic पर, यह मैक्रो व्यंजकों के मानों को उनके डिबग अभ्यावेदन के साथ प्रिंट करेगा।
///
/// [`assert_eq!`] के विपरीत, `debug_assert_eq!` स्टेटमेंट केवल डिफ़ॉल्ट रूप से गैर-अनुकूलित बिल्ड में सक्षम होते हैं।
/// एक अनुकूलित बिल्ड `debug_assert_eq!` स्टेटमेंट को तब तक निष्पादित नहीं करेगा जब तक कि `-C debug-assertions` को कंपाइलर को पास नहीं किया जाता है।
/// यह `debug_assert_eq!` को उन चेकों के लिए उपयोगी बनाता है जो रिलीज बिल्ड में उपस्थित होने के लिए बहुत महंगे हैं लेकिन विकास के दौरान सहायक हो सकते हैं।
///
/// `debug_assert_eq!` के विस्तार का परिणाम हमेशा टाइप चेक किया जाता है।
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// दावा करता है कि दो व्यंजक एक दूसरे के बराबर नहीं हैं।
///
/// panic पर, यह मैक्रो व्यंजकों के मानों को उनके डिबग अभ्यावेदन के साथ प्रिंट करेगा।
///
/// [`assert_ne!`] के विपरीत, `debug_assert_ne!` स्टेटमेंट केवल डिफ़ॉल्ट रूप से गैर-अनुकूलित बिल्ड में सक्षम होते हैं।
/// एक अनुकूलित बिल्ड `debug_assert_ne!` स्टेटमेंट को तब तक निष्पादित नहीं करेगा जब तक कि `-C debug-assertions` को कंपाइलर को पास नहीं किया जाता है।
/// यह `debug_assert_ne!` को उन चेकों के लिए उपयोगी बनाता है जो रिलीज बिल्ड में उपस्थित होने के लिए बहुत महंगे हैं लेकिन विकास के दौरान सहायक हो सकते हैं।
///
/// `debug_assert_ne!` के विस्तार का परिणाम हमेशा टाइप चेक किया जाता है।
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// लौटाता है कि क्या दिया गया व्यंजक दिए गए किसी भी पैटर्न से मेल खाता है।
///
/// `match` एक्सप्रेशन की तरह, पैटर्न को वैकल्पिक रूप से `if` और एक गार्ड एक्सप्रेशन का अनुसरण किया जा सकता है जिसकी पैटर्न से बंधे नामों तक पहुंच है।
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// किसी परिणाम को खोल देता है या उसकी त्रुटि का प्रचार करता है।
///
/// `?` ऑपरेटर को `try!` को बदलने के लिए जोड़ा गया था और इसके बजाय इसका उपयोग किया जाना चाहिए।
/// इसके अलावा, `try` Rust 2018 में एक आरक्षित शब्द है, इसलिए यदि आपको इसका उपयोग करना है, तो आपको [raw-identifier syntax][ris] का उपयोग करना होगा: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` दिए गए [`Result`] से मेल खाता है।`Ok` वैरिएंट के मामले में, एक्सप्रेशन में रैप्ड वैल्यू का मान होता है।
///
/// `Err` संस्करण के मामले में, यह आंतरिक त्रुटि को पुनः प्राप्त करता है।`try!` तब `From` का उपयोग करके रूपांतरण करता है।
/// यह विशेष त्रुटियों और अधिक सामान्य त्रुटियों के बीच स्वचालित रूपांतरण प्रदान करता है।
/// परिणामस्वरूप त्रुटि तुरंत वापस कर दी जाती है।
///
/// जल्दी वापसी के कारण, `try!` का उपयोग केवल उन कार्यों में किया जा सकता है जो [`Result`] लौटाते हैं।
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // त्वरित वापसी त्रुटियों का पसंदीदा तरीका
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // त्वरित वापसी त्रुटियों की पिछली विधि
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // यह इसके बराबर है:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// स्वरूपित डेटा को बफर में लिखता है।
///
/// यह मैक्रो एक 'writer', एक प्रारूप स्ट्रिंग और तर्कों की सूची को स्वीकार करता है।
/// तर्कों को निर्दिष्ट प्रारूप स्ट्रिंग के अनुसार स्वरूपित किया जाएगा और परिणाम लेखक को दिया जाएगा।
/// लेखक `write_fmt` पद्धति के साथ कोई भी मान हो सकता है;आम तौर पर यह [`fmt::Write`] या [`io::Write`] trait के कार्यान्वयन से आता है।
/// मैक्रो जो कुछ भी `write_fmt` विधि लौटाता है;आमतौर पर एक [`fmt::Result`], या एक [`io::Result`]।
///
/// प्रारूप स्ट्रिंग सिंटैक्स के बारे में अधिक जानकारी के लिए [`std::fmt`] देखें।
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// एक मॉड्यूल `std::fmt::Write` और `std::io::Write` दोनों को आयात कर सकता है और या तो लागू होने वाली वस्तुओं पर `write!` को कॉल कर सकता है, क्योंकि ऑब्जेक्ट आमतौर पर दोनों को लागू नहीं करते हैं।
///
/// हालाँकि, मॉड्यूल को traits योग्य आयात करना चाहिए ताकि उनके नाम विरोध न करें:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt. का उपयोग करता है
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt. का उपयोग करता है
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: इस मैक्रो का उपयोग `no_std` सेटअप में भी किया जा सकता है।
/// `no_std` सेटअप में आप घटकों के कार्यान्वयन विवरण के लिए जिम्मेदार होते हैं।
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// स्वरूपित डेटा को एक बफर में लिखें, जिसमें एक नई पंक्ति संलग्न हो।
///
/// सभी प्लेटफार्मों पर, नई लाइन केवल LINE FEED वर्ण (`\n`/`U+000A`) है (कोई अतिरिक्त CARRIAGE RETURN (`\r`/`U+000D`) नहीं।
///
/// अधिक जानकारी के लिए, [`write!`] देखें।प्रारूप स्ट्रिंग सिंटैक्स की जानकारी के लिए, [`std::fmt`] देखें।
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// एक मॉड्यूल `std::fmt::Write` और `std::io::Write` दोनों को आयात कर सकता है और या तो लागू होने वाली वस्तुओं पर `write!` को कॉल कर सकता है, क्योंकि ऑब्जेक्ट आमतौर पर दोनों को लागू नहीं करते हैं।
/// हालाँकि, मॉड्यूल को traits योग्य आयात करना चाहिए ताकि उनके नाम विरोध न करें:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt. का उपयोग करता है
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt. का उपयोग करता है
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// अगम्य कोड इंगित करता है।
///
/// यह किसी भी समय उपयोगी होता है जब संकलक यह निर्धारित नहीं कर सकता कि कुछ कोड पहुंच योग्य नहीं है।उदाहरण के लिए:
///
/// * गार्ड शर्तों के साथ हथियारों का मिलान करें।
/// * लूप जो गतिशील रूप से समाप्त होते हैं।
/// * इटरेटर जो गतिशील रूप से समाप्त होते हैं।
///
/// यदि यह निर्धारण कि कोड पहुंच योग्य नहीं है, गलत साबित होता है, तो प्रोग्राम तुरंत [`panic!`] के साथ समाप्त हो जाता है।
///
/// इस मैक्रो का असुरक्षित समकक्ष [`unreachable_unchecked`] फ़ंक्शन है, जो कोड तक पहुंचने पर अपरिभाषित व्यवहार का कारण बनेगा।
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// यह हमेशा [`panic!`] होगा।
///
/// # Examples
///
/// हथियारों का मिलान करें:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // अगर टिप्पणी की गई तो संकलन त्रुटि
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 के सबसे खराब कार्यान्वयनों में से एक one
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" के संदेश से घबराकर बिना क्रियान्वित कोड को इंगित करता है।
///
/// यह आपके कोड को टाइप-चेक करने की अनुमति देता है, जो उपयोगी है यदि आप trait को प्रोटोटाइप या कार्यान्वित कर रहे हैं जिसके लिए कई विधियों की आवश्यकता होती है जिन्हें आप सभी का उपयोग करने की योजना नहीं बनाते हैं।
///
/// `unimplemented!` और [`todo!`] के बीच अंतर यह है कि `todo!` बाद में कार्यक्षमता को लागू करने का इरादा बताता है और संदेश "not yet implemented" है, `unimplemented!` ऐसा कोई दावा नहीं करता है।
/// इसका संदेश "not implemented" है।
/// साथ ही कुछ IDE `todo!`s को चिह्नित करेंगे।
///
/// # Panics
///
/// यह हमेशा [`panic!`] होगा क्योंकि `unimplemented!` एक निश्चित, विशिष्ट संदेश के साथ `panic!` के लिए सिर्फ एक शॉर्टहैंड है।
///
/// `panic!` की तरह, इस मैक्रो का कस्टम मान प्रदर्शित करने के लिए दूसरा रूप है।
///
/// # Examples
///
/// मान लें कि हमारे पास trait `Foo` है:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// हम 'MyStruct' के लिए `Foo` को लागू करना चाहते हैं, लेकिन किसी कारण से यह केवल `bar()` फ़ंक्शन को लागू करने के लिए समझ में आता है।
/// `baz()` और `qux()` को अभी भी `Foo` के हमारे कार्यान्वयन में परिभाषित करने की आवश्यकता होगी, लेकिन हम अपने कोड को संकलित करने की अनुमति देने के लिए उनकी परिभाषाओं में `unimplemented!` का उपयोग कर सकते हैं।
///
/// हम अभी भी चाहते हैं कि यदि लागू न किए गए तरीकों तक पहुंच जाए तो हमारा प्रोग्राम चलना बंद हो जाएगा।
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` और `MyStruct` से इसका कोई मतलब नहीं है, इसलिए हमारे यहां कोई तर्क नहीं है।
/////
///         // यह "thread 'main' panicked at 'not implemented'" प्रदर्शित करेगा।
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // हमारे यहाँ कुछ तर्क हैं, हम एक संदेश को लागू नहीं करने के लिए जोड़ सकते हैं!हमारी चूक को प्रदर्शित करने के लिए।
///         // यह प्रदर्शित करेगा: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// अधूरा कोड इंगित करता है।
///
/// यह उपयोगी हो सकता है यदि आप प्रोटोटाइप कर रहे हैं और बस अपना कोड टाइपचेक करना चाहते हैं।
///
/// [`unimplemented!`] और `todo!` के बीच अंतर यह है कि `todo!` बाद में कार्यक्षमता को लागू करने का इरादा बताता है और संदेश "not yet implemented" है, `unimplemented!` ऐसा कोई दावा नहीं करता है।
/// इसका संदेश "not implemented" है।
/// साथ ही कुछ IDE `todo!`s को चिह्नित करेंगे।
///
/// # Panics
///
/// यह हमेशा [`panic!`] होगा।
///
/// # Examples
///
/// यहां कुछ इन-प्रोग्रेस कोड का उदाहरण दिया गया है।हमारे पास trait `Foo` है:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// हम अपने किसी एक प्रकार पर `Foo` लागू करना चाहते हैं, लेकिन हम पहले केवल `bar()` पर भी काम करना चाहते हैं।हमारे कोड को संकलित करने के लिए, हमें `baz()` को लागू करने की आवश्यकता है, इसलिए हम `todo!` का उपयोग कर सकते हैं:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // कार्यान्वयन यहाँ जाता है
///     }
///
///     fn baz(&self) {
///         // आइए अभी के लिए baz() को लागू करने के बारे में चिंता न करें
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // हम baz() का उपयोग भी नहीं कर रहे हैं, इसलिए यह ठीक है।
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// अंतर्निहित मैक्रोज़ की परिभाषाएँ।
///
/// अधिकांश मैक्रो गुण (स्थिरता, दृश्यता, आदि) यहां स्रोत कोड से लिए गए हैं, मैक्रो इनपुट को आउटपुट में बदलने वाले विस्तार कार्यों के अपवाद के साथ, वे फ़ंक्शन कंपाइलर द्वारा प्रदान किए जाते हैं।
///
///
pub(crate) mod builtin {

    /// मिलने पर दिए गए त्रुटि संदेश के साथ संकलन विफल हो जाता है।
    ///
    /// इस मैक्रो का उपयोग तब किया जाना चाहिए जब crate गलत स्थितियों के लिए बेहतर त्रुटि संदेश प्रदान करने के लिए सशर्त संकलन रणनीति का उपयोग करता है।
    ///
    /// यह [`panic!`] का कंपाइलर-स्तरीय रूप है, लेकिन *रनटाइम* के बजाय *संकलन* के दौरान एक त्रुटि का उत्सर्जन करता है।
    ///
    /// # Examples
    ///
    /// ऐसे दो उदाहरण मैक्रोज़ और `#[cfg]` परिवेश हैं।
    ///
    /// यदि मैक्रो को अमान्य मान पारित किया जाता है तो बेहतर कंपाइलर त्रुटि का उत्सर्जन करें।
    /// अंतिम branch के बिना, कंपाइलर अभी भी एक त्रुटि का उत्सर्जन करेगा, लेकिन त्रुटि के संदेश में दो मान्य मानों का उल्लेख नहीं होगा।
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// यदि कई सुविधाओं में से कोई एक उपलब्ध नहीं है, तो संकलक त्रुटि का उत्सर्जन करें।
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// अन्य स्ट्रिंग-स्वरूपण मैक्रोज़ के लिए पैरामीटर का निर्माण करता है।
    ///
    /// पारित प्रत्येक अतिरिक्त तर्क के लिए `{}` युक्त एक स्वरूपण स्ट्रिंग अक्षरशः ले कर यह मैक्रो कार्य करता है।
    /// `format_args!` यह सुनिश्चित करने के लिए अतिरिक्त पैरामीटर तैयार करता है कि आउटपुट को एक स्ट्रिंग के रूप में व्याख्या किया जा सकता है और तर्कों को एक प्रकार में विहित करता है।
    /// [`Display`] trait को लागू करने वाला कोई भी मान `format_args!` को पास किया जा सकता है, जैसा कि किसी भी [`Debug`] कार्यान्वयन को स्वरूपण स्ट्रिंग के भीतर `{:?}` में पास किया जा सकता है।
    ///
    ///
    /// यह मैक्रो [`fmt::Arguments`] प्रकार का मान उत्पन्न करता है।उपयोगी पुनर्निर्देशन करने के लिए यह मान [`std::fmt`] के भीतर मैक्रोज़ को पास किया जा सकता है।
    /// अन्य सभी फ़ॉर्मेटिंग मैक्रोज़ ([`format!`], [`write!`], [`println!`], आदि) इसी के माध्यम से प्रॉक्सी किए जाते हैं।
    /// `format_args!`, इसके व्युत्पन्न मैक्रोज़ के विपरीत, ढेर आवंटन से बचा जाता है।
    ///
    /// आप [`fmt::Arguments`] मान का उपयोग कर सकते हैं जो `format_args!` `Debug` और `Display` संदर्भों में लौटाता है जैसा कि नीचे देखा गया है।
    /// उदाहरण से यह भी पता चलता है कि `Debug` और `Display` एक ही चीज़ के प्रारूप हैं: `format_args!` में प्रक्षेपित प्रारूप स्ट्रिंग।
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// अधिक जानकारी के लिए, [`std::fmt`] में दस्तावेज़ देखें।
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` के समान, लेकिन अंत में एक नई पंक्ति जोड़ता है।
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// संकलन समय पर एक पर्यावरण चर का निरीक्षण करता है।
    ///
    /// यह मैक्रो संकलित समय पर नामित पर्यावरण चर के मान तक विस्तारित होगा, जो `&'static str` प्रकार की अभिव्यक्ति देगा।
    ///
    ///
    /// यदि पर्यावरण चर परिभाषित नहीं है, तो एक संकलन त्रुटि उत्सर्जित होगी।
    /// संकलन त्रुटि न निकालने के लिए, इसके बजाय [`option_env!`] मैक्रो का उपयोग करें।
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// आप दूसरे पैरामीटर के रूप में एक स्ट्रिंग पास करके त्रुटि संदेश को अनुकूलित कर सकते हैं:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// यदि `documentation` पर्यावरण चर परिभाषित नहीं है, तो आपको निम्न त्रुटि मिलेगी:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// वैकल्पिक रूप से संकलन समय पर एक पर्यावरण चर का निरीक्षण करता है।
    ///
    /// यदि नामित पर्यावरण चर संकलन समय पर मौजूद है, तो यह `Option<&'static str>` प्रकार की अभिव्यक्ति में विस्तारित होगा जिसका मान पर्यावरण चर के मान का `Some` है।
    /// यदि पर्यावरण चर मौजूद नहीं है, तो इसका विस्तार `None` तक हो जाएगा।
    /// इस प्रकार के बारे में अधिक जानकारी के लिए [`Option<T>`][Option] देखें।
    ///
    /// पर्यावरण चर मौजूद है या नहीं, इस पर ध्यान दिए बिना इस मैक्रो का उपयोग करते समय एक संकलन समय त्रुटि कभी उत्सर्जित नहीं होती है।
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// पहचानकर्ताओं को एक पहचानकर्ता में जोड़ता है।
    ///
    /// यह मैक्रो किसी भी संख्या में अल्पविराम से अलग किए गए पहचानकर्ताओं को लेता है, और उन सभी को एक में जोड़ता है, एक अभिव्यक्ति उत्पन्न करता है जो एक नया पहचानकर्ता है।
    /// ध्यान दें कि स्वच्छता इसे ऐसा बनाती है कि यह मैक्रो स्थानीय चरों को कैप्चर नहीं कर सकता है।
    /// साथ ही, एक सामान्य नियम के रूप में, मैक्रोज़ को केवल आइटम, स्टेटमेंट या एक्सप्रेशन स्थिति में ही अनुमति दी जाती है।
    /// इसका मतलब है कि जब आप इस मैक्रो का उपयोग मौजूदा चर, फ़ंक्शन या मॉड्यूल आदि के संदर्भ में कर सकते हैं, तो आप इसके साथ एक नया परिभाषित नहीं कर सकते।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents!(नया, मज़ा, नाम) { }//इस तरह से प्रयोग करने योग्य नहीं है!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// एक स्थिर स्ट्रिंग स्लाइस में अक्षर को जोड़ता है।
    ///
    /// यह मैक्रो किसी भी संख्या में अल्पविराम से अलग किए गए अक्षर लेता है, जो `&'static str` प्रकार की अभिव्यक्ति प्रदान करता है जो बाएं से दाएं संयोजित सभी अक्षर का प्रतिनिधित्व करता है।
    ///
    ///
    /// समाप्‍त होने के लिए इंटीजर और फ्लोटिंग पॉइंट लिटरल को कड़ा किया जाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// उस लाइन नंबर तक फैलता है जिस पर इसे लागू किया गया था।
    ///
    /// [`column!`] और [`file!`] के साथ, ये मैक्रोज़ डेवलपर्स के लिए स्रोत के भीतर स्थान के बारे में डिबगिंग जानकारी प्रदान करते हैं।
    ///
    /// विस्तारित एक्सप्रेशन में टाइप `u32` है और यह 1-आधारित है, इसलिए प्रत्येक फ़ाइल में पहली पंक्ति 1 का मूल्यांकन करती है, दूसरी से 2, आदि।
    /// यह सामान्य संकलक या लोकप्रिय संपादकों द्वारा त्रुटि संदेशों के अनुरूप है।
    /// लौटाई गई लाइन *जरूरी नहीं* है कि `line!` इनवोकेशन की ही लाइन है, बल्कि `line!` मैक्रो के इनवोकेशन तक जाने वाला पहला मैक्रो इनवोकेशन है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// उस कॉलम संख्या तक विस्तृत हो जाता है जिस पर इसे लागू किया गया था।
    ///
    /// [`line!`] और [`file!`] के साथ, ये मैक्रोज़ डेवलपर्स के लिए स्रोत के भीतर स्थान के बारे में डिबगिंग जानकारी प्रदान करते हैं।
    ///
    /// विस्तारित एक्सप्रेशन में टाइप `u32` है और यह 1-आधारित है, इसलिए प्रत्येक पंक्ति में पहला कॉलम 1 का मूल्यांकन करता है, दूसरे से 2, आदि।
    /// यह सामान्य संकलक या लोकप्रिय संपादकों द्वारा त्रुटि संदेशों के अनुरूप है।
    /// लौटाया गया कॉलम *जरूरी नहीं* कि `column!` इनवोकेशन की ही लाइन है, बल्कि `column!` मैक्रो के इनवोकेशन तक जाने वाला पहला मैक्रो इनवोकेशन है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// उस फ़ाइल नाम का विस्तार करता है जिसमें इसे लागू किया गया था।
    ///
    /// [`line!`] और [`column!`] के साथ, ये मैक्रोज़ डेवलपर्स के लिए स्रोत के भीतर स्थान के बारे में डिबगिंग जानकारी प्रदान करते हैं।
    ///
    /// विस्तारित अभिव्यक्ति में `&'static str` प्रकार है, और लौटाई गई फ़ाइल स्वयं `file!` मैक्रो का आह्वान नहीं है, बल्कि `file!` मैक्रो के आह्वान तक जाने वाला पहला मैक्रो आमंत्रण है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// अपने तर्कों को पुष्ट करता है।
    ///
    /// यह मैक्रो `&'static str` प्रकार की अभिव्यक्ति देगा जो मैक्रो को दिए गए सभी tokens का स्ट्रिंगिफिकेशन है।
    /// मैक्रो इनवोकेशन के सिंटैक्स पर ही कोई प्रतिबंध नहीं लगाया गया है।
    ///
    /// ध्यान दें कि इनपुट tokens के विस्तारित परिणाम future में बदल सकते हैं।यदि आप आउटपुट पर भरोसा करते हैं तो आपको सावधान रहना चाहिए।
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// एक स्ट्रिंग के रूप में एक UTF-8 एन्कोडेड फ़ाइल शामिल है।
    ///
    /// फ़ाइल वर्तमान फ़ाइल के सापेक्ष स्थित है (इसी तरह मॉड्यूल कैसे मिलते हैं)।
    /// प्रदान किए गए पथ को संकलन समय पर प्लेटफ़ॉर्म-विशिष्ट तरीके से व्याख्यायित किया जाता है।
    /// इसलिए, उदाहरण के लिए, बैकस्लैश `\` युक्त Windows पथ वाला एक आमंत्रण Unix पर सही ढंग से संकलित नहीं होगा।
    ///
    ///
    /// यह मैक्रो `&'static str` प्रकार की अभिव्यक्ति देगा जो फ़ाइल की सामग्री है।
    ///
    /// # Examples
    ///
    /// मान लें कि एक ही निर्देशिका में निम्न सामग्री वाली दो फ़ाइलें हैं:
    ///
    /// फ़ाइल 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// फ़ाइल 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' को संकलित करना और परिणामी बाइनरी चलाना "adiós" को प्रिंट करेगा।
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// एक बाइट सरणी के संदर्भ के रूप में एक फ़ाइल शामिल है।
    ///
    /// फ़ाइल वर्तमान फ़ाइल के सापेक्ष स्थित है (इसी तरह मॉड्यूल कैसे मिलते हैं)।
    /// प्रदान किए गए पथ को संकलन समय पर प्लेटफ़ॉर्म-विशिष्ट तरीके से व्याख्यायित किया जाता है।
    /// इसलिए, उदाहरण के लिए, बैकस्लैश `\` युक्त Windows पथ वाला एक आमंत्रण Unix पर सही ढंग से संकलित नहीं होगा।
    ///
    ///
    /// यह मैक्रो `&'static [u8; N]` प्रकार की अभिव्यक्ति देगा जो फ़ाइल की सामग्री है।
    ///
    /// # Examples
    ///
    /// मान लें कि एक ही निर्देशिका में निम्न सामग्री वाली दो फ़ाइलें हैं:
    ///
    /// फ़ाइल 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// फ़ाइल 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' को संकलित करना और परिणामी बाइनरी चलाना "adiós" को प्रिंट करेगा।
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// वर्तमान मॉड्यूल पथ का प्रतिनिधित्व करने वाली एक स्ट्रिंग तक फैलता है।
    ///
    /// वर्तमान मॉड्यूल पथ को crate root तक ले जाने वाले मॉड्यूल के पदानुक्रम के रूप में माना जा सकता है।
    /// लौटाए गए पथ का पहला घटक वर्तमान में संकलित किए जा रहे crat का नाम है।
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// संकलन-समय पर कॉन्फ़िगरेशन फ़्लैग के बूलियन संयोजनों का मूल्यांकन करता है।
    ///
    /// `#[cfg]` विशेषता के अतिरिक्त, यह मैक्रो कॉन्फ़िगरेशन फ़्लैग के बूलियन एक्सप्रेशन मूल्यांकन की अनुमति देने के लिए प्रदान किया जाता है।
    /// यह अक्सर कम डुप्लिकेट कोड की ओर जाता है।
    ///
    /// इस मैक्रो को दिया गया सिंटैक्स [`cfg`] विशेषता के समान सिंटैक्स है।
    ///
    /// `cfg!`, `#[cfg]` के विपरीत, किसी भी कोड को नहीं हटाता है और केवल सही या गलत का मूल्यांकन करता है।
    /// उदाहरण के लिए, if/else एक्सप्रेशन में सभी ब्लॉकों को मान्य होना चाहिए जब `cfg!` का उपयोग शर्त के लिए किया जाता है, भले ही `cfg!` क्या मूल्यांकन कर रहा हो।
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// किसी फ़ाइल को संदर्भ के अनुसार अभिव्यक्ति या आइटम के रूप में पार्स करता है।
    ///
    /// फ़ाइल वर्तमान फ़ाइल के सापेक्ष स्थित है (इसी तरह मॉड्यूल कैसे मिलते हैं)।प्रदान किए गए पथ को संकलन समय पर प्लेटफ़ॉर्म-विशिष्ट तरीके से व्याख्यायित किया जाता है।
    /// इसलिए, उदाहरण के लिए, बैकस्लैश `\` युक्त Windows पथ वाला एक आमंत्रण Unix पर सही ढंग से संकलित नहीं होगा।
    ///
    /// इस मैक्रो का उपयोग करना अक्सर एक बुरा विचार है, क्योंकि यदि फ़ाइल को एक अभिव्यक्ति के रूप में पार्स किया जाता है, तो इसे आसपास के कोड में अस्वच्छ रूप से रखा जाएगा।
    /// इसके परिणामस्वरूप वेरिएबल या फ़ंक्शन फ़ाइल की अपेक्षा से भिन्न हो सकते हैं यदि वेरिएबल या फ़ंक्शन हैं जिनका वर्तमान फ़ाइल में समान नाम है।
    ///
    ///
    /// # Examples
    ///
    /// मान लें कि एक ही निर्देशिका में निम्न सामग्री वाली दो फ़ाइलें हैं:
    ///
    /// फ़ाइल 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// फ़ाइल 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' को संकलित करना और परिणामी बाइनरी चलाना "🙈🙊🙉🙈🙊🙉" को प्रिंट करेगा।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// दावा करता है कि रनटाइम पर एक बूलियन अभिव्यक्ति `true` है।
    ///
    /// यदि प्रदान की गई अभिव्यक्ति का मूल्यांकन रनटाइम पर `true` पर नहीं किया जा सकता है, तो यह [`panic!`] मैक्रो का आह्वान करेगा।
    ///
    /// # Uses
    ///
    /// डिबग और रिलीज़ बिल्ड दोनों में अभिकथन की हमेशा जाँच की जाती है, और इसे अक्षम नहीं किया जा सकता है।
    /// उन दावों के लिए [`debug_assert!`] देखें जो डिफ़ॉल्ट रूप से रिलीज़ बिल्ड में सक्षम नहीं हैं।
    ///
    /// असुरक्षित कोड रन-टाइम इनवेरिएंट को लागू करने के लिए `assert!` पर भरोसा कर सकता है, जिसका उल्लंघन करने पर असुरक्षितता हो सकती है।
    ///
    /// `assert!` के अन्य उपयोग-मामलों में सुरक्षित कोड में रन-टाइम इनवेरिएंट का परीक्षण और लागू करना शामिल है (जिसके उल्लंघन के परिणामस्वरूप असुरक्षितता नहीं हो सकती है)।
    ///
    ///
    /// # कस्टम संदेश
    ///
    /// इस मैक्रो का दूसरा रूप है, जहां एक कस्टम panic संदेश स्वरूपण के लिए तर्कों के साथ या बिना प्रदान किया जा सकता है।
    /// इस फॉर्म के सिंटैक्स के लिए [`std::fmt`] देखें।
    /// प्रारूप तर्कों के रूप में प्रयुक्त अभिव्यक्तियों का मूल्यांकन केवल तभी किया जाएगा जब दावा विफल हो जाए।
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // इन अभिकथनों के लिए panic संदेश दिए गए व्यंजक का कठोर मान है।
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // एक बहुत ही सरल कार्य
    ///
    /// assert!(some_computation());
    ///
    /// // एक कस्टम संदेश के साथ जोर दें
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// इनलाइन असेंबली।
    ///
    /// उपयोग के लिए [unstable book] पढ़ें।
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// एलएलवीएम-शैली इनलाइन असेंबली।
    ///
    /// उपयोग के लिए [unstable book] पढ़ें।
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// मॉड्यूल-स्तरीय इनलाइन असेंबली।
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// प्रिंट्स ने tokens को मानक आउटपुट में पास किया।
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// अन्य मैक्रोज़ को डीबग करने के लिए उपयोग की जाने वाली ट्रेसिंग कार्यक्षमता को सक्षम या अक्षम करता है।
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// एट्रीब्यूट मैक्रो का उपयोग व्युत्पन्न मैक्रोज़ को लागू करने के लिए किया जाता है।
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// किसी फ़ंक्शन को इकाई परीक्षण में बदलने के लिए लागू मैक्रो को एट्रीब्यूट करें।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// किसी फ़ंक्शन को बेंचमार्क परीक्षण में बदलने के लिए एट्रीब्यूट मैक्रो लागू किया गया।
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` और `#[bench]` मैक्रोज़ का कार्यान्वयन विवरण।
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// एक वैश्विक आवंटक के रूप में पंजीकृत करने के लिए एक स्थिर पर लागू मैक्रो विशेषता।
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) भी देखें।
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// उस आइटम को रखता है जिस पर इसे लागू किया जाता है यदि पारित पथ पहुंच योग्य है, और इसे अन्यथा हटा देता है।
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// उस कोड खंड में सभी `#[cfg]` और `#[cfg_attr]` विशेषताओं का विस्तार करता है जिस पर इसे लागू किया गया है।
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` कंपाइलर का अस्थिर कार्यान्वयन विवरण, उपयोग न करें।
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` कंपाइलर का अस्थिर कार्यान्वयन विवरण, उपयोग न करें।
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}