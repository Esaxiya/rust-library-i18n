//! स्लाइस के पुनरावृत्तियों द्वारा उपयोग किए जाने वाले मैक्रोज़।

// इनलाइनिंग is_empty और len एक बड़ा प्रदर्शन अंतर बनाता है
macro_rules! is_empty {
    // जिस तरह से हम ZST इटरेटर की लंबाई को एन्कोड करते हैं, यह ZST और गैर-ZST दोनों के लिए काम करता है।
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// कुछ बाउंड चेक से छुटकारा पाने के लिए (देखें `position`), हम लंबाई की गणना कुछ अप्रत्याशित तरीके से करते हैं।
// ('कोडजेन/स्लाइस-पोजिशन-बाउंड्स-चेक' द्वारा परीक्षण किया गया।)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // हम कभी-कभी असुरक्षित ब्लॉक में उपयोग किए जाते हैं

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // यह _cannot_ `unchecked_sub` का उपयोग करता है क्योंकि हम लंबे ZST स्लाइस इटरेटर की लंबाई का प्रतिनिधित्व करने के लिए रैपिंग पर निर्भर करते हैं।
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // हम जानते हैं कि `start <= end`, इसलिए `offset_from` से बेहतर कर सकता है, जिसे साइन इन करने की आवश्यकता है।
            // यहां उपयुक्त झंडे लगाकर हम एलएलवीएम को यह बता सकते हैं, जो इसे सीमा जांच को हटाने में मदद करता है।
            // सुरक्षा: अपरिवर्तनीय प्रकार से, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // एलएलवीएम को यह भी बताकर कि पॉइंटर्स प्रकार के आकार के सटीक गुणक से अलग हैं, यह `(end - start) < size` के बजाय `len() == 0` को `start == end` तक अनुकूलित कर सकता है।
            //
            // सुरक्षा: अपरिवर्तनीय प्रकार से, पॉइंटर्स को संरेखित किया जाता है ताकि
            //         उनके बीच की दूरी नुकीले आकार की गुणज होनी चाहिए
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` और `IterMut` पुनरावृत्तियों की साझा परिभाषा
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // पहला तत्व लौटाता है और इटरेटर की शुरुआत को 1 से आगे बढ़ाता है।
        // इनलाइन फ़ंक्शन की तुलना में प्रदर्शन में बहुत सुधार करता है।
        // इटरेटर खाली नहीं होना चाहिए।
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // अंतिम तत्व लौटाता है और इटरेटर के अंत को 1 से पीछे की ओर ले जाता है।
        // इनलाइन फ़ंक्शन की तुलना में प्रदर्शन में बहुत सुधार करता है।
        // इटरेटर खाली नहीं होना चाहिए।
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // जब T एक ZST होता है, तो पुनरावर्तक के अंत को `n` द्वारा पीछे की ओर ले जाकर पुनरावर्तक को सिकोड़ता है।
        // `n` `self.len()` से अधिक नहीं होना चाहिए।
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // इटरेटर से एक स्लाइस बनाने के लिए हेल्पर फंक्शन।
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // सुरक्षा: इटरेटर को पॉइंटर के साथ एक स्लाइस से बनाया गया था
                // `self.ptr` और लंबाई `len!(self)`।
                // यह गारंटी देता है कि `from_raw_parts` के लिए सभी आवश्यक शर्तें पूरी होती हैं।
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // `offset` तत्वों द्वारा इटरेटर की शुरुआत को आगे बढ़ाने के लिए हेल्पर फ़ंक्शन, पुरानी शुरुआत को वापस कर देता है।
            //
            // असुरक्षित क्योंकि ऑफ़सेट `self.len()` से अधिक नहीं होना चाहिए।
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // सुरक्षा: कॉलर गारंटी देता है कि `offset` `self.len()` से अधिक नहीं है,
                    // तो यह नया सूचक `self` के अंदर है और इस प्रकार गैर-शून्य होने की गारंटी है।
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // `offset` तत्वों द्वारा इटरेटर के अंत को पीछे की ओर ले जाने के लिए हेल्पर फ़ंक्शन, नया छोर लौटाता है।
            //
            // असुरक्षित क्योंकि ऑफ़सेट `self.len()` से अधिक नहीं होना चाहिए।
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // सुरक्षा: कॉलर गारंटी देता है कि `offset` `self.len()` से अधिक नहीं है,
                    // जो एक `isize` अतिप्रवाह नहीं होने की गारंटी है।
                    // साथ ही, परिणामी सूचक `slice` की सीमा में है, जो `offset` के लिए अन्य आवश्यकताओं को पूरा करता है।
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // स्लाइस के साथ लागू किया जा सकता है, लेकिन यह सीमा जांच से बचा जाता है

                // सुरक्षा: स्लाइस के प्रारंभ सूचक के बाद से `assume` कॉल सुरक्षित हैं
                // गैर-शून्य होना चाहिए, और गैर-जेडएसटी पर स्लाइस में एक गैर-शून्य अंत सूचक भी होना चाहिए।
                // `next_unchecked!` पर कॉल सुरक्षित है क्योंकि हम जांचते हैं कि पहले इटरेटर खाली है या नहीं।
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // यह पुनरावर्तक अब खाली है।
                    if mem::size_of::<T>() == 0 {
                        // हमें इसे इस तरह से करना होगा क्योंकि `ptr` कभी भी 0 नहीं हो सकता है, लेकिन `end` हो सकता है (लपेटने के कारण)।
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // सुरक्षा: यदि T ZST नहीं है तो अंत 0 नहीं हो सकता क्योंकि ptr 0 नहीं है और अंत>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // सुरक्षा: हम सीमा में हैं।`post_inc_start` ZST के लिए भी सही काम करता है।
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // हम डिफ़ॉल्ट कार्यान्वयन को ओवरराइड करते हैं, जो `try_fold` का उपयोग करता है, क्योंकि यह सरल कार्यान्वयन कम LLVM IR उत्पन्न करता है और संकलन के लिए तेज़ है।
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // हम डिफ़ॉल्ट कार्यान्वयन को ओवरराइड करते हैं, जो `try_fold` का उपयोग करता है, क्योंकि यह सरल कार्यान्वयन कम LLVM IR उत्पन्न करता है और संकलन के लिए तेज़ है।
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // हम डिफ़ॉल्ट कार्यान्वयन को ओवरराइड करते हैं, जो `try_fold` का उपयोग करता है, क्योंकि यह सरल कार्यान्वयन कम LLVM IR उत्पन्न करता है और संकलन के लिए तेज़ है।
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // हम डिफ़ॉल्ट कार्यान्वयन को ओवरराइड करते हैं, जो `try_fold` का उपयोग करता है, क्योंकि यह सरल कार्यान्वयन कम LLVM IR उत्पन्न करता है और संकलन के लिए तेज़ है।
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // हम डिफ़ॉल्ट कार्यान्वयन को ओवरराइड करते हैं, जो `try_fold` का उपयोग करता है, क्योंकि यह सरल कार्यान्वयन कम LLVM IR उत्पन्न करता है और संकलन के लिए तेज़ है।
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // हम डिफ़ॉल्ट कार्यान्वयन को ओवरराइड करते हैं, जो `try_fold` का उपयोग करता है, क्योंकि यह सरल कार्यान्वयन कम LLVM IR उत्पन्न करता है और संकलन के लिए तेज़ है।
            // साथ ही, `assume` एक सीमा जांच से बचता है।
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // सुरक्षा: हमें लूप इनवेरिएंट द्वारा सीमा में रहने की गारंटी है:
                        // जब `i >= n`, `self.next()` `None` लौटाता है और लूप टूट जाता है।
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // हम डिफ़ॉल्ट कार्यान्वयन को ओवरराइड करते हैं, जो `try_fold` का उपयोग करता है, क्योंकि यह सरल कार्यान्वयन कम LLVM IR उत्पन्न करता है और संकलन के लिए तेज़ है।
            // साथ ही, `assume` एक सीमा जांच से बचता है।
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // सुरक्षा: `i` `n` से कम होना चाहिए क्योंकि यह `n` से शुरू होता है
                        // और घटती ही जा रही है।
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `i` की सीमा में है
                // अंतर्निहित टुकड़ा, इसलिए `i` एक `isize` को ओवरफ्लो नहीं कर सकता है, और लौटाए गए संदर्भों को स्लाइस के एक तत्व को संदर्भित करने की गारंटी है और इस प्रकार वैध होने की गारंटी है।
                //
                // यह भी ध्यान दें कि कॉलर यह भी गारंटी देता है कि हमें एक ही इंडेक्स के साथ फिर कभी नहीं बुलाया जाता है, और इस सबस्लाइस तक पहुंचने वाली कोई अन्य विधियों को कॉल नहीं किया जाता है, इसलिए यह लौटाए गए संदर्भ के मामले में परिवर्तनीय होने के लिए मान्य है
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // स्लाइस के साथ लागू किया जा सकता है, लेकिन यह सीमा जांच से बचा जाता है

                // सुरक्षा: `assume` कॉल सुरक्षित हैं क्योंकि स्लाइस का प्रारंभ सूचक गैर-शून्य होना चाहिए,
                // और गैर-जेडएसटी पर स्लाइस में एक गैर-शून्य अंत सूचक भी होना चाहिए।
                // `next_back_unchecked!` पर कॉल सुरक्षित है क्योंकि हम जांचते हैं कि पहले इटरेटर खाली है या नहीं।
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // यह पुनरावर्तक अब खाली है।
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // सुरक्षा: हम सीमा में हैं।`pre_dec_end` ZST के लिए भी सही काम करता है।
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}