//! `[T]` के लिए traits की तुलना करें।

use crate::cmp;
use crate::cmp::Ordering::{self, Greater, Less};
use crate::mem;

use super::from_raw_parts;
use super::memchr;

extern "C" {
    /// कॉल कार्यान्वयन memcmp प्रदान करता है।
    ///
    /// डेटा को u8 के रूप में व्याख्यायित करता है।
    ///
    /// बराबर के लिए 0, इससे कम के लिए <0 और इससे अधिक के लिए> 0 देता है।
    ///
    // FIXME(#32610): वापसी प्रकार c_int. होना चाहिए
    fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> PartialEq<[B]> for [A]
where
    A: PartialEq<B>,
{
    fn eq(&self, other: &[B]) -> bool {
        SlicePartialEq::equal(self, other)
    }

    fn ne(&self, other: &[B]) -> bool {
        SlicePartialEq::not_equal(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for [T] {}

/// vectors [lexicographically](Ord#lexicographical-comparison) की तुलना लागू करता है।
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for [T] {
    fn cmp(&self, other: &[T]) -> Ordering {
        SliceOrd::compare(self, other)
    }
}

/// vectors [lexicographically](Ord#lexicographical-comparison) की तुलना लागू करता है।
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for [T] {
    fn partial_cmp(&self, other: &[T]) -> Option<Ordering> {
        SlicePartialOrd::partial_compare(self, other)
    }
}

#[doc(hidden)]
// इंटरमीडिएट trait स्लाइस के PartialEq की विशेषज्ञता के लिए
trait SlicePartialEq<B> {
    fn equal(&self, other: &[B]) -> bool;

    fn not_equal(&self, other: &[B]) -> bool {
        !self.equal(other)
    }
}

// सामान्य टुकड़ा समानता
impl<A, B> SlicePartialEq<B> for [A]
where
    A: PartialEq<B>,
{
    default fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        self.iter().zip(other.iter()).all(|(x, y)| x == y)
    }
}

// जब प्रकार अनुमति देते हैं तो बाइटवाइज समानता के लिए memcmp का उपयोग करें
impl<A, B> SlicePartialEq<B> for [A]
where
    A: BytewiseEquality<B>,
{
    fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        // सुरक्षा: `self` और `other` संदर्भ हैं और इस प्रकार वैध होने की गारंटी है।
        // ऊपर समान आकार के लिए दो स्लाइसों की जाँच की गई है।
        unsafe {
            let size = mem::size_of_val(self);
            memcmp(self.as_ptr() as *const u8, other.as_ptr() as *const u8, size) == 0
        }
    }
}

#[doc(hidden)]
// स्लाइस के पार्टियलऑर्ड की विशेषज्ञता के लिए मध्यवर्ती trait
trait SlicePartialOrd: Sized {
    fn partial_compare(left: &[Self], right: &[Self]) -> Option<Ordering>;
}

impl<A: PartialOrd> SlicePartialOrd for A {
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        let l = cmp::min(left.len(), right.len());

        // कंपाइलर में बाउंड चेक एलिमिनेशन को सक्षम करने के लिए स्लाइस टू लूप इटरेशन रेंज
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].partial_cmp(&rhs[i]) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }

        left.len().partial_cmp(&right.len())
    }
}

// यही वह अर्थ है जो हम चाहते हैं।दुर्भाग्य से यह आवाज नहीं है।
// `partial_ord_slice.rs` देखें।
/*
impl<A> SlicePartialOrd for A
where
    A: Ord,
{
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}
*/

impl<A: AlwaysApplicableOrd> SlicePartialOrd for A {
    fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}

#[rustc_specialization_trait]
trait AlwaysApplicableOrd: SliceOrd + Ord {}

macro_rules! always_applicable_ord {
    ($([$($p:tt)*] $t:ty,)*) => {
        $(impl<$($p)*> AlwaysApplicableOrd for $t {})*
    }
}

always_applicable_ord! {
    [] u8, [] u16, [] u32, [] u64, [] u128, [] usize,
    [] i8, [] i16, [] i32, [] i64, [] i128, [] isize,
    [] bool, [] char,
    [T: ?Sized] *const T, [T: ?Sized] *mut T,
    [T: AlwaysApplicableOrd] &T,
    [T: AlwaysApplicableOrd] &mut T,
    [T: AlwaysApplicableOrd] Option<T>,
}

#[doc(hidden)]
// इंटरमीडिएट trait स्लाइस के Ord. की विशेषज्ञता के लिए
trait SliceOrd: Sized {
    fn compare(left: &[Self], right: &[Self]) -> Ordering;
}

impl<A: Ord> SliceOrd for A {
    default fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let l = cmp::min(left.len(), right.len());

        // कंपाइलर में बाउंड चेक एलिमिनेशन को सक्षम करने के लिए स्लाइस टू लूप इटरेशन रेंज
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].cmp(&rhs[i]) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }

        left.len().cmp(&right.len())
    }
}

// memcmp लेक्सिकोग्राफिक रूप से अहस्ताक्षरित बाइट्स के अनुक्रम की तुलना करता है।
// यह उस क्रम से मेल खाता है जो हम [u8] के लिए चाहते हैं, लेकिन कोई अन्य नहीं ([i8] भी नहीं)।
impl SliceOrd for u8 {
    #[inline]
    fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let order =
            // सुरक्षा: `left` और `right` संदर्भ हैं और इस प्रकार वैध होने की गारंटी है।
            // हम न्यूनतम दोनों लंबाई का उपयोग करते हैं जो गारंटी देता है कि दोनों क्षेत्र उस अंतराल में पढ़ने के लिए मान्य हैं।
            //
            unsafe { memcmp(left.as_ptr(), right.as_ptr(), cmp::min(left.len(), right.len())) };
        if order == 0 {
            left.len().cmp(&right.len())
        } else if order < 0 {
            Less
        } else {
            Greater
        }
    }
}

// `Eq` पर विशेषज्ञता की अनुमति देने के लिए हैक करें, भले ही `Eq` में एक विधि हो।
#[rustc_unsafe_specialization_marker]
trait MarkerEq<T>: PartialEq<T> {}

impl<T: Eq> MarkerEq<T> for T {}

#[doc(hidden)]
/// Trait उन प्रकारों के लिए लागू किया गया है जिनकी तुलना उनके बाइटवाइज प्रतिनिधित्व का उपयोग करके समानता के लिए की जा सकती है
///
#[rustc_specialization_trait]
trait BytewiseEquality<T>: MarkerEq<T> + Copy {}

macro_rules! impl_marker_for {
    ($traitname:ident, $($ty:ty)*) => {
        $(
            impl $traitname<$ty> for $ty { }
        )*
    }
}

impl_marker_for!(BytewiseEquality,
                 u8 i8 u16 i16 u32 i32 u64 i64 u128 i128 usize isize char bool);

pub(super) trait SliceContains: Sized {
    fn slice_contains(&self, x: &[Self]) -> bool;
}

impl<T> SliceContains for T
where
    T: PartialEq,
{
    default fn slice_contains(&self, x: &[Self]) -> bool {
        x.iter().any(|y| *y == *self)
    }
}

impl SliceContains for u8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        memchr::memchr(*self, x).is_some()
    }
}

impl SliceContains for i8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        let byte = *self as u8;
        // सुरक्षा: `i8` और `u8` में एक ही मेमोरी लेआउट है, इस प्रकार `x.as_ptr()` कास्टिंग
        // क्योंकि `*const u8` सुरक्षित है।
        // `x.as_ptr()` एक संदर्भ से आता है और इस प्रकार स्लाइस `x.len()` की लंबाई के लिए पढ़ने के लिए मान्य होने की गारंटी है, जो `isize::MAX` से बड़ा नहीं हो सकता है।
        // लौटा हुआ टुकड़ा कभी भी उत्परिवर्तित नहीं होता है।
        let bytes: &[u8] = unsafe { from_raw_parts(x.as_ptr() as *const u8, x.len()) };
        memchr::memchr(byte, bytes).is_some()
    }
}