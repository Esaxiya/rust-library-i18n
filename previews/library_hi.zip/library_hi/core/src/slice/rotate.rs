// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// श्रेणी `[mid-left, mid+right)` को इस प्रकार घुमाता है कि `mid` पर अवयव पहला अवयव बन जाता है।समान रूप से, `left` तत्वों को बाईं ओर या `right` तत्वों को दाईं ओर घुमाता है।
///
/// # Safety
///
/// निर्दिष्ट सीमा पढ़ने और लिखने के लिए मान्य होनी चाहिए।
///
/// # Algorithm
///
/// एल्गोरिथम 1 का उपयोग `left + right` के छोटे मानों या बड़े `T` के लिए किया जाता है।
/// तत्वों को `mid - left` से शुरू करते हुए और `right` चरण मोडुलो `left + right` द्वारा आगे बढ़ते हुए एक समय में अपने अंतिम स्थान पर ले जाया जाता है, जैसे कि केवल एक अस्थायी की आवश्यकता होती है।
/// आखिरकार, हम `mid - left` पर वापस आ जाते हैं।
/// हालाँकि, यदि `gcd(left + right, right)` 1 नहीं है, तो उपरोक्त चरण तत्वों पर छोड़ दिए गए हैं।
/// उदाहरण के लिए:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// सौभाग्य से, अंतिम तत्वों के बीच छोड़े गए तत्वों की संख्या हमेशा बराबर होती है, इसलिए हम केवल अपनी प्रारंभिक स्थिति को ऑफसेट कर सकते हैं और अधिक राउंड कर सकते हैं (राउंड की कुल संख्या `gcd(left + right, right)` value) है।
///
/// अंतिम परिणाम यह है कि सभी तत्वों को एक बार और केवल एक बार अंतिम रूप दिया जाता है।
///
/// एल्गोरिदम 2 का उपयोग किया जाता है यदि `left + right` बड़ा है लेकिन `min(left, right)` स्टैक बफर पर फिट होने के लिए काफी छोटा है।
/// `min(left, right)` तत्वों को बफर पर कॉपी किया जाता है, `memmove` को दूसरों पर लागू किया जाता है, और बफर पर वाले को वापस उस छेद में ले जाया जाता है जहां वे उत्पन्न हुए थे।
///
/// एक बार `left + right` के काफी बड़े हो जाने पर वेक्टरकृत किए जा सकने वाले एल्गोरिदम उपरोक्त से बेहतर प्रदर्शन करते हैं।
/// एल्गोरिथम 1 को एक बार में कई चक्कर काटकर और प्रदर्शन करके वेक्टरकृत किया जा सकता है, लेकिन औसतन बहुत कम राउंड होते हैं जब तक कि `left + right` बहुत बड़ा न हो, और एक दौर का सबसे खराब मामला हमेशा होता है।
/// इसके बजाय, एल्गोरिथ्म 3 `min(left, right)` तत्वों की बार-बार अदला-बदली का उपयोग करता है जब तक कि एक छोटी घुमाने की समस्या नहीं रह जाती।
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// जब `left < right` इसके बजाय बाईं ओर से अदला-बदली होती है।
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. यदि इन मामलों की जाँच नहीं की जाती है तो नीचे दिए गए एल्गोरिदम विफल हो सकते हैं
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // एल्गोरिथम 1 माइक्रोबेंचमार्क इंगित करता है कि यादृच्छिक पारियों के लिए औसत प्रदर्शन लगभग `left + right == 32` तक सभी तरह से बेहतर है, लेकिन सबसे खराब स्थिति प्रदर्शन 16 के आसपास भी टूट जाता है।
            // 24 को मध्य मैदान के रूप में चुना गया था।
            // यदि `T` का आकार 4 `use`s से बड़ा है, तो यह एल्गोरिथम अन्य एल्गोरिदम से भी बेहतर प्रदर्शन करता है।
            //
            //
            let x = unsafe { mid.sub(left) };
            // पहले दौर की शुरुआत
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` की गणना करके हाथ से पहले पाया जा सकता है, लेकिन एक लूप करना तेज़ है जो साइड इफेक्ट के रूप में जीसीडी की गणना करता है, फिर बाकी हिस्से को कर रहा है
            //
            //
            let mut gcd = right;
            // बेंचमार्क से पता चलता है कि एक अस्थायी को एक बार पढ़ने, पीछे की ओर कॉपी करने और फिर उस अस्थायी को अंत में लिखने के बजाय सभी तरह से अस्थायी रूप से स्वैप करना तेज़ है।
            // यह संभवतः इस तथ्य के कारण है कि अस्थायी को बदलने या बदलने के लिए दो को प्रबंधित करने की आवश्यकता के बजाय लूप में केवल एक मेमोरी एड्रेस का उपयोग किया जाता है।
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` को बढ़ाने और फिर यह जाँचने के बजाय कि क्या यह सीमा से बाहर है, हम जाँचते हैं कि `i` अगले वेतन वृद्धि पर सीमा से बाहर जाएगा या नहीं।
                // यह पॉइंटर्स या `usize` के किसी भी रैपिंग को रोकता है।
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // पहले दौर का अंत
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // यह सशर्त यहाँ होना चाहिए यदि `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // अधिक राउंड के साथ चंक खत्म करें
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` शून्य आकार का प्रकार नहीं है, इसलिए इसके आकार से विभाजित करना ठीक है।
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // एल्गोरिथम 2 यहाँ `[T; 0]` यह सुनिश्चित करने के लिए है कि यह T. के लिए उचित रूप से संरेखित है
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // एल्गोरिथम 3 स्वैपिंग का एक वैकल्पिक तरीका है जिसमें यह पता लगाना शामिल है कि इस एल्गोरिथम का अंतिम स्वैप कहां होगा, और इस एल्गोरिथम की तरह आसन्न विखंडू को स्वैप करने के बजाय उस अंतिम चंक का उपयोग करके स्वैप करना शामिल है, लेकिन यह तरीका अभी भी तेज है।
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // एल्गोरिथम 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}