// rust-memchr से लिया गया मूल कार्यान्वयन।
// कॉपीराइट २०१५ एंड्रयू गैलेंट, ब्लस और निकोलस कोच

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// कटाव का प्रयोग करें।
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// यदि `x` में कोई शून्य बाइट है तो `true` लौटाता है।
///
/// *मैटर्स कम्प्यूटेशनल* से, जे. अरंड्ट:
///
/// "विचार प्रत्येक बाइट्स में से एक को घटाना है और फिर उन बाइट्स की तलाश करना है जहां उधार सबसे महत्वपूर्ण तरीके से प्रचारित होता है
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` में बाइट `x` से मेल खाने वाला पहला इंडेक्स देता है।
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // छोटे स्लाइस के लिए तेज़ रास्ता
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // एक बार में दो `usize` शब्द पढ़कर एक बाइट मान के लिए स्कैन करें।
    //
    // `text` को तीन भागों में विभाजित करें
    // - पाठ में पहले शब्द संरेखित पते से पहले असंरेखित प्रारंभिक भाग
    // - शरीर, एक बार में 2 शब्दों से स्कैन करें
    // - अंतिम शेष भाग, <2 शब्द आकार

    // एक संरेखित सीमा तक खोजें
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // पाठ का मुख्य भाग खोजें
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // सुरक्षा: समय का विधेय कम से कम 2 * usize_bytes की दूरी की गारंटी देता है
        // ऑफसेट और स्लाइस के अंत के बीच।
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // यदि कोई मिलान बाइट है तो तोड़ें break
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // बॉडी लूप बंद होने के बिंदु के बाद बाइट का पता लगाएं।
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` में बाइट `x` से मेल खाने वाला अंतिम इंडेक्स लौटाता है।
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // एक बार में दो `usize` शब्द पढ़कर एक बाइट मान के लिए स्कैन करें।
    //
    // `text` को तीन भागों में विभाजित करें:
    // - असंरेखित पूंछ, पाठ में अंतिम शब्द संरेखित पते के बाद,
    // - शरीर, एक बार में 2 शब्दों द्वारा स्कैन किया गया,
    // - पहले शेष बाइट्स, <2 शब्द आकार।
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // हम इसे केवल उपसर्ग और प्रत्यय की लंबाई प्राप्त करने के लिए कहते हैं।
        // बीच में हम हमेशा दो विखंडू को एक साथ प्रोसेस करते हैं।
        // सुरक्षा: `[u8]` को `[usize]` में ट्रांसमिट करना आकार के अंतर को छोड़कर सुरक्षित है जिसे `align_to` द्वारा नियंत्रित किया जाता है।
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // पाठ का मुख्य भाग खोजें, सुनिश्चित करें कि हम min_aligned_offset को पार नहीं करते हैं।
    // ऑफसेट हमेशा संरेखित होता है, इसलिए केवल `>` का परीक्षण करना पर्याप्त है और संभावित अतिप्रवाह से बचा जाता है।
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // सुरक्षा: ऑफ़सेट लेन, suffix.len() से शुरू होता है, जब तक कि यह. से अधिक है
        // min_aligned_offset (prefix.len()) शेष दूरी कम से कम 2 * चंक_बाइट्स है।
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // यदि कोई मिलान बाइट है तो तोड़ दें।
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // बॉडी लूप के रुकने के बिंदु से पहले बाइट का पता लगाएं।
    text[..offset].iter().rposition(|elt| *elt == x)
}