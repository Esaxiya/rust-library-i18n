//! स्लाइस छँटाई
//!
//! इस मॉड्यूल में ऑरसन पीटर्स के पैटर्न-पराजित क्विकॉर्ट पर आधारित एक सॉर्टिंग एल्गोरिदम शामिल है, जो यहां प्रकाशित हुआ है: <https://github.com/orlp/pdqsort>
//!
//!
//! अस्थिर छँटाई libcore के साथ संगत है क्योंकि यह हमारे स्थिर छँटाई कार्यान्वयन के विपरीत, स्मृति आवंटित नहीं करता है।
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// गिराए जाने पर, `src` से `dest` में कॉपी हो जाती है।
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // सुरक्षा: यह एक सहायक वर्ग है।
        //          कृपया शुद्धता के लिए इसके उपयोग को देखें।
        //          अर्थात्, किसी को यह सुनिश्चित करना चाहिए कि `src` और `dst` `ptr::copy_nonoverlapping` की आवश्यकता के अनुसार ओवरलैप नहीं होते हैं।
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// पहले तत्व को दाईं ओर तब तक शिफ्ट करता है जब तक कि उसका सामना अधिक या समान तत्व से न हो जाए।
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // सुरक्षा: नीचे असुरक्षित संचालन में बिना किसी बाध्य जांच के अनुक्रमण शामिल है (`get_unchecked` और `get_unchecked_mut`)
    // और स्मृति (`ptr::copy_nonoverlapping`) की प्रतिलिपि बनाना।
    //
    // ए।अनुक्रमण:
    //  1. हमने सरणी के आकार को>=2 पर चेक किया।
    //  2. हम जो भी इंडेक्सिंग करेंगे वह हमेशा अधिकतम {0 <= index < len} के बीच होगा।
    //
    // बीमेमोरी कॉपी करना
    //  1. हम उन संदर्भों के लिए संकेत प्राप्त कर रहे हैं जिनके वैध होने की गारंटी है।
    //  2. वे ओवरलैप नहीं कर सकते क्योंकि हम स्लाइस के अंतर सूचकांकों के लिए पॉइंटर्स प्राप्त करते हैं।
    //     अर्थात्, `i` और `i-1`।
    //  3. यदि स्लाइस ठीक से संरेखित है, तो तत्व ठीक से संरेखित हैं।
    //     यह सुनिश्चित करने के लिए कॉलर की ज़िम्मेदारी है कि टुकड़ा ठीक से गठबंधन हो।
    //
    // अधिक विवरण के लिए नीचे टिप्पणियाँ देखें।
    unsafe {
        // यदि पहले दो तत्व क्रम से बाहर हैं...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // स्टैक-आवंटित चर में पहला तत्व पढ़ें।
            // यदि निम्नलिखित तुलना ऑपरेशन panics, `hole` गिरा दिया जाएगा और स्वचालित रूप से तत्व को वापस स्लाइस में लिख देगा।
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // `i`-वें तत्व को बाईं ओर एक स्थान पर ले जाएं, इस प्रकार छेद को दाईं ओर स्थानांतरित करें।
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` गिरा दिया जाता है और इस प्रकार `tmp` को `v` में शेष छेद में कॉपी करता है।
        }
    }
}

/// अंतिम तत्व को बाईं ओर तब तक शिफ्ट करता है जब तक कि उसका सामना छोटे या समान तत्व से न हो जाए।
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // सुरक्षा: नीचे असुरक्षित संचालन में बिना किसी बाध्य जांच के अनुक्रमण शामिल है (`get_unchecked` और `get_unchecked_mut`)
    // और स्मृति (`ptr::copy_nonoverlapping`) की प्रतिलिपि बनाना।
    //
    // ए।अनुक्रमण:
    //  1. हमने सरणी के आकार को>=2 पर चेक किया।
    //  2. हम जो भी इंडेक्सिंग करेंगे वह हमेशा अधिकतम `0 <= index < len-1` के बीच होगा।
    //
    // बीमेमोरी कॉपी करना
    //  1. हम उन संदर्भों के लिए संकेत प्राप्त कर रहे हैं जिनके वैध होने की गारंटी है।
    //  2. वे ओवरलैप नहीं कर सकते क्योंकि हम स्लाइस के अंतर सूचकांकों के लिए पॉइंटर्स प्राप्त करते हैं।
    //     अर्थात्, `i` और `i+1`।
    //  3. यदि स्लाइस ठीक से संरेखित है, तो तत्व ठीक से संरेखित हैं।
    //     यह सुनिश्चित करने के लिए कॉलर की ज़िम्मेदारी है कि टुकड़ा ठीक से गठबंधन हो।
    //
    // अधिक विवरण के लिए नीचे टिप्पणियाँ देखें।
    unsafe {
        // यदि अंतिम दो तत्व क्रम से बाहर हैं...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // अंतिम तत्व को स्टैक-आवंटित चर में पढ़ें।
            // यदि निम्नलिखित तुलना ऑपरेशन panics, `hole` गिरा दिया जाएगा और स्वचालित रूप से तत्व को वापस स्लाइस में लिख देगा।
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // `i`-वें तत्व को एक स्थान पर दाईं ओर ले जाएं, इस प्रकार छेद को बाईं ओर स्थानांतरित करें।
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` गिरा दिया जाता है और इस प्रकार `tmp` को `v` में शेष छेद में कॉपी करता है।
        }
    }
}

/// कई आउट-ऑफ-ऑर्डर तत्वों को चारों ओर स्थानांतरित करके आंशिक रूप से एक स्लाइस को सॉर्ट करता है।
///
/// यदि स्लाइस को अंत में क्रमबद्ध किया जाता है, तो `true` लौटाता है।यह फ़ंक्शन *O*(*n*) सबसे खराब स्थिति है।
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // शिफ्ट किए जाने वाले आसन्न आउट-ऑफ-ऑर्डर जोड़े की अधिकतम संख्या।
    const MAX_STEPS: usize = 5;
    // यदि टुकड़ा इससे छोटा है, तो किसी भी तत्व को स्थानांतरित न करें।
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // सुरक्षा: हमने पहले ही स्पष्ट रूप से `i < len` के साथ बाउंड चेकिंग कर ली है।
        // हमारे सभी बाद के अनुक्रमण केवल `0 <= index < len`. की सीमा में हैं
        unsafe {
            // आसन्न आउट-ऑफ-ऑर्डर तत्वों की अगली जोड़ी खोजें।
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // हम कर रहे हैं?
        if i == len {
            return true;
        }

        // छोटे सरणियों पर तत्वों को स्थानांतरित न करें, जिनकी प्रदर्शन लागत है।
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // तत्वों की मिली जोड़ी को स्वैप करें।यह उन्हें सही क्रम में रखता है।
        v.swap(i - 1, i);

        // छोटे तत्व को बाईं ओर शिफ्ट करें।
        shift_tail(&mut v[..i], is_less);
        // बड़े तत्व को दाईं ओर शिफ्ट करें।
        shift_head(&mut v[i..], is_less);
    }

    // सीमित चरणों में स्लाइस को सॉर्ट करने का प्रबंधन नहीं किया।
    false
}

/// सम्मिलन प्रकार का उपयोग करके एक टुकड़ा क्रमबद्ध करता है, जो कि *O*(*n*^2) सबसे खराब स्थिति है।
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// हेपसॉर्ट का उपयोग करके `v` को सॉर्ट करता है, जो गारंटी देता है *O*(*n*\*log(* n*)) सबसे खराब स्थिति।
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // यह बाइनरी हीप अपरिवर्तनीय `parent >= child` का सम्मान करता है।
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` के बच्चे:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // बड़ा बच्चा चुनें।
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // रुकें अगर अपरिवर्तनीय `node` पर रहता है।
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // बड़े बच्चे के साथ `node` स्वैप करें, एक कदम नीचे जाएं, और स्थानांतरण जारी रखें।
            v.swap(node, greater);
            node = greater;
        }
    };

    // रैखिक समय में ढेर बनाएँ।
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // ढेर से अधिकतम तत्वों को पॉप करें।
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` को `pivot` से छोटे तत्वों में विभाजित करता है, उसके बाद `pivot` से अधिक या उसके बराबर के तत्व।
///
///
/// `pivot` से छोटे तत्वों की संख्या लौटाता है।
///
/// शाखाओं के संचालन की लागत को कम करने के लिए विभाजन को ब्लॉक-दर-ब्लॉक किया जाता है।
/// यह विचार [BlockQuicksort][pdf] पेपर में प्रस्तुत किया गया है।
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // एक विशिष्ट ब्लॉक में तत्वों की संख्या।
    const BLOCK: usize = 128;

    // विभाजन एल्गोरिथ्म पूरा होने तक निम्नलिखित चरणों को दोहराता है:
    //
    // 1. पिवट से अधिक या उसके बराबर तत्वों की पहचान करने के लिए बाईं ओर से एक ब्लॉक ट्रेस करें।
    // 2. धुरी से छोटे तत्वों की पहचान करने के लिए दाईं ओर से एक ब्लॉक ट्रेस करें।
    // 3. बाएँ और दाएँ पक्ष के बीच पहचाने गए तत्वों का आदान-प्रदान करें।
    //
    // हम तत्वों के एक ब्लॉक के लिए निम्नलिखित चर रखते हैं:
    //
    // 1. `block` - ब्लॉक में तत्वों की संख्या।
    // 2. `start` - `offsets` सरणी में पॉइंटर प्रारंभ करें।
    // 3. `end` - `offsets` सरणी में अंत सूचक।
    // 4. 'ऑफसेट', ब्लॉक के भीतर आउट-ऑफ-ऑर्डर तत्वों के सूचकांक।

    // बाईं ओर वर्तमान ब्लॉक (`l` से `l.add(block_l)`) तक।
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // दाईं ओर वर्तमान ब्लॉक (`r.sub(block_r)` to `r`).
    // सुरक्षा: .add() के दस्तावेज़ीकरण में विशेष रूप से उल्लेख किया गया है कि `vec.as_ptr().add(vec.len())` हमेशा सुरक्षित है'
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: जब हमें वीएलए मिलते हैं, तो लंबाई की एक सरणी बनाने का प्रयास करें `min(v.len(), 2 * BLOCK)` बल्कि
    // लंबाई `BLOCK` के दो निश्चित आकार के सरणियों की तुलना में।वीएलए अधिक कैश-कुशल हो सकते हैं।

    // पॉइंटर्स `l` (inclusive) और `r` (exclusive) के बीच तत्वों की संख्या देता है।
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // जब `l` और `r` बहुत करीब आ जाते हैं, तो हमें ब्लॉक-दर-ब्लॉक का विभाजन करना होता है।
        // फिर हम शेष तत्वों को बीच में विभाजित करने के लिए कुछ पैच-अप कार्य करते हैं।
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // शेष तत्वों की संख्या (अभी भी धुरी की तुलना में नहीं)।
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // ब्लॉक आकार समायोजित करें ताकि बाएं और दाएं ब्लॉक ओवरलैप न हों, लेकिन पूरे शेष अंतर को कवर करने के लिए पूरी तरह से गठबंधन हो जाएं।
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // बाईं ओर से `block_l` तत्वों को ट्रेस करें।
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // सुरक्षा: नीचे दिए गए असुरक्षित संचालन में `offset` का उपयोग शामिल है।
                //         फलन के लिए आवश्यक शर्तों के अनुसार, हम उन्हें संतुष्ट करते हैं क्योंकि:
                //         1. `offsets_l` स्टैक-आवंटित है, और इस प्रकार अलग आवंटित वस्तु माना जाता है।
                //         2. फ़ंक्शन `is_less` एक `bool` देता है।
                //            `bool` को कास्ट करने से `isize` कभी भी ओवरफ्लो नहीं होगा।
                //         3. हमने गारंटी दी है कि `block_l`, `<= BLOCK` होगा।
                //            साथ ही, `end_l` को शुरू में `offsets_` के शुरुआती पॉइंटर पर सेट किया गया था जिसे स्टैक पर घोषित किया गया था।
                //            इस प्रकार, हम जानते हैं कि सबसे खराब स्थिति में भी (`is_less` के सभी आमंत्रण झूठे लौटते हैं) हम केवल 1 बाइट के अंत में ही होंगे।
                //        यहां एक और असुरक्षित ऑपरेशन `elem` को संदर्भित कर रहा है।
                //        हालाँकि, `elem` शुरू में स्लाइस का शुरुआती सूचक था जो हमेशा मान्य होता है।
                unsafe {
                    // शाखा रहित तुलना।
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // `block_r` तत्वों को दाईं ओर से ट्रेस करें।
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // सुरक्षा: नीचे दिए गए असुरक्षित संचालन में `offset` का उपयोग शामिल है।
                //         फलन के लिए आवश्यक शर्तों के अनुसार, हम उन्हें संतुष्ट करते हैं क्योंकि:
                //         1. `offsets_r` स्टैक-आवंटित है, और इस प्रकार अलग आवंटित वस्तु माना जाता है।
                //         2. फ़ंक्शन `is_less` एक `bool` देता है।
                //            `bool` को कास्ट करने से `isize` कभी भी ओवरफ्लो नहीं होगा।
                //         3. हमने गारंटी दी है कि `block_r`, `<= BLOCK` होगा।
                //            साथ ही, `end_r` को शुरू में `offsets_` के शुरुआती पॉइंटर पर सेट किया गया था जिसे स्टैक पर घोषित किया गया था।
                //            इस प्रकार, हम जानते हैं कि सबसे खराब स्थिति में भी (`is_less` के सभी आमंत्रण सत्य लौटते हैं) हम केवल 1 बाइट के अंत में ही होंगे।
                //        यहां एक और असुरक्षित ऑपरेशन `elem` को संदर्भित कर रहा है।
                //        हालाँकि, `elem` शुरू में `1 *sizeof(T)` था और इसे एक्सेस करने से पहले हम इसे `1* sizeof(T)` से घटाते हैं।
                //        साथ ही, `block_r` को `BLOCK` से कम होने का दावा किया गया था और इसलिए `elem` अधिक से अधिक स्लाइस की शुरुआत की ओर इशारा करेगा।
                unsafe {
                    // शाखा रहित तुलना।
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // बाएँ और दाएँ पक्ष के बीच अदला-बदली करने वाले तत्वों की संख्या।
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // एक समय में एक जोड़ी की अदला-बदली करने के बजाय, यह चक्रीय क्रमपरिवर्तन करने के लिए अधिक कुशल है।
            // यह पूरी तरह से स्वैपिंग के बराबर नहीं है, लेकिन कम मेमोरी ऑपरेशंस का उपयोग करके एक समान परिणाम उत्पन्न करता है।
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // बाएं ब्लॉक में सभी आउट-ऑफ-ऑर्डर तत्वों को स्थानांतरित कर दिया गया था।अगले ब्लॉक में जाएं।
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // दाएं ब्लॉक में सभी आउट-ऑफ-ऑर्डर तत्वों को स्थानांतरित कर दिया गया था।पिछले ब्लॉक में जाएं।
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // अब जो कुछ बचा है वह आउट-ऑफ-ऑर्डर तत्वों के साथ अधिकतम एक ब्लॉक (या तो बाएं या दाएं) है जिसे स्थानांतरित करने की आवश्यकता है।
    // ऐसे शेष तत्वों को उनके ब्लॉक के भीतर अंत में आसानी से स्थानांतरित किया जा सकता है।
    //

    if start_l < end_l {
        // बायां ब्लॉक रहता है।
        // इसके शेष आउट-ऑफ-ऑर्डर तत्वों को सबसे दाईं ओर ले जाएं।
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // राइट ब्लॉक रहता है।
        // इसके शेष आउट-ऑफ-ऑर्डर तत्वों को दूर बाईं ओर ले जाएं।
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // और कुछ नहीं करना है, हम कर चुके हैं।
        width(v.as_mut_ptr(), l)
    }
}

/// `v` को `v[pivot]` से छोटे तत्वों में विभाजित करता है, उसके बाद `v[pivot]` से अधिक या उसके बराबर के तत्व।
///
///
/// का एक टपल लौटाता है:
///
/// 1. `v[pivot]` से छोटे तत्वों की संख्या।
/// 2. सच है अगर `v` पहले से ही विभाजित था।
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // पिवट को स्लाइस की शुरुआत में रखें।
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // दक्षता के लिए पिवट को स्टैक-आवंटित चर में पढ़ें।
        // यदि निम्नलिखित तुलना ऑपरेशन panics, पिवट स्वचालित रूप से वापस स्लाइस में लिखा जाएगा।
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // आउट-ऑफ-ऑर्डर तत्वों की पहली जोड़ी खोजें।
        let mut l = 0;
        let mut r = v.len();

        // सुरक्षा: नीचे दी गई असुरक्षितता में एक सरणी को अनुक्रमित करना शामिल है।
        // पहले के लिए: हम पहले से ही यहां `l < r` के साथ सीमा की जांच कर रहे हैं।
        // दूसरे के लिए: हमारे पास शुरू में `l == 0` और `r == v.len()` हैं और हमने हर इंडेक्सिंग ऑपरेशन में उस `l < r` की जाँच की।
        //                     यहाँ से हम जानते हैं कि `r` कम से कम `r == l` होना चाहिए जो कि पहले वाले से मान्य होना दिखाया गया था।
        unsafe {
            // पिवट से बड़ा या उसके बराबर पहला तत्व खोजें।
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // पिवट से छोटा अंतिम तत्व खोजें।
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` दायरे से बाहर चला जाता है और पिवट (जो एक स्टैक-आवंटित चर है) को वापस उस स्लाइस में लिखता है जहां यह मूल रूप से था।
        // सुरक्षा सुनिश्चित करने के लिए यह कदम महत्वपूर्ण है!
        //
    };

    // धुरी को दो विभाजनों के बीच रखें।
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` को `v[pivot]` के बराबर तत्वों में विभाजित करता है और उसके बाद `v[pivot]` से बड़े तत्वों को विभाजित करता है।
///
/// पिवट के बराबर तत्वों की संख्या लौटाता है।
/// यह माना जाता है कि `v` में पिवट से छोटे तत्व नहीं हैं।
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // पिवट को स्लाइस की शुरुआत में रखें।
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // दक्षता के लिए पिवट को स्टैक-आवंटित चर में पढ़ें।
    // यदि निम्नलिखित तुलना ऑपरेशन panics, पिवट स्वचालित रूप से वापस स्लाइस में लिखा जाएगा।
    // सुरक्षा: यहां सूचक मान्य है क्योंकि यह एक स्लाइस के संदर्भ से प्राप्त होता है।
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // अब स्लाइस को विभाजित करें।
    let mut l = 0;
    let mut r = v.len();
    loop {
        // सुरक्षा: नीचे दी गई असुरक्षितता में एक सरणी को अनुक्रमित करना शामिल है।
        // पहले के लिए: हम पहले से ही यहां `l < r` के साथ सीमा की जांच कर रहे हैं।
        // दूसरे के लिए: हमारे पास शुरू में `l == 0` और `r == v.len()` हैं और हमने हर इंडेक्सिंग ऑपरेशन में उस `l < r` की जाँच की।
        //                     यहाँ से हम जानते हैं कि `r` कम से कम `r == l` होना चाहिए जो कि पहले वाले से मान्य होना दिखाया गया था।
        unsafe {
            // पिवट से बड़ा पहला तत्व खोजें।
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // धुरी के बराबर अंतिम तत्व खोजें।
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // हम कर रहे हैं?
            if l >= r {
                break;
            }

            // आउट-ऑफ-ऑर्डर तत्वों की मिली जोड़ी को स्वैप करें।
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // हमने `l` तत्वों को धुरी के बराबर पाया।पिवट के लिए खाते में 1 जोड़ें।
    l + 1

    // `_pivot_guard` दायरे से बाहर चला जाता है और पिवट (जो एक स्टैक-आवंटित चर है) को वापस उस स्लाइस में लिखता है जहां यह मूल रूप से था।
    // सुरक्षा सुनिश्चित करने के लिए यह कदम महत्वपूर्ण है!
}

/// पैटर्न को तोड़ने के प्रयास में कुछ तत्वों को तितर-बितर कर देता है जिससे क्विकॉर्ट में असंतुलित विभाजन हो सकता है।
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // जॉर्ज मार्सग्लिया द्वारा "Xorshift RNGs" पेपर से छद्म यादृच्छिक संख्या जनरेटर।
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // यादृच्छिक संख्याएँ मॉड्यूलो इस संख्या को लें।
        // संख्या `usize` में फिट बैठती है क्योंकि `len` `isize::MAX` से बड़ा नहीं है।
        let modulus = len.next_power_of_two();

        // कुछ धुरी उम्मीदवार इस सूचकांक के पास होंगे।आइए उन्हें यादृच्छिक करें।
        let pos = len / 4 * 2;

        for i in 0..3 {
            // एक यादृच्छिक संख्या मॉड्यूलो `len` उत्पन्न करें।
            // हालांकि, महंगा संचालन से बचने के लिए हम पहले इसे दो की शक्ति मॉड्यूलो लेते हैं, और फिर `len` तक घटाते हैं जब तक कि यह `[0, len - 1]` की सीमा में फिट न हो जाए।
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` से कम होने की गारंटी है।
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` में एक पिवट चुनता है और इंडेक्स और `true` देता है यदि टुकड़ा पहले से ही सॉर्ट किया गया है।
///
/// `v` में तत्वों को प्रक्रिया में पुन: व्यवस्थित किया जा सकता है।
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // माध्यिका-माध्यम विधि चुनने के लिए न्यूनतम लंबाई।
    // छोटे स्लाइस सरल माध्यिका-तीन विधि का उपयोग करते हैं।
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // इस फ़ंक्शन में किए जा सकने वाले स्वैप की अधिकतम संख्या।
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // तीन सूचकांक जिनके पास हम एक पिवट चुनने जा रहे हैं।
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // सूचकांकों को छांटते समय हमारे द्वारा किए जाने वाले स्वैप की कुल संख्या की गणना करता है।
    let mut swaps = 0;

    if len >= 8 {
        // सूचकांकों को स्वैप करें ताकि `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // सूचकांकों को स्वैप करें ताकि `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` का माध्यिका ढूँढता है और अनुक्रमणिका को `a` में संग्रहीत करता है।
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b`, और `c` के आस-पड़ोस में माध्यिकाएं खोजें।
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b` और `c` के बीच माध्यिका ज्ञात कीजिए।
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // स्वैप की अधिकतम संख्या का प्रदर्शन किया गया।
        // संभावना है कि टुकड़ा अवरोही है या अधिकतर अवरोही है, इसलिए उलटा होने से शायद इसे तेजी से क्रमबद्ध करने में मदद मिलेगी।
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` को पुनरावर्ती रूप से क्रमबद्ध करता है।
///
/// यदि मूल सरणी में स्लाइस का पूर्ववर्ती था, तो इसे `pred` के रूप में निर्दिष्ट किया जाता है।
///
/// `limit` `heapsort` पर स्विच करने से पहले अनुमत असंतुलित विभाजन की संख्या है।
/// यदि शून्य है, तो यह फ़ंक्शन तुरंत हीपॉर्ट पर स्विच हो जाएगा।
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // इस लंबाई तक के स्लाइस को इंसर्शन सॉर्ट का उपयोग करके सॉर्ट किया जाता है।
    const MAX_INSERTION: usize = 20;

    // सही है अगर अंतिम विभाजन यथोचित रूप से संतुलित था।
    let mut was_balanced = true;
    // सही है अगर पिछले विभाजन ने तत्वों को फेरबदल नहीं किया (टुकड़ा पहले से ही विभाजित था)।
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // सम्मिलन प्रकार का उपयोग करके बहुत छोटी स्लाइस को क्रमबद्ध किया जाता है।
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // यदि बहुत अधिक खराब पिवट विकल्प बनाए गए थे, तो `O(n * log(n))` सबसे खराब स्थिति की गारंटी के लिए बस वापस हीपॉर्ट पर आएं।
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // यदि पिछला विभाजन असंतुलित था, तो कुछ तत्वों को इधर-उधर फेरबदल करके स्लाइस में पैटर्न को तोड़ने का प्रयास करें।
        // उम्मीद है कि हम इस बार एक बेहतर धुरी चुनेंगे।
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // एक पिवट चुनें और अनुमान लगाने का प्रयास करें कि क्या टुकड़ा पहले से ही सॉर्ट किया गया है।
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // यदि अंतिम विभाजन शालीनता से संतुलित था और तत्वों में फेरबदल नहीं किया था, और यदि पिवट चयन भविष्यवाणी करता है कि टुकड़ा पहले से ही सॉर्ट किया गया है ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // कई आउट-ऑफ-ऑर्डर तत्वों की पहचान करने और उन्हें सही स्थिति में स्थानांतरित करने का प्रयास करें।
            // अगर टुकड़ा पूरी तरह से सॉर्ट किया जा रहा है, तो हम कर चुके हैं।
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // यदि चुना हुआ पिवट पूर्ववर्ती के बराबर है, तो यह स्लाइस में सबसे छोटा तत्व है।
        // स्लाइस को पिवट से बड़े तत्वों के बराबर और तत्वों में विभाजित करें।
        // यह मामला आमतौर पर तब हिट होता है जब स्लाइस में कई डुप्लिकेट तत्व होते हैं।
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // पिवट से बड़े तत्वों को छांटना जारी रखें।
                v = &mut { v }[mid..];
                continue;
            }
        }

        // टुकड़ा विभाजित करें।
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // स्लाइस को `left`, `pivot` और `right` में विभाजित करें।
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // रिकर्सिव कॉल की कुल संख्या को कम करने और कम स्टैक स्पेस का उपभोग करने के लिए केवल छोटे पक्ष में रिकर्स करें।
        // फिर बस लंबी तरफ जारी रखें (यह पूंछ रिकर्सन के समान है)।
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// पैटर्न-पराजय क्विकसॉर्ट का उपयोग करके `v` को सॉर्ट करता है, जो कि *O*(*n*\*log(* n*)) सबसे खराब स्थिति है।
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // शून्य-आकार के प्रकारों पर छँटाई का कोई सार्थक व्यवहार नहीं है।
    if mem::size_of::<T>() == 0 {
        return;
    }

    // असंतुलित विभाजन की संख्या को `floor(log2(len)) + 1` तक सीमित करें।
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // इस लंबाई तक के स्लाइस के लिए उन्हें आसानी से सॉर्ट करना शायद तेज़ है।
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // एक धुरी चुनें
        let (pivot, _) = choose_pivot(v, is_less);

        // यदि चुना हुआ पिवट पूर्ववर्ती के बराबर है, तो यह स्लाइस में सबसे छोटा तत्व है।
        // स्लाइस को पिवट से बड़े तत्वों के बराबर और तत्वों में विभाजित करें।
        // यह मामला आमतौर पर तब हिट होता है जब स्लाइस में कई डुप्लिकेट तत्व होते हैं।
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // अगर हमने अपना सूचकांक पास कर लिया है, तो हम अच्छे हैं।
                if mid > index {
                    return;
                }

                // अन्यथा, पिवट से बड़े तत्वों को क्रमबद्ध करना जारी रखें।
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // स्लाइस को `left`, `pivot` और `right` में विभाजित करें।
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // यदि मध्य==सूचकांक, तो हम कर रहे हैं, क्योंकि partition() ने गारंटी दी है कि मध्य के बाद के सभी तत्व मध्य से अधिक या बराबर हैं।
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // शून्य-आकार के प्रकारों पर छँटाई का कोई सार्थक व्यवहार नहीं है।कुछ मत करो।
    } else if index == v.len() - 1 {
        // अधिकतम तत्व खोजें और इसे सरणी के अंतिम स्थान पर रखें।
        // हम यहां `unwrap()` का उपयोग करने के लिए स्वतंत्र हैं क्योंकि हम जानते हैं कि v खाली नहीं होना चाहिए।
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // न्यूनतम तत्व खोजें और इसे सरणी की पहली स्थिति में रखें।
        // हम यहां `unwrap()` का उपयोग करने के लिए स्वतंत्र हैं क्योंकि हम जानते हैं कि v खाली नहीं होना चाहिए।
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}