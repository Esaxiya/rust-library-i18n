//! ASCII `[u8]` पर संचालन।

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// जाँचता है कि इस स्लाइस में सभी बाइट्स ASCII रेंज के भीतर हैं या नहीं।
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// जाँचता है कि दो स्लाइस ASCII केस-असंवेदनशील मिलान हैं।
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` के समान, लेकिन अस्थायी आवंटित और कॉपी किए बिना।
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// इस स्लाइस को इसके ASCII अपर केस के बराबर इन-प्लेस में कनवर्ट करता है।
    ///
    /// ASCII अक्षर 'a' से 'z' को 'A' से 'Z' में मैप किया गया है, लेकिन गैर-ASCII अक्षर अपरिवर्तित हैं।
    ///
    /// मौजूदा एक को संशोधित किए बिना एक नया अपरकेस मान वापस करने के लिए, [`to_ascii_uppercase`] का उपयोग करें।
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// इस स्लाइस को इसके ASCII लोअर केस के समतुल्य इन-प्लेस में कनवर्ट करता है।
    ///
    /// ASCII अक्षर 'A' से 'Z' को 'a' से 'z' में मैप किया गया है, लेकिन गैर-ASCII अक्षर अपरिवर्तित हैं।
    ///
    /// मौजूदा को संशोधित किए बिना एक नया लोअरकेस मान वापस करने के लिए, [`to_ascii_lowercase`] का उपयोग करें।
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `true` लौटाता है यदि `v` शब्द में कोई भी बाइट nonascii (>=128) है।
/// `../str/mod.rs` से Snarfed, जो utf8 सत्यापन के लिए कुछ ऐसा ही करता है।
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// अनुकूलित ASCII परीक्षण जो बाइट-एट-ए-टाइम संचालन (जब संभव हो) के बजाय उपयोग-पर-एक-समय संचालन का उपयोग करेगा।
///
/// हम यहां जिस एल्गोरिथम का उपयोग करते हैं वह बहुत सरल है।यदि `s` बहुत छोटा है, तो हम बस प्रत्येक बाइट की जांच करते हैं और इसके साथ किया जाता है।अन्यथा:
///
/// - एक असंरेखित भार के साथ पहला शब्द पढ़ें।
/// - सूचक को संरेखित करें, बाद के शब्दों को संरेखित भार के साथ अंत तक पढ़ें।
/// - एक असंरेखित लोड के साथ `s` से अंतिम `usize` पढ़ें।
///
/// यदि इनमें से कोई भी भार कुछ ऐसा उत्पन्न करता है जिसके लिए `contains_nonascii` (above) सत्य लौटाता है, तो हम जानते हैं कि उत्तर गलत है।
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // यदि हम शब्द-दर-समय कार्यान्वयन से कुछ हासिल नहीं करते हैं, तो एक अदिश लूप पर वापस आएं।
    //
    // हम इसे आर्किटेक्चर के लिए भी करते हैं जहां `size_of::<usize>()` `usize` के लिए पर्याप्त संरेखण नहीं है, क्योंकि यह एक अजीब edge मामला है।
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // हम हमेशा पहला शब्द unaligned पढ़ते हैं, जिसका अर्थ है `align_offset` is
    // 0, हम संरेखित रीड के लिए फिर से वही मान पढ़ेंगे।
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // सुरक्षा: हम ऊपर `len < USIZE_SIZE` सत्यापित करते हैं।
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // हमने इसे ऊपर जाँचा, कुछ हद तक परोक्ष रूप से।
    // ध्यान दें कि `offset_to_aligned` या तो `align_offset` या `USIZE_SIZE` है, दोनों को ऊपर स्पष्ट रूप से चेक किया गया है।
    //
    debug_assert!(offset_to_aligned <= len);

    // सुरक्षा: word_ptr (ठीक से संरेखित) ptr का उपयोग करता है जिसे हम पढ़ने के लिए उपयोग करते हैं
    // टुकड़े का मध्य भाग।
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` `word_ptr` का बाइट इंडेक्स है, जिसका उपयोग लूप एंड चेक के लिए किया जाता है।
    let mut byte_pos = offset_to_aligned;

    // व्यामोह संरेखण के बारे में जाँच करता है, क्योंकि हम असंरेखित भार का एक गुच्छा करने वाले हैं।
    // व्यवहार में हालांकि `align_offset` में बग को छोड़कर यह असंभव होना चाहिए।
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // अंतिम संरेखित शब्द तक बाद के शब्दों को पढ़ें, बाद में टेल चेक में किए जाने वाले अंतिम संरेखित शब्द को छोड़कर, यह सुनिश्चित करने के लिए कि टेल हमेशा अतिरिक्त branch `byte_pos == len` पर एक `usize` है।
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // विवेक जाँचता है कि पठन सीमा में है
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // और यह कि `byte_pos` के बारे में हमारी धारणाएं कायम हैं।
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // सुरक्षा: हम जानते हैं कि `word_ptr` ठीक से संरेखित है (क्योंकि .)
        // `align_offset`), और हम जानते हैं कि हमारे पास `word_ptr` और अंत के बीच पर्याप्त बाइट हैं
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // सुरक्षा: हम जानते हैं कि `byte_pos <= len - USIZE_SIZE`, जिसका अर्थ है कि
        // इसके बाद `add`, `word_ptr` अधिकतम वन-पास्ट-द-एंड होगा।
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // यह सुनिश्चित करने के लिए विवेक जाँच करें कि वास्तव में केवल एक `usize` बचा है।
    // इसकी गारंटी हमारी लूप कंडीशन से होनी चाहिए।
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // सुरक्षा: यह `len >= USIZE_SIZE` पर निर्भर करता है, जिसे हम शुरुआत में जांचते हैं।
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}