//! `Clone` trait उन प्रकारों के लिए जिन्हें 'निहित रूप से कॉपी' नहीं किया जा सकता है।
//!
//! Rust में, कुछ सरल प्रकार "implicitly copyable" हैं और जब आप उन्हें असाइन करते हैं या उन्हें तर्क के रूप में पास करते हैं, तो रिसीवर को एक प्रति प्राप्त होगी, जिससे मूल मान यथावत रहेगा।
//! इन प्रकारों को प्रतिलिपि बनाने के लिए आवंटन की आवश्यकता नहीं होती है और अंतिम रूप नहीं होते हैं (यानी, उनके पास स्वामित्व वाले बक्से नहीं होते हैं या [`Drop`] लागू नहीं होते हैं), इसलिए संकलक उन्हें सस्ता और प्रतिलिपि बनाने के लिए सुरक्षित मानता है।
//!
//! [`Clone`] trait को लागू करने और [`clone`] विधि को कॉल करके, अन्य प्रकार की प्रतियां स्पष्ट रूप से बनाई जानी चाहिए।
//!
//! [`clone`]: Clone::clone
//!
//! मूल उपयोग उदाहरण:
//!
//! ```
//! let s = String::new(); // स्ट्रिंग प्रकार क्लोन लागू करता है
//! let copy = s.clone(); // तो हम इसे क्लोन कर सकते हैं
//! ```
//!
//! क्लोन trait को आसानी से लागू करने के लिए, आप `#[derive(Clone)]` का भी उपयोग कर सकते हैं।उदाहरण:
//!
//! ```
//! #[derive(Clone)] // हम क्लोन trait को मॉर्फियस स्ट्रक्चर में जोड़ते हैं
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // और अब हम इसे क्लोन कर सकते हैं!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// किसी वस्तु को स्पष्ट रूप से डुप्लिकेट करने की क्षमता के लिए एक सामान्य trait।
///
/// उस [`Copy`] में [`Copy`] से अंतर निहित और बेहद सस्ता है, जबकि `Clone` हमेशा स्पष्ट होता है और महंगा हो भी सकता है और नहीं भी।
/// इन विशेषताओं को लागू करने के लिए, Rust आपको [`Copy`] को फिर से लागू करने की अनुमति नहीं देता है, लेकिन आप `Clone` को फिर से लागू कर सकते हैं और मनमाना कोड चला सकते हैं।
///
/// चूंकि `Clone`, [`Copy`] से अधिक सामान्य है, आप स्वचालित रूप से कुछ भी [`Copy`] को `Clone` बना सकते हैं।
///
/// ## Derivable
///
/// यदि सभी फ़ील्ड `Clone` हैं, तो इस trait का उपयोग `#[derive]` के साथ किया जा सकता है।[`Clone`] का `व्युत्पन्न` कार्यान्वयन प्रत्येक क्षेत्र पर [`clone`] को कॉल करता है।
///
/// [`clone`]: Clone::clone
///
/// एक सामान्य संरचना के लिए, `#[derive]` सामान्य मानकों पर बाध्य `Clone` जोड़कर सशर्त रूप से `Clone` लागू करता है।
///
/// ```
/// // `derive` पढ़ने के लिए क्लोन लागू करता है<T>जब T क्लोन है।
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## मैं `Clone` को कैसे कार्यान्वित कर सकता हूं?
///
/// [`Copy`] के प्रकारों में `Clone` का मामूली कार्यान्वयन होना चाहिए।अधिक औपचारिक रूप से:
/// अगर `T: Copy`, `x: T`, और `y: &T`, तो `let x = y.clone();` `let x = *y;` के बराबर है।
/// मैनुअल कार्यान्वयन इस अपरिवर्तनीय को बनाए रखने के लिए सावधान रहना चाहिए;हालांकि, स्मृति सुरक्षा सुनिश्चित करने के लिए असुरक्षित कोड को उस पर भरोसा नहीं करना चाहिए।
///
/// एक उदाहरण एक सामान्य संरचना है जिसमें फ़ंक्शन पॉइंटर होता है।इस मामले में, `Clone` का कार्यान्वयन `व्युत्पन्न` नहीं किया जा सकता है, लेकिन इसे इस प्रकार कार्यान्वित किया जा सकता है:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## अतिरिक्त कार्यान्वयनकर्ता
///
/// [implementors listed below][impls] के अलावा, निम्न प्रकार भी `Clone` को लागू करते हैं:
///
/// * फ़ंक्शन आइटम प्रकार (यानी, प्रत्येक फ़ंक्शन के लिए परिभाषित विशिष्ट प्रकार)
/// * फ़ंक्शन पॉइंटर प्रकार (जैसे, `fn() -> i32`)
/// * सरणी प्रकार, सभी आकारों के लिए, यदि आइटम प्रकार भी `Clone` लागू करता है (जैसे, `[i32; 123456]`)
/// * टपल प्रकार, यदि प्रत्येक घटक `Clone` (जैसे, `()`, `(i32, bool)`) को भी लागू करता है
/// * क्लोजर प्रकार, यदि वे पर्यावरण से कोई मूल्य नहीं लेते हैं या यदि ऐसे सभी कैप्चर किए गए मान स्वयं `Clone` को लागू करते हैं।
///   ध्यान दें कि साझा संदर्भ द्वारा कैप्चर किए गए चर हमेशा `Clone` को लागू करते हैं (भले ही संदर्भ न हो), जबकि परिवर्तनीय संदर्भ द्वारा कैप्चर किए गए चर कभी भी `Clone` को लागू नहीं करते हैं।
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// मूल्य की एक प्रति देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str क्लोन लागू करता है
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` से कॉपी-असाइनमेंट करता है।
    ///
    /// `a.clone_from(&b)` कार्यक्षमता में `a = b.clone()` के बराबर है, लेकिन अनावश्यक आवंटन से बचने के लिए `a` के संसाधनों का पुन: उपयोग करने के लिए इसे ओवरराइड किया जा सकता है।
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` का एक अर्थ उत्पन्न करने वाला मैक्रो व्युत्पन्न करें।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): इन structs का उपयोग केवल#[derive] द्वारा किया जाता है ताकि यह दावा किया जा सके कि एक प्रकार का प्रत्येक घटक क्लोन या कॉपी लागू करता है।
//
//
// ये structs उपयोगकर्ता कोड में कभी नहीं दिखना चाहिए।
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// आदिम प्रकारों के लिए `Clone` का कार्यान्वयन।
///
/// कार्यान्वयन जिन्हें Rust में वर्णित नहीं किया जा सकता है, उन्हें `traits::SelectionContext::copy_clone_conditions()` में `rustc_trait_selection` में कार्यान्वित किया जाता है।
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// साझा संदर्भों को क्लोन किया जा सकता है, लेकिन परिवर्तनीय संदर्भ *नहीं*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// साझा संदर्भों को क्लोन किया जा सकता है, लेकिन परिवर्तनीय संदर्भ *नहीं*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}