use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// संकलक को स्वचालित रूप से `टी` के विनाशक को कॉल करने से रोकने के लिए एक रैपर।
/// यह रैपर 0-लागत का है।
///
/// `ManuallyDrop<T>` `T` के समान लेआउट अनुकूलन के अधीन है।
/// परिणामस्वरूप, इसका संकलक द्वारा अपनी सामग्री के बारे में की गई धारणाओं पर *कोई प्रभाव नहीं* पड़ता है।
/// उदाहरण के लिए, `ManuallyDrop<&mut T>` को [`mem::zeroed`] के साथ प्रारंभ करना अपरिभाषित व्यवहार है।
/// यदि आपको अप्रारंभीकृत डेटा को संभालने की आवश्यकता है, तो इसके बजाय [`MaybeUninit<T>`] का उपयोग करें।
///
/// ध्यान दें कि `ManuallyDrop<T>` के अंदर मान को एक्सेस करना सुरक्षित है।
/// इसका मतलब यह है कि एक `ManuallyDrop<T>` जिसकी सामग्री को हटा दिया गया है, उसे सार्वजनिक सुरक्षित API के माध्यम से उजागर नहीं किया जाना चाहिए।
/// तदनुसार, `ManuallyDrop::drop` असुरक्षित है।
///
/// # `ManuallyDrop` और ड्रॉप ऑर्डर।
///
/// Rust में मूल्यों का एक अच्छी तरह से परिभाषित [drop order] है।
/// यह सुनिश्चित करने के लिए कि फ़ील्ड या स्थानीय लोगों को एक विशिष्ट क्रम में गिराया जाता है, घोषणाओं को इस तरह से पुन: व्यवस्थित करें कि निहित ड्रॉप ऑर्डर सही है।
///
/// ड्रॉप ऑर्डर को नियंत्रित करने के लिए `ManuallyDrop` का उपयोग करना संभव है, लेकिन इसके लिए असुरक्षित कोड की आवश्यकता होती है और अनइंडिंग की उपस्थिति में सही ढंग से करना कठिन होता है।
///
///
/// उदाहरण के लिए, यदि आप यह सुनिश्चित करना चाहते हैं कि एक विशिष्ट फ़ील्ड को अन्य फ़ील्ड के बाद छोड़ दिया जाए, तो इसे किसी स्ट्रक्चर का अंतिम फ़ील्ड बनाएं:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` के बाद छोड़ दिया जाएगा।
///     // Rust गारंटी देता है कि घोषणा के क्रम में फ़ील्ड हटा दिए गए हैं।
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// मैन्युअल रूप से गिराए जाने के लिए एक मान लपेटें।
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // आप अभी भी मूल्य पर सुरक्षित रूप से काम कर सकते हैं
    /// assert_eq!(*x, "Hello");
    /// // लेकिन `Drop` यहां नहीं चलाया जाएगा
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` कंटेनर से मान निकालता है।
    ///
    /// यह मूल्य को फिर से गिराने की अनुमति देता है।
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // यह `Box` को गिरा देता है।
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` कंटेनर से मान निकालता है।
    ///
    /// यह विधि मुख्य रूप से ड्रॉप में मूल्यों को बाहर ले जाने के लिए है।
    /// मान को मैन्युअल रूप से छोड़ने के लिए [`ManuallyDrop::drop`] का उपयोग करने के बजाय, आप इस पद्धति का उपयोग मान लेने के लिए कर सकते हैं और इसका उपयोग वांछित होने पर कर सकते हैं।
    ///
    /// जब भी संभव हो, इसके बजाय [`into_inner`][`ManuallyDrop::into_inner`] का उपयोग करना बेहतर होता है, जो `ManuallyDrop<T>` की सामग्री को डुप्लिकेट करने से रोकता है।
    ///
    ///
    /// # Safety
    ///
    /// यह फ़ंक्शन इस कंटेनर की स्थिति को अपरिवर्तित छोड़कर, आगे के उपयोग को रोकने के बिना निहित मूल्य को अर्थपूर्ण रूप से हटा देता है।
    /// यह सुनिश्चित करना आपकी जिम्मेदारी है कि इस `ManuallyDrop` का दोबारा उपयोग न किया जाए।
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // सुरक्षा: हम एक संदर्भ से पढ़ रहे हैं, जिसकी गारंटी है
        // पढ़ने के लिए मान्य होना।
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// निहित मान को मैन्युअल रूप से छोड़ देता है।यह [`ptr::drop_in_place`] को एक पॉइंटर के साथ निहित मान पर कॉल करने के बराबर है।
    /// जैसे, जब तक निहित मूल्य एक पैक्ड संरचना नहीं है, विनाशक को मूल्य को स्थानांतरित किए बिना इन-प्लेस कहा जाएगा, और इस प्रकार [pinned] डेटा को सुरक्षित रूप से छोड़ने के लिए उपयोग किया जा सकता है।
    ///
    /// यदि आपके पास मूल्य का स्वामित्व है, तो आप इसके बजाय [`ManuallyDrop::into_inner`] का उपयोग कर सकते हैं।
    ///
    /// # Safety
    ///
    /// यह फ़ंक्शन निहित मान के विनाशक को चलाता है।
    /// विनाशक द्वारा किए गए परिवर्तनों के अलावा, स्मृति अपरिवर्तित छोड़ दी गई है, और जहां तक संकलक का संबंध है, अभी भी एक बिट-पैटर्न रखता है जो कि `T` प्रकार के लिए मान्य है।
    ///
    ///
    /// हालांकि, यह "zombie" मान सुरक्षित कोड के संपर्क में नहीं आना चाहिए, और इस फ़ंक्शन को एक से अधिक बार नहीं कहा जाना चाहिए।
    /// किसी मान को छोड़ने के बाद उसका उपयोग करना, या किसी मान को कई बार छोड़ना, अपरिभाषित व्यवहार का कारण बन सकता है (`drop` क्या करता है इसके आधार पर)।
    /// यह आमतौर पर टाइप सिस्टम द्वारा रोका जाता है, लेकिन `ManuallyDrop` के उपयोगकर्ताओं को कंपाइलर की सहायता के बिना उन गारंटी को बनाए रखना चाहिए।
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // सुरक्षा: हम एक परिवर्तनीय संदर्भ द्वारा इंगित मूल्य को छोड़ रहे हैं
        // जो लिखने के लिए मान्य होने की गारंटी है।
        // यह सुनिश्चित करने के लिए कॉलर पर निर्भर है कि `slot` फिर से नहीं छोड़ा गया है।
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}