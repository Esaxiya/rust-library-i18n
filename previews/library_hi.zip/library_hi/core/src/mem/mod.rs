//! स्मृति से निपटने के लिए बुनियादी कार्य।
//!
//! इस मॉड्यूल में प्रकार के आकार और संरेखण को क्वेरी करने, मेमोरी को प्रारंभ करने और हेरफेर करने के लिए कार्य शामिल हैं।
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// मूल्य के बारे में स्वामित्व और "forgets" लेता है **इसके विनाशक को चलाए बिना**।
///
/// कोई भी संसाधन जो मूल्य का प्रबंधन करता है, जैसे कि हीप मेमोरी या फ़ाइल हैंडल, एक अगम्य स्थिति में हमेशा के लिए रुक जाएगा।हालांकि, यह गारंटी नहीं देता है कि इस मेमोरी के पॉइंटर्स वैध रहेंगे।
///
/// * अगर आप मेमोरी लीक करना चाहते हैं, तो [`Box::leak`] देखें।
/// * यदि आप स्मृति के लिए एक कच्चा सूचक प्राप्त करना चाहते हैं, तो [`Box::into_raw`] देखें।
/// * यदि आप किसी मूल्य का ठीक से निपटान करना चाहते हैं, तो इसके विनाशक को चलाकर, [`mem::drop`] देखें।
///
/// # Safety
///
/// `forget` `unsafe` के रूप में चिह्नित नहीं है, क्योंकि Rust की सुरक्षा गारंटी में यह गारंटी शामिल नहीं है कि विनाशक हमेशा चलेंगे।
/// उदाहरण के लिए, एक प्रोग्राम [`Rc`][rc] का उपयोग करके एक संदर्भ चक्र बना सकता है, या विनाशकों को चलाए बिना बाहर निकलने के लिए [`process::exit`][exit] को कॉल कर सकता है।
/// इस प्रकार, `mem::forget` को सुरक्षित कोड से अनुमति देने से Rust की सुरक्षा गारंटी मौलिक रूप से परिवर्तित नहीं होती है।
///
/// उस ने कहा, मेमोरी या I/O ऑब्जेक्ट जैसे संसाधनों को लीक करना आमतौर पर अवांछनीय है।
/// FFI या असुरक्षित कोड के लिए कुछ विशेष उपयोग के मामलों में आवश्यकता सामने आती है, लेकिन फिर भी, [`ManuallyDrop`] को आमतौर पर पसंद किया जाता है।
///
/// क्योंकि किसी मान को भूलने की अनुमति है, आपके द्वारा लिखे गए किसी भी `unsafe` कोड को इस संभावना की अनुमति देनी चाहिए।आप एक मूल्य वापस नहीं कर सकते हैं और उम्मीद करते हैं कि कॉलर आवश्यक रूप से मूल्य के विनाशक को चलाएगा।
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` का विहित सुरक्षित उपयोग `Drop` trait द्वारा लागू किए गए मान के विध्वंसक को दरकिनार करना है।उदाहरण के लिए, यह एक `File` को लीक करेगा, अर्थात
/// चर द्वारा लिए गए स्थान को पुनः प्राप्त करें लेकिन अंतर्निहित सिस्टम संसाधन को कभी भी बंद न करें:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// यह तब उपयोगी होता है जब अंतर्निहित संसाधन का स्वामित्व पहले Rust के बाहर कोड में स्थानांतरित किया गया था, उदाहरण के लिए कच्ची फ़ाइल डिस्क्रिप्टर को C कोड में स्थानांतरित करके।
///
/// # `ManuallyDrop` के साथ संबंध
///
/// जबकि `mem::forget` का उपयोग *मेमोरी* स्वामित्व को स्थानांतरित करने के लिए भी किया जा सकता है, ऐसा करना त्रुटि-प्रवण है।
/// [`ManuallyDrop`] की जगह इस्तेमाल किया जाना चाहिए।उदाहरण के लिए, इस कोड पर विचार करें:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` की सामग्री का उपयोग करके `String` बनाएं
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // `v` को लीक करें क्योंकि इसकी मेमोरी अब `s` द्वारा प्रबंधित की जाती है
/// mem::forget(v);  // त्रुटि, v अमान्य है और इसे किसी फ़ंक्शन में पास नहीं किया जाना चाहिए
/// assert_eq!(s, "Az");
/// // `s` परोक्ष रूप से गिरा दिया गया है और इसकी स्मृति हटा दी गई है।
/// ```
///
/// उपरोक्त उदाहरण के साथ दो मुद्दे हैं:
///
/// * यदि `String` के निर्माण और `mem::forget()` के आह्वान के बीच अधिक कोड जोड़े गए, तो इसके भीतर एक panic एक डबल फ्री का कारण होगा क्योंकि एक ही मेमोरी को `v` और `s` दोनों द्वारा नियंत्रित किया जाता है।
/// * `v.as_mut_ptr()` को कॉल करने और डेटा के स्वामित्व को `s` पर ट्रांसमिट करने के बाद, `v` मान अमान्य है।
/// यहां तक कि जब कोई मान केवल `mem::forget` (जो इसका निरीक्षण नहीं करेगा) में ले जाया जाता है, तो कुछ प्रकारों की उनके मूल्यों पर सख्त आवश्यकताएं होती हैं जो लटकने या अब स्वामित्व में नहीं होने पर उन्हें अमान्य बनाती हैं।
/// किसी भी तरह से अमान्य मानों का उपयोग करना, जिसमें उन्हें पास करना या उन्हें कार्यों से वापस करना शामिल है, अपरिभाषित व्यवहार का गठन करता है और संकलक द्वारा की गई धारणाओं को तोड़ सकता है।
///
/// `ManuallyDrop` पर स्विच करने से दोनों मुद्दों से बचा जा सकता है:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // इससे पहले कि हम `v` को इसके कच्चे भागों में अलग करें, सुनिश्चित करें कि यह गिरा नहीं है!
/////
/// let mut v = ManuallyDrop::new(v);
/// // अब `v` को अलग करें।ये ऑपरेशन panic नहीं कर सकते हैं, इसलिए कोई रिसाव नहीं हो सकता है।
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // अंत में, एक `String` बनाएं।
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` परोक्ष रूप से गिरा दिया गया है और इसकी स्मृति हटा दी गई है।
/// ```
///
/// `ManuallyDrop` डबल-फ्री को मजबूती से रोकता है क्योंकि हम कुछ और करने से पहले `v` के विनाशक को अक्षम करते हैं।
/// `mem::forget()` इसकी अनुमति नहीं देता क्योंकि यह अपने तर्क का उपभोग करता है, हमें `v` से कुछ भी निकालने के बाद ही इसे कॉल करने के लिए मजबूर करता है।
/// भले ही `ManuallyDrop` के निर्माण और स्ट्रिंग के निर्माण के बीच एक panic पेश किया गया था (जो दिखाए गए कोड में नहीं हो सकता है), इसके परिणामस्वरूप एक रिसाव होगा और डबल फ्री नहीं होगा।
/// दूसरे शब्दों में, `ManuallyDrop` (डबल-) ड्रॉपिंग के पक्ष में गलती करने के बजाय लीक होने की तरफ गलती करता है।
///
/// इसके अलावा, `ManuallyDrop` हमें `s` को स्वामित्व स्थानांतरित करने के बाद "touch" `v` होने से रोकता है-इसके विनाशक को चलाए बिना इसे निपटाने के लिए `v` के साथ बातचीत करने का अंतिम चरण पूरी तरह से टाला जाता है।
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] की तरह, लेकिन अनसाइज़ किए गए मानों को भी स्वीकार करता है।
///
/// जब `unsized_locals` सुविधा स्थिर हो जाती है तो यह फ़ंक्शन केवल एक शिम को हटाने का इरादा रखता है।
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// बाइट्स में एक प्रकार का आकार देता है।
///
/// अधिक विशेष रूप से, यह संरेखण पैडिंग सहित उस आइटम प्रकार के साथ सरणी में लगातार तत्वों के बीच बाइट्स में ऑफ़सेट है।
///
/// इस प्रकार, किसी भी प्रकार के `T` और लंबाई `n` के लिए, `[T; n]` का आकार `n * size_of::<T>()` है।
///
/// सामान्य तौर पर, एक प्रकार का आकार संकलनों में स्थिर नहीं होता है, लेकिन विशिष्ट प्रकार जैसे कि आदिम हैं।
///
/// निम्न तालिका आदिम के लिए आकार देती है।
///
/// प्रकार |का आकार: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |१ एक्स०१एक्स |2 u32 |4 u64 |8 यू128 |16 i8 |१ एक्स०५एक्स |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 चार |4
///
/// इसके अलावा, `usize` और `isize` का आकार समान है।
///
/// प्रकार `*const T`, `&T`, `Box<T>`, `Option<&T>`, और `Option<Box<T>>` सभी का आकार समान है।
/// यदि `T` का आकार है, तो उन सभी प्रकारों का आकार `usize` के समान है।
///
/// एक सूचक की परिवर्तनशीलता इसके आकार को नहीं बदलती है।जैसे, `&T` और `&mut T` का आकार समान है।
/// इसी तरह `*const T` और `* mut T` के लिए।
///
/// # `#[repr(C)]` आइटम का आकार
///
/// आइटम के लिए `C` प्रतिनिधित्व में एक परिभाषित लेआउट है।
/// इस लेआउट के साथ, आइटम का आकार भी तब तक स्थिर रहता है जब तक सभी फ़ील्ड का आकार स्थिर होता है।
///
/// ## संरचनाओं का आकार
///
/// `structs` के लिए, आकार निम्न एल्गोरिथम द्वारा निर्धारित किया जाता है।
///
/// घोषणा आदेश द्वारा आदेशित संरचना में प्रत्येक क्षेत्र के लिए:
///
/// 1. फ़ील्ड का आकार जोड़ें।
/// 2. वर्तमान आकार को अगले फ़ील्ड के [alignment] के निकटतम गुणक में गोल करें।
///
/// अंत में, संरचना के आकार को उसके [alignment] के निकटतम गुणज में गोल करें।
/// संरचना का संरेखण आमतौर पर इसके सभी क्षेत्रों का सबसे बड़ा संरेखण होता है;इसे `repr(align(N))` के उपयोग से बदला जा सकता है।
///
/// `C` के विपरीत, शून्य आकार की संरचनाएँ आकार में एक बाइट तक गोल नहीं होती हैं।
///
/// ## Enums का आकार
///
/// एनम जो कि विवेचक के अलावा कोई डेटा नहीं रखते हैं, उनका आकार उसी प्लेटफॉर्म पर सी एनम के समान होता है, जिसके लिए उन्हें संकलित किया जाता है।
///
/// ## यूनियनों का आकार
///
/// संघ का आकार उसके सबसे बड़े क्षेत्र का आकार है।
///
/// `C` के विपरीत, शून्य आकार की यूनियनें आकार में एक बाइट तक गोल नहीं होती हैं।
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // कुछ आदिम
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // कुछ सरणियाँ
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // सूचक आकार समानता
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` का उपयोग करना।
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // पहले फ़ील्ड का आकार 1 है, इसलिए आकार में 1 जोड़ें।आकार 1 है।
/// // दूसरे क्षेत्र का संरेखण 2 है, इसलिए पैडिंग के लिए आकार में 1 जोड़ें।आकार 2 है।
/// // दूसरी फ़ील्ड का आकार 2 है, इसलिए आकार में 2 जोड़ें।आकार 4 है।
/// // तीसरे क्षेत्र का संरेखण 1 है, इसलिए पैडिंग के आकार में 0 जोड़ें।आकार 4 है।
/// // तीसरे क्षेत्र का आकार 1 है, इसलिए आकार में 1 जोड़ें।आकार 5 है।
/// // अंत में, संरचना का संरेखण 2 है (क्योंकि इसके क्षेत्रों में सबसे बड़ा संरेखण 2 है), इसलिए पैडिंग के लिए आकार में 1 जोड़ें।
/// // आकार 6 है।
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs समान नियमों का पालन करते हैं।
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // ध्यान दें कि फ़ील्ड को फिर से व्यवस्थित करने से आकार कम हो सकता है।
/// // हम `second` से पहले `third` लगाकर दोनों पैडिंग बाइट्स को हटा सकते हैं।
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // संघ का आकार सबसे बड़े क्षेत्र का आकार है।
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// बाइट्स में पॉइंट-टू मान का आकार देता है।
///
/// यह आमतौर पर `size_of::<T>()` जैसा ही होता है।
/// हालांकि, जब `T`*में* कोई सांख्यिकीय रूप से ज्ञात आकार नहीं है, उदाहरण के लिए, एक टुकड़ा [`[T]`][slice] या [trait object], तो `size_of_val` का उपयोग गतिशील रूप से ज्ञात आकार प्राप्त करने के लिए किया जा सकता है।
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // सुरक्षा: `val` एक संदर्भ है, इसलिए यह एक वैध कच्चा सूचक है
    unsafe { intrinsics::size_of_val(val) }
}

/// बाइट्स में पॉइंट-टू मान का आकार देता है।
///
/// यह आमतौर पर `size_of::<T>()` जैसा ही होता है।हालांकि, जब `T`*में* कोई सांख्यिकीय रूप से ज्ञात आकार नहीं है, उदाहरण के लिए, एक टुकड़ा [`[T]`][slice] या [trait object], तो गतिशील रूप से ज्ञात आकार प्राप्त करने के लिए `size_of_val_raw` का उपयोग किया जा सकता है।
///
/// # Safety
///
/// यह फ़ंक्शन कॉल करने के लिए केवल तभी सुरक्षित है जब निम्न शर्तें लागू हों:
///
/// - यदि `T` `Sized` है, तो यह फ़ंक्शन कॉल करने के लिए हमेशा सुरक्षित है।
/// - यदि `T` की अनसाइज़्ड टेल है:
///     - एक [slice], तो स्लाइस टेल की लंबाई एक आरंभिक पूर्णांक होना चाहिए, और *संपूर्ण मान*(डायनेमिक टेल लेंथ + स्टेटिकली साइज़ प्रीफ़िक्स) का आकार `isize` में फ़िट होना चाहिए।
///     - एक [trait object], तो सूचक के vtable भाग को एक अनसाइज़िंग ज़बरदस्ती द्वारा प्राप्त एक मान्य vtable को इंगित करना चाहिए, और *संपूर्ण मान*(डायनेमिक टेल लेंथ + स्टेटिकली साइज़ प्रीफ़िक्स) का आकार `isize` में फ़िट होना चाहिए।
///
///     - एक (unstable) [extern type], तो यह फ़ंक्शन कॉल करने के लिए हमेशा सुरक्षित है, लेकिन panic या अन्यथा गलत मान लौटा सकता है, क्योंकि बाहरी प्रकार का लेआउट ज्ञात नहीं है।
///     यह बाहरी प्रकार की पूंछ वाले प्रकार के संदर्भ में [`size_of_val`] जैसा ही व्यवहार है।
///     - अन्यथा, परंपरागत रूप से इस फ़ंक्शन को कॉल करने की अनुमति नहीं है।
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // सुरक्षा: कॉलर को एक वैध कच्चा सूचक प्रदान करना होगा
    unsafe { intrinsics::size_of_val(val) }
}

/// एक प्रकार का [ABI]-आवश्यक न्यूनतम संरेखण लौटाता है।
///
/// `T` प्रकार के मान का प्रत्येक संदर्भ इस संख्या का गुणज होना चाहिए।
///
/// यह संरचना क्षेत्रों के लिए उपयोग किया जाने वाला संरेखण है।यह पसंदीदा संरेखण से छोटा हो सकता है।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` द्वारा इंगित मान के प्रकार का [ABI]-आवश्यक न्यूनतम संरेखण लौटाता है।
///
/// `T` प्रकार के मान का प्रत्येक संदर्भ इस संख्या का गुणज होना चाहिए।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // सुरक्षा: वैल एक संदर्भ है, इसलिए यह एक वैध कच्चा सूचक है
    unsafe { intrinsics::min_align_of_val(val) }
}

/// एक प्रकार का [ABI]-आवश्यक न्यूनतम संरेखण लौटाता है।
///
/// `T` प्रकार के मान का प्रत्येक संदर्भ इस संख्या का गुणज होना चाहिए।
///
/// यह संरचना क्षेत्रों के लिए उपयोग किया जाने वाला संरेखण है।यह पसंदीदा संरेखण से छोटा हो सकता है।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` द्वारा इंगित मान के प्रकार का [ABI]-आवश्यक न्यूनतम संरेखण लौटाता है।
///
/// `T` प्रकार के मान का प्रत्येक संदर्भ इस संख्या का गुणज होना चाहिए।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // सुरक्षा: वैल एक संदर्भ है, इसलिए यह एक वैध कच्चा सूचक है
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val` द्वारा इंगित मान के प्रकार का [ABI]-आवश्यक न्यूनतम संरेखण लौटाता है।
///
/// `T` प्रकार के मान का प्रत्येक संदर्भ इस संख्या का गुणज होना चाहिए।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// यह फ़ंक्शन कॉल करने के लिए केवल तभी सुरक्षित है जब निम्न शर्तें लागू हों:
///
/// - यदि `T` `Sized` है, तो यह फ़ंक्शन कॉल करने के लिए हमेशा सुरक्षित है।
/// - यदि `T` की अनसाइज़्ड टेल है:
///     - एक [slice], तो स्लाइस टेल की लंबाई एक आरंभिक पूर्णांक होना चाहिए, और *संपूर्ण मान*(डायनेमिक टेल लेंथ + स्टेटिकली साइज़ प्रीफ़िक्स) का आकार `isize` में फ़िट होना चाहिए।
///     - एक [trait object], तो सूचक के vtable भाग को एक अनसाइज़िंग ज़बरदस्ती द्वारा प्राप्त एक मान्य vtable को इंगित करना चाहिए, और *संपूर्ण मान*(डायनेमिक टेल लेंथ + स्टेटिकली साइज़ प्रीफ़िक्स) का आकार `isize` में फ़िट होना चाहिए।
///
///     - एक (unstable) [extern type], तो यह फ़ंक्शन कॉल करने के लिए हमेशा सुरक्षित है, लेकिन panic या अन्यथा गलत मान लौटा सकता है, क्योंकि बाहरी प्रकार का लेआउट ज्ञात नहीं है।
///     यह बाहरी प्रकार की पूंछ वाले प्रकार के संदर्भ में [`align_of_val`] जैसा ही व्यवहार है।
///     - अन्यथा, परंपरागत रूप से इस फ़ंक्शन को कॉल करने की अनुमति नहीं है।
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // सुरक्षा: कॉलर को एक वैध कच्चा सूचक प्रदान करना होगा
    unsafe { intrinsics::min_align_of_val(val) }
}

/// यदि `T` प्रकार के मानों को छोड़ना मायने रखता है तो `true` लौटाता है।
///
/// यह विशुद्ध रूप से एक अनुकूलन संकेत है, और इसे रूढ़िवादी रूप से लागू किया जा सकता है:
/// यह उन प्रकारों के लिए `true` लौटा सकता है जिन्हें वास्तव में छोड़ने की आवश्यकता नहीं है।
/// जैसे कि हमेशा `true` लौटाना इस फ़ंक्शन का एक वैध कार्यान्वयन होगा।हालाँकि यदि यह फ़ंक्शन वास्तव में `false` लौटाता है, तो आप निश्चित हो सकते हैं कि `T` को छोड़ने का कोई दुष्प्रभाव नहीं है।
///
/// संग्रह जैसी चीजों के निम्न स्तर के कार्यान्वयन, जिन्हें अपने डेटा को मैन्युअल रूप से छोड़ने की आवश्यकता होती है, इस फ़ंक्शन का उपयोग अनावश्यक रूप से नष्ट होने पर उनकी सभी सामग्री को छोड़ने की कोशिश करने से बचने के लिए करना चाहिए।
///
/// इससे रिलीज़ बिल्ड में कोई फर्क नहीं पड़ सकता है (जहां एक लूप जिसका कोई साइड-इफेक्ट नहीं है, आसानी से पता लगाया और समाप्त किया जाता है), लेकिन अक्सर डिबग बिल्ड के लिए एक बड़ी जीत होती है।
///
/// ध्यान दें कि [`drop_in_place`] पहले से ही यह जांच करता है, इसलिए यदि आपका कार्यभार कुछ छोटी संख्या में [`drop_in_place`] कॉल तक कम किया जा सकता है, तो इसका उपयोग करना अनावश्यक है।
/// विशेष रूप से ध्यान दें कि आप एक टुकड़ा [`drop_in_place`] कर सकते हैं, और वह सभी मानों के लिए एक ही आवश्यकता_ड्रॉप जांच करेगा।
///
/// Vec जैसे प्रकार इसलिए स्पष्ट रूप से `needs_drop` का उपयोग किए बिना सिर्फ `drop_in_place(&mut self[..])`।
/// दूसरी ओर, [`HashMap`] जैसे प्रकारों को एक बार में एक मान छोड़ना पड़ता है और इस API का उपयोग करना चाहिए।
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// यहां एक उदाहरण दिया गया है कि कैसे एक संग्रह `needs_drop` का उपयोग कर सकता है:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // डेटा ड्रॉप करें
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// सभी-शून्य बाइट-पैटर्न द्वारा दर्शाए गए प्रकार `T` का मान लौटाता है।
///
/// इसका मतलब यह है कि, उदाहरण के लिए, `(u8, u16)` में पैडिंग बाइट अनिवार्य रूप से शून्य नहीं है।
///
/// इस बात की कोई गारंटी नहीं है कि सभी-शून्य बाइट-पैटर्न किसी प्रकार के `T` के मान्य मान का प्रतिनिधित्व करता है।
/// उदाहरण के लिए, सभी-शून्य बाइट-पैटर्न संदर्भ प्रकारों (`&T`, `&mut T`) और फ़ंक्शन पॉइंटर्स के लिए मान्य मान नहीं है।
/// इस तरह के प्रकारों पर `zeroed` का उपयोग तत्काल [undefined behavior][ub] का कारण बनता है क्योंकि [the Rust compiler assumes][inv] कि एक वैरिएबल में हमेशा एक वैध मान होता है जिसे वह आरंभीकृत मानता है।
///
///
/// यह [`MaybeUninit::zeroed().assume_init()`][zeroed] के समान प्रभाव डालता है।
/// यह कभी-कभी एफएफआई के लिए उपयोगी होता है, लेकिन आम तौर पर इससे बचा जाना चाहिए।
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// इस फ़ंक्शन का सही उपयोग: शून्य के साथ एक पूर्णांक प्रारंभ करना।
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *गलत* इस फ़ंक्शन का उपयोग: शून्य के साथ एक संदर्भ प्रारंभ करना।
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // अपरिभाषित व्यवहार!
/// let _y: fn() = unsafe { mem::zeroed() }; // और फिर!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // सुरक्षा: कॉल करने वाले को यह गारंटी देनी चाहिए कि `T` के लिए एक पूर्ण-शून्य मान मान्य है।
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Rust की सामान्य मेमोरी-इनिशियलाइज़ेशन जाँच को `T` प्रकार का मान उत्पन्न करने का नाटक करते हुए, कुछ भी नहीं करते हुए बायपास करता है।
///
/// **यह फ़ंक्शन बहिष्कृत है।** इसके बजाय [`MaybeUninit<T>`] का उपयोग करें।
///
/// बहिष्करण का कारण यह है कि फ़ंक्शन का मूल रूप से सही ढंग से उपयोग नहीं किया जा सकता है: इसका [`MaybeUninit::uninit().assume_init()`][uninit] जैसा ही प्रभाव है।
///
/// जैसा कि [`assume_init` documentation][assume_init] बताता है, [the Rust compiler assumes][inv] कि मान ठीक से प्रारंभ किए गए हैं।
/// परिणामस्वरूप, कॉलिंग उदा
/// `mem::uninitialized::<bool>()` `bool` को वापस करने के लिए तत्काल अपरिभाषित व्यवहार का कारण बनता है जो निश्चित रूप से `true` या `false` नहीं है।
/// इससे भी बदतर, वास्तव में अनियमित स्मृति जैसे कि यहां क्या लौटाया जाता है, यह विशेष है कि संकलक जानता है कि इसका कोई निश्चित मूल्य नहीं है।
/// यह एक चर में अप्रारंभीकृत डेटा रखने के लिए अपरिभाषित व्यवहार बनाता है, भले ही उस चर का पूर्णांक प्रकार हो।
/// (ध्यान दें कि गैर-आरंभिक पूर्णांकों के आसपास के नियमों को अभी तक अंतिम रूप नहीं दिया गया है, लेकिन जब तक वे हैं, उनसे बचना उचित है।)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि एक प्रारंभिक मान `T` के लिए मान्य है।
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// किसी एक को इनिशियलाइज़ किए बिना दो परिवर्तनशील स्थानों पर मानों की अदला-बदली करें।
///
/// * यदि आप डिफ़ॉल्ट या डमी मान के साथ स्वैप करना चाहते हैं, तो [`take`] देखें।
/// * यदि आप पुराने मान को वापस करते हुए पारित मान के साथ अदला-बदली करना चाहते हैं, तो [`replace`] देखें।
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // सुरक्षा: कच्चे पॉइंटर्स सभी को संतुष्ट करने वाले सुरक्षित परिवर्तनीय संदर्भों से बनाए गए हैं
    // `ptr::swap_nonoverlapping_one`. पर बाधाएं
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` को `T` के डिफ़ॉल्ट मान से बदल देता है, पिछला `dest` मान लौटाता है।
///
/// * यदि आप दो चरों के मानों को बदलना चाहते हैं, तो [`swap`] देखें।
/// * यदि आप डिफ़ॉल्ट मान के बजाय किसी पारित मान से प्रतिस्थापित करना चाहते हैं, तो [`replace`] देखें।
///
/// # Examples
///
/// एक साधारण उदाहरण:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` किसी स्ट्रक्चर फ़ील्ड को "empty" मान से बदलकर उसका स्वामित्व लेने की अनुमति देता है।
/// `take` के बिना आप इस तरह के मुद्दों में भाग सकते हैं:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// ध्यान दें कि `T` अनिवार्य रूप से [`Clone`] को लागू नहीं करता है, इसलिए यह `self.buf` को क्लोन और रीसेट भी नहीं कर सकता है।
/// लेकिन `take` का उपयोग `self.buf` के मूल मान को `self` से अलग करने के लिए किया जा सकता है, जिससे इसे वापस किया जा सकता है:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` को संदर्भित `dest` में ले जाता है, पिछला `dest` मान लौटाता है।
///
/// न तो मूल्य गिरा है।
///
/// * यदि आप दो चरों के मानों को बदलना चाहते हैं, तो [`swap`] देखें।
/// * यदि आप किसी डिफ़ॉल्ट मान से प्रतिस्थापित करना चाहते हैं, तो [`take`] देखें।
///
/// # Examples
///
/// एक साधारण उदाहरण:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` एक संरचना क्षेत्र की खपत को दूसरे मूल्य के साथ बदलकर अनुमति देता है।
/// `replace` के बिना आप इस तरह के मुद्दों में भाग सकते हैं:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// ध्यान दें कि `T` अनिवार्य रूप से [`Clone`] को लागू नहीं करता है, इसलिए हम इस कदम से बचने के लिए `self.buf[i]` का क्लोन भी नहीं बना सकते हैं।
/// लेकिन `replace` का उपयोग उस इंडेक्स पर मूल मान को `self` से अलग करने के लिए किया जा सकता है, जिससे इसे वापस किया जा सकता है:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // सुरक्षा: हम `dest` से पढ़ते हैं लेकिन बाद में इसमें सीधे `src` लिखते हैं,
    // ताकि पुराना मान दोहराया न जाए।
    // कुछ भी नहीं गिरा है और यहाँ कुछ भी panic नहीं हो सकता है।
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// एक मूल्य का निपटान।
///
/// यह तर्क के [`Drop`][drop] के कार्यान्वयन को कॉल करके ऐसा करता है।
///
/// यह प्रभावी रूप से उन प्रकारों के लिए कुछ नहीं करता है जो `Copy` को लागू करते हैं, उदाहरण के लिए
/// integers.
/// ऐसे मान कॉपी किए जाते हैं और _then_ फ़ंक्शन में चले जाते हैं, इसलिए इस फ़ंक्शन कॉल के बाद मान बना रहता है।
///
///
/// यह फ़ंक्शन जादू नहीं है;इसे शाब्दिक रूप से परिभाषित किया गया है
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// चूंकि `_x` को फ़ंक्शन में ले जाया जाता है, इसलिए फ़ंक्शन के वापस आने से पहले इसे स्वचालित रूप से हटा दिया जाता है।
///
/// [drop]: Drop
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // vector को स्पष्ट रूप से छोड़ें
/// ```
///
/// चूंकि [`RefCell`] रनटाइम पर उधार नियमों को लागू करता है, `drop` एक [`RefCell`] उधार जारी कर सकता है:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // इस स्लॉट पर परिवर्तनीय उधार को त्यागें
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// [`Copy`] को लागू करने वाले पूर्णांक और अन्य प्रकार `drop` से अप्रभावित रहते हैं।
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` की एक प्रति को स्थानांतरित और गिराया जाता है
/// drop(y); // `y` की एक प्रति को स्थानांतरित और गिराया जाता है
///
/// println!("x: {}, y: {}", x, y.0); // अभी भी उपलब्ध
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` को `&U` टाइप करने के रूप में व्याख्या करता है, और उसके बाद निहित मान को स्थानांतरित किए बिना `src` पढ़ता है।
///
/// यह फ़ंक्शन असुरक्षित रूप से मान लेगा कि पॉइंटर `src` `&T` को `&U` में ट्रांसमिट करके और फिर `&U` को पढ़कर [`size_of::<U>`][size_of] बाइट्स के लिए मान्य है (सिवाय इसके कि यह इस तरह से किया जाता है कि `&U` `&T` की तुलना में सख्त संरेखण आवश्यकताओं को पूरा करता है)।
/// यह `src` से बाहर जाने के बजाय असुरक्षित रूप से निहित मूल्य की एक प्रति भी बनाएगा।
///
/// यदि `T` और `U` के अलग-अलग आकार हैं, तो यह संकलन-समय की त्रुटि नहीं है, लेकिन केवल इस फ़ंक्शन को लागू करने के लिए अत्यधिक प्रोत्साहित किया जाता है जहां `T` और `U` का आकार समान होता है।यदि `U`, `T` से बड़ा है, तो यह फ़ंक्शन [undefined behavior][ub] को ट्रिगर करता है।
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array' से डेटा कॉपी करें और इसे 'Foo' के रूप में मानें
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // कॉपी किए गए डेटा को संशोधित करें
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' की सामग्री नहीं बदलनी चाहिए थी
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // यदि U की संरेखण आवश्यकता अधिक है, तो src उपयुक्त रूप से संरेखित नहीं हो सकता है।
    if align_of::<U>() > align_of::<T>() {
        // सुरक्षा: `src` एक संदर्भ है जो पढ़ने के लिए मान्य होने की गारंटी है।
        // कॉल करने वाले को यह गारंटी देनी चाहिए कि वास्तविक रूपांतरण सुरक्षित है।
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // सुरक्षा: `src` एक संदर्भ है जो पढ़ने के लिए मान्य होने की गारंटी है।
        // हमने अभी जाँच की है कि `src as *const U` ठीक से संरेखित है।
        // कॉल करने वाले को यह गारंटी देनी चाहिए कि वास्तविक रूपांतरण सुरक्षित है।
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// अपारदर्शी प्रकार एक एनम के विवेचक का प्रतिनिधित्व करता है।
///
/// अधिक जानकारी के लिए इस मॉड्यूल में [`discriminant`] फ़ंक्शन देखें।
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. ये trait कार्यान्वयन प्राप्त नहीं किए जा सकते क्योंकि हम T पर कोई सीमा नहीं चाहते हैं।

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` में विशिष्ट रूप से एनम वैरिएंट की पहचान करने वाला मान लौटाता है।
///
/// यदि `T` एक एनम नहीं है, तो इस फ़ंक्शन को कॉल करने से अपरिभाषित व्यवहार नहीं होगा, लेकिन वापसी मान अनिर्दिष्ट है।
///
///
/// # Stability
///
/// यदि एनम परिभाषा में परिवर्तन होता है तो एनम वैरिएंट का विवेचक बदल सकता है।
/// एक ही कंपाइलर के साथ संकलन के बीच कुछ प्रकार का भेदभाव नहीं बदलेगा।
///
/// # Examples
///
/// इसका उपयोग वास्तविक डेटा की अवहेलना करते हुए डेटा ले जाने वाले एनम की तुलना करने के लिए किया जा सकता है:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Enum प्रकार `T` में वेरिएंट की संख्या लौटाता है।
///
/// यदि `T` एक एनम नहीं है, तो इस फ़ंक्शन को कॉल करने से अपरिभाषित व्यवहार नहीं होगा, लेकिन वापसी मान अनिर्दिष्ट है।
/// समान रूप से, यदि `T`, `usize::MAX` से अधिक वेरिएंट वाला एक एनम है, तो रिटर्न वैल्यू अनिर्दिष्ट है।
/// निर्जन प्रकारों की गणना की जाएगी।
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}