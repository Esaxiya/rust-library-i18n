use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` के गैर-आरंभिक उदाहरणों के निर्माण के लिए एक आवरण प्रकार।
///
/// # आरंभीकरण अपरिवर्तनीय
///
/// संकलक, सामान्य रूप से, मानता है कि चर के प्रकार की आवश्यकताओं के अनुसार एक चर को ठीक से प्रारंभ किया गया है।उदाहरण के लिए, संदर्भ प्रकार का एक चर संरेखित और गैर-नल होना चाहिए।
/// यह एक अपरिवर्तनीय है जिसे असुरक्षित कोड में भी *हमेशा* बरकरार रखा जाना चाहिए।
/// एक परिणाम के रूप में, संदर्भ प्रकार के एक चर को शून्य-प्रारंभ करना तात्कालिक [undefined behavior][ub] का कारण बनता है, चाहे वह संदर्भ कभी भी स्मृति तक पहुंचने के लिए उपयोग किया जाता हो:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // अपरिभाषित व्यवहार!️
/// // `MaybeUninit<&i32>` के साथ समतुल्य कोड:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // अपरिभाषित व्यवहार!️
/// ```
///
/// इसका उपयोग कंपाइलर द्वारा विभिन्न अनुकूलन के लिए किया जाता है, जैसे रन-टाइम चेक को खत्म करना और `enum` लेआउट को अनुकूलित करना।
///
/// इसी तरह, पूरी तरह से अप्रारंभीकृत मेमोरी में कोई भी सामग्री हो सकती है, जबकि `bool` हमेशा `true` या `false` होना चाहिए।इसलिए, एक अप्रारंभीकृत `bool` बनाना अपरिभाषित व्यवहार है:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // अपरिभाषित व्यवहार!️
/// // `MaybeUninit<bool>` के साथ समतुल्य कोड:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // अपरिभाषित व्यवहार!️
/// ```
///
/// इसके अलावा, अप्रारंभीकृत स्मृति इस मायने में विशेष है कि इसका कोई निश्चित मान नहीं है ("fixed" अर्थ "it won't change without being written to")।एक ही गैर-आरंभिक बाइट को कई बार पढ़ना अलग-अलग परिणाम दे सकता है।
/// यह अपरिभाषित व्यवहार को एक चर में प्रारंभिक डेटा रखने के लिए बनाता है, भले ही उस चर के पास एक पूर्णांक प्रकार हो, जो अन्यथा किसी भी *निश्चित* बिट पैटर्न को पकड़ सकता है:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // अपरिभाषित व्यवहार!️
/// // `MaybeUninit<i32>` के साथ समतुल्य कोड:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // अपरिभाषित व्यवहार!️
/// ```
/// (ध्यान दें कि गैर-आरंभिक पूर्णांकों के आसपास के नियमों को अभी तक अंतिम रूप नहीं दिया गया है, लेकिन जब तक वे हैं, उनसे बचना उचित है।)
///
/// इसके शीर्ष पर, याद रखें कि अधिकांश प्रकारों में अतिरिक्त इनवेरिएंट होते हैं जिन्हें केवल प्रकार के स्तर पर आरंभिक माना जाता है।
/// उदाहरण के लिए, एक `1`-प्रारंभिक [`Vec<T>`] को आरंभीकृत माना जाता है (वर्तमान कार्यान्वयन के तहत; यह एक स्थिर गारंटी का गठन नहीं करता है) क्योंकि संकलक को इसके बारे में केवल एक ही आवश्यकता है कि डेटा पॉइंटर गैर-शून्य होना चाहिए।
/// ऐसा `Vec<T>` बनाने से *तत्काल* अपरिभाषित व्यवहार नहीं होता है, लेकिन अधिकांश सुरक्षित संचालन (इसे छोड़ने सहित) के साथ अपरिभाषित व्यवहार का कारण होगा।
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` अप्रारंभीकृत डेटा से निपटने के लिए असुरक्षित कोड को सक्षम करने का कार्य करता है।
/// यह संकलक के लिए एक संकेत है जो दर्शाता है कि यहां डेटा *नहीं* प्रारंभ किया जा सकता है:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // एक स्पष्ट रूप से अप्रारंभीकृत संदर्भ बनाएं।
/// // कंपाइलर जानता है कि `MaybeUninit<T>` के अंदर डेटा अमान्य हो सकता है, और इसलिए यह UB नहीं है:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // इसे मान्य मान पर सेट करें।
/// unsafe { x.as_mut_ptr().write(&0); }
/// // इनिशियलाइज़्ड डेटा एक्सट्रेक्ट करें--इसकी अनुमति केवल *के बाद* ठीक से `x` को इनिशियलाइज़ करने के लिए है!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// संकलक तब इस कोड पर कोई गलत धारणा या अनुकूलन नहीं करना जानता है।
///
/// आप `MaybeUninit<T>` को `Option<T>` जैसा ही मान सकते हैं, लेकिन बिना किसी रन-टाइम ट्रैकिंग के और बिना किसी सुरक्षा जांच के।
///
/// ## out-pointers
///
/// आप "out-pointers" को लागू करने के लिए `MaybeUninit<T>` का उपयोग कर सकते हैं: किसी फ़ंक्शन से डेटा वापस करने के बजाय, परिणाम को डालने के लिए इसे कुछ (uninitialized) मेमोरी में पॉइंटर पास करें।
/// यह तब उपयोगी हो सकता है जब कॉल करने वाले के लिए यह नियंत्रित करना महत्वपूर्ण हो कि परिणाम में संग्रहीत मेमोरी कैसे आवंटित की जाती है, और आप अनावश्यक चालों से बचना चाहते हैं।
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` पुरानी सामग्री को नहीं छोड़ता है, जो महत्वपूर्ण है।
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // अब हम जानते हैं कि `v` को इनिशियलाइज़ किया गया है!यह भी सुनिश्चित करता है कि vector ठीक से गिरा हो।
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## एक सरणी तत्व-दर-तत्व प्रारंभ करना
///
/// `MaybeUninit<T>` एक बड़े सरणी तत्व-दर-तत्व को प्रारंभ करने के लिए इस्तेमाल किया जा सकता है:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` की एक अप्रारंभीकृत सरणी बनाएं।
///     // `assume_init` सुरक्षित है क्योंकि जिस प्रकार का हम यहां इनिशियलाइज़ करने का दावा कर रहे हैं, वह `MaybeUninit` का एक गुच्छा है, जिसे इनिशियलाइज़ करने की आवश्यकता नहीं है।
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` को छोड़ने से कुछ नहीं होता है।
///     // इस प्रकार `ptr::write` के बजाय कच्चे पॉइंटर असाइनमेंट का उपयोग करने से पुराने अप्रारंभीकृत मान को गिराया नहीं जाता है।
/////
///     // इसके अलावा अगर इस लूप के दौरान panic है, तो हमारे पास मेमोरी लीक है, लेकिन कोई मेमोरी सुरक्षा समस्या नहीं है।
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // सब कुछ इनिशियलाइज़ किया गया है।
///     // सरणी को आरंभिक प्रकार में परिवर्तित करें।
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// आप आंशिक रूप से आरंभिक सरणियों के साथ भी काम कर सकते हैं, जो निम्न-स्तरीय डेटास्ट्रक्चर में पाई जा सकती हैं।
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` की एक अप्रारंभीकृत सरणी बनाएं।
/// // `assume_init` सुरक्षित है क्योंकि जिस प्रकार का हम यहां इनिशियलाइज़ करने का दावा कर रहे हैं, वह `MaybeUninit` का एक गुच्छा है, जिसे इनिशियलाइज़ करने की आवश्यकता नहीं है।
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // हमारे द्वारा असाइन किए गए तत्वों की संख्या गिनें।
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // सरणी में प्रत्येक आइटम के लिए, यदि हम इसे आवंटित करते हैं तो ड्रॉप करें।
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## एक संरचना क्षेत्र-दर-क्षेत्र प्रारंभ करना
///
/// आप फ़ील्ड द्वारा structs फ़ील्ड प्रारंभ करने के लिए `MaybeUninit<T>`, और [`std::ptr::addr_of_mut`] मैक्रो का उपयोग कर सकते हैं:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` फ़ील्ड को प्रारंभ करना
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` फ़ील्ड को प्रारंभ करना यदि यहाँ कोई panic है, तो `name` फ़ील्ड में `String` लीक हो जाता है।
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // सभी फ़ील्ड आरंभिक हैं, इसलिए हम प्रारंभिक फू प्राप्त करने के लिए `assume_init` को कॉल करते हैं।
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` के समान आकार, संरेखण और ABI होने की गारंटी है:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// हालांकि याद रखें कि एक प्रकार *युक्त* एक `MaybeUninit<T>` जरूरी नहीं कि एक ही लेआउट हो;Rust सामान्य रूप से गारंटी नहीं देता है कि `Foo<T>` के क्षेत्रों में `Foo<U>` के समान क्रम है, भले ही `T` और `U` का आकार और संरेखण समान हो।
///
/// इसके अलावा क्योंकि कोई भी बिट मान `MaybeUninit<T>` के लिए मान्य है, संकलक non-zero/niche-filling अनुकूलन लागू नहीं कर सकता है, जिसके परिणामस्वरूप संभावित रूप से बड़ा आकार हो सकता है:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// यदि `T` FFI-सुरक्षित है, तो `MaybeUninit<T>` भी ऐसा ही है।
///
/// जबकि `MaybeUninit` `#[repr(transparent)]` है (यह दर्शाता है कि यह `T` के समान आकार, संरेखण और ABI की गारंटी देता है), यह पिछली किसी भी चेतावनी को *नहीं* बदलता है।
/// `Option<T>` और `Option<MaybeUninit<T>>` में अभी भी अलग-अलग आकार हो सकते हैं, और `T` प्रकार के फ़ील्ड वाले प्रकारों को अलग-अलग तरीके से रखा जा सकता है (और आकार) यदि वह फ़ील्ड `MaybeUninit<T>` था।
/// `MaybeUninit` एक संघ प्रकार है, और यूनियनों पर `#[repr(transparent)]` अस्थिर है (देखें [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// समय के साथ, यूनियनों पर `#[repr(transparent)]` की सटीक गारंटी विकसित हो सकती है, और `MaybeUninit` `#[repr(transparent)]` रह भी सकता है और नहीं भी।
/// उस ने कहा, `MaybeUninit<T>`*हमेशा* गारंटी देगा कि इसका आकार, संरेखण और ABI `T` के समान है;यह सिर्फ इतना है कि जिस तरह से `MaybeUninit` लागू होता है वह गारंटी विकसित हो सकती है।
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// लैंग आइटम ताकि हम इसमें अन्य प्रकार लपेट सकें।यह जनरेटर के लिए उपयोगी है।
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` को कॉल न करते हुए, हम यह नहीं जान सकते कि क्या हम इसके लिए पर्याप्त रूप से इनिशियलाइज़ हैं।
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// दिए गए मान के साथ आरंभ किया गया एक नया `MaybeUninit<T>` बनाता है।
    /// इस फ़ंक्शन के रिटर्न वैल्यू पर [`assume_init`] को कॉल करना सुरक्षित है।
    ///
    /// ध्यान दें कि `MaybeUninit<T>` को छोड़ने से `T` का ड्रॉप कोड कभी कॉल नहीं होगा।
    /// यह सुनिश्चित करना आपकी जिम्मेदारी है कि यदि `T` को इनिशियलाइज़ किया जाता है तो उसे गिरा दिया जाता है।
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// एक अप्रारंभीकृत अवस्था में एक नया `MaybeUninit<T>` बनाता है।
    ///
    /// ध्यान दें कि `MaybeUninit<T>` को छोड़ने से `T` का ड्रॉप कोड कभी कॉल नहीं होगा।
    /// यह सुनिश्चित करना आपकी जिम्मेदारी है कि यदि `T` को इनिशियलाइज़ किया जाता है तो उसे गिरा दिया जाता है।
    ///
    /// कुछ उदाहरणों के लिए [type-level documentation][MaybeUninit] देखें।
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// एक प्रारंभिक अवस्था में `MaybeUninit<T>` आइटम्स की एक नई सरणी बनाएं।
    ///
    /// Note: future Rust संस्करण में यह विधि अनावश्यक हो सकती है जब सरणी शाब्दिक वाक्यविन्यास [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) की अनुमति देता है।
    ///
    /// नीचे दिया गया उदाहरण तब `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` का उपयोग कर सकता है।
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// डेटा का एक (संभवतः छोटा) टुकड़ा लौटाता है जिसे वास्तव में पढ़ा गया था
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // सुरक्षा: एक अप्रारंभीकृत `[MaybeUninit<_>; LEN]` मान्य है।
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// एक प्रारंभिक अवस्था में एक नया `MaybeUninit<T>` बनाता है, जिसमें मेमोरी `0` बाइट्स से भरी जाती है।यह `T` पर निर्भर करता है कि क्या यह पहले से ही उचित आरंभीकरण के लिए बनाता है।
    ///
    /// उदाहरण के लिए, `MaybeUninit<usize>::zeroed()` को इनिशियलाइज़ किया गया है, लेकिन `MaybeUninit<&'static i32>::zeroed()` इसलिए नहीं है क्योंकि संदर्भ शून्य नहीं होने चाहिए।
    ///
    /// ध्यान दें कि `MaybeUninit<T>` को छोड़ने से `T` का ड्रॉप कोड कभी कॉल नहीं होगा।
    /// यह सुनिश्चित करना आपकी जिम्मेदारी है कि यदि `T` को इनिशियलाइज़ किया जाता है तो उसे गिरा दिया जाता है।
    ///
    /// # Example
    ///
    /// इस फ़ंक्शन का सही उपयोग: शून्य के साथ एक संरचना प्रारंभ करना, जहां संरचना के सभी फ़ील्ड बिट-पैटर्न 0 को मान्य मान के रूप में रख सकते हैं।
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *गलत* इस फ़ंक्शन का उपयोग: `x.zeroed().assume_init()` को कॉल करना जब `0` प्रकार के लिए मान्य बिट-पैटर्न नहीं है:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // एक जोड़ी के अंदर, हम एक `NotZero` बनाते हैं जिसमें कोई वैध विवेचक नहीं होता है।
    /// // यह अपरिभाषित व्यवहार है।️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // सुरक्षा: `u.as_mut_ptr()` आवंटित स्मृति को इंगित करता है।
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` का मान सेट करता है।
    /// यह किसी भी पिछले मान को छोड़े बिना इसे अधिलेखित कर देता है, इसलिए सावधान रहें कि इसे दो बार उपयोग न करें जब तक कि आप विध्वंसक को चलाना छोड़ना नहीं चाहते।
    ///
    /// आपकी सुविधा के लिए, यह `self` की (अब सुरक्षित रूप से प्रारंभ की गई) सामग्री के लिए एक परिवर्तनीय संदर्भ भी देता है।
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // सुरक्षा: हमने अभी इस मान को आरंभ किया है।
        unsafe { self.assume_init_mut() }
    }

    /// निहित मूल्य के लिए एक सूचक प्राप्त करें।
    /// इस सूचक से पढ़ना या इसे संदर्भ में बदलना अपरिभाषित व्यवहार है जब तक कि `MaybeUninit<T>` प्रारंभ नहीं किया जाता है।
    /// स्मृति को लिखना कि यह सूचक (non-transitively) इंगित करता है अपरिभाषित व्यवहार है (`UnsafeCell<T>` के अंदर को छोड़कर)।
    ///
    /// # Examples
    ///
    /// इस विधि का सही उपयोग:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` में एक संदर्भ बनाएं।यह ठीक है क्योंकि हमने इसे इनिशियलाइज़ किया है।
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *गलत* इस पद्धति का उपयोग:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // हमने एक अप्रारंभीकृत vector के लिए एक संदर्भ बनाया है!यह अपरिभाषित व्यवहार है।️
    /// ```
    ///
    /// (ध्यान दें कि गैर-आरंभिक डेटा के संदर्भ के नियमों को अभी तक अंतिम रूप नहीं दिया गया है, लेकिन जब तक वे हैं, उनसे बचने की सलाह दी जाती है।)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` और `ManuallyDrop` दोनों `repr(transparent)` हैं इसलिए हम पॉइंटर को कास्ट कर सकते हैं।
        self as *const _ as *const T
    }

    /// निहित मूल्य के लिए एक परिवर्तनशील सूचक प्राप्त करें।
    /// इस सूचक से पढ़ना या इसे संदर्भ में बदलना अपरिभाषित व्यवहार है जब तक कि `MaybeUninit<T>` प्रारंभ नहीं किया जाता है।
    ///
    /// # Examples
    ///
    /// इस विधि का सही उपयोग:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` में एक संदर्भ बनाएं।
    /// // यह ठीक है क्योंकि हमने इसे इनिशियलाइज़ किया है।
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *गलत* इस पद्धति का उपयोग:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // हमने एक अप्रारंभीकृत vector के लिए एक संदर्भ बनाया है!यह अपरिभाषित व्यवहार है।️
    /// ```
    ///
    /// (ध्यान दें कि गैर-आरंभिक डेटा के संदर्भ के नियमों को अभी तक अंतिम रूप नहीं दिया गया है, लेकिन जब तक वे हैं, उनसे बचने की सलाह दी जाती है।)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` और `ManuallyDrop` दोनों `repr(transparent)` हैं इसलिए हम पॉइंटर को कास्ट कर सकते हैं।
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` कंटेनर से मान निकालता है।यह सुनिश्चित करने का एक शानदार तरीका है कि डेटा गिरा दिया जाएगा, क्योंकि परिणामी `T` सामान्य ड्रॉप हैंडलिंग के अधीन है।
    ///
    /// # Safety
    ///
    /// यह सुनिश्चित करने के लिए कॉलर पर निर्भर है कि `MaybeUninit<T>` वास्तव में प्रारंभिक स्थिति में है।जब सामग्री अभी तक पूरी तरह से प्रारंभ नहीं हुई है तो इसे कॉल करना तत्काल अपरिभाषित व्यवहार का कारण बनता है।
    /// [type-level documentation][inv] में इस इनिशियलाइज़ेशन इनवेरिएंट के बारे में अधिक जानकारी है।
    ///
    /// [inv]: #initialization-invariant
    ///
    /// इसके शीर्ष पर, याद रखें कि अधिकांश प्रकारों में अतिरिक्त इनवेरिएंट होते हैं जिन्हें केवल प्रकार के स्तर पर आरंभिक माना जाता है।
    /// उदाहरण के लिए, एक `1`-प्रारंभिक [`Vec<T>`] को आरंभीकृत माना जाता है (वर्तमान कार्यान्वयन के तहत; यह एक स्थिर गारंटी का गठन नहीं करता है) क्योंकि संकलक को इसके बारे में केवल एक ही आवश्यकता है कि डेटा पॉइंटर गैर-शून्य होना चाहिए।
    ///
    /// ऐसा `Vec<T>` बनाने से *तत्काल* अपरिभाषित व्यवहार नहीं होता है, लेकिन अधिकांश सुरक्षित संचालन (इसे छोड़ने सहित) के साथ अपरिभाषित व्यवहार का कारण होगा।
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// इस विधि का सही उपयोग:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *गलत* इस पद्धति का उपयोग:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` अभी तक प्रारंभ नहीं किया गया था, इसलिए यह अंतिम पंक्ति अपरिभाषित व्यवहार का कारण बनी।️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `self` को इनिशियलाइज़ किया गया है।
        // इसका मतलब यह भी है कि `self` एक `value` वैरिएंट होना चाहिए।
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` कंटेनर से मान पढ़ता है।परिणामी `T` सामान्य ड्रॉप हैंडलिंग के अधीन है।
    ///
    /// जब भी संभव हो, इसके बजाय [`assume_init`] का उपयोग करना बेहतर होता है, जो `MaybeUninit<T>` की सामग्री को डुप्लिकेट करने से रोकता है।
    ///
    /// # Safety
    ///
    /// यह सुनिश्चित करने के लिए कॉलर पर निर्भर है कि `MaybeUninit<T>` वास्तव में प्रारंभिक स्थिति में है।जब सामग्री अभी तक पूरी तरह से प्रारंभ नहीं हुई है तो इसे कॉल करना अपरिभाषित व्यवहार का कारण बनता है।
    /// [type-level documentation][inv] में इस इनिशियलाइज़ेशन इनवेरिएंट के बारे में अधिक जानकारी है।
    ///
    /// इसके अलावा, यह `MaybeUninit<T>` में उसी डेटा की एक प्रति पीछे छोड़ देता है।
    /// डेटा की कई प्रतियों का उपयोग करते समय (`assume_init_read` को कई बार कॉल करके, या पहले `assume_init_read` और फिर [`assume_init`] पर कॉल करके), यह सुनिश्चित करना आपकी ज़िम्मेदारी है कि डेटा वास्तव में डुप्लिकेट हो सकता है।
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// इस विधि का सही उपयोग:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` है, इसलिए हम कई बार पढ़ सकते हैं।
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` मान की नकल करना ठीक है, इसलिए हम कई बार पढ़ सकते हैं।
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *गलत* इस पद्धति का उपयोग:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // अब हमने एक ही vector की दो प्रतियां बनाईं, जिससे दोनों के छूटने पर डबल-फ्री ️ बन गया!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `self` को इनिशियलाइज़ किया गया है।
        // `self.as_ptr()` से पढ़ना सुरक्षित है क्योंकि `self` को इनिशियलाइज़ किया जाना चाहिए।
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// निहित मूल्य को जगह में गिरा देता है।
    ///
    /// यदि आपके पास `MaybeUninit` का स्वामित्व है, तो आप इसके बजाय [`assume_init`] का उपयोग कर सकते हैं।
    ///
    /// # Safety
    ///
    /// यह सुनिश्चित करने के लिए कॉलर पर निर्भर है कि `MaybeUninit<T>` वास्तव में प्रारंभिक स्थिति में है।जब सामग्री अभी तक पूरी तरह से प्रारंभ नहीं हुई है तो इसे कॉल करना अपरिभाषित व्यवहार का कारण बनता है।
    ///
    /// उसके ऊपर, `T` प्रकार के सभी अतिरिक्त इनवेरिएंट संतुष्ट होने चाहिए, क्योंकि `T` (या इसके सदस्य) का `Drop` कार्यान्वयन इस पर भरोसा कर सकता है।
    /// उदाहरण के लिए, एक `1`-प्रारंभिक [`Vec<T>`] को आरंभीकृत माना जाता है (वर्तमान कार्यान्वयन के तहत; यह एक स्थिर गारंटी का गठन नहीं करता है) क्योंकि संकलक को इसके बारे में केवल एक ही आवश्यकता है कि डेटा पॉइंटर गैर-शून्य होना चाहिए।
    ///
    /// हालांकि इस तरह के `Vec<T>` को छोड़ने से अपरिभाषित व्यवहार होगा।
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `self` को इनिशियलाइज़ किया गया है और
        // `T` के सभी अपरिवर्तनीयों को संतुष्ट करता है।
        // यदि ऐसा है तो मूल्य को जगह में गिराना सुरक्षित है।
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// निहित मूल्य के लिए एक साझा संदर्भ प्राप्त करें।
    ///
    /// यह तब उपयोगी हो सकता है जब हम एक `MaybeUninit` को एक्सेस करना चाहते हैं जिसे इनिशियलाइज़ किया गया है लेकिन `MaybeUninit` का स्वामित्व नहीं है (`.assume_init()`) के उपयोग को रोकना।
    ///
    /// # Safety
    ///
    /// जब सामग्री अभी तक पूरी तरह से प्रारंभ नहीं हुई है तो इसे कॉल करना अपरिभाषित व्यवहार का कारण बनता है: यह गारंटी देने के लिए कॉलर पर निर्भर है कि `MaybeUninit<T>` वास्तव में प्रारंभिक स्थिति में है।
    ///
    ///
    /// # Examples
    ///
    /// ### इस विधि का सही उपयोग:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` प्रारंभ करें:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // अब जब हमारे `MaybeUninit<_>` को इनिशियलाइज़ करने के लिए जाना जाता है, तो इसका एक साझा संदर्भ बनाना ठीक है:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // सुरक्षा: `x` को इनिशियलाइज़ किया गया है।
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *गलत* इस पद्धति का उपयोग:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // हमने एक अप्रारंभीकृत vector के लिए एक संदर्भ बनाया है!यह अपरिभाषित व्यवहार है।️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` का उपयोग करके `MaybeUninit` को प्रारंभ करें:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // एक अप्रारंभीकृत `Cell<bool>` का संदर्भ: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `self` को इनिशियलाइज़ किया गया है।
        // इसका मतलब यह भी है कि `self` एक `value` वैरिएंट होना चाहिए।
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// निहित मूल्य के लिए एक परिवर्तनीय (unique) संदर्भ प्राप्त करता है।
    ///
    /// यह तब उपयोगी हो सकता है जब हम एक `MaybeUninit` को एक्सेस करना चाहते हैं जिसे इनिशियलाइज़ किया गया है लेकिन `MaybeUninit` का स्वामित्व नहीं है (`.assume_init()`) के उपयोग को रोकना।
    ///
    /// # Safety
    ///
    /// जब सामग्री अभी तक पूरी तरह से प्रारंभ नहीं हुई है तो इसे कॉल करना अपरिभाषित व्यवहार का कारण बनता है: यह गारंटी देने के लिए कॉलर पर निर्भर है कि `MaybeUninit<T>` वास्तव में प्रारंभिक स्थिति में है।
    /// उदाहरण के लिए, `.assume_init_mut()` का उपयोग `MaybeUninit` को इनिशियलाइज़ करने के लिए नहीं किया जा सकता है।
    ///
    /// # Examples
    ///
    /// ### इस विधि का सही उपयोग:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// इनपुट बफर के *सभी* बाइट्स को इनिशियलाइज़ करता है।
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` प्रारंभ करें:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // अब हम जानते हैं कि `buf` को इनिशियलाइज़ किया गया है, इसलिए हम इसे `.assume_init()` कर सकते हैं।
    /// // हालाँकि, `.assume_init()` का उपयोग करने से 2048 बाइट्स का `memcpy` ट्रिगर हो सकता है।
    /// // यह सुनिश्चित करने के लिए कि हमारे बफर को कॉपी किए बिना इनिशियलाइज़ किया गया है, हम `&mut MaybeUninit<[u8; 2048]>` को `&mut [u8; 2048]` में अपग्रेड करते हैं:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // सुरक्षा: `buf` को इनिशियलाइज़ किया गया है।
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // अब हम `buf` को सामान्य स्लाइस के रूप में उपयोग कर सकते हैं:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *गलत* इस पद्धति का उपयोग:
    ///
    /// आप किसी मान को प्रारंभ करने के लिए `.assume_init_mut()` का उपयोग नहीं कर सकते:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // हमने एक अप्रारंभीकृत `bool` के लिए एक (mutable) संदर्भ बनाया है!
    ///     // यह अपरिभाषित व्यवहार है।️
    /// }
    /// ```
    ///
    /// उदाहरण के लिए, आप [`Read`] को एक अप्रारंभीकृत बफ़र में नहीं बना सकते:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) प्रारंभिक स्मृति के संदर्भ में!
    ///                             // यह अपरिभाषित व्यवहार है।
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// न ही आप क्षेत्र-दर-क्षेत्र क्रमिक आरंभीकरण करने के लिए प्रत्यक्ष क्षेत्र पहुँच का उपयोग कर सकते हैं:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) प्रारंभिक स्मृति के संदर्भ में!
    ///                  // यह अपरिभाषित व्यवहार है।
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) प्रारंभिक स्मृति के संदर्भ में!
    ///                  // यह अपरिभाषित व्यवहार है।
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): हम वर्तमान में ऊपर के गलत होने पर भरोसा करते हैं, यानी, हमारे पास अप्रारंभीकृत डेटा (जैसे, `libcore/fmt/float.rs` में) के संदर्भ हैं।
    // हमें स्थिरीकरण से पहले नियमों के बारे में अंतिम निर्णय लेना चाहिए।
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `self` को इनिशियलाइज़ किया गया है।
        // इसका मतलब यह भी है कि `self` एक `value` वैरिएंट होना चाहिए।
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` कंटेनरों की एक सरणी से मान निकालता है।
    ///
    /// # Safety
    ///
    /// यह सुनिश्चित करने के लिए कॉलर पर निर्भर है कि सरणी के सभी तत्व प्रारंभिक स्थिति में हैं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // सुरक्षा: अब सुरक्षित है क्योंकि हमने सभी तत्वों को इनिशियलाइज़ किया है
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * कॉलर गारंटी देता है कि सरणी के सभी तत्व आरंभिक हैं
        // * `MaybeUninit<T>` और टी को एक ही लेआउट होने की गारंटी है
        // * MaybeUnint नहीं गिरता है, इसलिए कोई डबल-फ्री नहीं है और इस प्रकार रूपांतरण सुरक्षित है
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// मान लें कि सभी तत्वों को प्रारंभ किया गया है, उन्हें एक टुकड़ा प्राप्त करें।
    ///
    /// # Safety
    ///
    /// यह सुनिश्चित करने के लिए कॉलर पर निर्भर है कि `MaybeUninit<T>` तत्व वास्तव में प्रारंभिक स्थिति में हैं।
    ///
    /// जब सामग्री अभी तक पूरी तरह से प्रारंभ नहीं हुई है तो इसे कॉल करना अपरिभाषित व्यवहार का कारण बनता है।
    ///
    /// अधिक विवरण और उदाहरणों के लिए [`assume_init_ref`] देखें।
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // सुरक्षा: `*const [T]` पर स्लाइस कास्ट करना सुरक्षित है क्योंकि कॉलर गारंटी देता है कि
        // `slice` इनिशियलाइज़ किया गया है, और `MaybeUninit` का लेआउट `T` के समान होने की गारंटी है।
        // प्राप्त सूचक मान्य है क्योंकि यह `slice` के स्वामित्व वाली स्मृति को संदर्भित करता है जो एक संदर्भ है और इस प्रकार पढ़ने के लिए मान्य होने की गारंटी है।
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// मान लें कि सभी तत्वों को प्रारंभ किया गया है, उनके लिए एक परिवर्तनीय टुकड़ा प्राप्त करें।
    ///
    /// # Safety
    ///
    /// यह सुनिश्चित करने के लिए कॉलर पर निर्भर है कि `MaybeUninit<T>` तत्व वास्तव में प्रारंभिक स्थिति में हैं।
    ///
    /// जब सामग्री अभी तक पूरी तरह से प्रारंभ नहीं हुई है तो इसे कॉल करना अपरिभाषित व्यवहार का कारण बनता है।
    ///
    /// अधिक विवरण और उदाहरणों के लिए [`assume_init_mut`] देखें।
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // सुरक्षा: `slice_get_ref` के लिए सुरक्षा नोटों के समान, लेकिन हमारे पास a
        // परिवर्तनीय संदर्भ जो लिखने के लिए मान्य होने की भी गारंटी है।
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// सरणी के पहले तत्व के लिए एक सूचक प्राप्त करें।
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// सरणी के पहले तत्व के लिए एक परिवर्तनशील सूचक प्राप्त करें।
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` से `this` के तत्वों की प्रतिलिपि बनाता है, `this` की अब इनिटलाइज्ड सामग्री के लिए एक परिवर्तनीय संदर्भ लौटाता है।
    ///
    /// यदि `T` `Copy` को लागू नहीं करता है, तो [`write_slice_cloned`] का उपयोग करें
    ///
    /// यह [`slice::copy_from_slice`] के समान है।
    ///
    /// # Panics
    ///
    /// यदि दो स्लाइस की लंबाई अलग-अलग है तो यह फ़ंक्शन panic होगा।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // सुरक्षा: हमने लेन के सभी तत्वों को अतिरिक्त क्षमता में कॉपी किया है
    /// // vec के पहले src.len() तत्व अब मान्य हैं।
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // सुरक्षा: और [टी] और और [शायद यूनीटUn<T>] एक ही लेआउट है
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // सुरक्षा: मान्य तत्वों को अभी-अभी `this` में कॉपी किया गया है, इसलिए इसे इनिशियलाइज़ किया गया है
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` से `this` तक तत्वों को क्लोन करता है, `this` की अब इनिटलाइज्ड सामग्री के लिए एक परिवर्तनीय संदर्भ लौटाता है।
    /// कोई भी पहले से ही निष्क्रिय तत्व नहीं छोड़ा जाएगा।
    ///
    /// यदि `T` `Copy` को लागू करता है, तो [`write_slice`] का उपयोग करें
    ///
    /// यह [`slice::clone_from_slice`] के समान है लेकिन मौजूदा तत्वों को नहीं छोड़ता है।
    ///
    /// # Panics
    ///
    /// यह फ़ंक्शन panic होगा यदि दो स्लाइस की अलग-अलग लंबाई है, या यदि `Clone` panics का कार्यान्वयन है।
    ///
    /// यदि कोई panic है, तो पहले से क्लोन किए गए तत्वों को हटा दिया जाएगा।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // सुरक्षा: हमने लेन के सभी तत्वों को अतिरिक्त क्षमता में क्लोन किया है
    /// // vec के पहले src.len() तत्व अब मान्य हैं।
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice के विपरीत यह क्लोन_फ्रॉम_स्लाइस को स्लाइस पर कॉल नहीं करता है क्योंकि `MaybeUninit<T: Clone>` क्लोन को लागू नहीं करता है।
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // सुरक्षा: इस कच्चे टुकड़े में केवल आरंभिक वस्तुएं होंगी
                // इसलिए, इसे छोड़ने की अनुमति है।
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: हमें स्पष्ट रूप से उन्हें समान लंबाई में काटने की आवश्यकता है
        // सीमा की जाँच के लिए, और ऑप्टिमाइज़र साधारण मामलों के लिए memcpy उत्पन्न करेगा (उदाहरण के लिए T= u8)।
        //
        let len = this.len();
        let src = &src[..len];

        // गार्ड की जरूरत है b/c panic क्लोन के दौरान हो सकता है
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // सुरक्षा: मान्य तत्व अभी-अभी `this` में लिखे गए हैं, इसलिए इसे इनिशियलाइज़ किया गया है
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}