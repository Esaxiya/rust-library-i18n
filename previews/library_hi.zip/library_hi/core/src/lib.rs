//! # Rust कोर लाइब्रेरी
//!
//! Rust कोर लाइब्रेरी [The Rust Standard Library](../std/index.html) की निर्भरता-मुक्त [^ मुक्त] नींव है।
//! यह भाषा और उसके पुस्तकालयों के बीच पोर्टेबल गोंद है, जो सभी Rust कोड के आंतरिक और आदिम बिल्डिंग ब्लॉक्स को परिभाषित करता है।
//!
//! यह कोई अपस्ट्रीम लाइब्रेरी, कोई सिस्टम लाइब्रेरी और कोई libc से लिंक नहीं करता है।
//!
//! [^free]: Strictly बोलते हुए, कुछ प्रतीक हैं जिनकी आवश्यकता है लेकिन
//!          वे हमेशा आवश्यक नहीं होते हैं।
//!
//! मुख्य पुस्तकालय *न्यूनतम* है: यह ढेर आवंटन के बारे में भी नहीं जानता है, न ही यह समवर्ती या I/O प्रदान करता है।
//! इन चीज़ों के लिए प्लेटफ़ॉर्म एकीकरण की आवश्यकता होती है, और यह लाइब्रेरी प्लेटफ़ॉर्म-अज्ञेयवादी है।
//!
//! # कोर लाइब्रेरी का उपयोग कैसे करें
//!
//! कृपया ध्यान दें कि इन सभी विवरणों को वर्तमान में स्थिर नहीं माना जाता है।
//!
//!
//!
// FIXME: इंटरफ़ेस के व्यवस्थित होने पर मुझे और विवरण भरें detail
//! यह पुस्तकालय कुछ मौजूदा प्रतीकों की धारणा पर बनाया गया है:
//!
//! * `memcpy`, `memcmp`, `memset`, ये कोर मेमोरी रूटीन हैं जो अक्सर LLVM द्वारा उत्पन्न होते हैं।
//! इसके अतिरिक्त, यह पुस्तकालय इन कार्यों के लिए स्पष्ट कॉल कर सकता है।
//! उनके हस्ताक्षर वही हैं जो सी में पाए जाते हैं।
//!   ये फ़ंक्शन अक्सर सिस्टम libc द्वारा प्रदान किए जाते हैं, लेकिन [compiler-builtins crate](https://crates.io/crates/compiler_builtins) द्वारा भी प्रदान किए जा सकते हैं।
//!
//!
//! * `rust_begin_panic` - यह फ़ंक्शन चार तर्क लेता है, एक `fmt::Arguments`, एक `&'static str`, और दो `u32`।
//! ये चार तर्क panic संदेश को निर्देशित करते हैं, जिस फ़ाइल पर panic लागू किया गया था, और फ़ाइल के अंदर की रेखा और कॉलम।
//! यह इस मुख्य पुस्तकालय के उपभोक्ताओं पर निर्भर है कि वे इस panic फ़ंक्शन को परिभाषित करें;यह केवल कभी वापस न आने की आवश्यकता है।
//! इसके लिए `panic_impl` नाम की एक `lang` विशेषता की आवश्यकता होती है।
//!
//! * `rust_eh_personality` - संकलक के विफलता तंत्र द्वारा उपयोग किया जाता है।
//! इसे अक्सर GCC के व्यक्तित्व फ़ंक्शन के लिए मैप किया जाता है, लेकिन crates जो panic को ट्रिगर नहीं करता है, यह आश्वासन दिया जा सकता है कि इस फ़ंक्शन को कभी नहीं कहा जाता है।
//! `lang` विशेषता को `eh_personality` कहा जाता है।
//!
//!
//!

// चूंकि libcore कई मूलभूत लैंग आइटम को परिभाषित करता है, सभी परीक्षण विचित्र मुद्दों से बचने के लिए एक अलग crate, libcoretest में रहते हैं।
//
// यहां हम स्पष्ट रूप से#[cfg]-परीक्षण करते समय इस पूरे crate को बाहर करते हैं।
// यदि हम ऐसा नहीं करते हैं, तो उत्पन्न परीक्षण आर्टिफैक्ट और लिंक्ड लिबटेस्ट (जिसमें ट्रांजिटिवली लिबकोर शामिल है) दोनों ही लैंग आइटम्स के एक ही सेट को परिभाषित करेंगे, और यह E0152 "found duplicate lang item" त्रुटि का कारण बनेगा।
//
// विवरण के लिए #50466 में चर्चा देखें।
//
// यह cfg डॉक्टर परीक्षणों को प्रभावित नहीं करेगा।
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // देखें #65860
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: सार्वजनिक होने की आवश्यकता नहीं है
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// `core_arch` crate को सीधे libcore में खींचें।`core_arch` की सामग्री एक अलग भंडार में हैं: rust-lang/stdarch.
//
// `core_arch` libcore पर निर्भर करता है, लेकिन इस मॉड्यूल की सामग्री इस तरह से स्थापित की जाती है कि इसे सीधे यहां खींचकर काम करता है जैसे crate इस crate को अपने libcore के रूप में उपयोग करता है।
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: क्लैशिंग_extern_declarations isde के बाद इस एनोटेशन को rust-lang/stdarch में ले जाया जाना चाहिए
// विलय होना।यह वर्तमान में नहीं हो सकता क्योंकि बूटस्ट्रैप विफल रहता है क्योंकि lint को अभी तक परिभाषित नहीं किया गया है।
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;