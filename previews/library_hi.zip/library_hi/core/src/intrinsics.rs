//! कंपाइलर इंट्रिनिक्स।
//!
//! संबंधित परिभाषाएँ `compiler/rustc_codegen_llvm/src/intrinsic.rs` में हैं।
//! संबंधित कॉन्स कार्यान्वयन `compiler/rustc_mir/src/interpret/intrinsics.rs`. में हैं
//!
//! # कॉन्स्ट इंट्रिनिक्स
//!
//! Note: इंट्रिनिक्स की स्थिरता में किसी भी बदलाव पर भाषा टीम के साथ चर्चा की जानी चाहिए।
//! इसमें स्थिरता की स्थिरता में परिवर्तन शामिल हैं।
//!
//! संकलन-समय पर एक आंतरिक प्रयोग करने योग्य बनाने के लिए, किसी को <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> से `compiler/rustc_mir/src/interpret/intrinsics.rs` तक कार्यान्वयन की प्रतिलिपि बनाने और आंतरिक में `#[rustc_const_unstable(feature = "foo", issue = "01234")]` जोड़ने की आवश्यकता होती है।
//!
//!
//! यदि एक `const fn` से `rustc_const_stable` विशेषता के साथ एक आंतरिक का उपयोग किया जाना चाहिए, तो आंतरिक की विशेषता `rustc_const_stable` भी होनी चाहिए।
//! इस तरह का परिवर्तन टी-लैंग परामर्श के बिना नहीं किया जाना चाहिए, क्योंकि यह एक ऐसी सुविधा को भाषा में बदल देता है जिसे संकलक समर्थन के बिना उपयोगकर्ता कोड में दोहराया नहीं जा सकता है।
//!
//! # Volatiles
//!
//! अस्थिर इंट्रिनिक्स I/O मेमोरी पर कार्य करने के उद्देश्य से संचालन प्रदान करते हैं, जो कि अन्य अस्थिर इंट्रिनिक्स में कंपाइलर द्वारा पुन: व्यवस्थित नहीं होने की गारंटी है।[[volatile]] पर LLVM दस्तावेज़ देखें।
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! परमाणु इंट्रिनिक्स कई संभावित मेमोरी ऑर्डरिंग के साथ मशीन शब्दों पर सामान्य परमाणु संचालन प्रदान करते हैं।वे C++ 11 के समान शब्दार्थ का पालन करते हैं।[[atomics]] पर LLVM दस्तावेज़ देखें।
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! स्मृति क्रम पर एक त्वरित पुनश्चर्या:
//!
//! * अधिग्रहण, ताला प्राप्त करने के लिए एक बाधा।बाद में पढ़ना और लिखना बैरियर के बाद होता है।
//! * रिलीज, एक ताला जारी करने के लिए एक बाधा।पूर्ववर्ती पढ़ना और लिखना बैरियर से पहले होता है।
//! * क्रमिक रूप से सुसंगत, क्रमिक रूप से सुसंगत संचालन क्रम में होने की गारंटी है।यह परमाणु प्रकारों के साथ काम करने के लिए मानक मोड है और Java के `volatile` के बराबर है।
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// इन आयातों का उपयोग इंट्रा-डॉक लिंक को सरल बनाने के लिए किया जाता है
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // सुरक्षा: `ptr::drop_in_place` देखें
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // एनबी, ये इंट्रिनिक्स कच्चे पॉइंटर्स लेते हैं क्योंकि वे अलियास्ड मेमोरी को बदलते हैं, जो कि `&` या `&mut` के लिए मान्य नहीं है।
    //

    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकार पर `compare_exchange` विधि के माध्यम से [`Ordering::SeqCst`] और `failure` दोनों मापदंडों के रूप में पास करके उपलब्ध है।
    ///
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकार पर `compare_exchange` विधि के माध्यम से [`Ordering::Acquire`] और `failure` दोनों मापदंडों के रूप में पास करके उपलब्ध है।
    ///
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `compare_exchange` विधि के माध्यम से [`Ordering::Release`] को `success` और [`Ordering::Relaxed`] को `failure` पैरामीटर के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `compare_exchange` विधि के माध्यम से [`Ordering::AcqRel`] को `success` और [`Ordering::Acquire`] को `failure` पैरामीटर के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकार पर `compare_exchange` विधि के माध्यम से [`Ordering::Relaxed`] और `failure` दोनों मापदंडों के रूप में पास करके उपलब्ध है।
    ///
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `compare_exchange` विधि के माध्यम से [`Ordering::SeqCst`] को `success` और [`Ordering::Relaxed`] को `failure` पैरामीटर के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `compare_exchange` विधि के माध्यम से [`Ordering::SeqCst`] को `success` और [`Ordering::Acquire`] को `failure` पैरामीटर के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `compare_exchange` विधि के माध्यम से [`Ordering::Acquire`] को `success` और [`Ordering::Relaxed`] को `failure` पैरामीटर के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `compare_exchange` विधि के माध्यम से [`Ordering::AcqRel`] को `success` और [`Ordering::Relaxed`] को `failure` पैरामीटर के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकार पर `compare_exchange_weak` विधि के माध्यम से [`Ordering::SeqCst`] और `failure` दोनों मापदंडों के रूप में पास करके उपलब्ध है।
    ///
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकार पर `compare_exchange_weak` विधि के माध्यम से [`Ordering::Acquire`] और `failure` दोनों मापदंडों के रूप में पास करके उपलब्ध है।
    ///
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `compare_exchange_weak` विधि के माध्यम से [`Ordering::Release`] को `success` और [`Ordering::Relaxed`] को `failure` पैरामीटर के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `compare_exchange_weak` विधि के माध्यम से [`Ordering::AcqRel`] को `success` और [`Ordering::Acquire`] को `failure` पैरामीटर के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकार पर `compare_exchange_weak` विधि के माध्यम से [`Ordering::Relaxed`] और `failure` दोनों मापदंडों के रूप में पास करके उपलब्ध है।
    ///
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `compare_exchange_weak` विधि के माध्यम से [`Ordering::SeqCst`] को `success` और [`Ordering::Relaxed`] को `failure` पैरामीटर के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `compare_exchange_weak` विधि के माध्यम से [`Ordering::SeqCst`] को `success` और [`Ordering::Acquire`] को `failure` पैरामीटर के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `compare_exchange_weak` विधि के माध्यम से [`Ordering::Acquire`] को `success` और [`Ordering::Relaxed`] को `failure` पैरामीटर के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// एक मान संग्रहीत करता है यदि वर्तमान मान `old` मान के समान है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `compare_exchange_weak` विधि के माध्यम से [`Ordering::AcqRel`] को `success` और [`Ordering::Relaxed`] को `failure` पैरामीटर के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// सूचक का वर्तमान मान लोड करता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `load` विधि के माध्यम से [`Ordering::SeqCst`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// सूचक का वर्तमान मान लोड करता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `load` विधि के माध्यम से [`Ordering::Acquire`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// सूचक का वर्तमान मान लोड करता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `load` विधि के माध्यम से [`Ordering::Relaxed`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// मान को निर्दिष्ट मेमोरी लोकेशन पर स्टोर करता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `store` विधि के माध्यम से [`Ordering::SeqCst`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// मान को निर्दिष्ट मेमोरी लोकेशन पर स्टोर करता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `store` विधि के माध्यम से [`Ordering::Release`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// मान को निर्दिष्ट मेमोरी लोकेशन पर स्टोर करता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `store` विधि के माध्यम से [`Ordering::Relaxed`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// पुराने मान को वापस करते हुए, निर्दिष्ट मेमोरी स्थान पर मान संग्रहीत करता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `swap` विधि के माध्यम से [`Ordering::SeqCst`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// पुराने मान को वापस करते हुए, निर्दिष्ट मेमोरी स्थान पर मान संग्रहीत करता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `swap` विधि के माध्यम से [`Ordering::Acquire`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// पुराने मान को वापस करते हुए, निर्दिष्ट मेमोरी स्थान पर मान संग्रहीत करता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `swap` विधि के माध्यम से [`Ordering::Release`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// पुराने मान को वापस करते हुए, निर्दिष्ट मेमोरी स्थान पर मान संग्रहीत करता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `swap` विधि के माध्यम से [`Ordering::AcqRel`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// पुराने मान को वापस करते हुए, निर्दिष्ट मेमोरी स्थान पर मान संग्रहीत करता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `swap` विधि के माध्यम से [`Ordering::Relaxed`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// वर्तमान मान में जोड़ता है, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_add` विधि के माध्यम से [`Ordering::SeqCst`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// वर्तमान मान में जोड़ता है, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_add` विधि के माध्यम से [`Ordering::Acquire`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// वर्तमान मान में जोड़ता है, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_add` विधि के माध्यम से [`Ordering::Release`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// वर्तमान मान में जोड़ता है, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_add` विधि के माध्यम से [`Ordering::AcqRel`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// वर्तमान मान में जोड़ता है, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_add` विधि के माध्यम से [`Ordering::Relaxed`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// पिछले मान को वापस करते हुए, वर्तमान मान से घटाएं।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_sub` विधि के माध्यम से [`Ordering::SeqCst`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// पिछले मान को वापस करते हुए, वर्तमान मान से घटाएं।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_sub` विधि के माध्यम से [`Ordering::Acquire`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// पिछले मान को वापस करते हुए, वर्तमान मान से घटाएं।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_sub` विधि के माध्यम से [`Ordering::Release`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// पिछले मान को वापस करते हुए, वर्तमान मान से घटाएं।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_sub` विधि के माध्यम से [`Ordering::AcqRel`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// पिछले मान को वापस करते हुए, वर्तमान मान से घटाएं।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_sub` विधि के माध्यम से [`Ordering::Relaxed`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// बिटवाइज़ और वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_and` विधि के माध्यम से [`Ordering::SeqCst`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ और वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_and` विधि के माध्यम से [`Ordering::Acquire`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ और वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_and` विधि के माध्यम से [`Ordering::Release`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ और वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_and` विधि के माध्यम से [`Ordering::AcqRel`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ और वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_and` विधि के माध्यम से [`Ordering::Relaxed`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// बिटवाइज़ नंद वर्तमान मान के साथ, पिछले मान को लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`AtomicBool`] प्रकार पर `fetch_nand` विधि के माध्यम से [`Ordering::SeqCst`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ नंद वर्तमान मान के साथ, पिछले मान को लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`AtomicBool`] प्रकार पर `fetch_nand` विधि के माध्यम से [`Ordering::Acquire`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ नंद वर्तमान मान के साथ, पिछले मान को लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`AtomicBool`] प्रकार पर `fetch_nand` विधि के माध्यम से [`Ordering::Release`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ नंद वर्तमान मान के साथ, पिछले मान को लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`AtomicBool`] प्रकार पर `fetch_nand` विधि के माध्यम से [`Ordering::AcqRel`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ नंद वर्तमान मान के साथ, पिछले मान को लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`AtomicBool`] प्रकार पर `fetch_nand` विधि के माध्यम से [`Ordering::Relaxed`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// बिटवाइज़ या वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_or` विधि के माध्यम से [`Ordering::SeqCst`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ या वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_or` विधि के माध्यम से [`Ordering::Acquire`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ या वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_or` विधि के माध्यम से [`Ordering::Release`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ या वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_or` विधि के माध्यम से [`Ordering::AcqRel`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ या वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_or` विधि के माध्यम से [`Ordering::Relaxed`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// बिटवाइज़ xor वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_xor` विधि के माध्यम से [`Ordering::SeqCst`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ xor वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_xor` विधि के माध्यम से [`Ordering::Acquire`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ xor वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_xor` विधि के माध्यम से [`Ordering::Release`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ xor वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_xor` विधि के माध्यम से [`Ordering::AcqRel`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// बिटवाइज़ xor वर्तमान मान के साथ, पिछला मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`atomic`] प्रकारों पर `fetch_xor` विधि के माध्यम से [`Ordering::Relaxed`] को `order` के रूप में पास करके उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// एक हस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ अधिकतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::SeqCst`] को `order` के रूप में पास करके `fetch_max` विधि के माध्यम से [`atomic`] हस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ अधिकतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Acquire`] को `order` के रूप में पास करके `fetch_max` विधि के माध्यम से [`atomic`] हस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ अधिकतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Release`] को `order` के रूप में पास करके `fetch_max` विधि के माध्यम से [`atomic`] हस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ अधिकतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::AcqRel`] को `order` के रूप में पास करके `fetch_max` विधि के माध्यम से [`atomic`] हस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// वर्तमान मूल्य के साथ अधिकतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Relaxed`] को `order` के रूप में पास करके `fetch_max` विधि के माध्यम से [`atomic`] हस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// एक हस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ न्यूनतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::SeqCst`] को `order` के रूप में पास करके `fetch_min` विधि के माध्यम से [`atomic`] हस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ न्यूनतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Acquire`] को `order` के रूप में पास करके `fetch_min` विधि के माध्यम से [`atomic`] हस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ न्यूनतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Release`] को `order` के रूप में पास करके `fetch_min` विधि के माध्यम से [`atomic`] हस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ न्यूनतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::AcqRel`] को `order` के रूप में पास करके `fetch_min` विधि के माध्यम से [`atomic`] हस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ न्यूनतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Relaxed`] को `order` के रूप में पास करके `fetch_min` विधि के माध्यम से [`atomic`] हस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// एक अहस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ न्यूनतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::SeqCst`] को `order` के रूप में पास करके `fetch_min` विधि के माध्यम से [`atomic`] अहस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक अहस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ न्यूनतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Acquire`] को `order` के रूप में पास करके `fetch_min` विधि के माध्यम से [`atomic`] अहस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक अहस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ न्यूनतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Release`] को `order` के रूप में पास करके `fetch_min` विधि के माध्यम से [`atomic`] अहस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक अहस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ न्यूनतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::AcqRel`] को `order` के रूप में पास करके `fetch_min` विधि के माध्यम से [`atomic`] अहस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक अहस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ न्यूनतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Relaxed`] को `order` के रूप में पास करके `fetch_min` विधि के माध्यम से [`atomic`] अहस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// एक अहस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ अधिकतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::SeqCst`] को `order` के रूप में पास करके `fetch_max` विधि के माध्यम से [`atomic`] अहस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक अहस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ अधिकतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Acquire`] को `order` के रूप में पास करके `fetch_max` विधि के माध्यम से [`atomic`] अहस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक अहस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ अधिकतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Release`] को `order` के रूप में पास करके `fetch_max` विधि के माध्यम से [`atomic`] अहस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक अहस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ अधिकतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::AcqRel`] को `order` के रूप में पास करके `fetch_max` विधि के माध्यम से [`atomic`] अहस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक अहस्ताक्षरित तुलना का उपयोग करके वर्तमान मूल्य के साथ अधिकतम।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Relaxed`] को `order` के रूप में पास करके `fetch_max` विधि के माध्यम से [`atomic`] अहस्ताक्षरित पूर्णांक प्रकारों पर उपलब्ध है।
    /// उदाहरण के लिए, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` इंट्रिन्सिक कोड जनरेटर के लिए एक संकेत है कि यदि समर्थित हो तो प्रीफेच निर्देश सम्मिलित करें;अन्यथा, यह एक नो-ऑप है।
    /// प्रीफ़ेच का कार्यक्रम के व्यवहार पर कोई प्रभाव नहीं पड़ता है, लेकिन इसकी प्रदर्शन विशेषताओं को बदल सकता है।
    ///
    /// `locality` तर्क एक स्थिर पूर्णांक होना चाहिए और (0) से लेकर (3) तक, अत्यधिक स्थानीय कैश में रखने के लिए एक अस्थायी स्थानीयता विनिर्देशक है।
    ///
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` इंट्रिन्सिक कोड जनरेटर के लिए एक संकेत है कि यदि समर्थित हो तो प्रीफेच निर्देश सम्मिलित करें;अन्यथा, यह एक नो-ऑप है।
    /// प्रीफ़ेच का कार्यक्रम के व्यवहार पर कोई प्रभाव नहीं पड़ता है, लेकिन इसकी प्रदर्शन विशेषताओं को बदल सकता है।
    ///
    /// `locality` तर्क एक स्थिर पूर्णांक होना चाहिए और (0) से लेकर (3) तक, अत्यधिक स्थानीय कैश में रखने के लिए एक अस्थायी स्थानीयता विनिर्देशक है।
    ///
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` इंट्रिन्सिक कोड जनरेटर के लिए एक संकेत है कि यदि समर्थित हो तो प्रीफेच निर्देश सम्मिलित करें;अन्यथा, यह एक नो-ऑप है।
    /// प्रीफ़ेच का कार्यक्रम के व्यवहार पर कोई प्रभाव नहीं पड़ता है, लेकिन इसकी प्रदर्शन विशेषताओं को बदल सकता है।
    ///
    /// `locality` तर्क एक स्थिर पूर्णांक होना चाहिए और (0) से लेकर (3) तक, अत्यधिक स्थानीय कैश में रखने के लिए एक अस्थायी स्थानीयता विनिर्देशक है।
    ///
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` इंट्रिन्सिक कोड जनरेटर के लिए एक संकेत है कि यदि समर्थित हो तो प्रीफेच निर्देश सम्मिलित करें;अन्यथा, यह एक नो-ऑप है।
    /// प्रीफ़ेच का कार्यक्रम के व्यवहार पर कोई प्रभाव नहीं पड़ता है, लेकिन इसकी प्रदर्शन विशेषताओं को बदल सकता है।
    ///
    /// `locality` तर्क एक स्थिर पूर्णांक होना चाहिए और (0) से लेकर (3) तक, अत्यधिक स्थानीय कैश में रखने के लिए एक अस्थायी स्थानीयता विनिर्देशक है।
    ///
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// एक परमाणु बाड़।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::SeqCst`] को `order` के रूप में पास करके [`atomic::fence`] में उपलब्ध है।
    ///
    ///
    pub fn atomic_fence();
    /// एक परमाणु बाड़।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Acquire`] को `order` के रूप में पास करके [`atomic::fence`] में उपलब्ध है।
    ///
    ///
    pub fn atomic_fence_acq();
    /// एक परमाणु बाड़।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Release`] को `order` के रूप में पास करके [`atomic::fence`] में उपलब्ध है।
    ///
    ///
    pub fn atomic_fence_rel();
    /// एक परमाणु बाड़।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::AcqRel`] को `order` के रूप में पास करके [`atomic::fence`] में उपलब्ध है।
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// एक कंपाइलर-ओनली मेमोरी बैरियर।
    ///
    /// मेमोरी एक्सेस को कंपाइलर द्वारा इस बाधा के पार कभी भी पुन: व्यवस्थित नहीं किया जाएगा, लेकिन इसके लिए कोई निर्देश नहीं दिया जाएगा।
    /// यह उसी थ्रेड पर संचालन के लिए उपयुक्त है जिसे प्रीमेप्ट किया जा सकता है, जैसे सिग्नल हैंडलर के साथ बातचीत करते समय।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::SeqCst`] को `order` के रूप में पास करके [`atomic::compiler_fence`] में उपलब्ध है।
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// एक कंपाइलर-ओनली मेमोरी बैरियर।
    ///
    /// मेमोरी एक्सेस को कंपाइलर द्वारा इस बाधा के पार कभी भी पुन: व्यवस्थित नहीं किया जाएगा, लेकिन इसके लिए कोई निर्देश नहीं दिया जाएगा।
    /// यह उसी थ्रेड पर संचालन के लिए उपयुक्त है जिसे प्रीमेप्ट किया जा सकता है, जैसे सिग्नल हैंडलर के साथ बातचीत करते समय।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Acquire`] को `order` के रूप में पास करके [`atomic::compiler_fence`] में उपलब्ध है।
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// एक कंपाइलर-ओनली मेमोरी बैरियर।
    ///
    /// मेमोरी एक्सेस को कंपाइलर द्वारा इस बाधा के पार कभी भी पुन: व्यवस्थित नहीं किया जाएगा, लेकिन इसके लिए कोई निर्देश नहीं दिया जाएगा।
    /// यह उसी थ्रेड पर संचालन के लिए उपयुक्त है जिसे प्रीमेप्ट किया जा सकता है, जैसे सिग्नल हैंडलर के साथ बातचीत करते समय।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::Release`] को `order` के रूप में पास करके [`atomic::compiler_fence`] में उपलब्ध है।
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// एक कंपाइलर-ओनली मेमोरी बैरियर।
    ///
    /// मेमोरी एक्सेस को कंपाइलर द्वारा इस बाधा के पार कभी भी पुन: व्यवस्थित नहीं किया जाएगा, लेकिन इसके लिए कोई निर्देश नहीं दिया जाएगा।
    /// यह उसी थ्रेड पर संचालन के लिए उपयुक्त है जिसे प्रीमेप्ट किया जा सकता है, जैसे सिग्नल हैंडलर के साथ बातचीत करते समय।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`Ordering::AcqRel`] को `order` के रूप में पास करके [`atomic::compiler_fence`] में उपलब्ध है।
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// जादू आंतरिक जो फ़ंक्शन से जुड़ी विशेषताओं से इसका अर्थ प्राप्त करता है।
    ///
    /// उदाहरण के लिए, डेटाफ्लो इसका उपयोग स्थिर अभिकथन को इंजेक्ट करने के लिए करता है ताकि `rustc_peek(potentially_uninitialized)` वास्तव में दोबारा जांच कर सके कि डेटाफ्लो ने वास्तव में गणना की है कि यह नियंत्रण प्रवाह में उस बिंदु पर शुरू नहीं हुआ है।
    ///
    ///
    /// इस आंतरिक का उपयोग कंपाइलर के बाहर नहीं किया जाना चाहिए।
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// प्रक्रिया के निष्पादन को रोकता है।
    ///
    /// इस ऑपरेशन का एक अधिक उपयोगकर्ता के अनुकूल और स्थिर संस्करण [`std::process::abort`](../../std/process/fn.abort.html) है।
    ///
    pub fn abort() -> !;

    /// ऑप्टिमाइज़र को सूचित करता है कि कोड में यह बिंदु पहुंच योग्य नहीं है, और अधिक अनुकूलन को सक्षम करता है।
    ///
    /// एनबी, यह `unreachable!()` मैक्रो से बहुत अलग है: मैक्रो के विपरीत, जिसे panics निष्पादित करते समय, इस फ़ंक्शन के साथ चिह्नित कोड तक पहुंचना *अपरिभाषित व्यवहार* है।
    ///
    ///
    /// इस आंतरिक का स्थिर संस्करण [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) है।
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// अनुकूलक को सूचित करता है कि एक शर्त हमेशा सत्य होती है।
    /// यदि स्थिति गलत है, तो व्यवहार अपरिभाषित है।
    ///
    /// इस आंतरिक के लिए कोई कोड नहीं बनाया गया है, लेकिन अनुकूलक इसे (और इसकी स्थिति) को पास के बीच संरक्षित करने का प्रयास करेगा, जो आसपास के कोड के अनुकूलन में हस्तक्षेप कर सकता है और प्रदर्शन को कम कर सकता है।
    /// इसका उपयोग नहीं किया जाना चाहिए यदि इनवेरिएंट को ऑप्टिमाइज़र द्वारा स्वयं खोजा जा सकता है, या यदि यह कोई महत्वपूर्ण अनुकूलन सक्षम नहीं करता है।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// संकलक को संकेत देता है कि branch स्थिति सत्य होने की संभावना है।
    /// इसे पास किया गया मान लौटाता है।
    ///
    /// `if` कथनों के अलावा किसी अन्य उपयोग का शायद कोई प्रभाव नहीं पड़ेगा।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// संकलक को संकेत देता है कि branch स्थिति के गलत होने की संभावना है।
    /// इसे पास किया गया मान लौटाता है।
    ///
    /// `if` कथनों के अलावा किसी अन्य उपयोग का शायद कोई प्रभाव नहीं पड़ेगा।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// डिबगर द्वारा निरीक्षण के लिए ब्रेकपॉइंट ट्रैप निष्पादित करता है।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    pub fn breakpoint();

    /// बाइट्स में एक प्रकार का आकार।
    ///
    /// अधिक विशेष रूप से, यह संरेखण पैडिंग सहित एक ही प्रकार की लगातार वस्तुओं के बीच बाइट्स में ऑफसेट है।
    ///
    ///
    /// इस आंतरिक का स्थिर संस्करण [`core::mem::size_of`](crate::mem::size_of) है।
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// एक प्रकार का न्यूनतम संरेखण।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`core::mem::align_of`](crate::mem::align_of) है।
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// एक प्रकार का पसंदीदा संरेखण।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// बाइट्स में संदर्भित मान का आकार।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`mem::size_of_val`] है।
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// संदर्भित मूल्य का आवश्यक संरेखण।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`core::mem::align_of_val`](crate::mem::align_of_val) है।
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// एक प्रकार का नाम युक्त एक स्थिर स्ट्रिंग टुकड़ा प्राप्त करता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`core::any::type_name`](crate::any::type_name) है।
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// एक पहचानकर्ता प्राप्त करता है जो निर्दिष्ट प्रकार के लिए विश्व स्तर पर अद्वितीय है।
    /// यह फ़ंक्शन किसी भी प्रकार के लिए समान मान लौटाएगा, चाहे जो भी crate इसे लागू किया गया हो।
    ///
    ///
    /// इस आंतरिक का स्थिर संस्करण [`core::any::TypeId::of`](crate::any::TypeId::of) है।
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// असुरक्षित कार्यों के लिए एक गार्ड जिसे `T` निर्जन होने पर कभी भी निष्पादित नहीं किया जा सकता है:
    /// यह स्थिर रूप से या तो panic होगा, या कुछ भी नहीं करेगा।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// असुरक्षित कार्यों के लिए एक गार्ड जिसे कभी भी निष्पादित नहीं किया जा सकता है यदि `T` शून्य-प्रारंभिकरण की अनुमति नहीं देता है: यह स्थिर रूप से या तो panic होगा, या कुछ भी नहीं करेगा।
    ///
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    pub fn assert_zero_valid<T>();

    /// असुरक्षित कार्यों के लिए एक गार्ड जिसे कभी भी निष्पादित नहीं किया जा सकता है यदि `T` में अमान्य बिट पैटर्न हैं: यह स्थिर रूप से या तो panic होगा, या कुछ भी नहीं करेगा।
    ///
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    pub fn assert_uninit_valid<T>();

    /// एक स्थिर `Location` का संदर्भ मिलता है जो दर्शाता है कि इसे कहां कहा गया था।
    ///
    /// इसके बजाय [`core::panic::Location::caller`](crate::panic::Location::caller) का उपयोग करने पर विचार करें।
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// ड्रॉप ग्लू चलाए बिना मान को दायरे से बाहर ले जाता है।
    ///
    /// यह केवल [`mem::forget_unsized`] के लिए मौजूद है;सामान्य `forget` इसके बजाय `ManuallyDrop` का उपयोग करता है।
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// एक प्रकार के मान के बिट्स को दूसरे प्रकार के रूप में पुनर्व्याख्या करता है।
    ///
    /// दोनों प्रकारों का आकार समान होना चाहिए।
    /// न तो मूल, न ही परिणाम, [invalid value](../../nomicon/what-unsafe-does.html) हो सकता है।
    ///
    /// `transmute` शब्दार्थ रूप से एक प्रकार से दूसरे प्रकार की बिटवाइज़ चाल के बराबर है।यह बिट्स को स्रोत मान से गंतव्य मान में कॉपी करता है, फिर मूल को भूल जाता है।
    /// यह हुड के नीचे C के `memcpy` के बराबर है, ठीक `transmute_copy` की तरह।
    ///
    /// क्योंकि `transmute` एक बाय-वैल्यू ऑपरेशन है, *ट्रांसम्यूट किए गए मानों का संरेखण स्वयं एक चिंता का विषय नहीं है।
    /// किसी भी अन्य फ़ंक्शन की तरह, कंपाइलर पहले से ही सुनिश्चित करता है कि `T` और `U` दोनों ठीक से संरेखित हैं।
    /// हालांकि, जब उन मानों को ट्रांसमिट किया जाता है जो *कहीं और इंगित करते हैं*(जैसे पॉइंटर्स, संदर्भ, बॉक्स ...), कॉलर को पॉइंट-टू वैल्यू के उचित संरेखण को सुनिश्चित करना होता है।
    ///
    /// `transmute` **अविश्वसनीय रूप से** असुरक्षित है।इस फ़ंक्शन के साथ [undefined behavior][ub] उत्पन्न करने के कई तरीके हैं।`transmute` परम अंतिम उपाय होना चाहिए।
    ///
    /// [nomicon](../../nomicon/transmutes.html) में अतिरिक्त दस्तावेज हैं।
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// कुछ चीजें हैं जिनके लिए `transmute` वास्तव में उपयोगी है।
    ///
    /// पॉइंटर को फंक्शन पॉइंटर में बदलना।यह मशीनों के लिए पोर्टेबल *नहीं* है जहां फ़ंक्शन पॉइंटर्स और डेटा पॉइंटर्स के अलग-अलग आकार होते हैं।
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// जीवन भर का विस्तार करना, या एक अपरिवर्तनीय जीवनकाल को छोटा करना।यह उन्नत है, बहुत असुरक्षित Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// निराश न हों: `transmute` के कई उपयोग अन्य माध्यमों से प्राप्त किए जा सकते हैं।
    /// नीचे `transmute` के सामान्य अनुप्रयोग दिए गए हैं जिन्हें सुरक्षित निर्माणों से बदला जा सकता है।
    ///
    /// कच्चे bytes(`&[u8]`) को `u32`, `f64`, आदि में बदलना:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // इसके बजाय `u32::from_ne_bytes` का उपयोग करें
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // या एंडियननेस निर्दिष्ट करने के लिए `u32::from_le_bytes` या `u32::from_be_bytes` का उपयोग करें
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// एक पॉइंटर को `usize` में बदलना:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // इसके बजाय `as` कास्ट का उपयोग करें
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` को `&mut T` में बदलना:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // इसके बजाय एक पुनर्उधार का उपयोग करें
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` को `&mut U` में बदलना:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // अब, `as` को एक साथ रखें और पुन: उधार लें, ध्यान दें कि `as` `as` की चेनिंग सकर्मक नहीं है
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` को `&[u8]` में बदलना:
    ///
    /// ```
    /// // ऐसा करने का यह अच्छा तरीका नहीं है।
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // आप `str::as_bytes`. का उपयोग कर सकते हैं
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // या, यदि आप स्ट्रिंग अक्षर पर नियंत्रण रखते हैं, तो बस बाइट स्ट्रिंग का उपयोग करें
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` को `Vec<Option<&T>>` में बदलना।
    ///
    /// एक कंटेनर की आंतरिक प्रकार की सामग्री को प्रसारित करने के लिए, आपको यह सुनिश्चित करना होगा कि कंटेनर के किसी भी अपरिवर्तनीय का उल्लंघन न हो।
    /// `Vec` के लिए, इसका मतलब है कि आंतरिक प्रकारों के आकार *और संरेखण* दोनों का मिलान होना चाहिए।
    /// अन्य कंटेनर प्रकार, संरेखण, या यहां तक कि `TypeId` के आकार पर भरोसा कर सकते हैं, ऐसे में कंटेनर इनवेरिएंट का उल्लंघन किए बिना ट्रांसमिटिंग बिल्कुल भी संभव नहीं होगा।
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // vector को क्लोन करें क्योंकि हम बाद में उनका पुन: उपयोग करेंगे
    /// let v_clone = v_orig.clone();
    ///
    /// // ट्रांसम्यूट का उपयोग करना: यह `Vec` के अनिर्दिष्ट डेटा लेआउट पर निर्भर करता है, जो एक बुरा विचार है और अपरिभाषित व्यवहार का कारण बन सकता है।
    /////
    /// // हालाँकि, यह नो-कॉपी है।
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // यह सुझाया गया, सुरक्षित तरीका है।
    /// // हालाँकि, यह संपूर्ण vector को एक नए सरणी में कॉपी करता है।
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // डेटा लेआउट पर भरोसा किए बिना, यह "transmuting" और `Vec` का उचित नो-कॉपी, असुरक्षित तरीका है।
    /// // `transmute` को शाब्दिक रूप से कॉल करने के बजाय, हम एक पॉइंटर कास्ट करते हैं, लेकिन मूल आंतरिक प्रकार (`&i32`) को नए (`Option<&i32>`) में बदलने के मामले में, इसमें सभी समान चेतावनी हैं।
    /////
    /// // ऊपर दी गई जानकारी के अलावा, [`from_raw_parts`] दस्तावेज़ीकरण भी देखें।
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME इसे अपडेट करें जब vec_into_raw_parts स्थिर हो जाए।
    ///     // सुनिश्चित करें कि मूल vector गिराया नहीं गया है।
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` लागू करना:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // ऐसा करने के कई तरीके हैं, और निम्नलिखित (transmute) तरीके से कई समस्याएं हैं।
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // पहला: ट्रांसम्यूट सुरक्षित प्रकार नहीं है;यह सब जाँचता है कि T और
    ///         // यू एक ही आकार के हैं।
    ///         // दूसरा, यहीं, आपके पास एक ही स्मृति की ओर इशारा करते हुए दो परस्पर संदर्भ हैं।
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // यह प्रकार की सुरक्षा समस्याओं से छुटकारा दिलाता है;`&mut *` आपको `&mut T` या `* mut T` से *केवल* एक `&mut T` देगा।
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // हालांकि, आपके पास अभी भी एक ही स्मृति को इंगित करने वाले दो परिवर्तनीय संदर्भ हैं।
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // इस प्रकार मानक पुस्तकालय इसे करता है।
    /// // यह सबसे अच्छा तरीका है, अगर आपको ऐसा कुछ करने की ज़रूरत है
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // इसमें अब एक ही स्मृति की ओर इशारा करते हुए तीन परस्पर संदर्भ हैं।`slice`, प्रतिद्वंद्विता ret.0, और प्रतिद्वंद्विता ret.1।
    ///         // `slice` `let ptr = ...` के बाद कभी भी उपयोग नहीं किया जाता है, और इसलिए कोई इसे "dead" के रूप में मान सकता है, और इसलिए, आपके पास केवल दो वास्तविक परिवर्तनशील स्लाइस हैं।
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: हालांकि यह आंतरिक स्थिरांक को स्थिर बनाता है, हमारे पास const fn. में कुछ कस्टम कोड हैं
    // जाँच करता है जो `const fn` के भीतर इसके उपयोग को रोकता है।
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// यदि `T` के रूप में दिए गए वास्तविक प्रकार को ड्रॉप ग्लू की आवश्यकता है, तो `true` लौटाता है;`false` देता है यदि `T` के लिए प्रदान किया गया वास्तविक प्रकार `Copy` लागू करता है।
    ///
    ///
    /// यदि वास्तविक प्रकार को न तो ड्रॉप ग्लू की आवश्यकता है और न ही `Copy` लागू करता है, तो इस फ़ंक्शन का रिटर्न मान अनिर्दिष्ट है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`mem::needs_drop`](crate::mem::needs_drop) है।
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// एक सूचक से ऑफसेट की गणना करता है।
    ///
    /// इसे एक पूर्णांक में और उससे परिवर्तित होने से बचने के लिए एक आंतरिक के रूप में कार्यान्वित किया जाता है, क्योंकि रूपांतरण अलियासिंग जानकारी को फेंक देगा।
    ///
    /// # Safety
    ///
    /// प्रारंभिक और परिणामी सूचक दोनों या तो सीमा में होना चाहिए या किसी आवंटित वस्तु के अंत से एक बाइट पहले होना चाहिए।
    /// यदि या तो सूचक सीमा से बाहर है या अंकगणितीय अतिप्रवाह होता है, तो दिए गए मूल्य के किसी भी आगे उपयोग के परिणामस्वरूप अपरिभाषित व्यवहार होगा।
    ///
    ///
    /// इस आंतरिक का स्थिर संस्करण [`pointer::offset`] है।
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// संभावित रूप से रैपिंग करते हुए एक पॉइंटर से ऑफ़सेट की गणना करता है।
    ///
    /// यह एक पूर्णांक में और उससे परिवर्तित होने से बचने के लिए एक आंतरिक के रूप में कार्यान्वित किया जाता है, क्योंकि रूपांतरण कुछ अनुकूलन को रोकता है।
    ///
    /// # Safety
    ///
    /// `offset` आंतरिक के विपरीत, यह आंतरिक परिणामी सूचक को किसी आवंटित वस्तु के अंत से पहले या एक बाइट में इंगित करने के लिए प्रतिबंधित नहीं करता है, और यह दो के पूरक अंकगणित के साथ लपेटता है।
    /// परिणामी मान वास्तव में स्मृति तक पहुँचने के लिए उपयोग किए जाने के लिए आवश्यक रूप से मान्य नहीं है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`pointer::wrapping_offset`] है।
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// `count`*`size_of::<T>()` के आकार और के संरेखण के साथ उपयुक्त `llvm.memcpy.p0i8.0i8.*` आंतरिक के बराबर
    ///
    /// `min_align_of::<T>()`
    ///
    /// अस्थिर पैरामीटर `true` पर सेट है, इसलिए इसे तब तक ऑप्टिमाइज़ नहीं किया जाएगा जब तक कि आकार शून्य के बराबर न हो।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// उपयुक्त `llvm.memmove.p0i8.0i8.*` आंतरिक के बराबर, `count* size_of::<T>()` के आकार और Equi के संरेखण के साथ
    ///
    /// `min_align_of::<T>()`
    ///
    /// अस्थिर पैरामीटर `true` पर सेट है, इसलिए इसे तब तक ऑप्टिमाइज़ नहीं किया जाएगा जब तक कि आकार शून्य के बराबर न हो।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` के आकार और `min_align_of::<T>()` के संरेखण के साथ उपयुक्त `llvm.memset.p0i8.*` आंतरिक के बराबर।
    ///
    ///
    /// अस्थिर पैरामीटर `true` पर सेट है, इसलिए इसे तब तक ऑप्टिमाइज़ नहीं किया जाएगा जब तक कि आकार शून्य के बराबर न हो।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` पॉइंटर से एक वोलेटाइल लोड करता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`core::ptr::read_volatile`](crate::ptr::read_volatile) है।
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` पॉइंटर के लिए एक अस्थिर स्टोर करता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`core::ptr::write_volatile`](crate::ptr::write_volatile) है।
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` सूचक से एक अस्थिर भार करता है सूचक को संरेखित करने की आवश्यकता नहीं है।
    ///
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` पॉइंटर के लिए एक अस्थिर स्टोर करता है।
    /// सूचक को संरेखित करने की आवश्यकता नहीं है।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// किसी `f32` of का वर्गमूल लौटाता है
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// किसी `f64` of का वर्गमूल लौटाता है
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// एक `f32` को एक पूर्णांक शक्ति तक बढ़ाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// एक `f64` को एक पूर्णांक शक्ति तक बढ़ाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// किसी `f32` की ज्या लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// किसी `f64` की ज्या लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// किसी `f32` की कोज्या लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// किसी `f64` की कोज्या लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32` को `f32` पावर तक बढ़ाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64` को `f64` पावर तक बढ़ाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// किसी `f32` का घातांक लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// किसी `f64` का घातांक लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// `f32` की शक्ति तक बढ़ाए गए 2 लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// `f64` की शक्ति तक बढ़ाए गए 2 लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// किसी `f32` का प्राकृतिक लघुगणक लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// किसी `f64` का प्राकृतिक लघुगणक लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// किसी `f32` का आधार 10 लघुगणक देता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// किसी `f64` का आधार 10 लघुगणक देता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// किसी `f32` का आधार 2 लघुगणक देता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// किसी `f64` का आधार 2 लघुगणक देता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` मानों के लिए `a * b + c` लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` मानों के लिए `a * b + c` लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// किसी `f32` का निरपेक्ष मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// किसी `f64` का निरपेक्ष मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// कम से कम दो `f32` मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// कम से कम दो `f64` मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// अधिकतम दो `f32` मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// अधिकतम दो `f64` मान लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `f32` मानों के लिए `y` से `x` तक के चिह्न की प्रतिलिपि बनाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `f64` मानों के लिए `y` से `x` तक के चिह्न की प्रतिलिपि बनाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32` से कम या उसके बराबर सबसे बड़ा पूर्णांक देता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64` से कम या उसके बराबर सबसे बड़ा पूर्णांक देता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32` से बड़ा या उसके बराबर सबसे छोटा पूर्णांक देता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64` से बड़ा या उसके बराबर सबसे छोटा पूर्णांक देता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// किसी `f32` का पूर्णांक भाग लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// किसी `f64` का पूर्णांक भाग लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// निकटतम पूर्णांक को `f32` पर लौटाता है।
    /// यदि तर्क एक पूर्णांक नहीं है, तो एक अचूक फ़्लोटिंग-पॉइंट अपवाद बढ़ा सकता है।
    pub fn rintf32(x: f32) -> f32;
    /// निकटतम पूर्णांक को `f64` पर लौटाता है।
    /// यदि तर्क एक पूर्णांक नहीं है, तो एक अचूक फ़्लोटिंग-पॉइंट अपवाद बढ़ा सकता है।
    pub fn rintf64(x: f64) -> f64;

    /// निकटतम पूर्णांक को `f32` पर लौटाता है।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    pub fn nearbyintf32(x: f32) -> f32;
    /// निकटतम पूर्णांक को `f64` पर लौटाता है।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    pub fn nearbyintf64(x: f64) -> f64;

    /// निकटतम पूर्णांक को `f32` पर लौटाता है।आधे-अधूरे मामलों को शून्य से दूर कर देता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// निकटतम पूर्णांक को `f64` पर लौटाता है।आधे-अधूरे मामलों को शून्य से दूर कर देता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण है
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// फ्लोट जोड़ जो बीजीय नियमों के आधार पर अनुकूलन की अनुमति देता है।
    /// मान सकते हैं कि इनपुट सीमित हैं।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// फ्लोट घटाव जो बीजीय नियमों के आधार पर अनुकूलन की अनुमति देता है।
    /// मान सकते हैं कि इनपुट सीमित हैं।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// फ्लोट गुणन जो बीजीय नियमों के आधार पर अनुकूलन की अनुमति देता है।
    /// मान सकते हैं कि इनपुट सीमित हैं।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// फ्लोट डिवीजन जो बीजीय नियमों के आधार पर अनुकूलन की अनुमति देता है।
    /// मान सकते हैं कि इनपुट सीमित हैं।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// शेष फ़्लोट करें जो बीजीय नियमों के आधार पर अनुकूलन की अनुमति देता है।
    /// मान सकते हैं कि इनपुट सीमित हैं।
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// LLVM के fptoui/fptosi के साथ कनवर्ट करें, जो सीमा से बाहर के मानों के लिए undef लौट सकता है
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] और [`f64::to_int_unchecked`] के रूप में स्थिर।
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// पूर्णांक प्रकार `T`. में सेट बिट्स की संख्या लौटाता है
    ///
    /// इस आंतरिक के स्थिर संस्करण `count_ones` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// एक पूर्णांक प्रकार `T` में अग्रणी अनसेट बिट्स (zeroes) की संख्या लौटाता है।
    ///
    /// इस आंतरिक के स्थिर संस्करण `leading_zeros` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `0` मान वाला `x` `T` की बिट चौड़ाई लौटाएगा।
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` की तरह, लेकिन अतिरिक्त-असुरक्षित क्योंकि यह `undef` देता है जब `0` मान के साथ `x` दिया जाता है।
    ///
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// एक पूर्णांक प्रकार `T` में अनुगामी अनसेट बिट्स (zeroes) की संख्या लौटाता है।
    ///
    /// इस आंतरिक के स्थिर संस्करण `trailing_zeros` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` मान वाला `x` `T` की बिट चौड़ाई लौटाएगा:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` की तरह, लेकिन अतिरिक्त-असुरक्षित क्योंकि यह `undef` देता है जब `0` मान के साथ `x` दिया जाता है।
    ///
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// बाइट्स को एक पूर्णांक प्रकार `T` में उलट देता है।
    ///
    /// इस आंतरिक के स्थिर संस्करण `swap_bytes` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// बिट्स को एक पूर्णांक प्रकार `T` में उलट देता है।
    ///
    /// इस आंतरिक के स्थिर संस्करण `reverse_bits` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// चेक किया गया पूर्णांक जोड़ करता है।
    ///
    /// इस आंतरिक के स्थिर संस्करण `overflowing_add` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// चेक किया गया पूर्णांक घटाव करता है
    ///
    /// इस आंतरिक के स्थिर संस्करण `overflowing_sub` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// चेक किया गया पूर्णांक गुणन करता है
    ///
    /// इस आंतरिक के स्थिर संस्करण `overflowing_mul` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// एक सटीक विभाजन करता है, जिसके परिणामस्वरूप अपरिभाषित व्यवहार होता है जहां `x % y != 0` या `y == 0` या `x == T::MIN && y == -1`
    ///
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// एक अनियंत्रित विभाजन करता है, जिसके परिणामस्वरूप अपरिभाषित व्यवहार होता है जहां `y == 0` या `x == T::MIN && y == -1`
    ///
    ///
    /// इस आंतरिक के लिए सुरक्षित रैपर `checked_div` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// एक अनियंत्रित विभाजन के शेष को लौटाता है, जिसके परिणामस्वरूप `y == 0` या `x == T::MIN && y == -1`. पर अपरिभाषित व्यवहार होता है
    ///
    ///
    /// इस आंतरिक के लिए सुरक्षित रैपर `checked_rem` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// एक अनियंत्रित बाएं शिफ्ट करता है, जिसके परिणामस्वरूप `y < 0` या `y >= N`, जहां एन बिट्स में टी की चौड़ाई है, अपरिभाषित व्यवहार होता है।
    ///
    ///
    /// इस आंतरिक के लिए सुरक्षित रैपर `checked_shl` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// एक अनियंत्रित दायां बदलाव करता है, जिसके परिणामस्वरूप `y < 0` या `y >= N` में अपरिभाषित व्यवहार होता है, जहां N बिट्स में T की चौड़ाई है।
    ///
    ///
    /// इस आंतरिक के लिए सुरक्षित रैपर `checked_shr` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// एक अनियंत्रित जोड़ का परिणाम देता है, जिसके परिणामस्वरूप `x + y > T::MAX` या `x + y < T::MIN` होने पर अपरिभाषित व्यवहार होता है।
    ///
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// एक अनियंत्रित घटाव का परिणाम देता है, जिसके परिणामस्वरूप `x - y > T::MAX` या `x - y < T::MIN` होने पर अपरिभाषित व्यवहार होता है।
    ///
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// एक अनियंत्रित गुणन का परिणाम देता है, जिसके परिणामस्वरूप `x *y > T::MAX` या `x* y < T::MIN` होने पर अपरिभाषित व्यवहार होता है।
    ///
    ///
    /// इस आंतरिक में एक स्थिर समकक्ष नहीं है।
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// बाईं ओर घुमाता है।
    ///
    /// इस आंतरिक के स्थिर संस्करण `rotate_left` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// राइट रोटेट करता है।
    ///
    /// इस आंतरिक के स्थिर संस्करण `rotate_right` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// रिटर्न (ए + बी) मॉड 2 <sup>एन</sup>, जहां एन बिट्स में टी की चौड़ाई है।
    ///
    /// इस आंतरिक के स्थिर संस्करण `wrapping_add` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// रिटर्न (ए, बी) मॉड 2 <sup>एन</sup>, जहां एन बिट्स में टी की चौड़ाई है।
    ///
    /// इस आंतरिक के स्थिर संस्करण `wrapping_sub` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// रिटर्न (ए * बी) मॉड 2 <sup>एन</sup>, जहां एन बिट्स में टी की चौड़ाई है।
    ///
    /// इस आंतरिक के स्थिर संस्करण `wrapping_mul` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// संख्यात्मक सीमा पर संतृप्त `a + b` की गणना करता है।
    ///
    /// इस आंतरिक के स्थिर संस्करण `saturating_add` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// संख्यात्मक सीमा पर संतृप्त `a - b` की गणना करता है।
    ///
    /// इस आंतरिक के स्थिर संस्करण `saturating_sub` विधि के माध्यम से पूर्णांक आदिम पर उपलब्ध हैं।
    /// उदाहरण के लिए,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' में वैरिएंट के लिए विवेचक का मान लौटाता है;
    /// यदि `T` में कोई विभेदक नहीं है, तो `0` लौटाता है।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`core::mem::discriminant`](crate::mem::discriminant) है।
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// `usize` कास्ट प्रकार के प्रकारों की संख्या को `usize` पर लौटाता है;
    /// यदि `T` का कोई प्रकार नहीं है, तो `0` लौटाता है।निर्जन प्रकारों की गणना की जाएगी।
    ///
    /// इस आंतरिक का स्थिर संस्करण [`mem::variant_count`] है।
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust का "try catch" निर्माण जो डेटा पॉइंटर `data` के साथ फ़ंक्शन पॉइंटर `try_fn` को आमंत्रित करता है।
    ///
    /// तीसरा तर्क एक फ़ंक्शन है जिसे panic होने पर कहा जाता है।
    /// यह फ़ंक्शन डेटा पॉइंटर और पॉइंटर को लक्ष्य-विशिष्ट अपवाद ऑब्जेक्ट पर ले जाता है जिसे पकड़ा गया था।
    ///
    /// अधिक जानकारी के लिए कंपाइलर का स्रोत और साथ ही std का कैच कार्यान्वयन देखें।
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// LLVM के अनुसार `!nontemporal` स्टोर उत्सर्जित करता है (उनके डॉक्स देखें)।
    /// शायद कभी स्थिर नहीं होगा।
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// विवरण के लिए `<*const T>::offset_from` का दस्तावेज़ीकरण देखें।
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// विवरण के लिए `<*const T>::guaranteed_eq` का दस्तावेज़ीकरण देखें।
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// विवरण के लिए `<*const T>::guaranteed_ne` का दस्तावेज़ीकरण देखें।
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// संकलन समय पर आवंटित करें।रनटाइम पर नहीं बुलाया जाना चाहिए।
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// कुछ कार्यों को यहां परिभाषित किया गया है क्योंकि वे गलती से इस मॉड्यूल में स्थिर पर उपलब्ध करा दिए गए हैं।
// <https://github.com/rust-lang/rust/issues/15702> देखें।
// (`transmute` भी इस श्रेणी में आता है, लेकिन `T` और `U` का आकार समान होने की जांच के कारण इसे लपेटा नहीं जा सकता है।)
//

/// जांचता है कि `ptr`, `align_of::<T>()` के संबंध में ठीक से संरेखित है या नहीं।
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count *size_of::<T>()` बाइट्स को `src` से `dst` में कॉपी करता है।स्रोत और गंतव्य को ओवरलैप* नहीं* करना चाहिए।
///
/// स्मृति के उन क्षेत्रों के लिए जो ओवरलैप हो सकते हैं, इसके बजाय [`copy`] का उपयोग करें।
///
/// `copy_nonoverlapping` शब्दार्थ रूप से C के [`memcpy`] के समतुल्य है, लेकिन तर्क क्रम की अदला-बदली के साथ।
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// यदि निम्न में से किसी भी स्थिति का उल्लंघन किया जाता है तो व्यवहार अपरिभाषित होता है:
///
/// * `src` `count * size_of::<T>()` बाइट्स के पढ़ने के लिए [valid] होना चाहिए।
///
/// * `dst` `count * size_of::<T>()` बाइट्स लिखने के लिए [valid] होना चाहिए।
///
/// * `src` और `dst` दोनों को ठीक से संरेखित किया जाना चाहिए।
///
/// * मेमोरी का क्षेत्र `गिनती. के आकार के साथ `src` से शुरू होता है *
///   का आकार: :<T>()` बाइट्स को समान आकार के साथ `dst` से शुरू होने वाले मेमोरी के क्षेत्र के साथ *नहीं* ओवरलैप होना चाहिए।
///
/// [`read`] की तरह, `copy_nonoverlapping`, `T` की एक बिटवाइज़ कॉपी बनाता है, भले ही `T` [`Copy`] हो या नहीं।
/// यदि `T` [`Copy`] नहीं है, तो `*src` से शुरू होने वाले क्षेत्र और `* dst` से शुरू होने वाले क्षेत्र में *दोनों* का उपयोग करके [violate memory safety][read-ownership] कर सकते हैं।
///
///
/// ध्यान दें कि भले ही प्रभावी ढंग से कॉपी किया गया आकार (`गिनती * size_of: :<T>()`) `0` है, पॉइंटर्स गैर-नल और ठीक से संरेखित होने चाहिए।
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] को मैन्युअल रूप से लागू करें:
///
/// ```
/// use std::ptr;
///
/// /// `src` के सभी तत्वों को `dst` में ले जाता है, `src` को खाली छोड़ देता है।
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // सुनिश्चित करें कि `dst` में सभी `src` को धारण करने की पर्याप्त क्षमता है।
///     dst.reserve(src_len);
///
///     unsafe {
///         // ऑफ़सेट करने के लिए कॉल हमेशा सुरक्षित होती है क्योंकि `Vec` कभी भी `isize::MAX` बाइट्स से अधिक आवंटित नहीं करेगा।
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // इसकी सामग्री को छोड़े बिना `src` को छोटा करें।
///         // panics के नीचे कुछ और होने की स्थिति में समस्याओं से बचने के लिए हम पहले ऐसा करते हैं।
///         src.set_len(0);
///
///         // दो क्षेत्रों को ओवरलैप नहीं किया जा सकता क्योंकि परिवर्तनीय संदर्भ उपनाम नहीं हैं, और दो अलग-अलग vectors एक ही स्मृति के स्वामी नहीं हो सकते हैं।
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // `dst` को सूचित करें कि इसमें अब `src` की सामग्री है।
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: ये जांच केवल रन टाइम पर करें
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // कोडजन प्रभाव को छोटा रखने के लिए घबराएं नहीं।
        abort();
    }*/

    // सुरक्षा: `copy_nonoverlapping` के लिए सुरक्षा अनुबंध होना चाहिए
    // फोन करने वाले ने सही ठहराया।
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count * size_of::<T>()` बाइट्स को `src` से `dst` में कॉपी करता है।स्रोत और गंतव्य ओवरलैप हो सकते हैं।
///
/// यदि स्रोत और गंतव्य *कभी* ओवरलैप नहीं होंगे, तो इसके बजाय [`copy_nonoverlapping`] का उपयोग किया जा सकता है।
///
/// `copy` शब्दार्थ रूप से C के [`memmove`] के समतुल्य है, लेकिन तर्क क्रम की अदला-बदली के साथ।
/// कॉपी करना इस तरह होता है जैसे बाइट्स को `src` से एक अस्थायी सरणी में कॉपी किया गया था और फिर सरणी से `dst` में कॉपी किया गया था।
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// यदि निम्न में से किसी भी स्थिति का उल्लंघन किया जाता है तो व्यवहार अपरिभाषित होता है:
///
/// * `src` `count * size_of::<T>()` बाइट्स के पढ़ने के लिए [valid] होना चाहिए।
///
/// * `dst` `count * size_of::<T>()` बाइट्स लिखने के लिए [valid] होना चाहिए।
///
/// * `src` और `dst` दोनों को ठीक से संरेखित किया जाना चाहिए।
///
/// [`read`] की तरह, `copy`, `T` की एक बिटवाइज़ कॉपी बनाता है, भले ही `T` [`Copy`] हो या नहीं।
/// यदि `T` [`Copy`] नहीं है, तो `*src` से शुरू होने वाले क्षेत्र और `* dst` से शुरू होने वाले क्षेत्र में दोनों मानों का उपयोग करके [violate memory safety][read-ownership] किया जा सकता है।
///
///
/// ध्यान दें कि भले ही प्रभावी ढंग से कॉपी किया गया आकार (`गिनती * size_of: :<T>()`) `0` है, पॉइंटर्स गैर-नल और ठीक से संरेखित होने चाहिए।
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// एक असुरक्षित बफर से कुशलतापूर्वक Rust vector बनाएं:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` इसके प्रकार और गैर-शून्य के लिए सही ढंग से संरेखित होना चाहिए।
/// /// * `ptr` `T` प्रकार के `elts` सन्निहित तत्वों के पढ़ने के लिए मान्य होना चाहिए।
/// /// * `T: Copy` तक इस फ़ंक्शन को कॉल करने के बाद उन तत्वों का उपयोग नहीं किया जाना चाहिए।
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // सुरक्षा: हमारी पूर्व शर्त सुनिश्चित करती है कि स्रोत संरेखित और मान्य है,
///     // और `Vec::with_capacity` सुनिश्चित करता है कि हमारे पास उन्हें लिखने के लिए प्रयोग करने योग्य स्थान है।
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // सुरक्षा: हमने इसे पहले इतनी क्षमता के साथ बनाया था,
///     // और पिछले `copy` ने इन तत्वों को इनिशियलाइज़ किया है।
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: ये जांच केवल रन टाइम पर करें
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // कोडजन प्रभाव को छोटा रखने के लिए घबराएं नहीं।
        abort();
    }*/

    // सुरक्षा: कॉल करने वाले द्वारा `copy` के सुरक्षा अनुबंध को बरकरार रखा जाना चाहिए।
    unsafe { copy(src, dst, count) }
}

/// `dst` से `val` तक मेमोरी के `count * size_of::<T>()` बाइट्स सेट करता है।
///
/// `write_bytes` C के [`memset`] के समान है, लेकिन `count * size_of::<T>()` बाइट्स को `val` पर सेट करता है।
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// यदि निम्न में से किसी भी स्थिति का उल्लंघन किया जाता है तो व्यवहार अपरिभाषित होता है:
///
/// * `dst` `count * size_of::<T>()` बाइट्स लिखने के लिए [valid] होना चाहिए।
///
/// * `dst` ठीक से संरेखित होना चाहिए।
///
/// इसके अतिरिक्त, कॉलर को यह सुनिश्चित करना चाहिए कि स्मृति के दिए गए क्षेत्र में `count * size_of::<T>()` बाइट्स लिखने से `T` का वैध मान प्राप्त होता है।
/// `T` के रूप में टाइप की गई मेमोरी के क्षेत्र का उपयोग करना जिसमें `T` का अमान्य मान है, अपरिभाषित व्यवहार है।
///
/// ध्यान दें कि भले ही प्रभावी ढंग से कॉपी किया गया आकार (`गिनती * size_of: :<T>()`) `0` है, पॉइंटर गैर-नल होना चाहिए और ठीक से संरेखित होना चाहिए।
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// अमान्य मान बनाना:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // एक नल पॉइंटर के साथ `Box<T>` को अधिलेखित करके पहले से धारित मान को लीक करता है।
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // इस बिंदु पर, `v` का उपयोग करने या छोड़ने से अपरिभाषित व्यवहार होता है।
/// // drop(v); // ERROR
///
/// // यहां तक कि `v` "uses" को लीक करना, और इसलिए अपरिभाषित व्यवहार है।
/// // mem::forget(v); // ERROR
///
/// // वास्तव में, `v` मूल प्रकार के लेआउट इनवेरिएंट के अनुसार अमान्य है, इसलिए इसे छूने वाला कोई भी ऑपरेशन अपरिभाषित व्यवहार है।
/////
/// // चलो v2 =वी;//त्रुटि
///
/// unsafe {
///     // आइए इसके बजाय एक वैध मान डालें
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // अब डिब्बा ठीक है
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // सुरक्षा: कॉल करने वाले द्वारा `write_bytes` के सुरक्षा अनुबंध को बरकरार रखा जाना चाहिए।
    unsafe { write_bytes(dst, val, count) }
}