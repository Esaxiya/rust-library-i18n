//! साझा करने योग्य परिवर्तनीय कंटेनर।
//!
//! Rust स्मृति सुरक्षा इस नियम पर आधारित है: किसी वस्तु `T` को देखते हुए, निम्न में से केवल एक होना संभव है:
//!
//! - ऑब्जेक्ट के लिए कई अपरिवर्तनीय संदर्भ (`&T`) (जिसे **अलियासिंग** के रूप में भी जाना जाता है) होना।
//! - वस्तु के लिए एक परिवर्तनशील संदर्भ (`&mut T`) होना (जिसे **परिवर्तनशीलता** भी कहा जाता है)।
//!
//! यह Rust कंपाइलर द्वारा लागू किया गया है।हालांकि, ऐसी स्थितियां हैं जहां यह नियम पर्याप्त लचीला नहीं है।कभी-कभी किसी वस्तु के कई संदर्भ होने और फिर भी उसे बदलने की आवश्यकता होती है।
//!
//! अलियासिंग की उपस्थिति में भी, नियंत्रित तरीके से परिवर्तनशीलता की अनुमति देने के लिए साझा करने योग्य परिवर्तनशील कंटेनर मौजूद हैं।[`Cell<T>`] और [`RefCell<T>`] दोनों इसे सिंगल-थ्रेडेड तरीके से करने की अनुमति देते हैं।
//! हालांकि, न तो `Cell<T>` और न ही `RefCell<T>` थ्रेड सुरक्षित हैं (वे [`Sync`] लागू नहीं करते हैं)।
//! यदि आपको कई थ्रेड्स के बीच अलियासिंग और म्यूटेशन करने की आवश्यकता है, तो [`Mutex<T>`], [`RwLock<T>`] या [`atomic`] प्रकारों का उपयोग करना संभव है।
//!
//! `Cell<T>` और `RefCell<T>` प्रकारों के मान साझा संदर्भों के माध्यम से उत्परिवर्तित हो सकते हैं (अर्थात
//! सामान्य `&T` प्रकार), जबकि अधिकांश Rust प्रकारों को केवल अद्वितीय (`&mut T`) संदर्भों के माध्यम से उत्परिवर्तित किया जा सकता है।
//! हम कहते हैं कि `Cell<T>` और `RefCell<T>` विशिष्ट Rust प्रकारों के विपरीत 'आंतरिक परिवर्तनशीलता' प्रदान करते हैं जो 'विरासत में मिली परिवर्तनशीलता' प्रदर्शित करते हैं।
//!
//! सेल प्रकार दो फ्लेवर में आते हैं: `Cell<T>` और `RefCell<T>`।`Cell<T>`, `Cell<T>` के अंदर और बाहर मूल्यों को स्थानांतरित करके आंतरिक परिवर्तनशीलता को लागू करता है।
//! मानों के बजाय संदर्भों का उपयोग करने के लिए, किसी को `RefCell<T>` प्रकार का उपयोग करना चाहिए, उत्परिवर्तन से पहले एक राइट लॉक प्राप्त करना चाहिए।`Cell<T>` वर्तमान आंतरिक मूल्य को पुनः प्राप्त करने और बदलने के तरीके प्रदान करता है:
//!
//!  - [`Copy`] को लागू करने वाले प्रकारों के लिए, [`get`](Cell::get) विधि वर्तमान आंतरिक मान को पुनः प्राप्त करती है।
//!  - [`Default`] को लागू करने वाले प्रकारों के लिए, [`take`](Cell::take) विधि वर्तमान आंतरिक मान को [`Default::default()`] से बदल देती है और प्रतिस्थापित मान लौटा देती है।
//!  - सभी प्रकारों के लिए, [`replace`](Cell::replace) विधि वर्तमान आंतरिक मान को प्रतिस्थापित करती है और प्रतिस्थापित मान लौटाती है और [`into_inner`](Cell::into_inner) विधि `Cell<T>` का उपभोग करती है और आंतरिक मान लौटाती है।
//!  इसके अतिरिक्त, [`set`](Cell::set) विधि आंतरिक मान को प्रतिस्थापित कर देती है, प्रतिस्थापित मान को छोड़ देती है।
//!
//! `RefCell<T>` 'गतिशील उधार' को लागू करने के लिए Rust के जीवनकाल का उपयोग करता है, एक ऐसी प्रक्रिया जिसके द्वारा कोई व्यक्ति आंतरिक मूल्य के लिए अस्थायी, अनन्य, परिवर्तनशील पहुंच का दावा कर सकता है।
//! 'रेफसेल' के लिए उधार<T>Rust के मूल संदर्भ प्रकारों के विपरीत, 'रनटाइम पर' ट्रैक किए जाते हैं, जो संकलन समय पर पूरी तरह से स्थिर रूप से ट्रैक किए जाते हैं।
//! क्योंकि `RefCell<T>` उधार गतिशील हैं, ऐसे मूल्य को उधार लेने का प्रयास करना संभव है जो पहले से ही पारस्परिक रूप से उधार लिया गया है;जब ऐसा होता है तो इसका परिणाम थ्रेड panic होता है।
//!
//! # आंतरिक परिवर्तनशीलता का चयन कब करें
//!
//! अधिक सामान्य विरासत में मिली परिवर्तनशीलता, जहां किसी के पास किसी मान को बदलने के लिए अद्वितीय पहुंच होनी चाहिए, प्रमुख भाषा तत्वों में से एक है जो Rust को पॉइंटर अलियासिंग के बारे में दृढ़ता से तर्क करने में सक्षम बनाता है, स्थिर रूप से क्रैश बग को रोकता है।
//! उसके कारण, विरासत में मिली परिवर्तनशीलता को प्राथमिकता दी जाती है, और आंतरिक परिवर्तनशीलता एक अंतिम उपाय है।
//! चूंकि सेल प्रकार उत्परिवर्तन को सक्षम करते हैं जहां इसे अन्यथा अस्वीकृत किया जाएगा, ऐसे अवसर होते हैं जब आंतरिक परिवर्तनशीलता उपयुक्त हो सकती है, या यहां तक कि * का उपयोग किया जाना चाहिए, उदाहरण के लिए
//!
//! * कुछ अपरिवर्तनीय की परिवर्तनशीलता 'inside' का परिचय
//! * तार्किक रूप से अपरिवर्तनीय विधियों का कार्यान्वयन विवरण।
//! * [`Clone`] के परिवर्तनशील कार्यान्वयन।
//!
//! ## कुछ अपरिवर्तनीय की परिवर्तनशीलता 'inside' का परिचय
//!
//! [`Rc<T>`] और [`Arc<T>`] सहित कई साझा स्मार्ट पॉइंटर प्रकार कंटेनर प्रदान करते हैं जिन्हें क्लोन किया जा सकता है और कई पार्टियों के बीच साझा किया जा सकता है।
//! क्योंकि निहित मूल्यों को गुणा-अलियास किया जा सकता है, उन्हें केवल `&` के साथ उधार लिया जा सकता है, `&mut` नहीं।
//! कोशिकाओं के बिना इन स्मार्ट पॉइंटर्स के अंदर डेटा को बिल्कुल भी बदलना असंभव होगा।
//!
//! फिर परिवर्तनशीलता को पुन: प्रस्तुत करने के लिए साझा सूचक प्रकारों के अंदर `RefCell<T>` डालना बहुत आम है:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // गतिशील उधार के दायरे को सीमित करने के लिए एक नया ब्लॉक बनाएं
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // ध्यान दें कि यदि हमने कैश के पिछले उधार को दायरे से बाहर नहीं होने दिया था, तो बाद के उधार के कारण एक गतिशील धागा panic होगा।
//!     //
//!     // यह `RefCell` का उपयोग करने का प्रमुख खतरा है।
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! ध्यान दें कि यह उदाहरण `Rc<T>` का उपयोग करता है न कि `Arc<T>` का।`रेफसेल<T>`s सिंगल-थ्रेडेड परिदृश्यों के लिए हैं।यदि आपको बहु-थ्रेडेड स्थिति में साझा परिवर्तनशीलता की आवश्यकता है, तो [`RwLock<T>`] या [`Mutex<T>`] का उपयोग करने पर विचार करें।
//!
//! ## तार्किक रूप से अपरिवर्तनीय विधियों का कार्यान्वयन विवरण
//!
//! कभी-कभी यह वांछनीय हो सकता है कि एपीआई में यह उजागर न करें कि "under the hood" में उत्परिवर्तन हो रहा है।
//! ऐसा इसलिए हो सकता है क्योंकि तार्किक रूप से ऑपरेशन अपरिवर्तनीय है, लेकिन उदाहरण के लिए, कैशिंग कार्यान्वयन को उत्परिवर्तन करने के लिए मजबूर करता है;या क्योंकि आपको trait विधि को लागू करने के लिए उत्परिवर्तन को नियोजित करना होगा जिसे मूल रूप से `&self` लेने के लिए परिभाषित किया गया था।
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // महंगी गणना यहाँ जाती है
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone`. के परिवर्तनशील कार्यान्वयन
//!
//! यह पिछले का एक विशेष, लेकिन सामान्य मामला है: अपरिवर्तनीय प्रतीत होने वाले संचालन के लिए छुपा उत्परिवर्तन।
//! [`clone`](Clone::clone) विधि से स्रोत मान नहीं बदलने की उम्मीद है, और `&self` लेने के लिए घोषित किया गया है, `&mut self` नहीं।
//! इसलिए, `clone` विधि में होने वाले किसी भी उत्परिवर्तन को सेल प्रकारों का उपयोग करना चाहिए।
//! उदाहरण के लिए, [`Rc<T>`] एक `Cell<T>` के भीतर अपनी संदर्भ संख्या बनाए रखता है।
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// एक परिवर्तनीय स्मृति स्थान।
///
/// # Examples
///
/// इस उदाहरण में, आप देख सकते हैं कि `Cell<T>` एक अपरिवर्तनीय संरचना के अंदर उत्परिवर्तन को सक्षम करता है।
/// दूसरे शब्दों में, यह "interior mutability" को सक्षम बनाता है।
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // त्रुटि: `my_struct` अपरिवर्तनीय है
/// // my_struct.regular_field =नया_मान;
///
/// // काम करता है: हालांकि `my_struct` अपरिवर्तनीय है, `special_field` एक `Cell` है,
/// // जिसे हमेशा उत्परिवर्तित किया जा सकता है
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// अधिक के लिए [module-level documentation](self) देखें।
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// T के लिए `Default` मान के साथ `Cell<T>` बनाता है।
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// दिए गए मान वाला एक नया `Cell` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// निहित मान सेट करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// दो कोशिकाओं के मूल्यों को स्वैप करता है।
    /// `std::mem::swap` के साथ अंतर यह है कि इस फ़ंक्शन को `&mut` संदर्भ की आवश्यकता नहीं है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // सुरक्षा: अलग थ्रेड से कॉल करने पर यह जोखिम भरा हो सकता है, लेकिन `Cell`
        // `!Sync` है तो ऐसा नहीं होगा।
        // यह किसी भी पॉइंटर्स को अमान्य नहीं करेगा क्योंकि `Cell` सुनिश्चित करता है कि इन 'सेल' में से किसी एक में और कुछ भी इंगित नहीं किया जाएगा।
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// निहित मान को `val` से बदल देता है, और पुराना निहित मान लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // सुरक्षा: यदि एक अलग थ्रेड से कॉल किया जाता है तो यह डेटा दौड़ का कारण बन सकता है,
        // लेकिन `Cell` `!Sync` है इसलिए ऐसा नहीं होगा।
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// मान को खोल देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// निहित मूल्य की एक प्रति देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // सुरक्षा: यदि एक अलग थ्रेड से कॉल किया जाता है तो यह डेटा दौड़ का कारण बन सकता है,
        // लेकिन `Cell` `!Sync` है इसलिए ऐसा नहीं होगा।
        unsafe { *self.value.get() }
    }

    /// किसी फ़ंक्शन का उपयोग करके निहित मान को अपडेट करता है और नया मान देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// इस सेल में अंतर्निहित डेटा के लिए एक कच्चा सूचक लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// अंतर्निहित डेटा के लिए एक परिवर्तनशील संदर्भ देता है।
    ///
    /// यह कॉल `Cell` को पारस्परिक रूप से (संकलन-समय पर) उधार लेता है जो गारंटी देता है कि हमारे पास एकमात्र संदर्भ है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T` से `&Cell<T>` लौटाता है
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // सुरक्षा: `&mut` अद्वितीय पहुंच सुनिश्चित करता है।
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// `Default::default()` को उसके स्थान पर छोड़ते हुए, सेल का मान लेता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>` से `&[Cell<T>]` लौटाता है
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // सुरक्षा: `Cell<T>` में `T` के समान मेमोरी लेआउट है।
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// गतिशील रूप से जाँचे गए उधार नियमों के साथ एक परिवर्तनशील स्मृति स्थान
///
/// अधिक के लिए [module-level documentation](self) देखें।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] द्वारा लौटाई गई त्रुटि।
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] द्वारा लौटाई गई त्रुटि।
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// सकारात्मक मान सक्रिय `Ref` की संख्या का प्रतिनिधित्व करते हैं।नकारात्मक मान सक्रिय `RefMut` की संख्या का प्रतिनिधित्व करते हैं।
// एकाधिक `RefMut` केवल एक समय में सक्रिय हो सकते हैं यदि वे `RefCell` के अलग, गैर-अतिव्यापी घटकों (उदाहरण के लिए, एक स्लाइस की विभिन्न श्रेणियां) को संदर्भित करते हैं।
//
// `Ref` और `RefMut` दोनों आकार में दो शब्द हैं, और इसलिए `usize` रेंज के आधे हिस्से को ओवरफ्लो करने के लिए कभी भी पर्याप्त `Ref` या `RefMut` अस्तित्व में नहीं होगा।
// इस प्रकार, एक `BorrowFlag` शायद कभी भी ओवरफ्लो या अंडरफ्लो नहीं होगा।
// हालांकि, यह कोई गारंटी नहीं है, क्योंकि एक पैथोलॉजिकल प्रोग्राम बार-बार बना सकता है और फिर mem::forget `Ref` या `RefMut`s बना सकता है।
// इस प्रकार, असुरक्षितता से बचने के लिए सभी कोड को स्पष्ट रूप से ओवरफ्लो और अंडरफ्लो की जांच करनी चाहिए, या कम से कम उस स्थिति में सही व्यवहार करना चाहिए जो ओवरफ्लो या अंडरफ्लो होता है (उदाहरण के लिए, BorrowRef::new देखें)।
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` युक्त एक नया `RefCell` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// लपेटा हुआ मान लौटाते हुए, `RefCell` का उपभोग करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // चूंकि यह फ़ंक्शन मान के अनुसार `self` (`RefCell`) लेता है, इसलिए कंपाइलर स्थिर रूप से सत्यापित करता है कि यह वर्तमान में उधार नहीं लिया गया है।
        //
        self.value.into_inner()
    }

    /// लिपटे हुए मान को एक नए के साथ बदल देता है, पुराने मान को वापस कर देता है, बिना किसी एक को प्रारंभ किए।
    ///
    ///
    /// यह फ़ंक्शन [`std::mem::replace`](../mem/fn.replace.html) से मेल खाता है।
    ///
    /// # Panics
    ///
    /// Panics यदि मूल्य वर्तमान में उधार लिया गया है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// रैप किए गए मान को `f` से परिकलित एक नए के साथ बदल देता है, पुराने मान को लौटाता है, बिना किसी एक को प्रारंभ किए।
    ///
    ///
    /// # Panics
    ///
    /// Panics यदि मूल्य वर्तमान में उधार लिया गया है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// किसी एक को इनिशियलाइज़ किए बिना, `self` के रैप्ड वैल्यू को `other` के रैप्ड वैल्यू के साथ स्वैप करें।
    ///
    ///
    /// यह फ़ंक्शन [`std::mem::swap`](../mem/fn.swap.html) से मेल खाता है।
    ///
    /// # Panics
    ///
    /// Panics यदि दोनों में से किसी एक में मान वर्तमान में उधार लिया गया है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// लिपटे हुए मूल्य को अपरिवर्तनीय रूप से उधार लेता है।
    ///
    /// उधार तब तक रहता है जब तक लौटा हुआ `Ref` दायरे से बाहर नहीं हो जाता।
    /// एक ही समय में कई अपरिवर्तनीय उधार लिए जा सकते हैं।
    ///
    /// # Panics
    ///
    /// Panics यदि मूल्य वर्तमान में परस्पर उधार लिया गया है।
    /// नॉन-पैनिकिंग वैरिएंट के लिए, [`try_borrow`](#method.try_borrow) का उपयोग करें।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic का एक उदाहरण:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// अपरिवर्तनीय रूप से लिपटे मूल्य को उधार लेता है, यदि मूल्य वर्तमान में पारस्परिक रूप से उधार लिया गया है तो एक त्रुटि लौटाता है।
    ///
    ///
    /// उधार तब तक रहता है जब तक लौटा हुआ `Ref` दायरे से बाहर नहीं हो जाता।
    /// एक ही समय में कई अपरिवर्तनीय उधार लिए जा सकते हैं।
    ///
    /// यह [`borrow`](#method.borrow) का नॉन-पैनिकिंग वेरिएंट है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // सुरक्षा: `BorrowRef` सुनिश्चित करता है कि केवल अपरिवर्तनीय पहुंच है
            // उधार लेते समय मूल्य के लिए।
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// पारस्परिक रूप से लिपटे मूल्य को उधार लेता है।
    ///
    /// उधार तब तक रहता है जब तक कि लौटा हुआ `RefMut` या सभी `RefMut` इससे बाहर निकलने के दायरे से बाहर नहीं निकल जाते।
    ///
    /// यह उधार सक्रिय होने पर मूल्य उधार नहीं लिया जा सकता है।
    ///
    /// # Panics
    ///
    /// Panics यदि मूल्य वर्तमान में उधार लिया गया है।
    /// नॉन-पैनिकिंग वैरिएंट के लिए, [`try_borrow_mut`](#method.try_borrow_mut) का उपयोग करें।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic का एक उदाहरण:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// पारस्परिक रूप से लिपटे मूल्य को उधार लेता है, यदि मूल्य वर्तमान में उधार लिया गया है तो एक त्रुटि लौटाता है।
    ///
    ///
    /// उधार तब तक रहता है जब तक कि लौटा हुआ `RefMut` या सभी `RefMut` इससे बाहर निकलने के दायरे से बाहर नहीं निकल जाते।
    /// यह उधार सक्रिय होने पर मूल्य उधार नहीं लिया जा सकता है।
    ///
    /// यह [`borrow_mut`](#method.borrow_mut) का नॉन-पैनिकिंग वेरिएंट है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // सुरक्षा: `BorrowRef` अद्वितीय पहुंच की गारंटी देता है।
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// इस सेल में अंतर्निहित डेटा के लिए एक कच्चा सूचक लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// अंतर्निहित डेटा के लिए एक परिवर्तनशील संदर्भ देता है।
    ///
    /// यह कॉल `RefCell` को पारस्परिक रूप से (संकलन-समय पर) उधार लेता है, इसलिए गतिशील जांच की कोई आवश्यकता नहीं है।
    ///
    /// हालाँकि सावधान रहें: यह विधि `self` को परिवर्तनशील होने की उम्मीद करती है, जो आमतौर पर `RefCell` का उपयोग करते समय ऐसा नहीं होता है।
    ///
    /// यदि `self` परिवर्तनशील नहीं है, तो इसके बजाय [`borrow_mut`] विधि पर एक नज़र डालें।
    ///
    /// साथ ही, कृपया ध्यान रखें कि यह विधि केवल विशेष परिस्थितियों के लिए है और आमतौर पर वह नहीं है जो आप चाहते हैं।
    /// संदेह की स्थिति में, इसके बजाय [`borrow_mut`] का उपयोग करें।
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `RefCell` की उधार स्थिति पर लीक हुए गार्डों के प्रभाव को पूर्ववत करें।
    ///
    /// यह कॉल [`get_mut`] के समान है लेकिन अधिक विशिष्ट है।
    /// यह सुनिश्चित करने के लिए कि कोई उधार मौजूद नहीं है, यह `RefCell` को पारस्परिक रूप से उधार लेता है और फिर राज्य ट्रैकिंग साझा उधार को रीसेट करता है।
    /// यह प्रासंगिक है अगर कुछ `Ref` या `RefMut` उधार लीक हो गए हैं।
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// अपरिवर्तनीय रूप से लिपटे मूल्य को उधार लेता है, यदि मूल्य वर्तमान में पारस्परिक रूप से उधार लिया गया है तो एक त्रुटि लौटाता है।
    ///
    /// # Safety
    ///
    /// `RefCell::borrow` के विपरीत, यह विधि असुरक्षित है क्योंकि यह `Ref` नहीं लौटाती है, इस प्रकार उधार ध्वज को अछूता छोड़ देती है।
    /// `RefCell` को पारस्परिक रूप से उधार लेना, जबकि इस विधि द्वारा लौटाया गया संदर्भ जीवित है, अपरिभाषित व्यवहार है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // सुरक्षा: हम जाँचते हैं कि अब कोई सक्रिय रूप से नहीं लिख रहा है, लेकिन यह है
            // यह सुनिश्चित करने के लिए कॉलर की ज़िम्मेदारी है कि कोई भी तब तक नहीं लिखता जब तक कि लौटाया गया संदर्भ उपयोग में न हो।
            // साथ ही, `self.value.get()`, `self` के स्वामित्व वाले मूल्य को संदर्भित करता है और इस प्रकार `self` के जीवनकाल के लिए वैध होने की गारंटी है।
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// `Default::default()` को उसके स्थान पर छोड़कर, लपेटा हुआ मान लेता है।
    ///
    /// # Panics
    ///
    /// Panics यदि मूल्य वर्तमान में उधार लिया गया है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics यदि मूल्य वर्तमान में परस्पर उधार लिया गया है।
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// T के लिए `Default` मान के साथ `RefCell<T>` बनाता है।
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics यदि दोनों में से किसी एक में मान वर्तमान में उधार लिया गया है।
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics यदि दोनों में से किसी एक में मान वर्तमान में उधार लिया गया है।
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics यदि दोनों में से किसी एक में मान वर्तमान में उधार लिया गया है।
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics यदि दोनों में से किसी एक में मान वर्तमान में उधार लिया गया है।
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics यदि दोनों में से किसी एक में मान वर्तमान में उधार लिया गया है।
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics यदि दोनों में से किसी एक में मान वर्तमान में उधार लिया गया है।
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics यदि दोनों में से किसी एक में मान वर्तमान में उधार लिया गया है।
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // इन मामलों में बढ़ते हुए उधार के परिणामस्वरूप एक गैर-पठन मूल्य (<=0) हो सकता है:
            // 1. यह <0 था, यानी लेखन उधार हैं, इसलिए हम Rust के संदर्भ अलियासिंग नियमों के कारण पढ़ने के लिए उधार लेने की अनुमति नहीं दे सकते हैं
            // 2.
            // यह isize::MAX (पढ़ने के लिए उधार लेने की अधिकतम राशि) था और यह isize::MIN (लेखन उधार की अधिकतम राशि) में बह गया था, इसलिए हम अतिरिक्त पढ़ने के उधार की अनुमति नहीं दे सकते क्योंकि isize इतने सारे पढ़े गए उधार का प्रतिनिधित्व नहीं कर सकता है (यह केवल तभी हो सकता है जब आप mem::forget `Ref` की एक छोटी स्थिर राशि से अधिक, जो अच्छा अभ्यास नहीं है)
            //
            //
            //
            //
            None
        } else {
            // इन मामलों में बढ़ते हुए उधार के परिणामस्वरूप रीडिंग वैल्यू (> 0) हो सकती है:
            // 1. यह=0 था, यानी यह उधार नहीं लिया गया था, और हम पहली बार पढ़ा गया उधार ले रहे हैं
            // 2. यह> 0 और <isize::MAX था, अर्थात
            // पढ़े गए उधार थे, और एक और पढ़े गए उधार होने का प्रतिनिधित्व करने के लिए isize काफी बड़ा है
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // चूंकि यह रेफरी मौजूद है, हम जानते हैं कि उधार ध्वज एक पठन उधार है।
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // उधार काउंटर को एक लिखित उधार में बहने से रोकें।
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// किसी `RefCell` बॉक्स में किसी मान के लिए उधार लिया गया संदर्भ लपेटता है।
/// `RefCell<T>` से अपरिवर्तनीय रूप से उधार लिए गए मूल्य के लिए एक आवरण प्रकार।
///
/// अधिक के लिए [module-level documentation](self) देखें।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// एक `Ref` कॉपी करता है।
    ///
    /// `RefCell` पहले से ही अपरिवर्तनीय रूप से उधार लिया गया है, इसलिए यह विफल नहीं हो सकता।
    ///
    /// यह एक संबद्ध फ़ंक्शन है जिसे `Ref::clone(...)` के रूप में उपयोग करने की आवश्यकता है।
    /// एक `Clone` कार्यान्वयन या एक विधि `r.borrow().clone()` की सामग्री को क्लोन करने के लिए `r.borrow().clone()` के व्यापक उपयोग में हस्तक्षेप करेगी।
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// उधार डेटा के एक घटक के लिए एक नया `Ref` बनाता है।
    ///
    /// `RefCell` पहले से ही अपरिवर्तनीय रूप से उधार लिया गया है, इसलिए यह विफल नहीं हो सकता।
    ///
    /// यह एक संबद्ध फ़ंक्शन है जिसे `Ref::map(...)` के रूप में उपयोग करने की आवश्यकता है।
    /// एक विधि `Deref` के माध्यम से उपयोग किए गए `RefCell` की सामग्री पर समान नाम के तरीकों में हस्तक्षेप करेगी।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// उधार लिए गए डेटा के वैकल्पिक घटक के लिए एक नया `Ref` बनाता है।
    /// यदि क्लोजर `None` लौटाता है, तो मूल गार्ड को `Err(..)` के रूप में वापस कर दिया जाता है।
    ///
    /// `RefCell` पहले से ही अपरिवर्तनीय रूप से उधार लिया गया है, इसलिए यह विफल नहीं हो सकता।
    ///
    /// यह एक संबद्ध फ़ंक्शन है जिसे `Ref::filter_map(...)` के रूप में उपयोग करने की आवश्यकता है।
    /// एक विधि `Deref` के माध्यम से उपयोग किए गए `RefCell` की सामग्री पर समान नाम के तरीकों में हस्तक्षेप करेगी।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// उधार लिए गए डेटा के विभिन्न घटकों के लिए `Ref` को कई `Ref` में विभाजित करता है।
    ///
    /// `RefCell` पहले से ही अपरिवर्तनीय रूप से उधार लिया गया है, इसलिए यह विफल नहीं हो सकता।
    ///
    /// यह एक संबद्ध फ़ंक्शन है जिसे `Ref::map_split(...)` के रूप में उपयोग करने की आवश्यकता है।
    /// एक विधि `Deref` के माध्यम से उपयोग किए गए `RefCell` की सामग्री पर समान नाम के तरीकों में हस्तक्षेप करेगी।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// अंतर्निहित डेटा के संदर्भ में कनवर्ट करें।
    ///
    /// अंतर्निहित `RefCell` को फिर से पारस्परिक रूप से कभी भी उधार नहीं लिया जा सकता है और हमेशा पहले से ही अपरिवर्तनीय रूप से उधार लिया हुआ दिखाई देगा।
    ///
    /// निरंतर संख्या में संदर्भों से अधिक लीक करना एक अच्छा विचार नहीं है।
    /// `RefCell` को अपरिवर्तनीय रूप से फिर से उधार लिया जा सकता है यदि कुल मिलाकर केवल कम संख्या में लीक हुए हों।
    ///
    /// यह एक संबद्ध फ़ंक्शन है जिसे `Ref::leak(...)` के रूप में उपयोग करने की आवश्यकता है।
    /// एक विधि `Deref` के माध्यम से उपयोग किए गए `RefCell` की सामग्री पर समान नाम के तरीकों में हस्तक्षेप करेगी।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // इस रेफरी को भूलकर हम यह सुनिश्चित करते हैं कि RefCell में उधार काउंटर आजीवन `'b` के भीतर UNUSED में वापस नहीं जा सकता है।
        // संदर्भ ट्रैकिंग स्थिति को रीसेट करने के लिए उधार लिए गए RefCell के लिए एक अद्वितीय संदर्भ की आवश्यकता होगी।
        // मूल सेल से कोई और परिवर्तनशील संदर्भ नहीं बनाया जा सकता है।
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// उधार डेटा के एक घटक के लिए एक नया `RefMut` बनाता है, उदाहरण के लिए, एक एनम संस्करण।
    ///
    /// `RefCell` पहले से ही पारस्परिक रूप से उधार लिया गया है, इसलिए यह विफल नहीं हो सकता।
    ///
    /// यह एक संबद्ध फ़ंक्शन है जिसे `RefMut::map(...)` के रूप में उपयोग करने की आवश्यकता है।
    /// एक विधि `Deref` के माध्यम से उपयोग किए गए `RefCell` की सामग्री पर समान नाम के तरीकों में हस्तक्षेप करेगी।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): उधार-चेक फिक्स करें
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// उधार लिए गए डेटा के वैकल्पिक घटक के लिए एक नया `RefMut` बनाता है।
    /// यदि क्लोजर `None` लौटाता है, तो मूल गार्ड को `Err(..)` के रूप में वापस कर दिया जाता है।
    ///
    /// `RefCell` पहले से ही पारस्परिक रूप से उधार लिया गया है, इसलिए यह विफल नहीं हो सकता।
    ///
    /// यह एक संबद्ध फ़ंक्शन है जिसे `RefMut::filter_map(...)` के रूप में उपयोग करने की आवश्यकता है।
    /// एक विधि `Deref` के माध्यम से उपयोग किए गए `RefCell` की सामग्री पर समान नाम के तरीकों में हस्तक्षेप करेगी।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): उधार-चेक फिक्स करें
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // सुरक्षा: फ़ंक्शन अवधि के लिए एक विशेष संदर्भ पर रहता है
        // `orig` के माध्यम से इसकी कॉल का, और पॉइंटर केवल फ़ंक्शन कॉल के अंदर डी-रेफरेंस होता है, कभी भी अनन्य संदर्भ से बचने की इजाजत नहीं देता है।
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // सुरक्षा: ऊपर के समान।
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// उधार लिए गए डेटा के विभिन्न घटकों के लिए `RefMut` को कई `RefMut` में विभाजित करता है।
    ///
    /// अंतर्निहित `RefCell` पारस्परिक रूप से उधार लिया जाएगा जब तक कि दोनों `RefMut` के दायरे से बाहर नहीं हो जाते।
    ///
    /// `RefCell` पहले से ही पारस्परिक रूप से उधार लिया गया है, इसलिए यह विफल नहीं हो सकता।
    ///
    /// यह एक संबद्ध फ़ंक्शन है जिसे `RefMut::map_split(...)` के रूप में उपयोग करने की आवश्यकता है।
    /// एक विधि `Deref` के माध्यम से उपयोग किए गए `RefCell` की सामग्री पर समान नाम के तरीकों में हस्तक्षेप करेगी।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// अंतर्निहित डेटा के लिए एक परिवर्तनीय संदर्भ में कनवर्ट करें।
    ///
    /// अंतर्निहित `RefCell` को फिर से उधार नहीं लिया जा सकता है और हमेशा पहले से ही पारस्परिक रूप से उधार लिया हुआ दिखाई देगा, जिससे लौटाया गया संदर्भ केवल इंटीरियर के लिए ही होगा।
    ///
    ///
    /// यह एक संबद्ध फ़ंक्शन है जिसे `RefMut::leak(...)` के रूप में उपयोग करने की आवश्यकता है।
    /// एक विधि `Deref` के माध्यम से उपयोग किए गए `RefCell` की सामग्री पर समान नाम के तरीकों में हस्तक्षेप करेगी।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // इस BorrowRefMut को भूलकर हम यह सुनिश्चित करते हैं कि RefCell में उधार काउंटर आजीवन `'b` के भीतर UNUSED में वापस नहीं जा सकता है।
        // संदर्भ ट्रैकिंग स्थिति को रीसेट करने के लिए उधार लिए गए RefCell के लिए एक अद्वितीय संदर्भ की आवश्यकता होगी।
        // उस जीवनकाल के भीतर मूल सेल से कोई और संदर्भ नहीं बनाया जा सकता है, जिससे वर्तमान उधार शेष जीवनकाल के लिए एकमात्र संदर्भ बन जाता है।
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone के विपरीत, प्रारंभिक बनाने के लिए नया कहा जाता है
        // परिवर्तनीय संदर्भ, और इसलिए वर्तमान में कोई मौजूदा संदर्भ नहीं होना चाहिए।
        // इस प्रकार, जबकि क्लोन परिवर्तनशील रिफ़काउंट को बढ़ाता है, यहाँ हम स्पष्ट रूप से केवल UNUSED से UNUSED में जाने की अनुमति देते हैं, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // एक `BorrowRefMut` क्लोन करता है।
    //
    // यह केवल तभी मान्य होता है जब प्रत्येक `BorrowRefMut` का उपयोग मूल वस्तु की एक विशिष्ट, गैर-अतिव्यापी श्रेणी के एक परिवर्तनशील संदर्भ को ट्रैक करने के लिए किया जाता है।
    //
    // यह क्लोन इम्प्लांट में नहीं है ताकि कोड इसे पूरी तरह से कॉल न करे।
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // उधार काउंटर को बहने से रोकें।
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>` से पारस्परिक रूप से उधार लिए गए मूल्य के लिए एक आवरण प्रकार।
///
/// अधिक के लिए [module-level documentation](self) देखें।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust में आंतरिक परिवर्तनशीलता के लिए मूल आदिम।
///
/// यदि आपके पास एक संदर्भ `&T` है, तो सामान्य रूप से Rust में संकलक इस ज्ञान के आधार पर अनुकूलन करता है कि `&T` अपरिवर्तनीय डेटा की ओर इशारा करता है।उस डेटा को बदलना, उदाहरण के लिए उपनाम के माध्यम से या `&T` को `&mut T` में ट्रांसमिट करके, अपरिभाषित व्यवहार माना जाता है।
/// `UnsafeCell<T>` `&T` के लिए अपरिवर्तनीय गारंटी से ऑप्ट-आउट: एक साझा संदर्भ `&UnsafeCell<T>` डेटा को इंगित कर सकता है जिसे उत्परिवर्तित किया जा रहा है।इसे "interior mutability" कहा जाता है।
///
/// अन्य सभी प्रकार जो आंतरिक परिवर्तनशीलता की अनुमति देते हैं, जैसे कि `Cell<T>` और `RefCell<T>`, आंतरिक रूप से अपने डेटा को लपेटने के लिए `UnsafeCell` का उपयोग करते हैं।
///
/// ध्यान दें कि साझा संदर्भों के लिए केवल अपरिवर्तनीयता गारंटी `UnsafeCell` से प्रभावित होती है।परिवर्तनीय संदर्भों के लिए विशिष्टता गारंटी अप्रभावित है।एलियासिंग `&mut` प्राप्त करने का कोई *नहीं* कानूनी तरीका है, यहां तक कि `UnsafeCell<T>` के साथ भी नहीं।
///
/// `UnsafeCell` API स्वयं तकनीकी रूप से बहुत सरल है: [`.get()`] आपको इसकी सामग्री के लिए एक कच्चा सूचक `*mut T` देता है।अमूर्त डिज़ाइनर के रूप में उस कच्चे सूचक का सही उपयोग करना _you_ पर निर्भर है।
///
/// [`.get()`]: `UnsafeCell::get`
///
/// सटीक Rust अलियासिंग नियम कुछ हद तक प्रवाह में हैं, लेकिन मुख्य बिंदु विवादास्पद नहीं हैं:
///
/// - यदि आप जीवन भर `'a` (या तो एक `&T` या `&mut T` संदर्भ) के साथ एक सुरक्षित संदर्भ बनाते हैं जो सुरक्षित कोड द्वारा पहुँचा जा सकता है (उदाहरण के लिए, क्योंकि आपने इसे वापस कर दिया है), तो आपको डेटा को किसी भी तरह से एक्सेस नहीं करना चाहिए जो शेष के संदर्भ के विपरीत है। `'a` का।
/// उदाहरण के लिए, इसका मतलब यह है कि यदि आप `*mut T` को `UnsafeCell<T>` से लेते हैं और इसे `&T` में डालते हैं, तो `T` में डेटा अपरिवर्तनीय रहना चाहिए (निश्चित रूप से `T` के भीतर पाया गया कोई भी `UnsafeCell` डेटा मॉड्यूल) जब तक उस संदर्भ का जीवनकाल समाप्त नहीं हो जाता।
/// इसी तरह, यदि आप एक `&mut T` संदर्भ बनाते हैं जो सुरक्षित कोड के लिए जारी किया गया है, तो आपको उस संदर्भ के समाप्त होने तक `UnsafeCell` के भीतर डेटा तक नहीं पहुंचना चाहिए।
///
/// - हर समय, आपको डेटा दौड़ से बचना चाहिए।यदि एक से अधिक थ्रेड्स की एक ही `UnsafeCell` तक पहुंच है, तो किसी भी लेखन में अन्य सभी एक्सेस (या परमाणु का उपयोग) के संबंध में एक उचित घटित होना चाहिए।
///
/// उचित डिजाइन में सहायता के लिए, निम्नलिखित परिदृश्यों को सिंगल-थ्रेडेड कोड के लिए स्पष्ट रूप से कानूनी घोषित किया गया है:
///
/// 1. एक `&T` संदर्भ सुरक्षित कोड के लिए जारी किया जा सकता है और वहां यह अन्य `&T` संदर्भों के साथ सह-अस्तित्व में हो सकता है, लेकिन `&mut T` के साथ नहीं
///
/// 2. एक `&mut T` संदर्भ सुरक्षित कोड के लिए जारी किया जा सकता है, बशर्ते न तो अन्य `&mut T` और न ही `&T` इसके साथ सह-अस्तित्व में हों।एक `&mut T` हमेशा अद्वितीय होना चाहिए।
///
/// ध्यान दें कि एक `&UnsafeCell<T>` की सामग्री को उत्परिवर्तित करते समय (भले ही अन्य `&UnsafeCell<T>` संदर्भ उर्फ सेल) ठीक है (बशर्ते आप उपरोक्त इनवेरिएंट को किसी अन्य तरीके से लागू करें), यह अभी भी कई `&mut UnsafeCell<T>` उपनामों के लिए अपरिभाषित व्यवहार है।
/// अर्थात्, `UnsafeCell` एक रैपर है जिसे `&UnsafeCell<_>` संदर्भ के माध्यम से _shared_ accesses (_i.e._ के साथ विशेष सहभागिता के लिए डिज़ाइन किया गया है);`&mut UnsafeCell<_>` के माध्यम से _exclusive_ accesses (_e.g._ के साथ व्यवहार करते समय कोई जादू नहीं है): उस `&mut` उधार की अवधि के लिए न तो सेल और न ही लिपटे मूल्य को अलियास किया जा सकता है।
///
/// यह [`.get_mut()`] एक्सेसर द्वारा प्रदर्शित किया गया है, जो एक _safe_ getter है जो एक `&mut T` उत्पन्न करता है।
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// यहां एक उदाहरण दिया गया है कि सेल को अलियासिंग करने वाले कई संदर्भ होने के बावजूद `UnsafeCell<_>` की सामग्री को ध्वनि रूप से कैसे बदलना है:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // एक ही `x` के एकाधिक/समवर्ती/साझा संदर्भ प्राप्त करें।
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // सुरक्षा: इस दायरे में `x` की सामग्री का कोई अन्य संदर्भ नहीं है,
///     // इसलिए हमारा प्रभावी रूप से अद्वितीय है।
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- उधार लेना---+
///     *p1_exclusive += 27; // |
/// } // <---------- इस बिंदु से आगे नहीं जा सकता -------------------+
///
/// unsafe {
///     // सुरक्षा: इस दायरे में किसी को भी `x` की सामग्री तक विशेष पहुंच की उम्मीद नहीं है,
///     // इसलिए हमारे पास एक साथ कई साझा एक्सेस हो सकते हैं।
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// निम्नलिखित उदाहरण इस तथ्य को प्रदर्शित करता है कि `UnsafeCell<T>` के लिए अनन्य पहुँच का अर्थ है उसके `T` तक अनन्य पहुँच:
///
/// ```rust
/// #![forbid(unsafe_code)] // अनन्य पहुंच के साथ,
///                         // `UnsafeCell` एक पारदर्शी नो-ऑप रैपर है, इसलिए यहां `unsafe` की कोई आवश्यकता नहीं है।
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x` के लिए एक संकलन-समय-जांच अद्वितीय संदर्भ प्राप्त करें।
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // एक विशेष संदर्भ के साथ, हम सामग्री को मुफ्त में बदल सकते हैं।
/// *p_unique.get_mut() = 0;
/// // या, समकक्ष:
/// x = UnsafeCell::new(0);
///
/// // जब हम मूल्य के मालिक होते हैं, तो हम सामग्री को मुफ्त में निकाल सकते हैं।
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// `UnsafeCell` का एक नया उदाहरण बनाता है जो निर्दिष्ट मान को लपेट देगा।
    ///
    ///
    /// विधियों के माध्यम से आंतरिक मूल्य तक सभी पहुंच `unsafe` है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// मान को खोल देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// लिपटे मूल्य के लिए एक परिवर्तनशील सूचक प्राप्त करें।
    ///
    /// इसे किसी भी प्रकार के सूचक पर डाला जा सकता है।
    /// सुनिश्चित करें कि `&mut T` को कास्ट करते समय एक्सेस अद्वितीय है (कोई सक्रिय संदर्भ, परिवर्तनशील या नहीं), और सुनिश्चित करें कि `&T` पर कास्टिंग करते समय कोई उत्परिवर्तन या परिवर्तनशील उपनाम नहीं चल रहा है
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // हम #[repr(transparent)] की वजह से पॉइंटर को `UnsafeCell<T>` से `T` तक कास्ट कर सकते हैं।
        // यह libstd की विशेष स्थिति का फायदा उठाता है, उपयोगकर्ता कोड की कोई गारंटी नहीं है कि यह कंपाइलर के future संस्करणों में काम करेगा!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// अंतर्निहित डेटा के लिए एक परिवर्तनशील संदर्भ देता है।
    ///
    /// यह कॉल `UnsafeCell` को पारस्परिक रूप से (संकलन-समय पर) उधार लेता है जो गारंटी देता है कि हमारे पास एकमात्र संदर्भ है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// लिपटे मूल्य के लिए एक परिवर्तनशील सूचक प्राप्त करें।
    /// [`get`] में अंतर यह है कि यह फ़ंक्शन एक कच्चे सूचक को स्वीकार करता है, जो अस्थायी संदर्भों के निर्माण से बचने के लिए उपयोगी है।
    ///
    /// परिणाम किसी भी प्रकार के सूचक को डाला जा सकता है।
    /// सुनिश्चित करें कि `&mut T` पर कास्ट करते समय एक्सेस अद्वितीय है (कोई सक्रिय संदर्भ, परिवर्तनशील या नहीं), और सुनिश्चित करें कि `&T` पर कास्टिंग करते समय कोई उत्परिवर्तन या परिवर्तनशील उपनाम नहीं चल रहा है।
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell` के क्रमिक आरंभीकरण के लिए `raw_get` की आवश्यकता होती है, क्योंकि `get` को कॉल करने के लिए अप्रारंभीकृत डेटा का संदर्भ बनाने की आवश्यकता होगी:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // हम #[repr(transparent)] की वजह से पॉइंटर को `UnsafeCell<T>` से `T` तक कास्ट कर सकते हैं।
        // यह libstd की विशेष स्थिति का फायदा उठाता है, उपयोगकर्ता कोड की कोई गारंटी नहीं है कि यह कंपाइलर के future संस्करणों में काम करेगा!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// T के लिए `Default` मान के साथ एक `UnsafeCell` बनाता है।
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}