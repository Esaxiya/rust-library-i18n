use crate::iter::FromIterator;

/// एक पुनरावर्तक से सभी इकाई आइटम को एक में संक्षिप्त करता है।
///
/// उच्च-स्तरीय अमूर्त के साथ संयुक्त होने पर यह अधिक उपयोगी होता है, जैसे कि `Result<(), E>` में एकत्रित करना जहाँ आप केवल त्रुटियों की परवाह करते हैं:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}