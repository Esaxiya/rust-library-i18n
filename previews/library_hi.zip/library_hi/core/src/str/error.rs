//! utf8 त्रुटि प्रकार को परिभाषित करता है।

use crate::fmt;

/// एक स्ट्रिंग के रूप में [`u8`] के अनुक्रम की व्याख्या करने का प्रयास करते समय होने वाली त्रुटियां।
///
/// जैसे, [`स्ट्रिंग`] और [`&str`] दोनों के लिए कार्यों और विधियों का `from_utf8` परिवार इस त्रुटि का उपयोग करता है, उदाहरण के लिए।
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// इस त्रुटि प्रकार की विधियों का उपयोग ढेर मेमोरी आवंटित किए बिना `String::from_utf8_lossy` के समान कार्यक्षमता बनाने के लिए किया जा सकता है:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// दिए गए स्ट्रिंग में वह इंडेक्स लौटाता है जिस तक मान्य UTF-8 सत्यापित किया गया था।
    ///
    /// यह अधिकतम सूचकांक है जैसे कि `from_utf8(&input[..index])` `Ok(_)` लौटाएगा।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::str;
    ///
    /// // vector. में कुछ अमान्य बाइट्स
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 एक Utf8Error लौटाता है
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // दूसरा बाइट यहाँ अमान्य है
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// विफलता के बारे में अधिक जानकारी प्रदान करता है:
    ///
    /// * `None`: इनपुट का अंत अप्रत्याशित रूप से पहुंच गया था।
    ///   `self.valid_up_to()` इनपुट के अंत से 1 से 3 बाइट्स है।
    ///   यदि एक बाइट स्ट्रीम (जैसे फ़ाइल या नेटवर्क सॉकेट) को क्रमिक रूप से डीकोड किया जा रहा है, तो यह एक वैध `char` हो सकता है जिसका UTF-8 बाइट अनुक्रम कई हिस्सों में फैला हुआ है।
    ///
    ///
    /// * `Some(len)`: एक अप्रत्याशित बाइट का सामना करना पड़ा।
    ///   प्रदान की गई लंबाई अमान्य बाइट अनुक्रम की है जो `valid_up_to()` द्वारा दिए गए सूचकांक पर शुरू होती है।
    ///   हानिपूर्ण डिकोडिंग के मामले में उस क्रम के बाद ([`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] डालने के बाद) डिकोडिंग फिर से शुरू होनी चाहिए।
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] का उपयोग करके `bool` को पार्स करते समय एक त्रुटि वापस आ गई
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}