//! स्ट्रिंग हेरफेर।
//!
//! अधिक विवरण के लिए, [`std::str`] मॉड्यूल देखें।
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. सीमा के बाहर
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. प्रारंभ <=अंत
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. चरित्र सीमा
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // चरित्र खोजें
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` लेन और चार सीमा से कम होना चाहिए
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` की लंबाई लौटाता है।
    ///
    /// यह लंबाई बाइट्स में है, न कि [`char`] s या ग्रैफेम में।
    /// दूसरे शब्दों में, यह वह नहीं हो सकता है जिसे मनुष्य स्ट्रिंग की लंबाई मानता है।
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // फैंसी च!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// यदि `self` की लंबाई शून्य बाइट्स है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// जाँचता है कि `index`-th बाइट UTF-8 कोड बिंदु अनुक्रम या स्ट्रिंग के अंत में पहली बाइट है।
    ///
    ///
    /// स्ट्रिंग की शुरुआत और अंत (जब `इंडेक्स== self.len()`) को सीमाएं माना जाता है।
    ///
    /// यदि `index`, `self.len()` से बड़ा है, तो `false` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老`. की शुरुआत
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` का दूसरा बाइट
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` का तीसरा बाइट
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 और लेन हमेशा ठीक हैं।
        // 0 के लिए स्पष्ट रूप से परीक्षण करें ताकि यह आसानी से चेक को अनुकूलित कर सके और उस मामले के लिए स्ट्रिंग डेटा पढ़ना छोड़ सके।
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // यह बिट मैजिक के बराबर है: b <128 ||बी>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// एक स्ट्रिंग स्लाइस को बाइट स्लाइस में परिवर्तित करता है।
    /// बाइट स्लाइस को वापस एक स्ट्रिंग स्लाइस में बदलने के लिए, [`from_utf8`] फ़ंक्शन का उपयोग करें।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // सुरक्षा: ध्वनि स्थिरांक क्योंकि हम एक ही लेआउट के साथ दो प्रकारों को प्रसारित करते हैं
        unsafe { mem::transmute(self) }
    }

    /// म्यूटेबल स्ट्रिंग स्लाइस को म्यूटेबल बाइट स्लाइस में कनवर्ट करता है।
    ///
    /// # Safety
    ///
    /// कॉलर को यह सुनिश्चित करना चाहिए कि उधार समाप्त होने से पहले स्लाइस की सामग्री वैध UTF-8 है और अंतर्निहित `str` का उपयोग किया जाता है।
    ///
    ///
    /// `str` का उपयोग जिसकी सामग्री मान्य नहीं है UTF-8 अपरिभाषित व्यवहार है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // सुरक्षा: `&str` से `&[u8]` तक की कास्ट `str`. के बाद से सुरक्षित है
        // `&[u8]` के समान लेआउट है (केवल libstd ही यह गारंटी दे सकता है)।
        // सूचक विचलन सुरक्षित है क्योंकि यह एक परिवर्तनीय संदर्भ से आता है जिसे लिखने के लिए मान्य होने की गारंटी है।
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// एक स्ट्रिंग स्लाइस को एक कच्चे सूचक में परिवर्तित करता है।
    ///
    /// चूंकि स्ट्रिंग स्लाइस बाइट्स का एक टुकड़ा है, कच्चा सूचक [`u8`] की ओर इशारा करता है।
    /// यह पॉइंटर स्ट्रिंग स्लाइस के पहले बाइट की ओर इशारा करेगा।
    ///
    /// कॉलर को यह सुनिश्चित करना चाहिए कि लौटा हुआ सूचक कभी भी लिखा नहीं गया है।
    /// यदि आपको स्ट्रिंग स्लाइस की सामग्री को बदलने की आवश्यकता है, तो [`as_mut_ptr`] का उपयोग करें।
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// एक परिवर्तनशील स्ट्रिंग स्लाइस को एक कच्चे सूचक में परिवर्तित करता है।
    ///
    /// चूंकि स्ट्रिंग स्लाइस बाइट्स का एक टुकड़ा है, कच्चा सूचक [`u8`] की ओर इशारा करता है।
    /// यह पॉइंटर स्ट्रिंग स्लाइस के पहले बाइट की ओर इशारा करेगा।
    ///
    /// यह सुनिश्चित करना आपकी जिम्मेदारी है कि स्ट्रिंग स्लाइस केवल इस तरह से संशोधित हो कि यह वैध UTF-8 बना रहे।
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` का सबस्लाइस लौटाता है।
    ///
    /// यह `str` को अनुक्रमित करने का गैर-घबराहट विकल्प है।
    /// जब भी समतुल्य अनुक्रमण क्रिया panic होगी, [`None`] लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // सूचकांक UTF-8 अनुक्रम सीमाओं पर नहीं हैं
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // सीमा के बाहर
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` का एक परिवर्तनीय उपखंड देता है।
    ///
    /// यह `str` को अनुक्रमित करने का गैर-घबराहट विकल्प है।
    /// जब भी समतुल्य अनुक्रमण क्रिया panic होगी, [`None`] लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // सही लंबाई
    /// assert!(v.get_mut(0..5).is_some());
    /// // सीमा के बाहर
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` का एक अनियंत्रित उपखंड लौटाता है।
    ///
    /// यह `str` को अनुक्रमित करने का अनियंत्रित विकल्प है।
    ///
    /// # Safety
    ///
    /// इस फ़ंक्शन के कॉलर जिम्मेदार हैं कि ये पूर्व शर्त संतुष्ट हैं:
    ///
    /// * आरंभिक सूचकांक अंतिम सूचकांक से अधिक नहीं होना चाहिए;
    /// * अनुक्रमणिका मूल स्लाइस की सीमा के भीतर होनी चाहिए;
    /// * अनुक्रमणिका UTF-8 अनुक्रम सीमाओं पर स्थित होनी चाहिए।
    ///
    /// ऐसा न करने पर, लौटाई गई स्ट्रिंग स्लाइस अमान्य मेमोरी को संदर्भित कर सकती है या `str` प्रकार द्वारा संप्रेषित इनवेरिएंट का उल्लंघन कर सकती है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // सुरक्षा: कॉल करने वाले को `get_unchecked` के सुरक्षा अनुबंध को बनाए रखना चाहिए;
        // टुकड़ा dereferencable है क्योंकि `self` एक सुरक्षित संदर्भ है।
        // लौटा हुआ सूचक सुरक्षित है क्योंकि `SliceIndex` के इम्प्लांट्स की गारंटी है कि यह है।
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str` का एक परिवर्तनशील, अनियंत्रित उपखंड लौटाता है।
    ///
    /// यह `str` को अनुक्रमित करने का अनियंत्रित विकल्प है।
    ///
    /// # Safety
    ///
    /// इस फ़ंक्शन के कॉलर जिम्मेदार हैं कि ये पूर्व शर्त संतुष्ट हैं:
    ///
    /// * आरंभिक सूचकांक अंतिम सूचकांक से अधिक नहीं होना चाहिए;
    /// * अनुक्रमणिका मूल स्लाइस की सीमा के भीतर होनी चाहिए;
    /// * अनुक्रमणिका UTF-8 अनुक्रम सीमाओं पर स्थित होनी चाहिए।
    ///
    /// ऐसा न करने पर, लौटाई गई स्ट्रिंग स्लाइस अमान्य मेमोरी को संदर्भित कर सकती है या `str` प्रकार द्वारा संप्रेषित इनवेरिएंट का उल्लंघन कर सकती है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // सुरक्षा: कॉल करने वाले को `get_unchecked_mut` के सुरक्षा अनुबंध को बनाए रखना चाहिए;
        // टुकड़ा dereferencable है क्योंकि `self` एक सुरक्षित संदर्भ है।
        // लौटा हुआ सूचक सुरक्षित है क्योंकि `SliceIndex` के इम्प्लांट्स की गारंटी है कि यह है।
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// सुरक्षा जांचों को दरकिनार करते हुए दूसरे स्ट्रिंग स्लाइस से एक स्ट्रिंग स्लाइस बनाता है।
    ///
    /// यह आमतौर पर अनुशंसित नहीं है, सावधानी के साथ प्रयोग करें!एक सुरक्षित विकल्प के लिए [`str`] और [`Index`] देखें।
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// यह नया टुकड़ा `begin` से `end` तक जाता है, जिसमें `begin` भी शामिल है लेकिन `end` को छोड़कर।
    ///
    /// इसके बजाय एक परिवर्तनीय स्ट्रिंग टुकड़ा प्राप्त करने के लिए, [`slice_mut_unchecked`] विधि देखें।
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// इस फ़ंक्शन के कॉलर जिम्मेदार हैं कि तीन पूर्व शर्त संतुष्ट हैं:
    ///
    /// * `begin` `end` से अधिक नहीं होना चाहिए।
    /// * `begin` और `end` स्ट्रिंग स्लाइस के भीतर बाइट स्थिति होनी चाहिए।
    /// * `begin` और `end` को UTF-8 अनुक्रम सीमाओं पर स्थित होना चाहिए।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // सुरक्षा: कॉल करने वाले को `get_unchecked` के सुरक्षा अनुबंध को बनाए रखना चाहिए;
        // टुकड़ा dereferencable है क्योंकि `self` एक सुरक्षित संदर्भ है।
        // लौटा हुआ सूचक सुरक्षित है क्योंकि `SliceIndex` के इम्प्लांट्स की गारंटी है कि यह है।
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// सुरक्षा जांचों को दरकिनार करते हुए दूसरे स्ट्रिंग स्लाइस से एक स्ट्रिंग स्लाइस बनाता है।
    /// यह आमतौर पर अनुशंसित नहीं है, सावधानी के साथ प्रयोग करें!एक सुरक्षित विकल्प के लिए [`str`] और [`IndexMut`] देखें।
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// यह नया टुकड़ा `begin` से `end` तक जाता है, जिसमें `begin` भी शामिल है लेकिन `end` को छोड़कर।
    ///
    /// इसके बजाय एक अपरिवर्तनीय स्ट्रिंग स्लाइस प्राप्त करने के लिए, [`slice_unchecked`] विधि देखें।
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// इस फ़ंक्शन के कॉलर जिम्मेदार हैं कि तीन पूर्व शर्त संतुष्ट हैं:
    ///
    /// * `begin` `end` से अधिक नहीं होना चाहिए।
    /// * `begin` और `end` स्ट्रिंग स्लाइस के भीतर बाइट स्थिति होनी चाहिए।
    /// * `begin` और `end` को UTF-8 अनुक्रम सीमाओं पर स्थित होना चाहिए।
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // सुरक्षा: कॉल करने वाले को `get_unchecked_mut` के सुरक्षा अनुबंध को बनाए रखना चाहिए;
        // टुकड़ा dereferencable है क्योंकि `self` एक सुरक्षित संदर्भ है।
        // लौटा हुआ सूचक सुरक्षित है क्योंकि `SliceIndex` के इम्प्लांट्स की गारंटी है कि यह है।
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// एक स्ट्रिंग स्लाइस को एक इंडेक्स पर दो में विभाजित करें।
    ///
    /// तर्क, `mid`, स्ट्रिंग की शुरुआत से बाइट ऑफ़सेट होना चाहिए।
    /// यह UTF-8 कोड बिंदु की सीमा पर भी होना चाहिए।
    ///
    /// लौटाए गए दो स्लाइस स्ट्रिंग स्लाइस की शुरुआत से `mid` तक और `mid` से स्ट्रिंग स्लाइस के अंत तक जाते हैं।
    ///
    /// इसके बजाय परिवर्तनीय स्ट्रिंग स्लाइस प्राप्त करने के लिए, [`split_at_mut`] विधि देखें।
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics यदि `mid` UTF-8 कोड बिंदु सीमा पर नहीं है, या यदि यह स्ट्रिंग स्लाइस के अंतिम कोड बिंदु के अंत से पहले है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary जाँचता है कि सूचकांक [0 में है, .len()]
        if self.is_char_boundary(mid) {
            // सुरक्षा: अभी जांच की गई है कि `mid` चार सीमा पर है।
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// एक परिवर्तनशील स्ट्रिंग स्लाइस को एक इंडेक्स पर दो में विभाजित करें।
    ///
    /// तर्क, `mid`, स्ट्रिंग की शुरुआत से बाइट ऑफ़सेट होना चाहिए।
    /// यह UTF-8 कोड बिंदु की सीमा पर भी होना चाहिए।
    ///
    /// लौटाए गए दो स्लाइस स्ट्रिंग स्लाइस की शुरुआत से `mid` तक और `mid` से स्ट्रिंग स्लाइस के अंत तक जाते हैं।
    ///
    /// इसके बजाय अपरिवर्तनीय स्ट्रिंग स्लाइस प्राप्त करने के लिए, [`split_at`] विधि देखें।
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics यदि `mid` UTF-8 कोड बिंदु सीमा पर नहीं है, या यदि यह स्ट्रिंग स्लाइस के अंतिम कोड बिंदु के अंत से पहले है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary जाँचता है कि सूचकांक [0 में है, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // सुरक्षा: अभी जांच की गई है कि `mid` चार सीमा पर है।
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// एक स्ट्रिंग स्लाइस के [`char`] s पर एक पुनरावर्तक देता है।
    ///
    /// चूंकि एक स्ट्रिंग स्लाइस में मान्य UTF-8 होता है, हम [`char`] द्वारा एक स्ट्रिंग स्लाइस के माध्यम से पुनरावृति कर सकते हैं।
    /// यह विधि ऐसे पुनरावर्तक को लौटाती है।
    ///
    /// यह याद रखना महत्वपूर्ण है कि [`char`] एक यूनिकोड स्केलर मान का प्रतिनिधित्व करता है, और आपके विचार से मेल नहीं खा सकता है कि 'character' क्या है।
    ///
    /// ग्रैफेम क्लस्टर्स पर पुनरावृत्ति वह हो सकती है जो आप वास्तव में चाहते हैं।
    /// यह कार्यक्षमता Rust की मानक लाइब्रेरी द्वारा प्रदान नहीं की गई है, इसके बजाय crates.io जांचें।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// याद रखें, [`char`] वर्णों के बारे में आपके अंतर्ज्ञान से मेल नहीं खा सकते हैं:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // नहीं 'y̆' not
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// एक स्ट्रिंग स्लाइस के [`char`] s और उनकी स्थिति पर एक पुनरावर्तक देता है।
    ///
    /// चूंकि एक स्ट्रिंग स्लाइस में मान्य UTF-8 होता है, हम [`char`] द्वारा एक स्ट्रिंग स्लाइस के माध्यम से पुनरावृति कर सकते हैं।
    /// यह विधि इन दोनों [`char`] s के साथ-साथ उनके बाइट पदों का एक पुनरावर्तक लौटाती है।
    ///
    /// इटरेटर टुपल्स उत्पन्न करता है।स्थिति पहले है, [`char`] दूसरे स्थान पर है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// याद रखें, [`char`] वर्णों के बारे में आपके अंतर्ज्ञान से मेल नहीं खा सकते हैं:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // नहीं (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // यहां 3 नोट करें, अंतिम चरित्र ने दो बाइट्स लिए
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// एक स्ट्रिंग स्लाइस के बाइट्स पर एक पुनरावर्तक।
    ///
    /// चूंकि एक स्ट्रिंग स्लाइस में बाइट्स का एक क्रम होता है, हम बाइट द्वारा एक स्ट्रिंग स्लाइस के माध्यम से पुनरावृति कर सकते हैं।
    /// यह विधि ऐसे पुनरावर्तक को लौटाती है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// व्हाइटस्पेस द्वारा एक स्ट्रिंग स्लाइस को विभाजित करता है।
    ///
    /// लौटाया गया पुनरावर्तक स्ट्रिंग स्लाइस लौटाएगा जो मूल स्ट्रिंग स्लाइस के उप-स्लाइस हैं, जो किसी भी मात्रा में व्हाइटस्पेस से अलग होते हैं।
    ///
    ///
    /// 'Whitespace' यूनिकोड व्युत्पन्न कोर संपत्ति `White_Space` की शर्तों के अनुसार परिभाषित किया गया है।
    /// यदि आप इसके बजाय केवल ASCII व्हाइटस्पेस पर विभाजित करना चाहते हैं, तो [`split_ascii_whitespace`] का उपयोग करें।
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// सभी प्रकार के व्हाइटस्पेस पर विचार किया जाता है:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// ASCII व्हाइटस्पेस द्वारा एक स्ट्रिंग स्लाइस को विभाजित करता है।
    ///
    /// लौटाया गया पुनरावर्तक स्ट्रिंग स्लाइस लौटाएगा जो मूल स्ट्रिंग स्लाइस के उप-स्लाइस हैं, जो एएससीआईआई व्हाइटस्पेस की किसी भी मात्रा से अलग होते हैं।
    ///
    ///
    /// इसके बजाय यूनिकोड `Whitespace` द्वारा विभाजित करने के लिए, [`split_whitespace`] का उपयोग करें।
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// सभी प्रकार के ASCII व्हॉट्सएप पर विचार किया जाता है:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// एक स्ट्रिंग की तर्ज पर एक पुनरावर्तक, स्ट्रिंग स्लाइस के रूप में।
    ///
    /// लाइनों को या तो एक नई लाइन (`\n`) या एक लाइन फीड (`\r\n`) के साथ कैरिज रिटर्न के साथ समाप्त किया जाता है।
    ///
    /// अंतिम पंक्ति का अंत वैकल्पिक है।
    /// एक स्ट्रिंग जो अंतिम पंक्ति के अंत के साथ समाप्त होती है, वही पंक्तियाँ एक समान स्ट्रिंग के रूप में अंतिम पंक्ति समाप्त होने के बिना वापस आ जाएगी।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// अंतिम पंक्ति के अंत की आवश्यकता नहीं है:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// एक स्ट्रिंग की तर्ज पर एक पुनरावर्तक।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 के रूप में एन्कोड किए गए स्ट्रिंग पर `u16` का पुनरावर्तक देता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// यदि दिया गया पैटर्न इस स्ट्रिंग स्लाइस के सब-स्लाइस से मेल खाता है, तो `true` लौटाता है।
    ///
    /// यदि ऐसा नहीं है तो `false` लौटाता है।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// यदि दिया गया पैटर्न इस स्ट्रिंग स्लाइस के उपसर्ग से मेल खाता है, तो `true` लौटाता है।
    ///
    /// यदि ऐसा नहीं है तो `false` लौटाता है।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// यदि दिया गया पैटर्न इस स्ट्रिंग स्लाइस के प्रत्यय से मेल खाता है, तो `true` लौटाता है।
    ///
    /// यदि ऐसा नहीं है तो `false` लौटाता है।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// पैटर्न से मेल खाने वाले इस स्ट्रिंग स्लाइस के पहले वर्ण का बाइट इंडेक्स लौटाता है।
    ///
    /// यदि पैटर्न मेल नहीं खाता है तो [`None`] लौटाता है।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// सरल पैटर्न:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// पॉइंट-फ्री स्टाइल और क्लोजर का उपयोग करके अधिक जटिल पैटर्न:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// पैटर्न नहीं मिल रहा है:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// इस स्ट्रिंग स्लाइस में पैटर्न के सबसे दाहिने मिलान के पहले वर्ण के लिए बाइट इंडेक्स लौटाता है।
    ///
    /// यदि पैटर्न मेल नहीं खाता है तो [`None`] लौटाता है।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// सरल पैटर्न:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// क्लोजर के साथ अधिक जटिल पैटर्न:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// पैटर्न नहीं मिल रहा है:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// इस स्ट्रिंग स्लाइस के सबस्ट्रिंग पर एक पुनरावर्तक, एक पैटर्न से मेल खाने वाले वर्णों द्वारा अलग किया गया।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # इटरेटर व्यवहार
    ///
    /// यदि पैटर्न रिवर्स सर्च की अनुमति देता है और forward/reverse सर्च समान तत्वों को उत्पन्न करता है तो लौटा हुआ पुनरावर्तक [`DoubleEndedIterator`] होगा।
    /// यह सच है, उदाहरण के लिए, [`char`], लेकिन `&str` के लिए नहीं।
    ///
    /// यदि पैटर्न रिवर्स सर्च की अनुमति देता है लेकिन इसके परिणाम फॉरवर्ड सर्च से भिन्न हो सकते हैं, तो [`rsplit`] विधि का उपयोग किया जा सकता है।
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// सरल पैटर्न:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// यदि पैटर्न वर्णों का एक टुकड़ा है, तो किसी भी वर्ण की प्रत्येक घटना पर विभाजित करें:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// क्लोजर का उपयोग करके एक अधिक जटिल पैटर्न:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// यदि एक स्ट्रिंग में कई सन्निहित विभाजक हैं, तो आप आउटपुट में खाली स्ट्रिंग्स के साथ समाप्त होंगे:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// सन्निहित विभाजकों को रिक्त स्ट्रिंग द्वारा अलग किया जाता है।
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// एक स्ट्रिंग के प्रारंभ या अंत में विभाजक खाली तारों से घिरे होते हैं।
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// जब खाली स्ट्रिंग को विभाजक के रूप में उपयोग किया जाता है, तो यह स्ट्रिंग के प्रत्येक वर्ण को स्ट्रिंग के आरंभ और अंत के साथ अलग करता है।
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// जब व्हाइटस्पेस को विभाजक के रूप में उपयोग किया जाता है तो सन्निहित विभाजक संभावित रूप से आश्चर्यजनक व्यवहार कर सकते हैं।यह कोड सही है:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// यह आपको _not_ देता है:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// इस व्यवहार के लिए [`split_whitespace`] का प्रयोग करें।
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// इस स्ट्रिंग स्लाइस के सबस्ट्रिंग पर एक पुनरावर्तक, एक पैटर्न से मेल खाने वाले वर्णों द्वारा अलग किया गया।
    /// `split` द्वारा निर्मित इटरेटर से उस `split_inclusive` में अंतर मिलान वाले हिस्से को सबस्ट्रिंग के टर्मिनेटर के रूप में छोड़ देता है।
    ///
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// यदि स्ट्रिंग के अंतिम तत्व का मिलान किया जाता है, तो उस तत्व को पूर्ववर्ती सबस्ट्रिंग का टर्मिनेटर माना जाएगा।
    /// वह सबस्ट्रिंग इटरेटर द्वारा लौटाया गया अंतिम आइटम होगा।
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// दिए गए स्ट्रिंग स्लाइस के सबस्ट्रिंग पर एक इटरेटर, एक पैटर्न से मेल खाने वाले वर्णों से अलग होता है और रिवर्स ऑर्डर में उत्पन्न होता है।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # इटरेटर व्यवहार
    ///
    /// लौटाए गए पुनरावर्तक की आवश्यकता है कि पैटर्न एक रिवर्स खोज का समर्थन करता है, और यदि forward/reverse खोज समान तत्वों को उत्पन्न करती है तो यह एक [`DoubleEndedIterator`] होगा।
    ///
    ///
    /// सामने से पुनरावृति के लिए, [`split`] विधि का उपयोग किया जा सकता है।
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// सरल पैटर्न:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// क्लोजर का उपयोग करके एक अधिक जटिल पैटर्न:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// दिए गए स्ट्रिंग स्लाइस के सबस्ट्रिंग पर एक पुनरावर्तक, एक पैटर्न से मेल खाने वाले वर्णों द्वारा अलग किया गया।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] के समतुल्य, सिवाय इसके कि अनुगामी विकल्प खाली होने पर छोड़ दिया जाता है।
    ///
    /// [`split`]: str::split
    ///
    /// इस पद्धति का उपयोग पैटर्न द्वारा _separated_ के बजाय _terminated_ स्ट्रिंग डेटा के लिए किया जा सकता है।
    ///
    /// # इटरेटर व्यवहार
    ///
    /// यदि पैटर्न रिवर्स सर्च की अनुमति देता है और forward/reverse सर्च समान तत्वों को उत्पन्न करता है तो लौटा हुआ पुनरावर्तक [`DoubleEndedIterator`] होगा।
    /// यह सच है, उदाहरण के लिए, [`char`], लेकिन `&str` के लिए नहीं।
    ///
    /// यदि पैटर्न रिवर्स सर्च की अनुमति देता है लेकिन इसके परिणाम फॉरवर्ड सर्च से भिन्न हो सकते हैं, तो [`rsplit_terminator`] विधि का उपयोग किया जा सकता है।
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self` के सबस्ट्रिंग पर एक पुनरावर्तक, एक पैटर्न से मेल खाने वाले वर्णों से अलग होता है और रिवर्स ऑर्डर में उत्पन्न होता है।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] के समतुल्य, सिवाय इसके कि अनुगामी विकल्प खाली होने पर छोड़ दिया जाता है।
    ///
    /// [`split`]: str::split
    ///
    /// इस पद्धति का उपयोग पैटर्न द्वारा _separated_ के बजाय _terminated_ स्ट्रिंग डेटा के लिए किया जा सकता है।
    ///
    /// # इटरेटर व्यवहार
    ///
    /// लौटाए गए पुनरावर्तक की आवश्यकता है कि पैटर्न एक रिवर्स खोज का समर्थन करता है, और यदि forward/reverse खोज समान तत्वों को उत्पन्न करती है तो यह डबल एंडेड हो जाएगी।
    ///
    ///
    /// सामने से पुनरावृति के लिए, [`split_terminator`] विधि का उपयोग किया जा सकता है।
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// दिए गए स्ट्रिंग स्लाइस के सबस्ट्रिंग पर एक पुनरावर्तक, एक पैटर्न द्वारा अलग किया गया, जो अधिकतम `n` आइटम पर लौटने के लिए प्रतिबंधित है।
    ///
    /// यदि `n` सबस्ट्रिंग लौटाए जाते हैं, तो अंतिम सबस्ट्रिंग (`n`वें सबस्ट्रिंग) में शेष स्ट्रिंग होगी।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # इटरेटर व्यवहार
    ///
    /// लौटा हुआ इटरेटर डबल एंडेड नहीं होगा, क्योंकि यह समर्थन करने के लिए कुशल नहीं है।
    ///
    /// यदि पैटर्न रिवर्स सर्च की अनुमति देता है, तो [`rsplitn`] विधि का उपयोग किया जा सकता है।
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// सरल पैटर्न:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// क्लोजर का उपयोग करके एक अधिक जटिल पैटर्न:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// इस स्ट्रिंग स्लाइस के सबस्ट्रिंग पर एक पुनरावर्तक, एक पैटर्न द्वारा अलग किया गया, स्ट्रिंग के अंत से शुरू होकर, अधिकतम `n` आइटम पर लौटने के लिए प्रतिबंधित है।
    ///
    ///
    /// यदि `n` सबस्ट्रिंग लौटाए जाते हैं, तो अंतिम सबस्ट्रिंग (`n`वें सबस्ट्रिंग) में शेष स्ट्रिंग होगी।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # इटरेटर व्यवहार
    ///
    /// लौटा हुआ इटरेटर डबल एंडेड नहीं होगा, क्योंकि यह समर्थन करने के लिए कुशल नहीं है।
    ///
    /// सामने से विभाजित करने के लिए, [`splitn`] विधि का उपयोग किया जा सकता है।
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// सरल पैटर्न:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// क्लोजर का उपयोग करके एक अधिक जटिल पैटर्न:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// निर्दिष्ट सीमांकक की पहली घटना पर स्ट्रिंग को विभाजित करता है और सीमांकक से पहले उपसर्ग और सीमांकक के बाद प्रत्यय देता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// निर्दिष्ट सीमांकक की अंतिम घटना पर स्ट्रिंग को विभाजित करता है और सीमांकक से पहले उपसर्ग और सीमांकक के बाद प्रत्यय देता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// दिए गए स्ट्रिंग स्लाइस के भीतर एक पैटर्न के असंबद्ध मैचों पर एक पुनरावर्तक।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # इटरेटर व्यवहार
    ///
    /// यदि पैटर्न रिवर्स सर्च की अनुमति देता है और forward/reverse सर्च समान तत्वों को उत्पन्न करता है तो लौटा हुआ पुनरावर्तक [`DoubleEndedIterator`] होगा।
    /// यह सच है, उदाहरण के लिए, [`char`], लेकिन `&str` के लिए नहीं।
    ///
    /// यदि पैटर्न रिवर्स सर्च की अनुमति देता है लेकिन इसके परिणाम फॉरवर्ड सर्च से भिन्न हो सकते हैं, तो [`rmatches`] विधि का उपयोग किया जा सकता है।
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// इस स्ट्रिंग स्लाइस के भीतर एक पैटर्न के असंबद्ध मैचों पर एक पुनरावर्तक, उल्टे क्रम में उत्पन्न हुआ।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # इटरेटर व्यवहार
    ///
    /// लौटाए गए पुनरावर्तक की आवश्यकता है कि पैटर्न एक रिवर्स खोज का समर्थन करता है, और यदि forward/reverse खोज समान तत्वों को उत्पन्न करती है तो यह एक [`DoubleEndedIterator`] होगा।
    ///
    ///
    /// सामने से पुनरावृति के लिए, [`matches`] विधि का उपयोग किया जा सकता है।
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// इस स्ट्रिंग स्लाइस के भीतर एक पैटर्न के असंबद्ध मैचों के साथ-साथ उस इंडेक्स पर एक पुनरावर्तक जो मैच शुरू होता है।
    ///
    /// ओवरलैप होने वाले `self` के भीतर `pat` के मैचों के लिए, केवल पहले मैच के अनुरूप सूचकांक लौटाए जाते हैं।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # इटरेटर व्यवहार
    ///
    /// यदि पैटर्न रिवर्स सर्च की अनुमति देता है और forward/reverse सर्च समान तत्वों को उत्पन्न करता है तो लौटा हुआ पुनरावर्तक [`DoubleEndedIterator`] होगा।
    /// यह सच है, उदाहरण के लिए, [`char`], लेकिन `&str` के लिए नहीं।
    ///
    /// यदि पैटर्न रिवर्स सर्च की अनुमति देता है लेकिन इसके परिणाम फॉरवर्ड सर्च से भिन्न हो सकते हैं, तो [`rmatch_indices`] विधि का उपयोग किया जा सकता है।
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // केवल पहला `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` के भीतर एक पैटर्न के असंबद्ध मैचों पर एक पुनरावर्तक, मैच के सूचकांक के साथ रिवर्स ऑर्डर में उत्पन्न हुआ।
    ///
    /// ओवरलैप होने वाले `self` के भीतर `pat` के मैचों के लिए, केवल पिछले मैच के अनुरूप सूचकांक लौटाए जाते हैं।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # इटरेटर व्यवहार
    ///
    /// लौटाए गए पुनरावर्तक की आवश्यकता है कि पैटर्न एक रिवर्स खोज का समर्थन करता है, और यदि forward/reverse खोज समान तत्वों को उत्पन्न करती है तो यह एक [`DoubleEndedIterator`] होगा।
    ///
    ///
    /// सामने से पुनरावृति के लिए, [`match_indices`] विधि का उपयोग किया जा सकता है।
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // केवल अंतिम `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// एक स्ट्रिंग स्लाइस देता है जिसमें अग्रणी और पिछला व्हाइटस्पेस हटा दिया जाता है।
    ///
    /// 'Whitespace' यूनिकोड व्युत्पन्न कोर संपत्ति `White_Space` की शर्तों के अनुसार परिभाषित किया गया है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// प्रमुख खाली स्थान को हटाकर एक स्ट्रिंग स्लाइस लौटाता है।
    ///
    /// 'Whitespace' यूनिकोड व्युत्पन्न कोर संपत्ति `White_Space` की शर्तों के अनुसार परिभाषित किया गया है।
    ///
    /// # पाठ दिशात्मकता
    ///
    /// एक स्ट्रिंग बाइट्स का एक क्रम है।
    /// `start` इस संदर्भ में उस बाइट स्ट्रिंग की पहली स्थिति का अर्थ है;अंग्रेजी या रूसी जैसी बाएँ से दाएँ भाषा के लिए, यह बाईं ओर होगा, और दाएँ-से-बाएँ भाषाओं जैसे अरबी या हिब्रू के लिए, यह दायाँ पक्ष होगा।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// पिछली खाली जगह को हटाकर एक स्ट्रिंग स्लाइस लौटाता है।
    ///
    /// 'Whitespace' यूनिकोड व्युत्पन्न कोर संपत्ति `White_Space` की शर्तों के अनुसार परिभाषित किया गया है।
    ///
    /// # पाठ दिशात्मकता
    ///
    /// एक स्ट्रिंग बाइट्स का एक क्रम है।
    /// `end` इस संदर्भ में उस बाइट स्ट्रिंग की अंतिम स्थिति का अर्थ है;अंग्रेजी या रूसी जैसी बाएँ से दाएँ भाषा के लिए, यह दाएँ पक्ष होगा, और अरबी या हिब्रू जैसी दाएँ-से-बाएँ भाषाओं के लिए, यह बाएँ पक्ष होगा।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// प्रमुख खाली स्थान को हटाकर एक स्ट्रिंग स्लाइस लौटाता है।
    ///
    /// 'Whitespace' यूनिकोड व्युत्पन्न कोर संपत्ति `White_Space` की शर्तों के अनुसार परिभाषित किया गया है।
    ///
    /// # पाठ दिशात्मकता
    ///
    /// एक स्ट्रिंग बाइट्स का एक क्रम है।
    /// 'Left' इस संदर्भ में उस बाइट स्ट्रिंग की पहली स्थिति का अर्थ है;अरबी या हिब्रू जैसी भाषा के लिए जो 'बाएं से दाएं' के बजाय 'दाएं से बाएं' हैं, यह _right_ पक्ष होगा, बाएं नहीं।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// पिछली खाली जगह को हटाकर एक स्ट्रिंग स्लाइस लौटाता है।
    ///
    /// 'Whitespace' यूनिकोड व्युत्पन्न कोर संपत्ति `White_Space` की शर्तों के अनुसार परिभाषित किया गया है।
    ///
    /// # पाठ दिशात्मकता
    ///
    /// एक स्ट्रिंग बाइट्स का एक क्रम है।
    /// 'Right' इस संदर्भ में उस बाइट स्ट्रिंग की अंतिम स्थिति का अर्थ है;अरबी या हिब्रू जैसी भाषा के लिए जो 'बाएं से दाएं' के बजाय 'दाएं से बाएं' हैं, यह _left_ पक्ष होगा, दायां नहीं।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// बार-बार हटाए गए पैटर्न से मेल खाने वाले सभी उपसर्गों और प्रत्ययों के साथ एक स्ट्रिंग स्लाइस लौटाता है।
    ///
    /// [pattern] एक [`char`], [`char`] s का एक टुकड़ा या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई वर्ण मेल खाता है या नहीं।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// सरल पैटर्न:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// क्लोजर का उपयोग करके एक अधिक जटिल पैटर्न:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // सबसे पुराना ज्ञात मिलान याद रखें, इसे नीचे सुधारें यदि
            // पिछला मैच अलग है
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // सुरक्षा: `Searcher` मान्य सूचकांकों को वापस करने के लिए जाना जाता है।
        unsafe { self.get_unchecked(i..j) }
    }

    /// बार-बार हटाए गए पैटर्न से मेल खाने वाले सभी उपसर्गों के साथ एक स्ट्रिंग स्लाइस देता है।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # पाठ दिशात्मकता
    ///
    /// एक स्ट्रिंग बाइट्स का एक क्रम है।
    /// `start` इस संदर्भ में उस बाइट स्ट्रिंग की पहली स्थिति का अर्थ है;अंग्रेजी या रूसी जैसी बाएँ से दाएँ भाषा के लिए, यह बाईं ओर होगा, और दाएँ-से-बाएँ भाषाओं जैसे अरबी या हिब्रू के लिए, यह दायाँ पक्ष होगा।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // सुरक्षा: `Searcher` मान्य सूचकांकों को वापस करने के लिए जाना जाता है।
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// हटाए गए उपसर्ग के साथ एक स्ट्रिंग टुकड़ा देता है।
    ///
    /// यदि स्ट्रिंग `prefix` पैटर्न से शुरू होती है, तो उपसर्ग के बाद सबस्ट्रिंग लौटाती है, जो `Some` में लिपटी होती है।
    /// `trim_start_matches` के विपरीत, यह विधि उपसर्ग को ठीक एक बार हटा देती है।
    ///
    /// यदि स्ट्रिंग `prefix` से प्रारंभ नहीं होती है, तो `None` लौटाती है।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// हटाए गए प्रत्यय के साथ एक स्ट्रिंग टुकड़ा देता है।
    ///
    /// यदि स्ट्रिंग `suffix` पैटर्न के साथ समाप्त होती है, तो प्रत्यय से पहले सबस्ट्रिंग लौटाता है, जो `Some` में लिपटा होता है।
    /// `trim_end_matches` के विपरीत, यह विधि प्रत्यय को ठीक एक बार हटा देती है।
    ///
    /// यदि स्ट्रिंग `suffix` के साथ समाप्त नहीं होती है, तो `None` लौटाती है।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// बार-बार हटाए गए पैटर्न से मेल खाने वाले सभी प्रत्ययों के साथ एक स्ट्रिंग स्लाइस लौटाता है।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # पाठ दिशात्मकता
    ///
    /// एक स्ट्रिंग बाइट्स का एक क्रम है।
    /// `end` इस संदर्भ में उस बाइट स्ट्रिंग की अंतिम स्थिति का अर्थ है;अंग्रेजी या रूसी जैसी बाएँ से दाएँ भाषा के लिए, यह दाएँ पक्ष होगा, और अरबी या हिब्रू जैसी दाएँ-से-बाएँ भाषाओं के लिए, यह बाएँ पक्ष होगा।
    ///
    ///
    /// # Examples
    ///
    /// सरल पैटर्न:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// क्लोजर का उपयोग करके एक अधिक जटिल पैटर्न:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // सुरक्षा: `Searcher` मान्य सूचकांकों को वापस करने के लिए जाना जाता है।
        unsafe { self.get_unchecked(0..j) }
    }

    /// बार-बार हटाए गए पैटर्न से मेल खाने वाले सभी उपसर्गों के साथ एक स्ट्रिंग स्लाइस देता है।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # पाठ दिशात्मकता
    ///
    /// एक स्ट्रिंग बाइट्स का एक क्रम है।
    /// 'Left' इस संदर्भ में उस बाइट स्ट्रिंग की पहली स्थिति का अर्थ है;अरबी या हिब्रू जैसी भाषा के लिए जो 'बाएं से दाएं' के बजाय 'दाएं से बाएं' हैं, यह _right_ पक्ष होगा, बाएं नहीं।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// बार-बार हटाए गए पैटर्न से मेल खाने वाले सभी प्रत्ययों के साथ एक स्ट्रिंग स्लाइस लौटाता है।
    ///
    /// [pattern] एक `&str`, [`char`], [`char`] s का एक टुकड़ा, या एक फ़ंक्शन या क्लोजर हो सकता है जो यह निर्धारित करता है कि कोई चरित्र मेल खाता है या नहीं।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # पाठ दिशात्मकता
    ///
    /// एक स्ट्रिंग बाइट्स का एक क्रम है।
    /// 'Right' इस संदर्भ में उस बाइट स्ट्रिंग की अंतिम स्थिति का अर्थ है;अरबी या हिब्रू जैसी भाषा के लिए जो 'बाएं से दाएं' के बजाय 'दाएं से बाएं' हैं, यह _left_ पक्ष होगा, दायां नहीं।
    ///
    ///
    /// # Examples
    ///
    /// सरल पैटर्न:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// क्लोजर का उपयोग करके एक अधिक जटिल पैटर्न:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// इस स्ट्रिंग स्लाइस को दूसरे प्रकार में पार्स करता है।
    ///
    /// क्योंकि `parse` इतना सामान्य है, यह प्रकार के अनुमान के साथ समस्या पैदा कर सकता है।
    /// जैसे, `parse` उन कुछ मौकों में से एक है, जिन्हें आप प्यार से 'turbofish' के रूप में जाने जाने वाले सिंटैक्स को देखेंगे: `::<>`.
    ///
    /// यह अनुमान एल्गोरिथ्म को विशेष रूप से यह समझने में मदद करता है कि आप किस प्रकार का विश्लेषण करने का प्रयास कर रहे हैं।
    ///
    /// `parse` [`FromStr`] trait को लागू करने वाले किसी भी प्रकार में पार्स कर सकते हैं।
    ///

    /// # Errors
    ///
    /// यदि इस स्ट्रिंग स्लाइस को वांछित प्रकार में पार्स करना संभव नहीं है तो [`Err`] लौटाएगा।
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// मूल उपयोग
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` को एनोटेट करने के बजाय 'turbofish' का उपयोग करना:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// पार्स करने में विफल:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// जाँचता है कि क्या इस स्ट्रिंग के सभी वर्ण ASCII श्रेणी के भीतर हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // हम यहां प्रत्येक बाइट को कैरेक्टर के रूप में मान सकते हैं: सभी मल्टीबाइट कैरेक्टर एक बाइट से शुरू होते हैं जो एएससीआई रेंज में नहीं है, इसलिए हम वहां पहले ही रुक जाएंगे।
        //
        //
        self.as_bytes().is_ascii()
    }

    /// जाँचता है कि दो तार ASCII केस-संवेदी मिलान हैं।
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` के समान, लेकिन अस्थायी आवंटित और कॉपी किए बिना।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// इस स्ट्रिंग को इसके ASCII अपर केस के बराबर इन-प्लेस में कनवर्ट करता है।
    ///
    /// ASCII अक्षर 'a' से 'z' को 'A' से 'Z' में मैप किया गया है, लेकिन गैर-ASCII अक्षर अपरिवर्तित हैं।
    ///
    /// मौजूदा एक को संशोधित किए बिना एक नया अपरकेस मान वापस करने के लिए, [`to_ascii_uppercase()`] का उपयोग करें।
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // सुरक्षा: सुरक्षित है क्योंकि हम एक ही लेआउट के साथ दो प्रकारों को ट्रांसमिट करते हैं।
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// इस स्ट्रिंग को इसके ASCII लोअर केस के समतुल्य इन-प्लेस में कनवर्ट करता है।
    ///
    /// ASCII अक्षर 'A' से 'Z' को 'a' से 'z' में मैप किया गया है, लेकिन गैर-ASCII अक्षर अपरिवर्तित हैं।
    ///
    /// मौजूदा को संशोधित किए बिना एक नया लोअरकेस मान वापस करने के लिए, [`to_ascii_lowercase()`] का उपयोग करें।
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // सुरक्षा: सुरक्षित है क्योंकि हम एक ही लेआउट के साथ दो प्रकारों को ट्रांसमिट करते हैं।
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// एक पुनरावर्तक लौटाएं जो `self` में [`char::escape_debug`] के साथ प्रत्येक चार से बच निकलता है।
    ///
    ///
    /// Note: केवल विस्तारित ग्रेफेम कोडपॉइंट जो स्ट्रिंग शुरू करते हैं, बच जाएंगे।
    ///
    /// # Examples
    ///
    /// एक पुनरावर्तक के रूप में:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// सीधे `println!` का उपयोग करना:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// दोनों के बराबर हैं:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` का उपयोग करना:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// एक पुनरावर्तक लौटाएं जो `self` में [`char::escape_default`] के साथ प्रत्येक चार से बच निकलता है।
    ///
    ///
    /// # Examples
    ///
    /// एक पुनरावर्तक के रूप में:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// सीधे `println!` का उपयोग करना:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// दोनों के बराबर हैं:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` का उपयोग करना:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// एक पुनरावर्तक लौटाएं जो `self` में [`char::escape_unicode`] के साथ प्रत्येक चार से बच निकलता है।
    ///
    ///
    /// # Examples
    ///
    /// एक पुनरावर्तक के रूप में:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// सीधे `println!` का उपयोग करना:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// दोनों के बराबर हैं:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` का उपयोग करना:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// एक खाली str. बनाता है
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// एक खाली परिवर्तनशील str. बनाता है
    #[inline]
    fn default() -> Self {
        // सुरक्षा: खाली स्ट्रिंग मान्य UTF-8 है।
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// एक नाम योग्य, क्लोन करने योग्य fn प्रकार
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // सुरक्षा: सुरक्षित नहीं
        unsafe { from_utf8_unchecked(bytes) }
    };
}