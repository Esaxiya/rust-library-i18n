//! `str` के लिए Trait कार्यान्वयन।

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// स्ट्रिंग्स के आदेश को लागू करता है।
///
/// स्ट्रिंग्स को उनके बाइट मानों द्वारा [lexicographically](Ord#lexicographical-comparison) का आदेश दिया जाता है।
/// यह यूनिकोड कोड बिंदुओं को कोड चार्ट में उनकी स्थिति के आधार पर क्रमित करता है।
/// यह जरूरी नहीं कि "alphabetical" ऑर्डर जैसा ही हो, जो भाषा और लोकेल के अनुसार बदलता रहता है।
/// सांस्कृतिक रूप से स्वीकृत मानकों के अनुसार स्ट्रिंग्स को सॉर्ट करने के लिए स्थानीय-विशिष्ट डेटा की आवश्यकता होती है जो `str` प्रकार के दायरे से बाहर होता है।
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// स्ट्रिंग्स पर तुलना संचालन लागू करता है।
///
/// स्ट्रिंग्स की तुलना उनके बाइट मानों से [lexicographically](Ord#lexicographical-comparison) की जाती है।
/// यह कोड चार्ट में उनकी स्थिति के आधार पर यूनिकोड कोड बिंदुओं की तुलना करता है।
/// यह जरूरी नहीं कि "alphabetical" ऑर्डर जैसा ही हो, जो भाषा और लोकेल के अनुसार बदलता रहता है।
/// सांस्कृतिक रूप से स्वीकृत मानकों के अनुसार स्ट्रिंग्स की तुलना करने के लिए स्थानीय-विशिष्ट डेटा की आवश्यकता होती है जो `str` प्रकार के दायरे से बाहर होता है।
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// सिंटैक्स `&self[..]` या `&mut self[..]` के साथ सबस्ट्रिंग स्लाइसिंग लागू करता है।
///
/// पूरे स्ट्रिंग का एक टुकड़ा देता है, यानी, `&self` या `&mut self` देता है।`&self [0 .. के बराबर
/// लेन]`या`&म्यूट स्वयं [0 ..
/// len]`.
/// अन्य अनुक्रमण संचालन के विपरीत, यह panic कभी नहीं हो सकता है।
///
/// यह ऑपरेशन *ओ*(1) है।
///
/// 1.20.0 से पहले, ये अनुक्रमण संचालन अभी भी `Index` और `IndexMut` के प्रत्यक्ष कार्यान्वयन द्वारा समर्थित थे।
///
/// `&self[0 .. len]` या `&mut self[0 .. len]` के बराबर।
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// सिंटैक्स `&self[begin .. end]` या `&mut self[begin .. end]` के साथ सबस्ट्रिंग स्लाइसिंग लागू करता है।
///
/// दिए गए स्ट्रिंग का एक टुकड़ा बाइट श्रेणी [`begin`, `end`) से लौटाता है।
///
/// यह ऑपरेशन *ओ*(1) है।
///
/// 1.20.0 से पहले, ये अनुक्रमण संचालन अभी भी `Index` और `IndexMut` के प्रत्यक्ष कार्यान्वयन द्वारा समर्थित थे।
///
/// # Panics
///
/// Panics यदि `begin` या `end` किसी वर्ण के आरंभिक बाइट ऑफ़सेट को इंगित नहीं करता है (जैसा कि `is_char_boundary` द्वारा परिभाषित किया गया है), यदि `begin > end`, या यदि `end > len`।
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ये होंगे panic:
/// // बाइट 2 `ö` के भीतर है:
/// // और एस [2 ..3];
///
/// // बाइट 8 `老`&s [1 .. के भीतर स्थित है।
/// // 8];
///
/// // बाइट 100 स्ट्रिंग के बाहर है&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // सुरक्षा: अभी जाँच की गई है कि `start` और `end` चार सीमा पर हैं,
            // और हम एक सुरक्षित संदर्भ में गुजर रहे हैं, इसलिए वापसी मूल्य भी एक होगा।
            // हमने चार सीमाओं की भी जाँच की, इसलिए यह मान्य UTF-8 है।
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // सुरक्षा: अभी जाँच की गई है कि `start` और `end` चार सीमा पर हैं।
            // हम जानते हैं कि सूचक अद्वितीय है क्योंकि हमें यह `slice` से मिला है।
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // सुरक्षा: कॉलर गारंटी देता है कि `self` `slice` की सीमा में है
        // जो `add` के लिए सभी शर्तों को पूरा करता है।
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // सुरक्षा: `get_unchecked` के लिए टिप्पणियाँ देखें।
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary जाँचता है कि सूचकांक [0 में है, .len()] NLL परेशानी के कारण ऊपर दिए गए `get` का पुन: उपयोग नहीं कर सकता है
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // सुरक्षा: अभी जाँच की गई है कि `start` और `end` चार सीमा पर हैं,
            // और हम एक सुरक्षित संदर्भ में गुजर रहे हैं, इसलिए वापसी मूल्य भी एक होगा।
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// सिंटैक्स `&self[.. end]` या `&mut self[.. end]` के साथ सबस्ट्रिंग स्लाइसिंग लागू करता है।
///
/// दिए गए स्ट्रिंग का एक टुकड़ा बाइट श्रेणी [`0`, `end`) से लौटाता है।
/// `&self[0 .. end]` या `&mut self[0 .. end]` के बराबर।
///
/// यह ऑपरेशन *ओ*(1) है।
///
/// 1.20.0 से पहले, ये अनुक्रमण संचालन अभी भी `Index` और `IndexMut` के प्रत्यक्ष कार्यान्वयन द्वारा समर्थित थे।
///
/// # Panics
///
/// Panics यदि `end` किसी वर्ण के प्रारंभिक बाइट ऑफ़सेट को इंगित नहीं करता है (जैसा कि `is_char_boundary` द्वारा परिभाषित किया गया है), या यदि `end > len`।
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // सुरक्षा: अभी जाँच की गई है कि `end` चार सीमा पर है,
            // और हम एक सुरक्षित संदर्भ में गुजर रहे हैं, इसलिए वापसी मूल्य भी एक होगा।
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // सुरक्षा: अभी जाँच की गई है कि `end` चार सीमा पर है,
            // और हम एक सुरक्षित संदर्भ में गुजर रहे हैं, इसलिए वापसी मूल्य भी एक होगा।
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // सुरक्षा: अभी जाँच की गई है कि `end` चार सीमा पर है,
            // और हम एक सुरक्षित संदर्भ में गुजर रहे हैं, इसलिए वापसी मूल्य भी एक होगा।
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// सिंटैक्स `&self[begin ..]` या `&mut self[begin ..]` के साथ सबस्ट्रिंग स्लाइसिंग लागू करता है।
///
/// दिए गए स्ट्रिंग का एक टुकड़ा बाइट श्रेणी [`begin`, `len`) से लौटाता है।`&स्वयं के बराबर [शुरू करें ..
/// लेन]`या`&म्यूट स्वयं [शुरू करें ..
/// len]`.
///
/// यह ऑपरेशन *ओ*(1) है।
///
/// 1.20.0 से पहले, ये अनुक्रमण संचालन अभी भी `Index` और `IndexMut` के प्रत्यक्ष कार्यान्वयन द्वारा समर्थित थे।
///
/// # Panics
///
/// Panics यदि `begin` किसी वर्ण के प्रारंभिक बाइट ऑफ़सेट को इंगित नहीं करता है (जैसा कि `is_char_boundary` द्वारा परिभाषित किया गया है), या यदि `begin > len`।
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // सुरक्षा: अभी जाँच की गई है कि `start` चार सीमा पर है,
            // और हम एक सुरक्षित संदर्भ में गुजर रहे हैं, इसलिए वापसी मूल्य भी एक होगा।
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // सुरक्षा: अभी जाँच की गई है कि `start` चार सीमा पर है,
            // और हम एक सुरक्षित संदर्भ में गुजर रहे हैं, इसलिए वापसी मूल्य भी एक होगा।
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // सुरक्षा: कॉलर गारंटी देता है कि `self` `slice` की सीमा में है
        // जो `add` के लिए सभी शर्तों को पूरा करता है।
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // सुरक्षा: `get_unchecked` के समान।
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // सुरक्षा: अभी जाँच की गई है कि `start` चार सीमा पर है,
            // और हम एक सुरक्षित संदर्भ में गुजर रहे हैं, इसलिए वापसी मूल्य भी एक होगा।
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// सिंटैक्स `&self[begin ..= end]` या `&mut self[begin ..= end]` के साथ सबस्ट्रिंग स्लाइसिंग लागू करता है।
///
/// बाइट श्रेणी [`begin`, `end`] से दिए गए स्ट्रिंग का एक टुकड़ा देता है।`&self [begin .. end + 1]` या `&mut self[begin .. end + 1]` के समतुल्य, सिवाय इसके कि यदि `end` का `usize` के लिए अधिकतम मान है।
///
/// यह ऑपरेशन *ओ*(1) है।
///
/// # Panics
///
/// Panics यदि `begin` किसी वर्ण के प्रारंभिक बाइट ऑफ़सेट को इंगित नहीं करता है (जैसा कि `is_char_boundary` द्वारा परिभाषित किया गया है), यदि `end` किसी वर्ण के अंतिम बाइट ऑफ़सेट को इंगित नहीं करता है (`end + 1` या तो एक प्रारंभिक बाइट ऑफ़सेट या `len` के बराबर है), यदि `begin > end`, या यदि `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // सुरक्षा: कॉल करने वाले को `get_unchecked` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // सुरक्षा: कॉल करने वाले को `get_unchecked_mut` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// सिंटैक्स `&self[..= end]` या `&mut self[..= end]` के साथ सबस्ट्रिंग स्लाइसिंग लागू करता है।
///
/// बाइट श्रेणी [0, `end`] से दिए गए स्ट्रिंग का एक टुकड़ा देता है।
/// `&self [0 .. end + 1]` के बराबर, सिवाय अगर `end` का `usize` के लिए अधिकतम मान है।
///
/// यह ऑपरेशन *ओ*(1) है।
///
/// # Panics
///
/// Panics यदि `end` किसी वर्ण के अंतिम बाइट ऑफ़सेट को इंगित नहीं करता है (`end + 1` या तो एक प्रारंभिक बाइट ऑफ़सेट है जैसा कि `is_char_boundary` द्वारा परिभाषित किया गया है, या `len` के बराबर है), या यदि `end >= len`।
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // सुरक्षा: कॉल करने वाले को `get_unchecked` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // सुरक्षा: कॉल करने वाले को `get_unchecked_mut` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// एक स्ट्रिंग से एक मान पार्स करें
///
/// `FromStr` की [`from_str`] विधि अक्सर [`str`] की [`parse`] विधि के माध्यम से निहित रूप से उपयोग की जाती है।
/// उदाहरण के लिए [`पार्स`] के दस्तावेज़ देखें।
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` कोई आजीवन पैरामीटर नहीं है, और इसलिए आप केवल उन प्रकारों को पार्स कर सकते हैं जिनमें स्वयं एक आजीवन पैरामीटर नहीं है।
///
/// दूसरे शब्दों में, आप `i32` को `FromStr` के साथ पार्स कर सकते हैं, लेकिन `&i32` नहीं।
/// आप एक ऐसी संरचना को पार्स कर सकते हैं जिसमें एक `i32` है, लेकिन ऐसा नहीं है जिसमें `&i32` हो।
///
/// # Examples
///
/// उदाहरण `Point` प्रकार पर `FromStr` का मूल कार्यान्वयन:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// संबंधित त्रुटि जिसे पार्सिंग से वापस किया जा सकता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// इस प्रकार का मान वापस करने के लिए एक स्ट्रिंग `s` को पार्स करता है।
    ///
    /// यदि पार्सिंग सफल होती है, तो [`Ok`] के अंदर मान वापस करें, अन्यथा जब स्ट्रिंग खराब स्वरूपित हो तो अंदर [`Err`] के लिए विशिष्ट त्रुटि लौटाएं।
    /// त्रुटि प्रकार trait के कार्यान्वयन के लिए विशिष्ट है।
    ///
    /// # Examples
    ///
    /// [`i32`] के साथ मूल उपयोग, एक प्रकार जो `FromStr` लागू करता है:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// एक स्ट्रिंग से `bool` पार्स करें।
    ///
    /// एक `Result<bool, ParseBoolError>` उत्पन्न करता है, क्योंकि `s` वास्तव में पार्स करने योग्य हो भी सकता है और नहीं भी।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// ध्यान दें, कई मामलों में, `str` पर `.parse()` विधि अधिक उचित है।
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}