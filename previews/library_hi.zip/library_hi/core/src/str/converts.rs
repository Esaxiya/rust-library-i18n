//! बाइट्स स्लाइस से `str` बनाने के तरीके।

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// बाइट्स के एक स्लाइस को एक स्ट्रिंग स्लाइस में कनवर्ट करता है।
///
/// एक स्ट्रिंग स्लाइस ([`&str`]) बाइट्स ([`u8`]) से बना है, और एक बाइट स्लाइस ([`&[u8]`][byteslice]) बाइट्स से बना है, इसलिए यह फ़ंक्शन दोनों के बीच कनवर्ट करता है।
/// सभी बाइट स्लाइस मान्य स्ट्रिंग स्लाइस नहीं हैं, हालांकि: [`&str`] के लिए यह आवश्यक है कि यह मान्य UTF-8 हो।
/// `from_utf8()` यह सुनिश्चित करने के लिए जांच करता है कि बाइट वैध UTF-8 हैं, और फिर रूपांतरण करता है।
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// यदि आप सुनिश्चित हैं कि बाइट स्लाइस वैध UTF-8 है, और आप वैधता जांच के ऊपरी हिस्से को नहीं लेना चाहते हैं, तो इस फ़ंक्शन का एक असुरक्षित संस्करण [`from_utf8_unchecked`] है, जिसका व्यवहार समान है लेकिन चेक को छोड़ देता है।
///
///
/// यदि आपको `&str` के बजाय `String` की आवश्यकता है, तो [`String::from_utf8`][string] पर विचार करें।
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// चूंकि आप `[u8; N]` को स्टैक-आवंटित कर सकते हैं, और आप इसका [`&[u8]`][byteslice] ले सकते हैं, यह फ़ंक्शन स्टैक-आवंटित स्ट्रिंग रखने का एक तरीका है।इसका एक उदाहरण नीचे दिए गए उदाहरण अनुभाग में है।
///
/// [byteslice]: slice
///
/// # Errors
///
/// यदि स्लाइस UTF-8 नहीं है तो इस विवरण के साथ `Err` लौटाता है कि प्रदान किया गया टुकड़ा UTF-8 क्यों नहीं है।
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// use std::str;
///
/// // vector. में कुछ बाइट्स
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // हम जानते हैं कि ये बाइट मान्य हैं, इसलिए बस `unwrap()` का उपयोग करें।
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// गलत बाइट्स:
///
/// ```
/// use std::str;
///
/// // vector. में कुछ अमान्य बाइट्स
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// वापस की जा सकने वाली त्रुटियों के प्रकार के बारे में अधिक विवरण के लिए [`Utf8Error`] के लिए दस्तावेज़ देखें।
///
/// एक "stack allocated string":
///
/// ```
/// use std::str;
///
/// // कुछ बाइट्स, एक स्टैक-आवंटित सरणी में
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // हम जानते हैं कि ये बाइट मान्य हैं, इसलिए बस `unwrap()` का उपयोग करें।
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // सुरक्षा: बस सत्यापन चलाया गया।
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// बाइट्स के एक परिवर्तनशील स्लाइस को एक परिवर्तनशील स्ट्रिंग स्लाइस में परिवर्तित करता है।
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" एक परिवर्तनीय vector. के रूप में
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // जैसा कि हम जानते हैं कि ये बाइट मान्य हैं, हम `unwrap()`. का उपयोग कर सकते हैं
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// गलत बाइट्स:
///
/// ```
/// use std::str;
///
/// // एक परिवर्तनीय vector in में कुछ अमान्य बाइट्स
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// वापस की जा सकने वाली त्रुटियों के प्रकार के बारे में अधिक विवरण के लिए [`Utf8Error`] के लिए दस्तावेज़ देखें।
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // सुरक्षा: बस सत्यापन चलाया गया।
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// यह जाँचे बिना कि स्ट्रिंग में मान्य UTF-8 है, बाइट्स के एक स्लाइस को एक स्ट्रिंग स्लाइस में कनवर्ट करता है।
///
/// अधिक जानकारी के लिए सुरक्षित संस्करण, [`from_utf8`] देखें।
///
/// # Safety
///
/// यह फ़ंक्शन असुरक्षित है क्योंकि यह जाँच नहीं करता है कि इसमें दिए गए बाइट मान्य UTF-8 हैं।
/// यदि इस बाधा का उल्लंघन किया जाता है, तो अपरिभाषित व्यवहार परिणाम देता है, जैसा कि शेष Rust मानता है कि [`&str`] s मान्य UTF-8 हैं।
///
///
/// [`&str`]: str
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// use std::str;
///
/// // vector. में कुछ बाइट्स
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि बाइट्स `v` वैध UTF-8 हैं।
    // समान लेआउट वाले `&str` और `&[u8]` पर भी निर्भर करता है।
    unsafe { mem::transmute(v) }
}

/// स्ट्रिंग में मान्य UTF-8 की जाँच किए बिना बाइट्स के एक स्लाइस को एक स्ट्रिंग स्लाइस में कनवर्ट करता है;परिवर्तनशील संस्करण।
///
///
/// अधिक जानकारी के लिए अपरिवर्तनीय संस्करण, [`from_utf8_unchecked()`] देखें।
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि बाइट्स `v`
    // वैध UTF-8 हैं, इस प्रकार `*mut str` के लिए कास्ट सुरक्षित है।
    // साथ ही, सूचक विचलन सुरक्षित है क्योंकि वह सूचक एक संदर्भ से आता है जिसे लिखने के लिए मान्य होने की गारंटी है।
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}