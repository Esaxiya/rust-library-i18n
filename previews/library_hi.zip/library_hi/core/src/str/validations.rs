//! UTF-8 सत्यापन से संबंधित संचालन।

use crate::mem;

use super::Utf8Error;

/// पहले बाइट के लिए प्रारंभिक कोडपॉइंट संचायक लौटाता है।
/// पहला बाइट विशेष है, केवल चौड़ाई 2 के लिए नीचे 5 बिट, चौड़ाई 3 के लिए 4 बिट और चौड़ाई 4 के लिए 3 बिट चाहिए।
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// निरंतरता बाइट `byte` के साथ अद्यतन किए गए `ch` का मान लौटाता है।
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// जाँचता है कि क्या बाइट एक UTF-8 निरंतरता बाइट है (अर्थात, बिट्स `10` से शुरू होता है)।
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// बाइट इटरेटर से अगला कोड बिंदु पढ़ता है (यूटीएफ-8-जैसे एन्कोडिंग मानते हुए)।
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // डिकोड UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // मल्टीबाइट केस बाइट संयोजन से डिकोड का अनुसरण करता है: [[[x y] z] w]
    //
    // NOTE: प्रदर्शन यहां सटीक फॉर्मूलेशन के प्रति संवेदनशील है
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] डब्ल्यू] मामला
        // 0xE0 में 5 वां बिट .. 0xEF हमेशा स्पष्ट होता है, इसलिए `init` अभी भी मान्य है
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] केस `init` के केवल निचले 3 बिट्स का उपयोग करें
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// बाइट इटरेटर से अंतिम कोड बिंदु पढ़ता है (यूटीएफ-8-जैसे एन्कोडिंग मानते हुए)।
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // डिकोड UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // मल्टीबाइट केस बाइट संयोजन से डिकोड का अनुसरण करता है: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// उपयोग में u64 फिट करने के लिए ट्रंकेशन का उपयोग करें
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// `true` लौटाता है यदि `x` शब्द में कोई भी बाइट nonascii (>=128) है।
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// `v` के माध्यम से चलता है कि यह एक वैध UTF-8 अनुक्रम है, उस स्थिति में `Ok(())` लौटाता है, या, यदि यह अमान्य है, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // हमें डेटा चाहिए था, लेकिन कोई नहीं था: त्रुटि!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2-बाइट एन्कोडिंग कोडपॉइंट\u {0080} से\u {07ff} पहले C2 80 अंतिम DF BF के लिए है
            // 3-बाइट एन्कोडिंग कोडप्वाइंट\u {0800} से\u {ffff} पहले E0 A0 80 अंतिम EF BF BF के लिए है जिसमें सरोगेट कोडपॉइंट्स\u {d800} से\u {dfff} ED A0 80 से ED BF BF शामिल नहीं हैं
            // 4-बाइट एन्कोडिंग कोडप्वाइंट\u {1000} 0 से\u {10ff} ff पहले F0 90 80 80 अंतिम F4 8F BF BF के लिए है
            //
            // RFC से UTF-8 सिंटैक्स का उपयोग करें
            //
            // https://tools.ietf.org/html/rfc3629
            // यूटीएफ8-1=%x00-7F EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ascii मामला, जल्दी से आगे बढ़ने की कोशिश करें।
            // जब सूचक को संरेखित किया जाता है, तो प्रति पुनरावृत्ति डेटा के 2 शब्द तब तक पढ़ें जब तक हमें एक गैर-असीसी बाइट वाला शब्द न मिल जाए।
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // सुरक्षा: चूंकि `align - index` और `ascii_block_size` हैं
                    // `usize_bytes`, `block = ptr.add(index)` के गुणकों को हमेशा `usize` के साथ संरेखित किया जाता है, इसलिए `block` और `block.offset(1)` दोनों को डीरेफेरेंस करना सुरक्षित है।
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // यदि कोई गैर-बाइट बाइट है तो तोड़ें
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // उस बिंदु से कदम जहां शब्दवार लूप रुका है
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// पहले बाइट को देखते हुए, यह निर्धारित करता है कि इस UTF-8 कैरेक्टर में कितने बाइट हैं।
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// एक निरंतरता बाइट के मान बिट्स का मुखौटा।
const CONT_MASK: u8 = 0b0011_1111;
/// एक निरंतरता बाइट के टैग बिट्स (टैग मास्क !CONT_MASK है) का मान।
const TAG_CONT_U8: u8 = 0b1000_0000;

// `&str` को लंबाई में `max` के बराबर छोटा करें यदि इसे छोटा किया गया हो तो `true` लौटाएं, और नया str.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}