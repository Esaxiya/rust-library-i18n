//! परमाणु प्रकार
//!
//! परमाणु प्रकार धागे के बीच आदिम साझा-स्मृति संचार प्रदान करते हैं, और अन्य समवर्ती प्रकारों के निर्माण खंड हैं।
//!
//! यह मॉड्यूल [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], आदि सहित कुछ चुनिंदा आदिम प्रकारों के परमाणु संस्करणों को परिभाषित करता है।
//! परमाणु प्रकार वर्तमान संचालन करते हैं, जब सही तरीके से उपयोग किया जाता है, तो थ्रेड्स के बीच अपडेट को सिंक्रनाइज़ करता है।
//!
//! प्रत्येक विधि एक [`Ordering`] लेती है जो उस ऑपरेशन के लिए मेमोरी बैरियर की ताकत का प्रतिनिधित्व करती है।ये आदेश [C++20 atomic orderings][1] के समान हैं।अधिक जानकारी के लिए [nomicon][2] देखें।
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! परमाणु चर थ्रेड्स के बीच साझा करने के लिए सुरक्षित हैं (वे [`Sync`] लागू करते हैं) लेकिन वे साझा करने के लिए तंत्र प्रदान नहीं करते हैं और Rust के [threading model](../../../std/thread/index.html#the-threading-model) का पालन करते हैं।
//!
//! परमाणु चर साझा करने का सबसे आम तरीका इसे [`Arc`][arc] (एक परमाणु-संदर्भ-गणना साझा सूचक) में रखना है।
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! परमाणु प्रकारों को स्थिर चर में संग्रहीत किया जा सकता है, [`AtomicBool::new`] जैसे निरंतर प्रारंभकर्ताओं का उपयोग करके प्रारंभ किया जाता है।परमाणु सांख्यिकी का उपयोग अक्सर आलसी वैश्विक आरंभीकरण के लिए किया जाता है।
//!
//! # Portability
//!
//! इस मॉड्यूल में सभी परमाणु प्रकार उपलब्ध होने पर [lock-free] होने की गारंटी है।इसका मतलब है कि वे आंतरिक रूप से वैश्विक म्यूटेक्स प्राप्त नहीं करते हैं।परमाणु प्रकार और संचालन की प्रतीक्षा-मुक्त होने की गारंटी नहीं है।
//! इसका मतलब है कि `fetch_or` जैसे संचालन को तुलना-और-स्वैप लूप के साथ लागू किया जा सकता है।
//!
//! बड़े आकार के परमाणु के साथ निर्देश परत पर परमाणु संचालन लागू किया जा सकता है।उदाहरण के लिए कुछ प्लेटफॉर्म `AtomicI8` को लागू करने के लिए 4-बाइट परमाणु निर्देशों का उपयोग करते हैं।
//! ध्यान दें कि इस अनुकरण का कोड की शुद्धता पर कोई असर नहीं होना चाहिए, यह केवल जागरूक होने के लिए कुछ है।
//!
//! इस मॉड्यूल में परमाणु प्रकार सभी प्लेटफार्मों पर उपलब्ध नहीं हो सकते हैं।हालांकि, यहां परमाणु प्रकार सभी व्यापक रूप से उपलब्ध हैं, और आम तौर पर मौजूदा पर भरोसा किया जा सकता है।कुछ उल्लेखनीय अपवाद हैं:
//!
//! * PowerPC और 32-बिट पॉइंटर्स वाले MIPS प्लेटफॉर्म में `AtomicU64` या `AtomicI64` प्रकार नहीं होते हैं।
//! * ARM `armv5te` जैसे प्लेटफ़ॉर्म जो Linux के लिए नहीं हैं, केवल `load` और `store` संचालन प्रदान करते हैं, और (CAS) संचालन, जैसे `swap`, `fetch_add`, आदि की तुलना और स्वैप का समर्थन नहीं करते हैं।
//! इसके अतिरिक्त Linux पर, ये CAS संचालन [operating system support] के माध्यम से कार्यान्वित किए जाते हैं, जो एक प्रदर्शन दंड के साथ आ सकते हैं।
//! * ARM `thumbv6m` के साथ लक्ष्य केवल `load` और `store` संचालन प्रदान करते हैं, और (CAS) संचालन, जैसे `swap`, `fetch_add`, आदि की तुलना और स्वैप का समर्थन नहीं करते हैं।
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! ध्यान दें कि future प्लेटफॉर्म जोड़े जा सकते हैं जिनमें कुछ परमाणु संचालन के लिए भी समर्थन नहीं है।अधिकतम पोर्टेबल कोड इस बात से सावधान रहना चाहेगा कि किस परमाणु प्रकार का उपयोग किया जाता है।
//! `AtomicUsize` और `AtomicIsize` आम तौर पर सबसे पोर्टेबल होते हैं, लेकिन फिर भी वे हर जगह उपलब्ध नहीं होते हैं।
//! संदर्भ के लिए, `std` लाइब्रेरी को पॉइंटर-आकार के परमाणु की आवश्यकता होती है, हालांकि `core` नहीं करता है।
//!
//! वर्तमान में आपको परमाणु के साथ कोड में सशर्त रूप से संकलित करने के लिए मुख्य रूप से `#[cfg(target_arch)]` का उपयोग करने की आवश्यकता होगी।एक अस्थिर `#[cfg(target_has_atomic)]` भी है जिसे future में स्थिर किया जा सकता है।
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! एक साधारण स्पिनलॉक:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // अन्य थ्रेड के लिए लॉक जारी करने की प्रतीक्षा करें
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! लाइव थ्रेड्स की वैश्विक गणना रखें:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// एक बूलियन प्रकार जिसे थ्रेड्स के बीच सुरक्षित रूप से साझा किया जा सकता है।
///
/// इस प्रकार का इन-मेमोरी प्रतिनिधित्व [`bool`] के समान है।
///
/// **नोट**: यह प्रकार केवल उन प्लेटफार्मों पर उपलब्ध है जो परमाणु भार और `u8` के स्टोर का समर्थन करते हैं।
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` के लिए आरंभिक `AtomicBool` बनाता है।
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// भेजें परमाणु बूल के लिए निहित रूप से लागू किया गया है।
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// एक कच्चा सूचक प्रकार जिसे थ्रेड्स के बीच सुरक्षित रूप से साझा किया जा सकता है।
///
/// इस प्रकार का इन-मेमोरी प्रतिनिधित्व `*mut T` के समान है।
///
/// **नोट**: यह प्रकार केवल उन प्लेटफार्मों पर उपलब्ध है जो परमाणु भार और पॉइंटर्स के स्टोर का समर्थन करते हैं।
/// इसका आकार लक्ष्य सूचक के आकार पर निर्भर करता है।
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// एक शून्य `AtomicPtr<T>` बनाता है।
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// परमाणु स्मृति आदेश
///
/// मेमोरी ऑर्डरिंग परमाणु संचालन मेमोरी को सिंक्रनाइज़ करने के तरीके को निर्दिष्ट करता है।
/// अपने सबसे कमजोर [`Ordering::Relaxed`] में, केवल ऑपरेशन द्वारा सीधे स्पर्श की गई मेमोरी को सिंक्रनाइज़ किया जाता है।
/// दूसरी ओर, [`Ordering::SeqCst`] ऑपरेशंस की एक स्टोर-लोड जोड़ी अन्य मेमोरी को सिंक्रोनाइज़ करती है जबकि अतिरिक्त रूप से सभी थ्रेड्स में इस तरह के ऑपरेशन के कुल ऑर्डर को संरक्षित करती है।
///
///
/// Rust की मेमोरी ऑर्डरिंग [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) है।
///
/// अधिक जानकारी के लिए [nomicon] देखें।
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// कोई आदेश देने की बाधा नहीं, केवल परमाणु संचालन।
    ///
    /// C++ 20 में [`memory_order_relaxed`] के अनुरूप है।
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// जब एक स्टोर के साथ जोड़ा जाता है, तो पिछले सभी ऑपरेशन [`Acquire`] (या मजबूत) ऑर्डरिंग के साथ इस मान के किसी भी लोड से पहले ऑर्डर किए जाते हैं।
    ///
    /// विशेष रूप से, पिछले सभी लेखन उन सभी थ्रेड्स के लिए दृश्यमान हो जाते हैं जो इस मान का [`Acquire`] (या अधिक मजबूत) लोड करते हैं।
    ///
    /// ध्यान दें कि लोड और स्टोर को संयोजित करने वाले ऑपरेशन के लिए इस ऑर्डरिंग का उपयोग करने से [`Relaxed`] लोड ऑपरेशन होता है!
    ///
    /// यह आदेश केवल उन परिचालनों के लिए लागू है जो एक स्टोर निष्पादित कर सकते हैं।
    ///
    /// C++ 20 में [`memory_order_release`] के अनुरूप है।
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// जब लोड के साथ जोड़ा जाता है, यदि लोड किए गए मान को स्टोर ऑपरेशन द्वारा [`Release`] (या मजबूत) ऑर्डरिंग के साथ लिखा गया था, तो बाद के सभी ऑपरेशन उस स्टोर के बाद ऑर्डर किए जाते हैं।
    /// विशेष रूप से, बाद के सभी लोड स्टोर से पहले लिखे गए डेटा को देखेंगे।
    ///
    /// ध्यान दें कि लोड और स्टोर को संयोजित करने वाले ऑपरेशन के लिए इस ऑर्डरिंग का उपयोग करने से [`Relaxed`] स्टोर ऑपरेशन होता है!
    ///
    /// यह आदेश केवल उन परिचालनों के लिए लागू होता है जो लोड कर सकते हैं।
    ///
    /// C++ 20 में [`memory_order_acquire`] के अनुरूप है।
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// [`Acquire`] और [`Release`] दोनों का एक साथ प्रभाव है:
    /// लोड के लिए यह [`Acquire`] ऑर्डरिंग का उपयोग करता है।स्टोर्स के लिए यह [`Release`] ऑर्डरिंग का उपयोग करता है।
    ///
    /// ध्यान दें कि `compare_and_swap` के मामले में, यह संभव है कि ऑपरेशन किसी भी स्टोर को निष्पादित नहीं कर रहा है और इसलिए इसमें केवल [`Acquire`] ऑर्डरिंग है।
    ///
    /// हालांकि, `AcqRel` कभी भी [`Relaxed`] एक्सेस नहीं करेगा।
    ///
    /// यह आदेश केवल उन परिचालनों के लिए लागू होता है जो लोड और स्टोर दोनों को मिलाते हैं।
    ///
    /// C++ 20 में [`memory_order_acq_rel`] के अनुरूप है।
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// जैसे [`Acquire`]/[`Release`]/[`AcqRel`](क्रमशः लोड, स्टोर और लोड-विद-स्टोर संचालन के लिए) अतिरिक्त गारंटी के साथ कि सभी थ्रेड एक ही क्रम में सभी क्रमिक रूप से सुसंगत संचालन देखते हैं .
    ///
    ///
    /// C++ 20 में [`memory_order_seq_cst`] के अनुरूप है।
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// एक [`AtomicBool`] को `false` में प्रारंभ किया गया।
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// एक नया `AtomicBool` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// अंतर्निहित [`bool`] के लिए एक परिवर्तनशील संदर्भ देता है।
    ///
    /// यह सुरक्षित है क्योंकि परिवर्तनीय संदर्भ गारंटी देता है कि कोई अन्य धागा समवर्ती रूप से परमाणु डेटा तक नहीं पहुंच रहा है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // सुरक्षा: परिवर्तनीय संदर्भ अद्वितीय स्वामित्व की गारंटी देता है।
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// एक `&mut bool` के लिए परमाणु पहुँच प्राप्त करें।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // सुरक्षा: परिवर्तनीय संदर्भ अद्वितीय स्वामित्व की गारंटी देता है, और
        // `bool` और `Self` दोनों का संरेखण 1 है।
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// परमाणु की खपत करता है और निहित मूल्य लौटाता है।
    ///
    /// यह सुरक्षित है क्योंकि मूल्य से `self` पास करना गारंटी देता है कि कोई अन्य थ्रेड समवर्ती रूप से परमाणु डेटा तक नहीं पहुंच रहा है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool से एक मान लोड करता है।
    ///
    /// `load` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।
    /// संभावित मान [`SeqCst`], [`Acquire`] और [`Relaxed`] हैं।
    ///
    /// # Panics
    ///
    /// Panics अगर `order` [`Release`] या [`AcqRel`] है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // सुरक्षा: किसी भी डेटा दौड़ को परमाणु आंतरिक और कच्चे. द्वारा रोका जाता है
        // पास किया गया पॉइंटर मान्य है क्योंकि हमें इसे एक संदर्भ से मिला है।
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool में एक मान स्टोर करता है।
    ///
    /// `store` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।
    /// संभावित मान [`SeqCst`], [`Release`] और [`Relaxed`] हैं।
    ///
    /// # Panics
    ///
    /// Panics अगर `order` [`Acquire`] या [`AcqRel`] है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // सुरक्षा: किसी भी डेटा दौड़ को परमाणु आंतरिक और कच्चे. द्वारा रोका जाता है
        // पास किया गया पॉइंटर मान्य है क्योंकि हमें इसे एक संदर्भ से मिला है।
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// bool में एक मान संग्रहीत करता है, पिछला मान लौटाता है।
    ///
    /// `swap` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
    /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
    ///
    ///
    /// **Note:** यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो `u8` पर परमाणु संचालन का समर्थन करते हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// [`bool`] में एक मान संग्रहीत करता है यदि वर्तमान मान `current` मान के समान है।
    ///
    /// वापसी मूल्य हमेशा पिछला मूल्य होता है।यदि यह `current` के बराबर है, तो मान अपडेट किया गया था।
    ///
    /// `compare_and_swap` एक [`Ordering`] तर्क भी लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।
    /// ध्यान दें कि [`AcqRel`] का उपयोग करते समय भी, ऑपरेशन विफल हो सकता है और इसलिए केवल `Acquire` लोड करें, लेकिन `Release` शब्दार्थ नहीं है।
    /// यदि ऐसा होता है तो [`Acquire`] का उपयोग इस ऑपरेशन का स्टोर हिस्सा [`Relaxed`] बनाता है, और [`Release`] का उपयोग लोड भाग को [`Relaxed`] बनाता है।
    ///
    /// **Note:** यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो `u8` पर परमाणु संचालन का समर्थन करते हैं।
    ///
    /// # `compare_exchange` और `compare_exchange_weak` में माइग्रेट करना
    ///
    /// `compare_and_swap` मेमोरी ऑर्डरिंग के लिए निम्नलिखित मैपिंग के साथ `compare_exchange` के बराबर है:
    ///
    /// मूल |सफलता |असफलता
    /// -------- | ------- | -------
    /// आराम से |आराम से |आराम से प्राप्त करें |अधिग्रहण |रिलीज प्राप्त करें |रिलीज |आराम से AcqRel |AcqRel |SeqCst प्राप्त करें |सेक्स्ट |SeqCst
    ///
    /// `compare_exchange_weak` तुलना के सफल होने पर भी नकली रूप से विफल होने की अनुमति है, जो संकलक को बेहतर असेंबली कोड उत्पन्न करने की अनुमति देता है जब तुलना और स्वैप का उपयोग लूप में किया जाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// [`bool`] में एक मान संग्रहीत करता है यदि वर्तमान मान `current` मान के समान है।
    ///
    /// वापसी मूल्य एक परिणाम है जो दर्शाता है कि क्या नया मूल्य लिखा गया था और इसमें पिछला मूल्य था।
    /// सफलता पर यह मान `current` के बराबर होने की गारंटी है।
    ///
    /// `compare_exchange` इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करने के लिए दो [`Ordering`] तर्क लेता है।
    /// `success` `current` के साथ तुलना सफल होने पर होने वाले रीड-मॉडिफाई-राइट ऑपरेशन के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।
    /// `failure` तुलना विफल होने पर होने वाले लोड ऑपरेशन के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।
    /// [`Acquire`] को सक्सेस ऑर्डरिंग के रूप में उपयोग करना स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके सफल लोड [`Relaxed`] बनाता है।
    ///
    /// विफलता आदेश केवल [`SeqCst`], [`Acquire`] या [`Relaxed`] हो सकता है और सफलता आदेश के बराबर या कमजोर होना चाहिए।
    ///
    /// **Note:** यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो `u8` पर परमाणु संचालन का समर्थन करते हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// [`bool`] में एक मान संग्रहीत करता है यदि वर्तमान मान `current` मान के समान है।
    ///
    /// [`AtomicBool::compare_exchange`] के विपरीत, तुलना के सफल होने पर भी इस फ़ंक्शन को नकली रूप से विफल होने की अनुमति है, जिसके परिणामस्वरूप कुछ प्लेटफ़ॉर्म पर अधिक कुशल कोड हो सकता है।
    ///
    /// वापसी मूल्य एक परिणाम है जो दर्शाता है कि क्या नया मूल्य लिखा गया था और इसमें पिछला मूल्य था।
    ///
    /// `compare_exchange_weak` इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करने के लिए दो [`Ordering`] तर्क लेता है।
    /// `success` `current` के साथ तुलना सफल होने पर होने वाले रीड-मॉडिफाई-राइट ऑपरेशन के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।
    /// `failure` तुलना विफल होने पर होने वाले लोड ऑपरेशन के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।
    /// [`Acquire`] को सक्सेस ऑर्डरिंग के रूप में उपयोग करना स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके सफल लोड [`Relaxed`] बनाता है।
    /// विफलता आदेश केवल [`SeqCst`], [`Acquire`] या [`Relaxed`] हो सकता है और सफलता आदेश के बराबर या कमजोर होना चाहिए।
    ///
    /// **Note:** यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो `u8` पर परमाणु संचालन का समर्थन करते हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// तार्किक "and" एक बूलियन मान के साथ।
    ///
    /// वर्तमान मान और तर्क `val` पर एक तार्किक "and" ऑपरेशन करता है, और परिणाम के लिए नया मान सेट करता है।
    ///
    /// पिछला मान लौटाता है।
    ///
    /// `fetch_and` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
    /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
    ///
    ///
    /// **Note:** यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो `u8` पर परमाणु संचालन का समर्थन करते हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// तार्किक "nand" एक बूलियन मान के साथ।
    ///
    /// वर्तमान मान और तर्क `val` पर एक तार्किक "nand" ऑपरेशन करता है, और परिणाम के लिए नया मान सेट करता है।
    ///
    /// पिछला मान लौटाता है।
    ///
    /// `fetch_nand` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
    /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
    ///
    ///
    /// **Note:** यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो `u8` पर परमाणु संचालन का समर्थन करते हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // हम यहां परमाणु_नंद का उपयोग नहीं कर सकते क्योंकि इसका परिणाम bool में अमान्य मान के साथ हो सकता है।
        // ऐसा इसलिए होता है क्योंकि परमाणु संचालन आंतरिक रूप से 8-बिट पूर्णांक के साथ किया जाता है, जो ऊपरी 7 बिट्स को सेट करेगा।
        //
        // इसलिए हम इसके बजाय बस fetch_xor या स्वैप का उपयोग करते हैं।
        if val {
            // !(x&true)== !x हमें bool को उल्टा करना चाहिए।
            //
            self.fetch_xor(true, order)
        } else {
            // !(x&false)==true हमें bool को सही पर सेट करना होगा।
            //
            self.swap(true, order)
        }
    }

    /// तार्किक "or" एक बूलियन मान के साथ।
    ///
    /// वर्तमान मान और तर्क `val` पर एक तार्किक "or" ऑपरेशन करता है, और परिणाम के लिए नया मान सेट करता है।
    ///
    /// पिछला मान लौटाता है।
    ///
    /// `fetch_or` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
    /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
    ///
    ///
    /// **Note:** यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो `u8` पर परमाणु संचालन का समर्थन करते हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// तार्किक "xor" एक बूलियन मान के साथ।
    ///
    /// वर्तमान मान और तर्क `val` पर एक तार्किक "xor" ऑपरेशन करता है, और परिणाम के लिए नया मान सेट करता है।
    ///
    /// पिछला मान लौटाता है।
    ///
    /// `fetch_xor` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
    /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
    ///
    ///
    /// **Note:** यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो `u8` पर परमाणु संचालन का समर्थन करते हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// अंतर्निहित [`bool`] के लिए एक परिवर्तनशील सूचक देता है।
    ///
    /// परिणामी पूर्णांक पर गैर-परमाणु पढ़ना और लिखना डेटा दौड़ हो सकता है।
    /// यह विधि ज्यादातर एफएफआई के लिए उपयोगी है, जहां फ़ंक्शन हस्ताक्षर `&AtomicBool` के बजाय `*mut bool` का उपयोग कर सकता है।
    ///
    /// इस परमाणु के साझा संदर्भ से `*mut` पॉइंटर लौटाना सुरक्षित है क्योंकि परमाणु प्रकार आंतरिक परिवर्तनशीलता के साथ काम करते हैं।
    /// एक परमाणु के सभी संशोधन एक साझा संदर्भ के माध्यम से मूल्य को बदलते हैं, और जब तक वे परमाणु संचालन का उपयोग करते हैं, तब तक वे सुरक्षित रूप से ऐसा कर सकते हैं।
    /// लौटाए गए कच्चे पॉइंटर के किसी भी उपयोग के लिए `unsafe` ब्लॉक की आवश्यकता होती है और फिर भी उसी प्रतिबंध को बनाए रखना होता है: इस पर संचालन परमाणु होना चाहिए।
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// मान प्राप्त करता है, और उस पर एक फ़ंक्शन लागू करता है जो एक वैकल्पिक नया मान देता है।यदि फ़ंक्शन `Some(_)`, अन्यथा `Err(previous_value)` लौटाता है, तो `Ok(previous_value)` का `Result` लौटाता है।
    ///
    /// Note: यह फ़ंक्शन को कई बार कॉल कर सकता है यदि इस बीच अन्य थ्रेड्स से मान बदल दिया गया है, जब तक कि फ़ंक्शन `Some(_)` लौटाता है, लेकिन फ़ंक्शन संग्रहीत मान पर केवल एक बार लागू किया जाएगा।
    ///
    ///
    /// `fetch_update` इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करने के लिए दो [`Ordering`] तर्क लेता है।
    /// पहला ऑपरेशन के अंत में सफल होने के लिए आवश्यक ऑर्डरिंग का वर्णन करता है जबकि दूसरा लोड के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।
    /// ये क्रमशः [`AtomicBool::compare_exchange`] की सफलता और विफलता के क्रम के अनुरूप हैं।
    ///
    /// [`Acquire`] को सक्सेस ऑर्डरिंग के रूप में उपयोग करना स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके अंतिम सफल लोड [`Relaxed`] बनाता है।
    /// (failed) लोड ऑर्डरिंग केवल [`SeqCst`], [`Acquire`] या [`Relaxed`] हो सकता है और सफलता ऑर्डरिंग के बराबर या कमजोर होना चाहिए।
    ///
    /// **Note:** यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो `u8` पर परमाणु संचालन का समर्थन करते हैं।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// एक नया `AtomicPtr` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// अंतर्निहित सूचक के लिए एक परिवर्तनीय संदर्भ देता है।
    ///
    /// यह सुरक्षित है क्योंकि परिवर्तनीय संदर्भ गारंटी देता है कि कोई अन्य धागा समवर्ती रूप से परमाणु डेटा तक नहीं पहुंच रहा है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// एक सूचक के लिए परमाणु पहुँच प्राप्त करें।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - परिवर्तनीय संदर्भ अद्वितीय स्वामित्व की गारंटी देता है।
        //  - `*mut T` और `Self` का संरेखण rust द्वारा समर्थित सभी प्लेटफार्मों पर समान है, जैसा कि ऊपर सत्यापित किया गया है।
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// परमाणु की खपत करता है और निहित मूल्य लौटाता है।
    ///
    /// यह सुरक्षित है क्योंकि मूल्य से `self` पास करना गारंटी देता है कि कोई अन्य थ्रेड समवर्ती रूप से परमाणु डेटा तक नहीं पहुंच रहा है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// सूचक से एक मान लोड करता है।
    ///
    /// `load` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।
    /// संभावित मान [`SeqCst`], [`Acquire`] और [`Relaxed`] हैं।
    ///
    /// # Panics
    ///
    /// Panics अगर `order` [`Release`] या [`AcqRel`] है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// सूचक में एक मान संग्रहीत करता है।
    ///
    /// `store` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।
    /// संभावित मान [`SeqCst`], [`Release`] और [`Relaxed`] हैं।
    ///
    /// # Panics
    ///
    /// Panics अगर `order` [`Acquire`] या [`AcqRel`] है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// पिछले मान को वापस करते हुए, पॉइंटर में एक मान संग्रहीत करता है।
    ///
    /// `swap` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
    /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
    ///
    ///
    /// **Note:** यह विधि केवल उन प्लेटफार्मों पर उपलब्ध है जो पॉइंटर्स पर परमाणु संचालन का समर्थन करते हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// यदि वर्तमान मान `current` मान के समान है, तो मान को पॉइंटर में संग्रहीत करता है।
    ///
    /// वापसी मूल्य हमेशा पिछला मूल्य होता है।यदि यह `current` के बराबर है, तो मान अपडेट किया गया था।
    ///
    /// `compare_and_swap` एक [`Ordering`] तर्क भी लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।
    /// ध्यान दें कि [`AcqRel`] का उपयोग करते समय भी, ऑपरेशन विफल हो सकता है और इसलिए केवल `Acquire` लोड करें, लेकिन `Release` शब्दार्थ नहीं है।
    /// यदि ऐसा होता है तो [`Acquire`] का उपयोग इस ऑपरेशन का स्टोर हिस्सा [`Relaxed`] बनाता है, और [`Release`] का उपयोग लोड भाग को [`Relaxed`] बनाता है।
    ///
    /// **Note:** यह विधि केवल उन प्लेटफार्मों पर उपलब्ध है जो पॉइंटर्स पर परमाणु संचालन का समर्थन करते हैं।
    ///
    /// # `compare_exchange` और `compare_exchange_weak` में माइग्रेट करना
    ///
    /// `compare_and_swap` मेमोरी ऑर्डरिंग के लिए निम्नलिखित मैपिंग के साथ `compare_exchange` के बराबर है:
    ///
    /// मूल |सफलता |असफलता
    /// -------- | ------- | -------
    /// आराम से |आराम से |आराम से प्राप्त करें |अधिग्रहण |रिलीज प्राप्त करें |रिलीज |आराम से AcqRel |AcqRel |SeqCst प्राप्त करें |सेक्स्ट |SeqCst
    ///
    /// `compare_exchange_weak` तुलना के सफल होने पर भी नकली रूप से विफल होने की अनुमति है, जो संकलक को बेहतर असेंबली कोड उत्पन्न करने की अनुमति देता है जब तुलना और स्वैप का उपयोग लूप में किया जाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// यदि वर्तमान मान `current` मान के समान है, तो मान को पॉइंटर में संग्रहीत करता है।
    ///
    /// वापसी मूल्य एक परिणाम है जो दर्शाता है कि क्या नया मूल्य लिखा गया था और इसमें पिछला मूल्य था।
    /// सफलता पर यह मान `current` के बराबर होने की गारंटी है।
    ///
    /// `compare_exchange` इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करने के लिए दो [`Ordering`] तर्क लेता है।
    /// `success` `current` के साथ तुलना सफल होने पर होने वाले रीड-मॉडिफाई-राइट ऑपरेशन के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।
    /// `failure` तुलना विफल होने पर होने वाले लोड ऑपरेशन के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।
    /// [`Acquire`] को सक्सेस ऑर्डरिंग के रूप में उपयोग करना स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके सफल लोड [`Relaxed`] बनाता है।
    ///
    /// विफलता आदेश केवल [`SeqCst`], [`Acquire`] या [`Relaxed`] हो सकता है और सफलता आदेश के बराबर या कमजोर होना चाहिए।
    ///
    /// **Note:** यह विधि केवल उन प्लेटफार्मों पर उपलब्ध है जो पॉइंटर्स पर परमाणु संचालन का समर्थन करते हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// यदि वर्तमान मान `current` मान के समान है, तो मान को पॉइंटर में संग्रहीत करता है।
    ///
    /// [`AtomicPtr::compare_exchange`] के विपरीत, तुलना के सफल होने पर भी इस फ़ंक्शन को नकली रूप से विफल होने की अनुमति है, जिसके परिणामस्वरूप कुछ प्लेटफ़ॉर्म पर अधिक कुशल कोड हो सकता है।
    ///
    /// वापसी मूल्य एक परिणाम है जो दर्शाता है कि क्या नया मूल्य लिखा गया था और इसमें पिछला मूल्य था।
    ///
    /// `compare_exchange_weak` इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करने के लिए दो [`Ordering`] तर्क लेता है।
    /// `success` `current` के साथ तुलना सफल होने पर होने वाले रीड-मॉडिफाई-राइट ऑपरेशन के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।
    /// `failure` तुलना विफल होने पर होने वाले लोड ऑपरेशन के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।
    /// [`Acquire`] को सक्सेस ऑर्डरिंग के रूप में उपयोग करना स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके सफल लोड [`Relaxed`] बनाता है।
    /// विफलता आदेश केवल [`SeqCst`], [`Acquire`] या [`Relaxed`] हो सकता है और सफलता आदेश के बराबर या कमजोर होना चाहिए।
    ///
    /// **Note:** यह विधि केवल उन प्लेटफार्मों पर उपलब्ध है जो पॉइंटर्स पर परमाणु संचालन का समर्थन करते हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // सुरक्षा: यह आंतरिक असुरक्षित है क्योंकि यह एक कच्चे सूचक पर संचालित होता है
        // लेकिन हम यह सुनिश्चित करने के लिए जानते हैं कि सूचक मान्य है (हमें इसे केवल एक `UnsafeCell` से मिला है जो हमारे पास संदर्भ के अनुसार है) और परमाणु संचालन ही हमें `UnsafeCell` सामग्री को सुरक्षित रूप से उत्परिवर्तित करने की अनुमति देता है।
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// मान प्राप्त करता है, और उस पर एक फ़ंक्शन लागू करता है जो एक वैकल्पिक नया मान देता है।यदि फ़ंक्शन `Some(_)`, अन्यथा `Err(previous_value)` लौटाता है, तो `Ok(previous_value)` का `Result` लौटाता है।
    ///
    /// Note: यह फ़ंक्शन को कई बार कॉल कर सकता है यदि इस बीच अन्य थ्रेड्स से मान बदल दिया गया है, जब तक कि फ़ंक्शन `Some(_)` लौटाता है, लेकिन फ़ंक्शन संग्रहीत मान पर केवल एक बार लागू किया जाएगा।
    ///
    ///
    /// `fetch_update` इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करने के लिए दो [`Ordering`] तर्क लेता है।
    /// पहला ऑपरेशन के अंत में सफल होने के लिए आवश्यक ऑर्डरिंग का वर्णन करता है जबकि दूसरा लोड के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।
    /// ये क्रमशः [`AtomicPtr::compare_exchange`] की सफलता और विफलता के क्रम के अनुरूप हैं।
    ///
    /// [`Acquire`] को सक्सेस ऑर्डरिंग के रूप में उपयोग करना स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके अंतिम सफल लोड [`Relaxed`] बनाता है।
    /// (failed) लोड ऑर्डरिंग केवल [`SeqCst`], [`Acquire`] या [`Relaxed`] हो सकता है और सफलता ऑर्डरिंग के बराबर या कमजोर होना चाहिए।
    ///
    /// **Note:** यह विधि केवल उन प्लेटफार्मों पर उपलब्ध है जो पॉइंटर्स पर परमाणु संचालन का समर्थन करते हैं।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` को `AtomicBool` में कनवर्ट करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // यह मैक्रो कुछ आर्किटेक्चर पर अप्रयुक्त हो जाता है।
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// एक पूर्णांक प्रकार जिसे थ्रेड्स के बीच सुरक्षित रूप से साझा किया जा सकता है।
        ///
        /// इस प्रकार में अंतर्निहित पूर्णांक प्रकार के समान इन-मेमोरी प्रतिनिधित्व है, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// परमाणु प्रकार और गैर-परमाणु प्रकारों के बीच अंतर के साथ-साथ इस प्रकार की पोर्टेबिलिटी के बारे में जानकारी के लिए, कृपया [module-level documentation] देखें।
        ///
        ///
        /// **Note:** यह प्रकार केवल उन प्लेटफार्मों पर उपलब्ध है जो परमाणु भार और [`. के भंडार का समर्थन करते हैं
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// एक परमाणु पूर्णांक `0` के लिए प्रारंभ किया गया।
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // भेजें परोक्ष रूप से लागू किया गया है।
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// एक नया परमाणु पूर्णांक बनाता है।
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// अंतर्निहित पूर्णांक के लिए एक परिवर्तनशील संदर्भ देता है।
            ///
            /// यह सुरक्षित है क्योंकि परिवर्तनीय संदर्भ गारंटी देता है कि कोई अन्य धागा समवर्ती रूप से परमाणु डेटा तक नहीं पहुंच रहा है।
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// चलो कुछ_इंट=123 को म्यूट करें;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq!(some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - परिवर्तनीय संदर्भ अद्वितीय स्वामित्व की गारंटी देता है।
                //  - `$int_type` और `Self` का संरेखण वही है, जैसा कि $cfg_align द्वारा वादा किया गया था और ऊपर सत्यापित किया गया था।
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// परमाणु की खपत करता है और निहित मूल्य लौटाता है।
            ///
            /// यह सुरक्षित है क्योंकि मूल्य से `self` पास करना गारंटी देता है कि कोई अन्य थ्रेड समवर्ती रूप से परमाणु डेटा तक नहीं पहुंच रहा है।
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// परमाणु पूर्णांक से एक मान लोड करता है।
            ///
            /// `load` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।
            /// संभावित मान [`SeqCst`], [`Acquire`] और [`Relaxed`] हैं।
            ///
            /// # Panics
            ///
            /// Panics अगर `order` [`Release`] या [`AcqRel`] है।
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// एक मान को परमाणु पूर्णांक में संग्रहीत करता है।
            ///
            /// `store` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।
            ///  संभावित मान [`SeqCst`], [`Release`] और [`Relaxed`] हैं।
            ///
            /// # Panics
            ///
            /// Panics अगर `order` [`Acquire`] या [`AcqRel`] है।
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// एक मान को परमाणु पूर्णांक में संग्रहीत करता है, पिछले मान को लौटाता है।
            ///
            /// `swap` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
            /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
            ///
            ///
            /// **नोट**: यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो परमाणु संचालन का समर्थन करते हैं
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// एक मान को परमाणु पूर्णांक में संग्रहीत करता है यदि वर्तमान मान `current` मान के समान है।
            ///
            /// वापसी मूल्य हमेशा पिछला मूल्य होता है।यदि यह `current` के बराबर है, तो मान अपडेट किया गया था।
            ///
            /// `compare_and_swap` एक [`Ordering`] तर्क भी लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।
            /// ध्यान दें कि [`AcqRel`] का उपयोग करते समय भी, ऑपरेशन विफल हो सकता है और इसलिए केवल `Acquire` लोड करें, लेकिन `Release` शब्दार्थ नहीं है।
            ///
            /// यदि ऐसा होता है तो [`Acquire`] का उपयोग इस ऑपरेशन का स्टोर हिस्सा [`Relaxed`] बनाता है, और [`Release`] का उपयोग लोड भाग को [`Relaxed`] बनाता है।
            ///
            /// **नोट**: यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो परमाणु संचालन का समर्थन करते हैं
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` और `compare_exchange_weak` में माइग्रेट करना
            ///
            /// `compare_and_swap` मेमोरी ऑर्डरिंग के लिए निम्नलिखित मैपिंग के साथ `compare_exchange` के बराबर है:
            ///
            /// मूल |सफलता |असफलता
            /// -------- | ------- | -------
            /// आराम से |आराम से |आराम से प्राप्त करें |अधिग्रहण |रिलीज प्राप्त करें |रिलीज |आराम से AcqRel |AcqRel |SeqCst प्राप्त करें |सेक्स्ट |SeqCst
            ///
            /// `compare_exchange_weak` तुलना के सफल होने पर भी नकली रूप से विफल होने की अनुमति है, जो संकलक को बेहतर असेंबली कोड उत्पन्न करने की अनुमति देता है जब तुलना और स्वैप का उपयोग लूप में किया जाता है।
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// एक मान को परमाणु पूर्णांक में संग्रहीत करता है यदि वर्तमान मान `current` मान के समान है।
            ///
            /// वापसी मूल्य एक परिणाम है जो दर्शाता है कि क्या नया मूल्य लिखा गया था और इसमें पिछला मूल्य था।
            /// सफलता पर यह मान `current` के बराबर होने की गारंटी है।
            ///
            /// `compare_exchange` इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करने के लिए दो [`Ordering`] तर्क लेता है।
            /// `success` `current` के साथ तुलना सफल होने पर होने वाले रीड-मॉडिफाई-राइट ऑपरेशन के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।
            /// `failure` तुलना विफल होने पर होने वाले लोड ऑपरेशन के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।
            /// [`Acquire`] को सक्सेस ऑर्डरिंग के रूप में उपयोग करना स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके सफल लोड [`Relaxed`] बनाता है।
            ///
            /// विफलता आदेश केवल [`SeqCst`], [`Acquire`] या [`Relaxed`] हो सकता है और सफलता आदेश के बराबर या कमजोर होना चाहिए।
            ///
            /// **नोट**: यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो परमाणु संचालन का समर्थन करते हैं
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// एक मान को परमाणु पूर्णांक में संग्रहीत करता है यदि वर्तमान मान `current` मान के समान है।
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// तुलना के सफल होने पर भी इस फ़ंक्शन को नकली रूप से विफल होने की अनुमति है, जिसके परिणामस्वरूप कुछ प्लेटफ़ॉर्म पर अधिक कुशल कोड हो सकता है।
            /// वापसी मूल्य एक परिणाम है जो दर्शाता है कि क्या नया मूल्य लिखा गया था और इसमें पिछला मूल्य था।
            ///
            /// `compare_exchange_weak` इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करने के लिए दो [`Ordering`] तर्क लेता है।
            /// `success` `current` के साथ तुलना सफल होने पर होने वाले रीड-मॉडिफाई-राइट ऑपरेशन के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।
            /// `failure` तुलना विफल होने पर होने वाले लोड ऑपरेशन के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।
            /// [`Acquire`] को सक्सेस ऑर्डरिंग के रूप में उपयोग करना स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके सफल लोड [`Relaxed`] बनाता है।
            ///
            /// विफलता आदेश केवल [`SeqCst`], [`Acquire`] या [`Relaxed`] हो सकता है और सफलता आदेश के बराबर या कमजोर होना चाहिए।
            ///
            /// **नोट**: यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो परमाणु संचालन का समर्थन करते हैं
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// म्यूट ओल्ड= val.load(Ordering::Relaxed);
            /// लूप {चलो नया=पुराना * 2;
            ///     मैच val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// वर्तमान मान में जोड़ता है, पिछला मान लौटाता है।
            ///
            /// यह ऑपरेशन अतिप्रवाह पर चारों ओर लपेटता है।
            ///
            /// `fetch_add` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
            /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
            ///
            ///
            /// **नोट**: यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो परमाणु संचालन का समर्थन करते हैं
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// वर्तमान मान से घटाता है, पिछला मान लौटाता है।
            ///
            /// यह ऑपरेशन अतिप्रवाह पर चारों ओर लपेटता है।
            ///
            /// `fetch_sub` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
            /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
            ///
            ///
            /// **नोट**: यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो परमाणु संचालन का समर्थन करते हैं
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// बिटवाइज़ "and" वर्तमान मान के साथ।
            ///
            /// वर्तमान मान और तर्क `val` पर थोड़ा सा "and" ऑपरेशन करता है, और परिणाम के लिए नया मान सेट करता है।
            ///
            /// पिछला मान लौटाता है।
            ///
            /// `fetch_and` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
            /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
            ///
            ///
            /// **नोट**: यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो परमाणु संचालन का समर्थन करते हैं
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// बिटवाइज़ "nand" वर्तमान मान के साथ।
            ///
            /// वर्तमान मान और तर्क `val` पर थोड़ा सा "nand" ऑपरेशन करता है, और परिणाम के लिए नया मान सेट करता है।
            ///
            /// पिछला मान लौटाता है।
            ///
            /// `fetch_nand` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
            /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
            ///
            ///
            /// **नोट**: यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो परमाणु संचालन का समर्थन करते हैं
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), !(0x13 और 0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// बिटवाइज़ "or" वर्तमान मान के साथ।
            ///
            /// वर्तमान मान और तर्क `val` पर थोड़ा सा "or" ऑपरेशन करता है, और परिणाम के लिए नया मान सेट करता है।
            ///
            /// पिछला मान लौटाता है।
            ///
            /// `fetch_or` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
            /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
            ///
            ///
            /// **नोट**: यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो परमाणु संचालन का समर्थन करते हैं
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// बिटवाइज़ "xor" वर्तमान मान के साथ।
            ///
            /// वर्तमान मान और तर्क `val` पर थोड़ा सा "xor" ऑपरेशन करता है, और परिणाम के लिए नया मान सेट करता है।
            ///
            /// पिछला मान लौटाता है।
            ///
            /// `fetch_xor` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
            /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
            ///
            ///
            /// **नोट**: यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो परमाणु संचालन का समर्थन करते हैं
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// मान प्राप्त करता है, और उस पर एक फ़ंक्शन लागू करता है जो एक वैकल्पिक नया मान देता है।यदि फ़ंक्शन `Some(_)`, अन्यथा `Err(previous_value)` लौटाता है, तो `Ok(previous_value)` का `Result` लौटाता है।
            ///
            /// Note: यह फ़ंक्शन को कई बार कॉल कर सकता है यदि इस बीच अन्य थ्रेड्स से मान बदल दिया गया है, जब तक कि फ़ंक्शन `Some(_)` लौटाता है, लेकिन फ़ंक्शन संग्रहीत मान पर केवल एक बार लागू किया जाएगा।
            ///
            ///
            /// `fetch_update` इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करने के लिए दो [`Ordering`] तर्क लेता है।
            /// पहला ऑपरेशन के अंत में सफल होने के लिए आवश्यक ऑर्डरिंग का वर्णन करता है जबकि दूसरा लोड के लिए आवश्यक ऑर्डरिंग का वर्णन करता है।ये सफलता और विफलता के आदेशों के अनुरूप हैं
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`] को सक्सेस ऑर्डरिंग के रूप में उपयोग करना स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके अंतिम सफल लोड [`Relaxed`] बनाता है।
            /// (failed) लोड ऑर्डरिंग केवल [`SeqCst`], [`Acquire`] या [`Relaxed`] हो सकता है और सफलता ऑर्डरिंग के बराबर या कमजोर होना चाहिए।
            ///
            /// **नोट**: यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो परमाणु संचालन का समर्थन करते हैं
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq!(x.fetch_update (Ording: :SeqCst, Ordering::SeqCst, |x| Some(x + 1)), Ok(7));
            /// assert_eq!(x.fetch_update (Ording: :SeqCst, Ordering::SeqCst, |x| Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// वर्तमान मूल्य के साथ अधिकतम।
            ///
            /// अधिकतम वर्तमान मान और तर्क `val` ढूँढता है, और परिणाम के लिए नया मान सेट करता है।
            ///
            /// पिछला मान लौटाता है।
            ///
            /// `fetch_max` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
            /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
            ///
            ///
            /// **नोट**: यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो परमाणु संचालन का समर्थन करते हैं
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// लेट बार=42;
            /// चलो max_foo=foo.fetch_max (बार, Ordering::SeqCst).max(bar);
            /// जोर दें! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// वर्तमान मूल्य के साथ न्यूनतम।
            ///
            /// वर्तमान मान का न्यूनतम और तर्क `val` ढूँढता है, और परिणाम के लिए नया मान सेट करता है।
            ///
            /// पिछला मान लौटाता है।
            ///
            /// `fetch_min` एक [`Ordering`] तर्क लेता है जो इस ऑपरेशन के मेमोरी ऑर्डरिंग का वर्णन करता है।सभी आदेश देने के तरीके संभव हैं।
            /// ध्यान दें कि [`Acquire`] का उपयोग स्टोर को इस ऑपरेशन [`Relaxed`] का हिस्सा बनाता है, और [`Release`] का उपयोग करके लोड भाग [`Relaxed`] बनाता है।
            ///
            ///
            /// **नोट**: यह विधि केवल उन प्लेटफॉर्म पर उपलब्ध है जो परमाणु संचालन का समर्थन करते हैं
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// लेट बार=12;
            /// चलो min_foo=foo.fetch_min (बार, Ordering::SeqCst).min(bar);
            /// assert_eq!(min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा दौड़ को परमाणु आंतरिकता द्वारा रोका जाता है।
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// अंतर्निहित पूर्णांक के लिए एक परिवर्तनशील सूचक देता है।
            ///
            /// परिणामी पूर्णांक पर गैर-परमाणु पढ़ना और लिखना डेटा दौड़ हो सकता है।
            /// यह विधि ज्यादातर एफएफआई के लिए उपयोगी है, जहां फ़ंक्शन हस्ताक्षर उपयोग कर सकते हैं
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// इस परमाणु के साझा संदर्भ से `*mut` पॉइंटर लौटाना सुरक्षित है क्योंकि परमाणु प्रकार आंतरिक परिवर्तनशीलता के साथ काम करते हैं।
            /// एक परमाणु के सभी संशोधन एक साझा संदर्भ के माध्यम से मूल्य को बदलते हैं, और जब तक वे परमाणु संचालन का उपयोग करते हैं, तब तक वे सुरक्षित रूप से ऐसा कर सकते हैं।
            /// लौटाए गए कच्चे पॉइंटर के किसी भी उपयोग के लिए `unsafe` ब्लॉक की आवश्यकता होती है और फिर भी उसी प्रतिबंध को बनाए रखना होता है: इस पर संचालन परमाणु होना चाहिए।
            ///
            ///
            /// # Examples
            ///
            /// ``(extern-declaration) को अनदेखा करें
            ///
            /// # एफएन main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// बाहरी "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // सुरक्षा: जब तक `my_atomic_op` परमाणु है तब तक सुरक्षित।
            /// असुरक्षित {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // सुरक्षा: कॉल करने वाले को `atomic_store` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // सुरक्षा: कॉल करने वाले को `atomic_load` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कॉल करने वाले को `atomic_swap` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// पिछला मान देता है (जैसे __sync_fetch_and_add)।
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कॉल करने वाले को `atomic_add` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// पिछला मान लौटाता है (जैसे __sync_fetch_and_sub)।
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कॉल करने वाले को `atomic_sub` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // सुरक्षा: कॉल करने वाले को `atomic_compare_exchange` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // सुरक्षा: कॉल करने वाले को `atomic_compare_exchange_weak` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कॉल करने वाले को `atomic_and`. के सुरक्षा अनुबंध को बनाए रखना चाहिए
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कॉल करने वाले को `atomic_nand`. के सुरक्षा अनुबंध को बनाए रखना चाहिए
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कॉल करने वाले को `atomic_or`. के सुरक्षा अनुबंध को बनाए रखना चाहिए
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कॉल करने वाले को `atomic_xor`. के सुरक्षा अनुबंध को बनाए रखना चाहिए
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// अधिकतम मान लौटाता है (हस्ताक्षरित तुलना)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कॉल करने वाले को `atomic_max`. के सुरक्षा अनुबंध को बनाए रखना चाहिए
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// न्यूनतम मान लौटाता है (हस्ताक्षरित तुलना)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कॉल करने वाले को `atomic_min`. के सुरक्षा अनुबंध को बनाए रखना चाहिए
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// अधिकतम मान लौटाता है (अहस्ताक्षरित तुलना)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कॉल करने वाले को `atomic_umax`. के सुरक्षा अनुबंध को बनाए रखना चाहिए
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// न्यूनतम मान लौटाता है (अहस्ताक्षरित तुलना)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कॉल करने वाले को `atomic_umin`. के सुरक्षा अनुबंध को बनाए रखना चाहिए
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// एक परमाणु बाड़।
///
/// निर्दिष्ट क्रम के आधार पर, एक बाड़ संकलक और सीपीयू को इसके चारों ओर कुछ प्रकार के मेमोरी संचालन को पुन: व्यवस्थित करने से रोकता है।
/// यह सिंक्रोनाइज़ करता है-इसके और परमाणु संचालन या अन्य धागों में बाड़ के बीच संबंध बनाता है।
///
/// एक बाड़ 'A' जिसमें (कम से कम) [`Release`] ऑर्डरिंग सेमेन्टिक्स है, एक बाड़ 'B' के साथ (कम से कम) [`Acquire`] सेमेन्टिक्स के साथ सिंक्रनाइज़ करता है, यदि और केवल तभी ऑपरेशन एक्स और वाई मौजूद हैं, दोनों कुछ परमाणु वस्तु 'M' पर काम कर रहे हैं जैसे कि ए पहले अनुक्रमित X, Y को B से पहले सिंक्रोनाइज़ किया जाता है और Y M में परिवर्तन को देखता है।
/// यह ए और बी के बीच होने से पहले की निर्भरता प्रदान करता है।
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] या [`Acquire`] शब्दार्थ के साथ परमाणु संचालन भी एक बाड़ के साथ सिंक्रनाइज़ कर सकते हैं।
///
/// एक बाड़ जिसमें [`SeqCst`] ऑर्डरिंग है, दोनों [`Acquire`] और [`Release`] शब्दार्थ होने के अलावा, अन्य [`SeqCst`] संचालन और/या बाड़ के वैश्विक कार्यक्रम क्रम में भाग लेता है।
///
/// [`Acquire`], [`Release`], [`AcqRel`] और [`SeqCst`] ऑर्डरिंग स्वीकार करता है।
///
/// # Panics
///
/// Panics अगर `order` [`Relaxed`] है।
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // स्पिनलॉक पर आधारित एक पारस्परिक बहिष्करण आदिम।
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // पुराना मान `false` होने तक प्रतीक्षा करें।
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // यह बाड़ `unlock` में स्टोर के साथ सिंक्रोनाइज़ करती है।
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // सुरक्षा: परमाणु बाड़ का उपयोग करना सुरक्षित है।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// एक कंपाइलर मेमोरी बाड़।
///
/// `compiler_fence` किसी भी मशीन कोड का उत्सर्जन नहीं करता है, लेकिन मेमोरी के प्रकार को प्रतिबंधित करता है जो कंपाइलर को करने की अनुमति देता है।विशेष रूप से, दिए गए [`Ordering`] सेमेन्टिक्स के आधार पर, कंपाइलर को कॉल के पहले या बाद में `compiler_fence` पर कॉल के दूसरी तरफ पढ़ने या लिखने की अनुमति नहीं दी जा सकती है।ध्यान दें कि यह *हार्डवेयर* को ऐसे री-ऑर्डर करने से **नहीं** रोकता है।
///
/// यह एकल-थ्रेडेड, निष्पादन संदर्भ में कोई समस्या नहीं है, लेकिन जब अन्य थ्रेड एक ही समय में मेमोरी को संशोधित कर सकते हैं, तो [`fence`] जैसे मजबूत सिंक्रनाइज़ेशन प्राइमेटिव की आवश्यकता होती है।
///
/// अलग-अलग ऑर्डरिंग सेमेन्टिक्स द्वारा रोके गए पुन: आदेश हैं:
///
///  - [`SeqCst`] के साथ, इस बिंदु पर पढ़ने और लिखने के पुन: क्रम की अनुमति नहीं है।
///  - [`Release`] के साथ, पिछले पढ़ने और लिखने को बाद के लिखने से पहले स्थानांतरित नहीं किया जा सकता है।
///  - [`Acquire`] के साथ, बाद के पढ़ने और लिखने को पिछले पढ़ने से आगे नहीं ले जाया जा सकता है।
///  - [`AcqRel`] के साथ, उपरोक्त दोनों नियम लागू होते हैं।
///
/// `compiler_fence` आम तौर पर केवल एक धागे को *स्वयं के साथ* दौड़ने से रोकने के लिए उपयोगी होता है।यही है, यदि कोई दिया गया धागा कोड के एक टुकड़े को निष्पादित कर रहा है, और फिर बाधित हो जाता है, और कहीं और कोड निष्पादित करना शुरू कर देता है (जबकि अभी भी उसी धागे में, और अवधारणात्मक रूप से अभी भी एक ही कोर पर)।पारंपरिक कार्यक्रमों में, यह केवल तभी हो सकता है जब सिग्नल हैंडलर पंजीकृत हो।
/// अधिक निम्न-स्तरीय कोड में, इंटरप्ट को संभालने, पूर्व-उत्सर्जन के साथ हरे रंग के धागे को लागू करते समय ऐसी स्थितियां भी उत्पन्न हो सकती हैं।
/// जिज्ञासु पाठकों को Linux कर्नेल की [memory barriers] की चर्चा पढ़ने के लिए प्रोत्साहित किया जाता है।
///
/// # Panics
///
/// Panics अगर `order` [`Relaxed`] है।
///
/// # Examples
///
/// `compiler_fence` के बिना, निम्नलिखित कोड में `assert_eq!` सफल होने की गारंटी *नहीं* है, सब कुछ एक ही धागे में होने के बावजूद।
/// यह देखने के लिए, याद रखें कि कंपाइलर स्टोर को `IMPORTANT_VARIABLE` और `IS_READ` में स्वैप करने के लिए स्वतंत्र है क्योंकि वे दोनों `Ordering::Relaxed` हैं।यदि ऐसा होता है, और `IS_READY` अपडेट होने के ठीक बाद सिग्नल हैंडलर को लागू किया जाता है, तो सिग्नल हैंडलर `IS_READY=1`, लेकिन `IMPORTANT_VARIABLE=0` को देखेगा।
/// `compiler_fence` का उपयोग करने से यह स्थिति ठीक हो जाती है।
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // पहले के लेखन को इस बिंदु से आगे ले जाने से रोकें
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // सुरक्षा: परमाणु बाड़ का उपयोग करना सुरक्षित है।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// प्रोसेसर को संकेत देता है कि यह एक व्यस्त-प्रतीक्षा स्पिन-लूप ("स्पिन लॉक") के अंदर है।
///
/// यह फ़ंक्शन [`hint::spin_loop`] के पक्ष में बहिष्कृत है।
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}