#![stable(feature = "duration_core", since = "1.25.0")]

//! अस्थायी परिमाणीकरण।
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // दोनों घोषणाएं बराबर हैं
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// समय की अवधि का प्रतिनिधित्व करने के लिए एक `Duration` प्रकार, आमतौर पर सिस्टम टाइमआउट के लिए उपयोग किया जाता है।
///
/// प्रत्येक `Duration` सेकंड की एक पूरी संख्या और नैनोसेकंड में दर्शाए गए एक भिन्नात्मक भाग से बना होता है।
/// यदि अंतर्निहित सिस्टम नैनोसेकंड-स्तर की सटीकता का समर्थन नहीं करता है, तो सिस्टम टाइमआउट को बाध्य करने वाले एपीआई आमतौर पर नैनोसेकंड की संख्या को पूरा करेंगे।
///
/// [`Duration`] [`Add`], [`Sub`], और अन्य [`ops`] traits सहित कई सामान्य traits लागू करते हैं।यह शून्य-लंबाई `Duration` लौटाकर [`Default`] लागू करता है।
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # `Duration` मानों को स्वरूपित करना
///
/// `Duration` जानबूझकर एक `Display` इम्प्लांट नहीं है, क्योंकि मानव पठनीयता के लिए समय की अवधि को प्रारूपित करने के कई तरीके हैं।
/// `Duration` एक `Debug` impl प्रदान करता है जो मान की पूर्ण सटीकता दिखाता है।
///
/// `Debug` आउटपुट माइक्रोसेकंड के लिए गैर-ASCII "µs" प्रत्यय का उपयोग करता है।
/// यदि आपका प्रोग्राम आउटपुट ऐसे संदर्भों में प्रकट हो सकता है जो पूर्ण यूनिकोड संगतता पर भरोसा नहीं कर सकते हैं, तो आप स्वयं `Duration` ऑब्जेक्ट्स को प्रारूपित करना चाहेंगे या ऐसा करने के लिए crate का उपयोग कर सकते हैं।
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // हमेशा 0 <=नैनो < NANOS_PER_SEC
}

impl Duration {
    /// एक सेकंड की अवधि।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// एक मिलीसेकंड की अवधि।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// एक माइक्रोसेकंड की अवधि।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// एक नैनोसेकंड की अवधि।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// शून्य समय की अवधि।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// अधिकतम अवधि।
    ///
    /// यह मोटे तौर पर 584,942,417,355 वर्षों की अवधि के बराबर है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// पूरे सेकंड और अतिरिक्त नैनोसेकंड की निर्दिष्ट संख्या से एक नया `Duration` बनाता है।
    ///
    /// यदि नैनोसेकंड की संख्या 1 बिलियन (एक सेकंड में नैनोसेकंड की संख्या) से अधिक है, तो यह प्रदान किए गए सेकंड में आगे बढ़ जाएगा।
    ///
    ///
    /// # Panics
    ///
    /// यह कंस्ट्रक्टर panic करेगा यदि नैनोसेकंड से कैरी सेकंड काउंटर को ओवरफ्लो करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// पूरे सेकंड की निर्दिष्ट संख्या से एक नया `Duration` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// मिलीसेकंड की निर्दिष्ट संख्या से एक नया `Duration` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// माइक्रोसेकंड की निर्दिष्ट संख्या से एक नया `Duration` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// नैनोसेकंड की निर्दिष्ट संख्या से एक नया `Duration` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// यदि यह `Duration` बिना समय के फैलता है तो सत्य वापस आ जाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// इस `Duration` द्वारा निहित _whole_ सेकंड की संख्या लौटाता है।
    ///
    /// लौटाए गए मान में अवधि का भिन्नात्मक (nanosecond) भाग शामिल नहीं है, जिसे [`subsec_nanos`] का उपयोग करके प्राप्त किया जा सकता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// `Duration` द्वारा दर्शाए गए सेकंड की कुल संख्या निर्धारित करने के लिए, `as_secs` के साथ संयोजन में `as_secs` का उपयोग करें:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// इस `Duration` के भिन्नात्मक भाग को पूरे मिलीसेकंड में लौटाता है।
    ///
    /// मिलीसेकंड द्वारा दर्शाए जाने पर यह विधि अवधि की लंबाई **नहीं** लौटाती है।
    /// लौटाई गई संख्या हमेशा एक सेकंड के भिन्नात्मक हिस्से का प्रतिनिधित्व करती है (यानी, यह एक हजार से कम है)।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// इस `Duration` के भिन्नात्मक भाग को संपूर्ण माइक्रोसेकंड में लौटाता है।
    ///
    /// यह विधि माइक्रोसेकंड द्वारा दर्शाए जाने पर अवधि की लंबाई **नहीं** लौटाती है।
    /// लौटाई गई संख्या हमेशा एक सेकंड के भिन्नात्मक हिस्से का प्रतिनिधित्व करती है (यानी, यह एक मिलियन से कम है)।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// इस `Duration` के भिन्नात्मक भाग को नैनोसेकंड में लौटाता है।
    ///
    /// नैनोसेकंड द्वारा दर्शाए जाने पर यह विधि अवधि की लंबाई **नहीं** लौटाती है।
    /// लौटाई गई संख्या हमेशा एक सेकंड के भिन्नात्मक हिस्से का प्रतिनिधित्व करती है (यानी, यह एक अरब से कम है)।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// इस `Duration` में निहित संपूर्ण मिलीसेकंड की कुल संख्या लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// इस `Duration` में निहित संपूर्ण माइक्रोसेकंड की कुल संख्या लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// इस `Duration` में निहित नैनोसेकंड की कुल संख्या लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// `Duration` जोड़ की जाँच की।
    /// `self + other` की गणना करता है, अतिप्रवाह होने पर [`None`] लौटाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// संतृप्त `Duration` जोड़।
    /// `self + other` की गणना करता है, अतिप्रवाह होने पर [`Duration::MAX`] लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` घटाव की जाँच की।
    /// `self - other` की गणना करता है, यदि परिणाम नकारात्मक होगा या अतिप्रवाह हुआ तो [`None`] लौटाएगा।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// संतृप्त `Duration` घटाव।
    /// `self - other` की गणना करता है, यदि परिणाम नकारात्मक होगा या अतिप्रवाह हुआ तो [`Duration::ZERO`] लौटाएगा।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// `Duration` गुणन की जाँच की।
    /// `self * other` की गणना करता है, अतिप्रवाह होने पर [`None`] लौटाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // नैनोसेकंड को u64 के रूप में गुणा करें, क्योंकि यह उस तरह से अतिप्रवाह नहीं हो सकता है।
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// संतृप्त `Duration` गुणन।
    /// `self * other` की गणना करता है, अतिप्रवाह होने पर [`Duration::MAX`] लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` डिवीजन की जाँच की।
    /// `self / other` की गणना करता है, यदि `other == 0` [`None`] लौटाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// इस `Duration` द्वारा निहित सेकंड की संख्या को `f64` के रूप में लौटाता है।
    /// लौटाए गए मान में अवधि का भिन्नात्मक (nanosecond) भाग शामिल होता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// इस `Duration` द्वारा निहित सेकंड की संख्या को `f32` के रूप में लौटाता है।
    /// लौटाए गए मान में अवधि का भिन्नात्मक (nanosecond) भाग शामिल होता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// `f64` के रूप में दर्शाए गए सेकंड की निर्दिष्ट संख्या से एक नया `Duration` बनाता है।
    ///
    /// # Panics
    /// यह कंस्ट्रक्टर panic करेगा यदि `secs` परिमित, ऋणात्मक या अतिप्रवाह `Duration` नहीं है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f32` के रूप में दर्शाए गए सेकंड की निर्दिष्ट संख्या से एक नया `Duration` बनाता है।
    ///
    /// # Panics
    /// यह कंस्ट्रक्टर panic करेगा यदि `secs` परिमित, ऋणात्मक या अतिप्रवाह `Duration` नहीं है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `Duration` को `f64` से गुणा करता है।
    /// # Panics
    /// यदि परिणाम परिमित, ऋणात्मक या अतिप्रवाह `Duration` नहीं है, तो यह विधि panic होगी।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// `Duration` को `f32` से गुणा करता है।
    /// # Panics
    /// यदि परिणाम परिमित, ऋणात्मक या अतिप्रवाह `Duration` नहीं है, तो यह विधि panic होगी।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // ध्यान दें कि गोलाई त्रुटियों के कारण परिणाम 8.478 और 847800.0 से थोड़ा अलग है
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// `Duration` को `f64` से विभाजित करें।
    /// # Panics
    /// यदि परिणाम परिमित, ऋणात्मक या अतिप्रवाह `Duration` नहीं है, तो यह विधि panic होगी।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // ध्यान दें कि ट्रंकेशन का उपयोग किया जाता है, गोलाई में नहीं
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// `Duration` को `f32` से विभाजित करें।
    /// # Panics
    /// यदि परिणाम परिमित, ऋणात्मक या अतिप्रवाह `Duration` नहीं है, तो यह विधि panic होगी।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // ध्यान दें कि गोलाई त्रुटियों के कारण परिणाम 0.859_872_611. से थोड़ा अलग है
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // ध्यान दें कि ट्रंकेशन का उपयोग किया जाता है, गोलाई में नहीं
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// `Duration` को `Duration` से विभाजित करें और `f64` लौटाएं।
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// `Duration` को `Duration` से विभाजित करें और `f32` लौटाएं।
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// दशमलव संकेतन में एक फ्लोटिंग पॉइंट नंबर को प्रारूपित करता है।
        ///
        /// संख्या को `integer_part` और भिन्नात्मक भाग के रूप में दिया गया है।
        /// भिन्नात्मक भाग का मान `fractional_part / divisor` है।
        /// तो `integer_part` =3, `fractional_part` =12 और `divisor` =100 संख्या `3.012` को दर्शाता है।
        /// अनुगामी शून्य छोड़े गए हैं।
        ///
        /// `divisor` 100_000_000 से ऊपर नहीं होना चाहिए।
        /// यह भी 10 की शक्ति होनी चाहिए, बाकी सब कुछ समझ में नहीं आता है।
        /// `fractional_part` `10 * divisor` से कम होना चाहिए!
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // आंशिक भाग को अस्थायी बफर में एन्कोड करें।
            // बफ़र को केवल 9 तत्वों को रखने की आवश्यकता है, क्योंकि `fractional_part` को 10^9 से छोटा होना चाहिए।
            //
            // नीचे दिए गए कोड को सरल बनाने के लिए बफ़र '0' अंकों से पहले से भरा हुआ है।
            let mut buf = [b'0'; 9];

            // इस स्थान पर अगला अंक लिखा जाता है
            let mut pos = 0;

            // हम बफ़र में अंक लिखते रहते हैं जबकि गैर-शून्य अंक शेष हैं और हमने अभी तक पर्याप्त अंक नहीं लिखे हैं।
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // बफ़र में नया अंक लिखें
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // यदि एक सटीक <9 निर्दिष्ट किया गया था, तो कुछ गैर-शून्य अंक शेष हो सकते हैं जो बफर में नहीं लिखे गए थे।
            // उस स्थिति में हमें सामान्य फ्लोटिंग पॉइंट नंबरों को प्रिंट करने के शब्दार्थ से मेल खाने के लिए राउंडिंग करने की आवश्यकता होती है।
            // हालांकि, राउंड अप करते समय हमें केवल काम करने की आवश्यकता होती है।
            // ऐसा तब होता है जब शेष का पहला अंक>=5 हो।
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // बफ़र में निहित संख्या को गोल करें।
                // हम बफर से पीछे की ओर जाते हैं और कैरी का ट्रैक रखते हैं।
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // यदि बफ़र में अंक '9' नहीं है, तो हमें बस इसे बढ़ाने की आवश्यकता है और तब रुक सकते हैं (चूंकि हमारे पास अब कोई कैरी नहीं है)।
                    // अन्यथा, हम इसे '0' (overflow) पर सेट करते हैं और जारी रखते हैं।
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // यदि हमारे पास अभी भी कैरी बिट सेट है, तो इसका मतलब है कि हम पूरे बफर को '0' पर सेट करते हैं और पूर्णांक भाग को बढ़ाने की आवश्यकता होती है।
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // बफ़र के अंत का निर्धारण करें: यदि सटीक सेट किया गया है, तो हम बफ़र से उतने अंकों का उपयोग करते हैं (9 तक सीमित)।
            // यदि यह सेट नहीं है, तो हम केवल अंतिम गैर-शून्य तक के सभी अंकों का उपयोग करते हैं।
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // यदि हमने एक भी भिन्नात्मक अंक उत्सर्जित नहीं किया है और परिशुद्धता को गैर-शून्य मान पर सेट नहीं किया गया है, तो हम दशमलव बिंदु को प्रिंट नहीं करते हैं।
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // सुरक्षा: हम केवल ASCII अंक बफ़र में लिख रहे हैं और यह था
                // '0' के साथ आरंभ किया गया है, इसलिए इसमें वैध UTF8 है।
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // यदि उपयोगकर्ता एक सटीक> 9 का अनुरोध करता है, तो हम अंत में '0' पैड करते हैं।
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // अनुरोध किए जाने पर अग्रणी '+' चिह्न प्रिंट करें
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}