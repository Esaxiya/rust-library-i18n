#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! अंतर्निहित प्रकार के कंपाइलर के लेआउट के लिए संरचना परिभाषाएं शामिल हैं।
//!
//! उन्हें सीधे कच्चे अभ्यावेदन में हेरफेर करने के लिए असुरक्षित कोड में ट्रांसम्यूट के लक्ष्य के रूप में इस्तेमाल किया जा सकता है।
//!
//!
//! उनकी परिभाषा हमेशा `rustc_middle::ty::layout` में परिभाषित ABI से मेल खानी चाहिए।
//!

/// `&dyn SomeTrait` जैसे trait ऑब्जेक्ट का प्रतिनिधित्व।
///
/// इस संरचना का लेआउट `&dyn SomeTrait` और `Box<dyn AnotherTrait>` जैसे प्रकारों के समान है।
///
/// `TraitObject` लेआउट से मेल खाने की गारंटी है, लेकिन यह trait ऑब्जेक्ट्स का प्रकार नहीं है (उदाहरण के लिए, फ़ील्ड `&dyn SomeTrait` पर सीधे पहुंच योग्य नहीं हैं) और न ही यह उस लेआउट को नियंत्रित करता है (परिभाषा बदलने से `&dyn SomeTrait` का लेआउट नहीं बदलेगा)।
///
/// इसे केवल असुरक्षित कोड द्वारा उपयोग करने के लिए डिज़ाइन किया गया है जिसे निम्न-स्तरीय विवरणों में हेरफेर करने की आवश्यकता है।
///
/// सभी trait ऑब्जेक्ट्स को सामान्य रूप से संदर्भित करने का कोई तरीका नहीं है, इसलिए इस प्रकार के मान बनाने का एकमात्र तरीका [`std::mem::transmute`][transmute] जैसे फ़ंक्शन के साथ है।
/// इसी तरह, `TraitObject` मान से एक वास्तविक trait ऑब्जेक्ट बनाने का एकमात्र तरीका `transmute` है।
///
/// [transmute]: crate::intrinsics::transmute
///
/// एक trait ऑब्जेक्ट को बेमेल प्रकारों के साथ संश्लेषित करना-एक जहां vtable उस मान के प्रकार के अनुरूप नहीं है जिस पर डेटा पॉइंटर इंगित करता है-अपरिभाषित व्यवहार की ओर ले जाने की अत्यधिक संभावना है।
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // एक उदाहरण trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // कंपाइलर को trait ऑब्जेक्ट बनाने दें
/// let object: &dyn Foo = &value;
///
/// // कच्चे प्रतिनिधित्व को देखो
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // डेटा पॉइंटर `value` का पता है
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // `object` से `i32` vtable का उपयोग करने के लिए सावधान रहते हुए, एक अलग `i32` की ओर इशारा करते हुए एक नई वस्तु का निर्माण करें
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // इसे वैसे ही काम करना चाहिए जैसे हमने सीधे `other_value` से trait ऑब्जेक्ट बनाया था
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}