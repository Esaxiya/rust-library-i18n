/// `?` ऑपरेटर के व्यवहार को अनुकूलित करने के लिए trait।
///
/// `Try` को लागू करने वाला एक प्रकार वह है जिसमें success/failure द्विभाजन के संदर्भ में इसे देखने का एक विहित तरीका है।
/// यह trait उन सफलता या विफलता मानों को मौजूदा उदाहरण से निकालने और सफलता या विफलता मान से एक नया उदाहरण बनाने की अनुमति देता है।
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// सफल के रूप में देखे जाने पर इस मान का प्रकार।
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// विफल के रूप में देखे जाने पर इस मान का प्रकार।
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" ऑपरेटर लागू करता है।`Ok(t)` की वापसी का अर्थ है कि निष्पादन सामान्य रूप से जारी रहना चाहिए, और `?` का परिणाम मान `t` है।
    /// `Err(e)` की वापसी का मतलब है कि निष्पादन branch को आंतरिकतम संलग्न `catch` पर होना चाहिए, या फ़ंक्शन से वापस आना चाहिए।
    ///
    /// यदि कोई `Err(e)` परिणाम लौटाया जाता है, तो संलग्न क्षेत्र के रिटर्न प्रकार में `e` का मान "wrapped" होगा (जिसे स्वयं `Try` लागू करना होगा)।
    ///
    /// विशेष रूप से, मान `X::from_error(From::from(e))` लौटाया जाता है, जहाँ `X` संलग्न कार्य का रिटर्न प्रकार है।
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// समग्र परिणाम बनाने के लिए एक त्रुटि मान लपेटें।
    /// उदाहरण के लिए, `Result::Err(x)` और `Result::from_error(x)` समतुल्य हैं।
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// समग्र परिणाम बनाने के लिए ठीक मान लपेटें।
    /// उदाहरण के लिए, `Result::Ok(x)` और `Result::from_ok(x)` समतुल्य हैं।
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}