/// अपरिवर्तनीय संदर्भों में अनुक्रमण संचालन (`container[index]`) के लिए उपयोग किया जाता है।
///
/// `container[index]` वास्तव में `*container.index(index)` के लिए वाक्यात्मक चीनी है, लेकिन केवल जब एक अपरिवर्तनीय मूल्य के रूप में उपयोग किया जाता है।
/// यदि एक परिवर्तनीय मान का अनुरोध किया जाता है, तो इसके बजाय [`IndexMut`] का उपयोग किया जाता है।
/// यह `let value = v[index]` जैसी अच्छी चीजों की अनुमति देता है यदि `value` का प्रकार [`Copy`] लागू करता है।
///
/// # Examples
///
/// निम्न उदाहरण `Index` को केवल-पढ़ने के लिए `NucleotideCount` कंटेनर पर लागू करता है, जिससे इंडेक्स सिंटैक्स के साथ अलग-अलग गणनाओं को पुनर्प्राप्त किया जा सकता है।
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// अनुक्रमण के बाद लौटा हुआ प्रकार।
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// अनुक्रमण (`container[index]`) ऑपरेशन करता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// उत्परिवर्तनीय संदर्भों में अनुक्रमण संचालन (`container[index]`) के लिए उपयोग किया जाता है।
///
/// `container[index]` वास्तव में `*container.index_mut(index)` के लिए वाक्यात्मक चीनी है, लेकिन केवल तभी जब एक परिवर्तनीय मूल्य के रूप में उपयोग किया जाता है।
/// यदि एक अपरिवर्तनीय मान का अनुरोध किया जाता है, तो इसके बजाय [`Index`] trait का उपयोग किया जाता है।
/// यह `v[index] = value` जैसी अच्छी चीजों की अनुमति देता है।
///
/// # Examples
///
/// `Balance` संरचना का एक बहुत ही सरल कार्यान्वयन जिसमें दो पक्ष होते हैं, जहां प्रत्येक को परस्पर और अपरिवर्तनीय रूप से अनुक्रमित किया जा सकता है।
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // इस मामले में, `balance[Side::Right]`, `*balance.index(Side::Right)` के लिए चीनी है, क्योंकि हम केवल* पढ़ रहे हैं* `balance[Side::Right]`, इसे नहीं लिख रहे हैं।
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // हालाँकि, इस मामले में `balance[Side::Left]` `*balance.index_mut(Side::Left)` के लिए चीनी है, क्योंकि हम `balance[Side::Left]` लिख रहे हैं।
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// परिवर्तनीय अनुक्रमण (`container[index]`) ऑपरेशन करता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}