/// कॉल ऑपरेटर का संस्करण जो एक अपरिवर्तनीय रिसीवर लेता है।
///
/// राज्य को बदले बिना `Fn` के उदाहरणों को बार-बार कहा जा सकता है।
///
/// *इस trait (`Fn`) को [function pointers] (`fn`) के साथ भ्रमित नहीं होना है।*
///
/// `Fn` क्लोजर द्वारा स्वचालित रूप से कार्यान्वित किया जाता है जो केवल कैप्चर किए गए चर के लिए अपरिवर्तनीय संदर्भ लेते हैं या कुछ भी कैप्चर नहीं करते हैं, साथ ही साथ (safe) [function pointers] (कुछ चेतावनियों के साथ, अधिक विवरण के लिए उनके दस्तावेज़ देखें)।
///
/// इसके अतिरिक्त, किसी भी प्रकार के `F` के लिए जो `Fn` को लागू करता है, `&F` `Fn` को भी लागू करता है।
///
/// चूंकि [`FnMut`] और [`FnOnce`] दोनों ही `Fn` के सुपरट्रेट्स हैं, इसलिए `Fn` के किसी भी उदाहरण को एक पैरामीटर के रूप में इस्तेमाल किया जा सकता है जहां [`FnMut`] या [`FnOnce`] अपेक्षित है।
///
/// जब आप फ़ंक्शन-जैसे प्रकार के पैरामीटर को स्वीकार करना चाहते हैं तो `Fn` को बाध्य के रूप में उपयोग करें और इसे बार-बार कॉल करने की आवश्यकता होती है और राज्य को बिना किसी परिवर्तन के (उदाहरण के लिए, इसे समवर्ती रूप से कॉल करते समय)।
/// यदि आपको ऐसी सख्त आवश्यकताओं की आवश्यकता नहीं है, तो [`FnMut`] या [`FnOnce`] को सीमा के रूप में उपयोग करें।
///
/// इस विषय पर कुछ और जानकारी के लिए [chapter on closures in *The Rust Programming Language*][book] देखें।
///
/// `Fn` traits (उदाहरण के लिए) के लिए विशेष सिंटैक्स भी ध्यान देने योग्य है
/// `Fn(usize, bool) -> उपयोग')।इसके तकनीकी विवरण में रुचि रखने वाले [the relevant section in the *Rustonomicon*][nomicon] का उल्लेख कर सकते हैं।
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## बंद करने का आह्वान
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` पैरामीटर का उपयोग करना
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ताकि regex भरोसा कर सके कि `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// कॉल ऑपरेशन करता है।
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// कॉल ऑपरेटर का संस्करण जो एक परिवर्तनशील रिसीवर लेता है।
///
/// `FnMut` के उदाहरणों को बार-बार बुलाया जा सकता है और स्थिति को बदल सकता है।
///
/// `FnMut` क्लोजर द्वारा स्वचालित रूप से कार्यान्वित किया जाता है जो कैप्चर किए गए चर के साथ-साथ [`Fn`] को लागू करने वाले सभी प्रकार के परिवर्तनीय संदर्भ लेते हैं, उदाहरण के लिए, (safe) [function pointers] (चूंकि `FnMut` [`Fn`] का एक सुपरट्रेट है)।
/// इसके अतिरिक्त, किसी भी प्रकार के `F` के लिए जो `FnMut` को लागू करता है, `&mut F` `FnMut` को भी लागू करता है।
///
/// चूंकि [`FnOnce`] `FnMut` का एक सुपरट्रेट है, `FnMut` के किसी भी इंस्टेंस का उपयोग किया जा सकता है जहां [`FnOnce`] अपेक्षित है, और चूंकि [`Fn`] `FnMut` का एक सबट्रेट है, [`Fn`] के किसी भी इंस्टेंस का उपयोग किया जा सकता है जहां `FnMut` अपेक्षित है।
///
/// `FnMut` को बाउंड के रूप में उपयोग करें जब आप फ़ंक्शन-जैसे प्रकार के पैरामीटर को स्वीकार करना चाहते हैं और इसे बार-बार कॉल करने की आवश्यकता होती है, जबकि इसे स्थिति को बदलने की अनुमति मिलती है।
/// यदि आप नहीं चाहते कि पैरामीटर राज्य को परिवर्तित करे, तो [`Fn`] को बाउंड के रूप में उपयोग करें;यदि आपको इसे बार-बार कॉल करने की आवश्यकता नहीं है, तो [`FnOnce`] का उपयोग करें।
///
/// इस विषय पर कुछ और जानकारी के लिए [chapter on closures in *The Rust Programming Language*][book] देखें।
///
/// `Fn` traits (उदाहरण के लिए) के लिए विशेष सिंटैक्स भी ध्यान देने योग्य है
/// `Fn(usize, bool) -> उपयोग')।इसके तकनीकी विवरण में रुचि रखने वाले [the relevant section in the *Rustonomicon*][nomicon] का उल्लेख कर सकते हैं।
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## एक पारस्परिक रूप से कैप्चरिंग क्लोजर को कॉल करना
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` पैरामीटर का उपयोग करना
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ताकि regex भरोसा कर सके कि `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// कॉल ऑपरेशन करता है।
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// कॉल ऑपरेटर का वह संस्करण जो बाय-वैल्यू रिसीवर लेता है।
///
/// `FnOnce` के उदाहरणों को कॉल किया जा सकता है, लेकिन कई बार कॉल करने योग्य नहीं हो सकता है।इस वजह से, यदि केवल एक प्रकार के बारे में ज्ञात है कि यह `FnOnce` को लागू करता है, तो इसे केवल एक बार बुलाया जा सकता है।
///
/// `FnOnce` क्लोजर द्वारा स्वचालित रूप से कार्यान्वित किया जाता है जो कैप्चर किए गए चर का उपभोग कर सकता है, साथ ही साथ सभी प्रकार जो [`FnMut`] को लागू करते हैं, उदाहरण के लिए, (safe) [function pointers] (चूंकि `FnOnce` [`FnMut`] का एक सुपरट्रेट है)।
///
///
/// चूंकि [`Fn`] और [`FnMut`] दोनों `FnOnce` के सबट्रेट्स हैं, [`Fn`] या [`FnMut`] के किसी भी इंस्टेंस का उपयोग किया जा सकता है जहां `FnOnce` अपेक्षित है।
///
/// जब आप फ़ंक्शन-जैसे प्रकार के पैरामीटर को स्वीकार करना चाहते हैं तो `FnOnce` को बाध्य के रूप में उपयोग करें और इसे केवल एक बार कॉल करने की आवश्यकता है।
/// यदि आपको बार-बार पैरामीटर को कॉल करने की आवश्यकता है, तो [`FnMut`] को बाउंड के रूप में उपयोग करें;यदि आपको राज्य को उत्परिवर्तित न करने की भी आवश्यकता है, तो [`Fn`] का उपयोग करें।
///
/// इस विषय पर कुछ और जानकारी के लिए [chapter on closures in *The Rust Programming Language*][book] देखें।
///
/// `Fn` traits (उदाहरण के लिए) के लिए विशेष सिंटैक्स भी ध्यान देने योग्य है
/// `Fn(usize, bool) -> उपयोग')।इसके तकनीकी विवरण में रुचि रखने वाले [the relevant section in the *Rustonomicon*][nomicon] का उल्लेख कर सकते हैं।
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` पैरामीटर का उपयोग करना
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` अपने कैप्चर किए गए चर का उपभोग करता है, इसलिए इसे एक से अधिक बार नहीं चलाया जा सकता है।
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()` को फिर से आमंत्रित करने का प्रयास `func` के लिए `use of moved value` त्रुटि देगा।
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` अब इस बिंदु पर लागू नहीं किया जा सकता
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ताकि regex भरोसा कर सके कि `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// कॉल ऑपरेटर के उपयोग के बाद लौटा हुआ प्रकार।
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// कॉल ऑपरेशन करता है।
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}