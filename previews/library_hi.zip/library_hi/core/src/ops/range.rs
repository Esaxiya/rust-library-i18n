use crate::fmt;
use crate::hash::Hash;

/// एक असीमित रेंज (`..`)।
///
/// `RangeFull` मुख्य रूप से [slicing index] के रूप में उपयोग किया जाता है, इसका शॉर्टहैंड `..` है।
/// यह [`Iterator`] के रूप में काम नहीं कर सकता क्योंकि इसका कोई प्रारंभिक बिंदु नहीं है।
///
/// # Examples
///
/// `..` सिंटैक्स एक `RangeFull` है:
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// इसमें [`IntoIterator`] कार्यान्वयन नहीं है, इसलिए आप इसे सीधे `for` लूप में उपयोग नहीं कर सकते।
/// यह संकलित नहीं होगा:
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// [slicing index] के रूप में प्रयुक्त, `RangeFull` एक स्लाइस के रूप में पूर्ण सरणी उत्पन्न करता है।
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // यह `RangeFull`. है
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// एक (half-open) रेंज, विशेष रूप से (`start..end`) के नीचे और विशेष रूप से ऊपर की ओर सीमित है।
///
///
/// श्रेणी `start..end` में `start <= x < end` के साथ सभी मान शामिल हैं।
/// यह खाली है यदि `start >= end`.
///
/// # Examples
///
/// `start..end` सिंटैक्स एक `Range` है:
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // यह एक `Range`. है
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // कॉपी नहीं--देखें #27186
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// (inclusive) की निचली सीमा।
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// (exclusive) रेंज की ऊपरी सीमा।
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// यदि `item` श्रेणी में समाहित है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// यदि श्रेणी में कोई आइटम नहीं है तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// यदि दोनों ओर अतुलनीय है तो सीमा खाली है:
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// एक सीमा केवल (`start..`) के नीचे समावेशी रूप से सीमित है।
///
/// `RangeFrom` `start..` में `x >= start` के साथ सभी मान शामिल हैं।
///
/// *नोट*: [`Iterator`] कार्यान्वयन में अतिप्रवाह (जब निहित डेटा प्रकार अपनी संख्यात्मक सीमा तक पहुंच जाता है) को panic, रैप, या संतृप्त करने की अनुमति है।
/// यह व्यवहार [`Step`] trait के कार्यान्वयन द्वारा परिभाषित किया गया है।
/// आदिम पूर्णांकों के लिए, यह सामान्य नियमों का पालन करता है, और अतिप्रवाह जाँच प्रोफ़ाइल का सम्मान करता है (डिबग में panic, रिलीज़ में लपेटें)।
/// यह भी ध्यान दें कि अतिप्रवाह आपके अनुमान से पहले होता है: अतिप्रवाह `next` को कॉल में होता है जो अधिकतम मूल्य उत्पन्न करता है, क्योंकि सीमा को अगले मान को प्राप्त करने के लिए एक राज्य में सेट किया जाना चाहिए।
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// `start..` सिंटैक्स एक `RangeFrom` है:
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // यह एक `RangeFrom`. है
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // कॉपी नहीं--देखें #27186
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// (inclusive) की निचली सीमा।
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// यदि `item` श्रेणी में समाहित है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// एक सीमा केवल विशेष रूप से (`..end`) के ऊपर सीमित है।
///
/// `RangeTo` `..end` में `x < end` के साथ सभी मान शामिल हैं।
/// यह [`Iterator`] के रूप में काम नहीं कर सकता क्योंकि इसका कोई प्रारंभिक बिंदु नहीं है।
///
/// # Examples
///
/// `..end` सिंटैक्स एक `RangeTo` है:
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// इसमें [`IntoIterator`] कार्यान्वयन नहीं है, इसलिए आप इसे सीधे `for` लूप में उपयोग नहीं कर सकते।
/// यह संकलित नहीं होगा:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// जब [slicing index] के रूप में उपयोग किया जाता है, तो `RangeTo` `end` द्वारा इंगित सूचकांक से पहले सभी सरणी तत्वों का एक टुकड़ा तैयार करता है।
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // यह एक `RangeTo`. है
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// (exclusive) रेंज की ऊपरी सीमा।
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// यदि `item` श्रेणी में समाहित है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// (`start..=end`) के नीचे और ऊपर समावेशी रूप से परिबद्ध एक सीमा।
///
/// `RangeInclusive` `start..=end` में `x >= start` और `x <= end` के साथ सभी मान शामिल हैं।यह `start <= end` तक खाली है।
///
/// यह पुनरावर्तक [fused] है, लेकिन पुनरावृति समाप्त होने के बाद `start` और `end` के विशिष्ट मान **अनिर्दिष्ट** हैं, इसके अलावा [`.is_empty()`] `true` लौटाएगा जब कोई और मान उत्पन्न नहीं होगा।
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// `start..=end` सिंटैक्स एक `RangeInclusive` है:
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // यह एक `RangeInclusive`. है
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // कॉपी नहीं--देखें #27186
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // ध्यान दें कि future में प्रतिनिधित्व बदलने की अनुमति देने के लिए यहां फ़ील्ड सार्वजनिक नहीं हैं;विशेष रूप से, जबकि हम संभावित रूप से start/end को उजागर कर सकते हैं, (future/current) निजी क्षेत्रों को बदले बिना उन्हें संशोधित करने से गलत व्यवहार हो सकता है, इसलिए हम उस मोड का समर्थन नहीं करना चाहते हैं।
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // यह क्षेत्र है:
    //  - `false` निर्माण पर
    //  - `false` जब पुनरावृत्ति ने एक तत्व उत्पन्न किया है और पुनरावृत्त समाप्त नहीं हुआ है
    //  - `true` जब पुनरावृत्ति का उपयोग इटरेटर को समाप्त करने के लिए किया गया हो
    //
    // पार्टियलऑर्ड बाध्य या विशेषज्ञता के बिना पार्टियलएक और हैश का समर्थन करने के लिए यह आवश्यक है।
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// एक नई समावेशी श्रेणी बनाता है।`start..=end` लिखने के बराबर।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// (inclusive) श्रेणी की निचली सीमा लौटाता है।
    ///
    /// पुनरावृत्ति के लिए एक समावेशी श्रेणी का उपयोग करते समय, `start()` और [`end()`] के मान पुनरावृत्ति समाप्त होने के बाद अनिर्दिष्ट होते हैं।
    /// यह निर्धारित करने के लिए कि क्या समावेशी श्रेणी खाली है, `start() > end()` की तुलना करने के बजाय [`is_empty()`] पद्धति का उपयोग करें।
    ///
    /// Note: सीमा समाप्त होने के बाद पुनरावृत्त होने के बाद इस विधि द्वारा लौटाया गया मान निर्दिष्ट नहीं है।
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// (inclusive) श्रेणी की ऊपरी सीमा लौटाता है।
    ///
    /// पुनरावृत्ति के लिए एक समावेशी श्रेणी का उपयोग करते समय, [`start()`] और `end()` के मान पुनरावृत्ति समाप्त होने के बाद अनिर्दिष्ट होते हैं।
    /// यह निर्धारित करने के लिए कि क्या समावेशी श्रेणी खाली है, `start() > end()` की तुलना करने के बजाय [`is_empty()`] पद्धति का उपयोग करें।
    ///
    /// Note: सीमा समाप्त होने के बाद पुनरावृत्त होने के बाद इस विधि द्वारा लौटाया गया मान निर्दिष्ट नहीं है।
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// `RangeInclusive` को (निचली सीमा, ऊपरी (inclusive) बाध्य) में नष्ट कर देता है।
    ///
    /// Note: सीमा समाप्त होने के बाद पुनरावृत्त होने के बाद इस विधि द्वारा लौटाया गया मान निर्दिष्ट नहीं है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// `SliceIndex` कार्यान्वयन के लिए एक विशेष `Range` में कनवर्ट करता है।
    /// कॉलर `end == usize::MAX` से निपटने के लिए जिम्मेदार है।
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // यदि हम थके हुए नहीं हैं, तो हम केवल `start..end + 1` को स्लाइस करना चाहते हैं।
        // यदि हम थक गए हैं, तो `end + 1..end + 1` के साथ टुकड़ा करने से हमें एक खाली सीमा मिलती है जो अभी भी उस समापन बिंदु के लिए सीमा-जांच के अधीन है।
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// यदि `item` श्रेणी में समाहित है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// पुनरावृत्ति समाप्त होने के बाद यह विधि हमेशा `false` लौटाती है:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // सटीक फ़ील्ड मान यहां निर्दिष्ट नहीं हैं
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// यदि श्रेणी में कोई आइटम नहीं है तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// यदि दोनों ओर अतुलनीय है तो सीमा खाली है:
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// पुनरावृत्ति समाप्त होने के बाद यह विधि `true` लौटाती है:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // सटीक फ़ील्ड मान यहां निर्दिष्ट नहीं हैं
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// एक सीमा केवल (`..=end`) के ऊपर समावेशी रूप से सीमित है।
///
/// `RangeToInclusive` `..=end` में `x <= end` के साथ सभी मान शामिल हैं।
/// यह [`Iterator`] के रूप में काम नहीं कर सकता क्योंकि इसका कोई प्रारंभिक बिंदु नहीं है।
///
/// # Examples
///
/// `..=end` सिंटैक्स एक `RangeToInclusive` है:
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// इसमें [`IntoIterator`] कार्यान्वयन नहीं है, इसलिए आप इसे सीधे `for` लूप में उपयोग नहीं कर सकते।यह संकलित नहीं होगा:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// जब [slicing index] के रूप में उपयोग किया जाता है, तो `RangeToInclusive` सभी सरणी तत्वों का एक टुकड़ा तैयार करता है जिसमें `end` द्वारा इंगित सूचकांक शामिल होता है।
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // यह एक `RangeToInclusive`. है
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// सीमा की ऊपरी सीमा (inclusive) upper
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// यदि `item` श्रेणी में समाहित है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// रेंज टू इनक्लूसिव<Idx>से तात्पर्य नहीं कर सकता <RangeTo<Idx>> क्योंकि (..0).into() के साथ अंडरफ्लो संभव होगा
//

/// चाबियों की एक श्रृंखला का एक समापन बिंदु।
///
/// # Examples
///
/// `बाउंड` रेंज एंडपॉइंट हैं:
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// [`BTreeMap::range`] के तर्क के रूप में `बाउंड` के टपल का उपयोग करना।
/// ध्यान दें कि ज्यादातर मामलों में, इसके बजाय रेंज सिंटैक्स (`1..5`) का उपयोग करना बेहतर होता है।
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// एक समावेशी बाध्य।
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// एक अनन्य बाध्य।
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// एक अनंत समापन बिंदु।इंगित करता है कि इस दिशा में कोई बाध्यता नहीं है।
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// `&Bound<T>` से `Bound<&T>` में कनवर्ट करता है।
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// `&mut Bound<T>` से `Bound<&T>` में कनवर्ट करता है।
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// बाउंड की सामग्री को क्लोन करके `Bound<&T>` को `Bound<T>` में मैप करें।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` `..`, `a..`, `..b`, `..=c`, `d..e`, या `f..=g` जैसे रेंज सिंटैक्स द्वारा उत्पादित Rust के अंतर्निर्मित रेंज प्रकारों द्वारा कार्यान्वित किया जाता है।
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// इंडेक्स बाउंड प्रारंभ करें।
    ///
    /// प्रारंभ मान को `Bound` के रूप में लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// अंत सूचकांक बाध्य।
    ///
    /// अंतिम मान को `Bound` के रूप में लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// यदि `item` श्रेणी में समाहित है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// जोर दें!((3..5).contains(&4));
    /// assert!(!(3..5).contains(&2));
    ///
    /// जोर दें!((0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // जब इटरेटर समाप्त हो जाता है, तो हमारे पास आमतौर पर प्रारंभ==अंत होता है, लेकिन हम चाहते हैं कि सीमा खाली दिखाई दे, जिसमें कुछ भी न हो।
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}