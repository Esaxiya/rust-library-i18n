//! ओवरलोड करने योग्य ऑपरेटर।
//!
//! इन traits को लागू करने से आप कुछ ऑपरेटरों को अधिभारित कर सकते हैं।
//!
//! इनमें से कुछ traits prelude द्वारा आयात किए गए हैं, इसलिए वे प्रत्येक Rust प्रोग्राम में उपलब्ध हैं।केवल traits द्वारा समर्थित ऑपरेटरों को ओवरलोड किया जा सकता है।
//! उदाहरण के लिए, अतिरिक्त ऑपरेटर (`+`) को [`Add`] trait के माध्यम से ओवरलोड किया जा सकता है, लेकिन चूंकि असाइनमेंट ऑपरेटर (`=`) के पास trait का कोई समर्थन नहीं है, इसलिए इसके शब्दार्थ को ओवरलोड करने का कोई तरीका नहीं है।
//! इसके अतिरिक्त, यह मॉड्यूल नए ऑपरेटरों को बनाने के लिए कोई तंत्र प्रदान नहीं करता है।
//! यदि विशेषता रहित ओवरलोडिंग या कस्टम ऑपरेटरों की आवश्यकता है, तो आपको Rust के सिंटैक्स का विस्तार करने के लिए मैक्रोज़ या कंपाइलर प्लगइन्स की ओर देखना चाहिए।
//!
//! ऑपरेटर traits का कार्यान्वयन उनके संबंधित संदर्भों में उनके सामान्य अर्थों और [operator precedence] को ध्यान में रखते हुए आश्चर्यजनक होना चाहिए।
//! उदाहरण के लिए, [`Mul`] को लागू करते समय, ऑपरेशन में गुणन के लिए कुछ समानता होनी चाहिए (और सहयोगीता जैसे अपेक्षित गुण साझा करें)।
//!
//! ध्यान दें कि `&&` और `||` ऑपरेटर शॉर्ट-सर्किट, यानी, वे केवल अपने दूसरे ऑपरेंड का मूल्यांकन करते हैं यदि यह परिणाम में योगदान देता है।चूंकि यह व्यवहार traits द्वारा लागू करने योग्य नहीं है, इसलिए `&&` और `||` ओवरलोडेबल ऑपरेटरों के रूप में समर्थित नहीं हैं।
//!
//! कई ऑपरेटर अपने ऑपरेंड को मूल्य के आधार पर लेते हैं।गैर-सामान्य संदर्भों में अंतर्निर्मित प्रकार शामिल हैं, यह आमतौर पर कोई समस्या नहीं है।
//! हालांकि, जेनेरिक कोड में इन ऑपरेटरों का उपयोग करने पर, कुछ ध्यान देने की आवश्यकता होती है यदि ऑपरेटरों को उनका उपभोग करने देने के विपरीत मूल्यों का पुन: उपयोग किया जाना है।एक विकल्प कभी-कभी [`clone`] का उपयोग करना है।
//! एक अन्य विकल्प संदर्भ के लिए अतिरिक्त ऑपरेटर कार्यान्वयन प्रदान करने वाले प्रकारों पर भरोसा करना है।
//! उदाहरण के लिए, एक उपयोगकर्ता-परिभाषित प्रकार `T` के लिए, जो अतिरिक्त का समर्थन करने वाला माना जाता है, संभवतः यह एक अच्छा विचार है कि `T` और `&T` दोनों traits [`Add<T>`][`Add`] और [`Add<&T>`][`Add`] को लागू करें ताकि जेनेरिक कोड अनावश्यक क्लोनिंग के बिना लिखा जा सके।
//!
//!
//! # Examples
//!
//! यह उदाहरण एक `Point` संरचना बनाता है जो [`Add`] और [`Sub`] को लागू करता है, और फिर दो `प्वाइंट` को जोड़ने और घटाने को प्रदर्शित करता है।
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! उदाहरण कार्यान्वयन के लिए प्रत्येक trait के लिए दस्तावेज़ देखें।
//!
//! [`Fn`], [`FnMut`], और [`FnOnce`] traits उन प्रकारों द्वारा कार्यान्वित किए जाते हैं जिन्हें फ़ंक्शन की तरह लागू किया जा सकता है।ध्यान दें कि [`Fn`] `&self` लेता है, [`FnMut`] `&mut self` लेता है और [`FnOnce`] `self` लेता है।
//! ये तीन प्रकार के तरीकों से मेल खाते हैं जिन्हें एक उदाहरण पर लागू किया जा सकता है: कॉल-बाय-रेफरेंस, कॉल-बाय-म्यूटेबल-रेफरेंस, और कॉल-बाय-वैल्यू।
//! इन traits का सबसे आम उपयोग उच्च-स्तरीय कार्यों के लिए सीमा के रूप में कार्य करना है जो फ़ंक्शन या क्लोजर को तर्क के रूप में लेते हैं।
//!
//! एक [`Fn`] को एक पैरामीटर के रूप में लेना:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! एक [`FnMut`] को एक पैरामीटर के रूप में लेना:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! एक [`FnOnce`] को एक पैरामीटर के रूप में लेना:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` अपने कैप्चर किए गए चर का उपभोग करता है, इसलिए इसे एक से अधिक बार नहीं चलाया जा सकता है
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()` को फिर से आमंत्रित करने का प्रयास `func` के लिए `use of moved value` त्रुटि फेंक देगा
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` अब इस बिंदु पर लागू नहीं किया जा सकता
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;