use crate::marker::Unsize;

/// Trait जो इंगित करता है कि यह एक के लिए एक सूचक या एक रैपर है, जहां पॉइंटी पर अनसाइज़िंग किया जा सकता है।
///
/// अधिक जानकारी के लिए [DST coercion RFC][dst-coerce] और [the nomicon entry on coercion][nomicon-coerce] देखें।
///
/// बिल्टिन पॉइंटर प्रकारों के लिए, `T` के पॉइंटर्स `U` के लिए पॉइंटर्स के साथ जबरदस्ती करेंगे यदि `T: Unsize<U>` पतले पॉइंटर से फैट पॉइंटर में कनवर्ट करके।
///
/// कस्टम प्रकारों के लिए, यहां जबरदस्ती `Foo<T>` से `Foo<U>` पर दबाव डालकर काम करती है बशर्ते `CoerceUnsized<Foo<U>> for Foo<T>` का एक इम्प्लांट मौजूद हो।
/// ऐसा इम्प्लांट केवल तभी लिखा जा सकता है जब `Foo<T>` में केवल एक गैर-प्रेत डेटा फ़ील्ड हो जिसमें `T` शामिल हो।
/// यदि उस फ़ील्ड का प्रकार `Bar<T>` है, तो `CoerceUnsized<Bar<U>> for Bar<T>` का कार्यान्वयन मौजूद होना चाहिए।
/// ज़बरदस्ती `Bar<T>` फ़ील्ड को `Bar<U>` में ज़बरदस्ती करके और `Foo<T>` से शेष फ़ील्ड को भरकर `Foo<U>` बनाने का काम करेगा।
/// यह प्रभावी रूप से एक सूचक क्षेत्र तक पहुंच जाएगा और उस पर दबाव डालेगा।
///
/// आम तौर पर, स्मार्ट पॉइंटर्स के लिए आप `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` को लागू करेंगे, जिसमें वैकल्पिक `?Sized` `T` पर ही बाध्य होगा।
/// रैपर प्रकारों के लिए जो सीधे `T` जैसे `Cell<T>` और `RefCell<T>` को एम्बेड करते हैं, आप सीधे `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` को लागू कर सकते हैं।
///
/// यह `Cell<Box<T>>` जैसे प्रकार के दबावों को काम करने देगा।
///
/// [`Unsize`][unsize] उन प्रकारों को चिह्नित करने के लिए उपयोग किया जाता है जिन्हें पॉइंटर्स के पीछे डीएसटी के लिए मजबूर किया जा सकता है।यह संकलक द्वारा स्वचालित रूप से कार्यान्वित किया जाता है।
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut टी-> &mut यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut टी-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut टी-> *म्यूट यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut टी-> *स्थिरांक यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * स्थिरांक यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *म्यूट टी->* म्यूट यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *म्यूट टी->* कॉन्स्ट यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *कॉन्स्ट टी->* कॉन्स्ट यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// इसका उपयोग ऑब्जेक्ट सुरक्षा के लिए किया जाता है, यह जांचने के लिए कि किसी विधि के रिसीवर प्रकार को भेजा जा सकता है।
///
/// trait का एक उदाहरण कार्यान्वयन:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut टी-> &mut यू
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *कॉन्स्ट टी->* कॉन्स्ट यू
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *म्यूट टी->* म्यूट यू
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}