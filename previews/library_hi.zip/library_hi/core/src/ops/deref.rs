/// अपरिवर्तनीय dereferencing संचालन के लिए उपयोग किया जाता है, जैसे `*v`।
///
/// अपरिवर्तनीय संदर्भों में (unary) `*` ऑपरेटर के साथ स्पष्ट dereferencing संचालन के लिए उपयोग किए जाने के अलावा, `Deref` भी कई परिस्थितियों में संकलक द्वारा निहित रूप से उपयोग किया जाता है।
/// इस तंत्र को ['`Deref` coercion'][more] कहा जाता है।
/// परिवर्तनीय संदर्भों में, [`DerefMut`] का उपयोग किया जाता है।
///
/// स्मार्ट पॉइंटर्स के लिए `Deref` को लागू करना उनके पीछे के डेटा तक पहुंच को सुविधाजनक बनाता है, यही वजह है कि वे `Deref` को लागू करते हैं।
/// दूसरी ओर, `Deref` और [`DerefMut`] के संबंध में नियम विशेष रूप से स्मार्ट पॉइंटर्स को समायोजित करने के लिए डिज़ाइन किए गए थे।
/// इस वजह से, भ्रम से बचने के लिए **`Deref` को केवल स्मार्ट पॉइंटर्स** के लिए लागू किया जाना चाहिए।
///
/// इसी तरह के कारणों के लिए,**यह trait कभी विफल नहीं होना चाहिए**।जब `Deref` परोक्ष रूप से लागू किया जाता है, तो dereferencing के दौरान विफलता अत्यंत भ्रामक हो सकती है।
///
/// # `Deref` जबरदस्ती पर अधिक
///
/// यदि `T` `Deref<Target = U>` लागू करता है, और `x` `T` प्रकार का मान है, तो:
///
/// * अपरिवर्तनीय संदर्भों में, `*x` (जहां `T` न तो एक संदर्भ है और न ही एक कच्चा सूचक है) `* Deref::deref(&x)` के बराबर है।
/// * `&T` प्रकार के मान `&U` प्रकार के मानों के साथ ज़बरदस्ती किए जाते हैं
/// * `T` `U` प्रकार की सभी (immutable) विधियों को परोक्ष रूप से लागू करता है।
///
/// अधिक विवरण के लिए, [the chapter in *The Rust Programming Language*][book] के साथ-साथ [the dereference operator][ref-deref-op], [method resolution] और [type coercions] पर संदर्भ अनुभाग देखें।
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// एक एकल क्षेत्र के साथ एक संरचना जो संरचना को संदर्भित करके पहुँचा जा सकता है।
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// dereferencing के बाद परिणामी प्रकार।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// मान का अवमानना करता है।
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;` की तरह म्यूटेबल डेरेफेरेंसिंग ऑपरेशंस के लिए उपयोग किया जाता है।
///
/// उत्परिवर्तित संदर्भों में (unary) `*` ऑपरेटर के साथ स्पष्ट dereferencing संचालन के लिए उपयोग किए जाने के अलावा, `DerefMut` भी कई परिस्थितियों में संकलक द्वारा निहित रूप से उपयोग किया जाता है।
/// इस तंत्र को ['`Deref` coercion'][more] कहा जाता है।
/// अपरिवर्तनीय संदर्भों में, [`Deref`] का उपयोग किया जाता है।
///
/// स्मार्ट पॉइंटर्स के लिए `DerefMut` को लागू करना उनके पीछे के डेटा को सुविधाजनक बनाता है, यही वजह है कि वे `DerefMut` को लागू करते हैं।
/// दूसरी ओर, [`Deref`] और `DerefMut` के संबंध में नियम विशेष रूप से स्मार्ट पॉइंटर्स को समायोजित करने के लिए डिज़ाइन किए गए थे।
/// इस वजह से, भ्रम से बचने के लिए **`DerefMut` को केवल स्मार्ट पॉइंटर्स के लिए लागू किया जाना चाहिए।
///
/// इसी तरह के कारणों से,**यह trait कभी विफल नहीं होना चाहिए**।जब `DerefMut` परोक्ष रूप से लागू किया जाता है, तो dereferencing के दौरान विफलता अत्यंत भ्रमित करने वाली हो सकती है।
///
/// # `Deref` जबरदस्ती पर अधिक
///
/// यदि `T` `DerefMut<Target = U>` लागू करता है, और `x` `T` प्रकार का मान है, तो:
///
/// * परिवर्तनीय संदर्भों में, `*x` (जहां `T` न तो एक संदर्भ है और न ही एक कच्चा सूचक है) `* DerefMut::deref_mut(&mut x)` के बराबर है।
/// * `&mut T` प्रकार के मान `&mut U` प्रकार के मानों के साथ ज़बरदस्ती किए जाते हैं
/// * `T` `U` प्रकार की सभी (mutable) विधियों को परोक्ष रूप से लागू करता है।
///
/// अधिक विवरण के लिए, [the chapter in *The Rust Programming Language*][book] के साथ-साथ [the dereference operator][ref-deref-op], [method resolution] और [type coercions] पर संदर्भ अनुभाग देखें।
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// एक एकल क्षेत्र के साथ एक संरचना जो संरचना को संदर्भित करके संशोधित किया जा सकता है।
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// मूल्य को परस्पर संदर्भित करता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// इंगित करता है कि एक संरचना को `arbitrary_self_types` सुविधा के बिना, एक विधि रिसीवर के रूप में उपयोग किया जा सकता है।
///
/// यह `Box<T>`, `Rc<T>`, `&T`, और `Pin<P>` जैसे stdlib पॉइंटर प्रकारों द्वारा कार्यान्वित किया जाता है।
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}