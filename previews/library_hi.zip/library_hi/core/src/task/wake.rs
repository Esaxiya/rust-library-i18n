#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// एक `RawWaker` एक कार्य निष्पादक के कार्यान्वयनकर्ता को एक [`Waker`] बनाने की अनुमति देता है जो अनुकूलित वेकअप व्यवहार प्रदान करता है।
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// इसमें एक डेटा पॉइंटर और एक [virtual function pointer table (vtable)][vtable] होता है जो `RawWaker` के व्यवहार को अनुकूलित करता है।
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// एक डेटा पॉइंटर, जिसका उपयोग निष्पादक द्वारा आवश्यकतानुसार मनमाना डेटा संग्रहीत करने के लिए किया जा सकता है।
    /// यह हो सकता है उदा
    /// कार्य के साथ संबद्ध `Arc` के लिए टाइप-मिटा हुआ सूचक।
    /// इस फ़ील्ड का मान उन सभी फ़ंक्शंस को पास हो जाता है जो पहले पैरामीटर के रूप में vtable का हिस्सा हैं।
    ///
    data: *const (),
    /// वर्चुअल फ़ंक्शन पॉइंटर टेबल जो इस वेकर के व्यवहार को अनुकूलित करती है।
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// प्रदान किए गए `data` पॉइंटर और `vtable` से एक नया `RawWaker` बनाता है।
    ///
    /// `data` पॉइंटर का उपयोग निष्पादक द्वारा आवश्यकतानुसार मनमाना डेटा संग्रहीत करने के लिए किया जा सकता है।यह हो सकता है उदा
    /// कार्य के साथ संबद्ध `Arc` के लिए टाइप-मिटा हुआ सूचक।
    /// इस पॉइंटर का मान पहले पैरामीटर के रूप में `vtable` के भाग वाले सभी कार्यों को पास हो जाएगा।
    ///
    /// `vtable` `Waker` के व्यवहार को अनुकूलित करता है जो `RawWaker` से बनता है।
    /// `Waker` पर प्रत्येक ऑपरेशन के लिए, अंतर्निहित `RawWaker` के `vtable` में संबंधित फ़ंक्शन को कॉल किया जाएगा।
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// एक वर्चुअल फ़ंक्शन पॉइंटर टेबल (vtable) जो [`RawWaker`] के व्यवहार को निर्दिष्ट करता है।
///
/// vtable के अंदर सभी कार्यों के लिए पास किया गया पॉइंटर संलग्न [`RawWaker`] ऑब्जेक्ट से `data` पॉइंटर है।
///
/// इस संरचना के अंदर के कार्यों को केवल [`RawWaker`] कार्यान्वयन के अंदर से ठीक से निर्मित [`RawWaker`] ऑब्जेक्ट के `data` पॉइंटर पर कॉल करने का इरादा है।
/// किसी अन्य `data` पॉइंटर का उपयोग करके निहित कार्यों में से एक को कॉल करने से अपरिभाषित व्यवहार होगा।
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// यह फ़ंक्शन तब कहा जाएगा जब [`RawWaker`] क्लोन हो जाएगा, उदाहरण के लिए जब [`Waker`] जिसमें [`RawWaker`] संग्रहीत है, क्लोन हो जाता है।
    ///
    /// इस फ़ंक्शन के कार्यान्वयन में उन सभी संसाधनों को बनाए रखना चाहिए जो [`RawWaker`] और संबंधित कार्य के इस अतिरिक्त उदाहरण के लिए आवश्यक हैं।
    /// परिणामी [`RawWaker`] पर `wake` को कॉल करने के परिणामस्वरूप उसी कार्य का वेकअप होना चाहिए जो मूल [`RawWaker`] द्वारा जागृत किया गया होता।
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// [`Waker`] पर `wake` को कॉल करने पर यह फ़ंक्शन कॉल किया जाएगा।
    /// इसे इस [`RawWaker`] से जुड़े कार्य को जगाना होगा।
    ///
    /// इस फ़ंक्शन के कार्यान्वयन को यह सुनिश्चित करना चाहिए कि [`RawWaker`] और संबंधित कार्य के इस उदाहरण से जुड़े किसी भी संसाधन को जारी किया जाए।
    ///
    ///
    wake: unsafe fn(*const ()),

    /// [`Waker`] पर `wake_by_ref` को कॉल करने पर यह फ़ंक्शन कॉल किया जाएगा।
    /// इसे इस [`RawWaker`] से जुड़े कार्य को जगाना होगा।
    ///
    /// यह फ़ंक्शन `wake` के समान है, लेकिन प्रदान किए गए डेटा पॉइंटर का उपभोग नहीं करना चाहिए।
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// [`RawWaker`] के गिराए जाने पर यह फ़ंक्शन कॉल किया जाता है।
    ///
    /// इस फ़ंक्शन के कार्यान्वयन को यह सुनिश्चित करना चाहिए कि [`RawWaker`] और संबंधित कार्य के इस उदाहरण से जुड़े किसी भी संसाधन को जारी किया जाए।
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// प्रदान किए गए `clone`, `wake`, `wake_by_ref` और `drop` फ़ंक्शन से एक नया `RawWakerVTable` बनाता है।
    ///
    /// # `clone`
    ///
    /// यह फ़ंक्शन तब कहा जाएगा जब [`RawWaker`] क्लोन हो जाएगा, उदाहरण के लिए जब [`Waker`] जिसमें [`RawWaker`] संग्रहीत है, क्लोन हो जाता है।
    ///
    /// इस फ़ंक्शन के कार्यान्वयन में उन सभी संसाधनों को बनाए रखना चाहिए जो [`RawWaker`] और संबंधित कार्य के इस अतिरिक्त उदाहरण के लिए आवश्यक हैं।
    /// परिणामी [`RawWaker`] पर `wake` को कॉल करने के परिणामस्वरूप उसी कार्य का वेकअप होना चाहिए जो मूल [`RawWaker`] द्वारा जागृत किया गया होता।
    ///
    /// # `wake`
    ///
    /// [`Waker`] पर `wake` को कॉल करने पर यह फ़ंक्शन कॉल किया जाएगा।
    /// इसे इस [`RawWaker`] से जुड़े कार्य को जगाना होगा।
    ///
    /// इस फ़ंक्शन के कार्यान्वयन को यह सुनिश्चित करना चाहिए कि [`RawWaker`] और संबंधित कार्य के इस उदाहरण से जुड़े किसी भी संसाधन को जारी किया जाए।
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// [`Waker`] पर `wake_by_ref` को कॉल करने पर यह फ़ंक्शन कॉल किया जाएगा।
    /// इसे इस [`RawWaker`] से जुड़े कार्य को जगाना होगा।
    ///
    /// यह फ़ंक्शन `wake` के समान है, लेकिन प्रदान किए गए डेटा पॉइंटर का उपभोग नहीं करना चाहिए।
    ///
    /// # `drop`
    ///
    /// [`RawWaker`] के गिराए जाने पर यह फ़ंक्शन कॉल किया जाता है।
    ///
    /// इस फ़ंक्शन के कार्यान्वयन को यह सुनिश्चित करना चाहिए कि [`RawWaker`] और संबंधित कार्य के इस उदाहरण से जुड़े किसी भी संसाधन को जारी किया जाए।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// एक अतुल्यकालिक कार्य का `Context`।
///
/// वर्तमान में, `Context` केवल `&Waker` तक पहुंच प्रदान करने का कार्य करता है जिसका उपयोग वर्तमान कार्य को जगाने के लिए किया जा सकता है।
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // सुनिश्चित करें कि हम future-प्रूफ जीवन भर को अपरिवर्तनीय होने के लिए मजबूर करके विचरण परिवर्तनों के खिलाफ हैं (तर्क-स्थिति जीवनकाल विरोधाभासी हैं जबकि वापसी-स्थिति जीवनकाल सहसंयोजक हैं)।
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// `&Waker` से एक नया `Context` बनाएं।
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// वर्तमान कार्य के लिए `Waker` का संदर्भ देता है।
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// एक `Waker` अपने निष्पादक को यह सूचित करके कार्य को जगाने के लिए एक हैंडल है कि यह चलाने के लिए तैयार है।
///
/// यह हैंडल एक [`RawWaker`] इंस्टेंस को इनकैप्सुलेट करता है, जो एक्ज़ीक्यूटर-विशिष्ट वेकअप व्यवहार को परिभाषित करता है।
///
///
/// [`Clone`], [`Send`], और [`Sync`] लागू करता है।
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// इस `Waker` से जुड़े कार्य को जगाएं।
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // वास्तविक वेकअप कॉल को एक वर्चुअल फ़ंक्शन कॉल के माध्यम से कार्यान्वयन के लिए प्रत्यायोजित किया जाता है जिसे निष्पादक द्वारा परिभाषित किया जाता है।
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` को कॉल न करें-वेकर का उपयोग `wake` द्वारा किया जाएगा।
        crate::mem::forget(self);

        // सुरक्षा: यह सुरक्षित है क्योंकि `Waker::from_raw` ही एकमात्र रास्ता है
        // `wake` और `data` को प्रारंभ करने के लिए उपयोगकर्ता को यह स्वीकार करने की आवश्यकता है कि `RawWaker` का अनुबंध बरकरार है।
        //
        unsafe { (wake)(data) };
    }

    /// `Waker` का उपभोग किए बिना इस `Waker` से जुड़े कार्य को जगाएं।
    ///
    /// यह `wake` के समान है, लेकिन उस स्थिति में थोड़ा कम कुशल हो सकता है जहां एक स्वामित्व वाला `Waker` उपलब्ध हो।
    /// `waker.clone().wake()` को कॉल करने के लिए इस विधि को प्राथमिकता दी जानी चाहिए।
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // वास्तविक वेकअप कॉल को एक वर्चुअल फ़ंक्शन कॉल के माध्यम से कार्यान्वयन के लिए प्रत्यायोजित किया जाता है जिसे निष्पादक द्वारा परिभाषित किया जाता है।
        //

        // सुरक्षा: `wake` देखें
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// यदि इस `Waker` और अन्य `Waker` ने समान कार्य को जगाया है तो `true` लौटाता है।
    ///
    /// यह फ़ंक्शन सर्वोत्तम-प्रयास के आधार पर काम करता है, और 'जागने वाला' उसी कार्य को जगाने पर भी झूठी वापसी कर सकता है।
    /// हालाँकि, यदि यह फ़ंक्शन `true` लौटाता है, तो यह गारंटी है कि `जागने वाला` उसी कार्य को जगाएगा।
    ///
    /// यह फ़ंक्शन मुख्य रूप से अनुकूलन उद्देश्यों के लिए उपयोग किया जाता है।
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`] से एक नया `Waker` बनाता है।
    ///
    /// यदि [`RawWaker`]'s और [`RawWakerVTable`] के दस्तावेज़ों में परिभाषित अनुबंध को बरकरार नहीं रखा जाता है, तो लौटाए गए `Waker` का व्यवहार अपरिभाषित है।
    ///
    /// इसलिए यह तरीका असुरक्षित है।
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // सुरक्षा: यह सुरक्षित है क्योंकि `Waker::from_raw` ही एकमात्र रास्ता है
            // `clone` और `data` को प्रारंभ करने के लिए उपयोगकर्ता को यह स्वीकार करने की आवश्यकता है कि [`RawWaker`] का अनुबंध बरकरार है।
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // सुरक्षा: यह सुरक्षित है क्योंकि `Waker::from_raw` ही एकमात्र रास्ता है
        // `drop` और `data` को प्रारंभ करने के लिए उपयोगकर्ता को यह स्वीकार करने की आवश्यकता है कि `RawWaker` का अनुबंध बरकरार है।
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}