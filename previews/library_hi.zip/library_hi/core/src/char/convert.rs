//! चरित्र रूपांतरण।

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` को `char` में कनवर्ट करता है।
///
/// ध्यान दें कि सभी [`char`] s मान्य [`u32`] s हैं, और इन्हें एक के साथ कास्ट किया जा सकता है
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// हालांकि, इसका उल्टा सच नहीं है: सभी मान्य [`u32`] s मान्य नहीं हैं [`char`] s.
/// `from_u32()` यदि इनपुट [`char`] के लिए मान्य मान नहीं है, तो `None` लौटाएगा।
///
/// इस फ़ंक्शन के असुरक्षित संस्करण के लिए जो इन जाँचों को अनदेखा करता है, [`from_u32_unchecked`] देखें।
///
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// जब इनपुट मान्य [`char`] न हो तो `None` लौटाना:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// वैधता को अनदेखा करते हुए `u32` को `char` में कनवर्ट करता है।
///
/// ध्यान दें कि सभी [`char`] s मान्य [`u32`] s हैं, और इन्हें एक के साथ कास्ट किया जा सकता है
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// हालांकि, इसका उल्टा सच नहीं है: सभी मान्य [`u32`] s मान्य नहीं हैं [`char`] s.
/// `from_u32_unchecked()` इसे अनदेखा कर देगा, और आँख बंद करके [`char`] पर डाल देगा, संभवतः एक अमान्य बना देगा।
///
///
/// # Safety
///
/// यह फ़ंक्शन असुरक्षित है, क्योंकि यह अमान्य `char` मान बना सकता है।
///
/// इस फ़ंक्शन के सुरक्षित संस्करण के लिए, [`from_u32`] फ़ंक्शन देखें।
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `i` एक वैध चार मान है।
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] को [`u32`] में कनवर्ट करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] को [`u64`] में कनवर्ट करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // चार को कोड बिंदु के मान पर डाला जाता है, फिर शून्य-विस्तारित 64 बिट तक।
        // देखें [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] को [`u128`] में कनवर्ट करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // चार को कोड बिंदु के मान पर डाला जाता है, फिर शून्य-विस्तारित 128 बिट तक।
        // देखें [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// एक बाइट को 0x00..=0xFF में एक `char` में मैप करता है जिसका कोड बिंदु U+0000..=U+00FF में समान मान रखता है।
///
/// यूनिकोड को इस तरह डिज़ाइन किया गया है कि यह प्रभावी रूप से वर्ण एन्कोडिंग के साथ बाइट्स को डिकोड करता है जिसे IANA ISO-8859-1 कहता है।
/// यह एन्कोडिंग ASCII के साथ संगत है।
///
/// ध्यान दें कि यह ISO/IEC 8859-1 उर्फ से अलग है
/// आईएसओ 8859-1 (एक कम हाइफ़न के साथ), जो कुछ "blanks", बाइट मान छोड़ देता है जो किसी भी वर्ण को असाइन नहीं किए जाते हैं।
/// ISO-8859-1 (IANA one) उन्हें C0 और C1 नियंत्रण कोड प्रदान करता है।
///
/// ध्यान दें कि यह Windows-1252 उर्फ से *भी* भिन्न है
/// कोड पृष्ठ 1252, जो एक सुपरसेट ISO/IEC 8859-1 है जो विराम चिह्न और विभिन्न लैटिन वर्णों के लिए कुछ (सभी नहीं!) रिक्त स्थान प्रदान करता है।
///
/// चीजों को और अधिक भ्रमित करने के लिए, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, और `windows-1252` विंडोज-1252 के सुपरसेट के लिए सभी उपनाम हैं जो शेष रिक्त स्थान को संबंधित C0 और C1 नियंत्रण कोड से भरते हैं।
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] को [`char`] में कनवर्ट करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// एक त्रुटि जिसे चार को पार्स करते समय वापस किया जा सकता है।
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // सुरक्षा: जाँच की गई कि यह एक कानूनी यूनिकोड मान है
            Ok(unsafe { transmute(i) })
        }
    }
}

/// u32 से चार में रूपांतरण विफल होने पर त्रुटि प्रकार वापस आ गया।
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// दिए गए मूलांक में एक अंक को `char` में परिवर्तित करता है।
///
/// यहाँ एक 'radix' को कभी-कभी 'base' भी कहा जाता है।
/// दो का मूलांक कुछ सामान्य मान देने के लिए एक द्विआधारी संख्या, दस का मूलांक, दशमलव और सोलह का मूलांक, हेक्साडेसिमल इंगित करता है।
///
/// मनमाना मूलांक समर्थित हैं।
///
/// `from_digit()` यदि दिए गए मूलांक में इनपुट एक अंक नहीं है तो `None` लौटाएगा।
///
/// # Panics
///
/// Panics यदि 36 से बड़ा मूलांक दिया जाए।
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // दशमलव 11, आधार 16 में एक एकल अंक है
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// इनपुट एक अंक नहीं होने पर `None` लौटाना:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// एक बड़े मूलांक को पास करना, जिससे panic उत्पन्न होता है:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}