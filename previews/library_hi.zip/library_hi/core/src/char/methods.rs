//! इम्प्लांट चार {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// उच्चतम वैध कोड बिंदु एक `char` हो सकता है।
    ///
    /// एक `char` एक [Unicode Scalar Value] है, जिसका अर्थ है कि यह एक [Code Point] है, लेकिन केवल एक निश्चित सीमा के भीतर है।
    /// `MAX` उच्चतम मान्य कोड बिंदु है जो एक मान्य [Unicode Scalar Value] है।
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` एक डिकोडिंग त्रुटि का प्रतिनिधित्व करने के लिए यूनिकोड में () का उपयोग किया जाता है।
    ///
    /// यह हो सकता है, उदाहरण के लिए, [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) को खराब गठित UTF-8 बाइट्स देते समय।
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// [Unicode](http://www.unicode.org/) का संस्करण जिस पर `char` और `str` विधियों के यूनिकोड भाग आधारित हैं।
    ///
    /// यूनिकोड के नए संस्करण नियमित रूप से जारी किए जाते हैं और बाद में यूनिकोड के आधार पर मानक पुस्तकालय में सभी विधियों को अद्यतन किया जाता है।
    /// इसलिए कुछ `char` और `str` विधियों का व्यवहार और इस स्थिरांक का मान समय के साथ बदलता रहता है।
    /// इसे एक ब्रेकिंग बदलाव *नहीं* माना जाता है।
    ///
    /// संस्करण क्रमांकन योजना को [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) में समझाया गया है।
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` में UTF-16 एन्कोडेड कोड बिंदुओं पर एक पुनरावर्तक बनाता है, अयुग्मित सरोगेट को `Err` के रूप में लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// `Err` परिणामों को प्रतिस्थापन वर्ण के साथ बदलकर एक हानिपूर्ण डिकोडर प्राप्त किया जा सकता है:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` को `char` में कनवर्ट करता है।
    ///
    /// ध्यान दें कि सभी `char` मान्य [`u32`] s हैं, और इन्हें एक के साथ कास्ट किया जा सकता है
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// हालांकि, इसका उल्टा सच नहीं है: सभी मान्य [`u32`] मान्य `चार` नहीं हैं।
    /// `from_u32()` यदि इनपुट `char` के लिए मान्य मान नहीं है, तो `None` लौटाएगा।
    ///
    /// इस फ़ंक्शन के असुरक्षित संस्करण के लिए जो इन जाँचों को अनदेखा करता है, [`from_u32_unchecked`] देखें।
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// जब इनपुट मान्य `char` न हो तो `None` लौटाना:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// वैधता को अनदेखा करते हुए `u32` को `char` में कनवर्ट करता है।
    ///
    /// ध्यान दें कि सभी `char` मान्य [`u32`] s हैं, और इन्हें एक के साथ कास्ट किया जा सकता है
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// हालांकि, इसका उल्टा सच नहीं है: सभी मान्य [`u32`] मान्य `चार` नहीं हैं।
    /// `from_u32_unchecked()` इसे अनदेखा कर देगा, और आँख बंद करके `char` पर डाल देगा, संभवतः एक अमान्य बना देगा।
    ///
    ///
    /// # Safety
    ///
    /// यह फ़ंक्शन असुरक्षित है, क्योंकि यह अमान्य `char` मान बना सकता है।
    ///
    /// इस फ़ंक्शन के सुरक्षित संस्करण के लिए, [`from_u32`] फ़ंक्शन देखें।
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // सुरक्षा: कॉलर द्वारा सुरक्षा अनुबंध को बरकरार रखा जाना चाहिए।
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// दिए गए मूलांक में एक अंक को `char` में परिवर्तित करता है।
    ///
    /// यहाँ एक 'radix' को कभी-कभी 'base' भी कहा जाता है।
    /// दो का मूलांक कुछ सामान्य मान देने के लिए एक द्विआधारी संख्या, दस का मूलांक, दशमलव और सोलह का मूलांक, हेक्साडेसिमल इंगित करता है।
    ///
    /// मनमाना मूलांक समर्थित हैं।
    ///
    /// `from_digit()` यदि दिए गए मूलांक में इनपुट एक अंक नहीं है तो `None` लौटाएगा।
    ///
    /// # Panics
    ///
    /// Panics यदि 36 से बड़ा मूलांक दिया जाए।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // दशमलव 11, आधार 16 में एक एकल अंक है
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// इनपुट एक अंक नहीं होने पर `None` लौटाना:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// एक बड़े मूलांक को पास करना, जिससे panic उत्पन्न होता है:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// जाँचता है कि दिए गए मूलांक में `char` एक अंक है या नहीं।
    ///
    /// यहाँ एक 'radix' को कभी-कभी 'base' भी कहा जाता है।
    /// दो का मूलांक कुछ सामान्य मान देने के लिए एक द्विआधारी संख्या, दस का मूलांक, दशमलव और सोलह का मूलांक, हेक्साडेसिमल इंगित करता है।
    ///
    /// मनमाना मूलांक समर्थित हैं।
    ///
    /// [`is_numeric()`] की तुलना में, यह फ़ंक्शन केवल `0-9`, `a-z` और `A-Z` वर्णों को पहचानता है।
    ///
    /// 'Digit' केवल निम्नलिखित वर्णों के रूप में परिभाषित किया गया है:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' की अधिक व्यापक समझ के लिए, [`is_numeric()`] देखें।
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics यदि 36 से बड़ा मूलांक दिया जाए।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// एक बड़े मूलांक को पास करना, जिससे panic उत्पन्न होता है:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// दिए गए मूलांक में एक `char` को एक अंक में परिवर्तित करता है।
    ///
    /// यहाँ एक 'radix' को कभी-कभी 'base' भी कहा जाता है।
    /// दो का मूलांक कुछ सामान्य मान देने के लिए एक द्विआधारी संख्या, दस का मूलांक, दशमलव और सोलह का मूलांक, हेक्साडेसिमल इंगित करता है।
    ///
    /// मनमाना मूलांक समर्थित हैं।
    ///
    /// 'Digit' केवल निम्नलिखित वर्णों के रूप में परिभाषित किया गया है:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// यदि `char` दिए गए मूलांक में किसी अंक को संदर्भित नहीं करता है तो `None` लौटाता है।
    ///
    /// # Panics
    ///
    /// Panics यदि 36 से बड़ा मूलांक दिया जाए।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// विफलता में एक गैर-अंकीय परिणाम पास करना:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// एक बड़े मूलांक को पास करना, जिससे panic उत्पन्न होता है:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // जहां `radix` स्थिर है और 10 या छोटा है, वहां निष्पादन की गति में सुधार करने के लिए कोड को यहां विभाजित किया गया है
        //
        let val = if likely(radix <= 10) {
            // यदि अंक नहीं है, तो मूलांक से बड़ी संख्या बनाई जाएगी।
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// एक पुनरावर्तक देता है जो एक चरित्र के हेक्साडेसिमल यूनिकोड को `चार` के रूप में छोड़ देता है।
    ///
    /// यह प्रपत्र `\u{NNNNNN}` के Rust सिंटैक्स वाले वर्णों से बच जाएगा जहां `NNNNNN` एक हेक्साडेसिमल प्रतिनिधित्व है।
    ///
    ///
    /// # Examples
    ///
    /// एक पुनरावर्तक के रूप में:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// सीधे `println!` का उपयोग करना:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// दोनों के बराबर हैं:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` का उपयोग करना:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // या-आईएनजी 1 सुनिश्चित करता है कि सी==0 के लिए कोड गणना करता है कि एक अंक मुद्रित किया जाना चाहिए और (जो समान है)(31, 32) अंडरफ्लो से बचा जाता है
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // सबसे महत्वपूर्ण हेक्स अंक का सूचकांक
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// `escape_debug` का एक विस्तारित संस्करण जो वैकल्पिक रूप से विस्तारित ग्रैफेम कोडपॉइंट से बचने की अनुमति देता है।
    /// यह हमें गैर-स्पेसिंग चिह्नों जैसे वर्णों को बेहतर तरीके से प्रारूपित करने की अनुमति देता है जब वे एक स्ट्रिंग की शुरुआत में होते हैं।
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// एक पुनरावर्तक देता है जो एक चरित्र के शाब्दिक एस्केप कोड को `चार` के रूप में देता है।
    ///
    /// यह `str` या `char` के `Debug` कार्यान्वयन के समान वर्णों से बच जाएगा।
    ///
    ///
    /// # Examples
    ///
    /// एक पुनरावर्तक के रूप में:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// सीधे `println!` का उपयोग करना:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// दोनों के बराबर हैं:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` का उपयोग करना:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// एक पुनरावर्तक देता है जो एक चरित्र के शाब्दिक एस्केप कोड को `चार` के रूप में देता है।
    ///
    /// डिफ़ॉल्ट को ऐसे शाब्दिक उत्पादन की ओर पूर्वाग्रह के साथ चुना जाता है जो विभिन्न भाषाओं में कानूनी हैं, जिनमें C++ 11 और समान सी-पारिवारिक भाषाएं शामिल हैं।
    /// सटीक नियम हैं:
    ///
    /// * Tab `\t` के रूप में बच निकला है।
    /// * कैरिज रिटर्न `\r` के रूप में बच निकला है।
    /// * लाइन फीड `\n` के रूप में बच जाती है।
    /// * सिंगल कोट `\'` के रूप में बच निकला है।
    /// * डबल कोट `\"` के रूप में बच निकला है।
    /// * बैकस्लैश `\\` के रूप में बच निकला है।
    /// * 'प्रिंट करने योग्य ASCII' श्रेणी `0x20` .. `0x7e` समावेशी में कोई भी वर्ण बच नहीं गया है।
    /// * अन्य सभी वर्णों को हेक्साडेसिमल यूनिकोड एस्केप दिया गया है;[`escape_unicode`] देखें।
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// एक पुनरावर्तक के रूप में:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// सीधे `println!` का उपयोग करना:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// दोनों के बराबर हैं:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` का उपयोग करना:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 में एन्कोड किए जाने पर इस `char` को बाइट्स की संख्या देता है।
    ///
    /// बाइट्स की वह संख्या हमेशा 1 और 4 के बीच होती है, समावेशी।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` प्रकार गारंटी देता है कि इसकी सामग्री UTF-8 है, और इसलिए हम उस लंबाई की तुलना कर सकते हैं जो प्रत्येक कोड बिंदु को `&str` बनाम `&str` के रूप में दर्शाया गया था:
    ///
    ///
    /// ```
    /// // वर्णों के रूप में
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // दोनों को तीन बाइट्स के रूप में दर्शाया जा सकता है
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str के रूप में, इन दोनों को UTF-8 में एन्कोड किया गया है
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // हम देख सकते हैं कि वे कुल छह बाइट लेते हैं ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... बिल्कुल &str. की तरह
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16 में एन्कोड किए जाने पर इस `char` को आवश्यक 16-बिट कोड इकाइयों की संख्या देता है।
    ///
    ///
    /// इस अवधारणा की अधिक व्याख्या के लिए [`len_utf8()`] के लिए दस्तावेज़ देखें।
    /// यह फ़ंक्शन एक दर्पण है, लेकिन UTF-8 के बजाय UTF-16 के लिए।
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// इस वर्ण को UTF-8 के रूप में प्रदान किए गए बाइट बफ़र में एन्कोड करता है, और फिर एन्कोडेड वर्ण वाले बफ़र का सबस्लाइस देता है।
    ///
    ///
    /// # Panics
    ///
    /// Panics यदि बफर पर्याप्त बड़ा नहीं है।
    /// लंबाई चार का एक बफर किसी भी `char` को एन्कोड करने के लिए काफी बड़ा है।
    ///
    /// # Examples
    ///
    /// इन दोनों उदाहरणों में, 'ß' एन्कोड करने के लिए दो बाइट लेता है।
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// एक बफर जो बहुत छोटा है:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // सुरक्षा: `char` सरोगेट नहीं है, इसलिए यह मान्य UTF-8 है।
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// इस वर्ण को UTF-16 के रूप में प्रदान किए गए `u16` बफ़र में एन्कोड करता है, और फिर एन्कोडेड वर्ण वाले बफ़र का सबलाइस देता है।
    ///
    ///
    /// # Panics
    ///
    /// Panics यदि बफर पर्याप्त बड़ा नहीं है।
    /// लंबाई 2 का एक बफर किसी भी `char` को एन्कोड करने के लिए काफी बड़ा है।
    ///
    /// # Examples
    ///
    /// इन दोनों उदाहरणों में, '𝕊' को एन्कोड करने में दो `u16` लगते हैं।
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// एक बफर जो बहुत छोटा है:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// यदि इस `char` में `Alphabetic` गुण है तो `true` लौटाता है।
    ///
    /// `Alphabetic` [Unicode Standard] के अध्याय 4 (चरित्र गुण) में वर्णित है और [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] में निर्दिष्ट है।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // प्यार बहुत कुछ है, लेकिन यह वर्णमाला नहीं है
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// यदि इस `char` में `Lowercase` गुण है तो `true` लौटाता है।
    ///
    /// `Lowercase` [Unicode Standard] के अध्याय 4 (चरित्र गुण) में वर्णित है और [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] में निर्दिष्ट है।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // विभिन्न चीनी लिपियों और विराम चिह्नों में कोई मामला नहीं है, और इसलिए:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// यदि इस `char` में `Uppercase` गुण है तो `true` लौटाता है।
    ///
    /// `Uppercase` [Unicode Standard] के अध्याय 4 (चरित्र गुण) में वर्णित है और [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] में निर्दिष्ट है।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // विभिन्न चीनी लिपियों और विराम चिह्नों में कोई मामला नहीं है, और इसलिए:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// यदि इस `char` में `White_Space` गुण है तो `true` लौटाता है।
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`] में निर्दिष्ट है।
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // एक गैर तोड़ने वाली जगह
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// यदि यह `char` या तो [`is_alphabetic()`] या [`is_numeric()`] को संतुष्ट करता है, तो `true` लौटाता है।
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// यदि इस `char` में नियंत्रण कोड के लिए सामान्य श्रेणी है, तो `true` लौटाता है।
    ///
    /// नियंत्रण कोड (`Cc` की सामान्य श्रेणी के साथ कोड बिंदु) [Unicode Standard] के अध्याय 4 (चरित्र गुण) में वर्णित हैं और [Unicode Character Database][ucd] [`UnicodeData.txt`] में निर्दिष्ट हैं।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// // यू+009सी, स्ट्रिंग टर्मिनेटर
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// यदि इस `char` में `Grapheme_Extend` गुण है तो `true` लौटाता है।
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] में वर्णित है और [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] में निर्दिष्ट है।
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// यदि इस `char` में संख्याओं के लिए सामान्य श्रेणियों में से एक है, तो `true` लौटाता है।
    ///
    /// संख्याओं के लिए सामान्य श्रेणियां (दशमलव अंकों के लिए `Nd`, अक्षर जैसे संख्यात्मक वर्णों के लिए `Nl`, और अन्य संख्यात्मक वर्णों के लिए `No`) [Unicode Character Database][ucd] [`UnicodeData.txt`] में निर्दिष्ट हैं।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// एक पुनरावर्तक देता है जो इस `char` के लोअरकेस मैपिंग को एक या अधिक के रूप में देता है
    /// `char`s.
    ///
    /// यदि इस `char` में लोअरकेस मैपिंग नहीं है, तो पुनरावर्तक समान `char` उत्पन्न करता है।
    ///
    /// यदि इस `char` में [Unicode Character Database][ucd] [`UnicodeData.txt`] द्वारा दी गई एक-से-एक लोअरकेस मैपिंग है, तो इटरेटर उस `char` को उत्पन्न करता है।
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// यदि इस `char` को विशेष ध्यान देने की आवश्यकता है (उदाहरण के लिए कई `char`s) तो पुनरावर्तक [`SpecialCasing.txt`] द्वारा दिए गए `char` (s) उत्पन्न करता है।
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// यह ऑपरेशन सिलाई के बिना बिना शर्त मैपिंग करता है।अर्थात्, रूपांतरण संदर्भ और भाषा से स्वतंत्र है।
    ///
    /// [Unicode Standard] में, अध्याय 4 (चरित्र गुण) सामान्य रूप से केस मैपिंग पर चर्चा करता है और अध्याय 3 (Conformance) केस रूपांतरण के लिए डिफ़ॉल्ट एल्गोरिथम पर चर्चा करता है।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// एक पुनरावर्तक के रूप में:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// सीधे `println!` का उपयोग करना:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// दोनों के बराबर हैं:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` का उपयोग करना:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // कभी-कभी परिणाम एक से अधिक वर्ण होते हैं:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // ऐसे वर्ण जिनमें अपरकेस और लोअरकेस दोनों नहीं होते हैं, वे स्वयं में परिवर्तित हो जाते हैं।
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// एक पुनरावर्तक देता है जो इस `char` के अपरकेस मैपिंग को एक या अधिक के रूप में उत्पन्न करता है
    /// `char`s.
    ///
    /// यदि इस `char` में अपरकेस मैपिंग नहीं है, तो इटरेटर समान `char` उत्पन्न करता है।
    ///
    /// यदि इस `char` में [Unicode Character Database][ucd] [`UnicodeData.txt`] द्वारा दी गई एक-से-एक अपरकेस मैपिंग है, तो इटरेटर उस `char` को उत्पन्न करता है।
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// यदि इस `char` को विशेष ध्यान देने की आवश्यकता है (उदाहरण के लिए कई `char`s) तो पुनरावर्तक [`SpecialCasing.txt`] द्वारा दिए गए `char` (s) उत्पन्न करता है।
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// यह ऑपरेशन सिलाई के बिना बिना शर्त मैपिंग करता है।अर्थात्, रूपांतरण संदर्भ और भाषा से स्वतंत्र है।
    ///
    /// [Unicode Standard] में, अध्याय 4 (चरित्र गुण) सामान्य रूप से केस मैपिंग पर चर्चा करता है और अध्याय 3 (Conformance) केस रूपांतरण के लिए डिफ़ॉल्ट एल्गोरिथम पर चर्चा करता है।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// एक पुनरावर्तक के रूप में:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// सीधे `println!` का उपयोग करना:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// दोनों के बराबर हैं:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` का उपयोग करना:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // कभी-कभी परिणाम एक से अधिक वर्ण होते हैं:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // ऐसे वर्ण जिनमें अपरकेस और लोअरकेस दोनों नहीं होते हैं, वे स्वयं में परिवर्तित हो जाते हैं।
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # लोकेल पर नोट
    ///
    /// तुर्की में, लैटिन में 'i' के समतुल्य के दो के बजाय पाँच रूप हैं:
    ///
    /// * 'Dotless': मैं/, कभी कभी लिखा .
    /// * 'Dotted': /मैं
    ///
    /// ध्यान दें कि लोअरकेस डॉटेड 'i' लैटिन के समान है।इसलिए:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// यहां `upper_i` का मान टेक्स्ट की भाषा पर निर्भर करता है: यदि हम `en-US` में हैं, तो यह `"I"` होना चाहिए, लेकिन यदि हम `tr_TR` में हैं, तो यह `"İ"` होना चाहिए।
    /// `to_uppercase()` इसे ध्यान में नहीं रखता है, और इसलिए:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// भाषाओं में रखती है।
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// जाँचता है कि मान ASCII सीमा के भीतर है या नहीं।
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// अपने ASCII अपरकेस समकक्ष में मान की एक प्रति बनाता है।
    ///
    /// ASCII अक्षर 'a' से 'z' को 'A' से 'Z' में मैप किया गया है, लेकिन गैर-ASCII अक्षर अपरिवर्तित हैं।
    ///
    /// इन-प्लेस मान को अपरकेस करने के लिए, [`make_ascii_uppercase()`] का उपयोग करें।
    ///
    /// गैर-ASCII वर्णों के अलावा ASCII वर्णों को अपरकेस करने के लिए, [`to_uppercase()`] का उपयोग करें।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// अपने एएससीआईआई लोअर केस समकक्ष में मूल्य की एक प्रति बनाता है।
    ///
    /// ASCII अक्षर 'A' से 'Z' को 'a' से 'z' में मैप किया गया है, लेकिन गैर-ASCII अक्षर अपरिवर्तित हैं।
    ///
    /// इन-प्लेस मान को कम करने के लिए, [`make_ascii_lowercase()`] का उपयोग करें।
    ///
    /// गैर-ASCII वर्णों के अलावा ASCII वर्णों को छोटा करने के लिए, [`to_lowercase()`] का उपयोग करें।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// जाँचता है कि दो मान ASCII केस-संवेदी मिलान हैं।
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` के बराबर।
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// इस प्रकार को इसके ASCII अपर केस के समतुल्य इन-प्लेस में कनवर्ट करता है।
    ///
    /// ASCII अक्षर 'a' से 'z' को 'A' से 'Z' में मैप किया गया है, लेकिन गैर-ASCII अक्षर अपरिवर्तित हैं।
    ///
    /// मौजूदा एक को संशोधित किए बिना एक नया अपरकेस मान वापस करने के लिए, [`to_ascii_uppercase()`] का उपयोग करें।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// इस प्रकार को इसके ASCII लोअर केस के समतुल्य इन-प्लेस में कनवर्ट करता है।
    ///
    /// ASCII अक्षर 'A' से 'Z' को 'a' से 'z' में मैप किया गया है, लेकिन गैर-ASCII अक्षर अपरिवर्तित हैं।
    ///
    /// मौजूदा को संशोधित किए बिना एक नया लोअरकेस मान वापस करने के लिए, [`to_ascii_lowercase()`] का उपयोग करें।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// जाँचता है कि क्या मान ASCII वर्णानुक्रमिक वर्ण है:
    ///
    /// - U+0041 'A' ..=U+005A 'Z', या
    /// - यू+0061 एक्स01एक्स ..=यू+007ए एक्स00एक्स।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// जाँचता है कि क्या मान ASCII अपरकेस वर्ण है:
    /// यू+0041 एक्स01एक्स ..=यू+005ए एक्स00एक्स।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// जाँचता है कि क्या मान ASCII लोअरकेस वर्ण है:
    /// यू+0061 एक्स01एक्स ..=यू+007ए एक्स00एक्स।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// जाँचता है कि क्या मान ASCII अल्फ़ान्यूमेरिक वर्ण है:
    ///
    /// - U+0041 'A' ..=U+005A 'Z', या
    /// - U+0061 'a' ..=U+007A 'z', या
    /// - यू+0030 एक्स01एक्स ..=यू+0039 एक्स00एक्स।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// जाँचता है कि क्या मान ASCII दशमलव अंक है:
    /// यू+0030 एक्स01एक्स ..=यू+0039 एक्स00एक्स।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// जाँचता है कि क्या मान ASCII हेक्साडेसिमल अंक है:
    ///
    /// - यू+0030 '0' ..=यू+0039 '9', या
    /// - यू+0041 'A' ..=यू+0046 'F', या
    /// - यू+0061 'a' ..=यू+0066 'f'।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// जाँचता है कि क्या मान ASCII विराम चिह्न वर्ण है:
    ///
    /// - यू+0021 ..=यू+002F `! " # $ % & ' ( ) * + , - . /`, या
    /// - यू+003ए ..=यू+0040 `: ; < = > ? @`, या
    /// - U+005B ..=U+0060 ``[\] ^ _` ``, या
    /// - यू+007बी ..=यू+007ई `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// जाँचता है कि क्या मान ASCII ग्राफ़िक वर्ण है:
    /// यू+0021 एक्स01एक्स ..=यू+007ई एक्स00एक्स।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// जाँचता है कि क्या मान ASCII व्हॉट्सएप वर्ण है:
    /// यू+0020 स्पेस, यू+0009 हॉरिजॉन्टल टैब, यू+000ए लाइन फीड, यू+000सी फॉर्म फीड, या यू+000डी कैरिज रिटर्न।
    ///
    /// Rust WhatWG इंफ्रा स्टैंडर्ड के [definition of ASCII whitespace][infra-aw] का उपयोग करता है।व्यापक उपयोग में कई अन्य परिभाषाएँ हैं।
    /// उदाहरण के लिए, [the POSIX locale][pct] में U+000B VERTICAL TAB के साथ-साथ उपरोक्त सभी वर्ण शामिल हैं, लेकिन-एक ही विनिर्देश से-[बॉर्न shell में "field splitting" के लिए डिफ़ॉल्ट नियम][bfs]*only* SPACE, HORIZONTAL TAB, और लाइन फ़ीड व्हॉट्सएप के रूप में।
    ///
    ///
    /// यदि आप कोई प्रोग्राम लिख रहे हैं जो किसी मौजूदा फ़ाइल स्वरूप को संसाधित करेगा, तो इस फ़ंक्शन का उपयोग करने से पहले जांचें कि उस प्रारूप की व्हाइटस्पेस की परिभाषा क्या है।
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// जाँचता है कि क्या मान ASCII नियंत्रण वर्ण है:
    /// यू+0000 एनयूएल ..=यू+001एफ यूनिट सेपरेटर, या यू+007एफ डिलीट।
    /// ध्यान दें कि अधिकांश ASCII व्हाइटस्पेस वर्ण नियंत्रण वर्ण हैं, लेकिन SPACE नहीं है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// प्रदान किए गए बाइट बफर में कच्चे u32 मान को UTF-8 के रूप में एन्कोड करता है, और फिर एन्कोडेड वर्ण वाले बफर का सबलाइस देता है।
///
///
/// `char::encode_utf8` के विपरीत, यह विधि सरोगेट श्रेणी में कोडपॉइंट को भी संभालती है।
/// (सरोगेट श्रेणी में एक `char` बनाना UB है।) परिणाम मान्य [generalized UTF-8] है लेकिन मान्य UTF-8 नहीं है।
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics यदि बफर पर्याप्त बड़ा नहीं है।
/// लंबाई चार का एक बफर किसी भी `char` को एन्कोड करने के लिए काफी बड़ा है।
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// प्रदान किए गए `u16` बफर में कच्चे u32 मान को UTF-16 के रूप में एन्कोड करता है, और फिर एन्कोडेड वर्ण वाले बफर का सबस्लाइस देता है।
///
///
/// `char::encode_utf16` के विपरीत, यह विधि सरोगेट श्रेणी में कोडपॉइंट को भी संभालती है।
/// (सरोगेट श्रेणी में एक `char` बनाना UB है।)
///
/// # Panics
///
/// Panics यदि बफर पर्याप्त बड़ा नहीं है।
/// लंबाई 2 का एक बफर किसी भी `char` को एन्कोड करने के लिए काफी बड़ा है।
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // सुरक्षा: प्रत्येक हाथ जांचता है कि क्या लिखने के लिए पर्याप्त बिट्स हैं
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // बीएमपी गिर जाता है
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // पूरक विमान सरोगेट में टूट जाते हैं।
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}