//! उन प्रकारों के लिए `Default` trait जिनमें सार्थक डिफ़ॉल्ट मान हो सकते हैं।

#![stable(feature = "rust1", since = "1.0.0")]

/// एक प्रकार को उपयोगी डिफ़ॉल्ट मान देने के लिए trait।
///
/// कभी-कभी, आप किसी प्रकार के डिफ़ॉल्ट मान पर वापस आना चाहते हैं, और विशेष रूप से परवाह नहीं करते कि यह क्या है।
/// यह अक्सर `स्ट्रक्चर` के साथ आता है जो विकल्पों के एक सेट को परिभाषित करता है:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// हम कुछ डिफ़ॉल्ट मानों को कैसे परिभाषित कर सकते हैं?आप `Default` का उपयोग कर सकते हैं:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// अब, आपको सभी डिफ़ॉल्ट मान मिलते हैं।Rust विभिन्न आदिम प्रकारों के लिए `Default` लागू करता है।
///
/// यदि आप किसी विशेष विकल्प को ओवरराइड करना चाहते हैं, लेकिन फिर भी अन्य डिफ़ॉल्ट बनाए रखें:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// इस trait का उपयोग `#[derive]` के साथ किया जा सकता है यदि सभी प्रकार के फ़ील्ड `Default` लागू करते हैं।
/// जब `derive`d, यह प्रत्येक फ़ील्ड के प्रकार के लिए डिफ़ॉल्ट मान का उपयोग करेगा।
///
/// ## मैं `Default` को कैसे कार्यान्वित कर सकता हूं?
///
/// `default()` विधि के लिए एक कार्यान्वयन प्रदान करें जो आपके प्रकार का मान लौटाता है जो कि डिफ़ॉल्ट होना चाहिए:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// एक प्रकार के लिए "default value" लौटाता है।
    ///
    /// डिफ़ॉल्ट मान अक्सर किसी प्रकार का प्रारंभिक मान, पहचान मान, या कुछ और होता है जो डिफ़ॉल्ट के रूप में समझ में आता है।
    ///
    ///
    /// # Examples
    ///
    /// अंतर्निहित डिफ़ॉल्ट मानों का उपयोग करना:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// अपना बनाना:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait के अनुसार किसी प्रकार का डिफ़ॉल्ट मान लौटाएं।
///
/// वापसी के प्रकार का अनुमान संदर्भ से लगाया जाता है;यह `Default::default()` के बराबर है लेकिन टाइप करने के लिए छोटा है।
///
/// उदाहरण के लिए:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default` का एक अर्थ उत्पन्न करने वाला मैक्रो व्युत्पन्न करें।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }