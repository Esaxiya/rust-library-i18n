//! `Result` प्रकार से निपटने में त्रुटि।
//!
//! [`Result<T, E>`][`Result`] त्रुटियों को वापस करने और प्रचारित करने के लिए उपयोग किया जाने वाला प्रकार है।
//! यह वेरिएंट के साथ एक एनम है, [`Ok(T)`], सफलता का प्रतिनिधित्व करता है और एक मान युक्त होता है, और [`Err(E)`], त्रुटि का प्रतिनिधित्व करता है और एक त्रुटि मान होता है।
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! जब भी त्रुटियां अपेक्षित और पुनर्प्राप्त करने योग्य होती हैं, तो फ़ंक्शन [`Result`] लौटाते हैं।`std` crate में, [`Result`] का सबसे प्रमुख रूप से [I/O](../../std/io/index.html) के लिए उपयोग किया जाता है।
//!
//! [`Result`] लौटने वाला एक साधारण फ़ंक्शन परिभाषित किया जा सकता है और इस तरह उपयोग किया जा सकता है:
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! [`Result`] s पर पैटर्न मिलान सरल मामलों के लिए स्पष्ट और सीधा है, लेकिन [`Result`] कुछ सुविधा विधियों के साथ आता है जो इसके साथ काम करना अधिक संक्षिप्त बनाते हैं।
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // `is_ok` और `is_err` विधियां वही करती हैं जो वे कहते हैं।
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` `Result` का उपभोग करता है और दूसरा उत्पादन करता है।
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // गणना जारी रखने के लिए `and_then` का उपयोग करें।
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // त्रुटि को संभालने के लिए `or_else` का उपयोग करें।
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // परिणाम का उपभोग करें और सामग्री को `unwrap` के साथ वापस करें।
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # परिणाम का उपयोग किया जाना चाहिए
//!
//! त्रुटियों को इंगित करने के लिए रिटर्न वैल्यू का उपयोग करने में एक आम समस्या यह है कि रिटर्न वैल्यू को अनदेखा करना आसान है, इस प्रकार त्रुटि को संभालने में विफल रहता है।
//! [`Result`] `#[must_use]` विशेषता के साथ एनोटेट किया गया है, जो परिणाम मान को अनदेखा किए जाने पर कंपाइलर को चेतावनी जारी करने का कारण बनेगा।
//! यह [`Result`] को उन कार्यों के लिए विशेष रूप से उपयोगी बनाता है जो त्रुटियों का सामना कर सकते हैं लेकिन अन्यथा उपयोगी मान वापस नहीं करते हैं।
//!
//! [`Write`] trait द्वारा I/O प्रकारों के लिए परिभाषित [`write_all`] विधि पर विचार करें:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: [`Write`] की वास्तविक परिभाषा [`io::Result`] का उपयोग करती है, जो केवल [`परिणाम`]`. का पर्याय है<T,`[`io: :Error`]`>`.*
//!
//! यह विधि कोई मान उत्पन्न नहीं करती है, लेकिन लेखन विफल हो सकता है।त्रुटि मामले को संभालना महत्वपूर्ण है, और *नहीं* कुछ इस तरह लिखें:
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // यदि `write_all` त्रुटियां हैं, तो हम कभी नहीं जान पाएंगे, क्योंकि वापसी मूल्य को अनदेखा कर दिया जाता है।
//! //
//! file.write_all(b"important message");
//! ```
//!
//! यदि आप इसे Rust में लिखते हैं, तो संकलक आपको एक चेतावनी देगा (डिफ़ॉल्ट रूप से, `unused_must_use` lint द्वारा नियंत्रित)।
//!
//! इसके बजाय, यदि आप त्रुटि को संभालना नहीं चाहते हैं, तो आप बस [`expect`] के साथ सफलता का दावा कर सकते हैं।
//! यह panic होगा यदि लेखन विफल हो जाता है, तो यह इंगित करने वाला एक मामूली उपयोगी संदेश प्रदान करता है:
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! आप बस सफलता का दावा भी कर सकते हैं:
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! या [`?`] के साथ कॉल स्टैक में त्रुटि का प्रचार करें:
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # प्रश्न चिह्न ऑपरेटर, `?`
//!
//! कोड लिखते समय जो कई फ़ंक्शन को कॉल करता है जो [`Result`] प्रकार लौटाते हैं, त्रुटि प्रबंधन कठिन हो सकता है।
//! प्रश्न चिह्न ऑपरेटर, [`?`], कॉल स्टैक में प्रोपेगेटिंग त्रुटियों के कुछ बॉयलरप्लेट को छुपाता है।
//!
//! यह इसे प्रतिस्थापित करता है:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // त्रुटि पर जल्दी वापसी
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! इसके साथ:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // त्रुटि पर जल्दी वापसी
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *यह ज्यादा अच्छा है!*
//!
//! [`?`] के साथ एक्सप्रेशन को समाप्त करने के परिणामस्वरूप अलिखित सफलता ([`Ok`]) मान प्राप्त होगा, जब तक कि परिणाम [`Err`] न हो, इस स्थिति में [`Err`] संलग्न फ़ंक्शन से जल्दी वापस आ जाता है।
//!
//!
//! [`?`] केवल उन कार्यों में उपयोग किया जा सकता है जो [`Err`] की प्रारंभिक वापसी के कारण [`Result`] लौटाते हैं जो इसे प्रदान करता है।
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` एक प्रकार है जो या तो सफलता ([`Ok`]) या विफलता ([`Err`]) का प्रतिनिधित्व करता है।
///
/// विवरण के लिए [module documentation](self) देखें।
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// सफलता मूल्य शामिल है
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// त्रुटि मान शामिल है
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// कार्यान्वयन टाइप करें
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // निहित मूल्यों को क्वेरी करना
    /////////////////////////////////////////////////////////////////////////

    /// यदि परिणाम [`Ok`] है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// यदि परिणाम [`Err`] है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// यदि परिणाम दिए गए मान वाला [`Ok`] मान है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// यदि परिणाम दिए गए मान वाला [`Err`] मान है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // प्रत्येक प्रकार के लिए एडेप्टर
    /////////////////////////////////////////////////////////////////////////

    /// `Result<T, E>` से [`Option<T>`] में कनवर्ट करता है।
    ///
    /// `self` को [`Option<T>`] में परिवर्तित करता है, `self` का उपभोग करता है, और त्रुटि को दूर करता है, यदि कोई हो।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// `Result<T, E>` से [`Option<E>`] में कनवर्ट करता है।
    ///
    /// `self` को [`Option<E>`] में परिवर्तित करता है, `self` का उपभोग करता है, और सफलता मान, यदि कोई हो, को त्याग देता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // संदर्भों के साथ काम करने के लिए एडेप्टर
    /////////////////////////////////////////////////////////////////////////

    /// `&Result<T, E>` से `Result<&T, &E>` में कनवर्ट करता है।
    ///
    /// एक नया `Result` बनाता है, जिसमें मूल में एक संदर्भ होता है, मूल को जगह में छोड़ देता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// `&mut Result<T, E>` से `Result<&mut T, &mut E>` में कनवर्ट करता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // निहित मूल्यों को बदलना
    /////////////////////////////////////////////////////////////////////////

    /// एक एक्स००एक्स से एक्स०१एक्स को एक निहित एक्स०२एक्स मान पर एक फ़ंक्शन लागू करके मैप करता है, एक एक्स०३एक्स मान को अछूता छोड़ देता है।
    ///
    ///
    /// इस फ़ंक्शन का उपयोग दो कार्यों के परिणामों की रचना के लिए किया जा सकता है।
    ///
    /// # Examples
    ///
    /// एक स्ट्रिंग की प्रत्येक पंक्ति पर संख्याओं को दो से गुणा करके प्रिंट करें।
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// किसी फ़ंक्शन को निहित मान (यदि [`Ok`]) पर लागू करता है, या प्रदत्त डिफ़ॉल्ट (यदि [`Err`]) देता है।
    ///
    /// `map_or` को दिए गए तर्कों का उत्सुकता से मूल्यांकन किया जाता है;यदि आप फ़ंक्शन कॉल का परिणाम पास कर रहे हैं, तो [`map_or_else`] का उपयोग करने की अनुशंसा की जाती है, जिसका आलसी मूल्यांकन किया जाता है।
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// किसी निहित [`Ok`] मान पर फ़ंक्शन लागू करके, या किसी निहित [`Err`] मान पर फ़ॉलबैक फ़ंक्शन लागू करके `Result<T, E>` से `U` को मैप करता है।
    ///
    ///
    /// इस फ़ंक्शन का उपयोग किसी त्रुटि को संभालने के दौरान एक सफल परिणाम को अनपैक करने के लिए किया जा सकता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// एक एक्स००एक्स से एक्स०१एक्स को एक निहित एक्स०२एक्स मान पर एक फ़ंक्शन लागू करके मैप करता है, एक एक्स०३एक्स मान को अछूता छोड़ देता है।
    ///
    ///
    /// इस फ़ंक्शन का उपयोग किसी त्रुटि को संभालने के दौरान एक सफल परिणाम से गुजरने के लिए किया जा सकता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // इटरेटर कंस्ट्रक्टर
    /////////////////////////////////////////////////////////////////////////

    /// संभावित रूप से निहित मान पर एक पुनरावर्तक देता है।
    ///
    /// यदि परिणाम [`Result::Ok`] है, तो इटरेटर एक मान देता है, अन्यथा कोई नहीं।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// संभावित रूप से निहित मान पर एक परिवर्तनीय पुनरावर्तक देता है।
    ///
    /// यदि परिणाम [`Result::Ok`] है, तो इटरेटर एक मान देता है, अन्यथा कोई नहीं।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // मूल्यों पर बूलियन संचालन, उत्सुक और आलसी
    /////////////////////////////////////////////////////////////////////////

    /// यदि परिणाम [`Ok`] है, तो `res` लौटाता है, अन्यथा `self` का [`Err`] मान लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// यदि परिणाम [`Ok`] है, तो `op` को कॉल करें, अन्यथा `self` का [`Err`] मान लौटाता है।
    ///
    ///
    /// इस फ़ंक्शन का उपयोग `Result` मानों के आधार पर नियंत्रण प्रवाह के लिए किया जा सकता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// यदि परिणाम [`Err`] है, तो `res` लौटाता है, अन्यथा `self` का [`Ok`] मान लौटाता है।
    ///
    /// `or` को दिए गए तर्कों का उत्सुकता से मूल्यांकन किया जाता है;यदि आप फ़ंक्शन कॉल का परिणाम पास कर रहे हैं, तो [`or_else`] का उपयोग करने की अनुशंसा की जाती है, जिसका आलसी मूल्यांकन किया जाता है।
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// यदि परिणाम [`Err`] है, तो `op` को कॉल करें, अन्यथा `self` का [`Ok`] मान लौटाता है।
    ///
    ///
    /// इस फ़ंक्शन का उपयोग परिणाम मानों के आधार पर प्रवाह को नियंत्रित करने के लिए किया जा सकता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// निहित [`Ok`] मान या प्रदत्त डिफ़ॉल्ट लौटाता है।
    ///
    /// `unwrap_or` को दिए गए तर्कों का उत्सुकता से मूल्यांकन किया जाता है;यदि आप फ़ंक्शन कॉल का परिणाम पास कर रहे हैं, तो [`unwrap_or_else`] का उपयोग करने की अनुशंसा की जाती है, जिसका आलसी मूल्यांकन किया जाता है।
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// निहित [`Ok`] मान लौटाता है या बंद होने से इसकी गणना करता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// यह जाँचे बिना कि मान [`Err`] नहीं है, `self` मान का उपभोग करते हुए निहित [`Ok`] मान लौटाता है।
    ///
    ///
    /// # Safety
    ///
    /// इस विधि को [`Err`] पर कॉल करना *[अपरिभाषित व्यवहार]* है।
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // अपरिभाषित व्यवहार!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // सुरक्षा: कॉलर द्वारा सुरक्षा अनुबंध को बरकरार रखा जाना चाहिए।
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// यह जाँचे बिना कि मान [`Ok`] नहीं है, `self` मान का उपभोग करते हुए निहित [`Err`] मान लौटाता है।
    ///
    ///
    /// # Safety
    ///
    /// इस विधि को [`Ok`] पर कॉल करना *[अपरिभाषित व्यवहार]* है।
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // अपरिभाषित व्यवहार!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // सुरक्षा: कॉलर द्वारा सुरक्षा अनुबंध को बरकरार रखा जाना चाहिए।
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// `Ok` भाग की सामग्री की प्रतिलिपि बनाकर `Result<&T, E>` को `Result<T, E>` में मैप करें।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// `Ok` भाग की सामग्री की प्रतिलिपि बनाकर `Result<&mut T, E>` को `Result<T, E>` में मैप करें।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// `Ok` भाग की सामग्री को क्लोन करके `Result<&T, E>` को `Result<T, E>` में मैप करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// `Ok` भाग की सामग्री को क्लोन करके `Result<&mut T, E>` को `Result<T, E>` में मैप करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// `self` मान का उपभोग करते हुए निहित [`Ok`] मान लौटाता है।
    ///
    /// # Panics
    ///
    /// Panics यदि मान एक [`Err`] है, जिसमें पारित संदेश और [`Err`] की सामग्री सहित panic संदेश है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// `self` मान का उपभोग करते हुए निहित [`Ok`] मान लौटाता है।
    ///
    /// क्योंकि यह फ़ंक्शन panic हो सकता है, इसका उपयोग आमतौर पर हतोत्साहित किया जाता है।
    /// इसके बजाय, पैटर्न मिलान का उपयोग करना और [`Err`] मामले को स्पष्ट रूप से संभालना पसंद करें, या [`unwrap_or`], [`unwrap_or_else`], या [`unwrap_or_default`] पर कॉल करें।
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics यदि मान [`Err`] है, तो [`Err`] के मान द्वारा प्रदान किया गया panic संदेश के साथ।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// `self` मान का उपभोग करते हुए निहित [`Err`] मान लौटाता है।
    ///
    /// # Panics
    ///
    /// Panics यदि मान एक [`Ok`] है, जिसमें पारित संदेश और [`Ok`] की सामग्री सहित panic संदेश है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// `self` मान का उपभोग करते हुए निहित [`Err`] मान लौटाता है।
    ///
    /// # Panics
    ///
    /// Panics यदि मान एक [`Ok`] है, तो [`Ok`] के मान द्वारा प्रदान किया गया एक कस्टम panic संदेश के साथ।
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// निहित [`Ok`] मान या डिफ़ॉल्ट लौटाता है
    ///
    /// `self` तर्क का उपभोग करता है, यदि [`Ok`], निहित मान देता है, अन्यथा यदि [`Err`], उस प्रकार के लिए डिफ़ॉल्ट मान देता है।
    ///
    ///
    /// # Examples
    ///
    /// एक स्ट्रिंग को एक पूर्णांक में परिवर्तित करता है, खराब-निर्मित स्ट्रिंग्स को 0 (पूर्णांक के लिए डिफ़ॉल्ट मान) में बदल देता है।
    /// [`parse`] एक स्ट्रिंग को किसी अन्य प्रकार में कनवर्ट करता है जो [`FromStr`] लागू करता है, त्रुटि पर [`Err`] लौटाता है।
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// निहित [`Ok`] मान देता है, लेकिन panics कभी नहीं।
    ///
    /// [`unwrap`] के विपरीत, इस पद्धति को panic परिणाम प्रकारों पर कभी नहीं जाना जाता है जिसके लिए इसे लागू किया गया है।
    /// इसलिए, इसे `unwrap` के बजाय एक रखरखाव सुरक्षा के रूप में उपयोग किया जा सकता है जो संकलित करने में विफल हो जाएगा यदि `Result` के त्रुटि प्रकार को बाद में एक त्रुटि में बदल दिया जाता है जो वास्तव में हो सकता है।
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// `Result<T, E>` (या `&Result<T, E>`) से `Result<&<T as Deref>::Target, &E>` में कनवर्ट करता है।
    ///
    /// [`Deref`](crate::ops::Deref) के माध्यम से मूल [`Result`] के [`Ok`] संस्करण को मजबूर करता है और नया [`Result`] लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// `Result<T, E>` (या `&mut Result<T, E>`) से `Result<&mut <T as DerefMut>::Target, &mut E>` में कनवर्ट करता है।
    ///
    /// [`DerefMut`](crate::ops::DerefMut) के माध्यम से मूल [`Result`] के [`Ok`] संस्करण को मजबूर करता है और नया [`Result`] लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// `Option` के `Result` को `Result` के `Option` में स्थानांतरित करता है।
    ///
    /// `Ok(None)` `None` में मैप किया जाएगा।
    /// `Ok(Some(_))` और `Err(_)` को `Some(Ok(_))` और `Some(Err(_))` में मैप किया जाएगा।
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// `Result<Result<T, E>, E>` से `Result<T, E>`. में कनवर्ट करता है
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// फ़्लैटनिंग एक समय में केवल एक स्तर के नेस्टिंग को हटाता है:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// यदि `self`, `Ok` है, तो [`Ok`] मान लौटाता है, और यदि `self`, `Err` है, तो [`Err`] मान देता है।
    ///
    /// दूसरे शब्दों में, यह फ़ंक्शन `Result<T, T>` का मान (`T`) लौटाता है, भले ही वह परिणाम `Ok` या `Err` हो या नहीं।
    ///
    /// यह [`Atomic*::compare_exchange`], या [`slice::binary_search`] जैसे API के संयोजन में उपयोगी हो सकता है, लेकिन केवल उन मामलों में जहां आपको परवाह नहीं है कि परिणाम `Ok` था या नहीं।
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// विधियों के कोड आकार को कम करने के लिए यह एक अलग कार्य है
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Trait कार्यान्वयन
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// संभावित रूप से निहित मूल्य पर एक उपभोग करने वाला पुनरावर्तक देता है।
    ///
    /// यदि परिणाम [`Result::Ok`] है, तो इटरेटर एक मान देता है, अन्यथा कोई नहीं।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// परिणाम इटरेटर्स
/////////////////////////////////////////////////////////////////////////////

/// [`Result`] के [`Ok`] संस्करण के संदर्भ में एक पुनरावर्तक।
///
/// यदि परिणाम [`Ok`] है, तो इटरेटर एक मान देता है, अन्यथा कोई नहीं।
///
/// [`Result::iter`] द्वारा बनाया गया।
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// एक [`Result`] के [`Ok`] संस्करण के एक परिवर्तनीय संदर्भ पर एक पुनरावर्तक।
///
/// [`Result::iter_mut`] द्वारा बनाया गया।
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// [`Result`] के [`Ok`] संस्करण में मान से अधिक का पुनरावर्तक।
///
/// यदि परिणाम [`Ok`] है, तो इटरेटर एक मान देता है, अन्यथा कोई नहीं।
///
/// यह संरचना [`Result`] ([`IntoIterator`] trait द्वारा प्रदान) पर [`into_iter`] विधि द्वारा बनाई गई है।
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// प्रत्येक तत्व को `Iterator` में लेता है: यदि यह `Err` है, तो कोई और तत्व नहीं लिया जाता है, और `Err` वापस कर दिया जाता है।
    /// यदि कोई `Err` नहीं होता है, तो प्रत्येक `Result` के मान वाला एक कंटेनर वापस कर दिया जाता है।
    ///
    /// यहाँ एक उदाहरण दिया गया है जो vector में प्रत्येक पूर्णांक को बढ़ाता है, अतिप्रवाह की जाँच करता है:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// यहां एक और उदाहरण दिया गया है जो पूर्णांकों की दूसरी सूची से एक को घटाने की कोशिश करता है, इस बार अंडरफ्लो की जांच कर रहा है:
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// यहां पिछले उदाहरण पर एक भिन्नता है, यह दर्शाता है कि पहले `Err` के बाद `iter` से कोई और तत्व नहीं लिया गया है।
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// चूंकि तीसरे तत्व के कारण अंडरफ्लो हुआ, इसलिए कोई और तत्व नहीं लिया गया, इसलिए `shared` का अंतिम मान 6 (= `3 + 2 + 1`) है, न कि 16।
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): यह प्रदर्शन बग बंद होने पर इसे Iterator::scan से बदला जा सकता है।
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}