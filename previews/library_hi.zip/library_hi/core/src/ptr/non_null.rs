use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` लेकिन गैर-शून्य और सहसंयोजक।
///
/// कच्चे पॉइंटर्स का उपयोग करके डेटा संरचनाओं का निर्माण करते समय यह अक्सर उपयोग करने के लिए सही चीज होती है, लेकिन अंततः इसके अतिरिक्त गुणों के कारण उपयोग करना अधिक खतरनाक होता है।यदि आप सुनिश्चित नहीं हैं कि आपको `NonNull<T>` का उपयोग करना चाहिए, तो बस `*mut T` का उपयोग करें!
///
/// `*mut T` के विपरीत, सूचक हमेशा गैर-शून्य होना चाहिए, भले ही सूचक को कभी भी संदर्भित न किया गया हो।ऐसा इसलिए है ताकि एनम इस निषिद्ध मूल्य का उपयोग एक विवेचक के रूप में कर सकें-`Option<NonNull<T>>` का आकार `* mut T` के समान है।
/// हालांकि पॉइंटर अभी भी लटक सकता है अगर इसे संदर्भित नहीं किया गया है।
///
/// `*mut T` के विपरीत, `NonNull<T>` को `T` पर सहसंयोजक होने के लिए चुना गया था।यह सहसंयोजक प्रकारों का निर्माण करते समय `NonNull<T>` का उपयोग करना संभव बनाता है, लेकिन ऐसे प्रकार में उपयोग किए जाने पर अस्वस्थता के जोखिम का परिचय देता है जो वास्तव में सहसंयोजक नहीं होना चाहिए।
/// (विपरीत विकल्प `*mut T` के लिए बनाया गया था, भले ही तकनीकी रूप से अस्वस्थता केवल असुरक्षित कार्यों को कॉल करने के कारण हो सकती है।)
///
/// `Box`, `Rc`, `Arc`, `Vec`, और `LinkedList` जैसे अधिकांश सुरक्षित एब्स्ट्रैक्शन के लिए कॉन्वर्सिस सही है।ऐसा इसलिए है क्योंकि वे एक सार्वजनिक एपीआई प्रदान करते हैं जो Rust के सामान्य साझा XOR परिवर्तनशील नियमों का पालन करता है।
///
/// यदि आपका प्रकार सुरक्षित रूप से सहसंयोजक नहीं हो सकता है, तो आपको यह सुनिश्चित करना होगा कि इसमें प्रतिरूप प्रदान करने के लिए कुछ अतिरिक्त फ़ील्ड शामिल हैं।अक्सर यह फ़ील्ड [`PhantomData`] प्रकार का होगा जैसे `PhantomData<Cell<T>>` या `PhantomData<&'a mut T>`।
///
/// ध्यान दें कि `NonNull<T>` में `&T` के लिए `From` इंस्टेंस है।हालांकि, यह इस तथ्य को नहीं बदलता है कि (ए से प्राप्त सूचक) साझा संदर्भ के माध्यम से उत्परिवर्तन अपरिभाषित व्यवहार है जब तक कि उत्परिवर्तन [`UnsafeCell<T>`] के अंदर नहीं होता है।एक साझा संदर्भ से एक परिवर्तनीय संदर्भ बनाने के लिए भी यही होता है।
///
/// `UnsafeCell<T>` के बिना इस `From` इंस्टेंस का उपयोग करते समय, यह सुनिश्चित करना आपकी ज़िम्मेदारी है कि `as_mut` को कभी भी कॉल नहीं किया जाता है, और `as_ptr` को उत्परिवर्तन के लिए कभी भी उपयोग नहीं किया जाता है।
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` पॉइंटर्स `Send` नहीं हैं क्योंकि उनके द्वारा संदर्भित डेटा को अलियास किया जा सकता है।
// एनबी, यह निहितार्थ अनावश्यक है, लेकिन बेहतर त्रुटि संदेश प्रदान करना चाहिए।
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` पॉइंटर्स `Sync` नहीं हैं क्योंकि उनके द्वारा संदर्भित डेटा को अलियास किया जा सकता है।
// एनबी, यह निहितार्थ अनावश्यक है, लेकिन बेहतर त्रुटि संदेश प्रदान करना चाहिए।
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// एक नया `NonNull` बनाता है जो झूल रहा है, लेकिन अच्छी तरह से संरेखित है।
    ///
    /// यह उन प्रकारों को प्रारंभ करने के लिए उपयोगी है जो आलसी आवंटित करते हैं, जैसे `Vec::new` करता है।
    ///
    /// ध्यान दें कि सूचक मान संभावित रूप से `T` के लिए एक वैध सूचक का प्रतिनिधित्व कर सकता है, जिसका अर्थ है कि इसे "not yet initialized" प्रहरी मान के रूप में उपयोग नहीं किया जाना चाहिए।
    /// आलसी आवंटित प्रकारों को किसी अन्य माध्यम से आरंभीकरण को ट्रैक करना चाहिए।
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // सुरक्षा: mem::align_of() एक गैर-शून्य उपयोग देता है जिसे तब कास्ट किया जाता है
        // एक * म्यूट टी के लिए।
        // इसलिए, `ptr` शून्य नहीं है और new_unchecked() को कॉल करने की शर्तों का सम्मान किया जाता है।
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// मान के लिए एक साझा संदर्भ देता है।[`as_ref`] के विपरीत, इसके लिए यह आवश्यक नहीं है कि मान को इनिशियलाइज़ किया जाए।
    ///
    /// परिवर्तनीय समकक्ष के लिए [`as_uninit_mut`] देखें।
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// इस विधि को कॉल करते समय, आपको यह सुनिश्चित करना होगा कि निम्नलिखित सभी सत्य हैं:
    ///
    /// * सूचक को ठीक से संरेखित किया जाना चाहिए।
    ///
    /// * यह [the module documentation] में परिभाषित अर्थ में "dereferencable" होना चाहिए।
    ///
    /// * आपको Rust के अलियासिंग नियमों को लागू करना होगा, क्योंकि लौटा हुआ जीवनकाल `'a` मनमाने ढंग से चुना गया है और जरूरी नहीं कि यह डेटा के वास्तविक जीवनकाल को प्रतिबिंबित करे।
    ///
    ///   विशेष रूप से, इस जीवनकाल की अवधि के लिए, सूचक द्वारा इंगित स्मृति को उत्परिवर्तित नहीं किया जाना चाहिए (`UnsafeCell` के अंदर को छोड़कर)।
    ///
    /// यह तब भी लागू होता है जब इस पद्धति का परिणाम अप्रयुक्त हो!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `self` सभी को पूरा करता है
        // संदर्भ के लिए आवश्यकताएँ।
        unsafe { &*self.cast().as_ptr() }
    }

    /// मान के लिए एक अद्वितीय संदर्भ देता है।[`as_mut`] के विपरीत, इसके लिए यह आवश्यक नहीं है कि मान को इनिशियलाइज़ किया जाए।
    ///
    /// साझा समकक्ष के लिए [`as_uninit_ref`] देखें।
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// इस विधि को कॉल करते समय, आपको यह सुनिश्चित करना होगा कि निम्नलिखित सभी सत्य हैं:
    ///
    /// * सूचक को ठीक से संरेखित किया जाना चाहिए।
    ///
    /// * यह [the module documentation] में परिभाषित अर्थ में "dereferencable" होना चाहिए।
    ///
    /// * आपको Rust के अलियासिंग नियमों को लागू करना होगा, क्योंकि लौटा हुआ जीवनकाल `'a` मनमाने ढंग से चुना गया है और जरूरी नहीं कि यह डेटा के वास्तविक जीवनकाल को प्रतिबिंबित करे।
    ///
    ///   विशेष रूप से, इस जीवनकाल की अवधि के लिए, पॉइंटर द्वारा इंगित की गई मेमोरी को किसी अन्य पॉइंटर के माध्यम से एक्सेस (पढ़ा या लिखित) नहीं किया जाना चाहिए।
    ///
    /// यह तब भी लागू होता है जब इस पद्धति का परिणाम अप्रयुक्त हो!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `self` सभी को पूरा करता है
        // संदर्भ के लिए आवश्यकताएँ।
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// एक नया `NonNull` बनाता है।
    ///
    /// # Safety
    ///
    /// `ptr` गैर-शून्य होना चाहिए।
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `ptr` गैर-शून्य है।
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// यदि `ptr` गैर-शून्य है, तो एक नया `NonNull` बनाता है।
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // सुरक्षा: सूचक पहले से ही चेक किया गया है और शून्य नहीं है
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// [`std::ptr::from_raw_parts`] के समान कार्यक्षमता करता है, सिवाय इसके कि एक `NonNull` पॉइंटर लौटाया जाता है, जैसा कि एक कच्चे `*const` पॉइंटर के विपरीत है।
    ///
    ///
    /// अधिक जानकारी के लिए [`std::ptr::from_raw_parts`] का दस्तावेज़ीकरण देखें।
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // सुरक्षा: `ptr::from::raw_parts_mut` का परिणाम गैर-शून्य है क्योंकि `data_address` है।
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// पता और मेटाडेटा घटकों में एक (संभवतः चौड़ा) सूचक को विघटित करें।
    ///
    /// पॉइंटर को बाद में [`NonNull::from_raw_parts`] के साथ फिर से बनाया जा सकता है।
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// अंतर्निहित `*mut` सूचक प्राप्त करता है।
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// मान के लिए एक साझा संदर्भ देता है।यदि मान को प्रारंभ नहीं किया जा सकता है, तो इसके बजाय [`as_uninit_ref`] का उपयोग किया जाना चाहिए।
    ///
    /// परिवर्तनीय समकक्ष के लिए [`as_mut`] देखें।
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// इस विधि को कॉल करते समय, आपको यह सुनिश्चित करना होगा कि निम्नलिखित सभी सत्य हैं:
    ///
    /// * सूचक को ठीक से संरेखित किया जाना चाहिए।
    ///
    /// * यह [the module documentation] में परिभाषित अर्थ में "dereferencable" होना चाहिए।
    ///
    /// * पॉइंटर को `T` के आरंभिक उदाहरण को इंगित करना चाहिए।
    ///
    /// * आपको Rust के अलियासिंग नियमों को लागू करना होगा, क्योंकि लौटा हुआ जीवनकाल `'a` मनमाने ढंग से चुना गया है और जरूरी नहीं कि यह डेटा के वास्तविक जीवनकाल को प्रतिबिंबित करे।
    ///
    ///   विशेष रूप से, इस जीवनकाल की अवधि के लिए, सूचक द्वारा इंगित स्मृति को उत्परिवर्तित नहीं किया जाना चाहिए (`UnsafeCell` के अंदर को छोड़कर)।
    ///
    /// यह तब भी लागू होता है जब इस पद्धति का परिणाम अप्रयुक्त हो!
    /// (प्रारंभिक होने के बारे में अभी तक पूरी तरह से तय नहीं किया गया है, लेकिन जब तक ऐसा नहीं होता है, तब तक एकमात्र सुरक्षित तरीका यह सुनिश्चित करना है कि वे वास्तव में प्रारंभ हो गए हैं।)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `self` सभी को पूरा करता है
        // संदर्भ के लिए आवश्यकताएँ।
        unsafe { &*self.as_ptr() }
    }

    /// मान के लिए एक अद्वितीय संदर्भ देता है।यदि मान को प्रारंभ नहीं किया जा सकता है, तो इसके बजाय [`as_uninit_mut`] का उपयोग किया जाना चाहिए।
    ///
    /// साझा समकक्ष के लिए [`as_ref`] देखें।
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// इस विधि को कॉल करते समय, आपको यह सुनिश्चित करना होगा कि निम्नलिखित सभी सत्य हैं:
    ///
    /// * सूचक को ठीक से संरेखित किया जाना चाहिए।
    ///
    /// * यह [the module documentation] में परिभाषित अर्थ में "dereferencable" होना चाहिए।
    ///
    /// * पॉइंटर को `T` के आरंभिक उदाहरण को इंगित करना चाहिए।
    ///
    /// * आपको Rust के अलियासिंग नियमों को लागू करना होगा, क्योंकि लौटा हुआ जीवनकाल `'a` मनमाने ढंग से चुना गया है और जरूरी नहीं कि यह डेटा के वास्तविक जीवनकाल को प्रतिबिंबित करे।
    ///
    ///   विशेष रूप से, इस जीवनकाल की अवधि के लिए, पॉइंटर द्वारा इंगित की गई मेमोरी को किसी अन्य पॉइंटर के माध्यम से एक्सेस (पढ़ा या लिखित) नहीं किया जाना चाहिए।
    ///
    /// यह तब भी लागू होता है जब इस पद्धति का परिणाम अप्रयुक्त हो!
    /// (प्रारंभिक होने के बारे में अभी तक पूरी तरह से तय नहीं किया गया है, लेकिन जब तक ऐसा नहीं होता है, तब तक एकमात्र सुरक्षित तरीका यह सुनिश्चित करना है कि वे वास्तव में प्रारंभ हो गए हैं।)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `self` सभी को पूरा करता है
        // एक परिवर्तनीय संदर्भ के लिए आवश्यकताएँ।
        unsafe { &mut *self.as_ptr() }
    }

    /// किसी अन्य प्रकार के सूचक को कास्ट करता है।
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // सुरक्षा: `self` एक `NonNull` सूचक है जो अनिवार्य रूप से गैर-शून्य है
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// पतले पॉइंटर और लंबाई से एक नॉन-नल रॉ स्लाइस बनाता है।
    ///
    /// `len` तर्क **तत्वों** की संख्या है, बाइट्स की संख्या नहीं।
    ///
    /// यह फ़ंक्शन सुरक्षित है, लेकिन वापसी मान को संदर्भित करना असुरक्षित है।
    /// स्लाइस सुरक्षा आवश्यकताओं के लिए [`slice::from_raw_parts`] का दस्तावेज़ीकरण देखें।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // पहले तत्व के लिए पॉइंटर से शुरू करते समय एक स्लाइस पॉइंटर बनाएं
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (ध्यान दें कि यह उदाहरण कृत्रिम रूप से इस पद्धति के उपयोग को प्रदर्शित करता है, लेकिन `लेट स्लाइस= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // सुरक्षा: `data` एक `NonNull` सूचक है जो अनिवार्य रूप से गैर-शून्य है
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// एक गैर-शून्य कच्चे स्लाइस की लंबाई देता है।
    ///
    /// लौटाया गया मान **तत्वों** की संख्या है, बाइट्स की संख्या नहीं।
    ///
    /// यह फ़ंक्शन सुरक्षित है, तब भी जब नॉन-नल रॉ स्लाइस को स्लाइस के लिए डीरेफरेंस नहीं किया जा सकता है क्योंकि पॉइंटर के पास वैध पता नहीं है।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// स्लाइस के बफर में एक गैर-शून्य सूचक देता है।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // सुरक्षा: हम जानते हैं कि `self` गैर-शून्य है।
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// स्लाइस के बफर में एक कच्चा सूचक लौटाता है।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// संभवत: अप्रारंभीकृत मानों के एक स्लाइस के लिए एक साझा संदर्भ देता है।[`as_ref`] के विपरीत, इसके लिए यह आवश्यक नहीं है कि मान को इनिशियलाइज़ किया जाए।
    ///
    /// परिवर्तनीय समकक्ष के लिए [`as_uninit_slice_mut`] देखें।
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// इस विधि को कॉल करते समय, आपको यह सुनिश्चित करना होगा कि निम्नलिखित सभी सत्य हैं:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` कई बाइट्स पढ़ने के लिए पॉइंटर [valid] होना चाहिए, और इसे ठीक से संरेखित किया जाना चाहिए।इसका मतलब विशेष रूप से है:
    ///
    ///     * इस स्लाइस की पूरी मेमोरी रेंज एक ही आवंटित वस्तु के भीतर समाहित होनी चाहिए!
    ///       स्लाइस कई आवंटित वस्तुओं में कभी नहीं फैल सकते हैं।
    ///
    ///     * पॉइंटर को शून्य-लंबाई वाले स्लाइस के लिए भी संरेखित किया जाना चाहिए।
    ///     इसका एक कारण यह है कि एनम लेआउट ऑप्टिमाइज़ेशन संदर्भों (किसी भी लंबाई के स्लाइस सहित) पर निर्भर हो सकता है और उन्हें अन्य डेटा से अलग करने के लिए गैर-शून्य हो सकता है।
    ///
    ///     आप एक पॉइंटर प्राप्त कर सकते हैं जो [`NonNull::dangling()`] का उपयोग करके शून्य-लंबाई वाले स्लाइस के लिए `data` के रूप में प्रयोग करने योग्य है।
    ///
    /// * स्लाइस का कुल आकार `ptr.len() * mem::size_of::<T>()` `isize::MAX` से बड़ा नहीं होना चाहिए।
    ///   [`pointer::offset`] के सुरक्षा दस्तावेज देखें।
    ///
    /// * आपको Rust के अलियासिंग नियमों को लागू करना होगा, क्योंकि लौटा हुआ जीवनकाल `'a` मनमाने ढंग से चुना गया है और जरूरी नहीं कि यह डेटा के वास्तविक जीवनकाल को प्रतिबिंबित करे।
    ///   विशेष रूप से, इस जीवनकाल की अवधि के लिए, सूचक द्वारा इंगित स्मृति को उत्परिवर्तित नहीं किया जाना चाहिए (`UnsafeCell` के अंदर को छोड़कर)।
    ///
    /// यह तब भी लागू होता है जब इस पद्धति का परिणाम अप्रयुक्त हो!
    ///
    /// [`slice::from_raw_parts`] भी देखें।
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // सुरक्षा: कॉल करने वाले को `as_uninit_slice` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// संभवतः अप्रारंभीकृत मानों के एक स्लाइस के लिए एक अद्वितीय संदर्भ देता है।[`as_mut`] के विपरीत, इसके लिए यह आवश्यक नहीं है कि मान को इनिशियलाइज़ किया जाए।
    ///
    /// साझा समकक्ष के लिए [`as_uninit_slice`] देखें।
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// इस विधि को कॉल करते समय, आपको यह सुनिश्चित करना होगा कि निम्नलिखित सभी सत्य हैं:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` कई बाइट्स पढ़ने और लिखने के लिए पॉइंटर [valid] होना चाहिए, और इसे ठीक से संरेखित किया जाना चाहिए।इसका मतलब विशेष रूप से है:
    ///
    ///     * इस स्लाइस की पूरी मेमोरी रेंज एक ही आवंटित वस्तु के भीतर समाहित होनी चाहिए!
    ///       स्लाइस कई आवंटित वस्तुओं में कभी नहीं फैल सकते हैं।
    ///
    ///     * पॉइंटर को शून्य-लंबाई वाले स्लाइस के लिए भी संरेखित किया जाना चाहिए।
    ///     इसका एक कारण यह है कि एनम लेआउट ऑप्टिमाइज़ेशन संदर्भों (किसी भी लंबाई के स्लाइस सहित) पर निर्भर हो सकता है और उन्हें अन्य डेटा से अलग करने के लिए गैर-शून्य हो सकता है।
    ///
    ///     आप एक पॉइंटर प्राप्त कर सकते हैं जो [`NonNull::dangling()`] का उपयोग करके शून्य-लंबाई वाले स्लाइस के लिए `data` के रूप में प्रयोग करने योग्य है।
    ///
    /// * स्लाइस का कुल आकार `ptr.len() * mem::size_of::<T>()` `isize::MAX` से बड़ा नहीं होना चाहिए।
    ///   [`pointer::offset`] के सुरक्षा दस्तावेज देखें।
    ///
    /// * आपको Rust के अलियासिंग नियमों को लागू करना होगा, क्योंकि लौटा हुआ जीवनकाल `'a` मनमाने ढंग से चुना गया है और जरूरी नहीं कि यह डेटा के वास्तविक जीवनकाल को प्रतिबिंबित करे।
    ///   विशेष रूप से, इस जीवनकाल की अवधि के लिए, पॉइंटर द्वारा इंगित की गई मेमोरी को किसी अन्य पॉइंटर के माध्यम से एक्सेस (पढ़ा या लिखित) नहीं किया जाना चाहिए।
    ///
    /// यह तब भी लागू होता है जब इस पद्धति का परिणाम अप्रयुक्त हो!
    ///
    /// [`slice::from_raw_parts_mut`] भी देखें।
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // यह सुरक्षित है क्योंकि `memory` कई बाइट्स `memory.len()` के लिए पढ़ने और लिखने के लिए मान्य है।
    /// // ध्यान दें कि यहां `memory.as_mut()` को कॉल करने की अनुमति नहीं है क्योंकि सामग्री को प्रारंभ नहीं किया जा सकता है।
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // सुरक्षा: कॉल करने वाले को `as_uninit_slice_mut` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// बाउंड चेकिंग किए बिना, किसी तत्व या सबलाइस के लिए एक कच्चा सूचक लौटाता है।
    ///
    /// इस विधि को आउट-ऑफ-बाउंड इंडेक्स के साथ कॉल करना या जब `self` dereferencable नहीं है, तब भी *[अपरिभाषित व्यवहार]* होता है, भले ही परिणामी पॉइंटर का उपयोग न किया गया हो।
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // सुरक्षा: कॉलर सुनिश्चित करता है कि `self` dereferencable है और `index` इन-बाउंड है।
        // परिणामस्वरूप, परिणामी सूचक NULL नहीं हो सकता।
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // सुरक्षा: एक अद्वितीय सूचक शून्य नहीं हो सकता है, इसलिए इसके लिए शर्तें
        // new_unchecked() सम्मान किया जाता है।
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // सुरक्षा: एक परिवर्तनीय संदर्भ शून्य नहीं हो सकता।
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // सुरक्षा: एक संदर्भ शून्य नहीं हो सकता, इसलिए इसके लिए शर्तें conditions
        // new_unchecked() सम्मान किया जाता है।
        unsafe { NonNull { pointer: reference as *const T } }
    }
}