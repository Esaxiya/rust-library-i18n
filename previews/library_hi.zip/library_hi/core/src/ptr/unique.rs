use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// कच्चे गैर-शून्य `*mut T` के चारों ओर एक आवरण जो इंगित करता है कि इस आवरण का स्वामी संदर्भ का स्वामी है।
/// `Box<T>`, `Vec<T>`, `String`, और `HashMap<K, V>` जैसे अमूर्त निर्माण के लिए उपयोगी।
///
/// `*mut T` के विपरीत, `Unique<T>` "as if" का व्यवहार करता है यह `T` का एक उदाहरण था।
/// यह `Send`/`Sync` लागू करता है यदि `T` `Send`/`Sync` है।
/// इसका तात्पर्य यह भी है कि जिस तरह की मजबूत अलियासिंग गारंटी `T` के उदाहरण की उम्मीद कर सकती है:
/// पॉइंटर के रेफरेंस को अपने यूनिक के लिए एक यूनिक पाथ के बिना संशोधित नहीं किया जाना चाहिए।
///
/// यदि आप अनिश्चित हैं कि आपके उद्देश्यों के लिए `Unique` का उपयोग करना सही है या नहीं, तो `NonNull` का उपयोग करने पर विचार करें, जिसमें कमजोर शब्दार्थ है।
///
///
/// `*mut T` के विपरीत, सूचक हमेशा गैर-शून्य होना चाहिए, भले ही सूचक को कभी भी संदर्भित न किया गया हो।
/// ऐसा इसलिए है ताकि एनम इस निषिद्ध मूल्य का उपयोग एक विवेचक के रूप में कर सकें-`Option<Unique<T>>` का आकार `Unique<T>` के समान है।
/// हालांकि पॉइंटर अभी भी लटक सकता है अगर इसे संदर्भित नहीं किया गया है।
///
/// `*mut T` के विपरीत, `Unique<T>` `T` से अधिक सहसंयोजक है।
/// यह किसी भी प्रकार के लिए हमेशा सही होना चाहिए जो Unique की एलियासिंग आवश्यकताओं को पूरा करता है।
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: इस मार्कर का विचरण के लिए कोई परिणाम नहीं है, लेकिन यह आवश्यक है
    // ड्रॉपक के लिए यह समझने के लिए कि हम तार्किक रूप से एक `T` के मालिक हैं।
    //
    // विवरण के लिए देखें:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` पॉइंटर्स `Send` हैं यदि `T` `Send` है क्योंकि वे जिस डेटा का संदर्भ देते हैं वह अनजान है।
/// ध्यान दें कि यह अलियासिंग इनवेरिएंट टाइप सिस्टम द्वारा लागू नहीं किया गया है;`Unique` का उपयोग करने वाले अमूर्त को इसे लागू करना चाहिए।
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` पॉइंटर्स `Sync` हैं यदि `T` `Sync` है क्योंकि वे जिस डेटा का संदर्भ देते हैं वह अनजान है।
/// ध्यान दें कि यह अलियासिंग इनवेरिएंट टाइप सिस्टम द्वारा लागू नहीं किया गया है;`Unique` का उपयोग करने वाले अमूर्त को इसे लागू करना चाहिए।
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// एक नया `Unique` बनाता है जो झूल रहा है, लेकिन अच्छी तरह से संरेखित है।
    ///
    /// यह उन प्रकारों को प्रारंभ करने के लिए उपयोगी है जो आलसी आवंटित करते हैं, जैसे `Vec::new` करता है।
    ///
    /// ध्यान दें कि सूचक मान संभावित रूप से `T` के लिए एक वैध सूचक का प्रतिनिधित्व कर सकता है, जिसका अर्थ है कि इसे "not yet initialized" प्रहरी मान के रूप में उपयोग नहीं किया जाना चाहिए।
    /// आलसी आवंटित प्रकारों को किसी अन्य माध्यम से आरंभीकरण को ट्रैक करना चाहिए।
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // सुरक्षा: mem::align_of() एक वैध, गैर-शून्य सूचक देता है।
        // इस प्रकार new_unchecked() को कॉल करने की शर्तों का सम्मान किया जाता है।
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// एक नया `Unique` बनाता है।
    ///
    /// # Safety
    ///
    /// `ptr` गैर-शून्य होना चाहिए।
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `ptr` गैर-शून्य है।
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// यदि `ptr` गैर-शून्य है, तो एक नया `Unique` बनाता है।
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // सुरक्षा: सूचक की पहले ही जाँच की जा चुकी है और यह रिक्त नहीं है।
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// अंतर्निहित `*mut` सूचक प्राप्त करता है।
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// सामग्री को संदर्भित करता है।
    ///
    /// परिणामी जीवनकाल स्वयं के लिए बाध्य है इसलिए यह "as if" व्यवहार करता है यह वास्तव में T का एक उदाहरण था जो उधार लिया जा रहा है।
    /// यदि लंबे समय तक (unbound) जीवनकाल की आवश्यकता है, तो `&*my_ptr.as_ptr()` का उपयोग करें।
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `self` सभी को पूरा करता है
        // संदर्भ के लिए आवश्यकताएँ।
        unsafe { &*self.as_ptr() }
    }

    /// सामग्री को परस्पर संदर्भित करता है।
    ///
    /// परिणामी जीवनकाल स्वयं के लिए बाध्य है इसलिए यह "as if" व्यवहार करता है यह वास्तव में T का एक उदाहरण था जो उधार लिया जा रहा है।
    /// यदि लंबे समय तक (unbound) जीवनकाल की आवश्यकता है, तो `&mut *my_ptr.as_ptr()` का उपयोग करें।
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `self` सभी को पूरा करता है
        // एक परिवर्तनीय संदर्भ के लिए आवश्यकताएँ।
        unsafe { &mut *self.as_ptr() }
    }

    /// किसी अन्य प्रकार के सूचक को कास्ट करता है।
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // सुरक्षा: Unique::new_unchecked() एक नया अनूठा और जरूरतों का निर्माण करता है
        // दिया गया पॉइंटर शून्य नहीं होना चाहिए।
        // चूंकि हम स्वयं को एक सूचक के रूप में पारित कर रहे हैं, यह शून्य नहीं हो सकता है।
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // सुरक्षा: एक परिवर्तनीय संदर्भ शून्य नहीं हो सकता
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}