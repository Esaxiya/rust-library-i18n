#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// किसी भी पॉइंट-टू प्रकार का सूचक मेटाडेटा प्रकार प्रदान करता है।
///
/// # सूचक मेटाडेटा
///
/// Rust में कच्चे सूचक प्रकार और संदर्भ प्रकार को दो भागों से बना माना जा सकता है:
/// एक डेटा पॉइंटर जिसमें मान का मेमोरी एड्रेस और कुछ मेटाडेटा होता है।
///
/// सांख्यिकीय रूप से आकार के प्रकारों के लिए (जो `Sized` traits लागू करते हैं) और साथ ही `extern` प्रकारों के लिए, पॉइंटर्स को "पतला" कहा जाता है: मेटाडेटा शून्य-आकार का होता है और इसका प्रकार `()` होता है।
///
///
/// [dynamically-sized types][dst] के पॉइंटर्स को "चौड़ा" या "वसा" कहा जाता है, उनके पास गैर-शून्य-आकार का मेटाडेटा होता है:
///
/// * उन संरचनाओं के लिए जिनका अंतिम क्षेत्र DST है, मेटाडेटा अंतिम फ़ील्ड का मेटाडेटा है
/// * `str` प्रकार के लिए, मेटाडेटा बाइट्स में `usize`. के रूप में लंबाई है
/// * `[T]` जैसे स्लाइस प्रकारों के लिए, मेटाडेटा आइटम में `usize` के रूप में लंबाई है
/// * trait ऑब्जेक्ट जैसे `dyn SomeTrait` के लिए, मेटाडेटा [`DynMetadata<Self>`][DynMetadata] है (उदा. `DynMetadata<dyn SomeTrait>`)
///
/// future में, Rust भाषा नए प्रकार के प्रकार प्राप्त कर सकती है जिसमें विभिन्न सूचक मेटाडेटा होते हैं।
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// इस trait का बिंदु इसका `Metadata` संबद्ध प्रकार है, जो ऊपर वर्णित अनुसार `()` या `usize` या `DynMetadata<_>` है।
/// यह स्वचालित रूप से हर प्रकार के लिए लागू किया जाता है।
/// इसे एक सामान्य संदर्भ में लागू किया जा सकता है, यहां तक कि बिना किसी बाध्यता के भी।
///
/// # Usage
///
/// कच्चे पॉइंटर्स को उनके [`to_raw_parts`] विधि के साथ डेटा पते और मेटाडेटा घटकों में विघटित किया जा सकता है।
///
/// वैकल्पिक रूप से, केवल मेटाडेटा को [`metadata`] फ़ंक्शन के साथ निकाला जा सकता है।
/// एक संदर्भ [`metadata`] को पारित किया जा सकता है और निहित रूप से मजबूर किया जा सकता है।
///
/// (possibly-wide) पॉइंटर को उसके पते और मेटाडेटा से [`from_raw_parts`] या [`from_raw_parts_mut`] के साथ वापस एक साथ रखा जा सकता है।
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// पॉइंटर्स में मेटाडेटा का प्रकार और `Self` के संदर्भ।
    #[lang = "metadata_type"]
    // NOTE: trait bounds को `static_assert_expected_bounds_for_metadata`. में रखें
    //
    // `library/core/src/ptr/metadata.rs` में यहां उन लोगों के साथ समन्वयित करें:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// इस trait उपनाम को लागू करने वाले प्रकारों के संकेत "पतले" हैं।
///
/// इसमें स्थिर रूप से-`आकार' प्रकार और `extern` प्रकार शामिल हैं।
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait उपनाम भाषा में स्थिर होने से पहले इसे स्थिर न करें?
pub trait Thin = Pointee<Metadata = ()>;

/// एक सूचक के मेटाडेटा घटक को निकालें।
///
/// `*mut T`, `&T`, या `&mut T` प्रकार के मान सीधे इस फ़ंक्शन में पारित किए जा सकते हैं क्योंकि वे स्पष्ट रूप से `* const T` के लिए बाध्य होते हैं।
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // सुरक्षा: `PtrRepr` संघ से मूल्य तक पहुंचना सुरक्षित है क्योंकि *const T
    // और PtrComponents<T>एक ही मेमोरी लेआउट है।
    // केवल std ही यह गारंटी दे सकता है।
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// डेटा पते और मेटाडेटा से (possibly-wide) रॉ पॉइंटर बनाता है।
///
/// यह फ़ंक्शन सुरक्षित है, लेकिन लौटा हुआ सूचक आवश्यक रूप से dereference के लिए सुरक्षित नहीं है।
/// स्लाइस के लिए, सुरक्षा आवश्यकताओं के लिए [`slice::from_raw_parts`] का दस्तावेज़ीकरण देखें।
/// trait ऑब्जेक्ट्स के लिए, मेटाडेटा को एक पॉइंटर से उसी अंतर्निहित इरेज़ किए गए प्रकार में आना चाहिए।
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // सुरक्षा: `PtrRepr` संघ से मूल्य तक पहुंचना सुरक्षित है क्योंकि *const T
    // और PtrComponents<T>एक ही मेमोरी लेआउट है।
    // केवल std ही यह गारंटी दे सकता है।
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// [`from_raw_parts`] के समान कार्य करता है, सिवाय इसके कि एक कच्चा `*mut` पॉइंटर लौटाया जाता है, जो कि एक कच्चे `* const` पॉइंटर के विपरीत है।
///
///
/// अधिक जानकारी के लिए [`from_raw_parts`] का दस्तावेज़ीकरण देखें।
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // सुरक्षा: `PtrRepr` संघ से मूल्य तक पहुंचना सुरक्षित है क्योंकि *const T
    // और PtrComponents<T>एक ही मेमोरी लेआउट है।
    // केवल std ही यह गारंटी दे सकता है।
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` बाउंड से बचने के लिए मैन्युअल इम्प्लांट की आवश्यकता है।
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` बाउंड से बचने के लिए मैन्युअल इम्प्लांट की आवश्यकता है।
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait ऑब्जेक्ट प्रकार के लिए मेटाडेटा।
///
/// यह एक vtable (वर्चुअल कॉल टेबल) के लिए एक सूचक है जो trait ऑब्जेक्ट के अंदर संग्रहीत ठोस प्रकार में हेरफेर करने के लिए सभी आवश्यक जानकारी का प्रतिनिधित्व करता है।
/// vtable विशेष रूप से इसमें शामिल हैं:
///
/// * आकार टाइप करें
/// * संरेखण टाइप करें
/// * प्रकार के `drop_in_place` impl के लिए एक सूचक (सादे-पुराने-डेटा के लिए नो-ऑप हो सकता है)
/// * trait. के प्रकार के कार्यान्वयन के लिए सभी विधियों के संकेत
///
/// ध्यान दें कि पहले तीन विशेष हैं क्योंकि वे किसी भी trait ऑब्जेक्ट को आवंटित करने, छोड़ने और हटाने के लिए आवश्यक हैं।
///
/// इस संरचना को एक प्रकार के पैरामीटर के साथ नाम देना संभव है जो `dyn` trait ऑब्जेक्ट नहीं है (उदाहरण के लिए `DynMetadata<u64>`) लेकिन उस संरचना का सार्थक मान प्राप्त करने के लिए नहीं।
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// सभी vtables का सामान्य उपसर्ग।इसके बाद trait विधियों के लिए फ़ंक्शन पॉइंटर्स हैं।
///
/// `DynMetadata::size_of` आदि का निजी कार्यान्वयन विवरण।
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// इस vtable से संबद्ध प्रकार का आकार लौटाता है।
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// इस vtable से संबद्ध प्रकार का संरेखण लौटाता है।
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// `Layout` के रूप में आकार और संरेखण को एक साथ लौटाता है
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // सुरक्षा: संकलक ने इस vtable को एक ठोस Rust प्रकार के लिए उत्सर्जित किया जो
        // एक वैध लेआउट के लिए जाना जाता है।`Layout::for_value` के समान तर्क।
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` सीमा से बचने के लिए आवश्यक मैनुअल इम्प्लांट्स।

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}