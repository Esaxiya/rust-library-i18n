#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! विदेशी फ़ंक्शन इंटरफ़ेस (FFI) बाइंडिंग से संबंधित उपयोगिताएँ।

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// [pointer] के रूप में उपयोग किए जाने पर C के `void` प्रकार के बराबर।
///
/// संक्षेप में, `*const c_void`, C के `const void*` के बराबर है और `*mut c_void`, C के `void*` के बराबर है।
/// उस ने कहा, यह C के `void` रिटर्न प्रकार के समान *नहीं* है, जो Rust का `()` प्रकार है।
///
/// FFI में अपारदर्शी प्रकारों के लिए पॉइंटर्स को मॉडल करने के लिए, `extern type` के स्थिर होने तक, एक खाली बाइट सरणी के आसपास newtype रैपर का उपयोग करने की अनुशंसा की जाती है।
///
/// विवरण के लिए [Nomicon] देखें।
///
/// कोई `std::os::raw::c_void` का उपयोग कर सकता है यदि वे पुराने Rust कंपाइलर को 1.1.0 तक सपोर्ट करना चाहते हैं।
/// Rust 1.30.0 के बाद, इसे इस परिभाषा द्वारा फिर से निर्यात किया गया था।
/// अधिक जानकारी के लिए कृपया [RFC 2521] पढ़ें।
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// एनबी, एलएलवीएम के लिए शून्य सूचक प्रकार को पहचानने के लिए और एक्स 00 एक्स जैसे विस्तार कार्यों द्वारा, हमें इसे एलएलवीएम बिटकोड में i8 * के रूप में प्रदर्शित करने की आवश्यकता है।
// यहां इस्तेमाल किया गया एनम यह सुनिश्चित करता है और केवल निजी वेरिएंट होने से "raw" प्रकार के दुरुपयोग को रोकता है।
// हमें दो प्रकारों की आवश्यकता है, क्योंकि संकलक अन्यथा repr विशेषता के बारे में शिकायत करता है और हमें कम से कम एक संस्करण की आवश्यकता होती है अन्यथा एनम निर्जन होगा और कम से कम ऐसे पॉइंटर्स को डीरेफरेंस करना यूबी होगा।
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list` का मूल कार्यान्वयन।
// नाम WIP है, अभी के लिए `VaListImpl` का उपयोग कर रहा है।
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` पर अपरिवर्तनीय, इसलिए प्रत्येक `VaListImpl<'f>` ऑब्जेक्ट उस फ़ंक्शन के क्षेत्र से जुड़ा हुआ है जिसे परिभाषित किया गया है
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 एक `va_list` का ABI कार्यान्वयन।
/// अधिक जानकारी के लिए [AArch64 Procedure Call Standard] देखें।
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC एक `va_list` का ABI कार्यान्वयन।
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 एक `va_list` का ABI कार्यान्वयन।
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list`. के लिए एक आवरण
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` को `VaList` में कनवर्ट करें जो C के `va_list` के साथ बाइनरी-संगत है।
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` को `VaList` में कनवर्ट करें जो C के `va_list` के साथ बाइनरी-संगत है।
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait को सार्वजनिक इंटरफेस में उपयोग करने की आवश्यकता है, हालांकि, trait को ही इस मॉड्यूल के बाहर उपयोग करने की अनुमति नहीं दी जानी चाहिए।
// उपयोगकर्ताओं को एक नए प्रकार के लिए trait को लागू करने की अनुमति देना (जिससे va_arg आंतरिक को नए प्रकार पर उपयोग करने की अनुमति मिलती है) अपरिभाषित व्यवहार का कारण बन सकता है।
//
// FIXME(dlrobertson): सार्वजनिक इंटरफ़ेस में VaArgSafe trait का उपयोग करने के लिए, लेकिन यह भी सुनिश्चित करने के लिए कि इसे कहीं और उपयोग नहीं किया जा सकता है, trait को एक निजी मॉड्यूल के भीतर सार्वजनिक होना चाहिए।
// एक बार RFC २१४५ के लागू हो जाने के बाद इसे सुधारने के बारे में सोचें।
//
//
//
//
mod sealed_trait {
    /// Trait जो [super::VaListImpl::arg] के साथ अनुमत प्रकारों का उपयोग करने की अनुमति देता है।
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// अगले तर्क के लिए अग्रिम।
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // सुरक्षा: कॉल करने वाले को `va_arg` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
        unsafe { va_arg(self) }
    }

    /// `va_list` को वर्तमान स्थान पर कॉपी करता है।
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // सुरक्षा: कॉल करने वाले को `va_end` के सुरक्षा अनुबंध को बनाए रखना चाहिए।
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // सुरक्षा: हम `MaybeUninit` को लिखते हैं, इस प्रकार इसे इनिशियलाइज़ किया जाता है और `assume_init` कानूनी है
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: इसे `va_end` पर कॉल करना चाहिए, लेकिन इसका कोई स्पष्ट तरीका नहीं है
        // गारंटी है कि `drop` हमेशा अपने कॉलर में इनलाइन हो जाता है, इसलिए `va_end` को उसी फ़ंक्शन से सीधे `va_copy` के रूप में कॉल किया जाएगा।
        // `man va_end` बताता है कि C को इसकी आवश्यकता है, और LLVM मूल रूप से C शब्दार्थ का अनुसरण करता है, इसलिए हमें यह सुनिश्चित करने की आवश्यकता है कि `va_end` को हमेशा `va_copy` के समान फ़ंक्शन से कॉल किया जाए।
        //
        // अधिक जानकारी के लिए, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // यह अभी के लिए काम करता है, क्योंकि `va_end` सभी मौजूदा LLVM लक्ष्यों पर एक नो-ऑप है।
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` या `va_copy` के साथ आरंभीकरण के बाद arglist `ap` को नष्ट करें।
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// arglist `src` के वर्तमान स्थान को arglist `dst` में कॉपी करता है।
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `va_list` `ap` से `T` प्रकार का तर्क लोड करता है और तर्क `ap` अंक को बढ़ाता है।
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}