use crate::future::Future;

/// `Future` में रूपांतरण।
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// उत्पादन पूरा होने पर future उत्पादन करेगा।
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// हम इसे किस प्रकार के future में बदल रहे हैं?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// एक मान से future बनाता है।
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}