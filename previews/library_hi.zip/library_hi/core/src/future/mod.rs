#![stable(feature = "futures_api", since = "1.36.0")]

//! अतुल्यकालिक मान।

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// इस प्रकार की आवश्यकता है क्योंकि:
///
/// a) जेनरेटर `for<'a, 'b> Generator<&'a mut Context<'b>>` को लागू नहीं कर सकते हैं, इसलिए हमें एक रॉ पॉइंटर पास करना होगा (<https://github.com/rust-lang/rust/issues/68923> देखें)।
///
/// b) रॉ पॉइंटर्स और `NonNull` `Send` या `Sync` नहीं हैं, जिससे हर एक future non-Send/Sync भी बन जाएगा, और हम ऐसा नहीं चाहते हैं।
///
/// यह `.await` के HIR कम करने को भी सरल करता है।
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// एक जनरेटर को future में लपेटें।
///
/// यह फ़ंक्शन नीचे एक `GenFuture` देता है, लेकिन बेहतर त्रुटि संदेश (`GenFuture<[closure.....]>` के बजाय `impl Future`) देने के लिए इसे `impl Trait` में छुपाता है।
///
// `const async fn` से उबरने के बाद अतिरिक्त त्रुटियों से बचने के लिए यह `const` है
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // हम इस तथ्य पर भरोसा करते हैं कि अंतर्निहित जनरेटर में सेल्फ-रेफरेंशियल उधार बनाने के लिए async/await futures अचल हैं।
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // सुरक्षा: सुरक्षित है क्योंकि हम !Unpin + !Drop हैं, और यह केवल एक क्षेत्र प्रक्षेपण है।
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // `&mut Context` को `NonNull` रॉ पॉइंटर में बदलते हुए, जनरेटर को फिर से शुरू करें।
            // `.await` लोअरिंग सुरक्षित रूप से उसे वापस `&mut Context` में डाल देगा।
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // सुरक्षा: कॉलर को गारंटी देनी चाहिए कि `cx.0` एक वैध सूचक है valid
    // जो एक परिवर्तनीय संदर्भ के लिए सभी आवश्यकताओं को पूरा करता है।
    unsafe { &mut *cx.0.as_ptr().cast() }
}