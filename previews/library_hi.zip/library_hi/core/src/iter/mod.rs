//! संगत बाहरी पुनरावृत्ति।
//!
//! यदि आपने स्वयं को किसी प्रकार के संग्रह के साथ पाया है, और उक्त संग्रह के तत्वों पर एक ऑपरेशन करने की आवश्यकता है, तो आप जल्दी से 'iterators' में चले जाएंगे।
//! मुहावरेदार Rust कोड में Iterators का अत्यधिक उपयोग किया जाता है, इसलिए यह उनके साथ परिचित होने के लायक है।
//!
//! अधिक व्याख्या करने से पहले, आइए इस बारे में बात करें कि यह मॉड्यूल कैसे संरचित है:
//!
//! # Organization
//!
//! यह मॉड्यूल बड़े पैमाने पर प्रकार द्वारा आयोजित किया जाता है:
//!
//! * [Traits] मुख्य भाग हैं: ये traits परिभाषित करते हैं कि किस प्रकार के इटरेटर मौजूद हैं और आप उनके साथ क्या कर सकते हैं।इन traits के तरीके कुछ अतिरिक्त अध्ययन समय लगाने के लायक हैं।
//! * [Functions] कुछ बुनियादी इटरेटर बनाने के लिए कुछ उपयोगी तरीके प्रदान करें।
//! * [Structs] अक्सर इस मॉड्यूल के traits पर विभिन्न तरीकों के रिटर्न प्रकार होते हैं।आप आमतौर पर `struct` के बजाय `struct` बनाने वाली विधि को देखना चाहेंगे।
//! क्यों के बारे में अधिक विवरण के लिए, '[कार्यान्वयन इटरेटर](#कार्यान्वयन-पुनरावृत्ति)' देखें।
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! इतना ही!आइए इटरेटर्स में खुदाई करें।
//!
//! # Iterator
//!
//! इस मॉड्यूल का दिल और आत्मा [`Iterator`] trait है।[`Iterator`] का मूल इस तरह दिखता है:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! एक पुनरावर्तक की एक विधि है, [`next`], जिसे कॉल करने पर, एक [`Option`]`. लौटाता है<Item>`.
//! [`next`] जब तक तत्व हैं, तब तक [`Some(Item)`] वापस आ जाएगा, और एक बार वे सभी समाप्त हो जाने के बाद, `None` को यह इंगित करने के लिए वापस कर देंगे कि पुनरावृत्ति समाप्त हो गई है।
//! अलग-अलग पुनरावर्तक पुनरावृत्ति को फिर से शुरू करना चुन सकते हैं, और इसलिए [`next`] को फिर से कॉल करना अंततः किसी बिंदु पर [`Some(Item)`] को फिर से वापस करना शुरू कर सकता है या नहीं (उदाहरण के लिए, [`TryIter`] देखें)।
//!
//!
//! [`Iterator`] की पूर्ण परिभाषा में कई अन्य विधियां भी शामिल हैं, लेकिन वे डिफ़ॉल्ट विधियां हैं, जिन्हें [`next`] के शीर्ष पर बनाया गया है, और इसलिए आप उन्हें निःशुल्क प्राप्त कर सकते हैं।
//!
//! इटरेटर भी कंपोजेबल होते हैं, और प्रोसेसिंग के अधिक जटिल रूपों को करने के लिए उन्हें एक साथ श्रृंखलाबद्ध करना आम बात है।अधिक विवरण के लिए नीचे दिया गया [Adapters](#adapters) अनुभाग देखें।
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # पुनरावृत्ति के तीन रूप
//!
//! तीन सामान्य तरीके हैं जो संग्रह से इटरेटर बना सकते हैं:
//!
//! * `iter()`, जो `&T` से अधिक पुनरावृत्त होता है।
//! * `iter_mut()`, जो `&mut T` से अधिक पुनरावृत्त होता है।
//! * `into_iter()`, जो `T` से अधिक पुनरावृत्त होता है।
//!
//! मानक पुस्तकालय में विभिन्न चीजें जहां उपयुक्त हो, तीनों में से एक या अधिक को लागू कर सकती हैं।
//!
//! # इटरेटर लागू करना
//!
//! अपने स्वयं के एक पुनरावर्तक बनाने में दो चरण शामिल हैं: पुनरावर्तक के राज्य को पकड़ने के लिए `struct` बनाना, और फिर उस `struct` के लिए [`Iterator`] को कार्यान्वित करना।
//! यही कारण है कि इस मॉड्यूल में इतने सारे 'स्ट्रक्चर' हैं: प्रत्येक इटरेटर और इटरेटर एडाप्टर के लिए एक है।
//!
//! आइए `Counter` नाम का एक इटरेटर बनाते हैं जो `1` से `5` तक गिना जाता है:
//!
//! ```
//! // सबसे पहले, संरचना:
//!
//! /// एक पुनरावर्तक जो एक से पांच तक गिना जाता है
//! struct Counter {
//!     count: usize,
//! }
//!
//! // हम चाहते हैं कि हमारी गिनती एक से शुरू हो, तो चलिए मदद करने के लिए एक new() विधि जोड़ते हैं।
//! // यह कड़ाई से आवश्यक नहीं है, लेकिन सुविधाजनक है।
//! // ध्यान दें कि हम `count` को शून्य पर शुरू करते हैं, हम देखेंगे कि नीचे `next()`'s कार्यान्वयन में क्यों।
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // फिर, हम अपने `Counter` के लिए `Iterator` लागू करते हैं:
//!
//! impl Iterator for Counter {
//!     // हम उपयोग के साथ गिनती करेंगे
//!     type Item = usize;
//!
//!     // next() एकमात्र आवश्यक तरीका है
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // हमारी गिनती बढ़ाओ।इसलिए हमने शून्य से शुरुआत की।
//!         self.count += 1;
//!
//!         // जांचें कि हमने गिनती पूरी की है या नहीं।
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // और अब हम इसका इस्तेमाल कर सकते हैं!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`] को इस तरह से कॉल करना दोहराव हो जाता है।Rust में एक निर्माण है जो [`next`] को आपके इटरेटर पर कॉल कर सकता है, जब तक कि यह `None` तक नहीं पहुंच जाता।आइए इसके आगे चलते हैं।
//!
//! यह भी ध्यान दें कि `Iterator` `nth` और `fold` जैसी विधियों का डिफ़ॉल्ट कार्यान्वयन प्रदान करता है जो आंतरिक रूप से `next` को कॉल करते हैं।
//! हालांकि, `nth` और `fold` जैसे तरीकों का एक कस्टम कार्यान्वयन लिखना भी संभव है यदि कोई पुनरावर्तक `next` को कॉल किए बिना उन्हें अधिक कुशलता से गणना कर सकता है।
//!
//! # `for` लूप और `IntoIterator`
//!
//! Rust का `for` लूप सिंटैक्स वास्तव में पुनरावृत्तियों के लिए चीनी है।यहाँ `for` का मूल उदाहरण दिया गया है:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! यह संख्या एक से पांच तक, प्रत्येक की अपनी लाइन पर प्रिंट करेगा।लेकिन आप यहां कुछ नोटिस करेंगे: हमने अपने vector पर एक पुनरावर्तक बनाने के लिए कभी भी कुछ भी नहीं कहा।क्या देता है?
//!
//! कुछ को एक पुनरावर्तक में परिवर्तित करने के लिए मानक पुस्तकालय में trait है: [`IntoIterator`].
//! इस trait में एक तरीका है, [`into_iter`], जो [`IntoIterator`] को लागू करने वाली चीज़ को एक पुनरावर्तक में परिवर्तित करता है।
//! आइए फिर से उस `for` लूप पर एक नज़र डालते हैं, और संकलक इसे किस रूप में परिवर्तित करता है:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust इसमें चीनी को कम करता है:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! सबसे पहले, हम मूल्य पर `into_iter()` कहते हैं।फिर, हम वापस आने वाले पुनरावर्तक से मेल खाते हैं, [`next`] को बार-बार कॉल करते हैं जब तक कि हम एक `None` नहीं देखते।
//! उस बिंदु पर, हम लूप से बाहर `break` करते हैं, और हमने पुनरावृति कर ली है।
//!
//! यहाँ एक और सूक्ष्म बात है: मानक पुस्तकालय में [`IntoIterator`] का एक दिलचस्प कार्यान्वयन है:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! दूसरे शब्दों में, सभी [`Iterator`] केवल स्वयं को वापस करके [`IntoIterator`] को लागू करते हैं।इसका मतलब दो चीजें हैं:
//!
//! 1. यदि आप [`Iterator`] लिख रहे हैं, तो आप इसे `for` लूप के साथ उपयोग कर सकते हैं।
//! 2. यदि आप एक संग्रह बना रहे हैं, तो इसके लिए [`IntoIterator`] को लागू करने से आपके संग्रह को `for` लूप के साथ उपयोग करने की अनुमति मिल जाएगी।
//!
//! # संदर्भ द्वारा पुनरावृति
//!
//! चूंकि [`into_iter()`] `self` को मान के आधार पर लेता है, एक संग्रह पर पुनरावृति करने के लिए `for` लूप का उपयोग करके उस संग्रह का उपभोग करता है।अक्सर, आप किसी संग्रह का उपभोग किए बिना उस पर पुनरावृति करना चाह सकते हैं।
//! कई संग्रह विधियों की पेशकश करते हैं जो संदर्भों पर इटरेटर प्रदान करते हैं, जिन्हें पारंपरिक रूप से क्रमशः `iter()` और `iter_mut()` कहा जाता है:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` अभी भी इस समारोह के स्वामित्व में है।
//! ```
//!
//! यदि संग्रह प्रकार `C` `iter()` प्रदान करता है, तो यह आमतौर पर `&C` के लिए `IntoIterator` को भी लागू करता है, एक कार्यान्वयन के साथ जो केवल `iter()` को कॉल करता है।
//! इसी तरह, एक संग्रह `C` जो `iter_mut()` प्रदान करता है, आमतौर पर `iter_mut()` को `&mut C` के लिए `IntoIterator` को लागू करता है।यह एक सुविधाजनक आशुलिपि सक्षम करता है:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()`. के समान
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()`. के समान
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! जबकि कई संग्रह `iter()` की पेशकश करते हैं, सभी `iter_mut()` की पेशकश नहीं करते हैं।
//! उदाहरण के लिए, [`HashSet<T>`] या [`HashMap<K, V>`] की कुंजियों को बदलने से कुंजी हैश बदलने पर संग्रह असंगत स्थिति में आ सकता है, इसलिए ये संग्रह केवल `iter()` प्रदान करते हैं।
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! ऐसे कार्य जो एक [`Iterator`] लेते हैं और दूसरा [`Iterator`] लौटाते हैं, उन्हें अक्सर 'इटरेटर एडेप्टर' कहा जाता है, क्योंकि वे 'एडेप्टर' का एक रूप हैं।
//! pattern'.
//!
//! सामान्य इटरेटर एडेप्टर में [`map`], [`take`] और [`filter`] शामिल हैं।
//! अधिक के लिए, उनके दस्तावेज़ देखें।
//!
//! यदि एक पुनरावर्तक एडाप्टर panics, पुनरावर्तक एक अनिर्दिष्ट (लेकिन स्मृति सुरक्षित) स्थिति में होगा।
//! यह स्थिति Rust के सभी संस्करणों में समान रहने की गारंटी नहीं है, इसलिए आपको घबराए हुए पुनरावर्तक द्वारा लौटाए गए सटीक मानों पर भरोसा करने से बचना चाहिए।
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! इटरेटर्स (और इटरेटर [adapters](#adapters))*आलसी* हैं। इसका मतलब है कि सिर्फ एक इटरेटर बनाने से _do_ बहुत कुछ नहीं होता है। जब तक आप [`next`] को कॉल नहीं करते तब तक वास्तव में कुछ भी नहीं होता है।
//! यह कभी-कभी भ्रम का स्रोत होता है जब केवल इसके दुष्प्रभावों के लिए एक पुनरावर्तक बनाते हैं।
//! उदाहरण के लिए, [`map`] विधि प्रत्येक तत्व पर एक क्लोजर को कॉल करती है, जिस पर वह पुनरावृति करता है:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! यह किसी भी मान को प्रिंट नहीं करेगा, क्योंकि हमने इसका उपयोग करने के बजाय केवल एक पुनरावर्तक बनाया है।संकलक हमें इस तरह के व्यवहार के बारे में चेतावनी देगा:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! इसके दुष्प्रभावों के लिए [`map`] लिखने का मुहावरेदार तरीका `for` लूप का उपयोग करना या [`for_each`] विधि को कॉल करना है:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! एक पुनरावर्तक का मूल्यांकन करने का एक अन्य सामान्य तरीका एक नया संग्रह बनाने के लिए [`collect`] विधि का उपयोग करना है।
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! इटरेटर को सीमित होने की आवश्यकता नहीं है।उदाहरण के तौर पर, एक ओपन-एंडेड रेंज एक अनंत इटरेटर है:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! अनंत इटरेटर को परिमित में बदलने के लिए [`take`] इटरेटर एडेप्टर का उपयोग करना आम है:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! यह नंबर `0` से `4` तक प्रिंट करेगा, प्रत्येक अपनी लाइन पर।
//!
//! ध्यान रखें कि अनंत पुनरावृत्तियों पर विधियां, यहां तक कि जिनके लिए परिणाम गणितीय रूप से परिमित समय में निर्धारित किया जा सकता है, समाप्त नहीं हो सकते हैं।
//! विशेष रूप से, [`min`] जैसी विधियां, जिन्हें सामान्य स्थिति में पुनरावर्तक में प्रत्येक तत्व को पार करने की आवश्यकता होती है, संभवतः किसी भी अनंत इटरेटर के लिए सफलतापूर्वक वापस नहीं आती है।
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // नहीं ओ!एक अनंत लूप!
//! // `ones.min()` एक अनंत लूप का कारण बनता है, इसलिए हम इस बिंदु तक नहीं पहुंचेंगे!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;