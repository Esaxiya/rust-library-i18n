use crate::iter::{FusedIterator, TrustedLen};

/// एक पुनरावर्तक बनाता है जो प्रदान किए गए बंद को लागू करके आलसी रूप से एक बार मूल्य उत्पन्न करता है।
///
/// यह आमतौर पर एकल मान जनरेटर को अन्य प्रकार के पुनरावृत्ति के [`chain()`] में अनुकूलित करने के लिए उपयोग किया जाता है।
/// हो सकता है कि आपके पास एक पुनरावर्तक हो जो लगभग सब कुछ शामिल करता है, लेकिन आपको एक अतिरिक्त विशेष मामले की आवश्यकता है।
/// हो सकता है कि आपके पास एक फ़ंक्शन है जो इटरेटर पर काम करता है, लेकिन आपको केवल एक मान को संसाधित करने की आवश्यकता है।
///
/// [`once()`] के विपरीत, यह फ़ंक्शन अनुरोध पर आलस्य से मान उत्पन्न करेगा।
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// use std::iter;
///
/// // एक अकेला नंबर है
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // बस एक, बस इतना ही हमें मिलता है
/// assert_eq!(None, one.next());
/// ```
///
/// एक और इटरेटर के साथ मिलकर जंजीर।
/// मान लें कि हम `.foo` निर्देशिका की प्रत्येक फ़ाइल पर पुनरावृति करना चाहते हैं, लेकिन एक कॉन्फ़िगरेशन फ़ाइल भी,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // हमें DirEntry-s के एक पुनरावर्तक से PathBufs के पुनरावर्तक में कनवर्ट करने की आवश्यकता है, इसलिए हम मानचित्र का उपयोग करते हैं
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // अब, हमारा इटरेटर सिर्फ हमारी कॉन्फिग फाइल के लिए
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // दो पुनरावृत्तियों को एक साथ एक बड़े पुनरावर्तक में श्रृंखलाबद्ध करें
/// let files = dirs.chain(config);
///
/// // यह हमें .foo के साथ-साथ .foorc में सभी फाइलें देगा
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// एक पुनरावर्तक जो प्रदान किए गए क्लोजर `F: FnOnce() -> A` को लागू करके `A` प्रकार का एकल तत्व उत्पन्न करता है।
///
///
/// यह `struct` [`once_with()`] फ़ंक्शन द्वारा बनाया गया है।
/// अधिक के लिए इसके दस्तावेज़ देखें।
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}