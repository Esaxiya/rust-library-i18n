use crate::iter::{FusedIterator, TrustedLen};

/// एक पुनरावर्तक बनाता है जो एक तत्व को बिल्कुल एक बार उत्पन्न करता है।
///
/// यह आमतौर पर एक मान को अन्य प्रकार के पुनरावृत्तियों के [`chain()`] में अनुकूलित करने के लिए उपयोग किया जाता है।
/// हो सकता है कि आपके पास एक पुनरावर्तक हो जो लगभग सब कुछ शामिल करता है, लेकिन आपको एक अतिरिक्त विशेष मामले की आवश्यकता है।
/// हो सकता है कि आपके पास एक फ़ंक्शन है जो इटरेटर पर काम करता है, लेकिन आपको केवल एक मान को संसाधित करने की आवश्यकता है।
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// use std::iter;
///
/// // एक अकेला नंबर है
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // बस एक, बस इतना ही हमें मिलता है
/// assert_eq!(None, one.next());
/// ```
///
/// एक और इटरेटर के साथ मिलकर जंजीर।
/// मान लें कि हम `.foo` निर्देशिका की प्रत्येक फ़ाइल पर पुनरावृति करना चाहते हैं, लेकिन एक कॉन्फ़िगरेशन फ़ाइल भी,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // हमें DirEntry-s के एक पुनरावर्तक से PathBufs के पुनरावर्तक में कनवर्ट करने की आवश्यकता है, इसलिए हम मानचित्र का उपयोग करते हैं
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // अब, हमारा इटरेटर सिर्फ हमारी कॉन्फिग फाइल के लिए
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // दो पुनरावृत्तियों को एक साथ एक बड़े पुनरावर्तक में श्रृंखलाबद्ध करें
/// let files = dirs.chain(config);
///
/// // यह हमें .foo के साथ-साथ .foorc में सभी फाइलें देगा
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// एक पुनरावर्तक जो एक तत्व को बिल्कुल एक बार उत्पन्न करता है।
///
/// यह `struct` [`once()`] फ़ंक्शन द्वारा बनाया गया है।अधिक के लिए इसके दस्तावेज़ देखें।
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}