use crate::iter::{FusedIterator, TrustedLen};

/// एक नया इटरेटर बनाता है जो एक ही तत्व को अंतहीन रूप से दोहराता है।
///
/// `repeat()` फ़ंक्शन एक ही मान को बार-बार दोहराता है।
///
/// `repeat()` जैसे अनंत पुनरावृत्तियों का उपयोग अक्सर [`Iterator::take()`] जैसे एडेप्टर के साथ किया जाता है, ताकि उन्हें परिमित बनाया जा सके।
///
/// यदि आपको आवश्यक इटरेटर का तत्व प्रकार `Clone` लागू नहीं करता है, या यदि आप दोहराए गए तत्व को स्मृति में नहीं रखना चाहते हैं, तो आप इसके बजाय [`repeat_with()`] फ़ंक्शन का उपयोग कर सकते हैं।
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// use std::iter;
///
/// // नंबर चार 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // हाँ, अभी भी चार
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] के साथ सीमित होना:
///
/// ```
/// use std::iter;
///
/// // वह आखिरी उदाहरण बहुत अधिक चौके थे।चलो केवल चार चौके हैं।
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... और अब हम कर चुके हैं
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// एक पुनरावर्तक जो किसी तत्व को अंतहीन रूप से दोहराता है।
///
/// यह `struct` [`repeat()`] फ़ंक्शन द्वारा बनाया गया है।अधिक के लिए इसके दस्तावेज़ देखें।
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}