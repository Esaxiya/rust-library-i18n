use crate::iter::{FusedIterator, TrustedLen};

/// एक नया पुनरावर्तक बनाता है जो प्रदान किए गए क्लोजर, पुनरावर्तक को लागू करके `A` प्रकार के तत्वों को अंतहीन रूप से दोहराता है, `F: FnMut() -> A`.
///
/// `repeat_with()` फ़ंक्शन पुनरावर्तक को बार-बार कॉल करता है।
///
/// `repeat_with()` जैसे अनंत पुनरावृत्तियों का उपयोग अक्सर [`Iterator::take()`] जैसे एडेप्टर के साथ किया जाता है, ताकि उन्हें परिमित बनाया जा सके।
///
/// यदि इटरेटर का तत्व प्रकार आपको [`Clone`] लागू करने की आवश्यकता है, और स्रोत तत्व को स्मृति में रखना ठीक है, तो आपको इसके बजाय [`repeat()`] फ़ंक्शन का उपयोग करना चाहिए।
///
///
/// `repeat_with()` द्वारा निर्मित एक पुनरावर्तक [`DoubleEndedIterator`] नहीं है।
/// यदि आपको [`DoubleEndedIterator`] वापस करने के लिए `repeat_with()` की आवश्यकता है, तो कृपया अपने उपयोग के मामले की व्याख्या करते हुए एक GitHub समस्या खोलें।
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// use std::iter;
///
/// // आइए मान लें कि हमारे पास एक प्रकार का कुछ मूल्य है जो `Clone` नहीं है या जो अभी तक स्मृति में नहीं रखना चाहता क्योंकि यह महंगा है:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // एक विशेष मूल्य हमेशा के लिए:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// उत्परिवर्तन का उपयोग करना और परिमित होना:
///
/// ```rust
/// use std::iter;
///
/// // शून्य से दो की तीसरी शक्ति तक:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... और अब हम कर चुके हैं
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// एक पुनरावर्तक जो प्रदान किए गए क्लोजर `F: FnMut() -> A` को लागू करके `A` प्रकार के तत्वों को अंतहीन रूप से दोहराता है।
///
///
/// यह `struct` [`repeat_with()`] फ़ंक्शन द्वारा बनाया गया है।
/// अधिक के लिए इसके दस्तावेज़ देखें।
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}