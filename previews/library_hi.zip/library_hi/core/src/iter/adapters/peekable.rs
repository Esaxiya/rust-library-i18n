use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// `peek()` वाला एक पुनरावर्तक जो अगले तत्व के लिए वैकल्पिक संदर्भ देता है।
///
///
/// यह `struct` [`Iterator`] पर [`peekable`] विधि द्वारा बनाया गया है।
/// अधिक के लिए इसके दस्तावेज़ देखें।
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// एक तिरछा मूल्य याद रखें, भले ही वह कोई नहीं था।
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// पीकेबल को याद रखना चाहिए कि क्या `.peek()` मेथड में कोई नहीं देखा गया है।
// यह सुनिश्चित करता है कि `.peek();.peek();` या `.peek();.next();` केवल अंतर्निहित इटरेटर को अधिकतम एक बार आगे बढ़ाता है।
// यह अपने आप इटरेटर को फ्यूज नहीं करता है।
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// इटरेटर को आगे बढ़ाए बिना next() मान का संदर्भ देता है।
    ///
    /// [`next`] की तरह, यदि कोई मान है, तो उसे `Some(T)` में लपेटा जाता है।
    /// लेकिन अगर पुनरावृत्ति खत्म हो गई है, तो `None` वापस कर दिया जाता है।
    ///
    /// [`next`]: Iterator::next
    ///
    /// क्योंकि `peek()` एक संदर्भ देता है, और कई पुनरावर्तक संदर्भों पर पुनरावृति करते हैं, संभावित रूप से भ्रमित करने वाली स्थिति हो सकती है जहां वापसी मान एक दोहरा संदर्भ है।
    /// आप इस प्रभाव को नीचे दिए गए उदाहरणों में देख सकते हैं।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() आइए देखते हैं future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // यदि हम कई बार `peek` करते हैं तो भी इटरेटर आगे नहीं बढ़ता है
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // इटरेटर समाप्त होने के बाद, `peek()` भी है
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// इटरेटर को आगे बढ़ाए बिना next() मान के लिए एक परिवर्तनीय संदर्भ देता है।
    ///
    /// [`next`] की तरह, यदि कोई मान है, तो उसे `Some(T)` में लपेटा जाता है।
    /// लेकिन अगर पुनरावृत्ति खत्म हो गई है, तो `None` वापस कर दिया जाता है।
    ///
    /// क्योंकि `peek_mut()` एक संदर्भ देता है, और कई पुनरावर्तक संदर्भों पर पुनरावृति करते हैं, संभावित रूप से भ्रमित करने वाली स्थिति हो सकती है जहां वापसी मान एक दोहरा संदर्भ है।
    /// आप इस प्रभाव को नीचे दिए गए उदाहरणों में देख सकते हैं।
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // `peek()` की तरह, हम future में इटरेटर को आगे बढ़ाए बिना देख सकते हैं।
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // इटरेटर में झांकें और परिवर्तनशील संदर्भ के पीछे मान सेट करें।
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // इटरेटर जारी रहने पर हम जो मान डालते हैं वह फिर से प्रकट होता है।
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// यदि कोई शर्त सत्य है तो इस पुनरावर्तक का अगला मान लें और वापस करें।
    /// यदि `func` इस पुनरावर्तक के अगले मान के लिए `true` लौटाता है, तो इसका उपभोग करें और इसे वापस करें।
    /// अन्यथा, `None` लौटाएं।
    /// # Examples
    /// यदि कोई संख्या 0 के बराबर है तो उसका उपभोग करें।
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // इटरेटर का पहला आइटम 0 है;भोग कीजिए।
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // लौटाया गया अगला आइटम अब 1 है, इसलिए `consume` `false` लौटाएगा।
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` अगले आइटम का मान सहेजता है यदि यह `expected` के बराबर नहीं था।
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// 10 से कम किसी भी संख्या का सेवन करें।
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // 10. से कम के सभी नंबरों का सेवन करें
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // लौटाया गया अगला मान 10. होगा
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // चूंकि हमने `self.next()` को कॉल किया था, इसलिए हमने `self.peeked` का उपभोग किया।
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// अगले आइटम का उपभोग करें और वापस करें यदि यह `expected` के बराबर है।
    /// # Example
    /// यदि कोई संख्या 0 के बराबर है तो उसका उपभोग करें।
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // इटरेटर का पहला आइटम 0 है;भोग कीजिए।
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // लौटाया गया अगला आइटम अब 1 है, इसलिए `consume` `false` लौटाएगा।
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` अगले आइटम का मान सहेजता है यदि यह `expected` के बराबर नहीं था।
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // सुरक्षा: असुरक्षित फ़ंक्शन समान आवश्यकताओं के साथ असुरक्षित फ़ंक्शन को अग्रेषित करना
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}