use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// यह trait उन शर्तों के तहत इंटरएटर-एडेप्टर पाइपलाइन में स्रोत-चरण तक संक्रमणीय पहुंच प्रदान करता है
/// * इटरेटर स्रोत `S` स्वयं `SourceIter<Source = S>` लागू करता है
/// * स्रोत और पाइपलाइन उपभोक्ता के बीच पाइपलाइन में प्रत्येक एडेप्टर के लिए इस trait का एक प्रतिनिधि कार्यान्वयन है।
///
/// जब स्रोत एक स्वामित्व वाला पुनरावर्तक संरचना होता है (जिसे आमतौर पर `IntoIter` कहा जाता है) तो यह [`FromIterator`] कार्यान्वयन में विशेषज्ञता के लिए उपयोगी हो सकता है या एक पुनरावर्तक आंशिक रूप से समाप्त होने के बाद शेष तत्वों को पुनर्प्राप्त करने के लिए उपयोगी हो सकता है।
///
///
/// ध्यान दें कि कार्यान्वयन के लिए जरूरी नहीं है कि वह पाइपलाइन के सबसे भीतरी स्रोत तक पहुंच प्रदान करे।एक स्टेटफुल इंटरमीडिएट एडेप्टर पाइपलाइन के एक हिस्से का उत्सुकता से मूल्यांकन कर सकता है और इसके आंतरिक भंडारण को स्रोत के रूप में उजागर कर सकता है।
///
/// trait असुरक्षित है क्योंकि कार्यान्वयनकर्ताओं को अतिरिक्त सुरक्षा गुणों को बनाए रखना चाहिए।
/// विवरण के लिए [`as_inner`] देखें।
///
/// # Examples
///
/// आंशिक रूप से उपभोग किए गए स्रोत को पुनः प्राप्त करना:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// एक पुनरावर्तक पाइपलाइन में एक स्रोत चरण।
    type Source: Iterator;

    /// एक पुनरावर्तक पाइपलाइन के स्रोत को पुनः प्राप्त करें।
    ///
    /// # Safety
    ///
    /// के कार्यान्वयन को उनके जीवनकाल के लिए एक ही परिवर्तनशील संदर्भ वापस करना होगा, जब तक कि एक कॉलर द्वारा प्रतिस्थापित नहीं किया जाता है।
    /// कॉलर केवल संदर्भ को बदल सकते हैं जब उन्होंने पुनरावृत्ति को रोक दिया और स्रोत निकालने के बाद इटरेटर पाइपलाइन को छोड़ दिया।
    ///
    /// इसका मतलब है कि इटरेटर एडेप्टर पुनरावृत्ति के दौरान नहीं बदलते स्रोत पर भरोसा कर सकते हैं लेकिन वे अपने ड्रॉप कार्यान्वयन में इस पर भरोसा नहीं कर सकते हैं।
    ///
    /// इस पद्धति को लागू करने का मतलब है कि एडेप्टर अपने स्रोत तक केवल निजी पहुंच को छोड़ देते हैं और केवल विधि रिसीवर प्रकारों के आधार पर की गई गारंटी पर भरोसा कर सकते हैं।
    /// प्रतिबंधित पहुंच की कमी के लिए यह भी आवश्यक है कि एडेप्टर को स्रोत के सार्वजनिक एपीआई को बनाए रखना चाहिए, भले ही उनके पास इसके आंतरिक तक पहुंच हो।
    ///
    /// बदले में कॉल करने वालों को स्रोत के किसी भी राज्य में होने की उम्मीद करनी चाहिए जो कि इसके सार्वजनिक एपीआई के अनुरूप है क्योंकि इसके और स्रोत के बीच बैठे एडेप्टर की समान पहुंच है।
    /// विशेष रूप से एक एडेप्टर ने कड़ाई से आवश्यकता से अधिक तत्वों का उपभोग किया हो सकता है।
    ///
    /// इन आवश्यकताओं का समग्र लक्ष्य उपभोक्ता को पाइपलाइन का उपयोग करने देना है
    /// * पुनरावृत्ति बंद होने के बाद स्रोत में जो कुछ भी रहता है
    /// * वह मेमोरी जो उपभोग करने वाले पुनरावर्तक को आगे बढ़ाकर अप्रयुक्त हो गई है
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// एक पुनरावर्तक एडाप्टर जो आउटपुट उत्पन्न करता है जब तक कि अंतर्निहित इटरेटर `Result::Ok` मान उत्पन्न करता है।
///
///
/// यदि कोई त्रुटि आती है, तो पुनरावर्तक रुक जाता है और त्रुटि संग्रहीत हो जाती है।
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// दिए गए इटरेटर को प्रोसेस करें जैसे कि उसे `Result<T, _>` के बजाय `T` मिले।
/// कोई भी त्रुटि आंतरिक पुनरावर्तक को रोक देगी और समग्र परिणाम एक त्रुटि होगी।
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}