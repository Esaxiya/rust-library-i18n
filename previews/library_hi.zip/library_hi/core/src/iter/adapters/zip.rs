use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// एक पुनरावर्तक जो एक साथ दो अन्य पुनरावृत्तियों को पुनरावृत्त करता है।
///
/// यह `struct` [`Iterator::zip`] द्वारा बनाया गया है।
/// अधिक के लिए इसके दस्तावेज़ देखें।
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // index, len और a_len का उपयोग केवल zip के विशेष संस्करण द्वारा किया जाता है
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // सुरक्षा: `ZipImpl::__iterator_get_unchecked` में समान सुरक्षा है
        // `Iterator::__iterator_get_unchecked` के रूप में आवश्यकताएं।
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// ज़िप विशेषज्ञता trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // इसकी सुरक्षा आवश्यकताएँ `Iterator::__iterator_get_unchecked` safety जैसी ही हैं
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// सामान्य ज़िप impl
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // ए, बी को बराबर लंबाई में समायोजित करें
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // सुरक्षा: `i` `self.len` से छोटा है, इस प्रकार `self.a.len()` और `self.b.len()` से छोटा है
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // आधार कार्यान्वयन के संभावित दुष्प्रभावों से मेल खाता है सुरक्षा: हमने अभी जाँच की है कि `i` < `self.a.len()`
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // सुरक्षा: `delta` की गणना करने के लिए `cmp::min` का उपयोग
                // सुनिश्चित करता है कि `end`, `self.len` से छोटा या उसके बराबर है, इसलिए `i` भी `self.len` से छोटा है।
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // सुरक्षा: ऊपर के समान।
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // a, b को समान लंबाई में समायोजित करें, सुनिश्चित करें कि केवल `next_back` की पहली कॉल ही ऐसा करती है, अन्यथा हम `get_unchecked()` को कॉल करने के बाद `self.next_back()` पर कॉल पर प्रतिबंध को तोड़ देंगे।
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // सुरक्षा: `i`, `self.len` के पिछले मान से छोटा है,
            // जो `self.a.len()` और `self.b.len()`. से भी छोटा या उसके बराबर है
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // सुरक्षा: कॉल करने वाले को `Iterator::__iterator_get_unchecked` के अनुबंध को बनाए रखना चाहिए।
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// निकालने योग्य "source" के रूप में ज़िप पुनरावृत्ति के बाईं ओर मनमाने ढंग से चयन करता है, इसके लिए दोनों को आज़माने में सक्षम होने के लिए नकारात्मक trait bounds की आवश्यकता होगी
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // सुरक्षा: असुरक्षित फ़ंक्शन समान आवश्यकताओं के साथ असुरक्षित फ़ंक्शन को अग्रेषित करना
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// आइटम तक सीमित: ज़िप के TrustedRandomAccess के उपयोग और स्रोत के ड्रॉप कार्यान्वयन के बीच बातचीत के बाद से प्रतिलिपि स्पष्ट नहीं है।
//
// स्रोत को तार्किक रूप से उन्नत किए जाने की संख्या को वापस करने की एक अतिरिक्त विधि (next()) को कॉल किए बिना शेष स्रोत को ठीक से छोड़ने की आवश्यकता होगी।
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // निहित पुनरावृत्तियों पर fmt को कॉल करना *सुरक्षित नहीं* है, क्योंकि एक बार जब हम पुनरावृति करना शुरू करते हैं तो वे अजीब, संभावित रूप से असुरक्षित स्थिति में होते हैं।
        //
        f.debug_struct("Zip").finish()
    }
}

/// एक पुनरावर्तक जिसका आइटम कुशलता से यादृच्छिक-सुलभ है
///
/// # Safety
///
/// इटरेटर का `size_hint` कॉल करने के लिए सटीक और सस्ता होना चाहिए।
///
/// `size` ओवरराइड नहीं किया जा सकता है।
///
/// `<Self as Iterator>::__iterator_get_unchecked` कॉल करने के लिए सुरक्षित होना चाहिए बशर्ते निम्नलिखित शर्तें पूरी हों।
///
/// 1. `0 <= idx` और `idx < self.size()`।
/// 2. यदि `self: !Clone`, तो `get_unchecked` को कभी भी `self` पर एक ही इंडेक्स के साथ एक से अधिक बार कॉल नहीं किया जाता है।
/// 3. `self.get_unchecked(idx)` को कॉल किए जाने के बाद `next_back` को केवल अधिकतम `self.size() - idx - 1` बार ही कॉल किया जाएगा।
/// 4. `get_unchecked` को कॉल करने के बाद, `self` पर केवल निम्न विधियों को कॉल किया जाएगा:
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// इसके अलावा, यह देखते हुए कि इन शर्तों को पूरा किया जाता है, यह गारंटी देनी चाहिए कि:
///
/// * यह `size_hint`. से लौटाए गए मान को नहीं बदलता है
/// * `get_unchecked` को कॉल करने के बाद `self` पर ऊपर सूचीबद्ध विधियों को कॉल करना सुरक्षित होना चाहिए, यह मानते हुए कि आवश्यक traits लागू किया गया है।
///
/// * `get_unchecked` को कॉल करने के बाद `self` को छोड़ना भी सुरक्षित होना चाहिए।
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // सुविधा विधि।
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` यदि एक पुनरावर्तक तत्व प्राप्त करने के दुष्प्रभाव हो सकते हैं।
    /// आंतरिक पुनरावृत्तियों को ध्यान में रखना याद रखें।
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// `Iterator::__iterator_get_unchecked` की तरह, लेकिन संकलक को यह जानने की आवश्यकता नहीं है कि `U: TrustedRandomAccess`.
///
///
/// ## Safety
///
/// `get_unchecked` को सीधे कॉल करने वाली समान आवश्यकताएं।
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // सुरक्षा: कॉल करने वाले को `Iterator::__iterator_get_unchecked` के अनुबंध को बनाए रखना चाहिए।
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// यदि `Self: TrustedRandomAccess`, तो `Iterator::__iterator_get_unchecked(self, index)` को कॉल करना सुरक्षित होना चाहिए।
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // सुरक्षा: कॉल करने वाले को `Iterator::__iterator_get_unchecked` के अनुबंध को बनाए रखना चाहिए।
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}