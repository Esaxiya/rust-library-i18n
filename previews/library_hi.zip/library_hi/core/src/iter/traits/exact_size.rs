/// एक पुनरावर्तक जो इसकी सटीक लंबाई जानता है।
///
/// कई [`Iterator`] नहीं जानते कि वे कितनी बार पुनरावृति करेंगे, लेकिन कुछ करते हैं।
/// यदि एक पुनरावर्तक जानता है कि वह कितनी बार पुनरावृति कर सकता है, तो उस जानकारी तक पहुँच प्रदान करना उपयोगी हो सकता है।
/// उदाहरण के लिए, यदि आप पीछे की ओर पुनरावृति करना चाहते हैं, तो एक अच्छी शुरुआत यह जानना है कि अंत कहाँ है।
///
/// `ExactSizeIterator` को लागू करते समय, आपको [`Iterator`] भी लागू करना होगा।
/// ऐसा करते समय, [`Iterator::size_hint`]*के कार्यान्वयन को* पुनरावर्तक का सटीक आकार वापस करना चाहिए।
///
/// [`len`] विधि का एक डिफ़ॉल्ट कार्यान्वयन है, इसलिए आपको आमतौर पर इसे लागू नहीं करना चाहिए।
/// हालांकि, आप डिफ़ॉल्ट की तुलना में अधिक प्रदर्शनकारी कार्यान्वयन प्रदान करने में सक्षम हो सकते हैं, इसलिए इस मामले में इसे ओवरराइड करना समझ में आता है।
///
///
/// ध्यान दें कि यह trait एक सुरक्षित trait है और इस तरह *नहीं* और *नहीं* गारंटी देता है कि लौटाई गई लंबाई सही है।
/// इसका मतलब है कि `unsafe` कोड **नहीं** होना चाहिए जो [`Iterator::size_hint`] की शुद्धता पर निर्भर करता है।
/// अस्थिर और असुरक्षित [`TrustedLen`](super::marker::TrustedLen) trait यह अतिरिक्त गारंटी देता है।
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// // एक परिमित सीमा ठीक से जानती है कि वह कितनी बार पुनरावृति करेगी
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] में, हमने एक [`Iterator`] लागू किया, `Counter`.
/// आइए इसके लिए `ExactSizeIterator` को भी लागू करें:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // हम पुनरावृत्तियों की शेष संख्या की गणना आसानी से कर सकते हैं।
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // और अब हम इसका इस्तेमाल कर सकते हैं!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// पुनरावर्तक की सटीक लंबाई लौटाता है।
    ///
    /// कार्यान्वयन सुनिश्चित करता है कि इटरेटर [`None`] को वापस करने से पहले, [`Some(T)`] मान से बिल्कुल `len()` अधिक बार लौटाएगा।
    ///
    /// इस पद्धति का एक डिफ़ॉल्ट कार्यान्वयन है, इसलिए आपको आमतौर पर इसे सीधे लागू नहीं करना चाहिए।
    /// हालांकि, यदि आप अधिक कुशल कार्यान्वयन प्रदान कर सकते हैं, तो आप ऐसा कर सकते हैं।
    /// उदाहरण के लिए [trait-level] दस्तावेज़ देखें।
    ///
    /// इस फ़ंक्शन में [`Iterator::size_hint`] फ़ंक्शन के समान सुरक्षा गारंटी है।
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// // एक परिमित सीमा ठीक से जानती है कि वह कितनी बार पुनरावृति करेगी
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: यह दावा अत्यधिक रक्षात्मक है, लेकिन यह अपरिवर्तनीय की जाँच करता है
        // trait द्वारा गारंटीकृत।
        // यदि यह trait rust-आंतरिक होता, तो हम debug_assert का उपयोग कर सकते थे!;मुखर_ईक!सभी Rust उपयोगकर्ता कार्यान्वयन की भी जाँच करेगा।
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// इटरेटर खाली होने पर `true` लौटाता है।
    ///
    /// इस विधि में [`ExactSizeIterator::len()`] का उपयोग करके एक डिफ़ॉल्ट कार्यान्वयन है, इसलिए आपको इसे स्वयं लागू करने की आवश्यकता नहीं है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}