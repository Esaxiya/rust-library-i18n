use crate::ops::{ControlFlow, Try};

/// दोनों सिरों से तत्वों को उत्पन्न करने में सक्षम एक पुनरावर्तक।
///
/// कुछ ऐसा जो `DoubleEndedIterator` को लागू करता है, उस चीज़ पर एक अतिरिक्त क्षमता होती है जो [`Iterator`] को लागू करती है: पीछे से और साथ ही सामने से `आइटम` को भी लेने की क्षमता।
///
///
/// यह ध्यान रखना महत्वपूर्ण है कि आगे और पीछे दोनों एक ही सीमा पर काम करते हैं, और क्रॉस नहीं करते हैं: बीच में मिलने पर पुनरावृत्ति समाप्त हो जाती है।
///
/// [`Iterator`] प्रोटोकॉल के समान ही, एक बार `DoubleEndedIterator` [`next_back()`] से [`None`] लौटाता है, इसे फिर से कॉल करना [`Some`] को फिर कभी वापस कर सकता है या नहीं।
/// [`next()`] और [`next_back()`] इस उद्देश्य के लिए विनिमेय हैं।
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// इटरेटर के अंत से एक तत्व को हटाता है और वापस करता है।
    ///
    /// कोई और तत्व न होने पर `None` लौटाता है।
    ///
    /// [trait-level] डॉक्स में अधिक विवरण हैं।
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// `DoubleEndedIterator` की विधियों द्वारा प्राप्त तत्व [`Iterator`] के तरीकों से प्राप्त होने वाले तत्वों से भिन्न हो सकते हैं:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// `n` तत्वों द्वारा इटरेटर को पीछे से आगे बढ़ाता है।
    ///
    /// `advance_back_by` [`advance_by`] का रिवर्स वर्जन है।[`None`] का सामना करने तक [`next_back`] को `n` बार कॉल करके यह विधि उत्सुकता से पीछे से शुरू होने वाले `n` तत्वों को छोड़ देगी।
    ///
    /// `advance_back_by(n)` [`Ok(())`] लौटाएगा यदि इटरेटर सफलतापूर्वक `n` तत्वों द्वारा आगे बढ़ता है, या [`Err(k)`] यदि [`None`] का सामना करना पड़ता है, जहां `k` तत्वों की संख्या है जो तत्वों से बाहर निकलने से पहले इटरेटर उन्नत है (यानी
    /// इटरेटर की लंबाई)।
    /// ध्यान दें कि `k` हमेशा `n` से छोटा होता है।
    ///
    /// `advance_back_by(0)` को कॉल करना किसी भी तत्व का उपभोग नहीं करता है और हमेशा [`Ok(())`] लौटाता है।
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // केवल `&3` को छोड़ दिया गया था
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// पुनरावर्तक के अंत से `n` वां तत्व देता है।
    ///
    /// यह अनिवार्य रूप से [`Iterator::nth()`] का उल्टा संस्करण है।
    /// हालांकि अधिकांश अनुक्रमण संचालन की तरह, गिनती शून्य से शुरू होती है, इसलिए `nth_back(0)` अंत से पहला मान देता है, `nth_back(1)` दूसरा, और इसी तरह।
    ///
    ///
    /// ध्यान दें कि अंत और लौटाए गए तत्व के बीच के सभी तत्वों का उपभोग किया जाएगा, जिसमें लौटा हुआ तत्व भी शामिल है।
    /// इसका मतलब यह भी है कि एक ही इटरेटर पर `nth_back(0)` को कई बार कॉल करने से अलग-अलग तत्व वापस आ जाएंगे।
    ///
    /// `nth_back()` [`None`] लौटाएगा यदि `n` इटरेटर की लंबाई से अधिक या उसके बराबर है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` को कई बार कॉल करना इटरेटर को रिवाइंड नहीं करता है:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// यदि `n + 1` से कम तत्व हैं तो `None` लौटाना:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// यह [`Iterator::try_fold()`] का उल्टा संस्करण है: यह इटरेटर के पीछे से शुरू होने वाले तत्वों को लेता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // चूंकि यह शॉर्ट-सर्किट है, शेष तत्व अभी भी इटरेटर के माध्यम से उपलब्ध हैं।
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// एक पुनरावर्तक विधि जो इटरेटर के तत्वों को पीछे से शुरू करके एकल, अंतिम मान तक कम कर देती है।
    ///
    /// यह [`Iterator::fold()`] का उल्टा संस्करण है: यह इटरेटर के पीछे से शुरू होने वाले तत्वों को लेता है।
    ///
    /// `rfold()` दो तर्क लेता है: एक प्रारंभिक मान, और दो तर्कों के साथ एक बंद: एक 'accumulator', और एक तत्व।
    /// क्लोजर वह मान लौटाता है जो अगले पुनरावृत्ति के लिए संचायक के पास होना चाहिए।
    ///
    /// प्रारंभिक मूल्य वह मूल्य है जो संचायक के पास पहली कॉल पर होगा।
    ///
    /// इस क्लोजर को इटरेटर के प्रत्येक तत्व पर लागू करने के बाद, `rfold()` संचायक लौटाता है।
    ///
    /// इस ऑपरेशन को कभी-कभी 'reduce' या 'inject' कहा जाता है।
    ///
    /// फोल्डिंग तब उपयोगी होती है जब आपके पास किसी चीज का संग्रह होता है, और आप उससे एक मूल्य उत्पन्न करना चाहते हैं।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a. के सभी तत्वों का योग
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// यह उदाहरण एक स्ट्रिंग बनाता है, प्रारंभिक मान से शुरू होता है और पीछे से सामने तक प्रत्येक तत्व के साथ जारी रहता है:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// पीछे से एक पुनरावर्तक के एक तत्व की खोज करता है जो एक विधेय को संतुष्ट करता है।
    ///
    /// `rfind()` एक क्लोजर लेता है जो `true` या `false` लौटाता है।
    /// यह अंत में शुरू होने वाले इटरेटर के प्रत्येक तत्व पर इस बंद को लागू करता है, और यदि उनमें से कोई भी `true` लौटाता है, तो `rfind()` [`Some(element)`] लौटाता है।
    /// यदि वे सभी `false` लौटाते हैं, तो यह [`None`] लौटाता है।
    ///
    /// `rfind()` शॉर्ट-सर्किटिंग है;दूसरे शब्दों में, जैसे ही क्लोजर `true` वापस आता है, यह प्रोसेसिंग बंद कर देगा।
    ///
    /// क्योंकि `rfind()` एक संदर्भ लेता है, और कई पुनरावर्तक संदर्भों पर पुनरावृति करते हैं, यह संभावित रूप से भ्रमित करने वाली स्थिति की ओर जाता है जहां तर्क एक दोहरा संदर्भ है।
    ///
    /// आप इस प्रभाव को नीचे दिए गए उदाहरणों में `&&x` के साथ देख सकते हैं।
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// पहले `true` पर रुकना:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // हम अभी भी `iter` का उपयोग कर सकते हैं, क्योंकि और भी तत्व हैं।
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}