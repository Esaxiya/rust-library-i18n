// अनदेखा-साफ-फ़ाइल लम्बाई इस फ़ाइल में लगभग विशेष रूप से `Iterator` की परिभाषा है।
// हम इसे कई फाइलों में विभाजित नहीं कर सकते हैं।
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// पुनरावृत्तियों से निपटने के लिए एक इंटरफ़ेस।
///
/// यह मुख्य पुनरावर्तक trait है।
/// आम तौर पर इटरेटर की अवधारणा के बारे में अधिक जानकारी के लिए, कृपया [module-level documentation] देखें।
/// विशेष रूप से, आप जानना चाह सकते हैं कि [implement `Iterator`][impl] कैसे करें।
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// तत्वों के प्रकार पर पुनरावृति की जा रही है।
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// इटरेटर को आगे बढ़ाता है और अगला मान देता है।
    ///
    /// पुनरावृत्ति समाप्त होने पर [`None`] लौटाता है।
    /// व्यक्तिगत पुनरावर्तक कार्यान्वयन पुनरावृत्ति को फिर से शुरू करना चुन सकता है, और इसलिए `next()` को फिर से कॉल करना अंततः किसी बिंदु पर [`Some(Item)`] को फिर से वापस करना शुरू कर सकता है या नहीं।
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() पर कॉल अगला मान लौटाती है...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... और फिर कोई नहीं एक बार यह खत्म हो गया है।
    /// assert_eq!(None, iter.next());
    ///
    /// // अधिक कॉल `None` वापस कर सकते हैं या नहीं भी कर सकते हैं।यहाँ, वे हमेशा करेंगे।
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// इटरेटर की शेष लंबाई पर सीमाएं लौटाता है।
    ///
    /// विशेष रूप से, `size_hint()` एक टपल लौटाता है जहां पहला तत्व निचली सीमा है, और दूसरा तत्व ऊपरी सीमा है।
    ///
    /// लौटाए गए टपल का दूसरा भाग एक [`Option`]`<`[`usize`]`>` होता है।
    /// यहाँ एक [`None`] का अर्थ है कि या तो कोई ज्ञात ऊपरी सीमा नहीं है, या ऊपरी सीमा [`usize`] से बड़ी है।
    ///
    /// # कार्यान्वयन नोट
    ///
    /// यह लागू नहीं किया जाता है कि एक पुनरावर्तक कार्यान्वयन तत्वों की घोषित संख्या उत्पन्न करता है।एक बग्गी इटरेटर निचले बाउंड से कम या तत्वों के ऊपरी बाउंड से अधिक उत्पन्न कर सकता है।
    ///
    /// `size_hint()` मुख्य रूप से इटरेटर के तत्वों के लिए स्थान आरक्षित करने जैसे अनुकूलन के लिए उपयोग करने का इरादा है, लेकिन इस पर भरोसा नहीं किया जाना चाहिए, उदाहरण के लिए, असुरक्षित कोड में सीमा जांच को छोड़ दें।
    /// `size_hint()` के गलत कार्यान्वयन से स्मृति सुरक्षा उल्लंघन नहीं होना चाहिए।
    ///
    /// उस ने कहा, कार्यान्वयन को एक सही अनुमान प्रदान करना चाहिए, क्योंकि अन्यथा यह trait के प्रोटोकॉल का उल्लंघन होगा।
    ///
    /// डिफ़ॉल्ट कार्यान्वयन `(0,`[`None`]`)` लौटाता है जो किसी भी पुनरावर्तक के लिए सही है।
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// एक अधिक जटिल उदाहरण:
    ///
    /// ```
    /// // सम संख्याएँ शून्य से दस तक।
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // हम शून्य से दस बार पुनरावृति कर सकते हैं।
    /// // यह जानते हुए कि filter() को क्रियान्वित किए बिना यह पांच बिल्कुल संभव नहीं होगा।
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // आइए chain(). के साथ पाँच और संख्याएँ जोड़ते हैं
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // अब दोनों सीमा पांच से बढ़ा दी गई है
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// ऊपरी सीमा के लिए `None` लौटाना:
    ///
    /// ```
    /// // एक अनंत पुनरावर्तक की कोई ऊपरी सीमा नहीं होती है और अधिकतम संभव निचली सीमा होती है
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// इटरेटर का उपभोग करता है, पुनरावृत्तियों की संख्या की गणना करता है और इसे वापस करता है।
    ///
    /// यह विधि [`next`] को बार-बार कॉल करेगी जब तक कि [`None`] का सामना नहीं किया जाता है, यह [`Some`] को जितनी बार देखा गया है, लौटाता है।
    /// ध्यान दें कि [`next`] को कम से कम एक बार कॉल करना होगा, भले ही इटरेटर में कोई तत्व न हो।
    ///
    /// [`next`]: Iterator::next
    ///
    /// # अतिप्रवाह व्यवहार
    ///
    /// विधि अतिप्रवाह के खिलाफ कोई सुरक्षा नहीं करती है, इसलिए [`usize::MAX`] से अधिक तत्वों के साथ एक पुनरावर्तक के तत्वों की गिनती या तो गलत परिणाम या panics उत्पन्न करती है।
    ///
    /// यदि डिबग अभिकथन सक्षम हैं, तो panic की गारंटी है।
    ///
    /// # Panics
    ///
    /// यह फ़ंक्शन panic हो सकता है यदि इटरेटर में [`usize::MAX`] से अधिक तत्व हैं।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// इटरेटर का उपभोग करता है, अंतिम तत्व लौटाता है।
    ///
    /// यह विधि [`None`] लौटने तक पुनरावर्तक का मूल्यांकन करेगी।
    /// ऐसा करते समय, यह वर्तमान तत्व का ट्रैक रखता है।
    /// [`None`] के वापस आने के बाद, `last()` उसके द्वारा देखे गए अंतिम तत्व को वापस कर देगा।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` तत्वों द्वारा पुनरावर्तक को आगे बढ़ाता है।
    ///
    /// [`None`] का सामना करने तक [`next`] को `n` बार कॉल करके यह विधि उत्सुकता से `n` तत्वों को छोड़ देगी।
    ///
    /// `advance_by(n)` [`Ok(())`][Ok] लौटाएगा यदि इटरेटर सफलतापूर्वक `n` तत्वों द्वारा आगे बढ़ता है, या [`Err(k)`][Err] यदि [`None`] का सामना करना पड़ता है, जहां `k` तत्वों की संख्या है जो तत्वों से बाहर निकलने से पहले इटरेटर उन्नत है (यानी
    /// इटरेटर की लंबाई)।
    /// ध्यान दें कि `k` हमेशा `n` से छोटा होता है।
    ///
    /// `advance_by(0)` को कॉल करना किसी भी तत्व का उपभोग नहीं करता है और हमेशा [`Ok(())`][Ok] लौटाता है।
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // केवल `&4` को छोड़ दिया गया था
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// पुनरावर्तक का `n`वां तत्व लौटाता है।
    ///
    /// अधिकांश अनुक्रमण संचालन की तरह, गिनती शून्य से शुरू होती है, इसलिए `nth(0)` पहला मान देता है, `nth(1)` दूसरा, और इसी तरह।
    ///
    /// ध्यान दें कि सभी पूर्ववर्ती तत्व, साथ ही लौटाए गए तत्व, पुनरावर्तक से भस्म हो जाएंगे।
    /// इसका मतलब है कि पिछले तत्वों को छोड़ दिया जाएगा, और यह भी कि एक ही पुनरावर्तक पर `nth(0)` को कई बार कॉल करने से विभिन्न तत्व वापस आ जाएंगे।
    ///
    ///
    /// `nth()` [`None`] लौटाएगा यदि `n` इटरेटर की लंबाई से अधिक या उसके बराबर है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` को कई बार कॉल करना इटरेटर को रिवाइंड नहीं करता है:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// यदि `n + 1` से कम तत्व हैं तो `None` लौटाना:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// एक ही बिंदु से शुरू होने वाला एक पुनरावर्तक बनाता है, लेकिन प्रत्येक पुनरावृत्ति पर दी गई राशि से आगे बढ़ता है।
    ///
    /// नोट 1: दिए गए चरण की परवाह किए बिना, इटरेटर का पहला तत्व हमेशा लौटाया जाएगा।
    ///
    /// नोट २: जिस समय पर ध्यान न दिया गया तत्वों को खींचा जाता है वह निश्चित नहीं है।
    /// `StepBy` अनुक्रम `next(), nth(step-1), nth(step-1),…` की तरह व्यवहार करता है, लेकिन अनुक्रम की तरह व्यवहार करने के लिए भी स्वतंत्र है
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// प्रदर्शन कारणों से कुछ पुनरावृत्तियों के लिए किस तरीके का उपयोग किया जाता है, यह बदल सकता है।
    /// दूसरा तरीका पहले इटरेटर को आगे बढ़ाएगा और अधिक वस्तुओं का उपभोग कर सकता है।
    ///
    /// `advance_n_and_return_first` के बराबर है:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// यदि दिया गया चरण `0` है तो विधि panic होगी।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// दो पुनरावर्तक लेता है और क्रम में दोनों पर एक नया पुनरावर्तक बनाता है।
    ///
    /// `chain()` एक नया पुनरावर्तक लौटाएगा जो पहले पहले पुनरावर्तक से मूल्यों पर और फिर दूसरे पुनरावर्तक से मूल्यों पर पुनरावृति करेगा।
    ///
    /// दूसरे शब्दों में, यह दो पुनरावृत्तियों को एक साथ, एक श्रृंखला में जोड़ता है।🔗
    ///
    /// [`once`] आमतौर पर एकल मान को अन्य प्रकार के पुनरावृत्तियों की श्रृंखला में अनुकूलित करने के लिए उपयोग किया जाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// चूंकि `chain()` का तर्क [`IntoIterator`] का उपयोग करता है, हम कुछ भी पास कर सकते हैं जिसे [`Iterator`] में परिवर्तित किया जा सकता है, न कि केवल एक [`Iterator`] में।
    /// उदाहरण के लिए, स्लाइस (`&[T]`) [`IntoIterator`] को लागू करता है, और इसलिए सीधे `chain()` को पास किया जा सकता है:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// यदि आप Windows API के साथ काम करते हैं, तो आप [`OsStr`] को `Vec<u16>` में कनवर्ट करना चाह सकते हैं:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// दो पुनरावृत्तियों को जोड़े के एकल पुनरावर्तक में 'ज़िप अप' करें।
    ///
    /// `zip()` एक नया पुनरावर्तक देता है जो दो अन्य पुनरावृत्तियों पर पुनरावृति करेगा, एक टपल लौटाएगा जहां पहला तत्व पहले पुनरावर्तक से आता है, और दूसरा तत्व दूसरे पुनरावर्तक से आता है।
    ///
    ///
    /// दूसरे शब्दों में, यह दो पुनरावृत्तियों को एक साथ, एक में जोड़ देता है।
    ///
    /// यदि कोई भी पुनरावर्तक [`None`] लौटाता है, तो ज़िपित पुनरावर्तक से [`next`] [`None`] लौटाएगा।
    /// यदि पहला पुनरावर्तक [`None`] लौटाता है, तो `zip` शॉर्ट-सर्किट होगा और दूसरे पुनरावर्तक पर `next` को नहीं बुलाया जाएगा।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// चूंकि `zip()` का तर्क [`IntoIterator`] का उपयोग करता है, हम कुछ भी पास कर सकते हैं जिसे [`Iterator`] में परिवर्तित किया जा सकता है, न कि केवल एक [`Iterator`] में।
    /// उदाहरण के लिए, स्लाइस (`&[T]`) [`IntoIterator`] को लागू करता है, और इसलिए सीधे `zip()` को पास किया जा सकता है:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` अक्सर एक अनंत इटरेटर को एक सीमित करने के लिए ज़िप करने के लिए प्रयोग किया जाता है।
    /// यह काम करता है क्योंकि परिमित पुनरावर्तक अंततः ज़िप को समाप्त करते हुए [`None`] लौटाएगा।`(0..)` के साथ ज़िप करना [`enumerate`] जैसा दिख सकता है:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// एक नया पुनरावर्तक बनाता है जो मूल पुनरावर्तक के आसन्न वस्तुओं के बीच `separator` की एक प्रति रखता है।
    ///
    /// यदि `separator` [`Clone`] को लागू नहीं करता है या हर बार गणना करने की आवश्यकता है, तो [`intersperse_with`] का उपयोग करें।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` से पहला तत्व।
    /// assert_eq!(a.next(), Some(&100)); // विभाजक।
    /// assert_eq!(a.next(), Some(&1));   // `a` से अगला तत्व।
    /// assert_eq!(a.next(), Some(&100)); // विभाजक।
    /// assert_eq!(a.next(), Some(&2));   // `a` से अंतिम तत्व।
    /// assert_eq!(a.next(), None);       // इटरेटर समाप्त हो गया है।
    /// ```
    ///
    /// `intersperse` एक सामान्य तत्व का उपयोग करके एक पुनरावर्तक के आइटम में शामिल होने के लिए बहुत उपयोगी हो सकता है:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// एक नया इटरेटर बनाता है जो मूल इटरेटर के आसन्न वस्तुओं के बीच `separator` द्वारा उत्पन्न एक आइटम रखता है।
    ///
    /// हर बार जब कोई आइटम अंतर्निहित इटरेटर से दो आसन्न वस्तुओं के बीच रखा जाता है, तो क्लोजर को ठीक उसी बार कहा जाएगा;
    /// विशेष रूप से, बंद नहीं कहा जाता है यदि अंतर्निहित इटरेटर दो से कम आइटम उत्पन्न करता है और अंतिम आइटम प्राप्त होने के बाद।
    ///
    ///
    /// यदि इटरेटर का आइटम [`Clone`] लागू करता है, तो [`intersperse`] का उपयोग करना आसान हो सकता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` से पहला तत्व।
    /// assert_eq!(it.next(), Some(NotClone(99))); // विभाजक।
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` से अगला तत्व।
    /// assert_eq!(it.next(), Some(NotClone(99))); // विभाजक।
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` से अंतिम तत्व।
    /// assert_eq!(it.next(), None);               // इटरेटर समाप्त हो गया है।
    /// ```
    ///
    /// `intersperse_with` उन स्थितियों में उपयोग किया जा सकता है जहां विभाजक की गणना करने की आवश्यकता होती है:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // एक वस्तु उत्पन्न करने के लिए क्लोजर पारस्परिक रूप से इसके संदर्भ को उधार लेता है।
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// एक क्लोजर लेता है और एक इटरेटर बनाता है जो प्रत्येक तत्व पर उस क्लोजर को कॉल करता है।
    ///
    /// `map()` अपने तर्क के माध्यम से एक पुनरावर्तक को दूसरे में बदल देता है:
    /// कुछ ऐसा जो [`FnMut`] को लागू करता है।यह एक नया इटरेटर उत्पन्न करता है जो मूल इटरेटर के प्रत्येक तत्व पर इस क्लोजर को कॉल करता है।
    ///
    /// यदि आप प्रकार में सोचने में अच्छे हैं, तो आप `map()` के बारे में इस तरह सोच सकते हैं:
    /// यदि आपके पास एक पुनरावर्तक है जो आपको कुछ प्रकार के `A` के तत्व देता है, और आप किसी अन्य प्रकार के `B` का पुनरावर्तक चाहते हैं, तो आप `map()` का उपयोग कर सकते हैं, एक क्लोजर पास कर सकते हैं जो `A` लेता है और `B` देता है।
    ///
    ///
    /// `map()` अवधारणात्मक रूप से एक [`for`] लूप के समान है।हालांकि, चूंकि `map()` आलसी है, इसलिए इसका सबसे अच्छा उपयोग तब किया जाता है जब आप पहले से ही अन्य पुनरावृत्तियों के साथ काम कर रहे हों।
    /// यदि आप साइड इफेक्ट के लिए किसी प्रकार की लूपिंग कर रहे हैं, तो `map()` की तुलना में [`for`] का उपयोग करना अधिक मुहावरेदार माना जाता है।
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// यदि आप किसी प्रकार का साइड इफेक्ट कर रहे हैं, तो [`for`] से `map()` को प्राथमिकता दें:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // यह मत करो:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // यह निष्पादित भी नहीं होगा, क्योंकि यह आलसी है।Rust आपको इस बारे में चेतावनी देगा।
    ///
    /// // इसके बजाय, इसके लिए उपयोग करें:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// एक पुनरावर्तक के प्रत्येक तत्व को बंद करने के लिए कहता है।
    ///
    /// यह इटरेटर पर [`for`] लूप का उपयोग करने के बराबर है, हालांकि `break` और `continue` बंद होने से संभव नहीं हैं।
    /// `for` लूप का उपयोग करना आम तौर पर अधिक मुहावरेदार है, लेकिन लंबी पुनरावृत्ति श्रृंखला के अंत में आइटम संसाधित करते समय `for_each` अधिक सुपाठ्य हो सकता है।
    ///
    /// कुछ मामलों में `for_each` लूप से भी तेज हो सकता है, क्योंकि यह `Chain` जैसे एडेप्टर पर आंतरिक पुनरावृत्ति का उपयोग करेगा।
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// इस तरह के एक छोटे से उदाहरण के लिए, एक `for` लूप क्लीनर हो सकता है, लेकिन `for_each` लंबे इटरेटर के साथ एक कार्यात्मक शैली रखने के लिए बेहतर हो सकता है:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// एक पुनरावर्तक बनाता है जो यह निर्धारित करने के लिए बंद करने का उपयोग करता है कि कोई तत्व उत्पन्न किया जाना चाहिए या नहीं।
    ///
    /// किसी तत्व को देखते हुए क्लोजर को `true` या `false` वापस करना होगा।लौटा हुआ पुनरावर्तक केवल उन तत्वों को उत्पन्न करेगा जिनके लिए क्लोजर सही है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// क्योंकि `filter()` को पास किया गया क्लोजर एक संदर्भ लेता है, और कई इटरेटर संदर्भों पर पुनरावृति करते हैं, यह संभावित रूप से भ्रमित करने वाली स्थिति की ओर जाता है, जहां क्लोजर का प्रकार एक दोहरा संदर्भ है:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // दो * एस की जरूरत है!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// इसके बजाय एक को दूर करने के लिए तर्क पर विनाशकारी का उपयोग करना आम है:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // दोनों और *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// अथवा दोनों:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // दो &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// इन परतों का।
    ///
    /// ध्यान दें कि `iter.filter(f).next()`, `iter.find(f)` के बराबर है।
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// एक पुनरावर्तक बनाता है जो फ़िल्टर और मानचित्र दोनों करता है।
    ///
    /// लौटा हुआ पुनरावर्तक केवल `मान` देता है जिसके लिए आपूर्ति की गई क्लोजर `Some(value)` लौटाती है।
    ///
    /// `filter_map` [`filter`] और [`map`] की श्रृंखलाओं को अधिक संक्षिप्त बनाने के लिए उपयोग किया जा सकता है।
    /// नीचे दिया गया उदाहरण दिखाता है कि कैसे एक `map().filter().map()` को एक कॉल से `filter_map` तक छोटा किया जा सकता है।
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// यहाँ वही उदाहरण है, लेकिन [`filter`] और [`map`] के साथ:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// एक पुनरावर्तक बनाता है जो वर्तमान पुनरावृत्ति गणना के साथ-साथ अगला मान भी देता है।
    ///
    /// इटरेटर ने यील्ड जोड़े `(i, val)` को लौटाया, जहां `i` पुनरावृत्ति का वर्तमान सूचकांक है और `val` इटरेटर द्वारा लौटाया गया मान है।
    ///
    ///
    /// `enumerate()` इसकी गिनती [`usize`] के रूप में रहती है।
    /// यदि आप किसी भिन्न आकार के पूर्णांक द्वारा गिनना चाहते हैं, तो [`zip`] फ़ंक्शन समान कार्यक्षमता प्रदान करता है।
    ///
    /// # अतिप्रवाह व्यवहार
    ///
    /// विधि अतिप्रवाह के खिलाफ कोई सुरक्षा नहीं करती है, इसलिए [`usize::MAX`] से अधिक तत्वों की गणना करने से या तो गलत परिणाम उत्पन्न होता है या panics।
    /// यदि डिबग अभिकथन सक्षम हैं, तो panic की गारंटी है।
    ///
    /// # Panics
    ///
    /// लौटा हुआ पुनरावर्तक panic हो सकता है यदि टू-टू-रिटर्न इंडेक्स [`usize`] को ओवरफ्लो कर देगा।
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// एक पुनरावर्तक बनाता है जो [`peek`] का उपयोग इटरेटर के अगले तत्व को बिना उपभोग किए देखने के लिए कर सकता है।
    ///
    /// एक पुनरावर्तक के लिए एक [`peek`] विधि जोड़ता है।अधिक जानकारी के लिए इसके दस्तावेज़ देखें।
    ///
    /// ध्यान दें कि अंतर्निहित इटरेटर अभी भी उन्नत है जब [`peek`] को पहली बार बुलाया जाता है: अगले तत्व को पुनर्प्राप्त करने के लिए, [`next`] को अंतर्निहित इटरेटर पर बुलाया जाता है, इसलिए कोई साइड इफेक्ट (यानी
    ///
    /// [`next`] विधि का अगला मान प्राप्त करने के अलावा कुछ भी होगा)।
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() आइए देखते हैं future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // हम कई बार peek() कर सकते हैं, इटरेटर आगे नहीं बढ़ेगा
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // इटरेटर समाप्त होने के बाद, peek() भी है
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// एक पुनरावर्तक बनाता है जो [`स्किप`] के तत्वों को एक विधेय पर आधारित करता है।
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` एक तर्क के रूप में एक बंद लेता है।यह इटरेटर के प्रत्येक तत्व पर इस बंद को कॉल करेगा, और तत्वों को तब तक अनदेखा करेगा जब तक कि यह `false` वापस न हो।
    ///
    /// `false` के वापस आने के बाद, `skip_while()`'s का कार्य समाप्त हो गया है, और शेष तत्व प्राप्त हो गए हैं।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// चूंकि `skip_while()` को पास किया गया क्लोजर एक संदर्भ लेता है, और कई इटरेटर संदर्भों पर पुनरावृति करते हैं, इससे संभावित रूप से भ्रमित स्थिति होती है, जहां क्लोजर तर्क का प्रकार दोहरा संदर्भ होता है:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // दो * एस की जरूरत है!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// प्रारंभिक `false` के बाद रुकना:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // जबकि यह गलत होता, क्योंकि हमें पहले से ही एक झूठा मिला है, skip_while() का अब और उपयोग नहीं किया जाता है
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// एक पुनरावर्तक बनाता है जो एक विधेय के आधार पर तत्व उत्पन्न करता है।
    ///
    /// `take_while()` एक तर्क के रूप में एक बंद लेता है।यह इटरेटर के प्रत्येक तत्व पर इस बंद को कॉल करेगा, और `true` लौटाते समय उपज तत्व।
    ///
    /// `false` के वापस आने के बाद, `take_while()`'s का काम खत्म हो गया है, और बाकी तत्वों को नजरअंदाज कर दिया गया है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// क्योंकि `take_while()` को पास किया गया क्लोजर एक संदर्भ लेता है, और कई इटरेटर संदर्भों पर पुनरावृति करते हैं, यह संभावित रूप से भ्रमित करने वाली स्थिति की ओर जाता है, जहां क्लोजर का प्रकार एक दोहरा संदर्भ है:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // दो * एस की जरूरत है!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// प्रारंभिक `false` के बाद रुकना:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // हमारे पास अधिक तत्व हैं जो शून्य से कम हैं, लेकिन चूंकि हमें पहले से ही एक झूठा मिला है, इसलिए take_while() का अब और उपयोग नहीं किया जाता है
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// चूंकि `take_while()` को यह देखने के लिए मूल्य को देखने की जरूरत है कि इसे शामिल किया जाना चाहिए या नहीं, उपभोग करने वाले इटरेटर देखेंगे कि इसे हटा दिया गया है:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` अब नहीं है, क्योंकि इसका उपभोग यह देखने के लिए किया गया था कि क्या पुनरावृत्ति बंद होनी चाहिए, लेकिन इसे पुनरावर्तक में वापस नहीं रखा गया था।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// एक पुनरावर्तक बनाता है जो दोनों एक विधेय और मानचित्र के आधार पर तत्व उत्पन्न करता है।
    ///
    /// `map_while()` एक तर्क के रूप में एक बंद लेता है।
    /// यह इटरेटर के प्रत्येक तत्व पर इस बंद को कॉल करेगा, और [`Some(_)`][`Some`] लौटाते समय उपज तत्व।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// यहाँ वही उदाहरण है, लेकिन [`take_while`] और [`map`] के साथ:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// प्रारंभिक [`None`] के बाद रुकना:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // हमारे पास अधिक तत्व हैं जो u32 (4, 5) में फिट हो सकते हैं, लेकिन `map_while` ने `-3` के लिए `None` लौटाया (जैसा कि `predicate` ने `None` लौटाया) और `collect` पहले `None` का सामना करना पड़ा।
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// चूंकि `map_while()` को यह देखने के लिए मूल्य को देखने की जरूरत है कि इसे शामिल किया जाना चाहिए या नहीं, उपभोग करने वाले इटरेटर देखेंगे कि इसे हटा दिया गया है:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` अब नहीं है, क्योंकि इसका उपभोग यह देखने के लिए किया गया था कि क्या पुनरावृत्ति बंद होनी चाहिए, लेकिन इसे पुनरावर्तक में वापस नहीं रखा गया था।
    ///
    /// ध्यान दें कि [`take_while`] के विपरीत यह पुनरावर्तक **नहीं** जुड़ा हुआ है।
    /// यह भी निर्दिष्ट नहीं है कि पहले [`None`] के वापस आने के बाद यह इटरेटर क्या लौटाता है।
    /// यदि आपको फ़्यूज्ड इटरेटर की आवश्यकता है, तो [`fuse`] का उपयोग करें।
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// एक पुनरावर्तक बनाता है जो पहले `n` तत्वों को छोड़ देता है।
    ///
    /// इनके सेवन के बाद शेष तत्व प्राप्त होते हैं।
    /// इस विधि को सीधे ओवरराइड करने के बजाय, `nth` विधि को ओवरराइड करें।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// एक पुनरावर्तक बनाता है जो इसके पहले `n` तत्व उत्पन्न करता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` इसे परिमित बनाने के लिए अक्सर एक अनंत इटरेटर के साथ प्रयोग किया जाता है:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// यदि `n` से कम तत्व उपलब्ध हैं, तो `take` स्वयं को अंतर्निहित पुनरावर्तक के आकार तक सीमित कर देगा:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// [`fold`] के समान एक पुनरावर्तक एडाप्टर जो आंतरिक स्थिति रखता है और एक नया पुनरावर्तक उत्पन्न करता है।
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` दो तर्क लेता है: एक प्रारंभिक मान जो आंतरिक स्थिति को बीज देता है, और दो तर्कों के साथ एक बंद होता है, पहला आंतरिक स्थिति के लिए एक परिवर्तनीय संदर्भ और दूसरा एक पुनरावर्तक तत्व होता है।
    ///
    /// क्लोजर आंतरिक स्थिति को पुनरावृत्तियों के बीच राज्य साझा करने के लिए असाइन कर सकता है।
    ///
    /// पुनरावृत्ति पर, इट्रेटर के प्रत्येक तत्व पर क्लोजर लागू किया जाएगा और क्लोजर से रिटर्न वैल्यू, एक [`Option`], इटरेटर द्वारा प्राप्त किया जाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // प्रत्येक पुनरावृत्ति, हम राज्य को तत्व से गुणा करेंगे
    ///     *state = *state * x;
    ///
    ///     // फिर, हम राज्य की उपेक्षा करेंगे
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// एक पुनरावर्तक बनाता है जो मानचित्र की तरह काम करता है, लेकिन नेस्टेड संरचना को समतल करता है।
    ///
    /// [`map`] एडेप्टर बहुत उपयोगी है, लेकिन केवल तभी जब क्लोजर तर्क मान उत्पन्न करता है।
    /// यदि यह इसके बजाय एक पुनरावर्तक उत्पन्न करता है, तो संकेत की एक अतिरिक्त परत होती है।
    /// `flat_map()` इस अतिरिक्त परत को अपने आप हटा देगा।
    ///
    /// आप `flat_map(f)` को [`map`]पिंग के सिमेंटिक समकक्ष के रूप में सोच सकते हैं, और फिर [`flatten`] ing जैसा कि `map(f).flatten()` में है।
    ///
    /// `flat_map()` के बारे में सोचने का दूसरा तरीका: [`map`] का क्लोजर प्रत्येक तत्व के लिए एक आइटम देता है, और `flat_map()`'s क्लोजर प्रत्येक तत्व के लिए एक पुनरावर्तक देता है।
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() एक पुनरावर्तक देता है
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// एक पुनरावर्तक बनाता है जो नेस्टेड संरचना को समतल करता है।
    ///
    /// यह तब उपयोगी होता है जब आपके पास इटरेटर्स का इटरेटर या चीजों का इटरेटर होता है जिसे इटरेटर में बदला जा सकता है और आप एक स्तर के संकेत को हटाना चाहते हैं।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// मानचित्रण और फिर समतल करना:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() एक पुनरावर्तक देता है
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// आप इसे [`flat_map()`] के संदर्भ में फिर से लिख सकते हैं, जो इस मामले में बेहतर है क्योंकि यह इरादे को अधिक स्पष्ट रूप से बताता है:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() एक पुनरावर्तक देता है
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// फ़्लैटनिंग एक समय में केवल एक स्तर के नेस्टिंग को हटाता है:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// यहां हम देखते हैं कि `flatten()` "deep" समतल नहीं करता है।
    /// इसके बजाय, नेस्टिंग का केवल एक स्तर हटा दिया जाता है।यही है, यदि आप `flatten()` एक त्रि-आयामी सरणी हैं, तो परिणाम द्वि-आयामी होगा और एक-आयामी नहीं होगा।
    /// एक-आयामी संरचना प्राप्त करने के लिए, आपको फिर से `flatten()` करना होगा।
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// एक पुनरावर्तक बनाता है जो पहले [`None`] के बाद समाप्त होता है।
    ///
    /// एक पुनरावर्तक [`None`] लौटाने के बाद, future कॉल [`Some(T)`] को फिर से प्राप्त कर सकता है या नहीं भी कर सकता है।
    /// `fuse()` एक पुनरावर्तक को अनुकूलित करता है, यह सुनिश्चित करता है कि [`None`] दिए जाने के बाद, यह हमेशा [`None`] को हमेशा के लिए वापस कर देगा।
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// // एक पुनरावर्तक जो कुछ और कोई नहीं के बीच वैकल्पिक होता है
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // अगर यह सम है, Some(i32), अन्यथा कोई नहीं
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // हम अपने इटरेटर को आगे और पीछे जाते हुए देख सकते हैं
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // हालाँकि, एक बार जब हम इसे फ्यूज कर देते हैं ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // यह पहली बार के बाद हमेशा `None` लौटाएगा।
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// एक पुनरावर्तक के प्रत्येक तत्व के साथ कुछ करता है, मान को पास करता है।
    ///
    /// पुनरावृत्तियों का उपयोग करते समय, आप अक्सर उनमें से कई को एक साथ श्रृंखलाबद्ध करेंगे।
    /// ऐसे कोड पर काम करते समय, आप यह देखना चाहेंगे कि पाइपलाइन के विभिन्न भागों में क्या हो रहा है।ऐसा करने के लिए, `inspect()` पर कॉल डालें।
    ///
    /// आपके अंतिम कोड में मौजूद होने की तुलना में `inspect()` को डिबगिंग टूल के रूप में उपयोग करना अधिक सामान्य है, लेकिन एप्लिकेशन इसे कुछ स्थितियों में उपयोगी पा सकते हैं जब त्रुटियों को त्यागने से पहले लॉग इन करने की आवश्यकता होती है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // यह पुनरावर्तक अनुक्रम जटिल है।
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // क्या हो रहा है इसकी जांच के लिए आइए कुछ inspect() कॉल जोड़ें
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// यह प्रिंट करेगा:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// लॉगिंग त्रुटियां उन्हें खारिज करने से पहले:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// यह प्रिंट करेगा:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// इसका उपभोग करने के बजाय, एक पुनरावर्तक उधार लेता है।
    ///
    /// यह मूल पुनरावर्तक के स्वामित्व को बनाए रखते हुए पुनरावृत्त एडेप्टर को लागू करने की अनुमति देने के लिए उपयोगी है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // अगर हम फिर से iter का उपयोग करने का प्रयास करते हैं, तो यह काम नहीं करेगा।
    /// // निम्न पंक्ति "त्रुटि देता है: स्थानांतरित मूल्य का उपयोग: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // चलो फिर कोशिश करते हैं
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // इसके बजाय, हम एक .by_ref(). में जोड़ते हैं
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // अब यह ठीक है:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// एक पुनरावर्तक को एक संग्रह में बदल देता है।
    ///
    /// `collect()` कुछ भी चलने योग्य ले सकता है, और इसे एक प्रासंगिक संग्रह में बदल सकता है।
    /// यह मानक पुस्तकालय में अधिक शक्तिशाली तरीकों में से एक है, जिसका उपयोग विभिन्न संदर्भों में किया जाता है।
    ///
    /// सबसे बुनियादी पैटर्न जिसमें `collect()` का उपयोग किया जाता है, एक संग्रह को दूसरे में बदलना है।
    /// आप एक संग्रह लेते हैं, उस पर [`iter`] को कॉल करते हैं, परिवर्तनों का एक गुच्छा करते हैं, और फिर अंत में `collect()` करते हैं।
    ///
    /// `collect()` उन प्रकारों के उदाहरण भी बना सकते हैं जो विशिष्ट संग्रह नहीं हैं।
    /// उदाहरण के लिए, एक [`String`] को [`char`] s से बनाया जा सकता है, और [`Result<T, E>`][`Result`] आइटम्स का एक पुनरावर्तक `Result<Collection<T>, E>` में एकत्र किया जा सकता है।
    ///
    /// अधिक के लिए नीचे दिए गए उदाहरण देखें।
    ///
    /// क्योंकि `collect()` इतना सामान्य है, यह प्रकार के अनुमान के साथ समस्या पैदा कर सकता है।
    /// जैसे, `collect()` उन कुछ मौकों में से एक है, जिन्हें आप प्यार से 'turbofish' के रूप में जाने जाने वाले सिंटैक्स को देखेंगे: `::<>`.
    /// यह अनुमान एल्गोरिथ्म को विशेष रूप से यह समझने में मदद करता है कि आप किस संग्रह में एकत्र करने का प्रयास कर रहे हैं।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ध्यान दें कि हमें बाईं ओर `: Vec<i32>` की आवश्यकता थी।ऐसा इसलिए है क्योंकि हम इसके बजाय, उदाहरण के लिए, एक [`VecDeque<T>`] एकत्र कर सकते हैं:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` को एनोटेट करने के बजाय 'turbofish' का उपयोग करना:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// क्योंकि `collect()` केवल इस बात की परवाह करता है कि आप क्या एकत्र कर रहे हैं, आप अभी भी टर्बोफिश के साथ आंशिक प्रकार के संकेत, `_` का उपयोग कर सकते हैं:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// [`String`] बनाने के लिए `collect()` का उपयोग करना:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// यदि आपके पास [`परिणाम. की एक सूची है<T, E>`][`परिणाम`] s, आप `collect()` का उपयोग यह देखने के लिए कर सकते हैं कि उनमें से कोई विफल तो नहीं हुआ:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // हमें पहली त्रुटि देता है
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // हमें उत्तरों की सूची देता है
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// एक पुनरावर्तक का उपभोग करता है, इससे दो संग्रह बनाता है।
    ///
    /// `partition()` को दिया गया विधेय `true`, या `false` लौटा सकता है।
    /// `partition()` एक जोड़ी देता है, वे सभी तत्व जिनके लिए इसने `true` लौटाया, और वे सभी तत्व जिनके लिए इसने `false` लौटाया।
    ///
    ///
    /// [`is_partitioned()`] और [`partition_in_place()`] भी देखें।
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// दिए गए विधेय के अनुसार इस पुनरावर्तक *इन-प्लेस* के तत्वों को पुन: व्यवस्थित करता है, जैसे कि जो सभी `true` लौटाते हैं, वे सभी `false` लौटाते हैं।
    ///
    /// पाए गए `true` तत्वों की संख्या लौटाता है।
    ///
    /// विभाजित वस्तुओं का सापेक्ष क्रम नहीं रखा जाता है।
    ///
    /// [`is_partitioned()`] और [`partition()`] भी देखें।
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // ईवन और ऑड्स के बीच जगह-जगह विभाजन
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: क्या हमें अतिप्रवाह की गिनती के बारे में चिंता करनी चाहिए?से अधिक पाने का एकमात्र तरीका way
        // `usize::MAX` परिवर्तनीय संदर्भ ZSTs के साथ हैं, जो विभाजन के लिए उपयोगी नहीं हैं ...

        // `Self` में सामान्यता से बचने के लिए ये क्लोजर "factory" फ़ंक्शन मौजूद हैं।

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // पहले `false` को बार-बार ढूंढें और इसे अंतिम `true` से बदलें।
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// जाँचता है कि क्या इस इटरेटर के तत्वों को दिए गए विधेय के अनुसार विभाजित किया गया है, जैसे कि वे सभी जो `true` लौटाते हैं, उन सभी से पहले हैं जो `false` लौटाते हैं।
    ///
    ///
    /// [`partition()`] और [`partition_in_place()`] भी देखें।
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // या तो सभी आइटम `true` का परीक्षण करते हैं, या पहला क्लॉज `false` पर रुक जाता है और हम जांचते हैं कि उसके बाद कोई और `true` आइटम नहीं हैं।
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// एक पुनरावर्तक विधि जो किसी फ़ंक्शन को तब तक लागू करती है जब तक वह सफलतापूर्वक लौटता है, एकल, अंतिम मान उत्पन्न करता है।
    ///
    /// `try_fold()` दो तर्क लेता है: एक प्रारंभिक मान, और दो तर्कों के साथ एक बंद: एक 'accumulator', और एक तत्व।
    /// क्लोजर या तो सफलतापूर्वक लौटाता है, उस मूल्य के साथ जो संचयक के पास अगले पुनरावृत्ति के लिए होना चाहिए, या यह विफलता देता है, एक त्रुटि मान के साथ जो तुरंत कॉलर को वापस प्रचारित किया जाता है (short-circuiting)।
    ///
    ///
    /// प्रारंभिक मूल्य वह मूल्य है जो संचायक के पास पहली कॉल पर होगा।यदि इटरेटर के प्रत्येक तत्व के खिलाफ क्लोजर को लागू करना सफल होता है, तो `try_fold()` अंतिम संचायक को सफलता के रूप में लौटाता है।
    ///
    /// फोल्डिंग तब उपयोगी होती है जब आपके पास किसी चीज का संग्रह होता है, और आप उससे एक मूल्य उत्पन्न करना चाहते हैं।
    ///
    /// # कार्यान्वयनकर्ताओं के लिए नोट
    ///
    /// अन्य (forward) विधियों में से कई में इस के संदर्भ में डिफ़ॉल्ट कार्यान्वयन हैं, इसलिए इसे स्पष्ट रूप से लागू करने का प्रयास करें यदि यह डिफ़ॉल्ट `for` लूप कार्यान्वयन से कुछ बेहतर कर सकता है।
    ///
    /// विशेष रूप से, इस कॉल को `try_fold()` आंतरिक भागों पर रखने का प्रयास करें जिससे यह पुनरावर्तक बना है।
    /// यदि कई कॉलों की आवश्यकता है, तो `?` ऑपरेटर संचायक मूल्य को साथ रखने के लिए सुविधाजनक हो सकता है, लेकिन किसी भी अपरिवर्तनीय से सावधान रहें जिन्हें उन शुरुआती रिटर्न से पहले बनाए रखने की आवश्यकता है।
    /// यह एक `&mut self` विधि है, इसलिए यहां एक त्रुटि को मारने के बाद पुनरावृत्ति को फिर से शुरू करने की आवश्यकता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // सरणी के सभी तत्वों का चेक किया गया योग
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // 100 तत्व जोड़ने पर यह योग अतिप्रवाह हो जाता है
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // चूंकि यह शॉर्ट-सर्किट है, शेष तत्व अभी भी इटरेटर के माध्यम से उपलब्ध हैं।
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// एक पुनरावर्तक विधि जो पुनरावर्तक में प्रत्येक आइटम पर एक गिरने योग्य फ़ंक्शन लागू करती है, पहली त्रुटि पर रुकती है और उस त्रुटि को वापस कर देती है।
    ///
    ///
    /// इसे [`for_each()`] का फॉलिबल फॉर्म या [`try_fold()`] का स्टेटलेस वर्जन भी माना जा सकता है।
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // यह शॉर्ट-सर्किटेड है, इसलिए शेष आइटम अभी भी इटरेटर में हैं:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// अंतिम परिणाम लौटाते हुए, एक ऑपरेशन लागू करके प्रत्येक तत्व को संचायक में बदल देता है।
    ///
    /// `fold()` दो तर्क लेता है: एक प्रारंभिक मान, और दो तर्कों के साथ एक बंद: एक 'accumulator', और एक तत्व।
    /// क्लोजर वह मान लौटाता है जो अगले पुनरावृत्ति के लिए संचायक के पास होना चाहिए।
    ///
    /// प्रारंभिक मूल्य वह मूल्य है जो संचायक के पास पहली कॉल पर होगा।
    ///
    /// इस क्लोजर को इटरेटर के प्रत्येक तत्व पर लागू करने के बाद, `fold()` संचायक लौटाता है।
    ///
    /// इस ऑपरेशन को कभी-कभी 'reduce' या 'inject' कहा जाता है।
    ///
    /// फोल्डिंग तब उपयोगी होती है जब आपके पास किसी चीज का संग्रह होता है, और आप उससे एक मूल्य उत्पन्न करना चाहते हैं।
    ///
    /// Note: `fold()`, और इसी तरह के तरीके जो पूरे पुनरावर्तक को पार करते हैं, अनंत पुनरावृत्तियों के लिए समाप्त नहीं हो सकते हैं, यहां तक कि traits पर भी जिसके लिए परिमित समय में परिणाम निर्धारित किया जा सकता है।
    ///
    /// Note: [`reduce()`] का उपयोग पहले तत्व को प्रारंभिक मान के रूप में उपयोग करने के लिए किया जा सकता है, यदि संचायक प्रकार और आइटम प्रकार समान है।
    ///
    /// # कार्यान्वयनकर्ताओं के लिए नोट
    ///
    /// अन्य (forward) विधियों में से कई में इस के संदर्भ में डिफ़ॉल्ट कार्यान्वयन हैं, इसलिए इसे स्पष्ट रूप से लागू करने का प्रयास करें यदि यह डिफ़ॉल्ट `for` लूप कार्यान्वयन से कुछ बेहतर कर सकता है।
    ///
    ///
    /// विशेष रूप से, इस कॉल को `fold()` आंतरिक भागों पर रखने का प्रयास करें जिससे यह पुनरावर्तक बना है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // सरणी के सभी तत्वों का योग
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// आइए यहां पुनरावृत्ति के प्रत्येक चरण पर चलते हैं:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// और इसलिए, हमारा अंतिम परिणाम, `6`.
    ///
    /// यह उन लोगों के लिए सामान्य है जिन्होंने परिणाम बनाने के लिए चीजों की सूची के साथ `for` लूप का उपयोग करने के लिए इटरेटर्स का बहुत उपयोग नहीं किया है।उन्हें `fold()`s में बदला जा सकता है:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // पाश के लिए:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // वे वही हैं
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// कम करने वाले ऑपरेशन को बार-बार लागू करके तत्वों को एक ही में कम कर देता है।
    ///
    /// यदि इटरेटर खाली है, तो [`None`] लौटाता है;अन्यथा, कमी का परिणाम देता है।
    ///
    /// कम से कम एक तत्व वाले पुनरावृत्तियों के लिए, यह [`fold()`] के समान है, जिसमें प्रारंभिक मान के रूप में पुनरावर्तक का पहला तत्व होता है, इसमें प्रत्येक बाद के तत्व को फोल्ड किया जाता है।
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// अधिकतम मूल्य खोजें:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// परीक्षण करें कि क्या पुनरावर्तक का प्रत्येक तत्व एक विधेय से मेल खाता है।
    ///
    /// `all()` एक क्लोजर लेता है जो `true` या `false` लौटाता है।यह इटरेटर के प्रत्येक तत्व पर इस बंद को लागू करता है, और यदि वे सभी `true` लौटाते हैं, तो `all()` भी करता है।
    /// यदि उनमें से कोई `false` लौटाता है, तो यह `false` लौटाता है।
    ///
    /// `all()` शॉर्ट-सर्किटिंग है;दूसरे शब्दों में, जैसे ही यह `false` पाता है, यह प्रसंस्करण बंद कर देगा, यह देखते हुए कि और कुछ भी हो, परिणाम भी `false` होगा।
    ///
    ///
    /// एक खाली इटरेटर `true` देता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// पहले `false` पर रुकना:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // हम अभी भी `iter` का उपयोग कर सकते हैं, क्योंकि और भी तत्व हैं।
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// परीक्षण करें कि क्या पुनरावर्तक का कोई तत्व एक विधेय से मेल खाता है।
    ///
    /// `any()` एक क्लोजर लेता है जो `true` या `false` लौटाता है।यह इटरेटर के प्रत्येक तत्व पर इस बंद को लागू करता है, और यदि उनमें से कोई भी `true` लौटाता है, तो `any()` भी करता है।
    /// यदि वे सभी `false` लौटाते हैं, तो यह `false` लौटाता है।
    ///
    /// `any()` शॉर्ट-सर्किटिंग है;दूसरे शब्दों में, जैसे ही यह `true` पाता है, यह प्रसंस्करण बंद कर देगा, यह देखते हुए कि और कुछ भी हो, परिणाम भी `true` होगा।
    ///
    ///
    /// एक खाली इटरेटर `false` देता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// पहले `true` पर रुकना:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // हम अभी भी `iter` का उपयोग कर सकते हैं, क्योंकि और भी तत्व हैं।
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// एक पुनरावर्तक के एक तत्व की खोज करता है जो एक विधेय को संतुष्ट करता है।
    ///
    /// `find()` एक क्लोजर लेता है जो `true` या `false` लौटाता है।
    /// यह इस क्लोजर को इटरेटर के प्रत्येक तत्व पर लागू करता है, और यदि उनमें से कोई भी `true` लौटाता है, तो `find()` [`Some(element)`] लौटाता है।
    /// यदि वे सभी `false` लौटाते हैं, तो यह [`None`] लौटाता है।
    ///
    /// `find()` शॉर्ट-सर्किटिंग है;दूसरे शब्दों में, जैसे ही क्लोजर `true` वापस आता है, यह प्रोसेसिंग बंद कर देगा।
    ///
    /// क्योंकि `find()` एक संदर्भ लेता है, और कई पुनरावर्तक संदर्भों पर पुनरावृति करते हैं, यह संभावित रूप से भ्रमित करने वाली स्थिति की ओर जाता है जहां तर्क एक दोहरा संदर्भ है।
    ///
    /// आप इस प्रभाव को नीचे दिए गए उदाहरणों में `&&x` के साथ देख सकते हैं।
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// पहले `true` पर रुकना:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // हम अभी भी `iter` का उपयोग कर सकते हैं, क्योंकि और भी तत्व हैं।
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// ध्यान दें कि `iter.find(f)`, `iter.filter(f).next()` के बराबर है।
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// इटरेटर के तत्वों पर कार्य लागू करता है और पहला गैर-कोई नहीं परिणाम देता है।
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()` के बराबर है।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// इटरेटर के तत्वों पर फ़ंक्शन लागू करता है और पहला सही परिणाम या पहली त्रुटि देता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// एक पुनरावर्तक में एक तत्व की खोज करता है, इसकी अनुक्रमणिका लौटाता है।
    ///
    /// `position()` एक क्लोजर लेता है जो `true` या `false` लौटाता है।
    /// यह इस क्लोजर को इटरेटर के प्रत्येक तत्व पर लागू करता है, और यदि उनमें से एक `true` लौटाता है, तो `position()` [`Some(index)`] लौटाता है।
    /// यदि वे सभी `false` लौटाते हैं, तो यह [`None`] लौटाता है।
    ///
    /// `position()` शॉर्ट-सर्किटिंग है;दूसरे शब्दों में, जैसे ही इसे `true` मिलेगा, यह प्रोसेसिंग बंद कर देगा।
    ///
    /// # अतिप्रवाह व्यवहार
    ///
    /// विधि अतिप्रवाह के खिलाफ कोई सुरक्षा नहीं करती है, इसलिए यदि [`usize::MAX`] से अधिक गैर-मिलान तत्व हैं, तो यह या तो गलत परिणाम या panics उत्पन्न करता है।
    ///
    /// यदि डिबग अभिकथन सक्षम हैं, तो panic की गारंटी है।
    ///
    /// # Panics
    ///
    /// यह फ़ंक्शन panic हो सकता है यदि इटरेटर में `usize::MAX` से अधिक गैर-मिलान तत्व हैं।
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// पहले `true` पर रुकना:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // हम अभी भी `iter` का उपयोग कर सकते हैं, क्योंकि और भी तत्व हैं।
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // लौटाया गया सूचकांक इटरेटर राज्य पर निर्भर करता है
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// एक पुनरावर्तक में दाईं ओर से एक तत्व की खोज करता है, इसकी अनुक्रमणिका लौटाता है।
    ///
    /// `rposition()` एक क्लोजर लेता है जो `true` या `false` लौटाता है।
    /// यह अंत से शुरू होने वाले इटरेटर के प्रत्येक तत्व पर इस बंद को लागू करता है, और यदि उनमें से एक `true` लौटाता है, तो `rposition()` [`Some(index)`] देता है।
    ///
    /// यदि वे सभी `false` लौटाते हैं, तो यह [`None`] लौटाता है।
    ///
    /// `rposition()` शॉर्ट-सर्किटिंग है;दूसरे शब्दों में, जैसे ही इसे `true` मिलेगा, यह प्रोसेसिंग बंद कर देगा।
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// पहले `true` पर रुकना:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // हम अभी भी `iter` का उपयोग कर सकते हैं, क्योंकि और भी तत्व हैं।
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // यहां अतिप्रवाह जांच की कोई आवश्यकता नहीं है, क्योंकि `ExactSizeIterator` का तात्पर्य है कि तत्वों की संख्या `usize` में फिट होती है।
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// एक पुनरावर्तक का अधिकतम तत्व लौटाता है।
    ///
    /// यदि कई तत्व समान रूप से अधिकतम हैं, तो अंतिम तत्व वापस कर दिया जाता है।
    /// यदि इटरेटर खाली है, तो [`None`] वापस कर दिया जाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// एक पुनरावर्तक का न्यूनतम तत्व लौटाता है।
    ///
    /// यदि कई तत्व समान रूप से न्यूनतम हैं, तो पहला तत्व वापस कर दिया जाता है।
    /// यदि इटरेटर खाली है, तो [`None`] वापस कर दिया जाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// वह तत्व लौटाता है जो निर्दिष्ट फ़ंक्शन से अधिकतम मान देता है।
    ///
    ///
    /// यदि कई तत्व समान रूप से अधिकतम हैं, तो अंतिम तत्व वापस कर दिया जाता है।
    /// यदि इटरेटर खाली है, तो [`None`] वापस कर दिया जाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// वह तत्व लौटाता है जो निर्दिष्ट तुलना फ़ंक्शन के संबंध में अधिकतम मान देता है।
    ///
    ///
    /// यदि कई तत्व समान रूप से अधिकतम हैं, तो अंतिम तत्व वापस कर दिया जाता है।
    /// यदि इटरेटर खाली है, तो [`None`] वापस कर दिया जाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// वह तत्व लौटाता है जो निर्दिष्ट फ़ंक्शन से न्यूनतम मान देता है।
    ///
    ///
    /// यदि कई तत्व समान रूप से न्यूनतम हैं, तो पहला तत्व वापस कर दिया जाता है।
    /// यदि इटरेटर खाली है, तो [`None`] वापस कर दिया जाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// वह तत्व लौटाता है जो निर्दिष्ट तुलना फ़ंक्शन के संबंध में न्यूनतम मान देता है।
    ///
    ///
    /// यदि कई तत्व समान रूप से न्यूनतम हैं, तो पहला तत्व वापस कर दिया जाता है।
    /// यदि इटरेटर खाली है, तो [`None`] वापस कर दिया जाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// एक पुनरावर्तक की दिशा उलट देता है।
    ///
    /// आमतौर पर, पुनरावृत्त बाएं से दाएं पुनरावृति करते हैं।
    /// `rev()` का उपयोग करने के बाद, एक पुनरावर्तक इसके बजाय दाएं से बाएं पुनरावृति करेगा।
    ///
    /// यह तभी संभव है जब इटरेटर का अंत हो, इसलिए `rev()` केवल [`DoubleEndedIterator`] s पर काम करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// जोड़े के एक पुनरावर्तक को कंटेनरों की एक जोड़ी में परिवर्तित करता है।
    ///
    /// `unzip()` जोड़े के पूरे पुनरावर्तक का उपभोग करता है, दो संग्रह उत्पन्न करता है: एक जोड़े के बाएं तत्वों से, और एक दाएं तत्वों से।
    ///
    ///
    /// यह फ़ंक्शन, कुछ अर्थों में, [`zip`] के विपरीत है।
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// एक पुनरावर्तक बनाता है जो इसके सभी तत्वों की प्रतिलिपि बनाता है।
    ///
    /// यह तब उपयोगी होता है जब आपके पास `&T` पर एक पुनरावर्तक होता है, लेकिन आपको `T` पर एक पुनरावर्तक की आवश्यकता होती है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // कॉपी किया गया .map(|&x| x). जैसा ही है
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// एक पुनरावर्तक बनाता है जो [`क्लोन`] अपने सभी तत्वों को बनाता है।
    ///
    /// यह तब उपयोगी होता है जब आपके पास `&T` पर एक पुनरावर्तक होता है, लेकिन आपको `T` पर एक पुनरावर्तक की आवश्यकता होती है।
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // क्लोन .map(|&x| x) के समान है, पूर्णांकों के लिए
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// एक पुनरावर्तक को अंतहीन रूप से दोहराता है।
    ///
    /// [`None`] पर रुकने के बजाय, इटरेटर शुरुआत से फिर से शुरू हो जाएगा।पुन: पुनरावृति के बाद, यह पुन: प्रारंभ में प्रारंभ होगा।और फिर।
    /// और फिर।
    /// Forever.
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// एक पुनरावर्तक के तत्वों का योग।
    ///
    /// प्रत्येक तत्व लेता है, उन्हें एक साथ जोड़ता है, और परिणाम देता है।
    ///
    /// एक खाली इटरेटर प्रकार का शून्य मान देता है।
    ///
    /// # Panics
    ///
    /// जब `sum()` को कॉल किया जाता है और एक आदिम पूर्णांक प्रकार लौटाया जा रहा है, तो यह विधि panic होगी यदि गणना अतिप्रवाह और डीबग अभिकथन सक्षम हैं।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// सभी तत्वों को गुणा करते हुए पूरे इटरेटर पर पुनरावृति करता है
    ///
    /// एक खाली इटरेटर प्रकार का एक मान देता है।
    ///
    /// # Panics
    ///
    /// जब `product()` को कॉल किया जाता है और एक आदिम पूर्णांक प्रकार लौटाया जा रहा है, तो विधि panic होगी यदि गणना अतिप्रवाह और डीबग अभिकथन सक्षम हैं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) इस [`Iterator`] के तत्वों की तुलना दूसरे के तत्वों से करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) निर्दिष्ट तुलना फ़ंक्शन के संबंध में इस [`Iterator`] के तत्वों की तुलना दूसरे के साथ करता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) इस [`Iterator`] के तत्वों की तुलना दूसरे के तत्वों से करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) निर्दिष्ट तुलना फ़ंक्शन के संबंध में इस [`Iterator`] के तत्वों की तुलना दूसरे के साथ करता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// निर्धारित करता है कि क्या इस [`Iterator`] के अवयव दूसरे के समान हैं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// निर्धारित करता है कि निर्दिष्ट समानता फ़ंक्शन के संबंध में इस [`Iterator`] के तत्व दूसरे के बराबर हैं या नहीं।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// निर्धारित करता है कि इस [`Iterator`] के अवयव दूसरे के अवयव से असमान हैं या नहीं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// निर्धारित करता है कि इस [`Iterator`] के अवयव [lexicographically](Ord#lexicographical-comparison) दूसरे के अवयव से कम हैं या नहीं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// निर्धारित करता है कि इस [`Iterator`] के अवयव [lexicographically](Ord#lexicographical-comparison) कम हैं या दूसरे के बराबर हैं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// निर्धारित करता है कि इस [`Iterator`] के अवयव [lexicographically](Ord#lexicographical-comparison) दूसरे से बड़े हैं या नहीं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// निर्धारित करता है कि इस [`Iterator`] के अवयव [lexicographically](Ord#lexicographical-comparison) दूसरे से बड़े या बराबर हैं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// जाँचता है कि क्या इस इटरेटर के तत्वों को क्रमबद्ध किया गया है।
    ///
    /// अर्थात्, प्रत्येक तत्व `a` और उसके निम्नलिखित तत्व `b`, `a <= b` को धारण करना चाहिए।यदि इटरेटर बिल्कुल शून्य या एक तत्व उत्पन्न करता है, तो `true` वापस कर दिया जाता है।
    ///
    /// ध्यान दें कि यदि `Self::Item` केवल `PartialOrd` है, लेकिन `Ord` नहीं है, तो उपरोक्त परिभाषा का अर्थ है कि यदि कोई दो लगातार आइटम तुलनीय नहीं हैं तो यह फ़ंक्शन `false` लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// जाँचता है कि क्या इस इटरेटर के तत्वों को दिए गए तुलनित्र फ़ंक्शन का उपयोग करके सॉर्ट किया गया है।
    ///
    /// `PartialOrd::partial_cmp` का उपयोग करने के बजाय, यह फ़ंक्शन दो तत्वों के क्रम को निर्धारित करने के लिए दिए गए `compare` फ़ंक्शन का उपयोग करता है।
    /// इसके अलावा, यह [`is_sorted`] के बराबर है;अधिक जानकारी के लिए इसके दस्तावेज़ देखें।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// जाँचता है कि क्या इस इटरेटर के तत्वों को दिए गए कुंजी निष्कर्षण फ़ंक्शन का उपयोग करके सॉर्ट किया गया है।
    ///
    /// इटरेटर के तत्वों की सीधे तुलना करने के बजाय, यह फ़ंक्शन तत्वों की कुंजियों की तुलना करता है, जैसा कि `f` द्वारा निर्धारित किया गया है।
    /// इसके अलावा, यह [`is_sorted`] के बराबर है;अधिक जानकारी के लिए इसके दस्तावेज़ देखें।
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// देखें [TrustedRandomAccess]
    // विधि समाधान में नाम टकराव से बचने के लिए असामान्य नाम है #76479 देखें।
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}