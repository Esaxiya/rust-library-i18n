/// एक [`Iterator`] से रूपांतरण।
///
/// एक प्रकार के लिए `FromIterator` को लागू करके, आप परिभाषित करते हैं कि इसे एक पुनरावर्तक से कैसे बनाया जाएगा।
/// यह उन प्रकारों के लिए सामान्य है जो किसी प्रकार के संग्रह का वर्णन करते हैं।
///
/// [`FromIterator::from_iter()`] शायद ही कभी स्पष्ट रूप से कहा जाता है, और इसके बजाय [`Iterator::collect()`] विधि के माध्यम से उपयोग किया जाता है।
///
/// अधिक उदाहरणों के लिए [`Iterator::collect()`]'s दस्तावेज़ीकरण देखें।
///
/// यह सभी देखें: [`IntoIterator`].
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// परोक्ष रूप से `FromIterator` का उपयोग करने के लिए [`Iterator::collect()`] का उपयोग करना:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// अपने प्रकार के लिए `FromIterator` कार्यान्वित करना:
///
/// ```
/// use std::iter::FromIterator;
///
/// // एक नमूना संग्रह, यह सिर्फ Vec. के ऊपर एक आवरण है<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // आइए इसे कुछ तरीके दें ताकि हम एक बना सकें और उसमें चीजें जोड़ सकें।
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // और हम FromIterator को लागू करेंगे
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // अब हम एक नया इटरेटर बना सकते हैं ...
/// let iter = (0..5).into_iter();
///
/// // ... और उसमें से एक MyCollection बनाएं
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // काम भी इकट्ठा करो!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// एक पुनरावर्तक से एक मूल्य बनाता है।
    ///
    /// अधिक के लिए [module-level documentation] देखें।
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`] में रूपांतरण।
///
/// एक प्रकार के लिए `IntoIterator` को लागू करके, आप परिभाषित करते हैं कि इसे एक पुनरावर्तक में कैसे परिवर्तित किया जाएगा।
/// यह उन प्रकारों के लिए सामान्य है जो किसी प्रकार के संग्रह का वर्णन करते हैं।
///
/// `IntoIterator` को लागू करने का एक लाभ यह है कि आपका प्रकार [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) होगा।
///
///
/// यह सभी देखें: [`FromIterator`].
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// अपने प्रकार के लिए `IntoIterator` कार्यान्वित करना:
///
/// ```
/// // एक नमूना संग्रह, यह सिर्फ Vec. के ऊपर एक आवरण है<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // आइए इसे कुछ तरीके दें ताकि हम एक बना सकें और उसमें चीजें जोड़ सकें।
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // और हम IntoIterator को लागू करेंगे
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // अब हम एक नया संग्रह बना सकते हैं...
/// let mut c = MyCollection::new();
///
/// // ... इसमें कुछ सामान जोड़ें ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... और फिर इसे एक इटरेटर में बदल दें:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` को trait bound के रूप में उपयोग करना आम बात है।यह इनपुट संग्रह प्रकार को बदलने की अनुमति देता है, जब तक कि यह अभी भी एक पुनरावर्तक है।
/// अतिरिक्त सीमाओं को सीमित करके निर्दिष्ट किया जा सकता है
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// तत्वों के प्रकार पर पुनरावृति की जा रही है।
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// हम इसे किस प्रकार के इटरेटर में बदल रहे हैं?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// एक मूल्य से एक पुनरावर्तक बनाता है।
    ///
    /// अधिक के लिए [module-level documentation] देखें।
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// एक पुनरावर्तक की सामग्री के साथ एक संग्रह बढ़ाएँ।
///
/// इटरेटर मूल्यों की एक श्रृंखला उत्पन्न करते हैं, और संग्रह को मूल्यों की एक श्रृंखला के रूप में भी माना जा सकता है।
/// `Extend` trait इस अंतर को पाटता है, जिससे आप उस पुनरावर्तक की सामग्री को शामिल करके संग्रह का विस्तार कर सकते हैं।
/// पहले से मौजूद कुंजी के साथ संग्रह का विस्तार करते समय, उस प्रविष्टि को अद्यतन किया जाता है या, संग्रह के मामले में जो समान कुंजियों वाली एकाधिक प्रविष्टियों की अनुमति देता है, वह प्रविष्टि डाली जाती है।
///
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// // आप कुछ वर्णों के साथ एक स्ट्रिंग का विस्तार कर सकते हैं:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` लागू करना:
///
/// ```
/// // एक नमूना संग्रह, यह सिर्फ Vec. के ऊपर एक आवरण है<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // आइए इसे कुछ तरीके दें ताकि हम एक बना सकें और उसमें चीजें जोड़ सकें।
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // चूंकि MyCollection में i32s की सूची है, इसलिए हम i32 के लिए एक्सटेंड लागू करते हैं
/// impl Extend<i32> for MyCollection {
///
///     // यह ठोस प्रकार के हस्ताक्षर के साथ थोड़ा आसान है: हम किसी भी चीज पर विस्तार कर सकते हैं जिसे इटरेटर में बदल दिया जा सकता है जो हमें i32s देता है।
///     // क्योंकि हमें MyCollection में डालने के लिए i32s की आवश्यकता है।
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // कार्यान्वयन बहुत सीधा है: पुनरावर्तक के माध्यम से लूप, और प्रत्येक तत्व को add() स्वयं के लिए।
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // आइए अपने संग्रह को तीन और संख्याओं के साथ बढ़ाएं
/// c.extend(vec![1, 2, 3]);
///
/// // हमने इन तत्वों को अंत में जोड़ा है
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// एक पुनरावर्तक की सामग्री के साथ एक संग्रह बढ़ाता है।
    ///
    /// चूंकि इस trait के लिए यह एकमात्र आवश्यक विधि है, इसलिए [trait-level] डॉक्स में अधिक विवरण हैं।
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// // आप कुछ वर्णों के साथ एक स्ट्रिंग का विस्तार कर सकते हैं:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// बिल्कुल एक तत्व के साथ संग्रह बढ़ाता है।
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// अतिरिक्त तत्वों की दी गई संख्या के लिए संग्रह में क्षमता आरक्षित करता है।
    ///
    /// डिफ़ॉल्ट कार्यान्वयन से कुछ भी नहीं होता है।
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}