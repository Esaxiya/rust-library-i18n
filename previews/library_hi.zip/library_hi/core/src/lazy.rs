//! आलसी मूल्य और स्थिर डेटा का एक बार का आरंभ।

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// एक सेल जिसे केवल एक बार लिखा जा सकता है।
///
/// `RefCell` के विपरीत, एक `OnceCell` केवल अपने मूल्य के लिए साझा `&T` संदर्भ प्रदान करता है।
/// `Cell` के विपरीत, `OnceCell` को इसे एक्सेस करने के लिए मान को कॉपी करने या बदलने की आवश्यकता नहीं है।
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // अपरिवर्तनीय: अधिकतम एक बार लिखा गया।
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// एक नया खाली सेल बनाता है।
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// अंतर्निहित मूल्य का संदर्भ प्राप्त करें।
    ///
    /// यदि सेल खाली है तो `None` लौटाता है।
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // सुरक्षा: `आंतरिक` के अपरिवर्तनीय होने के कारण सुरक्षित
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// अंतर्निहित मूल्य के लिए परिवर्तनीय संदर्भ प्राप्त करें।
    ///
    /// यदि सेल खाली है तो `None` लौटाता है।
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // सुरक्षा: सुरक्षित है क्योंकि हमारे पास अद्वितीय पहुंच है
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// सेल की सामग्री को `value` पर सेट करता है।
    ///
    /// # Errors
    ///
    /// यह विधि `Ok(())` लौटाती है यदि कक्ष खाली था और `Err(value)` यदि यह भरा हुआ था।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // सुरक्षा: सुरक्षित है क्योंकि हमारे पास अतिव्यापी परिवर्तनीय उधार नहीं हो सकते हैं
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // सुरक्षा: यह एकमात्र स्थान है जहां हम स्लॉट सेट करते हैं, कोई दौड़ नहीं
        // reentrancy/concurrency के कारण संभव है, और हमने जाँच की है कि स्लॉट वर्तमान में `None` है, इसलिए यह लेखन `आंतरिक` के अपरिवर्तनीय को बनाए रखता है।
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// सेल की सामग्री प्राप्त करता है, यदि सेल खाली था तो इसे `f` से प्रारंभ करें।
    ///
    /// # Panics
    ///
    /// यदि `f` panics, panic को कॉलर के लिए प्रचारित किया जाता है, और सेल अप्रारंभीकृत रहता है।
    ///
    ///
    /// `f` से सेल को रीएंट्रेंटली इनिशियलाइज़ करना एक त्रुटि है।ऐसा करने से panic बनता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// सेल की सामग्री प्राप्त करता है, यदि सेल खाली था तो इसे `f` से प्रारंभ करें।
    /// यदि सेल खाली था और `f` विफल हो गया, तो एक त्रुटि वापस आ जाती है।
    ///
    /// # Panics
    ///
    /// यदि `f` panics, panic को कॉलर के लिए प्रचारित किया जाता है, और सेल अप्रारंभीकृत रहता है।
    ///
    ///
    /// `f` से सेल को रीएंट्रेंटली इनिशियलाइज़ करना एक त्रुटि है।ऐसा करने से panic बनता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // ध्यान दें कि *कुछ* रीएंट्रेंट इनिशियलाइज़ेशन के रूप UB को जन्म दे सकते हैं (देखें `reentrant_init` टेस्ट)।
        // मेरा मानना है कि इस `assert` को हटाना, जबकि `set/get` रखना अच्छा होगा, लेकिन यह panic के लिए बेहतर लगता है, बजाय इसके कि चुपचाप पुराने मान का उपयोग किया जाए।
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// सेल का उपभोग करता है, लिपटे मूल्य को वापस करता है।
    ///
    /// यदि सेल खाली था तो `None` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // क्योंकि `into_inner` `self` को मान के आधार पर लेता है, संकलक स्थिर रूप से सत्यापित करता है कि यह वर्तमान में उधार नहीं लिया गया है।
        // इसलिए `Option<T>` को बाहर ले जाना सुरक्षित है।
        self.inner.into_inner()
    }

    /// इस `OnceCell` से मान निकालता है, इसे वापस एक प्रारंभिक अवस्था में ले जाता है।
    ///
    /// कोई प्रभाव नहीं पड़ता है और यदि `OnceCell` को प्रारंभ नहीं किया गया है तो `None` लौटाता है।
    ///
    /// एक परिवर्तनीय संदर्भ की आवश्यकता के द्वारा सुरक्षा की गारंटी है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// एक मान जिसे पहली पहुंच पर प्रारंभ किया जाता है।
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   तैयार आरंभीकरण
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// दिए गए इनिशियलाइज़िंग फंक्शन के साथ एक नया आलसी मान बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// इस आलसी मूल्य के मूल्यांकन को बाध्य करता है और परिणाम का संदर्भ देता है।
    ///
    ///
    /// यह `Deref` impl के बराबर है, लेकिन स्पष्ट है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// प्रारंभिक फ़ंक्शन के रूप में `Default` का उपयोग करके एक नया आलसी मान बनाता है।
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}