//! एक निश्चित लंबाई तक निश्चित-लंबाई वाले सरणियों के लिए `Eq` जैसी चीजों का कार्यान्वयन।
//! आखिरकार, हमें सभी लंबाई तक सामान्यीकरण करने में सक्षम होना चाहिए।
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// `T` के संदर्भ को लंबाई 1 की एक सरणी के संदर्भ में परिवर्तित करता है (प्रतिलिपि बनाए बिना)।
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // सुरक्षा: `&T` को `&[T; 1]` में कनवर्ट करना ध्वनि है।
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// `T` के एक परिवर्तनीय संदर्भ को लंबाई 1 (प्रतिलिपि के बिना) की एक सरणी के लिए एक परिवर्तनीय संदर्भ में परिवर्तित करता है।
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // सुरक्षा: `&mut T` को `&mut [T; 1]` में कनवर्ट करना ध्वनि है।
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// उपयोगिता trait केवल निश्चित आकार के सरणियों पर लागू की गई
///
/// इस trait का उपयोग अन्य traits को निश्चित आकार के सरणियों पर अधिक मेटाडेटा ब्लोट पैदा किए बिना लागू करने के लिए किया जा सकता है।
///
/// कार्यान्वयनकर्ताओं को निश्चित आकार के सरणियों तक सीमित करने के लिए trait को असुरक्षित चिह्नित किया गया है।
/// इस trait का एक उपयोगकर्ता यह मान सकता है कि कार्यान्वयनकर्ताओं के पास एक निश्चित आकार सरणी (उदाहरण के लिए, असुरक्षित आरंभीकरण के लिए) की स्मृति में सटीक लेआउट है।
///
///
/// ध्यान दें कि traits [`AsRef`] और [`AsMut`] उन प्रकारों के लिए समान तरीके प्रदान करते हैं जो निश्चित आकार के सरणियाँ नहीं हो सकते हैं।
/// कार्यान्वयनकर्ताओं को इसके बजाय traits पसंद करना चाहिए।
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// सरणी को अपरिवर्तनीय स्लाइस में परिवर्तित करता है
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// सरणी को परिवर्तनशील स्लाइस में परिवर्तित करता है
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// एक स्लाइस से एक सरणी में रूपांतरण विफल होने पर त्रुटि प्रकार वापस आ गया।
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // सुरक्षा: ठीक है क्योंकि हमने अभी जांच की है कि लंबाई फिट बैठती है
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // सुरक्षा: ठीक है क्योंकि हमने अभी जांच की है कि लंबाई फिट बैठती है
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: कोड ब्लोट को कम करने के लिए कुछ कम महत्वपूर्ण इम्प्लांट्स को छोड़ दिया जाता है
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// सरणियों की तुलना लागू करता है [lexicographically](Ord#lexicographical-comparison)।
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// डिफ़ॉल्ट इम्प्लांट्स को कॉन्स्ट जेनरिक के साथ नहीं किया जा सकता है क्योंकि `[T; 0]` को डिफॉल्ट को लागू करने की आवश्यकता नहीं है, और अलग-अलग नंबरों के लिए अलग-अलग इम्प्लांट ब्लॉक अभी तक समर्थित नहीं हैं।
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// `self` के समान आकार की एक सरणी देता है, जिसमें फ़ंक्शन `f` क्रम में प्रत्येक तत्व पर लागू होता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // सुरक्षा: हम निश्चित रूप से जानते हैं कि यह पुनरावर्तक बिल्कुल `N` प्राप्त करेगा
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// जोड़े की एक सरणी में दो सरणियों को 'ज़िप अप' करें।
    ///
    /// `zip()` एक नई सरणी देता है जहां प्रत्येक तत्व एक टपल होता है जहां पहला तत्व पहले सरणी से आता है, और दूसरा तत्व दूसरे सरणी से आता है।
    ///
    /// दूसरे शब्दों में, यह दो सरणियों को एक साथ, एक में जोड़ देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // सुरक्षा: हम निश्चित रूप से जानते हैं कि यह पुनरावर्तक बिल्कुल `N` प्राप्त करेगा
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// एक टुकड़ा देता है जिसमें संपूर्ण सरणी होती है।`&s[..]` के बराबर।
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// एक परिवर्तनशील टुकड़ा देता है जिसमें संपूर्ण सरणी होती है।
    /// `&mut s[..]` के बराबर।
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// प्रत्येक तत्व को उधार लेता है और `self` के समान आकार के संदर्भों की एक सरणी देता है।
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// [`map`](#method.map) जैसी अन्य विधियों के साथ संयुक्त होने पर यह विधि विशेष रूप से उपयोगी है।
    /// इस तरह, आप मूल सरणी को स्थानांतरित करने से बच सकते हैं यदि इसके तत्व `Copy` नहीं हैं।
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // हम अभी भी मूल सरणी तक पहुंच सकते हैं: इसे स्थानांतरित नहीं किया गया है।
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // सुरक्षा: हम निश्चित रूप से जानते हैं कि यह पुनरावर्तक बिल्कुल `N` प्राप्त करेगा
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// प्रत्येक तत्व को परस्पर उधार लेता है और `self` के समान आकार के साथ परिवर्तनशील संदर्भों की एक सरणी देता है।
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // सुरक्षा: हम निश्चित रूप से जानते हैं कि यह पुनरावर्तक बिल्कुल `N` प्राप्त करेगा
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// `iter` से `N` आइटम खींचता है और उन्हें एक सरणी के रूप में लौटाता है।
/// यदि इटरेटर `N` से कम आइटम देता है, तो यह फ़ंक्शन अपरिभाषित व्यवहार प्रदर्शित करता है।
///
///
/// अधिक जानकारी के लिए [`collect_into_array`] देखें।
///
/// # Safety
///
/// यह गारंटी देने वाले पर निर्भर है कि `iter` कम से कम `N` आइटम देता है।
/// इस शर्त का उल्लंघन करने से अपरिभाषित व्यवहार होता है।
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: यहाँ `TrustedLen` कुछ हद तक एक प्रयोग है।यह सिर्फ एक है
    // आंतरिक कार्य, इसलिए बेझिझक इसे हटा दें यदि यह बाध्यता एक बुरा विचार है।
    // उस स्थिति में, नीचे के निचले बाउंड `debug_assert!` को हटाना भी याद रखें!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // सुरक्षा: फ़ंक्शन अनुबंध द्वारा कवर किया गया।
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// `iter` से `N` आइटम खींचता है और उन्हें एक सरणी के रूप में लौटाता है।यदि पुनरावर्तक `N` से कम आइटम देता है, तो `None` वापस कर दिया जाता है और पहले से प्राप्त सभी आइटम हटा दिए जाते हैं।
///
/// चूंकि इटरेटर को एक परिवर्तनीय संदर्भ के रूप में पारित किया जाता है और यह फ़ंक्शन `next` को अधिकतम `N` बार कॉल करता है, फिर भी शेष वस्तुओं को पुनर्प्राप्त करने के लिए इटरेटर का उपयोग किया जा सकता है।
///
///
/// यदि `iter.next()` घबराता है, तो पहले से ही इटरेटर द्वारा प्राप्त सभी आइटम गिरा दिए जाते हैं।
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // सुरक्षा: एक खाली सरणी हमेशा बसी हुई होती है और इसकी कोई वैधता नहीं होती है।
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // सुरक्षा: इस कच्चे टुकड़े में केवल आरंभिक वस्तुएं होंगी।
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // सुरक्षा: `guard.initialized` 0 से शुरू होता है, इसमें एक से बढ़ जाता है
        // लूप और लूप को N (जो कि `array.len()`) है) तक पहुँचने के बाद निरस्त कर दिया जाता है।
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // जांचें कि क्या संपूर्ण सरणी प्रारंभ की गई थी।
        if guard.initialized == N {
            mem::forget(guard);

            // सुरक्षा: उपरोक्त शर्त यह दावा करती है कि सभी तत्व हैं
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // यह केवल तभी प्राप्त होता है जब `guard.initialized` `N` तक पहुंचने से पहले इटरेटर समाप्त हो जाता है।
    //
    // यह भी ध्यान दें कि `guard` यहां गिरा दिया गया है, सभी पहले से ही आरंभिक तत्वों को छोड़ रहा है।
    None
}