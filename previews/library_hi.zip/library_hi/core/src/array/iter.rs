//! सरणियों के लिए `IntoIter` के स्वामित्व वाले पुनरावर्तक को परिभाषित करता है।

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// एक बाय-वैल्यू [array] इटरेटर।
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// यह वह सरणी है जिस पर हम पुनरावृति कर रहे हैं।
    ///
    /// अनुक्रमणिका `i` वाले तत्व जहां `alive.start <= i < alive.end` अभी तक प्राप्त नहीं हुए हैं और मान्य सरणी प्रविष्टियां हैं।
    /// सूचकांक `i < alive.start` या `i >= alive.end` वाले तत्व पहले ही प्राप्त किए जा चुके हैं और अब उन्हें एक्सेस नहीं किया जाना चाहिए!वे मृत तत्व पूरी तरह से अप्रारंभीकृत अवस्था में भी हो सकते हैं!
    ///
    ///
    /// तो अपरिवर्तनीय हैं:
    /// - `data[alive]` जीवित है (अर्थात मान्य तत्व शामिल हैं)
    /// - `data[..alive.start]` और `data[alive.end..]` मर चुके हैं (अर्थात तत्व पहले ही पढ़े जा चुके हैं और अब उन्हें छुआ नहीं जाना चाहिए!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` में वे तत्व जो अभी तक प्राप्त नहीं हुए हैं।
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// दिए गए `array` पर एक नया इटरेटर बनाता है।
    ///
    /// *नोट*: इस विधि को [`IntoIterator` is implemented for arrays][array-into-iter] के बाद future में पदावनत किया जा सकता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `&i32` के बजाय `value` का प्रकार यहां `i32` है
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // सुरक्षा: यहां ट्रांसम्यूट वास्तव में सुरक्षित है।`MaybeUninit`. के दस्तावेज़
        // promise:
        //
        // > `MaybeUninit<T>` एक ही आकार और संरेखण होने की गारंटी है
        // > `T` के रूप में।
        //
        // दस्तावेज़ `MaybeUninit<T>` की सरणी से `T` की सरणी में एक ट्रांसम्यूट भी दिखाते हैं।
        //
        //
        // इसके साथ ही, यह इनिशियलाइज़ेशन इनवेरिएंट को संतुष्ट करता है।

        // FIXME(LukasKalbertodt): वास्तव में यहां `mem::transmute` का उपयोग करें, एक बार जब यह कॉन्स्ट जेनरिक के साथ काम करता है:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // तब तक, हम एक भिन्न प्रकार के रूप में बिटवाइज़ प्रतिलिपि बनाने के लिए `mem::transmute_copy` का उपयोग कर सकते हैं, फिर `array` को भूल जाएं ताकि इसे गिराया न जाए।
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// उन सभी तत्वों का एक अपरिवर्तनीय टुकड़ा लौटाता है जो अभी तक प्राप्त नहीं हुए हैं।
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // सुरक्षा: हम जानते हैं कि `alive` के भीतर सभी तत्वों को ठीक से प्रारंभ किया गया है।
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// उन सभी तत्वों का एक परिवर्तनशील टुकड़ा लौटाता है जो अभी तक प्राप्त नहीं हुए हैं।
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // सुरक्षा: हम जानते हैं कि `alive` के भीतर सभी तत्वों को ठीक से प्रारंभ किया गया है।
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // सामने से अगला सूचकांक प्राप्त करें।
        //
        // `alive.start` को 1 से बढ़ाना, `alive` के संबंध में अपरिवर्तनीय बनाए रखता है।
        // हालाँकि, इस परिवर्तन के कारण, थोड़े समय के लिए, जीवित क्षेत्र अब `data[alive]` नहीं, बल्कि `data[idx..alive.end]` है।
        //
        self.alive.next().map(|idx| {
            // सरणी से तत्व पढ़ें।
            // सुरक्षा: `idx` के पूर्व "alive" क्षेत्र में एक सूचकांक है
            // सरणी।इस तत्व को पढ़ने का अर्थ है कि `data[idx]` को अब मृत माना जाता है (अर्थात स्पर्श न करें)।
            // चूंकि `idx` जीवित-क्षेत्र की शुरुआत थी, जीवित क्षेत्र अब `data[alive]` फिर से है, सभी अपरिवर्तनीयों को पुनर्स्थापित कर रहा है।
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // पीछे से अगला सूचकांक प्राप्त करें।
        //
        // `alive.end` को 1 से घटाना `alive` के संबंध में अपरिवर्तनीय बनाए रखता है।
        // हालाँकि, इस परिवर्तन के कारण, थोड़े समय के लिए, जीवित क्षेत्र अब `data[alive]` नहीं, बल्कि `data[alive.start..=idx]` है।
        //
        self.alive.next_back().map(|idx| {
            // सरणी से तत्व पढ़ें।
            // सुरक्षा: `idx` के पूर्व "alive" क्षेत्र में एक सूचकांक है
            // सरणी।इस तत्व को पढ़ने का अर्थ है कि `data[idx]` को अब मृत माना जाता है (अर्थात स्पर्श न करें)।
            // चूंकि `idx` जीवित-क्षेत्र का अंत था, जीवित क्षेत्र अब `data[alive]` फिर से है, सभी अपरिवर्तनीयों को पुनर्स्थापित कर रहा है।
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // सुरक्षा: यह सुरक्षित है: `as_mut_slice` बिल्कुल सब-स्लाइस लौटाता है
        // उन तत्वों की संख्या जिन्हें अभी तक बाहर नहीं निकाला गया है और जिन्हें छोड़ा जाना बाकी है।
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // अपरिवर्तनीय `लाइव.स्टार्ट <=. के कारण कभी भी अंडरफ्लो नहीं होगा
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// इटरेटर वास्तव में सही लंबाई की रिपोर्ट करता है।
// "alive" तत्वों की संख्या (जो अभी भी प्राप्त की जाएगी) `alive` की सीमा की लंबाई है।
// यह सीमा लंबाई में या तो `next` या `next_back` में घटाई गई है।
// उन विधियों में इसे हमेशा 1 से घटाया जाता है, लेकिन केवल तभी जब `Some(_)` लौटाया जाता है।
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // ध्यान दें, हमें वास्तव में ठीक उसी जीवित सीमा से मेल खाने की आवश्यकता नहीं है, इसलिए हम केवल ऑफसेट 0 में क्लोन कर सकते हैं, भले ही `self` कहीं भी हो।
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // सभी जीवित तत्वों को क्लोन करें।
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // नई सरणी में एक क्लोन लिखें, फिर उसकी जीवंत सीमा को अपडेट करें।
            // यदि panics को क्लोन कर रहे हैं, तो हम पिछले आइटम को सही ढंग से छोड़ देंगे।
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // केवल उन तत्वों को प्रिंट करें जो अभी तक प्राप्त नहीं हुए हैं: हम अब प्राप्त तत्वों तक नहीं पहुंच सकते हैं।
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}