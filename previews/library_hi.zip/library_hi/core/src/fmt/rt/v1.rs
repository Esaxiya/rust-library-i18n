//! यह एक आंतरिक मॉड्यूल है जिसका उपयोग ifmt!रनटाइम।इन संरचनाओं को समय से पहले प्रारूप स्ट्रिंग्स को प्रीकंपाइल करने के लिए स्थिर सरणी में उत्सर्जित किया जाता है।
//!
//! ये परिभाषाएं उनके `ct` समकक्षों के समान हैं, लेकिन इसमें भिन्नता है कि इन्हें स्थिर रूप से आवंटित किया जा सकता है और रनटाइम के लिए थोड़ा अनुकूलित किया जा सकता है
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// संभावित संरेखण जिन्हें स्वरूपण निर्देश के भाग के रूप में अनुरोध किया जा सकता है।
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// संकेत है कि सामग्री को वाम-संरेखित किया जाना चाहिए।
    Left,
    /// संकेत है कि सामग्री सही-संरेखित होनी चाहिए।
    Right,
    /// संकेत है कि सामग्री केंद्र-संरेखित होनी चाहिए।
    Center,
    /// संरेखण का अनुरोध नहीं किया गया था।
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) और [precision](https://doc.rust-lang.org/std/fmt/#precision) विनिर्देशकों द्वारा उपयोग किया जाता है।
#[derive(Copy, Clone)]
pub enum Count {
    /// एक शाब्दिक संख्या के साथ निर्दिष्ट, मूल्य संग्रहीत करता है
    Is(usize),
    /// `$` और `*` सिंटैक्स का उपयोग करके निर्दिष्ट, अनुक्रमणिका को `args` में संग्रहीत करता है
    Param(usize),
    /// निर्दिष्ट नहीं है
    Implied,
}