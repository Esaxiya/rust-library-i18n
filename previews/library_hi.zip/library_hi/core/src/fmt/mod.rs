//! स्ट्रिंग्स को स्वरूपित करने और प्रिंट करने के लिए उपयोगिताएँ।

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// संभावित संरेखण `Formatter::align`. द्वारा लौटाए गए
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// संकेत है कि सामग्री को वाम-संरेखित किया जाना चाहिए।
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// संकेत है कि सामग्री सही-संरेखित होनी चाहिए।
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// संकेत है कि सामग्री केंद्र-संरेखित होनी चाहिए।
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// फ़ॉर्मेटर विधियों द्वारा लौटाया गया प्रकार।
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// त्रुटि प्रकार जो किसी संदेश को स्ट्रीम में स्वरूपित करने से लौटाया जाता है।
///
/// यह प्रकार किसी त्रुटि के अलावा किसी त्रुटि के संचरण का समर्थन नहीं करता है।
/// किसी भी अतिरिक्त जानकारी को किसी अन्य माध्यम से प्रसारित करने की व्यवस्था की जानी चाहिए।
///
/// याद रखने वाली एक महत्वपूर्ण बात यह है कि `fmt::Error` प्रकार को [`std::io::Error`] या [`std::error::Error`] के साथ भ्रमित नहीं होना चाहिए, जो आपके दायरे में भी हो सकता है।
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// यूनिकोड-स्वीकार करने वाले बफ़र्स या स्ट्रीम में लिखने या फ़ॉर्मेट करने के लिए एक trait।
///
/// यह trait केवल UTF-8-एन्कोडेड डेटा स्वीकार करता है और [flushable] नहीं है।
/// यदि आप केवल यूनिकोड स्वीकार करना चाहते हैं और आपको फ्लशिंग की आवश्यकता नहीं है, तो आपको इस trait को लागू करना चाहिए;
/// अन्यथा आपको [`std::io::Write`] लागू करना चाहिए।
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// इस लेखक में एक स्ट्रिंग टुकड़ा लिखता है, यह लौटाता है कि लेखन सफल हुआ या नहीं।
    ///
    /// यह विधि केवल तभी सफल हो सकती है जब संपूर्ण स्ट्रिंग टुकड़ा सफलतापूर्वक लिखा गया हो, और यह विधि तब तक वापस नहीं आएगी जब तक कि सभी डेटा नहीं लिखा गया हो या कोई त्रुटि न हो।
    ///
    ///
    /// # Errors
    ///
    /// यह फ़ंक्शन त्रुटि पर [`Error`] का एक उदाहरण लौटाएगा।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// इस लेखक में एक [`char`] लिखता है, यह लौटाता है कि क्या लेखन सफल हुआ।
    ///
    /// एक एकल [`char`] को एक से अधिक बाइट के रूप में एन्कोड किया जा सकता है।
    /// यह विधि तभी सफल हो सकती है जब संपूर्ण बाइट अनुक्रम सफलतापूर्वक लिखा गया हो, और यह विधि तब तक वापस नहीं आएगी जब तक कि सभी डेटा नहीं लिखा गया हो या कोई त्रुटि न हो।
    ///
    ///
    /// # Errors
    ///
    /// यह फ़ंक्शन त्रुटि पर [`Error`] का एक उदाहरण लौटाएगा।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// इस trait के कार्यान्वयनकर्ताओं के साथ [`write!`] मैक्रो के उपयोग के लिए गोंद।
    ///
    /// इस पद्धति को आम तौर पर मैन्युअल रूप से नहीं, बल्कि [`write!`] मैक्रो के माध्यम से ही लागू किया जाना चाहिए।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// स्वरूपण के लिए विन्यास।
///
/// एक `Formatter` स्वरूपण से संबंधित विभिन्न विकल्पों का प्रतिनिधित्व करता है।
/// उपयोगकर्ता सीधे `फ़ॉर्मेटर` का निर्माण नहीं करते हैं;[`Debug`] और [`Display`] जैसे सभी स्वरूपण traits की `fmt` विधि में एक के लिए एक परिवर्तनीय संदर्भ पास किया गया है।
///
///
/// `Formatter` के साथ इंटरैक्ट करने के लिए, आप फ़ॉर्मेटिंग से संबंधित विभिन्न विकल्पों को बदलने के लिए विभिन्न विधियों को कॉल करेंगे।
/// उदाहरण के लिए, कृपया नीचे दिए गए `Formatter` पर परिभाषित विधियों के दस्तावेज़ देखें।
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// तर्क अनिवार्य रूप से एक अनुकूलित आंशिक रूप से लागू स्वरूपण फ़ंक्शन है, जो `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` के बराबर है।

extern "C" {
    type Opaque;
}

/// यह संरचना सामान्य "argument" का प्रतिनिधित्व करती है जिसे Xprintf परिवार के कार्यों द्वारा लिया जाता है।इसमें दिए गए मान को प्रारूपित करने के लिए एक फ़ंक्शन होता है।
/// संकलन समय पर यह सुनिश्चित किया जाता है कि फ़ंक्शन और मान के सही प्रकार हैं, और फिर इस संरचना का उपयोग एक प्रकार के तर्कों को विहित करने के लिए किया जाता है।
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// यह फ़ॉर्मेटिंग इन्फ्रास्ट्रक्चर में indices/counts से जुड़े फ़ंक्शन पॉइंटर के लिए एकल स्थिर मान की गारंटी देता है।
//
// ध्यान दें कि इस तरह परिभाषित एक फ़ंक्शन सही नहीं होगा क्योंकि फ़ंक्शंस को हमेशा unnamed_addr टैग किया जाता है और वर्तमान में LLVM IR को कम किया जाता है, इसलिए उनके पते को LLVM के लिए महत्वपूर्ण नहीं माना जाता है और जैसे कि as_usize कास्ट को गलत तरीके से संकलित किया जा सकता था।
//
// व्यवहार में, हम गैर-उपयोग वाले डेटा (स्वरूपण तर्कों की स्थिर पीढ़ी के मामले के रूप में) पर कभी भी as_usize को कॉल नहीं करते हैं, इसलिए यह केवल एक अतिरिक्त जांच है।
//
// हम मुख्य रूप से यह सुनिश्चित करना चाहते हैं कि `USIZE_MARKER` पर फंक्शन पॉइंटर के पास *only* फंक्शन के लिए एक पता है जो `&usize` को अपना पहला तर्क भी लेता है।
// यहां read_volatile यह सुनिश्चित करता है कि हम पारित संदर्भ से उपयोग को सुरक्षित रूप से तैयार कर सकते हैं और यह पता गैर-उपयोग लेने वाले फ़ंक्शन पर इंगित नहीं करता है।
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // सुरक्षा: पीटीआर एक संदर्भ है
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // सुरक्षा: `mem::transmute(x)` सुरक्षित है क्योंकि
        //     1. `&'b T` `'b` के साथ उत्पन्न होने वाले जीवनकाल को बनाए रखता है (ताकि असीमित जीवनकाल न हो)
        //     2.
        //     `&'b T` और `&'b Opaque` में एक ही मेमोरी लेआउट है (जब `T` `Sized` है, जैसा कि यहां है) `mem::transmute(f)` सुरक्षित है क्योंकि `fn(&T, &mut Formatter<'_>) -> Result` और `fn(&Opaque, &mut Formatter<'_>) -> Result` में समान ABI है (जब तक `T` `Sized` है)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // सुरक्षा: `formatter` फ़ील्ड केवल USIZE_MARKER पर सेट है यदि
            // मूल्य एक उपयोग है, इसलिए यह सुरक्षित है
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// format_args. के v1 प्रारूप में उपलब्ध झंडे
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// format_args!() मैक्रो का उपयोग करते समय, इस फ़ंक्शन का उपयोग तर्क संरचना उत्पन्न करने के लिए किया जाता है।
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// इस फ़ंक्शन का उपयोग गैर-मानक स्वरूपण मापदंडों को निर्दिष्ट करने के लिए किया जाता है।
    /// वैध तर्क संरचना बनाने के लिए `pieces` सरणी कम से कम `fmt` जितनी लंबी होनी चाहिए।
    /// साथ ही, `fmt` के भीतर कोई भी `Count` जो कि `CountIsParam` या `CountIsNextParam` है, को `argumentusize` के साथ बनाए गए तर्क को इंगित करना होगा।
    ///
    /// हालांकि, ऐसा करने में विफल रहने से असुरक्षितता नहीं होती है, लेकिन अमान्य को अनदेखा कर दिया जाएगा।
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// स्वरूपित पाठ की लंबाई का अनुमान लगाता है।
    ///
    /// `format!` का उपयोग करते समय प्रारंभिक `String` क्षमता सेट करने के लिए इसका उपयोग करने का इरादा है।
    /// Note: यह न तो निचली और न ही ऊपरी सीमा है।
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // यदि प्रारूप स्ट्रिंग एक तर्क से शुरू होती है, तो कुछ भी प्रचारित न करें, जब तक कि टुकड़ों की लंबाई महत्वपूर्ण न हो।
            //
            //
            0
        } else {
            // कुछ तर्क हैं, इसलिए कोई भी अतिरिक्त धक्का स्ट्रिंग को फिर से आवंटित करेगा।
            //
            // इससे बचने के लिए, हम यहाँ क्षमता "pre-doubling" हैं।
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// यह संरचना प्रारूप स्ट्रिंग और उसके तर्कों के सुरक्षित रूप से पूर्व-संकलित संस्करण का प्रतिनिधित्व करती है।
/// इसे रनटाइम पर जेनरेट नहीं किया जा सकता क्योंकि इसे सुरक्षित रूप से नहीं किया जा सकता है, इसलिए कोई कंस्ट्रक्टर नहीं दिया जाता है और संशोधन को रोकने के लिए फ़ील्ड निजी हैं।
///
///
/// [`format_args!`] मैक्रो सुरक्षित रूप से इस संरचना का एक उदाहरण बनाएगा।
/// मैक्रो संकलन-समय पर प्रारूप स्ट्रिंग को मान्य करता है ताकि [`write()`] और [`format()`] फ़ंक्शंस का उपयोग सुरक्षित रूप से किया जा सके।
///
/// आप `Arguments<'a>` का उपयोग कर सकते हैं जो [`format_args!`] `Debug` और `Display` संदर्भों में वापस आता है जैसा कि नीचे देखा गया है।
/// उदाहरण से यह भी पता चलता है कि `Debug` और `Display` एक ही चीज़ के प्रारूप हैं: `format_args!` में प्रक्षेपित प्रारूप स्ट्रिंग।
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // मुद्रित करने के लिए स्ट्रिंग टुकड़े प्रारूपित करें।
    pieces: &'a [&'static str],

    // प्लेसहोल्डर स्पेक्स, या `None` यदि सभी स्पेक्स डिफ़ॉल्ट हैं (जैसा कि "{}{}" में है)।
    fmt: Option<&'a [rt::v1::Argument]>,

    // इंटरपोलेशन के लिए गतिशील तर्क, स्ट्रिंग टुकड़ों के साथ इंटरलीव किए जाने के लिए।
    // (प्रत्येक तर्क से पहले एक स्ट्रिंग टुकड़ा होता है।)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// स्वरूपित स्ट्रिंग प्राप्त करें, यदि उसके पास स्वरूपित करने के लिए कोई तर्क नहीं है।
    ///
    /// इसका उपयोग सबसे तुच्छ मामले में आवंटन से बचने के लिए किया जा सकता है।
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` आउटपुट को प्रोग्रामर-फेसिंग, डिबगिंग संदर्भ में प्रारूपित करना चाहिए।
///
/// सामान्यतया, आपको केवल `derive` एक `Debug` कार्यान्वयन करना चाहिए।
///
/// जब वैकल्पिक प्रारूप विनिर्देशक `#?` के साथ उपयोग किया जाता है, तो आउटपुट सुंदर-मुद्रित होता है।
///
/// स्वरूपकों के बारे में अधिक जानकारी के लिए, [the module-level documentation][module] देखें।
///
/// [module]: ../../std/fmt/index.html
///
/// इस trait का उपयोग `#[derive]` के साथ किया जा सकता है यदि सभी फ़ील्ड `Debug` को लागू करते हैं।
/// जब स्ट्रक्चर्स के लिए `व्युत्पन्न` होता है, तो यह `struct` के नाम का उपयोग करेगा, फिर `{`, फिर प्रत्येक फ़ील्ड के नाम की अल्पविराम से अलग की गई सूची और `Debug` मान, फिर `}`।
/// `Enum` के लिए, यह वैरिएंट के नाम का उपयोग करेगा और, यदि लागू हो, तो `(`, फिर फ़ील्ड के `Debug` मान, फिर `)`।
///
/// # Stability
///
/// व्युत्पन्न `Debug` प्रारूप स्थिर नहीं हैं, और इसलिए future Rust संस्करणों के साथ बदल सकते हैं।
/// इसके अतिरिक्त, मानक पुस्तकालय (`libstd`, `libcore`, `liballoc`, आदि) द्वारा प्रदान किए गए प्रकारों के `Debug` कार्यान्वयन स्थिर नहीं हैं, और future Rust संस्करणों के साथ भी बदल सकते हैं।
///
///
/// # Examples
///
/// एक कार्यान्वयन प्राप्त करना:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// मैन्युअल रूप से कार्यान्वित करना:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// [`debug_struct`] जैसे मैन्युअल कार्यान्वयन में आपकी सहायता करने के लिए [`Formatter`] संरचना पर कई सहायक विधियां हैं।
///
/// `Debug` `derive` या डीबग बिल्डर API का उपयोग करके [`Formatter`] पर कार्यान्वयन वैकल्पिक ध्वज का उपयोग करके सुंदर-प्रिंटिंग का समर्थन करते हैं: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` के साथ सुंदर-मुद्रण:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// दिए गए फ़ॉर्मेटर का उपयोग करके मान को स्वरूपित करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// trait `Debug` के बिना prelude से मैक्रो `Debug` को पुनः निर्यात करने के लिए अलग मॉड्यूल।
pub(crate) mod macros {
    /// trait `Debug` का एक अर्थ उत्पन्न करने वाला मैक्रो व्युत्पन्न करें।
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// trait को एक खाली प्रारूप के लिए प्रारूपित करें, `{}`.
///
/// `Display` [`Debug`] के समान है, लेकिन `Display` यूजर-फेसिंग आउटपुट के लिए है, और इसलिए इसे प्राप्त नहीं किया जा सकता है।
///
///
/// स्वरूपकों के बारे में अधिक जानकारी के लिए, [the module-level documentation][module] देखें।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `Display` को एक प्रकार पर कार्यान्वित करना:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// दिए गए फ़ॉर्मेटर का उपयोग करके मान को स्वरूपित करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait को अपने आउटपुट को base-8 में एक संख्या के रूप में प्रारूपित करना चाहिए।
///
/// आदिम हस्ताक्षरित पूर्णांकों (`i8` से `i128`, और `isize`) के लिए, नकारात्मक मानों को दो पूरक प्रतिनिधित्व के रूप में स्वरूपित किया जाता है।
///
///
/// वैकल्पिक ध्वज, `#`, आउटपुट के सामने एक `0o` जोड़ता है।
///
/// स्वरूपकों के बारे में अधिक जानकारी के लिए, [the module-level documentation][module] देखें।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` के साथ मूल उपयोग:
///
/// ```
/// let x = 42; // 42 अष्टक में '52' है
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// `Octal` को एक प्रकार पर कार्यान्वित करना:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // i32 के कार्यान्वयन के लिए प्रतिनिधि
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// दिए गए फ़ॉर्मेटर का उपयोग करके मान को स्वरूपित करता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait को अपने आउटपुट को बाइनरी में एक संख्या के रूप में प्रारूपित करना चाहिए।
///
/// आदिम हस्ताक्षरित पूर्णांकों ([`i8`] से [`i128`], और [`isize`]) के लिए, नकारात्मक मानों को दो पूरक प्रतिनिधित्व के रूप में स्वरूपित किया जाता है।
///
///
/// वैकल्पिक ध्वज, `#`, आउटपुट के सामने एक `0b` जोड़ता है।
///
/// स्वरूपकों के बारे में अधिक जानकारी के लिए, [the module-level documentation][module] देखें।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] के साथ मूल उपयोग:
///
/// ```
/// let x = 42; // 42 बाइनरी में '101010' है
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// `Binary` को एक प्रकार पर कार्यान्वित करना:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // i32 के कार्यान्वयन के लिए प्रतिनिधि
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// दिए गए फ़ॉर्मेटर का उपयोग करके मान को स्वरूपित करता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait को अपने आउटपुट को हेक्साडेसिमल में एक संख्या के रूप में प्रारूपित करना चाहिए, निचले मामले में `a` से `f` के साथ।
///
/// आदिम हस्ताक्षरित पूर्णांकों (`i8` से `i128`, और `isize`) के लिए, नकारात्मक मानों को दो पूरक प्रतिनिधित्व के रूप में स्वरूपित किया जाता है।
///
///
/// वैकल्पिक ध्वज, `#`, आउटपुट के सामने एक `0x` जोड़ता है।
///
/// स्वरूपकों के बारे में अधिक जानकारी के लिए, [the module-level documentation][module] देखें।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` के साथ मूल उपयोग:
///
/// ```
/// let x = 42; // 42 हेक्स में '2a' है
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// `LowerHex` को एक प्रकार पर कार्यान्वित करना:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // i32 के कार्यान्वयन के लिए प्रतिनिधि
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// दिए गए फ़ॉर्मेटर का उपयोग करके मान को स्वरूपित करता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait को अपने आउटपुट को हेक्साडेसिमल में एक संख्या के रूप में प्रारूपित करना चाहिए, ऊपरी मामले में `A` से `F` के साथ।
///
/// आदिम हस्ताक्षरित पूर्णांकों (`i8` से `i128`, और `isize`) के लिए, नकारात्मक मानों को दो पूरक प्रतिनिधित्व के रूप में स्वरूपित किया जाता है।
///
///
/// वैकल्पिक ध्वज, `#`, आउटपुट के सामने एक `0x` जोड़ता है।
///
/// स्वरूपकों के बारे में अधिक जानकारी के लिए, [the module-level documentation][module] देखें।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` के साथ मूल उपयोग:
///
/// ```
/// let x = 42; // 42 हेक्स में '2A' है
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// `UpperHex` को एक प्रकार पर कार्यान्वित करना:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // i32 के कार्यान्वयन के लिए प्रतिनिधि
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// दिए गए फ़ॉर्मेटर का उपयोग करके मान को स्वरूपित करता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait को अपने आउटपुट को मेमोरी लोकेशन के रूप में प्रारूपित करना चाहिए।
/// इसे आमतौर पर हेक्साडेसिमल के रूप में प्रस्तुत किया जाता है।
///
/// स्वरूपकों के बारे में अधिक जानकारी के लिए, [the module-level documentation][module] देखें।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` के साथ मूल उपयोग:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // यह '0x7f06092ac6d0'. जैसा कुछ पैदा करता है
/// ```
///
/// `Pointer` को एक प्रकार पर कार्यान्वित करना:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // `*const T` में कनवर्ट करने के लिए `as` का उपयोग करें, जो पॉइंटर को लागू करता है, जिसका हम उपयोग कर सकते हैं
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// दिए गए फ़ॉर्मेटर का उपयोग करके मान को स्वरूपित करता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait को अपने आउटपुट को कम-केस `e` के साथ वैज्ञानिक संकेतन में प्रारूपित करना चाहिए।
///
/// स्वरूपकों के बारे में अधिक जानकारी के लिए, [the module-level documentation][module] देखें।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` के साथ मूल उपयोग:
///
/// ```
/// let x = 42.0; // 42.0 वैज्ञानिक संकेतन में '4.2e1' है
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// `LowerExp` को एक प्रकार पर कार्यान्वित करना:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // f64 के कार्यान्वयन के लिए प्रतिनिधि
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// दिए गए फ़ॉर्मेटर का उपयोग करके मान को स्वरूपित करता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait को अपने आउटपुट को एक अपर-केस `E` के साथ वैज्ञानिक संकेतन में प्रारूपित करना चाहिए।
///
/// स्वरूपकों के बारे में अधिक जानकारी के लिए, [the module-level documentation][module] देखें।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` के साथ मूल उपयोग:
///
/// ```
/// let x = 42.0; // 42.0 वैज्ञानिक संकेतन में '4.2E1' है
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// `UpperExp` को एक प्रकार पर कार्यान्वित करना:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // f64 के कार्यान्वयन के लिए प्रतिनिधि
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// दिए गए फ़ॉर्मेटर का उपयोग करके मान को स्वरूपित करता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` फ़ंक्शन एक आउटपुट स्ट्रीम और एक `Arguments` संरचना लेता है जिसे `format_args!` मैक्रो के साथ पूर्व-संकलित किया जा सकता है।
///
///
/// दिए गए आउटपुट स्ट्रीम में निर्दिष्ट प्रारूप स्ट्रिंग के अनुसार तर्कों को स्वरूपित किया जाएगा।
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// कृपया ध्यान दें कि [`write!`] का उपयोग करना बेहतर हो सकता है।उदाहरण:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // हम सभी तर्कों के लिए डिफ़ॉल्ट स्वरूपण पैरामीटर का उपयोग कर सकते हैं।
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // प्रत्येक युक्ति में एक समान तर्क होता है जो एक स्ट्रिंग टुकड़े से पहले होता है।
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // सुरक्षा: arg और args.args एक ही तर्क से आते हैं,
                // जो गारंटी देता है कि अनुक्रमणिका हमेशा सीमा के भीतर होती है।
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // केवल एक अनुगामी स्ट्रिंग टुकड़ा बचा हो सकता है।
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // सुरक्षा: तर्क और तर्क एक ही तर्क से आते हैं,
    // जो गारंटी देता है कि अनुक्रमणिका हमेशा सीमा के भीतर होती है।
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // सही तर्क निकालें
    debug_assert!(arg.position < args.len());
    // सुरक्षा: तर्क और तर्क एक ही तर्क से आते हैं,
    // जो गारंटी देता है कि इसका सूचकांक हमेशा सीमा के भीतर है।
    let value = unsafe { args.get_unchecked(arg.position) };

    // फिर वास्तव में कुछ प्रिंटिंग करें
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // सुरक्षा: cnt और args एक ही तर्क से आते हैं,
            // जो गारंटी देता है कि यह सूचकांक हमेशा सीमा के भीतर है।
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// किसी चीज के खत्म होने के बाद पैडिंग।`Formatter::padding` द्वारा लौटाया गया।
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// इस पोस्ट को पैडिंग लिखें।
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // हम इसे बदलना चाहते हैं
            buf: wrap(self.buf),

            // और इन्हें सुरक्षित रखें
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // फ़ॉर्मेटिंग तर्कों को पैडिंग और प्रोसेस करने के लिए उपयोग की जाने वाली सहायक विधियाँ जिनका सभी स्वरूपण traits उपयोग कर सकते हैं।
    //

    /// एक पूर्णांक के लिए सही पैडिंग करता है जो पहले से ही एक स्ट्र में उत्सर्जित हो चुका है।
    /// स्ट्र में पूर्णांक के लिए चिह्न *नहीं* होना चाहिए, जो इस विधि द्वारा जोड़ा जाएगा।
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, चाहे मूल पूर्णांक या तो धनात्मक था या शून्य।
    /// * उपसर्ग, यदि '#' वर्ण (Alternate) प्रदान किया गया है, तो यह संख्या के सामने रखा जाने वाला उपसर्ग है।
    ///
    /// * buf, बाइट सरणी जिसमें संख्या को स्वरूपित किया गया है
    ///
    /// यह फ़ंक्शन प्रदान किए गए झंडे के साथ-साथ न्यूनतम चौड़ाई के लिए सही ढंग से खाता होगा।
    /// यह सटीकता को ध्यान में नहीं रखेगा।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // हमें नंबर आउटपुट से "-" को हटाना होगा।
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // यदि यह मौजूद है, तो संकेत लिखता है, और यदि अनुरोध किया जाता है तो उपसर्ग लिखता है
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // इस बिंदु पर `width` फ़ील्ड `min-width` पैरामीटर से अधिक है।
        match self.width {
            // यदि न्यूनतम लंबाई की आवश्यकता नहीं है तो हम केवल बाइट लिख सकते हैं।
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // जांचें कि क्या हम न्यूनतम चौड़ाई से अधिक हैं, यदि ऐसा है तो हम केवल बाइट्स भी लिख सकते हैं।
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // यदि भरण वर्ण शून्य है तो चिह्न और उपसर्ग पैडिंग से पहले चला जाता है
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // अन्यथा, चिह्न और उपसर्ग पैडिंग के बाद जाता है
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// यह फ़ंक्शन एक स्ट्रिंग स्लाइस लेता है और निर्दिष्ट प्रासंगिक स्वरूपण झंडे को लागू करने के बाद इसे आंतरिक बफर में छोड़ देता है।
    /// जेनेरिक स्ट्रिंग्स के लिए पहचाने जाने वाले झंडे हैं:
    ///
    /// * चौड़ाई, न्यूनतम चौड़ाई क्या उत्सर्जित करना है
    /// * fill/align - यदि प्रदान की गई स्ट्रिंग को गद्देदार करने की आवश्यकता है तो क्या उत्सर्जित करना है और इसे कहां छोड़ना है
    /// * सटीक, उत्सर्जित करने के लिए अधिकतम लंबाई, स्ट्रिंग को छोटा कर दिया जाता है यदि यह इस लंबाई से अधिक है
    ///
    /// विशेष रूप से यह फ़ंक्शन `flag` मापदंडों की उपेक्षा करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // सुनिश्चित करें कि सामने एक तेज़ रास्ता है
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // स्ट्रिंग को स्वरूपित करने के लिए `precision` फ़ील्ड को `max-width` के रूप में व्याख्या किया जा सकता है।
        //
        let s = if let Some(max) = self.precision {
            // यदि हमारी स्ट्रिंग सटीक है, तो हमारे पास छंटनी होनी चाहिए।
            // हालाँकि अन्य झंडे जैसे `fill`, `width` और `align` को हमेशा की तरह कार्य करना चाहिए।
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM यहाँ यह साबित नहीं कर सकता कि `..i` panic `&s[..i]` नहीं होगा, लेकिन हम जानते हैं कि यह panic नहीं कर सकता।
                // `unsafe` से बचने के लिए `get` + `unwrap_or` का उपयोग करें और अन्यथा यहां कोई panic-संबंधित कोड न डालें।
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // इस बिंदु पर `width` फ़ील्ड `min-width` पैरामीटर से अधिक है।
        match self.width {
            // यदि हम अधिकतम लंबाई से कम हैं, और न्यूनतम लंबाई की कोई आवश्यकता नहीं है, तो हम केवल स्ट्रिंग का उत्सर्जन कर सकते हैं
            //
            None => self.buf.write_str(s),
            // यदि हम अधिकतम चौड़ाई से कम हैं, तो जांचें कि क्या हम न्यूनतम चौड़ाई से अधिक हैं, यदि ऐसा है तो यह स्ट्रिंग को उत्सर्जित करने जितना आसान है।
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // यदि हम अधिकतम और न्यूनतम दोनों चौड़ाई के अंतर्गत हैं, तो निर्दिष्ट स्ट्रिंग + कुछ संरेखण के साथ न्यूनतम चौड़ाई भरें।
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// प्री-पैडिंग लिखें और अलिखित पोस्ट-पैडिंग वापस करें।
    /// कॉलर्स यह सुनिश्चित करने के लिए ज़िम्मेदार हैं कि पोस्ट-पेडिंग उस चीज़ के बाद लिखी जाती है जिसे पैड किया जा रहा है।
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// स्वरूपित भागों को लेता है और पैडिंग लागू करता है।
    /// मान लें कि कॉलर ने पहले से ही आवश्यक सटीकता के साथ भागों को प्रस्तुत किया है, ताकि `self.precision` को अनदेखा किया जा सके।
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // साइन-अवेयर ज़ीरो पैडिंग के लिए, हम पहले साइन को रेंडर करते हैं और ऐसा व्यवहार करते हैं जैसे कि हमारे पास शुरू से ही कोई साइन नहीं था।
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // एक संकेत हमेशा पहले जाता है
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // स्वरूपित भागों से चिह्न हटा दें
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // शेष भाग सामान्य पैडिंग प्रक्रिया से गुजरते हैं।
            let len = formatted.len();
            let ret = if width <= len {
                // कोई गद्दी नहीं
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // यह सामान्य मामला है और हम एक शॉर्टकट लेते हैं
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // सुरक्षा: इसका उपयोग `flt2dec::Part::Num` और `flt2dec::Part::Copy` के लिए किया जाता है।
            // `flt2dec::Part::Num` के लिए उपयोग करना सुरक्षित है क्योंकि प्रत्येक चार `c` `b'0'` और `b'9'` के बीच है, जिसका अर्थ है कि `s` मान्य UTF-8 है।
            // `flt2dec::Part::Copy(buf)` के लिए उपयोग करने के लिए अभ्यास में भी शायद सुरक्षित है क्योंकि `buf` सादा ASCII होना चाहिए, लेकिन किसी के लिए `buf` के लिए `flt2dec::to_shortest_str` में खराब मान में गुजरना संभव है क्योंकि यह एक सार्वजनिक कार्य है।
            //
            // FIXME: निर्धारित करें कि क्या इसका परिणाम यूबी में हो सकता है।
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 शून्य
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// इस फ़ॉर्मेटर में निहित अंतर्निहित बफ़र को कुछ डेटा लिखता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // यह इसके बराबर है:
    ///         // लिखें! (फॉर्मेटर, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// इस उदाहरण में कुछ स्वरूपित जानकारी लिखता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// स्वरूपण के लिए झंडे
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// जब भी संरेखण होता है तो चरित्र 'fill' के रूप में उपयोग किया जाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // हम ">" के साथ संरेखण को दाईं ओर सेट करते हैं।
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// यह दर्शाता है कि किस प्रकार के संरेखण का अनुरोध किया गया था।
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// वैकल्पिक रूप से निर्दिष्ट पूर्णांक चौड़ाई जो आउटपुट होना चाहिए।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // यदि हमें चौड़ाई प्राप्त होती है, तो हम इसका उपयोग करते हैं
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // वरना हम कुछ खास नहीं करते
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// संख्यात्मक प्रकारों के लिए वैकल्पिक रूप से निर्दिष्ट परिशुद्धता।
    /// वैकल्पिक रूप से, स्ट्रिंग प्रकारों के लिए अधिकतम चौड़ाई।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // यदि हमें कोई सटीकता प्राप्त होती है, तो हम इसका उपयोग करते हैं।
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // अन्यथा हम 2 पर डिफॉल्ट करते हैं।
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// निर्धारित करता है कि क्या `+` ध्वज निर्दिष्ट किया गया था।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// निर्धारित करता है कि क्या `-` ध्वज निर्दिष्ट किया गया था।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // आप माइनस साइन चाहते हैं?एक लो!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// निर्धारित करता है कि क्या `#` ध्वज निर्दिष्ट किया गया था।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// निर्धारित करता है कि क्या `0` ध्वज निर्दिष्ट किया गया था।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // हम फ़ॉर्मेटर के विकल्पों को अनदेखा करते हैं।
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: तय करें कि हम इन दो झंडों के लिए कौन सा सार्वजनिक एपीआई चाहते हैं।
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// एक [`DebugStruct`] बिल्डर बनाता है जिसे स्ट्रक्चर्स के लिए [`fmt::Debug`] कार्यान्वयन के निर्माण में सहायता के लिए डिज़ाइन किया गया है।
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// टपल संरचनाओं के लिए `fmt::Debug` कार्यान्वयन के निर्माण में सहायता के लिए डिज़ाइन किया गया एक `DebugTuple` बिल्डर बनाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// सूची-जैसी संरचनाओं के लिए `fmt::Debug` कार्यान्वयन के निर्माण में सहायता के लिए डिज़ाइन किया गया एक `DebugList` बिल्डर बनाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// सेट-जैसी संरचनाओं के लिए `fmt::Debug` कार्यान्वयन के निर्माण में सहायता के लिए डिज़ाइन किया गया एक `DebugSet` बिल्डर बनाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// इस अधिक जटिल उदाहरण में, हम मैच हथियारों की सूची बनाने के लिए [`format_args!`] और `.debug_set()` का उपयोग करते हैं:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// मानचित्र जैसी संरचनाओं के लिए `fmt::Debug` कार्यान्वयन के निर्माण में सहायता के लिए डिज़ाइन किया गया एक `DebugMap` बिल्डर बनाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// मूल स्वरूपण traits का कार्यान्वयन

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // अगर चार को भागने की जरूरत है, तो अब तक बैकलॉग फ्लश करें और लिखें, अन्यथा छोड़ें
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // वैकल्पिक ध्वज को पहले से ही लोअरहेक्स द्वारा विशेष माना जाता है-यह दर्शाता है कि 0x के साथ उपसर्ग करना है या नहीं।
        // हम इसका उपयोग शून्य विस्तार करने या न करने के लिए करते हैं, और फिर बिना शर्त इसे उपसर्ग प्राप्त करने के लिए सेट करते हैं।
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// विभिन्न मुख्य प्रकारों के लिए Display/Debug का कार्यान्वयन

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell पारस्परिक रूप से उधार लिया गया है इसलिए हम यहां इसके मूल्य को नहीं देख सकते हैं।
                // इसके बजाय प्लेसहोल्डर दिखाएं।
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// यदि आप उम्मीद करते हैं कि परीक्षण यहां होंगे, तो इसके बजाय core/tests/fmt.rs फ़ाइल देखें, यहां सभी rt::Piece संरचनाएं बनाने की तुलना में यह बहुत आसान है।
//
// आवंटन crate में उन लोगों के लिए भी परीक्षण हैं जिन्हें आवंटन की आवश्यकता है।