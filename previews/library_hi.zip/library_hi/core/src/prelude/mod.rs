//! लिबकोर prelude
//!
//! यह मॉड्यूल libcore के उपयोगकर्ताओं के लिए अभिप्रेत है जो libstd से भी लिंक नहीं करते हैं।
//! यह मॉड्यूल डिफ़ॉल्ट रूप से आयात किया जाता है जब `#![no_std]` का उपयोग मानक पुस्तकालय के prelude के समान तरीके से किया जाता है।
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// कोर prelude का 2015 संस्करण।
///
/// अधिक के लिए [module-level documentation](self) देखें।
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// कोर prelude का 2018 संस्करण।
///
/// अधिक के लिए [module-level documentation](self) देखें।
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// कोर prelude का 2021 संस्करण।
///
/// अधिक के लिए [module-level documentation](self) देखें।
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: और चीजें जोड़ें।
}