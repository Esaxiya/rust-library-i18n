//! आदिम traits और प्रकार के मूल गुणों का प्रतिनिधित्व करने वाले प्रकार।
//!
//! Rust प्रकारों को उनके आंतरिक गुणों के अनुसार विभिन्न उपयोगी तरीकों से वर्गीकृत किया जा सकता है।
//! इन वर्गीकरणों को traits के रूप में दर्शाया गया है।
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// प्रकार जिन्हें थ्रेड सीमाओं में स्थानांतरित किया जा सकता है।
///
/// यह trait स्वचालित रूप से कार्यान्वित किया जाता है जब संकलक निर्धारित करता है कि यह उपयुक्त है।
///
/// गैर-`भेजें` प्रकार का एक उदाहरण संदर्भ-गणना सूचक [`rc::Rc`][`Rc`] है।
/// यदि दो थ्रेड [`Rc`] s को क्लोन करने का प्रयास करते हैं, जो समान संदर्भ-गणना मान की ओर इशारा करते हैं, तो वे एक ही समय में संदर्भ गणना को अपडेट करने का प्रयास कर सकते हैं, जो कि [undefined behavior][ub] है क्योंकि [`Rc`] परमाणु संचालन का उपयोग नहीं करता है।
///
/// इसका चचेरा भाई [`sync::Arc`][arc] परमाणु संचालन (कुछ उपरि खर्च) का उपयोग करता है और इस प्रकार `Send` है।
///
/// अधिक जानकारी के लिए [the Nomicon](../../nomicon/send-and-sync.html) देखें।
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// संकलन समय पर ज्ञात स्थिर आकार वाले प्रकार।
///
/// सभी प्रकार के मापदंडों में `Sized` की एक अंतर्निहित सीमा होती है।यदि यह उपयुक्त नहीं है तो इस बाउंड को हटाने के लिए विशेष सिंटैक्स `?Sized` का उपयोग किया जा सकता है।
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // संरचना FooUse(Foo<[i32]>);//त्रुटि: [i32] के लिए आकार लागू नहीं किया गया है
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// एक अपवाद trait का निहित `Self` प्रकार है।
/// trait में एक अंतर्निहित `Sized` बाध्य नहीं है क्योंकि यह [trait ऑब्जेक्ट] के साथ असंगत है, जहां परिभाषा के अनुसार, trait को सभी संभावित कार्यान्वयनकर्ताओं के साथ काम करने की आवश्यकता है, और इस प्रकार कोई भी आकार हो सकता है।
///
///
/// हालाँकि Rust आपको `Sized` को trait से बाँधने देगा, आप बाद में trait ऑब्जेक्ट बनाने के लिए इसका उपयोग नहीं कर पाएंगे:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // चलो y: &dyn बार= &Impl;//त्रुटि: trait `Bar` को ऑब्जेक्ट में नहीं बनाया जा सकता है
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // डिफ़ॉल्ट के लिए, उदाहरण के लिए, जिसके लिए आवश्यक है कि `[T]: !Default` का मूल्यांकन किया जा सके
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// प्रकार जो गतिशील रूप से आकार के प्रकार के लिए "unsized" हो सकते हैं।
///
/// उदाहरण के लिए, आकार सरणी प्रकार `[i8; 2]` `Unsize<[i8]>` और `Unsize<dyn fmt::Debug>` लागू करता है।
///
/// `Unsize` के सभी कार्यान्वयन संकलक द्वारा स्वचालित रूप से प्रदान किए जाते हैं।
///
/// `Unsize` के लिए कार्यान्वित किया जाता है:
///
/// - `[T; N]` `Unsize<[T]>` है
/// - `T` `Unsize<dyn Trait>` है जब `T: Trait`
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>` है यदि:
///   - `T: Unsize<U>`
///   - फू एक संरचना है
///   - केवल `Foo` के अंतिम क्षेत्र में एक प्रकार है जिसमें `T` शामिल है
///   - `T` किसी अन्य फ़ील्ड के प्रकार का हिस्सा नहीं है
///   - `Bar<T>: Unsize<Bar<U>>`, यदि `Foo` के अंतिम क्षेत्र में `Bar<T>` टाइप है
///
/// `Unsize` [`ops::CoerceUnsized`] के साथ प्रयोग किया जाता है ताकि "user-defined" कंटेनर जैसे [`Rc`] को गतिशील रूप से आकार के प्रकार शामिल करने की अनुमति मिल सके।
/// अधिक जानकारी के लिए [DST coercion RFC][RFC982] और [the nomicon entry on coercion][nomicon-coerce] देखें।
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// पैटर्न मिलान में उपयोग किए गए स्थिरांक के लिए आवश्यक trait।
///
/// कोई भी प्रकार जो `PartialEq` प्राप्त करता है, इस trait को स्वचालित रूप से लागू करता है, इस पर ध्यान दिए बिना कि इसके प्रकार-पैरामीटर `Eq` को लागू करते हैं या नहीं।
///
/// यदि किसी `const` आइटम में कुछ प्रकार है जो इस trait को लागू नहीं करता है, तो वह प्रकार या तो (1.) `PartialEq` को लागू नहीं करता है (जिसका अर्थ है कि स्थिरांक उस तुलना विधि को प्रदान नहीं करेगा, जो कोड पीढ़ी मानती है कि उपलब्ध है), या (2.) यह *स्वयं को लागू करता है*`PartialEq` का संस्करण (जिसे हम मानते हैं कि संरचनात्मक-समानता तुलना के अनुरूप नहीं है)।
///
///
/// उपरोक्त दोनों में से किसी भी परिदृश्य में, हम पैटर्न मिलान में ऐसे स्थिरांक के उपयोग को अस्वीकार करते हैं।
///
/// [structural match RFC][RFC1445], और [issue 63438] भी देखें, जिन्होंने विशेषता-आधारित डिज़ाइन से इस trait में माइग्रेट करने के लिए प्रेरित किया।
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// पैटर्न मिलान में उपयोग किए गए स्थिरांक के लिए आवश्यक trait।
///
/// कोई भी प्रकार जो `Eq` प्राप्त करता है, स्वचालित रूप से इस trait को लागू करता है, इस पर ध्यान दिए बिना कि इसके प्रकार के पैरामीटर `Eq` को लागू करते हैं या नहीं।
///
/// यह हमारे टाइप सिस्टम में एक सीमा के आसपास काम करने के लिए एक हैक है।
///
/// # Background
///
/// हम चाहते हैं कि पैटर्न मैचों में उपयोग किए जाने वाले प्रकार के कॉन्स्ट्स में `#[derive(PartialEq, Eq)]` विशेषता हो।
///
/// एक अधिक आदर्श दुनिया में, हम केवल यह जाँच कर उस आवश्यकता की जाँच कर सकते हैं कि दिया गया प्रकार `StructuralPartialEq` trait *और*`Eq` trait दोनों को लागू करता है।
/// हालांकि, आपके पास एडीटी हो सकते हैं जो *करते हैं*`derive(PartialEq, Eq)`, और एक ऐसा मामला हो जिसे हम संकलक स्वीकार करना चाहते हैं, और फिर भी निरंतर प्रकार `Eq` को लागू करने में विफल रहता है।
///
/// अर्थात्, इस तरह का एक मामला:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (उपरोक्त कोड में समस्या यह है कि `Wrap<fn(&())>` `PartialEq` को लागू नहीं करता है, न ही `Eq`, क्योंकि `के लिए <'a> fn(&'a _)` does not implement those traits.)
///
/// इसलिए, हम `StructuralPartialEq` और केवल `Eq` के लिए भोले-भाले चेक पर भरोसा नहीं कर सकते।
///
/// इसके आसपास काम करने के लिए एक हैक के रूप में, हम दो अलग-अलग traits का उपयोग करते हैं, जिनमें से प्रत्येक दो व्युत्पन्न (`#[derive(PartialEq)]` और `#[derive(Eq)]`) द्वारा इंजेक्ट किया जाता है और जांचता है कि ये दोनों संरचनात्मक-मिलान जाँच के भाग के रूप में मौजूद हैं।
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// प्रकार जिनके मूल्यों को केवल बिट्स की प्रतिलिपि बनाकर दोहराया जा सकता है।
///
/// डिफ़ॉल्ट रूप से, वैरिएबल बाइंडिंग में 'मूव सेमेन्टिक्स' होता है।दूसरे शब्दों में:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` में चला गया है, और इसलिए इसका उपयोग नहीं किया जा सकता है
///
/// // प्रिंट्लन! ("{: ?}", एक्स);//त्रुटि: स्थानांतरित मूल्य का उपयोग
/// ```
///
/// हालांकि, यदि कोई प्रकार `Copy` लागू करता है, तो इसके बजाय 'कॉपी सेमेन्टिक्स' है:
///
/// ```
/// // हम एक `Copy` कार्यान्वयन प्राप्त कर सकते हैं।
/// // `Clone` भी आवश्यक है, क्योंकि यह `Copy` का एक सुपरट्रेट है।
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x`. की एक प्रति है
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// यह ध्यान रखना महत्वपूर्ण है कि इन दो उदाहरणों में, केवल अंतर यह है कि क्या आपको असाइनमेंट के बाद `x` तक पहुंचने की अनुमति है।
/// हुड के तहत, एक प्रतिलिपि और एक चाल दोनों के परिणामस्वरूप स्मृति में बिट्स की प्रतिलिपि बनाई जा सकती है, हालांकि इसे कभी-कभी अनुकूलित किया जाता है।
///
/// ## मैं `Copy` को कैसे कार्यान्वित कर सकता हूं?
///
/// आपके प्रकार पर `Copy` को लागू करने के दो तरीके हैं।`derive` का उपयोग करना सबसे आसान है:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// आप `Copy` और `Clone` को मैन्युअल रूप से भी लागू कर सकते हैं:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// दोनों के बीच एक छोटा सा अंतर है: `derive` रणनीति एक `Copy` को प्रकार के मापदंडों पर बाध्य करेगी, जो हमेशा वांछित नहीं होता है।
///
/// ## `Copy` और `Clone` में क्या अंतर है?
///
/// कॉपियां परोक्ष रूप से होती हैं, उदाहरण के लिए असाइनमेंट `y = x` के भाग के रूप में।`Copy` का व्यवहार अतिभारित नहीं है;यह हमेशा एक साधारण बिट-वार कॉपी होती है।
///
/// क्लोनिंग एक स्पष्ट क्रिया है, `x.clone()`।[`Clone`] का कार्यान्वयन मूल्यों को सुरक्षित रूप से डुप्लिकेट करने के लिए आवश्यक कोई भी प्रकार-विशिष्ट व्यवहार प्रदान कर सकता है।
/// उदाहरण के लिए, [`String`] के लिए [`Clone`] के कार्यान्वयन को ढेर में पॉइंट-टू स्ट्रिंग बफर की प्रतिलिपि बनाने की आवश्यकता है।
/// [`String`] मानों की एक साधारण बिटवाइज़ कॉपी केवल पॉइंटर को कॉपी करेगी, जिससे लाइन के नीचे डबल फ्री हो जाएगा।
/// इस कारण से, [`String`] [`Clone`] है लेकिन `Copy` नहीं है।
///
/// [`Clone`] `Copy` का एक सुपरट्रेट है, इसलिए जो कुछ भी `Copy` है उसे भी [`Clone`] को लागू करना होगा।
/// यदि कोई प्रकार `Copy` है तो उसके [`Clone`] कार्यान्वयन को केवल `*self` वापस करने की आवश्यकता है (उपरोक्त उदाहरण देखें)।
///
/// ## मेरा प्रकार `Copy` कब हो सकता है?
///
/// एक प्रकार `Copy` को लागू कर सकता है यदि उसके सभी घटक `Copy` को लागू करते हैं।उदाहरण के लिए, यह संरचना `Copy` हो सकती है:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// एक संरचना `Copy` हो सकती है, और [`i32`] `Copy` है, इसलिए `Point` `Copy` होने के योग्य है।
/// इसके विपरीत, विचार करें
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `PointList` संरचना `Copy` को लागू नहीं कर सकती है, क्योंकि [`Vec<T>`] `Copy` नहीं है।यदि हम `Copy` कार्यान्वयन प्राप्त करने का प्रयास करते हैं, तो हमें एक त्रुटि मिलेगी:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// साझा संदर्भ (`&T`) भी `Copy` हैं, इसलिए एक प्रकार `Copy` हो सकता है, भले ही इसमें `T` प्रकार के साझा संदर्भ हों जो *नहीं*`Copy` हों।
/// निम्नलिखित संरचना पर विचार करें, जो `Copy` को लागू कर सकती है, क्योंकि इसमें ऊपर से हमारे गैर-`कॉपी' प्रकार `PointList` का केवल *साझा संदर्भ* होता है:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## मेरा प्रकार `Copy` कब *नहीं* हो सकता है?
///
/// कुछ प्रकार सुरक्षित रूप से कॉपी नहीं किए जा सकते।उदाहरण के लिए, `&mut T` की प्रतिलिपि बनाने से एक उपनामित परिवर्तनशील संदर्भ बन जाएगा।
/// [`String`] को कॉपी करने से [`स्ट्रिंग`] के बफर को प्रबंधित करने की जिम्मेदारी दोहराई जाएगी, जिससे डबल फ्री हो जाएगा।
///
/// बाद के मामले को सामान्य बनाना, [`Drop`] को लागू करने वाला कोई भी प्रकार `Copy` नहीं हो सकता है, क्योंकि यह अपने स्वयं के [`size_of::<T>`] बाइट्स के अलावा कुछ संसाधनों का प्रबंधन कर रहा है।
///
/// यदि आप गैर-`कॉपी' डेटा वाले किसी स्ट्रक्चर या एनम पर `Copy` को लागू करने का प्रयास करते हैं, तो आपको [E0204] त्रुटि मिलेगी।
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## मेरा टाइप `Copy` कब *चाहिए*?
///
/// सामान्यतया, यदि आपका प्रकार _can_ `Copy` को लागू करता है, तो इसे करना चाहिए।
/// हालांकि, ध्यान रखें कि `Copy` को लागू करना आपके प्रकार के सार्वजनिक API का हिस्सा है।
/// यदि future में प्रकार गैर-`कॉपी` हो सकता है, तो ब्रेकिंग एपीआई परिवर्तन से बचने के लिए, अब `Copy` कार्यान्वयन को छोड़ना समझदारी हो सकती है।
///
/// ## अतिरिक्त कार्यान्वयनकर्ता
///
/// [implementors listed below][impls] के अलावा, निम्न प्रकार भी `Copy` को लागू करते हैं:
///
/// * फ़ंक्शन आइटम प्रकार (यानी, प्रत्येक फ़ंक्शन के लिए परिभाषित विशिष्ट प्रकार)
/// * फ़ंक्शन पॉइंटर प्रकार (जैसे, `fn() -> i32`)
/// * सरणी प्रकार, सभी आकारों के लिए, यदि आइटम प्रकार भी `Copy` लागू करता है (जैसे, `[i32; 123456]`)
/// * टपल प्रकार, यदि प्रत्येक घटक `Copy` (जैसे, `()`, `(i32, bool)`) को भी लागू करता है
/// * क्लोजर प्रकार, यदि वे पर्यावरण से कोई मूल्य नहीं लेते हैं या यदि ऐसे सभी कैप्चर किए गए मान स्वयं `Copy` को लागू करते हैं।
///   ध्यान दें कि साझा संदर्भ द्वारा कैप्चर किए गए चर हमेशा `Copy` को लागू करते हैं (भले ही संदर्भ न हो), जबकि परिवर्तनीय संदर्भ द्वारा कैप्चर किए गए चर कभी भी `Copy` को लागू नहीं करते हैं।
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) यह एक प्रकार की प्रतिलिपि बनाने की अनुमति देता है जो असंतुष्ट आजीवन सीमाओं के कारण `Copy` को लागू नहीं करता है (`A<'_>` की प्रतिलिपि केवल `A<'static>: Copy` और `A<'_>: Clone` होने पर)।
// हमारे पास यह विशेषता अभी के लिए यहां है क्योंकि `Copy` पर कुछ मौजूदा विशेषज्ञताएं हैं जो पहले से ही मानक पुस्तकालय में मौजूद हैं, और अभी इस व्यवहार को सुरक्षित रूप से रखने का कोई तरीका नहीं है।
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` का एक अर्थ उत्पन्न करने वाला मैक्रो व्युत्पन्न करें।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// वे प्रकार जिनके लिए थ्रेड्स के बीच संदर्भ साझा करना सुरक्षित है।
///
/// यह trait स्वचालित रूप से कार्यान्वित किया जाता है जब संकलक निर्धारित करता है कि यह उपयुक्त है।
///
/// सटीक परिभाषा है: एक प्रकार `T` [`Sync`] है यदि और केवल यदि `&T` [`Send`] है।
/// दूसरे शब्दों में, यदि थ्रेड के बीच `&T` संदर्भ पास करते समय [undefined behavior][ub] (डेटा दौड़ सहित) की कोई संभावना नहीं है।
///
/// जैसा कि कोई उम्मीद करेगा, [`u8`] और [`f64`] जैसे आदिम प्रकार सभी [`Sync`] हैं, और इसलिए सरल कुल प्रकार हैं, जैसे टुपल्स, स्ट्रक्चर और एनम।
/// मूल [`Sync`] प्रकारों के अधिक उदाहरणों में "immutable" प्रकार जैसे `&T`, और सरल विरासत में मिली परिवर्तनशीलता, जैसे [`Box<T>`][box], [`Vec<T>`][vec] और अधिकांश अन्य संग्रह प्रकार शामिल हैं।
///
/// (उनके कंटेनर के [`सिंक`] होने के लिए सामान्य पैरामीटर [`Sync`] होना चाहिए।)
///
/// परिभाषा का कुछ आश्चर्यजनक परिणाम यह है कि `&mut T` `Sync` है (यदि `T` `Sync` है) भले ही ऐसा लगता है कि यह अतुल्यकालिक उत्परिवर्तन प्रदान कर सकता है।
/// चाल यह है कि एक साझा संदर्भ (यानी, `& &mut T`) के पीछे एक परिवर्तनीय संदर्भ केवल पढ़ने के लिए हो जाता है, जैसे कि यह `& &T` था।
/// इसलिए डेटा रेस का कोई खतरा नहीं है।
///
/// वे प्रकार जो `Sync` नहीं हैं, वे हैं जिनके पास "interior mutability" गैर-थ्रेड-सुरक्षित रूप में है, जैसे कि [`Cell`][cell] और [`RefCell`][refcell]।
/// ये प्रकार एक अपरिवर्तनीय, साझा संदर्भ के माध्यम से भी अपनी सामग्री के उत्परिवर्तन की अनुमति देते हैं।
/// उदाहरण के लिए [`Cell<T>`][cell] पर `set` विधि `&self` लेती है, इसलिए इसके लिए केवल एक साझा संदर्भ [`&Cell<T>`][cell] की आवश्यकता होती है।
/// विधि कोई सिंक्रनाइज़ेशन नहीं करती है, इस प्रकार [`Cell`][cell] `Sync` नहीं हो सकता है।
///
/// गैर-`सिंक' प्रकार का एक अन्य उदाहरण संदर्भ-गणना सूचक [`Rc`][rc] है।
/// किसी भी संदर्भ [`&Rc<T>`][rc] को देखते हुए, आप एक गैर-परमाणु तरीके से संदर्भ गणना को संशोधित करते हुए एक नया [`Rc<T>`][rc] क्लोन कर सकते हैं।
///
/// ऐसे मामलों के लिए जब किसी को थ्रेड-सुरक्षित आंतरिक परिवर्तनशीलता की आवश्यकता होती है, Rust [atomic data types] प्रदान करता है, साथ ही [`sync::Mutex`][mutex] और [`sync::RwLock`][rwlock] के माध्यम से स्पष्ट लॉकिंग भी प्रदान करता है।
/// ये प्रकार सुनिश्चित करते हैं कि कोई भी उत्परिवर्तन डेटा दौड़ का कारण नहीं बन सकता है, इसलिए प्रकार `Sync` हैं।
/// इसी तरह, [`sync::Arc`][arc] [`Rc`][rc] का थ्रेड-सुरक्षित एनालॉग प्रदान करता है।
///
/// आंतरिक परिवर्तनशीलता वाले किसी भी प्रकार को value(s) के चारों ओर [`cell::UnsafeCell`][unsafecell] आवरण का भी उपयोग करना चाहिए जिसे साझा संदर्भ के माध्यम से उत्परिवर्तित किया जा सकता है।
/// ऐसा करने में विफल होना [undefined behavior][ub] है।
/// उदाहरण के लिए, [`ट्रांसम्यूट`][ट्रांसम्यूट]-`&T` से `&mut T` में प्रवेश करना अमान्य है।
///
/// `Sync` के बारे में अधिक जानकारी के लिए [the Nomicon][nomicon-send-and-sync] देखें।
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): एक बार बीटा में `rustc_on_unimplemented` भूमि में नोट्स जोड़ने के लिए समर्थन, और यह जांचने के लिए बढ़ाया गया है कि क्या क्लोजर आवश्यकता श्रृंखला में कहीं भी है, इसे (#48534) के रूप में विस्तारित करें:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// शून्य-आकार का प्रकार उन चीज़ों को चिह्नित करने के लिए उपयोग किया जाता है जो "act like" के मालिक हैं।
///
/// अपने प्रकार में `PhantomData<T>` फ़ील्ड जोड़ना संकलक को बताता है कि आपका प्रकार कार्य करता है जैसे कि यह `T` प्रकार का मान संग्रहीत करता है, भले ही यह वास्तव में नहीं है।
/// कुछ सुरक्षा गुणों की गणना करते समय इस जानकारी का उपयोग किया जाता है।
///
/// `PhantomData<T>` का उपयोग कैसे करें, इसकी अधिक गहन व्याख्या के लिए, कृपया [the Nomicon](../../nomicon/phantom-data.html) देखें।
///
/// # एक भयानक नोट
///
/// हालांकि उन दोनों के डरावने नाम हैं, `PhantomData` और 'प्रेत प्रकार' संबंधित हैं, लेकिन समान नहीं हैं।एक प्रेत प्रकार पैरामीटर केवल एक प्रकार का पैरामीटर है जिसका उपयोग कभी नहीं किया जाता है।
/// Rust में, यह अक्सर संकलक को शिकायत करने का कारण बनता है, और समाधान `PhantomData` के माध्यम से "dummy" उपयोग को जोड़ना है।
///
/// # Examples
///
/// ## अप्रयुक्त आजीवन पैरामीटर
///
/// शायद `PhantomData` के लिए सबसे आम उपयोग मामला एक ऐसी संरचना है जिसमें अप्रयुक्त आजीवन पैरामीटर होता है, आमतौर पर कुछ असुरक्षित कोड के हिस्से के रूप में।
/// उदाहरण के लिए, यहां एक संरचना `Slice` है जिसमें `*const T` प्रकार के दो पॉइंटर्स हैं, संभवतः कहीं एक सरणी में इंगित कर रहे हैं:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// इरादा यह है कि अंतर्निहित डेटा केवल आजीवन `'a` के लिए मान्य है, इसलिए `Slice` को `'a` से आगे नहीं बढ़ना चाहिए।
/// हालांकि, इस आशय को कोड में व्यक्त नहीं किया गया है, क्योंकि आजीवन `'a` का कोई उपयोग नहीं है और इसलिए यह स्पष्ट नहीं है कि यह किस डेटा पर लागू होता है।
/// हम संकलक को यह बताकर ठीक कर सकते हैं कि *जैसे कि*`Slice` संरचना में एक संदर्भ `&'a T` है:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// इसके बदले में एनोटेशन `T: 'a` की भी आवश्यकता होती है, जो दर्शाता है कि `T` में कोई भी संदर्भ जीवन भर `'a` पर मान्य है।
///
/// `Slice` को प्रारंभ करते समय आप केवल `phantom` फ़ील्ड के लिए `PhantomData` मान प्रदान करते हैं:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## अप्रयुक्त प्रकार पैरामीटर
///
/// कभी-कभी ऐसा होता है कि आपके पास अप्रयुक्त प्रकार के पैरामीटर हैं जो इंगित करते हैं कि एक संरचना किस प्रकार का डेटा "tied" है, भले ही वह डेटा वास्तव में संरचना में ही नहीं पाया जाता है।
/// यहाँ एक उदाहरण है जहाँ यह [FFI] के साथ उत्पन्न होता है।
/// विदेशी इंटरफ़ेस विभिन्न प्रकार के Rust मानों को संदर्भित करने के लिए `*mut ()` प्रकार के हैंडल का उपयोग करता है।
/// हम संरचना `ExternalResource` पर एक प्रेत प्रकार पैरामीटर का उपयोग करके Rust प्रकार को ट्रैक करते हैं जो एक हैंडल को लपेटता है।
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## स्वामित्व और ड्रॉप चेक
///
/// `PhantomData<T>` प्रकार का फ़ील्ड जोड़ना इंगित करता है कि आपके प्रकार के पास `T` प्रकार का डेटा है।बदले में इसका तात्पर्य है कि जब आपका प्रकार गिरा दिया जाता है, तो यह `T` प्रकार के एक या अधिक उदाहरणों को छोड़ सकता है।
/// इसका असर Rust कंपाइलर के [drop check] विश्लेषण पर पड़ता है।
///
/// यदि आपकी संरचना वास्तव में `T` प्रकार का डेटा *स्वयं* नहीं है, तो संदर्भ प्रकार का उपयोग करना बेहतर है, जैसे `PhantomData<&'a T>` (ideally) या `PhantomData<*const T>` (यदि कोई जीवनकाल लागू नहीं होता है), ताकि स्वामित्व का संकेत न दिया जा सके।
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// कंपाइलर-आंतरिक trait एनम भेदभाव के प्रकार को इंगित करने के लिए प्रयोग किया जाता है।
///
/// यह trait स्वचालित रूप से हर प्रकार के लिए लागू किया गया है और [`mem::Discriminant`] में कोई गारंटी नहीं जोड़ता है।
/// `DiscriminantKind::Discriminant` और `mem::Discriminant` के बीच ट्रांसमिट करना **अपरिभाषित व्यवहार** है।
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// विवेचक का प्रकार, जिसे `mem::Discriminant` द्वारा आवश्यक trait bounds को संतुष्ट करना चाहिए।
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// कंपाइलर-आंतरिक trait यह निर्धारित करने के लिए प्रयोग किया जाता है कि किसी प्रकार में कोई `UnsafeCell` आंतरिक रूप से शामिल है, लेकिन एक संकेत के माध्यम से नहीं।
///
/// यह प्रभावित करता है, उदाहरण के लिए, उस प्रकार का `static` केवल-पढ़ने के लिए स्थिर स्मृति या लिखने योग्य स्थिर स्मृति में रखा गया है या नहीं।
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// वे प्रकार जिन्हें पिन किए जाने के बाद सुरक्षित रूप से स्थानांतरित किया जा सकता है।
///
/// Rust के पास अचल प्रकार की कोई धारणा नहीं है, और चालों (जैसे, असाइनमेंट या [`mem::replace`] के माध्यम से) को हमेशा सुरक्षित मानता है।
///
/// [`Pin`][Pin] प्रकार का उपयोग इसके बजाय टाइप सिस्टम के माध्यम से चाल को रोकने के लिए किया जाता है।[`Pin<P<T>>`][Pin] रैपर में लिपटे पॉइंटर्स `P<T>` को बाहर नहीं निकाला जा सकता है।
/// पिन करने के बारे में अधिक जानकारी के लिए [`pin` module] दस्तावेज़ीकरण देखें।
///
/// `T` के लिए `Unpin` trait को लागू करने से टाइप को पिन करने के प्रतिबंध हटा दिए जाते हैं, जो तब `T` को [`mem::replace`] जैसे कार्यों के साथ [`Pin<P<T>>`][Pin] से बाहर ले जाने की अनुमति देता है।
///
///
/// `Unpin` गैर-पिन किए गए डेटा के लिए कोई परिणाम नहीं है।
/// विशेष रूप से, [`mem::replace`] खुशी से `!Unpin` डेटा ले जाता है (यह किसी भी `&mut T` के लिए काम करता है, न कि केवल `T: Unpin` के समय)।
/// हालाँकि, आप [`Pin<P<T>>`][Pin] के अंदर लिपटे डेटा पर [`mem::replace`] का उपयोग नहीं कर सकते क्योंकि आपको उसके लिए आवश्यक `&mut T` नहीं मिल सकता है, और *वह* जो इस सिस्टम को काम करता है।
///
/// तो यह, उदाहरण के लिए, केवल `Unpin` को लागू करने वाले प्रकारों पर ही किया जा सकता है:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // हमें `mem::replace` को कॉल करने के लिए एक परिवर्तनीय संदर्भ की आवश्यकता है।
/// // हम (implicitly) द्वारा `Pin::deref_mut` को लागू करके ऐसा संदर्भ प्राप्त कर सकते हैं, लेकिन यह केवल इसलिए संभव है क्योंकि `String` `Unpin` को लागू करता है।
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// यह trait लगभग हर प्रकार के लिए स्वचालित रूप से लागू किया गया है।
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// एक मार्कर प्रकार जो `Unpin` को लागू नहीं करता है।
///
/// यदि किसी प्रकार में `PhantomPinned` है, तो यह डिफ़ॉल्ट रूप से `Unpin` को लागू नहीं करेगा।
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// आदिम प्रकारों के लिए `Copy` का कार्यान्वयन।
///
/// कार्यान्वयन जिन्हें Rust में वर्णित नहीं किया जा सकता है, उन्हें `traits::SelectionContext::copy_clone_conditions()` में `rustc_trait_selection` में कार्यान्वित किया जाता है।
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// साझा संदर्भों की प्रतिलिपि बनाई जा सकती है, लेकिन परिवर्तनीय संदर्भ *नहीं*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}