//! Traits प्रकारों के बीच रूपांतरण के लिए।
//!
//! इस मॉड्यूल में traits एक प्रकार से दूसरे प्रकार में कनवर्ट करने का एक तरीका प्रदान करता है।
//! प्रत्येक trait एक अलग उद्देश्य प्रदान करता है:
//!
//! - सस्ते संदर्भ-से-संदर्भ रूपांतरण के लिए [`AsRef`] trait लागू करें
//! - सस्ते परिवर्तनीय-से-परिवर्तनीय रूपांतरणों के लिए [`AsMut`] trait लागू करें
//! - मूल्य-से-मूल्य रूपांतरण प्राप्त करने के लिए [`From`] trait लागू करें
//! - वर्तमान crate के बाहर के प्रकारों में मूल्य-से-मूल्य रूपांतरण प्राप्त करने के लिए [`Into`] trait लागू करें
//! - [`TryFrom`] और [`TryInto`] traits [`From`] और [`Into`] की तरह व्यवहार करते हैं, लेकिन रूपांतरण विफल होने पर इसे लागू किया जाना चाहिए।
//!
//! इस मॉड्यूल में traits अक्सर सामान्य कार्यों के लिए trait bounds के रूप में उपयोग किया जाता है जैसे कि कई प्रकार के तर्कों का समर्थन किया जाता है।उदाहरण के लिए प्रत्येक trait का दस्तावेज़ीकरण देखें।
//!
//! एक पुस्तकालय लेखक के रूप में, आपको हमेशा [`Into<U>`][`Into`] या [`TryInto<U>`][`TryInto`] के बजाय [`From<T>`][`From`] या [`TryFrom<T>`][`TryFrom`] को लागू करना पसंद करना चाहिए, क्योंकि [`From`] और [`TryFrom`] अधिक लचीलापन प्रदान करते हैं और मानक पुस्तकालय में एक कंबल कार्यान्वयन के लिए मुफ्त में समान [`Into`] या [`TryInto`] कार्यान्वयन प्रदान करते हैं।
//! Rust 1.41 से पहले के संस्करण को लक्षित करते समय, वर्तमान crate के बाहर किसी प्रकार में कनवर्ट करते समय [`Into`] या [`TryInto`] को सीधे लागू करना आवश्यक हो सकता है।
//!
//! # सामान्य कार्यान्वयन
//!
//! - [`AsRef`] और [`AsMut`] ऑटो-डीरेफरेंस यदि आंतरिक प्रकार एक संदर्भ है
//! - [`From`]`<U>for T` का अर्थ है [`Into`]`</u><T><U>यू के लिए</u>
//! - [`TryFrom`]`के <U>लिए T` का अर्थ है [`TryInto`]`</u><T><U>यू के लिए</u>
//! - [`From`] और [`Into`] रिफ्लेक्सिव हैं, जिसका अर्थ है कि सभी प्रकार स्वयं `into` और स्वयं `from` कर सकते हैं
//!
//! उपयोग के उदाहरणों के लिए प्रत्येक trait देखें।
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// पहचान समारोह।
///
/// इस फ़ंक्शन के बारे में दो बातें ध्यान देने योग्य हैं:
///
/// - यह हमेशा `|x| x` जैसे क्लोजर के बराबर नहीं होता है, क्योंकि क्लोजर `x` को एक अलग प्रकार में मजबूर कर सकता है।
///
/// - यह फ़ंक्शन में दिए गए इनपुट `x` को स्थानांतरित करता है।
///
/// हालांकि ऐसा फ़ंक्शन होना अजीब लग सकता है जो इनपुट को वापस लौटाता है, कुछ दिलचस्प उपयोग हैं।
///
///
/// # Examples
///
/// अन्य, दिलचस्प, कार्यों के क्रम में कुछ भी नहीं करने के लिए `identity` का उपयोग करना:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // आइए दिखाते हैं कि एक जोड़ना एक दिलचस्प कार्य है।
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// सशर्त में `identity` को "do nothing" बेस केस के रूप में उपयोग करना:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // और भी दिलचस्प चीजें करें...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` के एक पुनरावर्तक के `Some` वेरिएंट को रखने के लिए `identity` का उपयोग करना:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// एक सस्ता संदर्भ-से-संदर्भ रूपांतरण करने के लिए प्रयुक्त होता है।
///
/// यह trait [`AsMut`] के समान है जिसका उपयोग परस्पर संदर्भों के बीच कनवर्ट करने के लिए किया जाता है।
/// यदि आपको एक महंगा रूपांतरण करने की आवश्यकता है तो [`From`] को `&T` प्रकार के साथ लागू करना या एक कस्टम फ़ंक्शन लिखना बेहतर है।
///
/// `AsRef` [`Borrow`] के समान हस्ताक्षर हैं, लेकिन [`Borrow`] कुछ पहलुओं में भिन्न है:
///
/// - `AsRef` के विपरीत, [`Borrow`] में किसी भी `T` के लिए एक ब्लैंकेट इम्प्लांट है, और इसका उपयोग किसी संदर्भ या मान को स्वीकार करने के लिए किया जा सकता है।
/// - [`Borrow`] यह भी आवश्यक है कि उधार मूल्य के लिए [`Hash`], [`Eq`] और [`Ord`] स्वामित्व वाले मूल्य के बराबर हों।
/// इस कारण से, यदि आप किसी संरचना के केवल एक क्षेत्र को उधार लेना चाहते हैं तो आप `AsRef` को लागू कर सकते हैं, लेकिन [`Borrow`] को नहीं।
///
/// **Note: यह trait विफल नहीं होना चाहिए**।यदि रूपांतरण विफल हो सकता है, तो एक समर्पित विधि का उपयोग करें जो [`Option<T>`] या [`Result<T, E>`] लौटाता है।
///
/// # सामान्य कार्यान्वयन
///
/// - `AsRef` ऑटो-डेरेफरेंस यदि आंतरिक प्रकार एक संदर्भ या एक परिवर्तनीय संदर्भ है (उदाहरण: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds का उपयोग करके हम विभिन्न प्रकार के तर्कों को तब तक स्वीकार कर सकते हैं जब तक उन्हें निर्दिष्ट प्रकार `T` में परिवर्तित किया जा सकता है।
///
/// उदाहरण के लिए: एक सामान्य फ़ंक्शन बनाकर जो `AsRef<str>` लेता है, हम व्यक्त करते हैं कि हम उन सभी संदर्भों को स्वीकार करना चाहते हैं जिन्हें एक तर्क के रूप में [`&str`] में परिवर्तित किया जा सकता है।
/// चूंकि [`String`] और [`&str`] दोनों `AsRef<str>` को लागू करते हैं, इसलिए हम दोनों को इनपुट तर्क के रूप में स्वीकार कर सकते हैं।
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// रूपांतरण करता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// एक सस्ता परिवर्तनीय-से-परिवर्तनीय संदर्भ रूपांतरण करने के लिए प्रयुक्त होता है।
///
/// यह trait [`AsRef`] के समान है लेकिन इसका उपयोग परस्पर संदर्भों के बीच परिवर्तित करने के लिए किया जाता है।
/// यदि आपको एक महंगा रूपांतरण करने की आवश्यकता है तो [`From`] को `&mut T` प्रकार के साथ लागू करना या एक कस्टम फ़ंक्शन लिखना बेहतर है।
///
/// **Note: यह trait विफल नहीं होना चाहिए**।यदि रूपांतरण विफल हो सकता है, तो एक समर्पित विधि का उपयोग करें जो [`Option<T>`] या [`Result<T, E>`] लौटाता है।
///
/// # सामान्य कार्यान्वयन
///
/// - `AsMut` ऑटो-डेरेफरेंस यदि आंतरिक प्रकार एक परिवर्तनीय संदर्भ है (उदाहरण: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// एक सामान्य कार्य के लिए `AsMut` को trait bound के रूप में उपयोग करके हम सभी परिवर्तनीय संदर्भों को स्वीकार कर सकते हैं जिन्हें `&mut T` प्रकार में परिवर्तित किया जा सकता है।
/// क्योंकि [`Box<T>`] `AsMut<T>` को लागू करता है, हम एक फ़ंक्शन `add_one` लिख सकते हैं जो सभी तर्कों को लेता है जिन्हें `&mut u64` में परिवर्तित किया जा सकता है।
/// क्योंकि [`Box<T>`] `AsMut<T>` को लागू करता है, `add_one` `&mut Box<u64>` प्रकार के तर्कों को भी स्वीकार करता है:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// रूपांतरण करता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// एक मूल्य-से-मूल्य रूपांतरण जो इनपुट मूल्य का उपभोग करता है।[`From`] के विपरीत।
///
/// [`Into`] को लागू करने से बचना चाहिए और इसके बजाय [`From`] को लागू करना चाहिए।
/// [`From`] को लागू करना स्वचालित रूप से मानक पुस्तकालय में कंबल कार्यान्वयन के लिए [`Into`] के कार्यान्वयन के साथ एक प्रदान करता है।
///
/// एक सामान्य फ़ंक्शन पर trait bounds निर्दिष्ट करते समय [`From`] पर [`Into`] का उपयोग करना पसंद करें ताकि यह सुनिश्चित हो सके कि केवल [`Into`] को लागू करने वाले प्रकारों का भी उपयोग किया जा सकता है।
///
/// **Note: यह trait विफल नहीं होना चाहिए**।यदि रूपांतरण विफल हो सकता है, तो [`TryInto`] का उपयोग करें।
///
/// # सामान्य कार्यान्वयन
///
/// - [`से`]`<T>U` का अर्थ है `Into<U> for T`
/// - [`Into`] रिफ्लेक्सिव है, जिसका अर्थ है कि `Into<T> for T` लागू किया गया है
///
/// # Rust के पुराने संस्करणों में बाहरी प्रकारों में रूपांतरण के लिए [`Into`] को लागू करना
///
/// Rust 1.41 से पहले, यदि गंतव्य प्रकार वर्तमान crate का हिस्सा नहीं था तो आप सीधे [`From`] को लागू नहीं कर सकते थे।
/// उदाहरण के लिए, यह कोड लें:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// यह भाषा के पुराने संस्करणों में संकलित करने में विफल रहेगा क्योंकि Rust के अनाथ नियम थोड़े अधिक सख्त हुआ करते थे।
/// इसे बायपास करने के लिए, आप सीधे [`Into`] लागू कर सकते हैं:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// यह समझना महत्वपूर्ण है कि [`Into`] [`From`] कार्यान्वयन प्रदान नहीं करता है (जैसा कि [`From`] [`Into`] के साथ करता है)।
/// इसलिए, आपको हमेशा [`From`] को लागू करने का प्रयास करना चाहिए और फिर [`Into`] पर वापस आना चाहिए यदि [`From`] को लागू नहीं किया जा सकता है।
///
/// # Examples
///
/// [`String`] लागू करता है [`Into`]`<`[`Vec`]`<`[`u8`]`>>`:
///
/// यह व्यक्त करने के लिए कि हम सभी तर्कों को लेने के लिए एक सामान्य कार्य चाहते हैं जिन्हें एक निर्दिष्ट प्रकार `T` में परिवर्तित किया जा सकता है, हम [`Into`]`के trait bound का उपयोग कर सकते हैं<T>`.
///
/// उदाहरण के लिए: फ़ंक्शन `is_hello` उन सभी तर्कों को लेता है जिन्हें [`Vec`]`<`[`u8`]`>` में परिवर्तित किया जा सकता है।
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// रूपांतरण करता है।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// इनपुट मूल्य का उपभोग करते समय मूल्य-से-मूल्य रूपांतरण करने के लिए प्रयुक्त होता है।यह [`Into`] का व्युत्क्रम है।
///
/// किसी को हमेशा [`Into`] पर `From` को लागू करना पसंद करना चाहिए क्योंकि `From` को लागू करना स्वचालित रूप से मानक पुस्तकालय में कंबल कार्यान्वयन के लिए [`Into`] के कार्यान्वयन के साथ एक प्रदान करता है।
///
///
/// Rust 1.41 से पहले के संस्करण को लक्षित करते समय और वर्तमान crate के बाहर एक प्रकार में कनवर्ट करते समय केवल [`Into`] लागू करें।
/// `From` Rust के अनाथ नियमों के कारण पुराने संस्करणों में इस प्रकार के रूपांतरण करने में सक्षम नहीं था।
/// अधिक जानकारी के लिए [`Into`] देखें।
///
/// जेनेरिक फ़ंक्शन पर trait bounds निर्दिष्ट करते समय `From` का उपयोग करने पर [`Into`] का उपयोग करना पसंद करते हैं।
/// इस तरह, [`Into`] को सीधे लागू करने वाले प्रकारों को तर्क के रूप में भी इस्तेमाल किया जा सकता है।
///
/// त्रुटि प्रबंधन करते समय `From` भी बहुत उपयोगी है।विफल होने में सक्षम फ़ंक्शन का निर्माण करते समय, रिटर्न प्रकार आम तौर पर `Result<T, E>` के रूप में होगा।
/// `From` trait फ़ंक्शन को एकल त्रुटि प्रकार को वापस करने की अनुमति देकर त्रुटि प्रबंधन को सरल बनाता है जो कई त्रुटि प्रकारों को समाहित करता है।अधिक विवरण के लिए "Examples" अनुभाग और [the book][book] देखें।
///
/// **Note: यह trait विफल नहीं होना चाहिए**।यदि रूपांतरण विफल हो सकता है, तो [`TryFrom`] का उपयोग करें।
///
/// # सामान्य कार्यान्वयन
///
/// - `From<T> for U` का अर्थ है [`Into`]`<U>T`</u>. के <U>लिए</u>
/// - `From` रिफ्लेक्सिव है, जिसका अर्थ है कि `From<T> for T` लागू किया गया है
///
/// # Examples
///
/// [`String`] `From<&str>` लागू करता है:
///
/// `&str` से स्ट्रिंग में एक स्पष्ट रूपांतरण निम्नानुसार किया जाता है:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// त्रुटि प्रबंधन करते समय अक्सर अपने स्वयं के त्रुटि प्रकार के लिए `From` को लागू करना उपयोगी होता है।
/// अंतर्निहित त्रुटि प्रकारों को अपने स्वयं के कस्टम त्रुटि प्रकार में परिवर्तित करके जो अंतर्निहित त्रुटि प्रकार को समाहित करता है, हम अंतर्निहित कारण पर जानकारी खोए बिना एकल त्रुटि प्रकार वापस कर सकते हैं।
/// '?' ऑपरेटर स्वचालित रूप से अंतर्निहित त्रुटि प्रकार को `Into<CliError>::into` को कॉल करके हमारे कस्टम त्रुटि प्रकार में परिवर्तित करता है जो `From` को लागू करते समय स्वचालित रूप से प्रदान किया जाता है।
/// संकलक तब अनुमान लगाता है कि `Into` के किस कार्यान्वयन का उपयोग किया जाना चाहिए।
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// रूपांतरण करता है।
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// एक प्रयास किया गया रूपांतरण जो `self` की खपत करता है, जो महंगा हो भी सकता है और नहीं भी।
///
/// पुस्तकालय लेखकों को आमतौर पर इस trait को सीधे लागू नहीं करना चाहिए, लेकिन [`TryFrom`] trait को लागू करना पसंद करना चाहिए, जो अधिक लचीलापन प्रदान करता है और मानक पुस्तकालय में एक कंबल कार्यान्वयन के लिए एक समान `TryInto` कार्यान्वयन मुफ्त में प्रदान करता है।
/// इस बारे में अधिक जानकारी के लिए, [`Into`] के लिए दस्तावेज़ देखें।
///
/// # `TryInto` लागू करना
///
/// यह [`Into`] को लागू करने के समान प्रतिबंध और तर्क से ग्रस्त है, विवरण के लिए वहां देखें।
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// रूपांतरण त्रुटि की स्थिति में लौटाया गया प्रकार।
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// रूपांतरण करता है।
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// सरल और सुरक्षित प्रकार के रूपांतरण जो कुछ परिस्थितियों में नियंत्रित तरीके से विफल हो सकते हैं।यह [`TryInto`] का व्युत्क्रम है।
///
/// यह तब उपयोगी होता है जब आप एक प्रकार का रूपांतरण कर रहे होते हैं जो मामूली रूप से सफल हो सकता है लेकिन विशेष हैंडलिंग की भी आवश्यकता हो सकती है।
/// उदाहरण के लिए, [`From`] trait का उपयोग करके [`i64`] को [`i32`] में बदलने का कोई तरीका नहीं है, क्योंकि [`i64`] में एक ऐसा मान हो सकता है जिसे [`i32`] प्रदर्शित नहीं कर सकता है और इसलिए रूपांतरण डेटा खो देगा।
///
/// इसे [`i64`] को [`i32`] में छोटा करके (अनिवार्य रूप से [`i64`] का मान मॉड्यूलो [`i32::MAX`] देकर) या केवल [`i32::MAX`] को वापस करके, या किसी अन्य विधि द्वारा नियंत्रित किया जा सकता है।
/// [`From`] trait पूर्ण रूपांतरण के लिए अभिप्रेत है, इसलिए `TryFrom` trait प्रोग्रामर को सूचित करता है कि एक प्रकार का रूपांतरण कब खराब हो सकता है और उन्हें यह तय करने देता है कि इसे कैसे संभालना है।
///
/// # सामान्य कार्यान्वयन
///
/// - `TryFrom<T> for U` का अर्थ है [`TryInto`]`<U>T`</u>. के <U>लिए</u>
/// - [`try_from`] रिफ्लेक्सिव है, जिसका अर्थ है कि `TryFrom<T> for T` लागू किया गया है और विफल नहीं हो सकता है-`T::try_from()` प्रकार के मान पर `T::try_from()` को कॉल करने के लिए संबंधित `Error` प्रकार [`Infallible`] है।
/// जब [`!`] प्रकार स्थिर हो जाता है तो [`Infallible`] और [`!`] समतुल्य होंगे।
///
/// `TryFrom<T>` निम्नानुसार कार्यान्वित किया जा सकता है:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// जैसा कि बताया गया है, [`i32`] `TryFrom<`[`i64`]`>` लागू करता है:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // चुपचाप `big_number` को छोटा करता है, तथ्य के बाद छंटनी का पता लगाने और उसे संभालने की आवश्यकता है।
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // एक त्रुटि देता है क्योंकि `big_number` `i32` में फ़िट होने के लिए बहुत बड़ा है।
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` लौटाता है।
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// रूपांतरण त्रुटि की स्थिति में लौटाया गया प्रकार।
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// रूपांतरण करता है।
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// सामान्य निहितार्थ
////////////////////////////////////////////////////////////////////////////////

// जैसे ही ऊपर उठता है और
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut से अधिक लिफ्टों के रूप में
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): और/&mut के लिए उपरोक्त इम्प्लांट्स को निम्नलिखित अधिक सामान्य से बदलें:
// // डेरेफ के ऊपर लिफ्टों के रूप में
// अर्थ <D: ?Sized + Deref<Target: AsRef<U>>, यू:? आकार> <U>डी के लिए</u> AsRef <U>{fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut &mut से अधिक लिफ्ट करता है
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut के लिए उपरोक्त इम्प्लांट को निम्नलिखित अधिक सामान्य से बदलें:
// // AsMut ने DerefMut पर लिफ्ट की
// अर्थ <D: ?Sized + Deref<Target: AsMut<U>>, यू:? आकार> <U>डी के लिए</u> AsMut <U>{fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// से तात्पर्य है
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (और इस प्रकार Into) प्रतिवर्त है
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **स्थिरता नोट:** यह निहितार्थ अभी तक मौजूद नहीं है, लेकिन हम इसे future में जोड़ने के लिए "reserving space" हैं।
/// विवरण के लिए [rust-lang/rust#64715][#64715] देखें।
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): इसके बजाय एक सैद्धांतिक सुधार करें।
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom का अर्थ है TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// अचूक रूपांतरण शब्दार्थ रूप से एक निर्जन त्रुटि प्रकार के साथ गिरने योग्य रूपांतरणों के बराबर हैं।
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// कंक्रीट इम्प्लस
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// नो-एरर एरर टाइप
////////////////////////////////////////////////////////////////////////////////

/// त्रुटियों के लिए त्रुटि प्रकार जो कभी नहीं हो सकता।
///
/// चूंकि इस एनम का कोई रूप नहीं है, इसलिए इस प्रकार का मूल्य वास्तव में कभी भी मौजूद नहीं हो सकता है।
/// यह सामान्य एपीआई के लिए उपयोगी हो सकता है जो [`Result`] का उपयोग करते हैं और त्रुटि प्रकार को पैरामीटर करते हैं, यह इंगित करने के लिए कि परिणाम हमेशा [`Ok`] होता है।
///
/// उदाहरण के लिए, [`TryFrom`] trait (रूपांतरण जो [`Result`] लौटाता है) में सभी प्रकार के लिए एक कंबल कार्यान्वयन है जहां एक रिवर्स [`Into`] कार्यान्वयन मौजूद है।
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future संगतता
///
/// इस एनम की [the `!`“never”type][never] जैसी ही भूमिका है, जो Rust के इस संस्करण में अस्थिर है।
/// जब `!` को स्थिर किया जाता है, तो हम `Infallible` को इसके लिए एक प्रकार का उपनाम बनाने की योजना बनाते हैं:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... और अंत में `Infallible` को हटा दें।
///
/// हालांकि एक ऐसा मामला है जहां `!` को पूर्ण प्रकार के रूप में स्थिर करने से पहले `!` सिंटैक्स का उपयोग किया जा सकता है: फ़ंक्शन के रिटर्न प्रकार की स्थिति में।
/// विशेष रूप से, यह दो अलग-अलग फ़ंक्शन पॉइंटर प्रकारों के लिए संभव कार्यान्वयन है:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` एक एनम होने के साथ, यह कोड मान्य है।
/// हालाँकि जब `Infallible` never type के लिए एक उपनाम बन जाता है, तो दो `impl`s ओवरलैप होना शुरू हो जाएंगे और इसलिए भाषा के trait सुसंगतता नियमों द्वारा अस्वीकृत हो जाएंगे।
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}