//! Panic libcore के लिए समर्थन
//!
//! कोर लाइब्रेरी पैनिकिंग को परिभाषित नहीं कर सकती है, लेकिन यह पैनिकिंग को *घोषित* करती है।
//! इसका मतलब यह है कि libcore के अंदर के कार्यों को panic की अनुमति है, लेकिन उपयोगी होने के लिए एक अपस्ट्रीम crate को libcore के उपयोग के लिए पैनिकिंग को परिभाषित करना चाहिए।
//! घबराहट के लिए वर्तमान इंटरफ़ेस है:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! यह परिभाषा किसी भी सामान्य संदेश से घबराने की अनुमति देती है, लेकिन यह `Box<Any>` मान के साथ विफल होने की अनुमति नहीं देती है।
//! (`PanicInfo` में केवल एक `&(dyn Any + Send)` है, जिसके लिए हम `PanicInfo: :internal_constructor` में एक डमी मान भरते हैं।) इसका कारण यह है कि libcore को आवंटित करने की अनुमति नहीं है।
//!
//!
//! इस मॉड्यूल में कुछ अन्य पैनिकिंग फ़ंक्शन शामिल हैं, लेकिन ये कंपाइलर के लिए केवल आवश्यक लैंग आइटम हैं।सभी panics इस एक फ़ंक्शन के माध्यम से फ़नल किए गए हैं।
//! वास्तविक प्रतीक `#[panic_handler]` विशेषता के माध्यम से घोषित किया गया है।
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// जब कोई स्वरूपण उपयोग नहीं किया जाता है तो libcore के `panic!` मैक्रो का अंतर्निहित कार्यान्वयन।
#[cold]
// कभी भी इनलाइन न करें जब तक कि जितना संभव हो सके कॉल साइटों पर कोड ब्लोट से बचने के लिए पैनिक_इमीडिएट_एबॉर्ट न करें
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // अतिप्रवाह और अन्य `Assert` एमआईआर टर्मिनेटर पर panic के लिए कोडजन द्वारा आवश्यक needed
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ओवरहेड आकार को संभावित रूप से कम करने के लिए format_args!("{}", expr) के बजाय Arguments::new_v1 का उपयोग करें।
    // format_args!मैक्रो एक्सप्र लिखने के लिए स्ट्र के डिस्प्ले trait का उपयोग करता है, जो Formatter::pad को कॉल करता है, जिसे स्ट्रिंग ट्रंकेशन और पैडिंग को समायोजित करना चाहिए (भले ही यहां कोई भी उपयोग नहीं किया गया हो)।
    //
    // Arguments::new_v1 का उपयोग करने से कंपाइलर कुछ किलोबाइट तक की बचत करते हुए आउटपुट बाइनरी से Formatter::pad को छोड़ सकता है।
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // कॉन्स्ट-मूल्यांकन के लिए आवश्यक panics needed
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice एक्सेस पर panic के लिए कोडजन द्वारा आवश्यक
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// फ़ॉर्मेटिंग का उपयोग करते समय libcore के `panic!` मैक्रो का अंतर्निहित कार्यान्वयन।
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // नोट यह फ़ंक्शन कभी भी FFI सीमा को पार नहीं करता है;यह एक Rust-to-Rust कॉल है जो `#[panic_handler]` फ़ंक्शन के साथ हल हो जाती है।
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // सुरक्षा: `panic_impl` को सुरक्षित Rust कोड में परिभाषित किया गया है और इस प्रकार कॉल करना सुरक्षित है।
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` और `assert_ne!` मैक्रोज़ के लिए आंतरिक कार्य
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}