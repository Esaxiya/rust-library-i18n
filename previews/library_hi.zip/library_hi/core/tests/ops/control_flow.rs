use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // यह स्थिर सतह क्षेत्र नहीं है, लेकिन उनके बीच `?` को सस्ता रखने में मदद करता है, भले ही LLVM हमेशा इसका लाभ अभी न उठा सके।
    //
    // (दुख की बात है कि परिणाम और विकल्प असंगत हैं, इसलिए कंट्रोलफ्लो दोनों से मेल नहीं खा सकता है।)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}