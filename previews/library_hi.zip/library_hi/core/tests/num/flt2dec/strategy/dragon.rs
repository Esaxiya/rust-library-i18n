use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // मिरी बहुत धीमी है
fn exact_sanity_test() {
    // यह परीक्षण समाप्त होता है जो मैं केवल मान सकता हूं कि `exp2` लाइब्रेरी फ़ंक्शन का कुछ कोने-आश केस है, जिसे हम जो भी सी रनटाइम उपयोग कर रहे हैं उसमें परिभाषित किया गया है।
    // वीएस 2013 में इस फ़ंक्शन में स्पष्ट रूप से एक बग था क्योंकि लिंक होने पर यह परीक्षण विफल हो जाता है, लेकिन वीएस 2015 के साथ बग ठीक दिखाई देता है क्योंकि परीक्षण ठीक चलता है।
    //
    // बग `exp2(-1057)` के रिटर्न वैल्यू में अंतर प्रतीत होता है, जहां वीएस 2013 में यह बिट पैटर्न 0x2 के साथ डबल देता है और वीएस 2015 में यह 0x20000 देता है।
    //
    //
    // अभी के लिए इस परीक्षण को पूरी तरह से MSVC पर नज़रअंदाज़ कर दें क्योंकि इसका परीक्षण कहीं और किया गया है और हम प्रत्येक प्लेटफ़ॉर्म के exp2 कार्यान्वयन का परीक्षण करने में अत्यधिक रुचि नहीं रखते हैं।
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}