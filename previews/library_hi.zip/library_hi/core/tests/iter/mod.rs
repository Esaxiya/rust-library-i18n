//! Note
//! ----
//! आप शायद इस फ़ाइल को देख रहे हैं क्योंकि आप एक परीक्षण जोड़ रहे हैं (या आप बस ब्राउज़ कर रहे हैं, उस स्थिति में, अरे वहाँ!)
//!
//! iter परीक्षण सूट दो बड़े मॉड्यूल और कुछ विविध छोटे मॉड्यूल में विभाजित है।दो बड़े मॉड्यूल `adapters` और `traits` हैं।
//!
//! `adapters` `Iterator` पर विधियों के लिए हैं जो इटरेटर के अंदर डेटा को अनुकूलित करते हैं, चाहे वह किसी अन्य इटरेटर को उत्सर्जित करके या प्रत्येक आइटम पर बंद करने के बाद इटरेटर के अंदर से किसी आइटम को वापस कर दे।
//!
//!
//! `traits` trait के लिए हैं जो एक `Iterator` (और स्वयं `Iterator` trait, जिसमें ज्यादातर विविध तरीके शामिल हैं) का विस्तार करते हैं।
//! अधिकांश भाग के लिए, यदि `traits` में एक परीक्षण एक विशिष्ट एडेप्टर का उपयोग करता है, तो उसे `adapters` में उस एडेप्टर की परीक्षण फ़ाइल में ले जाया जाना चाहिए।
//!
//!
//!
//!
//!

mod adapters;
mod range;
mod sources;
mod traits;

use core::cell::Cell;
use core::convert::TryFrom;
use core::iter::*;

pub fn is_trusted_len<I: TrustedLen>(_: I) {}

#[test]
fn test_multi_iter() {
    let xs = [1, 2, 3, 4];
    let ys = [4, 3, 2, 1];
    assert!(xs.iter().eq(ys.iter().rev()));
    assert!(xs.iter().lt(xs.iter().skip(2)));
}

#[test]
fn test_counter_from_iter() {
    let it = (0..).step_by(5).take(10);
    let xs: Vec<isize> = FromIterator::from_iter(it);
    assert_eq!(xs, [0, 5, 10, 15, 20, 25, 30, 35, 40, 45]);
}

#[test]
fn test_functor_laws() {
    // identity:
    fn identity<T>(x: T) -> T {
        x
    }
    assert_eq!((0..10).map(identity).sum::<usize>(), (0..10).sum());

    // composition:
    fn f(x: usize) -> usize {
        x + 3
    }
    fn g(x: usize) -> usize {
        x * 2
    }
    fn h(x: usize) -> usize {
        g(f(x))
    }
    assert_eq!((0..10).map(f).map(g).sum::<usize>(), (0..10).map(h).sum());
}

#[test]
fn test_monad_laws_left_identity() {
    fn f(x: usize) -> impl Iterator<Item = usize> {
        (0..10).map(move |y| x * y)
    }
    assert_eq!(once(42).flat_map(f.clone()).sum::<usize>(), f(42).sum());
}

#[test]
fn test_monad_laws_right_identity() {
    assert_eq!((0..10).flat_map(|x| once(x)).sum::<usize>(), (0..10).sum());
}

#[test]
fn test_monad_laws_associativity() {
    fn f(x: usize) -> impl Iterator<Item = usize> {
        0..x
    }
    fn g(x: usize) -> impl Iterator<Item = usize> {
        (0..x).rev()
    }
    assert_eq!(
        (0..10).flat_map(f).flat_map(g).sum::<usize>(),
        (0..10).flat_map(|x| f(x).flat_map(g)).sum::<usize>()
    );
}

#[test]
pub fn extend_for_unit() {
    let mut x = 0;
    {
        let iter = (0..5).map(|_| {
            x += 1;
        });
        ().extend(iter);
    }
    assert_eq!(x, 5);
}