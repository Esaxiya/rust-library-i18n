// rsbegin.o और rsend.o तथाकथित "compiler runtime startup objects" हैं।
// उनमें कंपाइलर रनटाइम को सही ढंग से प्रारंभ करने के लिए आवश्यक कोड होता है।
//
// जब एक निष्पादन योग्य या डाइलिब छवि जुड़ी होती है, तो इन दो ऑब्जेक्ट फ़ाइलों के बीच सभी उपयोगकर्ता कोड और पुस्तकालय "sandwiched" होते हैं, इसलिए rsbegin.o से कोड या डेटा छवि के संबंधित अनुभागों में पहले बन जाते हैं, जबकि rsend.o से कोड और डेटा अंतिम बन जाते हैं।
// इस आशय का उपयोग किसी अनुभाग की शुरुआत या अंत में प्रतीकों को रखने के साथ-साथ किसी भी आवश्यक शीर्षलेख या पाद लेख को सम्मिलित करने के लिए किया जा सकता है।
//
// ध्यान दें कि वास्तविक मॉड्यूल प्रविष्टि बिंदु C रनटाइम स्टार्टअप ऑब्जेक्ट (आमतौर पर `crtX.o` कहा जाता है) में स्थित है, जो तब अन्य रनटाइम घटकों (अभी तक एक और विशेष छवि अनुभाग के माध्यम से पंजीकृत) के इनिशियलाइज़ेशन कॉलबैक को आमंत्रित करता है।
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // स्टैक फ्रेम की शुरुआत के निशान सूचना अनुभाग को खोलते हैं
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // अनविंडर के आंतरिक बुक-कीपिंग के लिए स्क्रैच स्पेस।
    // इसे $GCC/unwind-dw2-fde.h में `struct object` के रूप में परिभाषित किया गया है।
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // जानकारी registration/deregistration रूटीन खोलें।
    // libpanic_unwind के दस्तावेज़ देखें।
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // मॉड्यूल स्टार्टअप पर जानकारी खोलना रजिस्टर करें
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // शटडाउन पर अपंजीकृत
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-विशिष्ट init/uninit नियमित पंजीकरण
    pub mod mingw_init {
        // MinGW के स्टार्टअप ऑब्जेक्ट (crt0.o/dllcrt0.o) स्टार्टअप और एग्जिट पर .ctors और .dtors सेक्शन में ग्लोबल कंस्ट्रक्टर्स को इनवाइट करेंगे।
        // डीएलएल के मामले में, यह तब किया जाता है जब डीएलएल लोड और अनलोड किया जाता है।
        //
        // लिंकर अनुभागों को क्रमबद्ध करेगा, जो सुनिश्चित करता है कि हमारे कॉलबैक सूची के अंत में स्थित हैं।
        // चूंकि कंस्ट्रक्टर रिवर्स ऑर्डर में चलाए जाते हैं, यह सुनिश्चित करता है कि हमारे कॉलबैक पहले और आखिरी निष्पादित हैं।
        //
        //

        #[link_section = ".ctors.65535"] // .ctors.*: C आरंभीकरण कॉलबैक
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors.*: C टर्मिनेशन कॉलबैक
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}