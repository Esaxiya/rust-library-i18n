//! `compiler-rt` लाइब्रेरी के प्रोफाइलर भाग को संकलित करता है।
//!
//! विवरण के लिए libcompiler_builtins crate के लिए build.rs देखें।

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: `rerun-if-changed` निर्देश वर्तमान में उत्सर्जित नहीं हैं और निर्माण स्क्रिप्ट
    // इन स्रोत फ़ाइलों या उनमें शामिल शीर्षलेखों में परिवर्तनों पर पुन: नहीं चलाएगा।
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // इस फ़ाइल का नाम बदलकर LLVM 10 कर दिया गया।
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // ये फ़ाइलें LLVM 11 में जोड़ी गईं।
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // MSVC पर अतिरिक्त पुस्तकालयों को न खींचे
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // gcc की विभिन्न विशेषताओं को बंद करें और इस तरह, ज्यादातर पहले से ही कंपाइलर-आरटी के बिल्ड सिस्टम की नकल कर रहे हैं
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // मान लें कि जिन यूनिक्स के लिए हम इसका निर्माण कर रहे हैं उनके पास fnctl() उपलब्ध है
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // COMPILER_RT_HAS_ATOMICS. को कब सेट करना है, इसके लिए यह एक बहुत अच्छा अनुमानी होना चाहिए
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // ध्यान दें कि यदि हम दौड़ने जा रहे हैं तो यह अस्तित्व में होना चाहिए (अन्यथा हम प्रोफाइलर बिल्टिन बिल्कुल नहीं बनाते हैं)।
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}