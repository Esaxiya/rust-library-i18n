# `rustc-std-workspace-core` crate

यह crate एक छोटा और खाली crate है जो केवल `libcore` पर निर्भर करता है और इसकी सभी सामग्री को पुनः निर्यात करता है।
crate मानक पुस्तकालय को crates.io से crates पर निर्भर रहने के लिए सशक्त बनाने का मूलमंत्र है

crates.io पर Crates कि मानक पुस्तकालय crates.io से `rustc-std-workspace-core` crate पर निर्भर होने की आवश्यकता पर निर्भर करता है, जो खाली है।

हम इस रिपॉजिटरी में इस crat को ओवरराइड करने के लिए `[patch]` का उपयोग करते हैं।
नतीजतन, crates.io पर crates एक निर्भरता edge से `libcore`, इस रिपॉजिटरी में परिभाषित संस्करण को आकर्षित करेगा।
Cargo crates को सफलतापूर्वक बनाता है यह सुनिश्चित करने के लिए सभी निर्भरता किनारों को आकर्षित करना चाहिए!

ध्यान दें कि crates.io पर crates को सब कुछ सही ढंग से काम करने के लिए `core` नाम के साथ इस crate पर निर्भर रहने की आवश्यकता है।ऐसा करने के लिए वे उपयोग कर सकते हैं:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` कुंजी के उपयोग के माध्यम से crate का नाम बदलकर `core` कर दिया गया है, जिसका अर्थ है कि यह ऐसा दिखेगा

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

जब Cargo संकलक को आमंत्रित करता है, संकलक द्वारा अंतःक्षेपित `extern crate core` निर्देश को संतुष्ट करता है।




