//! DWARF-एन्कोडेड डेटा स्ट्रीम को पार्स करने के लिए उपयोगिताएँ।
//! देखें <http://www.dwarfstd.org>, DWARF-4 मानक, खंड 7, "Data Representation"
//!

// यह मॉड्यूल अभी के लिए केवल x86_64-pc-windows-gnu द्वारा उपयोग किया जाता है, लेकिन हम प्रतिगमन से बचने के लिए इसे हर जगह संकलित कर रहे हैं।
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF धाराएं पैक की जाती हैं, उदाहरण के लिए, एक u32 जरूरी नहीं कि 4-बाइट सीमा पर संरेखित हो।
    // यह सख्त संरेखण आवश्यकताओं वाले प्लेटफ़ॉर्म पर समस्याएँ पैदा कर सकता है।
    // "packed" संरचना में डेटा लपेटकर, हम बैकएंड को "misalignment-safe" कोड जनरेट करने के लिए कह रहे हैं।
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 और SLEB128 एन्कोडिंग को खंड 7.6, "Variable Length Data" में परिभाषित किया गया है।
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}