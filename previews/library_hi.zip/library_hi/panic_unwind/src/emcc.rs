//! *एमस्क्रिप्टेन* लक्ष्य के लिए अनवाइंडिंग।
//!
//! जबकि Unix प्लेटफॉर्म के लिए Rust का सामान्य अनइंडिंग कार्यान्वयन सीधे लिबुनविंड एपीआई में कॉल करता है, एम्स्क्रिप्टन पर हम इसके बजाय सी ++ अनइंडिंग एपीआई में कॉल करते हैं।
//! यह सिर्फ एक समीचीनता है क्योंकि एम्सस्क्रिप्टन का रनटाइम हमेशा उन एपीआई को लागू करता है और लिबुनविंड को लागू नहीं करता है।
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// यह C++ में std::type_info के लेआउट से मेल खाता है
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // यहां अग्रणी `\x01` बाइट वास्तव में LLVM के लिए एक जादुई संकेत है कि `_` कैरेक्टर के साथ प्रीफिक्सिंग जैसे किसी अन्य मैंगलिंग को *नहीं* लागू करें।
    //
    //
    // यह प्रतीक C++ के `std::type_info` द्वारा उपयोग किया जाने वाला vtable है।
    // `std::type_info` प्रकार के ऑब्जेक्ट, प्रकार के डिस्क्रिप्टर, इस तालिका में एक सूचक होते हैं।
    // टाइप डिस्क्रिप्टर को ऊपर परिभाषित सी ++ ईएच संरचनाओं द्वारा संदर्भित किया जाता है और जिसे हम नीचे बनाते हैं।
    //
    // ध्यान दें कि वास्तविक आकार 3 उपयोग से बड़ा है, लेकिन हमें केवल तीसरे तत्व को इंगित करने के लिए हमारे vtable की आवश्यकता है।
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info एक rust_panic वर्ग के लिए
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // आम तौर पर हम .as_ptr().add(2) का उपयोग करेंगे लेकिन यह एक कॉन्स संदर्भ में काम नहीं करता है।
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // यह जानबूझकर सामान्य नाम मैंगलिंग योजना का उपयोग नहीं करता है क्योंकि हम नहीं चाहते कि C++ Rust panics का उत्पादन या पकड़ने में सक्षम हो।
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // यह आवश्यक है क्योंकि C++ कोड std::exception_ptr के साथ हमारे निष्पादन को कैप्चर कर सकता है और इसे कई बार फिर से फेंक सकता है, संभवतः किसी अन्य थ्रेड में भी।
    //
    //
    caught: AtomicBool,

    // इसे एक विकल्प होने की आवश्यकता है क्योंकि ऑब्जेक्ट का जीवनकाल C++ सेमेन्टिक्स का अनुसरण करता है: जब catch_unwind बॉक्स को अपवाद से बाहर ले जाता है तो उसे अभी भी अपवाद ऑब्जेक्ट को वैध स्थिति में छोड़ना होगा क्योंकि इसके विनाशक को अभी भी __cxa_end_catch द्वारा बुलाया जा रहा है।
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try वास्तव में हमें इस संरचना के लिए एक सूचक देता है।
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // चूंकि cleanup() को panic की अनुमति नहीं है, इसलिए हम इसके बजाय बस निरस्त कर देते हैं।
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}