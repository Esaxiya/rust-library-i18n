//! libgcc/libunwind द्वारा समर्थित panics का कार्यान्वयन (किसी न किसी रूप में)।
//!
//! अपवाद हैंडलिंग और स्टैक अनइंडिंग की पृष्ठभूमि के लिए कृपया "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) और इससे जुड़े दस्तावेज़ देखें।
//! ये भी अच्छे पढ़ने वाले हैं:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## एक संक्षिप्त सारांश
//!
//! एक्सेप्शन हैंडलिंग दो चरणों में होती है: एक खोज चरण और एक सफाई चरण।
//!
//! दोनों चरणों में अनविंडर वर्तमान प्रक्रिया के मॉड्यूल के स्टैक फ्रेम से जानकारी का उपयोग करके ऊपर से नीचे तक स्टैक फ्रेम चलाता है (यहां "module" एक ओएस मॉड्यूल, यानी एक निष्पादन योग्य या गतिशील पुस्तकालय को संदर्भित करता है)।
//!
//!
//! प्रत्येक स्टैक फ्रेम के लिए, यह संबंधित "personality routine" को आमंत्रित करता है, जिसका पता भी खोलना जानकारी अनुभाग में संग्रहीत किया जाता है।
//!
//! खोज चरण में, एक व्यक्तित्व दिनचर्या का काम फेंकी जा रही अपवाद वस्तु की जांच करना और यह तय करना है कि उसे उस स्टैक फ्रेम में पकड़ा जाना चाहिए या नहीं।एक बार हैंडलर फ्रेम की पहचान हो जाने के बाद, सफाई चरण शुरू होता है।
//!
//! सफाई के चरण में, अनविंडर प्रत्येक व्यक्तित्व दिनचर्या को फिर से आमंत्रित करता है।
//! इस बार यह तय करता है कि वर्तमान स्टैक फ्रेम के लिए कौन सा (यदि कोई हो) क्लीनअप कोड चलाने की आवश्यकता है।यदि ऐसा है, तो नियंत्रण को फ़ंक्शन बॉडी में एक विशेष branch, "landing pad" में स्थानांतरित कर दिया जाता है, जो विनाशकों को आमंत्रित करता है, स्मृति को मुक्त करता है, आदि।
//! लैंडिंग पैड के अंत में, नियंत्रण को वापस अनविंडर और अनइंडिंग रिज्यूमे में स्थानांतरित कर दिया जाता है।
//!
//! एक बार स्टैक को हैंडलर फ्रेम स्तर पर खोल दिया गया है, खोलना बंद हो जाता है और अंतिम व्यक्तित्व रूटीन नियंत्रण को पकड़ ब्लॉक में स्थानांतरित कर देता है।
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust का अपवाद वर्ग पहचानकर्ता।
// इसका उपयोग व्यक्तित्व दिनचर्या द्वारा यह निर्धारित करने के लिए किया जाता है कि क्या अपवाद उनके स्वयं के रनटाइम द्वारा फेंका गया था।
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-- विक्रेता, भाषा
    0x4d4f5a_00_52555354
}

// प्रत्येक आर्किटेक्चर के लिए LLVM के TargetLowering::getExceptionPointerRegister() और TargetLowering::getExceptionSelectorRegister() से रजिस्टर आईडी उठा लिए गए, फिर रजिस्टर डेफिनिशन टेबल (आमतौर पर) के माध्यम से DWARF रजिस्टर नंबर पर मैप किया गया।<arch>RegisterInfo.td, "DwarfRegNum" खोजें)।
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register भी देखें।
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // ईएक्स, ईडीएक्स

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // आरएएक्स, आरडीएक्स

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// निम्नलिखित कोड GCC के C और C++ व्यक्तित्व दिनचर्या पर आधारित है।संदर्भ के लिए देखें:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI व्यक्तित्व दिनचर्या।
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS इसके बजाय डिफ़ॉल्ट रूटीन का उपयोग करता है क्योंकि यह SjLj अनइंडिंग का उपयोग करता है।
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // एआरएम पर बैकट्रेस राज्य के साथ व्यक्तित्व दिनचर्या को बुलाएगा==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // उन मामलों में हम स्टैक को खोलना जारी रखना चाहते हैं, अन्यथा हमारे सभी बैकट्रेस __rust_try. पर समाप्त हो जाएंगे
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF अनविंडर मानता है कि _Unwind_Context में फ़ंक्शन और LSDA पॉइंटर्स जैसी चीज़ें होती हैं, हालाँकि ARM EHABI उन्हें अपवाद ऑब्जेक्ट में रखता है।
            // _Unwind_GetLanguageSpecificData() जैसे कार्यों के हस्ताक्षर को संरक्षित करने के लिए, जो केवल संदर्भ सूचक लेते हैं, GCC व्यक्तित्व रूटीन एआरएम के "scratch register" (r12) के लिए आरक्षित स्थान का उपयोग करके संदर्भ में अपवाद_ऑब्जेक्ट के लिए एक सूचक को छिपाते हैं।
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ...एक अधिक सैद्धांतिक दृष्टिकोण हमारे लिबुनविंड बाइंडिंग में एआरएम के _Unwind_Context की पूर्ण परिभाषा प्रदान करना और डीडब्ल्यूएआरएफ संगतता कार्यों को दरकिनार करते हुए सीधे वहां से आवश्यक डेटा प्राप्त करना होगा।
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI को अपवाद वस्तु के बैरियर कैश में SP मान को अद्यतन करने के लिए व्यक्तित्व दिनचर्या की आवश्यकता होती है।
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // ARM EHABI पर व्यक्तित्व दिनचर्या वास्तव में लौटने से पहले एक स्टैक फ्रेम को खोलने के लिए जिम्मेदार है (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc. में परिभाषित
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // डिफ़ॉल्ट व्यक्तित्व दिनचर्या, जिसका उपयोग प्रत्यक्ष रूप से अधिकांश लक्ष्यों पर और अप्रत्यक्ष रूप से SEH के माध्यम से Windows x86_64 पर किया जाता है।
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 MinGW लक्ष्यों पर, अनइंडिंग मैकेनिज्म SEH है, हालांकि अनइंड हैंडलर डेटा (उर्फ LSDA) GCC-संगत एन्कोडिंग का उपयोग करता है।
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // हमारे अधिकांश लक्ष्यों के लिए व्यक्तित्व दिनचर्या।
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // वापसी पता कॉल निर्देश से 1 बाइट आगे इंगित करता है, जो एलएसडीए श्रेणी तालिका में अगली आईपी श्रेणी में हो सकता है।
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// फ़्रेम खोलना जानकारी पंजीकरण
//
// प्रत्येक मॉड्यूल की छवि में एक फ्रेम खोलना जानकारी अनुभाग (आमतौर पर ".eh_frame") होता है।जब एक मॉड्यूल loaded/unloaded प्रक्रिया में होता है, तो अनविंडर को स्मृति में इस खंड के स्थान के बारे में सूचित किया जाना चाहिए।इसे प्राप्त करने के तरीके मंच द्वारा भिन्न होते हैं।
// कुछ (उदाहरण के लिए, Linux) पर, अनविंडर अपने आप ही अनइंड इंफॉर्मेशन सेक्शन की खोज कर सकता है (dl_iterate_phdr() API and finding their ".eh_frame" sections) के माध्यम से वर्तमान में लोड किए गए मॉड्यूल की गतिशील रूप से गणना करके; अन्य, जैसे Windows, को अनइंडर एपीआई के माध्यम से अपने अनइंड इंफॉर्मेशन सेक्शन को सक्रिय रूप से पंजीकृत करने के लिए मॉड्यूल की आवश्यकता होती है।
//
//
// यह मॉड्यूल दो प्रतीकों को परिभाषित करता है जिन्हें संदर्भित किया जाता है और GCC रनटाइम के साथ हमारी जानकारी को पंजीकृत करने के लिए rsbegin.rs से बुलाया जाता है।
// स्टैक अनइंडिंग का कार्यान्वयन (अभी के लिए) libgcc_eh के लिए स्थगित है, हालांकि Rust crates किसी भी GCC रनटाइम के साथ संभावित टकराव से बचने के लिए इन Rust-विशिष्ट प्रवेश बिंदुओं का उपयोग करते हैं।
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}