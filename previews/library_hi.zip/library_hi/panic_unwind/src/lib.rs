//! स्टैक अनइंडिंग के माध्यम से panics का कार्यान्वयन
//!
//! यह crate, Rust में panics का एक कार्यान्वयन है, जिस प्लेटफॉर्म के लिए इसे संकलित किया जा रहा है, "most native" स्टैक अनइंडिंग मैकेनिज्म का उपयोग कर रहा है।
//! यह अनिवार्य रूप से वर्तमान में तीन बाल्टियों में वर्गीकृत किया गया है:
//!
//! 1. MSVC लक्ष्य `seh.rs` फ़ाइल में SEH का उपयोग करते हैं।
//! 2. Emscripten `emcc.rs` फ़ाइल में C++ अपवादों का उपयोग करता है।
//! 3. अन्य सभी लक्ष्य `gcc.rs` फ़ाइल में libunwind/libgcc का उपयोग करते हैं।
//!
//! प्रत्येक कार्यान्वयन के बारे में अधिक दस्तावेज संबंधित मॉड्यूल में पाए जा सकते हैं।
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` मिरी के साथ अप्रयुक्त है, इसलिए मौन चेतावनियां।
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust रनटाइम के स्टार्टअप ऑब्जेक्ट इन प्रतीकों पर निर्भर करते हैं, इसलिए उन्हें सार्वजनिक करें।
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // लक्ष्य जो अनइंडिंग का समर्थन नहीं करते हैं।
        // - arch=wasm32
        // - ओएस=कोई नहीं ("bare metal" लक्ष्य)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // मिरी रनटाइम का उपयोग करें।
        // हमें अभी भी ऊपर के सामान्य रनटाइम को भी लोड करने की आवश्यकता है, क्योंकि rustc को वहां से कुछ लैंग आइटमों को परिभाषित करने की अपेक्षा है।
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // वास्तविक रनटाइम का उपयोग करें।
        use real_imp as imp;
    }
}

extern "C" {
    /// जब कोई panic ऑब्जेक्ट `catch_unwind` के बाहर गिराया जाता है, तो libstd में हैंडलर को कॉल किया जाता है।
    ///
    fn __rust_drop_panic() -> !;

    /// जब कोई विदेशी अपवाद पकड़ा जाता है तो libstd में हैंडलर को कॉल किया जाता है।
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// एक अपवाद उठाने के लिए प्रवेश बिंदु, केवल मंच-विशिष्ट कार्यान्वयन के लिए प्रतिनिधि।
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}