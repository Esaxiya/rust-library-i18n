//! मिरी के लिए panics खोलना।
use alloc::boxed::Box;
use core::any::Any;

// पेलोड का प्रकार जो मिरी इंजन हमारे लिए अनइंडिंग के माध्यम से प्रचारित करता है।
// सूचक के आकार का होना चाहिए।
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// मिरी द्वारा प्रदान किया गया बाहरी कार्य खोलना शुरू करने के लिए।
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // हम `miri_start_panic` को जो पेलोड पास करते हैं, वह ठीक वही तर्क होगा जो हमें नीचे `cleanup` में मिलता है।
    // तो हम कुछ पॉइंटर-आकार प्राप्त करने के लिए इसे केवल एक बार बॉक्स अप करते हैं।
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // अंतर्निहित `Box` पुनर्प्राप्त करें।
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}