//! Windows SEH
//!
//! Windows (वर्तमान में केवल MSVC पर) पर, डिफ़ॉल्ट अपवाद हैंडलिंग तंत्र संरचित अपवाद हैंडलिंग (SEH) है।
//! यह कंपाइलर इंटर्नल के मामले में ड्वार्फ-आधारित अपवाद हैंडलिंग (उदाहरण के लिए, अन्य unix प्लेटफॉर्म का उपयोग करने वाले) से काफी अलग है, इसलिए एलएलवीएम को एसईएच के लिए अतिरिक्त समर्थन की आवश्यकता है।
//!
//! संक्षेप में, यहाँ क्या होता है:
//!
//! 1. `panic` फ़ंक्शन मानक Windows फ़ंक्शन `_CxxThrowException` को C++ जैसे अपवाद को फेंकने के लिए कॉल करता है, जो अनइंडिंग प्रक्रिया को ट्रिगर करता है।
//! 2.
//! कंपाइलर द्वारा उत्पन्न सभी लैंडिंग पैड व्यक्तित्व फ़ंक्शन `__CxxFrameHandler3`, CRT में एक फ़ंक्शन का उपयोग करते हैं, और Windows में अनइंडिंग कोड इस व्यक्तित्व फ़ंक्शन का उपयोग स्टैक पर सभी क्लीनअप कोड को निष्पादित करने के लिए करेगा।
//!
//! 3. `invoke` के लिए सभी कंपाइलर-जनरेटेड कॉल में एक लैंडिंग पैड सेट होता है जो `cleanuppad` LLVM निर्देश के रूप में सेट होता है, जो कि क्लीनअप रूटीन की शुरुआत को इंगित करता है।
//! सफाई दिनचर्या चलाने के लिए व्यक्तित्व (चरण 2 में, सीआरटी में परिभाषित) जिम्मेदार है।
//! 4. अंततः `try` आंतरिक (कंपाइलर द्वारा उत्पन्न) में "catch" कोड निष्पादित किया जाता है और इंगित करता है कि नियंत्रण Rust पर वापस आना चाहिए।
//! यह LLVM IR शर्तों में `catchswitch` प्लस `catchpad` निर्देश के माध्यम से किया जाता है, अंत में `catchret` निर्देश के साथ प्रोग्राम पर सामान्य नियंत्रण लौटाता है।
//!
//! gcc-आधारित अपवाद हैंडलिंग से कुछ विशिष्ट अंतर हैं:
//!
//! * Rust का कोई कस्टम व्यक्तित्व फ़ंक्शन नहीं है, यह इसके बजाय *हमेशा*`__CxxFrameHandler3` है।इसके अतिरिक्त, कोई अतिरिक्त फ़िल्टरिंग नहीं की जाती है, इसलिए हम किसी भी सी ++ अपवादों को पकड़ लेते हैं जो कि हम जिस तरह से फेंक रहे हैं उसकी तरह दिखते हैं।
//! ध्यान दें कि Rust में अपवाद फेंकना वैसे भी अपरिभाषित व्यवहार है, इसलिए यह ठीक होना चाहिए।
//! * हमारे पास अनडिंडिंग बाउंड्री के पार संचारित करने के लिए कुछ डेटा है, विशेष रूप से एक `Box<dyn Any + Send>`।बौने अपवादों की तरह, इन दो बिंदुओं को अपवाद में ही पेलोड के रूप में संग्रहीत किया जाता है।
//! एमएसवीसी पर, हालांकि, अतिरिक्त ढेर आवंटन की कोई आवश्यकता नहीं है क्योंकि कॉल स्टैक संरक्षित है जबकि फ़िल्टर फ़ंक्शन निष्पादित किए जा रहे हैं।
//! इसका मतलब यह है कि पॉइंटर्स को सीधे `_CxxThrowException` में पास किया जाता है, जिसे बाद में `try` इंट्रिंसिक के स्टैक फ्रेम में लिखे जाने के लिए फिल्टर फंक्शन में रिकवर किया जाता है।
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // यह एक विकल्प होना चाहिए क्योंकि हम संदर्भ द्वारा अपवाद को पकड़ते हैं और इसके विनाशक को सी ++ रनटाइम द्वारा निष्पादित किया जाता है।
    // जब हम बॉक्स को अपवाद से बाहर निकालते हैं, तो हमें इसके विनाशक के लिए बॉक्स को डबल-ड्रॉप किए बिना चलाने के लिए एक वैध स्थिति में अपवाद छोड़ना होगा।
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// सबसे पहले, प्रकार की परिभाषाओं का एक पूरा समूह।यहाँ कुछ प्लेटफ़ॉर्म-विशिष्ट विषमताएँ हैं, और बहुत कुछ जो LLVM से स्पष्ट रूप से कॉपी किया गया है।इन सबका उद्देश्य नीचे दिए गए `panic` फ़ंक्शन को `_CxxThrowException` पर कॉल के माध्यम से कार्यान्वित करना है।
//
// यह फ़ंक्शन दो तर्क लेता है।पहला उस डेटा का सूचक है जिसे हम पास कर रहे हैं, जो इस मामले में हमारा trait ऑब्जेक्ट है।खोजने में काफी आसान!हालांकि, अगला अधिक जटिल है।
// यह एक `_ThrowInfo` संरचना के लिए एक सूचक है, और यह आम तौर पर केवल फेंके जा रहे अपवाद का वर्णन करने के लिए है।
//
// वर्तमान में इस प्रकार [1] की परिभाषा थोड़ी बालों वाली है, और मुख्य विषमता (और ऑनलाइन लेख से अंतर) यह है कि 32-बिट पर पॉइंटर्स पॉइंटर्स होते हैं लेकिन 64-बिट पर पॉइंटर्स को 32-बिट ऑफ़सेट के रूप में व्यक्त किया जाता है। `__ImageBase` प्रतीक।
//
// इसे व्यक्त करने के लिए नीचे दिए गए मॉड्यूल में `ptr_t` और `ptr!` मैक्रो का उपयोग किया जाता है।
//
// इस प्रकार के ऑपरेशन के लिए एलएलवीएम द्वारा उत्सर्जित प्रकार की परिभाषाओं का चक्रव्यूह भी बारीकी से अनुसरण करता है।उदाहरण के लिए, यदि आप MSVC पर इस C++ कोड को संकलित करते हैं और LLVM IR उत्सर्जित करते हैं:
//
//      #include <stdint.h>
//
//      स्ट्रक्चर रस्ट_पैनिक {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      शून्य foo() { rust_panic a = {0, 1};
//          फेंको एक;}
//
// हम मूलतः यही अनुकरण करने का प्रयास कर रहे हैं।नीचे दिए गए अधिकांश स्थिर मान अभी LLVM से कॉपी किए गए हैं,
//
// किसी भी मामले में, ये सभी संरचनाएं एक समान तरीके से बनाई गई हैं, और यह हमारे लिए कुछ हद तक क्रियात्मक है।
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// ध्यान दें कि हम जानबूझकर यहां नाम प्रबंधन नियमों की उपेक्षा करते हैं: हम नहीं चाहते कि C++ केवल `struct rust_panic` घोषित करके Rust panics को पकड़ने में सक्षम हो।
//
//
// संशोधित करते समय, सुनिश्चित करें कि टाइप नाम स्ट्रिंग बिल्कुल `compiler/rustc_codegen_llvm/src/intrinsic.rs` में प्रयुक्त स्ट्रिंग से मेल खाती है।
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // यहां अग्रणी `\x01` बाइट वास्तव में LLVM के लिए एक जादुई संकेत है कि `_` कैरेक्टर के साथ प्रीफिक्सिंग जैसे किसी अन्य मैंगलिंग को *नहीं* लागू करें।
    //
    //
    // यह प्रतीक C++ के `std::type_info` द्वारा उपयोग किया जाने वाला vtable है।
    // `std::type_info` प्रकार के ऑब्जेक्ट, प्रकार के डिस्क्रिप्टर, इस तालिका में एक सूचक होते हैं।
    // टाइप डिस्क्रिप्टर को ऊपर परिभाषित सी ++ ईएच संरचनाओं द्वारा संदर्भित किया जाता है और जिसे हम नीचे बनाते हैं।
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// इस प्रकार के डिस्क्रिप्टर का उपयोग केवल अपवाद फेंकते समय किया जाता है।
// कैच भाग को आंतरिक प्रयास द्वारा नियंत्रित किया जाता है, जो अपना स्वयं का टाइपडिस्क्रिप्टर उत्पन्न करता है।
//
// यह ठीक है क्योंकि एमएसवीसी रनटाइम पॉइंटर समानता के बजाय टाइप डिस्क्रिप्टर से मेल खाने के लिए टाइप नाम पर स्ट्रिंग तुलना का उपयोग करता है।
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// विनाशक का उपयोग किया जाता है यदि सी ++ कोड अपवाद को पकड़ने और इसे प्रचारित किए बिना छोड़ने का निर्णय लेता है।
// कोशिश आंतरिक का पकड़ हिस्सा अपवाद वस्तु के पहले शब्द को 0 पर सेट करेगा ताकि इसे विनाशक द्वारा छोड़ दिया जा सके।
//
// ध्यान दें कि x86 Windows डिफ़ॉल्ट "C" कॉलिंग कन्वेंशन के बजाय C++ सदस्य कार्यों के लिए "thiscall" कॉलिंग कन्वेंशन का उपयोग करता है।
//
// अपवाद_कॉपी फ़ंक्शन यहां थोड़ा खास है: इसे MSVC रनटाइम द्वारा try/catch ब्लॉक के तहत लागू किया जाता है और panic जो हम यहां उत्पन्न करते हैं, उसका उपयोग अपवाद प्रतिलिपि के परिणाम के रूप में किया जाएगा।
//
// इसका उपयोग C++ रनटाइम द्वारा std::exception_ptr के साथ अपवादों को पकड़ने का समर्थन करने के लिए किया जाता है, जिसका हम समर्थन नहीं कर सकते क्योंकि Box<dyn Any>क्लोन करने योग्य नहीं है।
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException पूरी तरह से इस स्टैक फ्रेम पर निष्पादित होता है, इसलिए `data` को ढेर में स्थानांतरित करने की कोई आवश्यकता नहीं है।
    // हम इस फ़ंक्शन के लिए केवल एक स्टैक पॉइंटर पास करते हैं।
    //
    // यहां मैन्युअलीड्रॉप की आवश्यकता है क्योंकि हम नहीं चाहते कि अनइंडिंग करते समय अपवाद को छोड़ दिया जाए।
    // इसके बजाय इसे अपवाद_क्लीनअप द्वारा छोड़ दिया जाएगा जिसे सी ++ रनटाइम द्वारा बुलाया जाता है।
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // यह... आश्चर्यजनक लग सकता है, और उचित भी।32-बिट एमएसवीसी पर इन संरचनाओं के बीच पॉइंटर्स बस पॉइंटर्स हैं।
    // हालाँकि, 64-बिट MSVC पर, संरचनाओं के बीच के पॉइंटर्स को `__ImageBase` से 32-बिट ऑफ़सेट के रूप में व्यक्त किया जाता है।
    //
    // नतीजतन, 32-बिट एमएसवीसी पर हम इन सभी पॉइंटर्स को 'स्थिर' में घोषित कर सकते हैं।
    // 64-बिट MSVC पर, हमें स्टैटिक्स में पॉइंटर्स के घटाव को व्यक्त करना होगा, जिसे Rust वर्तमान में अनुमति नहीं देता है, इसलिए हम वास्तव में ऐसा नहीं कर सकते।
    //
    // अगली सबसे अच्छी बात, इन संरचनाओं को रनटाइम पर भरना है (वैसे भी घबराहट पहले से ही "slow path" है)।
    // तो यहां हम इन सभी पॉइंटर फ़ील्ड को 32-बिट पूर्णांक के रूप में पुन: व्याख्या करते हैं और फिर प्रासंगिक मान को इसमें संग्रहीत करते हैं (परमाणु रूप से, समवर्ती panics हो सकता है)।
    //
    // तकनीकी रूप से रनटाइम शायद इन क्षेत्रों का एक गैर-परमाणु पठन करेगा, लेकिन सिद्धांत रूप में वे कभी भी *गलत* मान नहीं पढ़ते हैं, इसलिए यह बहुत बुरा नहीं होना चाहिए ...
    //
    // किसी भी मामले में, हमें मूल रूप से ऐसा कुछ करने की ज़रूरत है जब तक कि हम स्टैटिक्स में अधिक संचालन व्यक्त नहीं कर सकते (और हम कभी भी सक्षम नहीं हो सकते)।
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // यहां NULL पेलोड का मतलब है कि हम __rust_try के कैच (...) से यहां आए हैं।
    // ऐसा तब होता है जब एक गैर-Rust विदेशी अपवाद पकड़ा जाता है।
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// यह संकलक के अस्तित्व के लिए आवश्यक है (उदाहरण के लिए, यह एक लैंग आइटम है), लेकिन इसे वास्तव में संकलक द्वारा कभी नहीं कहा जाता है क्योंकि __C_specific_handler या _except_handler3 हमेशा उपयोग किया जाने वाला व्यक्तित्व फ़ंक्शन है।
//
// इसलिए यह सिर्फ एक गर्भपात करने वाला ठूंठ है।
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}