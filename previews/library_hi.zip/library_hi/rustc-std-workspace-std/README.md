# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate के लिए दस्तावेज़ देखें।