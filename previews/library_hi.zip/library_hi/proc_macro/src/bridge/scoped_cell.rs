//! `Cell` (scoped) अस्तित्वगत जीवनकाल के लिए संस्करण।

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// लैम्ब्डा एप्लिकेशन टाइप करें, जीवन भर के साथ।
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// लैम्ब्डा टाइप करें जीवन भर, यानी, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) newtype FIXME(#52812) के साथ प्रोजेक्शन सीमाओं के आसपास काम करें `&'a mut <T as ApplyL<'b>>::Out` के साथ बदलें
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// `f` चलाते समय `self` से `replacement` में मान सेट करता है, जो पुराने मान को परस्पर रूप से प्राप्त करता है।
    /// `f` के बाहर निकलने के बाद पुराने मान को बहाल कर दिया जाएगा, यहां तक कि panic द्वारा भी, इसमें `f` द्वारा किए गए संशोधन भी शामिल हैं।
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// रैपर जो यह सुनिश्चित करता है कि सेल हमेशा भर जाए (मूल स्थिति के साथ, वैकल्पिक रूप से `f` द्वारा बदला गया), भले ही `f` घबरा गया हो।
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// `f` चलाते समय `self` से `value` में मान सेट करता है।
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}