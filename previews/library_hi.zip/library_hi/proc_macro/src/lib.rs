//! नए मैक्रो को परिभाषित करते समय मैक्रो लेखकों के लिए एक समर्थन पुस्तकालय।
//!
//! मानक वितरण द्वारा प्रदान की गई यह लाइब्रेरी, प्रक्रियात्मक रूप से परिभाषित मैक्रो परिभाषाओं के इंटरफेस में खपत प्रकार प्रदान करती है जैसे कि फ़ंक्शन-जैसे मैक्रोज़ `#[proc_macro]`, मैक्रो विशेषताएँ `#[proc_macro_attribute]` और कस्टम व्युत्पन्न विशेषताएँ`#[proc_macro_derive]`।
//!
//!
//! अधिक के लिए [the book] देखें।
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// निर्धारित करता है कि क्या proc_macro को वर्तमान में चल रहे प्रोग्राम के लिए पहुँच योग्य बनाया गया है।
///
/// proc_macro crate केवल प्रक्रियात्मक मैक्रोज़ के कार्यान्वयन के अंदर उपयोग के लिए अभिप्रेत है।इस crate panic में सभी कार्य यदि एक प्रक्रियात्मक मैक्रो के बाहर से लागू होते हैं, जैसे कि बिल्ड स्क्रिप्ट या यूनिट टेस्ट या साधारण Rust बाइनरी से।
///
/// Rust पुस्तकालयों के लिए विचार के साथ, जो मैक्रो और गैर-मैक्रो दोनों उपयोग मामलों का समर्थन करने के लिए डिज़ाइन किए गए हैं, `proc_macro::is_available()` यह पता लगाने के लिए एक गैर-घबराहट तरीका प्रदान करता है कि क्या proc_macro के एपीआई का उपयोग करने के लिए आवश्यक बुनियादी ढांचा वर्तमान में उपलब्ध है।
/// एक प्रक्रियात्मक मैक्रो के अंदर से लागू होने पर सत्य लौटाता है, अगर किसी अन्य बाइनरी से लागू किया जाता है तो झूठा होता है।
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// इस crate द्वारा प्रदान किया गया मुख्य प्रकार, tokens की एक अमूर्त धारा का प्रतिनिधित्व करता है, या, विशेष रूप से, token पेड़ों का एक क्रम।
/// प्रकार उन token पेड़ों पर पुनरावृति के लिए इंटरफेस प्रदान करते हैं और, इसके विपरीत, एक धारा में कई token पेड़ों को इकट्ठा करते हैं।
///
///
/// यह `#[proc_macro]`, `#[proc_macro_attribute]` और `#[proc_macro_derive]` परिभाषाओं का इनपुट और आउटपुट दोनों है।
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str` से त्रुटि वापस आ गई।
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// एक खाली `TokenStream` देता है जिसमें कोई token पेड़ नहीं है।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// जाँचता है कि क्या यह `TokenStream` खाली है।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// स्ट्रिंग को tokens में तोड़ने का प्रयास करता है और उन tokens को token स्ट्रीम में पार्स करता है।
/// कई कारणों से विफल हो सकता है, उदाहरण के लिए, यदि स्ट्रिंग में असंतुलित सीमांकक या भाषा में मौजूद वर्ण मौजूद नहीं हैं।
///
/// पार्स की गई स्ट्रीम में सभी tokens को `Span::call_site()` स्पैन मिलते हैं।
///
/// NOTE: कुछ त्रुटियाँ `LexError` को वापस करने के बजाय panics का कारण बन सकती हैं।हम इन त्रुटियों को बाद में `LexError` में बदलने का अधिकार सुरक्षित रखते हैं।
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// एनबी, पुल केवल `to_string` प्रदान करता है, इसके आधार पर `fmt::Display` को लागू करता है (दोनों के बीच सामान्य संबंध के विपरीत)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// token स्ट्रीम को एक स्ट्रिंग के रूप में प्रिंट करता है जिसे दोषरहित रूप से वापस उसी token स्ट्रीम (मॉड्यूलो स्पैन) में परिवर्तित किया जा सकता है, सिवाय संभवतः `TokenTree: :Group` के साथ `Delimiter::None` सीमांकक और नकारात्मक संख्यात्मक शाब्दिक।
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// डिबगिंग के लिए सुविधाजनक रूप में token प्रिंट करता है।
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// एक token स्ट्रीम बनाता है जिसमें एक token ट्री होता है।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// एक ही स्ट्रीम में कई token पेड़ एकत्र करता है।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token स्ट्रीम पर एक "flattening" ऑपरेशन, token ट्री को कई token स्ट्रीम से एक ही स्ट्रीम में एकत्रित करता है।
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) एक अनुकूलित कार्यान्वयन if/when संभव का उपयोग करें।
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// `TokenStream` प्रकार के लिए सार्वजनिक कार्यान्वयन विवरण, जैसे कि पुनरावृत्त।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// `टोकनस्ट्रीम` के `टोकनट्री` पर एक पुनरावर्तक।
    /// पुनरावृत्ति "shallow" है, उदाहरण के लिए, पुनरावर्तक सीमित समूहों में पुनरावृत्ति नहीं करता है, और पूरे समूह को token पेड़ के रूप में लौटाता है।
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` मनमाने ढंग से tokens स्वीकार करता है और इनपुट का वर्णन करने वाले `TokenStream` में फैलता है।
/// उदाहरण के लिए, `quote!(a + b)` एक व्यंजक उत्पन्न करेगा, जिसका मूल्यांकन करने पर, `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// `$` के साथ अनकोटिंग किया जाता है, और सिंगल नेक्स्ट आइडेंटिटी को अनक्वॉटेड टर्म के रूप में लेकर काम करता है।
/// `$` को ही उद्धृत करने के लिए, `$$` का उपयोग करें।
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// स्रोत कोड का एक क्षेत्र, मैक्रो विस्तार जानकारी के साथ।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// `self` स्पैन पर दिए गए `message` के साथ एक नया `Diagnostic` बनाता है।
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// एक अवधि जो मैक्रो परिभाषा साइट पर हल होती है।
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// वर्तमान प्रक्रियात्मक मैक्रो के आह्वान की अवधि।
    /// इस अवधि के साथ बनाए गए पहचानकर्ताओं को हल किया जाएगा जैसे कि वे सीधे मैक्रो कॉल स्थान (कॉल-साइट स्वच्छता) पर लिखे गए थे और मैक्रो कॉल साइट पर अन्य कोड भी उन्हें संदर्भित करने में सक्षम होंगे।
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// एक स्पैन जो `macro_rules` स्वच्छता का प्रतिनिधित्व करता है, और कभी-कभी मैक्रो डेफिनिशन साइट (स्थानीय चर, लेबल, `$crate`) और कभी-कभी मैक्रो कॉल साइट (बाकी सब कुछ) पर हल होता है।
    ///
    /// स्पैन लोकेशन कॉल-साइट से ली गई है।
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// मूल स्रोत फ़ाइल जिसमें यह अवधि इंगित करती है।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// पिछले मैक्रो विस्तार में tokens के लिए `Span` जिससे `self` उत्पन्न हुआ था, यदि कोई हो।
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// मूल स्रोत कोड की अवधि जिससे `self` उत्पन्न हुआ था।
    /// यदि यह `Span` अन्य मैक्रो विस्तारों से उत्पन्न नहीं हुआ था, तो वापसी मूल्य `*self` के समान है।
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// इस अवधि के लिए स्रोत फ़ाइल में प्रारंभिक line/column प्राप्त करता है।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// इस अवधि के लिए स्रोत फ़ाइल में अंतिम line/column प्राप्त करें।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` और `other` को शामिल करते हुए एक नया स्पैन बनाता है।
    ///
    /// यदि `self` और `other` अलग-अलग फाइलों से हैं तो `None` लौटाता है।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` के समान line/column जानकारी के साथ एक नया स्पैन बनाता है लेकिन यह प्रतीकों को हल करता है जैसे कि यह `other` पर था।
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` के समान नाम रिज़ॉल्यूशन व्यवहार के साथ लेकिन `other` की line/column जानकारी के साथ एक नया स्पैन बनाता है।
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// स्पैन से तुलना करके देखें कि क्या वे बराबर हैं।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// स्रोत टेक्स्ट को एक स्पैन के पीछे लौटाता है।
    /// यह रिक्त स्थान और टिप्पणियों सहित मूल स्रोत कोड को सुरक्षित रखता है।
    /// यह केवल एक परिणाम देता है यदि अवधि वास्तविक स्रोत कोड से मेल खाती है।
    ///
    /// Note: मैक्रो का अवलोकन योग्य परिणाम केवल tokens पर निर्भर होना चाहिए न कि इस स्रोत टेक्स्ट पर।
    ///
    /// इस फ़ंक्शन का परिणाम केवल निदान के लिए उपयोग किए जाने का सर्वोत्तम प्रयास है।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// डिबगिंग के लिए सुविधाजनक रूप में एक स्पैन प्रिंट करता है।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// एक पंक्ति-स्तंभ जोड़ी `Span` के प्रारंभ या अंत का प्रतिनिधित्व करती है।
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// स्रोत फ़ाइल में 1-अनुक्रमित रेखा जिस पर अवधि (inclusive) प्रारंभ या समाप्त होती है।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// स्रोत फ़ाइल में 0-अनुक्रमित स्तंभ (UTF-8 वर्णों में) जिस पर अवधि (inclusive) प्रारंभ या समाप्त होती है।
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// किसी दिए गए `Span` की स्रोत फ़ाइल।
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// इस स्रोत फ़ाइल का पथ प्राप्त करता है।
    ///
    /// ### Note
    /// यदि इस `SourceFile` से संबद्ध कोड अवधि एक बाहरी मैक्रो, इस मैक्रो द्वारा उत्पन्न की गई थी, तो यह फाइल सिस्टम पर वास्तविक पथ नहीं हो सकता है।
    /// जाँच करने के लिए [`is_real`] का उपयोग करें।
    ///
    /// यह भी ध्यान दें कि भले ही `is_real` `true` लौटाता हो, यदि `--remap-path-prefix` कमांड लाइन पर पारित किया गया था, तो दिया गया पथ वास्तव में मान्य नहीं हो सकता है।
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// यदि यह स्रोत फ़ाइल एक वास्तविक स्रोत फ़ाइल है, और बाहरी मैक्रो के विस्तार द्वारा उत्पन्न नहीं हुई है, तो `true` लौटाता है।
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // यह एक हैक है जब तक कि इंटरक्रेट स्पैन लागू नहीं हो जाते हैं और हमारे पास बाहरी मैक्रोज़ में उत्पन्न स्पैन के लिए वास्तविक स्रोत फ़ाइलें हो सकती हैं।
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// एक एकल token या token पेड़ों का एक सीमांकित अनुक्रम (जैसे, `[1, (), ..]`)।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// एक token धारा ब्रैकेट सीमांकक से घिरी हुई है।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// एक पहचानकर्ता।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// एक एकल विराम चिह्न (`+`, `,`, `$`, आदि)।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// एक शाब्दिक चरित्र (`'a'`), स्ट्रिंग (`"hello"`), संख्या (`2.3`), आदि।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// इस पेड़ की अवधि देता है, निहित token या एक सीमित स्ट्रीम की `span` विधि को सौंपता है।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *केवल इस token* के लिए स्पैन कॉन्फ़िगर करता है।
    ///
    /// ध्यान दें कि यदि यह token एक `Group` है तो यह विधि प्रत्येक आंतरिक tokens की अवधि को कॉन्फ़िगर नहीं करेगी, यह केवल प्रत्येक संस्करण की `set_span` विधि को सौंपेगी।
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// डिबगिंग के लिए सुविधाजनक रूप में token ट्री प्रिंट करता है।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // इनमें से प्रत्येक का नाम व्युत्पन्न डीबग में संरचना प्रकार में है, इसलिए संकेत की एक अतिरिक्त परत से परेशान न हों
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// एनबी, पुल केवल `to_string` प्रदान करता है, इसके आधार पर `fmt::Display` को लागू करता है (दोनों के बीच सामान्य संबंध के विपरीत)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// token ट्री को एक स्ट्रिंग के रूप में प्रिंट करता है जिसे दोषरहित रूप से वापस उसी token ट्री (मॉड्यूलो स्पैन) में परिवर्तित किया जा सकता है, सिवाय संभवतः `TokenTree: :Group` के साथ `Delimiter::None` सीमांकक और नकारात्मक संख्यात्मक शाब्दिक।
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// एक सीमित token स्ट्रीम।
///
/// एक `Group` में आंतरिक रूप से एक `TokenStream` होता है जो `Delimiter` से घिरा होता है।
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// वर्णन करता है कि कैसे token पेड़ों का एक क्रम सीमांकित किया जाता है।
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// एक निहित सीमांकक, जो, उदाहरण के लिए, "macro variable" `$var` से आने वाले tokens के आसपास दिखाई दे सकता है।
    /// `$var * 3` जैसे मामलों में ऑपरेटर प्राथमिकताओं को संरक्षित करना महत्वपूर्ण है जहां `$var` `1 + 2` है।
    /// निहित सीमांकक एक स्ट्रिंग के माध्यम से token स्ट्रीम के राउंडट्रिप से बच नहीं सकते हैं।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// दिए गए सीमांकक और token स्ट्रीम के साथ एक नया `Group` बनाता है।
    ///
    /// यह कंस्ट्रक्टर इस समूह की अवधि को `Span::call_site()` पर सेट करेगा।
    /// अवधि बदलने के लिए आप नीचे दिए गए `set_span` विधि का उपयोग कर सकते हैं।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// इस `Group` का सीमांकक लौटाता है
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// इस `Group` में सीमांकित tokens का `TokenStream` लौटाता है।
    ///
    /// ध्यान दें कि लौटाई गई token स्ट्रीम में ऊपर लौटाए गए डिलीमीटर शामिल नहीं हैं।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// पूरे `Group` में फैले इस token स्ट्रीम के सीमांकक के लिए अवधि लौटाता है।
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// इस समूह के शुरुआती सीमांकक की ओर इशारा करते हुए अवधि लौटाता है।
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// इस समूह के समापन सीमांकक की ओर इशारा करते हुए अवधि लौटाता है।
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// इस `समूह` के सीमांकक के लिए अवधि को कॉन्फ़िगर करता है, लेकिन इसके आंतरिक tokens को नहीं।
    ///
    /// यह विधि इस समूह द्वारा फैले सभी आंतरिक tokens की अवधि **नहीं** निर्धारित करेगी, बल्कि यह केवल `Group` के स्तर पर सीमांकक tokens की अवधि निर्धारित करेगी।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// एनबी, पुल केवल `to_string` प्रदान करता है, इसके आधार पर `fmt::Display` को लागू करता है (दोनों के बीच सामान्य संबंध के विपरीत)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// समूह को एक स्ट्रिंग के रूप में प्रिंट करता है जिसे दोषरहित रूप से वापस उसी समूह (मॉड्यूलो स्पैन) में परिवर्तित किया जाना चाहिए, सिवाय संभवतः `टोकनट्री: : ग्रुप` के साथ `Delimiter::None` सीमांकक।
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` `+`, `-` या `#` की तरह एक एकल विराम चिह्न है।
///
/// `+=` जैसे मल्टी-कैरेक्टर ऑपरेटरों को `Punct` के दो उदाहरणों के रूप में दर्शाया जाता है, जिसमें `Spacing` के विभिन्न रूप वापस आते हैं।
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// क्या एक `Punct` के तुरंत बाद दूसरा `Punct` या उसके बाद दूसरा token या व्हाइटस्पेस आता है।
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// उदाहरण के लिए, `+`, `+ =`, `+ident` या `+()` में `Alone` है।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// उदाहरण के लिए, `+=` या `'#` में `+`, `Joint` है।
    /// इसके अतिरिक्त, सिंगल कोट `'` लाइफटाइम `'ident` बनाने के लिए पहचानकर्ताओं के साथ जुड़ सकता है।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// दिए गए वर्ण और रिक्ति से एक नया `Punct` बनाता है।
    /// `ch` तर्क भाषा द्वारा अनुमत एक मान्य विराम चिह्न वर्ण होना चाहिए, अन्यथा फ़ंक्शन panic होगा।
    ///
    /// लौटाए गए `Punct` में `Span::call_site()` की डिफ़ॉल्ट अवधि होगी जिसे नीचे दिए गए `set_span` विधि के साथ आगे कॉन्फ़िगर किया जा सकता है।
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// इस विराम चिह्न का मान `char` के रूप में लौटाता है।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// इस विराम चिह्न वर्ण की रिक्ति देता है, यह दर्शाता है कि क्या इसके तुरंत बाद token स्ट्रीम में एक और `Punct` है, इसलिए उन्हें संभावित रूप से एक बहु-वर्ण ऑपरेटर (`Joint`) में जोड़ा जा सकता है, या इसके बाद कुछ अन्य token या व्हाइटस्पेस (`Alone`) है, इसलिए ऑपरेटर के पास निश्चित रूप से है समाप्त हो गया।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// इस विराम चिह्न वर्ण की अवधि लौटाता है।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// इस विराम चिह्न वर्ण के लिए स्पैन कॉन्फ़िगर करें।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// एनबी, पुल केवल `to_string` प्रदान करता है, इसके आधार पर `fmt::Display` को लागू करता है (दोनों के बीच सामान्य संबंध के विपरीत)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// विराम चिह्न वर्ण को एक स्ट्रिंग के रूप में प्रिंट करता है जो दोषरहित रूप से वापस उसी वर्ण में परिवर्तनीय होना चाहिए।
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// एक पहचानकर्ता (`ident`)।
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// दिए गए `string` के साथ-साथ निर्दिष्ट `span` के साथ एक नया `Ident` बनाता है।
    /// `string` तर्क भाषा द्वारा अनुमत एक मान्य पहचानकर्ता होना चाहिए (कीवर्ड सहित, जैसे `self` या `fn`)।अन्यथा, फ़ंक्शन panic होगा।
    ///
    /// ध्यान दें कि `span`, वर्तमान में rustc में, इस पहचानकर्ता के लिए स्वच्छता जानकारी को कॉन्फ़िगर करता है।
    ///
    /// इस समय तक `Span::call_site()` स्पष्ट रूप से "call-site" स्वच्छता में ऑप्ट-इन करता है, जिसका अर्थ है कि इस अवधि के साथ बनाए गए पहचानकर्ताओं को इस तरह हल किया जाएगा जैसे कि वे सीधे मैक्रो कॉल के स्थान पर लिखे गए थे, और मैक्रो कॉल साइट पर अन्य कोड संदर्भित करने में सक्षम होंगे उन्हें भी।
    ///
    ///
    /// बाद में `Span::def_site()` जैसे स्पैन "definition-site" हाइजीन में ऑप्ट-इन करने की अनुमति देंगे, जिसका अर्थ है कि इस अवधि के साथ बनाए गए पहचानकर्ताओं को मैक्रो परिभाषा के स्थान पर हल किया जाएगा और मैक्रो कॉल साइट पर अन्य कोड उन्हें संदर्भित नहीं कर पाएंगे।
    ///
    /// स्वच्छता के वर्तमान महत्व के कारण, इस निर्माता को, अन्य tokens के विपरीत, निर्माण में निर्दिष्ट करने के लिए `Span` की आवश्यकता होती है।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` के समान, लेकिन एक कच्चा पहचानकर्ता (`r#ident`) बनाता है।
    /// `string` तर्क भाषा द्वारा अनुमत एक मान्य पहचानकर्ता होना चाहिए (कीवर्ड सहित, जैसे `fn`)।
    /// पथ खंडों में प्रयोग करने योग्य खोजशब्द (जैसे
    /// `self`, `सुपर`) समर्थित नहीं हैं, और एक panic का कारण बनेंगे।
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// इस `Ident` की अवधि लौटाता है, जिसमें [`to_string`](Self::to_string) द्वारा लौटाई गई संपूर्ण स्ट्रिंग शामिल है।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// इस `Ident` की अवधि को कॉन्फ़िगर करता है, संभवतः इसके स्वच्छता संदर्भ को बदल रहा है।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// एनबी, पुल केवल `to_string` प्रदान करता है, इसके आधार पर `fmt::Display` को लागू करता है (दोनों के बीच सामान्य संबंध के विपरीत)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// पहचानकर्ता को एक स्ट्रिंग के रूप में प्रिंट करता है जो दोषरहित रूप से उसी पहचानकर्ता में परिवर्तनीय होना चाहिए।
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// एक शाब्दिक स्ट्रिंग (`"hello"`), बाइट स्ट्रिंग (`b"hello"`), वर्ण (`'a'`), बाइट वर्ण (`b'a'`), एक पूर्णांक या फ़्लोटिंग बिंदु संख्या जिसमें प्रत्यय के साथ या उसके बिना (`1`, `1u8`, `2.3`, `2.3f32`)।
///
/// `true` और `false` जैसे बूलियन अक्षर यहां नहीं हैं, वे `पहचान` हैं।
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// निर्दिष्ट मान के साथ एक नया प्रत्यय पूर्णांक शाब्दिक बनाता है।
        ///
        /// यह फ़ंक्शन `1u32` की तरह एक पूर्णांक बनाएगा जहां निर्दिष्ट पूर्णांक मान token का पहला भाग है और अंत में इंटीग्रल भी प्रत्यय है।
        /// ऋणात्मक संख्याओं से निर्मित अक्षर `TokenStream` या स्ट्रिंग्स के माध्यम से राउंड-ट्रिप से नहीं बच सकते हैं और दो tokens (`-` और सकारात्मक शाब्दिक) में तोड़े जा सकते हैं।
        ///
        ///
        /// इस पद्धति के माध्यम से बनाए गए साहित्य में डिफ़ॉल्ट रूप से `Span::call_site()` स्पैन होता है, जिसे नीचे दिए गए `set_span` विधि से कॉन्फ़िगर किया जा सकता है।
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// निर्दिष्ट मान के साथ एक नया अपरिष्कृत पूर्णांक शाब्दिक बनाता है।
        ///
        /// यह फ़ंक्शन `1` जैसा एक पूर्णांक बनाएगा जहां निर्दिष्ट पूर्णांक मान token का पहला भाग है।
        /// इस token पर कोई प्रत्यय निर्दिष्ट नहीं है, जिसका अर्थ है कि `Literal::i8_unsuffixed(1)` जैसे आमंत्रण `Literal::u32_unsuffixed(1)` के बराबर हैं।
        /// ऋणात्मक संख्याओं से निर्मित अक्षर `TokenStream` या स्ट्रिंग्स के माध्यम से राउंडट्रिप में जीवित नहीं रह सकते हैं और इन्हें दो tokens (`-` और सकारात्मक शाब्दिक) में तोड़ा जा सकता है।
        ///
        ///
        /// इस पद्धति के माध्यम से बनाए गए साहित्य में डिफ़ॉल्ट रूप से `Span::call_site()` स्पैन होता है, जिसे नीचे दिए गए `set_span` विधि से कॉन्फ़िगर किया जा सकता है।
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// एक नया अपरिष्कृत फ़्लोटिंग-पॉइंट शाब्दिक बनाता है।
    ///
    /// यह कंस्ट्रक्टर `Literal::i8_unsuffixed` के समान है जहां फ्लोट का मान सीधे token में उत्सर्जित होता है लेकिन किसी प्रत्यय का उपयोग नहीं किया जाता है, इसलिए इसे बाद में कंपाइलर में `f64` होने का अनुमान लगाया जा सकता है।
    ///
    /// ऋणात्मक संख्याओं से निर्मित अक्षर `TokenStream` या स्ट्रिंग्स के माध्यम से राउंडट्रिप में जीवित नहीं रह सकते हैं और इन्हें दो tokens (`-` और सकारात्मक शाब्दिक) में तोड़ा जा सकता है।
    ///
    /// # Panics
    ///
    /// इस फ़ंक्शन के लिए आवश्यक है कि निर्दिष्ट फ्लोट सीमित है, उदाहरण के लिए यदि यह अनंत या NaN है तो यह फ़ंक्शन panic होगा।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// एक नया प्रत्यय फ़्लोटिंग-पॉइंट शाब्दिक बनाता है।
    ///
    /// यह कंस्ट्रक्टर `1.0f32` की तरह एक शाब्दिक निर्माण करेगा जहां निर्दिष्ट मान token का पूर्ववर्ती भाग है और `f32` token का प्रत्यय है।
    /// यह token हमेशा संकलक में एक `f32` होने का अनुमान लगाया जाएगा।
    /// ऋणात्मक संख्याओं से निर्मित अक्षर `TokenStream` या स्ट्रिंग्स के माध्यम से राउंडट्रिप में जीवित नहीं रह सकते हैं और इन्हें दो tokens (`-` और सकारात्मक शाब्दिक) में तोड़ा जा सकता है।
    ///
    ///
    /// # Panics
    ///
    /// इस फ़ंक्शन के लिए आवश्यक है कि निर्दिष्ट फ्लोट सीमित है, उदाहरण के लिए यदि यह अनंत या NaN है तो यह फ़ंक्शन panic होगा।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// एक नया अपरिष्कृत फ़्लोटिंग-पॉइंट शाब्दिक बनाता है।
    ///
    /// यह कंस्ट्रक्टर `Literal::i8_unsuffixed` के समान है जहां फ्लोट का मान सीधे token में उत्सर्जित होता है लेकिन किसी प्रत्यय का उपयोग नहीं किया जाता है, इसलिए इसे बाद में कंपाइलर में `f64` होने का अनुमान लगाया जा सकता है।
    ///
    /// ऋणात्मक संख्याओं से निर्मित अक्षर `TokenStream` या स्ट्रिंग्स के माध्यम से राउंडट्रिप में जीवित नहीं रह सकते हैं और इन्हें दो tokens (`-` और सकारात्मक शाब्दिक) में तोड़ा जा सकता है।
    ///
    /// # Panics
    ///
    /// इस फ़ंक्शन के लिए आवश्यक है कि निर्दिष्ट फ्लोट सीमित है, उदाहरण के लिए यदि यह अनंत या NaN है तो यह फ़ंक्शन panic होगा।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// एक नया प्रत्यय फ़्लोटिंग-पॉइंट शाब्दिक बनाता है।
    ///
    /// यह कंस्ट्रक्टर `1.0f64` की तरह एक शाब्दिक निर्माण करेगा जहां निर्दिष्ट मान token का पूर्ववर्ती भाग है और `f64` token का प्रत्यय है।
    /// यह token हमेशा संकलक में एक `f64` होने का अनुमान लगाया जाएगा।
    /// ऋणात्मक संख्याओं से निर्मित अक्षर `TokenStream` या स्ट्रिंग्स के माध्यम से राउंडट्रिप में जीवित नहीं रह सकते हैं और इन्हें दो tokens (`-` और सकारात्मक शाब्दिक) में तोड़ा जा सकता है।
    ///
    ///
    /// # Panics
    ///
    /// इस फ़ंक्शन के लिए आवश्यक है कि निर्दिष्ट फ्लोट सीमित है, उदाहरण के लिए यदि यह अनंत या NaN है तो यह फ़ंक्शन panic होगा।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// शाब्दिक स्ट्रिंग।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// चरित्र शाब्दिक।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// बाइट स्ट्रिंग शाब्दिक।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// इस शाब्दिक को शामिल करने वाला स्पैन लौटाता है।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// इस शाब्दिक के लिए संबद्ध अवधि को कॉन्फ़िगर करता है।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// एक `Span` देता है जो `self.span()` का सबसेट है जिसमें `range` श्रेणी में केवल स्रोत बाइट्स होते हैं।
    /// यदि छंटनी की जाने वाली अवधि `self` की सीमा से बाहर है, तो `None` लौटाता है।
    ///
    // FIXME(SergioBenitez): जांचें कि बाइट रेंज स्रोत की UTF-8 सीमा पर शुरू और समाप्त होती है।
    // अन्यथा, यह संभावना है कि स्रोत पाठ मुद्रित होने पर panic कहीं और घटित होगा।
    // FIXME(SergioBenitez): उपयोगकर्ता के लिए यह जानने का कोई तरीका नहीं है कि `self.span()` वास्तव में क्या मैप करता है, इसलिए इस पद्धति को वर्तमान में केवल आँख बंद करके ही कहा जा सकता है।
    // उदाहरण के लिए, 'c' वर्ण के लिए `to_string()` "'\u{63}'" लौटाता है;उपयोगकर्ता के लिए यह जानने का कोई तरीका नहीं है कि स्रोत टेक्स्ट 'c' था या क्या वह '\u{63}' था।
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` जैसा कुछ, लेकिन `Bound<&T>` के लिए।
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// एनबी, पुल केवल `to_string` प्रदान करता है, इसके आधार पर `fmt::Display` को लागू करता है (दोनों के बीच सामान्य संबंध के विपरीत)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// शाब्दिक को एक स्ट्रिंग के रूप में प्रिंट करता है जिसे दोषरहित रूप से वापस उसी शाब्दिक में परिवर्तित किया जाना चाहिए (फ़्लोटिंग पॉइंट शाब्दिक के लिए संभावित गोलाई को छोड़कर)।
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// पर्यावरण चर के लिए ट्रैक की गई पहुंच।
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// एक पर्यावरण चर पुनर्प्राप्त करें और इसे निर्भरता जानकारी बनाने के लिए जोड़ें।
    /// कंपाइलर को क्रियान्वित करने वाले बिल्ड सिस्टम को पता चल जाएगा कि वेरिएबल को कंपाइलेशन के दौरान एक्सेस किया गया था, और उस वेरिएबल का मान बदलने पर बिल्ड को फिर से चलाने में सक्षम होगा।
    ///
    /// निर्भरता के अलावा यह फ़ंक्शन मानक पुस्तकालय से `env::var` के बराबर होना चाहिए, सिवाय इसके कि तर्क UTF-8 होना चाहिए।
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}