#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html) देखें।
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html) देखें।
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html) देखें।
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html) देखें।
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html) देखें।
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html) देखें।
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// कैश लाइन प्राप्त करें जिसमें दिए गए `rw` और `locality` का उपयोग करके पता `p` है।
///
/// `rw` इनमें से एक होना चाहिए:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): प्रीफेच पढ़ने की तैयारी कर रहा है।
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): प्रीफेच लिखने की तैयारी कर रहा है।
///
/// `locality` इनमें से एक होना चाहिए:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): केवल एक बार उपयोग किए जाने वाले डेटा के लिए स्ट्रीमिंग या गैर-अस्थायी प्रीफ़ेच।
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): स्तर 3 कैश में लाएं।
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): लेवल 2 कैश में लाएं।
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): स्तर 1 कैश में प्राप्त करें।
///
/// प्रीफेच मेमोरी निर्देश मेमोरी सिस्टम को संकेत देते हैं कि एक निर्दिष्ट पते से मेमोरी एक्सेस होने की संभावना future के निकट होने की संभावना है।
/// स्मृति प्रणाली ऐसी कार्रवाइयाँ करके प्रतिक्रिया दे सकती है जिनसे स्मृति पहुँच को तेज करने की अपेक्षा की जाती है, जैसे कि एक या अधिक कैश में निर्दिष्ट पते को प्रीलोड करना।
///
/// चूंकि ये संकेत केवल संकेत हैं, यह किसी विशेष सीपीयू के लिए किसी भी या सभी प्रीफेच निर्देशों को एनओपी के रूप में मानने के लिए मान्य है।
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // हम `llvm.prefetch` इंस्ट्रिन्सिक का उपयोग `cache type` =1 (डेटा कैश) के साथ करते हैं।
    // `rw` और `strategy` फ़ंक्शन पैरामीटर पर आधारित हैं।
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}