use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // हमारे `#[assert_instr]` एनोटेशन को यह बताने के लिए उपयोग किया जाता है कि सभी सिम इंट्रिनिक्स उनके कोडजन का परीक्षण करने के लिए उपलब्ध हैं, क्योंकि कुछ अतिरिक्त `-Ctarget-feature=+unimplemented-simd128` के पीछे गेट किए गए हैं जिनके पास अभी `#[target_feature]` में कोई समकक्ष नहीं है।
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}