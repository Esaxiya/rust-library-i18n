`core::arch` - Rust की कोर लाइब्रेरी आर्किटेक्चर-विशिष्ट इंट्रिनिक्स
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` मॉड्यूल आर्किटेक्चर पर निर्भर इंट्रिनिक्स (जैसे SIMD) को लागू करता है।

# Usage 

`core::arch` `libcore` के हिस्से के रूप में उपलब्ध है और इसे `libstd` द्वारा पुनः निर्यात किया जाता है।इस crate के बजाय `core::arch` या `std::arch` के माध्यम से इसका उपयोग करना पसंद करते हैं।
`feature(stdsimd)` के माध्यम से रात के समय Rust में अस्थिर सुविधाएँ अक्सर उपलब्ध होती हैं।

इस crate के माध्यम से `core::arch` का उपयोग करने के लिए रात्रिकालीन Rust की आवश्यकता होती है, और यह अक्सर टूट सकता है (और करता है)।केवल वे मामले जिनमें आपको इस crate के माध्यम से इसका उपयोग करने पर विचार करना चाहिए:

* यदि आपको स्वयं `core::arch` को फिर से संकलित करने की आवश्यकता है, उदाहरण के लिए, विशेष लक्ष्य-सुविधाओं के साथ जो `libcore`/`libstd` के लिए सक्षम नहीं हैं।
Note: यदि आपको इसे गैर-मानक लक्ष्य के लिए फिर से संकलित करने की आवश्यकता है, तो कृपया इस crate का उपयोग करने के बजाय `xargo` का उपयोग करना और `libcore`/`libstd` को फिर से संकलित करना पसंद करें।
  
* कुछ सुविधाओं का उपयोग करना जो अस्थिर Rust सुविधाओं के पीछे भी उपलब्ध नहीं हो सकता है।हम इन्हें कम से कम रखने की कोशिश करते हैं।
यदि आपको इनमें से कुछ सुविधाओं का उपयोग करने की आवश्यकता है, तो कृपया एक समस्या खोलें ताकि हम उन्हें रात के Rust में उजागर कर सकें और आप उनका उपयोग वहां से कर सकें।

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` मुख्य रूप से एमआईटी लाइसेंस और Apache लाइसेंस (संस्करण 2.0) दोनों की शर्तों के तहत वितरित किया जाता है, जिसमें विभिन्न बीएसडी-जैसे लाइसेंस द्वारा कवर किए गए हिस्से होते हैं।

विवरण के लिए LICENSE-APACHE, और LICENSE-MIT देखें।

# Contribution

जब तक आप स्पष्ट रूप से अन्यथा नहीं बताते हैं, आपके द्वारा `core_arch` में शामिल करने के लिए जानबूझकर सबमिट किया गया कोई भी योगदान, जैसा कि Apache-2.0 लाइसेंस में परिभाषित किया गया है, बिना किसी अतिरिक्त नियम या शर्तों के, उपरोक्त के अनुसार दोहरा लाइसेंस होगा।


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












