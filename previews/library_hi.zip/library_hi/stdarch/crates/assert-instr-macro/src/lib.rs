//! `#[assert_instr]` मैक्रो का कार्यान्वयन
//!
//! `stdarch` crate का परीक्षण करते समय इस मैक्रो का उपयोग किया जाता है और परीक्षण मामलों को उत्पन्न करने के लिए उपयोग किया जाता है ताकि यह सुनिश्चित किया जा सके कि फ़ंक्शन में वास्तव में वे निर्देश होते हैं जिनकी हम उम्मीद कर रहे हैं।
//!
//! यहां प्रक्रियात्मक मैक्रो अपेक्षाकृत सरल है, यह केवल मूल token स्ट्रीम में एक `#[test]` फ़ंक्शन जोड़ता है जो दावा करता है कि फ़ंक्शन में प्रासंगिक निर्देश शामिल हैं।
//!
//!
//!
//!

extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;

#[proc_macro_attribute]
pub fn assert_instr(
    attr: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    let invoc = match syn::parse::<Invoc>(attr) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let item = match syn::parse::<syn::Item>(item) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let func = match item {
        syn::Item::Fn(ref f) => f,
        _ => panic!("must be attached to a function"),
    };

    let instr = &invoc.instr;
    let name = &func.sig.ident;

    // avx सक्षम के साथ संकलित x86 लक्ष्यों के लिए assert_instr अक्षम करें, जिसके कारण LLVM विभिन्न इंट्रिनिक्स उत्पन्न करता है जिसका हम परीक्षण कर रहे हैं।
    //
    //
    let disable_assert_instr = std::env::var("STDARCH_DISABLE_ASSERT_INSTR").is_ok();

    // यदि निर्देश परीक्षण अक्षम हैं तो इस शिम को बिल्कुल भी उत्सर्जित करने से बचें, बस मूल वस्तु को हमारी विशेषता के बिना वापस कर दें।
    //
    if !cfg!(optimized) || disable_assert_instr {
        return (quote! { #item }).into();
    }

    let instr_str = instr
        .replace('.', "_")
        .replace('/', "_")
        .replace(':', "_")
        .replace(char::is_whitespace, "");
    let assert_name = syn::Ident::new(&format!("assert_{}_{}", name, instr_str), name.span());
    // ये नाम हमारे लिए इतना अनूठा होना चाहिए कि हम इसे बाद में डिस्सेप्लर में ढूंढ सकें:
    let shim_name = syn::Ident::new(
        &format!("stdarch_test_shim_{}_{}", name, instr_str),
        name.span(),
    );
    let mut inputs = Vec::new();
    let mut input_vals = Vec::new();
    let ret = &func.sig.output;
    for arg in func.sig.inputs.iter() {
        let capture = match *arg {
            syn::FnArg::Typed(ref c) => c,
            ref v => panic!(
                "arguments must not have patterns: `{:?}`",
                v.clone().into_token_stream()
            ),
        };
        let ident = match *capture.pat {
            syn::Pat::Ident(ref i) => &i.ident,
            _ => panic!("must have bare arguments"),
        };
        if let Some(&(_, ref tokens)) = invoc.args.iter().find(|a| *ident == a.0) {
            input_vals.push(quote! { #tokens });
        } else {
            inputs.push(capture);
            input_vals.push(quote! { #ident });
        }
    }

    let attrs = func
        .attrs
        .iter()
        .filter(|attr| {
            attr.path
                .segments
                .first()
                .expect("attr.path.segments.first() failed")
                .ident
                .to_string()
                .starts_with("target")
        })
        .collect::<Vec<_>>();
    let attrs = Append(&attrs);

    // Windows पर एक ABI का उपयोग करें जो रजिस्टरों में SIMD मान पास करता है, जैसे डिफ़ॉल्ट रूप से Unix (मुझे लगता है?) पर क्या होता है।
    //
    let abi = if cfg!(windows) {
        syn::LitStr::new("vectorcall", proc_macro2::Span::call_site())
    } else {
        syn::LitStr::new("C", proc_macro2::Span::call_site())
    };
    let shim_name_str = format!("{}{}", shim_name, assert_name);
    let to_test = quote! {
        #attrs
        #[no_mangle]
        #[inline(never)]
        pub unsafe extern #abi fn #shim_name(#(#inputs),*) #ret {
            // डिफ़ॉल्ट रूप से अनुकूलित मोड में कंपाइलर "mergefunc" नामक एक पास चलाता है जहां यह समान दिखने वाले कार्यों को मर्ज करेगा।
            // पता चलता है कि कुछ इंट्रिनिक्स समान कोड उत्पन्न करते हैं और वे एक साथ जुड़ जाते हैं, जिसका अर्थ है कि एक बस दूसरे पर कूद जाता है।
            // यह इस फ़ंक्शन के डिस्सेप्लर के हमारे निरीक्षण को गड़बड़ कर देता है और हम इसके बहुत बड़े प्रशंसक नहीं हैं।
            //
            // इस पास को विफल करने और कार्यों को विलय होने से रोकने के लिए हम कुछ कोड उत्पन्न करते हैं जो कोडजन के संदर्भ में बहुत तंग है लेकिन कोड को फोल्ड होने से रोकने के लिए अन्यथा अद्वितीय है।
            //
            //
            // Wasm32 पर अभी इसे टाला गया है क्योंकि ये फ़ंक्शन इनलाइन नहीं हैं जो हमारे परीक्षणों को तोड़ते हैं क्योंकि प्रत्येक आंतरिक ऐसा लगता है जैसे यह फ़ंक्शन को कॉल करता है।
            // टर्न आउट फ़ंक्शन वैसे भी wasm32 पर विलय करने के लिए पर्याप्त समान नहीं हैं।
            // इस बग को rust-lang/rust#74320 पर ट्रैक किया गया है।
            //
            //
            //
            //
            //
            //
            //
            #[cfg(not(target_arch = "wasm32"))]
            ::stdarch_test::_DONT_DEDUP.store(
                std::mem::transmute(#shim_name_str.as_bytes().as_ptr()),
                std::sync::atomic::Ordering::Relaxed,
            );
            #name(#(#input_vals),*)
        }
    };

    let tokens: TokenStream = quote! {
        #[test]
        #[allow(non_snake_case)]
        fn #assert_name() {
            #to_test

            ::stdarch_test::assert(#shim_name as usize,
                                   stringify!(#shim_name),
                                   #instr);
        }
    };

    let tokens: TokenStream = quote! {
        #item
        #tokens
    };
    tokens.into()
}

struct Invoc {
    instr: String,
    args: Vec<(syn::Ident, syn::Expr)>,
}

impl syn::parse::Parse for Invoc {
    fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        use syn::{ext::IdentExt, Token};

        let mut instr = String::new();
        while !input.is_empty() {
            if input.parse::<Token![,]>().is_ok() {
                break;
            }
            if let Ok(ident) = syn::Ident::parse_any(input) {
                instr.push_str(&ident.to_string());
                continue;
            }
            if input.parse::<Token![.]>().is_ok() {
                instr.push('.');
                continue;
            }
            if let Ok(s) = input.parse::<syn::LitStr>() {
                instr.push_str(&s.value());
                continue;
            }
            println!("{:?}", input.cursor().token_stream());
            return Err(input.error("expected an instruction"));
        }
        if instr.is_empty() {
            return Err(input.error("expected an instruction before comma"));
        }
        let mut args = Vec::new();
        while !input.is_empty() {
            let name = input.parse::<syn::Ident>()?;
            input.parse::<Token![=]>()?;
            let expr = input.parse::<syn::Expr>()?;
            args.push((name, expr));

            if input.parse::<Token![,]>().is_err() {
                if !input.is_empty() {
                    return Err(input.error("extra tokens at end"));
                }
                break;
            }
        }
        Ok(Self { instr, args })
    }
}

struct Append<T>(T);

impl<T> quote::ToTokens for Append<T>
where
    T: Clone + IntoIterator,
    T::Item: quote::ToTokens,
{
    fn to_tokens(&self, tokens: &mut proc_macro2::TokenStream) {
        for item in self.0.clone() {
            item.to_tokens(tokens);
        }
    }
}