# Stdarch में योगदान

`stdarch` crate योगदान स्वीकार करने के लिए तैयार है!सबसे पहले आप शायद भंडार को देखना चाहेंगे और सुनिश्चित करेंगे कि परीक्षण आपके लिए पास हो जाएं:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

जहां `<your-target-arch>` लक्ष्य ट्रिपल है जैसा कि `rustup` द्वारा उपयोग किया जाता है, उदाहरण के लिए `x86_x64-unknown-linux-gnu` (बिना किसी पूर्ववर्ती `nightly-` या समान)।
यह भी याद रखें कि इस भंडार को Rust के रात्रिकालीन चैनल की आवश्यकता है!
उपरोक्त परीक्षणों में वास्तव में आपके सिस्टम पर डिफ़ॉल्ट होने के लिए रात में rust की आवश्यकता होती है, जो कि `rustup default nightly` (और `rustup default stable` को वापस करने के लिए) का उपयोग करने के लिए सेट करता है।

यदि उपरोक्त में से कोई भी चरण काम नहीं करता है, [please let us know][new]!

आगे आप मदद करने के लिए [find an issue][issues] कर सकते हैं, हमने [`help wanted`][help] और [`impl-period`][impl] टैग के साथ कुछ का चयन किया है जो विशेष रूप से कुछ मदद का उपयोग कर सकते हैं। 
आपको [#40][vendor] में सबसे अधिक दिलचस्पी हो सकती है, x86 पर सभी विक्रेता इंट्रिनिक्स को लागू करना।उस मुद्दे को कुछ अच्छे संकेत मिले हैं कि कहां से शुरू किया जाए!

यदि आपके पास सामान्य प्रश्न हैं, तो बेझिझक [join us on gitter][gitter] पर पूछें और पूछें!प्रश्नों के साथ@BurntSushi या@alexcrichton को पिंग करने के लिए स्वतंत्र महसूस करें।

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# स्टैडार्च इंट्रिनिक्स के लिए उदाहरण कैसे लिखें

कुछ विशेषताएं हैं जिन्हें दिए गए आंतरिक के ठीक से काम करने के लिए सक्षम किया जाना चाहिए और उदाहरण केवल `cargo test --doc` द्वारा चलाया जाना चाहिए जब सुविधा सीपीयू द्वारा समर्थित हो।

परिणामस्वरूप, डिफ़ॉल्ट `fn main` जो `rustdoc` द्वारा उत्पन्न होता है, काम नहीं करेगा (ज्यादातर मामलों में)।
यह सुनिश्चित करने के लिए कि आपका उदाहरण अपेक्षित रूप से काम करता है, एक गाइड के रूप में निम्नलिखित का उपयोग करने पर विचार करें।

```rust
/// # // केवल उदाहरण सुनिश्चित करने के लिए हमें cfg_target_feature की आवश्यकता है
/// # // `cargo test --doc` द्वारा चलाया जाता है जब CPU सुविधा का समर्थन करता है
/// # #![feature(cfg_target_feature)]
/// # // आंतरिक काम करने के लिए हमें target_feature की आवश्यकता है
/// # #![feature(target_feature)]
/// #
/// # // रस्टडॉक डिफ़ॉल्ट रूप से `extern crate stdarch` का उपयोग करता है, लेकिन हमें इसकी आवश्यकता है
/// # // `#[macro_use]`
/// # # [macro_use] बाहरी crat stdarch;
/// #
/// # // वास्तविक मुख्य कार्य
/// # एफएन main() {
/// #     // इसे केवल तभी चलाएं जब `<target feature>` समर्थित हो
/// #     अगर cfg_feature_enabled!("<target feature>"){
/// #         // एक `worker` फ़ंक्शन बनाएं जो केवल लक्ष्य विशेषता होने पर ही चलाया जाएगा
/// #         // समर्थित है और सुनिश्चित करें कि आपके कार्यकर्ता के लिए `target_feature` सक्षम है
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         असुरक्षित fn worker() {
/// // अपना उदाहरण यहाँ लिखें।फ़ीचर विशिष्ट इंट्रिनिक्स यहां काम करेंगे!जंगली बनो!
///
/// #         }
///
/// #         असुरक्षित { worker(); }
/// #     }
/// # }
```

यदि उपरोक्त में से कुछ सिंटैक्स परिचित नहीं लगते हैं, तो [Rust Book] का [Documentation as tests] अनुभाग `rustdoc` सिंटैक्स का अच्छी तरह से वर्णन करता है।
हमेशा की तरह, [join us on gitter][gitter] पर बेझिझक संपर्क करें और हमसे पूछें कि क्या आपको कोई गड़बड़ी हुई है, और `stdarch` के दस्तावेज़ीकरण को बेहतर बनाने में मदद करने के लिए धन्यवाद!

# वैकल्पिक परीक्षण निर्देश

आमतौर पर यह अनुशंसा की जाती है कि आप परीक्षण चलाने के लिए `ci/run.sh` का उपयोग करें।
हालाँकि यह आपके लिए काम नहीं कर सकता है, उदाहरण के लिए यदि आप Windows पर हैं।

उस स्थिति में आप कोड जनरेशन के परीक्षण के लिए `cargo +nightly test` और `cargo +nightly test --release -p core_arch` चलाने के लिए वापस आ सकते हैं।
ध्यान दें कि इन्हें रात्रिकालीन टूलचेन स्थापित करने की आवश्यकता होती है और `rustc` को आपके लक्ष्य ट्रिपल और उसके सीपीयू के बारे में जानने की आवश्यकता होती है।
विशेष रूप से आपको `TARGET` पर्यावरण चर सेट करने की आवश्यकता है जैसा कि आप `ci/run.sh` के लिए करेंगे।
इसके अलावा आपको लक्ष्य सुविधाओं को इंगित करने के लिए `RUSTCFLAGS` (`C` की आवश्यकता है) सेट करने की आवश्यकता है, उदाहरण के लिए `RUSTCFLAGS="-C -target-features=+avx2"`.
यदि आप अपने वर्तमान CPU के विरुद्ध "just" विकसित कर रहे हैं तो आप `-C -target-cpu=native` भी सेट कर सकते हैं।

सावधान रहें कि जब आप इन वैकल्पिक निर्देशों का उपयोग करते हैं, तो [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], उदा
निर्देश निर्माण परीक्षण विफल हो सकते हैं क्योंकि डिस्सेबलर ने उन्हें अलग नाम दिया है, उदाहरण के लिए
यह उनके समान व्यवहार करने के बावजूद `aesenc` निर्देशों के बजाय `vaesenc` उत्पन्न कर सकता है।
साथ ही ये निर्देश सामान्य से कम परीक्षण निष्पादित करते हैं, इसलिए आश्चर्यचकित न हों कि जब आप अंततः पुल-अनुरोध करते हैं तो यहां शामिल नहीं किए गए परीक्षणों के लिए कुछ त्रुटियां दिखाई दे सकती हैं।

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






