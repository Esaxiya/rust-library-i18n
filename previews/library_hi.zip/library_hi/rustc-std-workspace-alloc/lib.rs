#![feature(no_core)]
#![no_core]

// इस crate की आवश्यकता क्यों है, इसके लिए rustc-std-workspace-core देखें।

// liballoc में आवंटन मॉड्यूल के साथ विरोध से बचने के लिए crate का नाम बदलें।
extern crate alloc as foo;

pub use foo::*;