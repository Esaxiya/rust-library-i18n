use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // तीसरे पक्ष के आवंटकों और `RawVec` के बीच एकीकरण का परीक्षण लिखना थोड़ा मुश्किल है क्योंकि `RawVec` एपीआई गलत आवंटन विधियों को उजागर नहीं करता है, इसलिए हम जांच नहीं कर सकते कि क्या होता है जब आवंटक समाप्त हो जाता है (panic का पता लगाने से परे)।
    //
    //
    // इसके बजाए, यह केवल जांचता है कि एक्स 00 एक्स विधियां कम से कम एलोकेटर एपीआई से गुजरती हैं जब यह भंडारण आरक्षित करती है।
    //
    //
    //
    //
    //

    // एक गूंगा आवंटनकर्ता जो आवंटन प्रयास विफल होने से पहले एक निश्चित मात्रा में ईंधन की खपत करता है।
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (एक वास्तविक आवंटन का कारण बनता है, इस प्रकार ५० + १५०=२०० यूनिट ईंधन का उपयोग करना)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // सबसे पहले, `reserve` `reserve_exact` की तरह आवंटित करता है।
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97, 7 के दोगुने से अधिक है, इसलिए `reserve` को `reserve_exact` की तरह काम करना चाहिए।
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3, 12 के आधे से भी कम है, इसलिए `reserve` को तेजी से बढ़ना चाहिए।
        // लिखने के समय यह टेस्ट ग्रो फैक्टर 2 है, इसलिए नई क्षमता 24 है, हालांकि, 1.5 का ग्रो फैक्टर भी ठीक है।
        //
        // इसलिए `>= 18` जोर से।
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}