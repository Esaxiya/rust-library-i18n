//! मेमोरी आवंटन एपीआई

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // वैश्विक आवंटनकर्ता को कॉल करने के लिए ये जादू के प्रतीक हैं।rustc उन्हें `__rg_alloc` आदि कॉल करने के लिए उत्पन्न करता है।
    // यदि कोई `#[global_allocator]` विशेषता है (उस विशेषता मैक्रो का विस्तार करने वाला कोड उन कार्यों को उत्पन्न करता है), या libstd (`__rdl_alloc` आदि) में डिफ़ॉल्ट कार्यान्वयन को कॉल करने के लिए।
    //
    // `library/std/src/alloc.rs` में) अन्यथा।
    // LLVM का rustc fork भी इन फ़ंक्शन नामों को विशेष मामलों में क्रमशः `malloc`, `realloc` और `free` की तरह अनुकूलित करने में सक्षम होने के लिए सक्षम करता है।
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// वैश्विक स्मृति आवंटनकर्ता।
///
/// यह प्रकार [`Allocator`] trait को `#[global_allocator]` विशेषता के साथ पंजीकृत आवंटक को कॉल अग्रेषित करके लागू करता है यदि कोई है, या `std` crate का डिफ़ॉल्ट है।
///
///
/// Note: जबकि यह प्रकार अस्थिर है, इसके द्वारा प्रदान की जाने वाली कार्यक्षमता को [free functions in `alloc`](self#functions) के माध्यम से एक्सेस किया जा सकता है।
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// वैश्विक आवंटनकर्ता के साथ स्मृति आवंटित करें।
///
/// यह फ़ंक्शन `#[global_allocator]` विशेषता के साथ पंजीकृत आवंटक की [`GlobalAlloc::alloc`] विधि को कॉल करता है यदि कोई एक है, या `std` crate का डिफ़ॉल्ट है।
///
///
/// जब यह और [`Allocator`] trait स्थिर हो जाते हैं, तो यह फ़ंक्शन [`Global`] प्रकार की `alloc` विधि के पक्ष में बहिष्कृत होने की उम्मीद है।
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] देखें।
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// वैश्विक आवंटनकर्ता के साथ स्मृति को हटा दें।
///
/// यह फ़ंक्शन `#[global_allocator]` विशेषता के साथ पंजीकृत आवंटक की [`GlobalAlloc::dealloc`] विधि को कॉल करता है यदि कोई एक है, या `std` crate का डिफ़ॉल्ट है।
///
///
/// जब यह और [`Allocator`] trait स्थिर हो जाते हैं, तो यह फ़ंक्शन [`Global`] प्रकार की `dealloc` विधि के पक्ष में बहिष्कृत होने की उम्मीद है।
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] देखें।
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// वैश्विक आवंटनकर्ता के साथ स्मृति को पुन: आवंटित करें।
///
/// यह फ़ंक्शन `#[global_allocator]` विशेषता के साथ पंजीकृत आवंटक की [`GlobalAlloc::realloc`] विधि को कॉल करता है यदि कोई एक है, या `std` crate का डिफ़ॉल्ट है।
///
///
/// जब यह और [`Allocator`] trait स्थिर हो जाते हैं, तो यह फ़ंक्शन [`Global`] प्रकार की `realloc` विधि के पक्ष में बहिष्कृत होने की उम्मीद है।
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] देखें।
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// वैश्विक आवंटनकर्ता के साथ शून्य-प्रारंभिक स्मृति आवंटित करें।
///
/// यह फ़ंक्शन `#[global_allocator]` विशेषता के साथ पंजीकृत आवंटक की [`GlobalAlloc::alloc_zeroed`] विधि को कॉल करता है यदि कोई एक है, या `std` crate का डिफ़ॉल्ट है।
///
///
/// जब यह और [`Allocator`] trait स्थिर हो जाते हैं, तो यह फ़ंक्शन [`Global`] प्रकार की `alloc_zeroed` विधि के पक्ष में बहिष्कृत होने की उम्मीद है।
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] देखें।
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // सुरक्षा: `layout` आकार में गैर-शून्य है,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // सुरक्षा: `Allocator::grow` के समान
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // सुरक्षा: `new_size` गैर-शून्य है क्योंकि `old_size`, `new_size` से बड़ा या उसके बराबर है
            // सुरक्षा शर्तों के अनुसार आवश्यक है।कॉलर द्वारा अन्य शर्तों को बरकरार रखा जाना चाहिए
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` शायद `new_size >= old_layout.size()` या कुछ इसी तरह की जांच करता है।
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // सुरक्षा: क्योंकि `new_layout.size()`, `old_size` से बड़ा या उसके बराबर होना चाहिए,
            // दोनों पुराने और नए मेमोरी आवंटन `old_size` बाइट्स के लिए पढ़ने और लिखने के लिए मान्य हैं।
            // साथ ही, क्योंकि पुराने आवंटन को अभी तक डिलीकेट नहीं किया गया था, यह `new_ptr` को ओवरलैप नहीं कर सकता है।
            // इस प्रकार, `copy_nonoverlapping` पर कॉल सुरक्षित है।
            // `dealloc` के सुरक्षा अनुबंध को कॉलर द्वारा बरकरार रखा जाना चाहिए।
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // सुरक्षा: `layout` आकार में गैर-शून्य है,
            // कॉलर द्वारा अन्य शर्तों को बरकरार रखा जाना चाहिए
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // सुरक्षा: कॉलर द्वारा सभी शर्तों का पालन किया जाना चाहिए
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // सुरक्षा: कॉलर द्वारा सभी शर्तों का पालन किया जाना चाहिए
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // सुरक्षा: कॉलर द्वारा शर्तों को बरकरार रखा जाना चाहिए
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // सुरक्षा: `new_size` गैर-शून्य है।कॉलर द्वारा अन्य शर्तों को बरकरार रखा जाना चाहिए
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` शायद `new_size <= old_layout.size()` या कुछ इसी तरह की जांच करता है।
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // सुरक्षा: क्योंकि `new_size`, `old_layout.size()` से छोटा या उसके बराबर होना चाहिए,
            // दोनों पुराने और नए मेमोरी आवंटन `new_size` बाइट्स के लिए पढ़ने और लिखने के लिए मान्य हैं।
            // साथ ही, क्योंकि पुराने आवंटन को अभी तक डिलीकेट नहीं किया गया था, यह `new_ptr` को ओवरलैप नहीं कर सकता है।
            // इस प्रकार, `copy_nonoverlapping` पर कॉल सुरक्षित है।
            // `dealloc` के सुरक्षा अनुबंध को कॉलर द्वारा बरकरार रखा जाना चाहिए।
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// अद्वितीय पॉइंटर्स के लिए आवंटक।
// इस समारोह को खोलना नहीं चाहिए।यदि ऐसा होता है, तो एमआईआर कोडजन विफल हो जाएगा।
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// यह हस्ताक्षर `Box` के समान होना चाहिए, अन्यथा एक ICE हो जाएगा।
// जब `Box` में एक अतिरिक्त पैरामीटर जोड़ा जाता है (जैसे `A: Allocator`), तो इसे यहां भी जोड़ा जाना चाहिए।
// उदाहरण के लिए यदि `Box` को `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` में बदला जाता है, तो इस फ़ंक्शन को `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` में भी बदलना होगा।
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # आवंटन त्रुटि हैंडलर

extern "Rust" {
    // वैश्विक आवंटन त्रुटि हैंडलर को कॉल करने के लिए यह जादू का प्रतीक है।
    // rustc `#[alloc_error_handler]` होने पर `__rg_oom` को कॉल करने के लिए या अन्यथा (`__rdl_oom`) के नीचे डिफ़ॉल्ट कार्यान्वयन को कॉल करने के लिए इसे उत्पन्न करता है।
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// स्मृति आवंटन त्रुटि या विफलता पर निरस्त करें।
///
/// मेमोरी आवंटन एपीआई के कॉलर्स जो आवंटन त्रुटि के जवाब में गणना को रद्द करना चाहते हैं, उन्हें सीधे `panic!` या इसी तरह का आह्वान करने के बजाय इस फ़ंक्शन को कॉल करने के लिए प्रोत्साहित किया जाता है।
///
///
/// इस फ़ंक्शन का डिफ़ॉल्ट व्यवहार मानक त्रुटि के लिए एक संदेश मुद्रित करना और प्रक्रिया को निरस्त करना है।
/// इसे [`set_alloc_error_hook`] और [`take_alloc_error_hook`] से बदला जा सकता है।
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// आवंटन परीक्षण के लिए `std::alloc::handle_alloc_error` सीधे इस्तेमाल किया जा सकता है।
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // उत्पन्न `__rust_alloc_error_handler`. के माध्यम से कॉल किया गया

    // अगर कोई `#[alloc_error_handler]` नहीं है
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // अगर कोई `#[alloc_error_handler]`. है
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// क्लोनों को पूर्व-आवंटित, अप्रारंभीकृत स्मृति में विशेषज्ञता दें।
/// `Box::clone` और `Rc`/`Arc::make_mut` द्वारा उपयोग किया जाता है।
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // आवंटित होने के बाद *पहले* ऑप्टिमाइज़र को स्थानीय को छोड़कर और स्थानांतरित करने के लिए जगह में क्लोन मूल्य बनाने की अनुमति मिल सकती है।
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // हम स्थानीय मूल्य को शामिल किए बिना, हमेशा जगह में कॉपी कर सकते हैं।
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}