//! यूनिकोड स्ट्रिंग स्लाइस।
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` प्रकार दो मुख्य स्ट्रिंग प्रकारों में से एक है, दूसरा `String` है।
//! अपने `String` समकक्ष के विपरीत, इसकी सामग्री उधार ली गई है।
//!
//! # मूल उपयोग
//!
//! `&str` प्रकार की एक मूल स्ट्रिंग घोषणा:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! यहां हमने एक स्ट्रिंग शाब्दिक घोषित किया है, जिसे स्ट्रिंग स्लाइस के रूप में भी जाना जाता है।
//! स्ट्रिंग अक्षर का एक स्थिर जीवनकाल होता है, जिसका अर्थ है कि स्ट्रिंग `hello_world` पूरे कार्यक्रम की अवधि के लिए वैध होने की गारंटी है।
//!
//! हम `hello_world` के जीवनकाल को भी स्पष्ट रूप से निर्दिष्ट कर सकते हैं:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// इस मॉड्यूल में कई प्रयोग केवल परीक्षण विन्यास में उपयोग किए जाते हैं।
// unused_imports चेतावनी को ठीक करने के बजाय उसे बंद करना अधिक आसान है।
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `Concat<str>` में `str` यहाँ अर्थपूर्ण नहीं है।
/// trait का यह प्रकार पैरामीटर केवल एक और इम्प्लांट को सक्षम करने के लिए मौजूद है।
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // हार्डकोडेड आकार वाले लूप बहुत तेजी से चलते हैं, छोटे विभाजक लंबाई वाले मामलों को विशेषज्ञ बनाते हैं
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // मनमाना गैर-शून्य आकार फ़ॉलबैक
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// ऑप्टिमाइज़्ड जॉइन इंप्लीमेंटेशन जो Vec. दोनों के लिए काम करता है<T>(टी: कॉपी) और स्ट्रिंग की आंतरिक वीसी वर्तमान में (2018-05-13) प्रकार के अनुमान और विशेषज्ञता के साथ एक बग है (इस मुद्दे को देखें #36262) इस कारण से SliceConcat<T>T: Copy और SliceConcat के लिए विशिष्ट नहीं है<str>इस फ़ंक्शन का एकमात्र उपयोगकर्ता है।
// इसे उस समय के लिए छोड़ दिया जाता है जब यह तय हो जाता है।
//
// स्ट्रिंग-जॉइन की सीमाएं एस हैं: उधार लें<str>और कुछ टी के लिए Vec-join Borrow<[T]> [T] और str दोनों impl AsRef<[T]> के लिए
// => s.borrow().as_ref() और हमारे पास हमेशा स्लाइस होते हैं
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // पहला टुकड़ा केवल एक ही है जिसके पहले कोई विभाजक नहीं है
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // शामिल Vec की सटीक कुल लंबाई की गणना करें यदि `len` गणना ओवरफ्लो हो जाती है, तो हम panic करेंगे, हम वैसे भी स्मृति से बाहर हो जाएंगे और शेष फ़ंक्शन को सुरक्षा के लिए पूर्व-आवंटित संपूर्ण Vec की आवश्यकता होगी
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // एक प्रारंभिक बफर तैयार करें
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // कॉपी सेपरेटर और स्लाइस ओवर बाउंड बाउंड चेक छोटे विभाजकों के लिए हार्डकोडेड ऑफ़सेट के साथ लूप उत्पन्न करते हैं बड़े पैमाने पर सुधार संभव (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // एक अजीब उधार कार्यान्वयन लंबाई गणना और वास्तविक प्रति के लिए अलग-अलग स्लाइस लौटा सकता है।
        //
        // सुनिश्चित करें कि हम कॉलर को अप्रारंभीकृत बाइट्स का खुलासा नहीं करते हैं।
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// स्ट्रिंग स्लाइस के लिए तरीके।
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// एक `Box<str>` को कॉपी या आवंटित किए बिना `Box<[u8]>` में कनवर्ट करता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// एक पैटर्न के सभी मैचों को दूसरी स्ट्रिंग से बदल देता है।
    ///
    /// `replace` एक नया [`String`] बनाता है, और इस स्ट्रिंग स्लाइस से डेटा को इसमें कॉपी करता है।
    /// ऐसा करते समय, यह एक पैटर्न के मेल खोजने का प्रयास करता है।
    /// यदि इसे कोई मिलता है, तो यह उन्हें प्रतिस्थापन स्ट्रिंग स्लाइस से बदल देता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// जब पैटर्न मेल नहीं खाता:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// किसी पैटर्न के पहले N मिलान को दूसरी स्ट्रिंग से बदलें।
    ///
    /// `replacen` एक नया [`String`] बनाता है, और इस स्ट्रिंग स्लाइस से डेटा को इसमें कॉपी करता है।
    /// ऐसा करते समय, यह एक पैटर्न के मेल खोजने का प्रयास करता है।
    /// यदि इसे कोई मिलता है, तो यह उन्हें अधिक से अधिक `count` बार प्रतिस्थापन स्ट्रिंग स्लाइस से बदल देता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// जब पैटर्न मेल नहीं खाता:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // पुन: आवंटन के समय को कम करने की आशा
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// एक नए [`String`] के रूप में, इस स्ट्रिंग स्लाइस के बराबर लोअरकेस देता है।
    ///
    /// 'Lowercase' यूनिकोड व्युत्पन्न कोर संपत्ति `Lowercase` की शर्तों के अनुसार परिभाषित किया गया है।
    ///
    /// चूंकि केस बदलते समय कुछ वर्ण कई वर्णों में विस्तारित हो सकते हैं, इसलिए यह फ़ंक्शन पैरामीटर को इन-प्लेस संशोधित करने के बजाय एक [`String`] देता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// सिग्मा के साथ एक मुश्किल उदाहरण:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // लेकिन एक शब्द के अंत में, यह है, नहीं:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// बिना किसी मामले के भाषाएं नहीं बदली जाती हैं:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // मैप्स टू Σ, एक शब्द के अंत को छोड़कर जहां यह के लिए मैप करता है।
                // यह एकमात्र सशर्त (contextual) है लेकिन `SpecialCasing.txt` में भाषा-स्वतंत्र मैपिंग है, इसलिए इसे सामान्य "condition" तंत्र के बजाय हार्ड-कोड करें।
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` की परिभाषा के लिए।
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// एक नए [`String`] के रूप में, इस स्ट्रिंग स्लाइस के बराबर अपरकेस देता है।
    ///
    /// 'Uppercase' यूनिकोड व्युत्पन्न कोर संपत्ति `Uppercase` की शर्तों के अनुसार परिभाषित किया गया है।
    ///
    /// चूंकि केस बदलते समय कुछ वर्ण कई वर्णों में विस्तारित हो सकते हैं, इसलिए यह फ़ंक्शन पैरामीटर को इन-प्लेस संशोधित करने के बजाय एक [`String`] देता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// मामले के बिना लिपियों को नहीं बदला जाता है:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// एक वर्ण एकाधिक बन सकता है:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// एक [`Box<str>`] को कॉपी या आवंटित किए बिना [`String`] में कनवर्ट करता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// एक स्ट्रिंग `n` बार दोहराकर एक नया [`String`] बनाता है।
    ///
    /// # Panics
    ///
    /// यदि क्षमता अतिप्रवाह होगी तो यह फ़ंक्शन panic होगा।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// अतिप्रवाह पर एक panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// इस स्ट्रिंग की एक प्रति देता है जहाँ प्रत्येक वर्ण को उसके ASCII अपर केस के बराबर मैप किया जाता है।
    ///
    ///
    /// ASCII अक्षर 'a' से 'z' को 'A' से 'Z' में मैप किया गया है, लेकिन गैर-ASCII अक्षर अपरिवर्तित हैं।
    ///
    /// इन-प्लेस मान को अपरकेस करने के लिए, [`make_ascii_uppercase`] का उपयोग करें।
    ///
    /// गैर-ASCII वर्णों के अलावा ASCII वर्णों को अपरकेस करने के लिए, [`to_uppercase`] का उपयोग करें।
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() UTF-8 अपरिवर्तनीय सुरक्षित रखता है।
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// इस स्ट्रिंग की एक प्रति देता है जहां प्रत्येक वर्ण को इसके ASCII लोअर केस समकक्ष में मैप किया जाता है।
    ///
    ///
    /// ASCII अक्षर 'A' से 'Z' को 'a' से 'z' में मैप किया गया है, लेकिन गैर-ASCII अक्षर अपरिवर्तित हैं।
    ///
    /// इन-प्लेस मान को कम करने के लिए, [`make_ascii_lowercase`] का उपयोग करें।
    ///
    /// गैर-ASCII वर्णों के अलावा ASCII वर्णों को छोटा करने के लिए, [`to_lowercase`] का उपयोग करें।
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() UTF-8 अपरिवर्तनीय सुरक्षित रखता है।
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// यह जाँचे बिना कि स्ट्रिंग में मान्य UTF-8 है, बाइट्स के बॉक्स किए गए स्लाइस को बॉक्सिंग स्ट्रिंग स्लाइस में कनवर्ट करता है।
///
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}