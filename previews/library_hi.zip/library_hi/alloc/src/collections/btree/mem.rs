use core::intrinsics;
use core::mem;
use core::ptr;

/// यह प्रासंगिक फ़ंक्शन को कॉल करके `v` अद्वितीय संदर्भ के पीछे के मान को बदल देता है।
///
///
/// यदि `change` बंद होने पर panic होता है, तो पूरी प्रक्रिया निरस्त कर दी जाएगी।
#[allow(dead_code)] // चित्रण के रूप में रखें और future उपयोग के लिए
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// यह प्रासंगिक फ़ंक्शन को कॉल करके `v` अद्वितीय संदर्भ के पीछे के मान को बदल देता है, और रास्ते में प्राप्त परिणाम देता है।
///
///
/// यदि `change` बंद होने पर panic होता है, तो पूरी प्रक्रिया निरस्त कर दी जाएगी।
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}