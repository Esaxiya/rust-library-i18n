use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// अस्थायी रूप से उसी श्रेणी के दूसरे, अपरिवर्तनीय समकक्ष को निकालता है।
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// एक पेड़ में एक निर्दिष्ट सीमा को परिसीमित करने वाले अलग पत्ते के किनारों को ढूँढता है।
    /// एक ही पेड़ या खाली विकल्पों की एक जोड़ी में अलग-अलग हैंडल की एक जोड़ी देता है।
    ///
    /// # Safety
    ///
    /// जब तक `BorrowType` `Immut` न हो, एक ही KV पर दो बार जाने के लिए डुप्लीकेट हैंडल का उपयोग न करें।
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// `(root1.first_leaf_edge(), root2.last_leaf_edge())` के बराबर लेकिन अधिक कुशल।
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// एक पेड़ में एक विशिष्ट श्रेणी का परिसीमन करने वाले पत्ती के किनारों की जोड़ी ढूँढता है।
    ///
    /// परिणाम तभी सार्थक होता है जब पेड़ को कुंजी द्वारा क्रमबद्ध किया जाता है, जैसे कि `BTreeMap` में पेड़ है।
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // सुरक्षा: हमारा उधार प्रकार अपरिवर्तनीय है।
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// एक पूरे पेड़ का परिसीमन करने वाले पत्ती के किनारों की जोड़ी ढूँढता है।
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// एक निर्दिष्ट सीमा को सीमित करने वाले पत्ते के किनारों की एक जोड़ी में एक अद्वितीय संदर्भ को विभाजित करता है।
    /// परिणाम गैर-अद्वितीय संदर्भ हैं जो (some) उत्परिवर्तन की अनुमति देते हैं, जिन्हें सावधानी से उपयोग किया जाना चाहिए।
    ///
    /// परिणाम तभी सार्थक होता है जब पेड़ को कुंजी द्वारा क्रमबद्ध किया जाता है, जैसे कि `BTreeMap` में पेड़ है।
    ///
    ///
    /// # Safety
    /// एक ही KV को दो बार देखने के लिए डुप्लीकेट हैंडल का उपयोग न करें।
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// पेड़ की पूरी श्रृंखला को सीमित करने वाले पत्ते के किनारों की एक जोड़ी में एक अद्वितीय संदर्भ को विभाजित करता है।
    /// परिणाम गैर-अद्वितीय संदर्भ हैं जो उत्परिवर्तन (केवल मूल्यों के) की अनुमति देते हैं, इसलिए सावधानी के साथ उपयोग किया जाना चाहिए।
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // हम यहां मूल NodeRef की नकल करते हैं-हम कभी भी एक ही KV पर दो बार नहीं जाएंगे, और कभी भी अतिव्यापी मूल्य संदर्भों के साथ समाप्त नहीं होंगे।
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// पेड़ की पूरी श्रृंखला को सीमित करने वाले पत्ते के किनारों की एक जोड़ी में एक अद्वितीय संदर्भ को विभाजित करता है।
    /// परिणाम गैर-अद्वितीय संदर्भ हैं जो बड़े पैमाने पर विनाशकारी उत्परिवर्तन की अनुमति देते हैं, इसलिए अत्यधिक सावधानी के साथ उपयोग किया जाना चाहिए।
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // हम यहां रूट NodeRef की नकल करते हैं-हम इसे कभी भी इस तरह से एक्सेस नहीं करेंगे जो रूट से प्राप्त संदर्भों को ओवरलैप करता है।
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// एक लीफ edge हैंडल को देखते हुए, [`Result::Ok`] को एक हैंडल के साथ पड़ोसी KV को दाईं ओर लौटाता है, जो या तो एक ही लीफ नोड में या एक पूर्वज नोड में होता है।
    ///
    /// यदि पत्ती edge पेड़ में अंतिम है, तो रूट नोड के साथ [`Result::Err`] लौटाता है।
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// एक लीफ edge हैंडल को देखते हुए, [`Result::Ok`] को एक हैंडल के साथ बाईं ओर पड़ोसी KV पर लौटाता है, जो या तो एक ही लीफ नोड में या एक पूर्वज नोड में होता है।
    ///
    /// यदि पत्ती edge पेड़ में पहला है, तो रूट नोड के साथ [`Result::Err`] लौटाता है।
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// एक आंतरिक edge हैंडल को देखते हुए, [`Result::Ok`] को एक हैंडल के साथ पड़ोसी KV को दाईं ओर लौटाता है, जो या तो एक ही आंतरिक नोड में या एक पूर्वज नोड में होता है।
    ///
    /// यदि आंतरिक edge ट्री में अंतिम है, तो रूट नोड के साथ [`Result::Err`] लौटाता है।
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// एक पत्ती edge हैंडल को एक मरते हुए पेड़ में देखते हुए, अगला पत्ता edge दाईं ओर देता है, और बीच में कुंजी-मूल्य जोड़ी, जो या तो एक ही पत्ती नोड में है, एक पूर्वज नोड में, या गैर-मौजूद है।
    ///
    ///
    /// यह विधि किसी भी node(s) को भी हटा देती है जिसके अंत तक यह पहुंचता है।
    /// इसका तात्पर्य यह है कि यदि कोई और कुंजी-मूल्य जोड़ी मौजूद नहीं है, तो पूरे शेष पेड़ को हटा दिया जाएगा और वापस लौटने के लिए कुछ भी नहीं बचा है।
    ///
    /// # Safety
    /// दिया गया edge पहले समकक्ष `deallocating_next_back` द्वारा वापस नहीं किया गया होगा।
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// एक पत्ती edge हैंडल को एक मरते हुए पेड़ में देखते हुए, बाईं ओर अगला पत्ता edge देता है, और बीच में की-वैल्यू जोड़ी, जो या तो एक ही लीफ नोड में है, एक पूर्वज नोड में, या गैर-मौजूद है।
    ///
    ///
    /// यह विधि किसी भी node(s) को भी हटा देती है जिसके अंत तक यह पहुंचता है।
    /// इसका तात्पर्य यह है कि यदि कोई और कुंजी-मूल्य जोड़ी मौजूद नहीं है, तो पूरे शेष पेड़ को हटा दिया जाएगा और वापस लौटने के लिए कुछ भी नहीं बचा है।
    ///
    /// # Safety
    /// दिया गया edge पहले समकक्ष `deallocating_next` द्वारा वापस नहीं किया गया होगा।
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// पत्ती से जड़ तक गांठों के ढेर को हटा देता है।
    /// `deallocating_next` और `deallocating_next_back` के पेड़ के दोनों किनारों पर निबटने के बाद, और एक ही edge से टकराने के बाद शेष पेड़ को हटाने का यह एकमात्र तरीका है।
    /// चूंकि इसका उद्देश्य केवल तभी कॉल करना है जब सभी कुंजी और मान वापस कर दिए गए हों, किसी भी कुंजी या मान पर कोई सफाई नहीं की जाती है।
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// लीफ edge हैंडल को अगले लीफ edge पर ले जाता है और बीच में कुंजी और मान का संदर्भ देता है।
    ///
    ///
    /// # Safety
    /// यात्रा की दिशा में एक और केवी होना चाहिए।
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// लीफ edge हैंडल को पिछले लीफ edge पर ले जाता है और बीच में कुंजी और मान का संदर्भ देता है।
    ///
    ///
    /// # Safety
    /// यात्रा की दिशा में एक और केवी होना चाहिए।
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// लीफ edge हैंडल को अगले लीफ edge पर ले जाता है और बीच में कुंजी और मान का संदर्भ देता है।
    ///
    ///
    /// # Safety
    /// यात्रा की दिशा में एक और केवी होना चाहिए।
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // बेंचमार्क के अनुसार इसे अंतिम करना तेज है।
        kv.into_kv_valmut()
    }

    /// लीफ edge हैंडल को पिछले लीफ पर ले जाता है और बीच में कुंजी और मान के संदर्भ देता है।
    ///
    ///
    /// # Safety
    /// यात्रा की दिशा में एक और केवी होना चाहिए।
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // बेंचमार्क के अनुसार इसे अंतिम करना तेज है।
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// लीफ edge हैंडल को अगले लीफ edge पर ले जाता है और बीच में कुंजी और मान लौटाता है, किसी भी नोड को पीछे छोड़ते हुए संबंधित edge को उसके मूल नोड में छोड़ देता है।
    ///
    /// # Safety
    /// - यात्रा की दिशा में एक और केवी होना चाहिए।
    /// - उस KV को पहले समकक्ष `next_back_unchecked` द्वारा पेड़ को पार करने के लिए उपयोग किए जा रहे हैंडल की किसी भी प्रति पर वापस नहीं किया गया था।
    ///
    /// अपडेट किए गए हैंडल के साथ आगे बढ़ने का एकमात्र सुरक्षित तरीका इसकी तुलना करना, इसे छोड़ना, इस विधि को फिर से इसकी सुरक्षा शर्तों के अधीन कॉल करना, या समकक्ष `next_back_unchecked` को इसकी सुरक्षा शर्तों के अधीन कॉल करना है।
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// लीफ edge हैंडल को पिछले लीफ edge पर ले जाता है और बीच में कुंजी और मान लौटाता है, किसी भी नोड को पीछे छोड़ते हुए संबंधित edge को उसके मूल नोड में छोड़ देता है।
    ///
    /// # Safety
    /// - यात्रा की दिशा में एक और केवी होना चाहिए।
    /// - वह पत्ता edge पहले समकक्ष `next_unchecked` द्वारा पेड़ को पार करने के लिए उपयोग किए जा रहे हैंडल की किसी भी प्रति पर वापस नहीं किया गया था।
    ///
    /// अपडेट किए गए हैंडल के साथ आगे बढ़ने का एकमात्र सुरक्षित तरीका इसकी तुलना करना, इसे छोड़ना, इस विधि को फिर से इसकी सुरक्षा शर्तों के अधीन कॉल करना, या समकक्ष `next_unchecked` को इसकी सुरक्षा शर्तों के अधीन कॉल करना है।
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// नोड में या उसके नीचे सबसे बाईं ओर का पत्ता edge लौटाता है, दूसरे शब्दों में, edge आपको आगे नेविगेट करते समय सबसे पहले चाहिए (या पीछे की ओर नेविगेट करते समय अंतिम)।
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// नोड में या उसके नीचे सबसे दाहिना पत्ता edge लौटाता है, दूसरे शब्दों में, edge जिसे आपको आगे नेविगेट करते समय अंतिम की आवश्यकता होती है (या पहले पीछे की ओर नेविगेट करते समय)।
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// आरोही कुंजियों के क्रम में लीफ नोड्स और आंतरिक केवी का दौरा करता है, और आंतरिक नोड्स को गहराई से पहले क्रम में भी देखता है, जिसका अर्थ है कि आंतरिक नोड्स उनके व्यक्तिगत केवी और उनके बच्चे नोड्स से पहले होते हैं।
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// एक (उप) ट्री में तत्वों की संख्या की गणना करता है।
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// आगे के नेविगेशन के लिए KV के निकटतम edge लीफ लौटाता है।
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// पश्चगामी नेविगेशन के लिए KV के निकटतम edge लीफ लौटाता है।
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}