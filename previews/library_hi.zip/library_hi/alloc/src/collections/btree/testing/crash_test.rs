use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// क्रैश टेस्ट डमी इंस्टेंस के लिए एक ब्लूप्रिंट जो विशेष घटनाओं की निगरानी करता है।
/// कुछ उदाहरणों को किसी बिंदु पर panic में कॉन्फ़िगर किया जा सकता है।
/// ईवेंट `clone`, `drop` या कुछ अनाम `query` हैं।
///
/// क्रैश टेस्ट डमी को एक आईडी द्वारा पहचाना और ऑर्डर किया जाता है, इसलिए उन्हें BTreeMap में चाबियों के रूप में उपयोग किया जा सकता है।
/// कार्यान्वयन जानबूझकर उपयोग करता है, `Debug` trait के अलावा crate में परिभाषित किसी भी चीज़ पर निर्भर नहीं करता है।
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// क्रैश टेस्ट डमी डिज़ाइन बनाता है।`id` उदाहरणों के क्रम और समानता को निर्धारित करता है।
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// क्रैश टेस्ट डमी का एक उदाहरण बनाता है जो रिकॉर्ड करता है कि वह किन घटनाओं का अनुभव करता है और वैकल्पिक रूप से panics।
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// लौटाता है कि कितनी बार डमी के उदाहरणों का क्लोन बनाया गया है।
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// यह लौटाता है कि कितनी बार डमी के उदाहरण छोड़े गए हैं।
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// यह लौटाता है कि डमी के उदाहरणों ने कितनी बार अपने `query` सदस्य को बुलाया है।
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// कुछ गुमनाम क्वेरी, जिसका परिणाम पहले ही दिया जा चुका है।
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}