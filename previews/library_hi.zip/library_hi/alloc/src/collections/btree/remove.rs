use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// पेड़ से एक कुंजी-मूल्य जोड़ी को हटाता है, और उस जोड़ी को लौटाता है, साथ ही साथ उस पूर्व जोड़ी से संबंधित पत्ता edge भी देता है।
    /// यह संभव है कि यह एक रूट नोड को खाली कर देता है जो आंतरिक है, जिसे कॉलर को पेड़ को पकड़े हुए मानचित्र से पॉप करना चाहिए।
    /// कॉलर को मानचित्र की लंबाई भी घटानी चाहिए।
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // हमें अस्थायी रूप से बच्चे के प्रकार को भूलना होगा, क्योंकि पत्ती के तत्काल माता-पिता के लिए कोई विशिष्ट नोड प्रकार नहीं है।
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // सुरक्षा: `new_pos` वह पत्ता है जिसे हमने या एक भाई से शुरू किया था।
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // केवल अगर हम विलय करते हैं, तो माता-पिता (यदि कोई हो) सिकुड़ गया है, लेकिन निम्न चरण को छोड़ देना अन्यथा बेंचमार्क में भुगतान नहीं करता है।
            //
            // सुरक्षा: हम उस पत्ते को नष्ट या पुनर्व्यवस्थित नहीं करेंगे जहां `pos` है
            // अपने माता-पिता को पुनरावर्ती रूप से संभालकर;कम से कम हम दादा-दादी के माध्यम से माता-पिता को नष्ट या पुनर्व्यवस्थित करेंगे, इस प्रकार पत्ते के अंदर माता-पिता के लिंक को बदल देंगे।
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // एक आसन्न केवी को उसके पत्ते से हटा दें और फिर उसे उस तत्व के स्थान पर वापस रख दें जिसे हमें हटाने के लिए कहा गया था।
        //
        // `choose_parent_kv` में सूचीबद्ध कारणों के लिए बाएँ आसन्न KV को प्राथमिकता दें।
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // आंतरिक नोड चोरी या विलय हो सकता है।
        // मूल KV कहाँ समाप्त हुआ, यह जानने के लिए वापस जाएँ।
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}