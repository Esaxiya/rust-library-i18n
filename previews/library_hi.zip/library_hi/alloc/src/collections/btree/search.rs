use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// देखने के लिए एक समावेशी बाध्य, ठीक `Bound::Included(T)` की तरह।
    Included(T),
    /// देखने के लिए एक विशेष बाध्य, बिल्कुल `Bound::Excluded(T)` की तरह।
    Excluded(T),
    /// एक बिना शर्त समावेशी बाध्य, ठीक `Bound::Unbounded` की तरह।
    AllIncluded,
    /// एक बिना शर्त अनन्य बाध्य।
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// नोड के नेतृत्व में एक (उप) पेड़ में दी गई कुंजी को पुनरावर्ती रूप से देखता है।
    /// मिलान KV के हैंडल के साथ एक `Found` लौटाता है, यदि कोई हो।
    /// अन्यथा, edge पत्ती के हैंडल के साथ एक `GoDown` लौटाता है जहां कुंजी है।
    ///
    /// परिणाम तभी सार्थक होता है जब पेड़ को कुंजी द्वारा क्रमबद्ध किया जाता है, जैसे कि `BTreeMap` में पेड़ है।
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// निकटतम नोड पर उतरता है जहां edge रेंज के निचले बाउंड से मेल खाता है edge ऊपरी बाउंड से मेल खाता है, यानी, निकटतम नोड जिसमें रेंज में कम से कम एक कुंजी निहित है।
    ///
    ///
    /// यदि पाया जाता है, तो उस नोड के साथ एक `Ok` लौटाता है, इसमें edge सूचकांकों की जोड़ी सीमा का परिसीमन करती है, और नोड के आंतरिक होने की स्थिति में चाइल्ड नोड्स में खोज जारी रखने के लिए संबंधित जोड़ी की सीमा।
    ///
    /// यदि नहीं मिला, तो एक `Err` लौटाता है जिसमें पत्ती edge पूरी श्रेणी से मेल खाती है।
    ///
    /// परिणाम तभी सार्थक होता है जब पेड़ को कुंजी द्वारा आदेश दिया जाता है।
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // इन चरों को रेखांकित करने से बचा जाना चाहिए।
        // हम मानते हैं कि `range` द्वारा रिपोर्ट की गई सीमाएं वही रहती हैं, लेकिन कॉल (#81138) के बीच एक प्रतिकूल कार्यान्वयन बदल सकता है।
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// किसी श्रेणी की निचली सीमा को परिसीमित करने वाले नोड में edge ढूँढता है।
    /// यदि `self` एक आंतरिक नोड है, तो मिलान करने वाले चाइल्ड नोड में खोज जारी रखने के लिए उपयोग की जाने वाली निचली बाउंड भी लौटाता है।
    ///
    ///
    /// परिणाम तभी सार्थक होता है जब पेड़ को कुंजी द्वारा आदेश दिया जाता है।
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// ऊपरी सीमा के लिए `find_lower_bound_edge` का क्लोन।
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// पुनरावर्तन के बिना, नोड में दी गई कुंजी को देखता है।
    /// मिलान KV के हैंडल के साथ एक `Found` लौटाता है, यदि कोई हो।
    /// अन्यथा, edge के हैंडल के साथ एक `GoDown` लौटाता है जहां कुंजी मिल सकती है (यदि नोड आंतरिक है) या जहां कुंजी डाली जा सकती है।
    ///
    ///
    /// परिणाम तभी सार्थक होता है जब पेड़ को कुंजी द्वारा क्रमबद्ध किया जाता है, जैसे कि `BTreeMap` में पेड़ है।
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// नोड में या तो केवी इंडेक्स देता है जिस पर कुंजी (या समकक्ष) मौजूद है, या edge इंडेक्स जहां कुंजी संबंधित है।
    ///
    ///
    /// परिणाम तभी सार्थक होता है जब पेड़ को कुंजी द्वारा क्रमबद्ध किया जाता है, जैसे कि `BTreeMap` में पेड़ है।
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// नोड में एक edge इंडेक्स ढूँढता है जो किसी श्रेणी की निचली सीमा को परिसीमित करता है।
    /// यदि `self` एक आंतरिक नोड है, तो मिलान करने वाले चाइल्ड नोड में खोज जारी रखने के लिए उपयोग की जाने वाली निचली बाउंड भी लौटाता है।
    ///
    ///
    /// परिणाम तभी सार्थक होता है जब पेड़ को कुंजी द्वारा आदेश दिया जाता है।
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// ऊपरी सीमा के लिए `find_lower_bound_index` का क्लोन।
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}