use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// एक पुनरावर्तक का कोर जो दो सख्ती से आरोही पुनरावृत्तियों के आउटपुट को मर्ज करता है, उदाहरण के लिए एक संघ या एक सममित अंतर।
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// पीकेबल में दोनों इटरेटर्स को लपेटने की तुलना में बेंचमार्क तेजी से, शायद इसलिए कि हम एक फ्यूज्डइटरेटर बाउंड लगाने का जोखिम उठा सकते हैं।
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// स्रोतों की एक जोड़ी को मर्ज करने वाले पुनरावर्तक के लिए एक नया कोर बनाता है।
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// विलय किए जा रहे स्रोतों की जोड़ी से उत्पन्न होने वाली वस्तुओं की अगली जोड़ी देता है।
    /// यदि दोनों दिए गए विकल्पों में एक मान होता है, तो वह मान बराबर होता है और दोनों स्रोतों में होता है।
    /// यदि दिए गए विकल्पों में से एक में कोई मान होता है, तो वह मान दूसरे स्रोत में नहीं होता है (या स्रोत सख्ती से आरोही नहीं होते हैं)।
    ///
    /// यदि न तो लौटाए गए विकल्प में कोई मान है, तो पुनरावृत्ति समाप्त हो गई है और बाद की कॉल उसी खाली जोड़ी को वापस कर देगी।
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// अंतिम इटरेटर के `size_hint` के लिए ऊपरी सीमा की एक जोड़ी देता है।
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}