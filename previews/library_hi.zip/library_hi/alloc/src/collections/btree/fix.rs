use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// भाई-बहन के साथ विलय या चोरी करके संभावित रूप से कम पूर्ण नोड को स्टॉक करता है।
    /// यदि सफल हो लेकिन पैरेंट नोड को सिकोड़ने की कीमत पर, उस सिकुड़े हुए पैरेंट नोड को लौटाता है।
    /// यदि नोड एक खाली रूट है, तो `Err` लौटाता है।
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// संभावित रूप से कम पूर्ण नोड को स्टॉक करता है, और यदि वह अपने मूल नोड को कम करने का कारण बनता है, तो माता-पिता को पुनरावर्ती रूप से स्टॉक करता है।
    /// यदि यह पेड़ को ठीक करता है तो `true` लौटाता है, यदि रूट नोड खाली हो गया है तो `false` नहीं कर सकता है।
    ///
    /// यह विधि पूर्वजों को प्रवेश पर पहले से ही कम होने की उम्मीद नहीं करती है और panics अगर यह एक खाली पूर्वज का सामना करती है।
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// शीर्ष पर खाली स्तरों को हटा देता है, लेकिन यदि पूरा पेड़ खाली है तो एक खाली पत्ता रखता है।
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// पेड़ की दाहिनी सीमा पर किसी भी अंडरफुल नोड्स को स्टॉक या मर्ज करें।
    /// अन्य नोड्स, जो रूट नहीं हैं और न ही सबसे दाहिने edge हैं, उनमें पहले से ही कम से कम MIN_LEN तत्व होने चाहिए।
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// `fix_right_border` का सममित क्लोन।
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// पेड़ की दाहिनी सीमा पर किसी भी अंडरफुल नोड्स को स्टॉक करें।
    /// अन्य नोड्स, जो रूट नहीं हैं और न ही सबसे दाहिने edge, को MIN_LEN तत्वों तक चोरी होने के लिए तैयार रहना चाहिए।
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // जाँच करें कि क्या दाएँ-अधिकांश बच्चा कम भरा है।
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // हमें चोरी करनी है।
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // और नीचे जाओ।
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// बाएं बच्चे को स्टॉक करता है, यह मानते हुए कि दायां बच्चा कम नहीं है, और एक अतिरिक्त तत्व का प्रावधान करता है ताकि उसके बच्चों को बदले में बिना कम किए विलय कर दिया जा सके।
    ///
    /// बाएं बच्चे को लौटाता है।
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` अगले स्तर पर विलय होने पर पुन: समायोजन से बचने के लिए।
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// यह मानते हुए कि बायां बच्चा कम नहीं है, दाएं बच्चे को स्टॉक कर देता है, और एक अतिरिक्त तत्व का प्रावधान करता है ताकि उसके बच्चों को बिना कम भरे हुए विलय कर दिया जा सके।
    ///
    /// जहां भी सही बच्चा समाप्त होता है वहां वापस लौटता है।
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` अगले स्तर पर विलय होने पर पुन: समायोजन से बचने के लिए।
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}