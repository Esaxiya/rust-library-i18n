// यह आदर्श का पालन करते हुए एक कार्यान्वयन का प्रयास है
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// चूंकि Rust में वास्तव में आश्रित प्रकार और बहुरूपी पुनरावर्तन नहीं होता है, इसलिए हम बहुत सारी असुरक्षितता के साथ काम करते हैं।
//

// इस मॉड्यूल का एक प्रमुख लक्ष्य पेड़ को एक सामान्य (यदि अजीब आकार का) कंटेनर के रूप में मानते हुए जटिलता से बचना है और अधिकांश बी-ट्री इनवेरिएंट से निपटने से बचना है।
//
// जैसे, यह मॉड्यूल परवाह नहीं करता है कि क्या प्रविष्टियों को क्रमबद्ध किया गया है, कौन से नोड्स कम हो सकते हैं, या यहां तक कि अंडरफुल का क्या मतलब है।हालाँकि, हम कुछ अपरिवर्तनीयों पर भरोसा करते हैं:
//
// - पेड़ों में एक समान depth/height होना चाहिए।इसका मतलब है कि किसी दिए गए नोड से पत्ती तक जाने वाले प्रत्येक पथ की लंबाई बिल्कुल समान होती है।
// - लंबाई `n` के एक नोड में `n` कुंजियाँ, `n` मान और `n + 1` किनारे होते हैं।
//   इसका तात्पर्य यह है कि एक खाली नोड में भी कम से कम एक edge होता है।
//   लीफ नोड के लिए, "having an edge" का मतलब केवल यह है कि हम नोड में स्थिति की पहचान कर सकते हैं, क्योंकि लीफ किनारे खाली हैं और डेटा प्रतिनिधित्व की आवश्यकता नहीं है।
// एक आंतरिक नोड में, एक edge दोनों एक स्थिति की पहचान करता है और इसमें एक चाइल्ड नोड के लिए एक पॉइंटर होता है।
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// लीफ नोड्स का अंतर्निहित प्रतिनिधित्व और आंतरिक नोड्स के प्रतिनिधित्व का हिस्सा।
struct LeafNode<K, V> {
    /// हम `K` और `V` में सहसंयोजक बनना चाहते हैं।
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// इस नोड की अनुक्रमणिका पैरेंट नोड के `edges` सरणी में है।
    /// `*node.parent.edges[node.parent_idx]` `node` जैसा ही होना चाहिए।
    /// यह केवल तभी प्रारंभ होने की गारंटी है जब `parent` गैर-शून्य है।
    parent_idx: MaybeUninit<u16>,

    /// यह नोड स्टोर की जाने वाली कुंजियों और मानों की संख्या.
    len: u16,

    /// नोड के वास्तविक डेटा को संग्रहीत करने वाली सरणियाँ।
    /// प्रत्येक सरणी के केवल पहले `len` तत्व आरंभिक और मान्य हैं।
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// एक नया `LeafNode` इन-प्लेस प्रारंभ करता है।
    unsafe fn init(this: *mut Self) {
        // एक सामान्य नीति के रूप में, यदि संभव हो तो हम फ़ील्ड को अप्रारंभीकृत छोड़ देते हैं, क्योंकि यह वालग्रिंड में ट्रैक करने के लिए थोड़ा तेज़ और आसान दोनों होना चाहिए।
        //
        unsafe {
            // parent_idx, कुंजियाँ, और वैल सभी शायद हो सकता हैUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// एक नया बॉक्सिंग `LeafNode` बनाता है।
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// आंतरिक नोड्स का अंतर्निहित प्रतिनिधित्व।जैसा कि `LeafNode`s के साथ होता है, इन्हें `BoxedNode` के पीछे छिपाया जाना चाहिए ताकि अप्रारंभीकृत कुंजियों और मूल्यों को छोड़ने से रोका जा सके।
/// `InternalNode` के किसी भी पॉइंटर को सीधे नोड के अंतर्निहित `LeafNode` हिस्से में एक पॉइंटर पर डाला जा सकता है, जिससे कोड को पत्ती और आंतरिक नोड्स पर सामान्य रूप से कार्य करने की अनुमति मिलती है, यह भी जांचे बिना कि दोनों में से कौन सा पॉइंटर इंगित कर रहा है।
///
/// यह गुण `repr(C)` के उपयोग द्वारा सक्षम किया गया है।
///
#[repr(C)]
// gdb_providers.py आत्मनिरीक्षण के लिए इस प्रकार के नाम का उपयोग करता है।
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// इस नोड के बच्चों के लिए संकेत।
    /// `len + 1` इनमें से प्रारंभिक और मान्य माना जाता है, सिवाय इसके कि अंत के पास, जबकि पेड़ उधार प्रकार `Dying` के माध्यम से आयोजित किया जाता है, इनमें से कुछ पॉइंटर्स लटक रहे हैं।
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// एक नया बॉक्सिंग `InternalNode` बनाता है।
    ///
    /// # Safety
    /// आंतरिक नोड्स का एक अपरिवर्तनीय यह है कि उनके पास कम से कम एक आरंभिक और वैध edge है।
    /// यह फ़ंक्शन ऐसा edge सेट नहीं करता है।
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // हमें केवल डेटा को इनिशियलाइज़ करने की आवश्यकता है;किनारे शायद यूनीट हैं।
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// एक नोड के लिए एक प्रबंधित, गैर-शून्य सूचक।यह या तो `LeafNode<K, V>` का स्वामित्व वाला सूचक है या `InternalNode<K, V>` का स्वामित्व वाला सूचक है।
///
/// हालाँकि, `BoxedNode` में इस बात की कोई जानकारी नहीं है कि वास्तव में इसमें कौन से दो प्रकार के नोड शामिल हैं, और आंशिक रूप से इस जानकारी की कमी के कारण, एक अलग प्रकार नहीं है और इसका कोई विनाशक नहीं है।
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// एक स्वामित्व वाले पेड़ का मूल नोड।
///
/// ध्यान दें कि इसमें विध्वंसक नहीं है, और इसे मैन्युअल रूप से साफ किया जाना चाहिए।
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// एक नया स्वामित्व वाला पेड़ देता है, जिसका अपना रूट नोड होता है जो शुरू में खाली होता है।
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` शून्य नहीं होना चाहिए।
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// परस्पर स्वामित्व वाले रूट नोड को उधार लेता है।
    /// `reborrow_mut` के विपरीत, यह सुरक्षित है क्योंकि रूट को नष्ट करने के लिए रिटर्न वैल्यू का उपयोग नहीं किया जा सकता है, और पेड़ के अन्य संदर्भ नहीं हो सकते हैं।
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// स्वामित्व वाले रूट नोड को थोड़ा पारस्परिक रूप से उधार लेता है।
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// एक संदर्भ के लिए अपरिवर्तनीय रूप से संक्रमण जो ट्रैवर्सल की अनुमति देता है और विनाशकारी तरीकों की पेशकश करता है और कुछ और।
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// पिछले रूट नोड की ओर इशारा करते हुए एकल edge के साथ एक नया आंतरिक नोड जोड़ता है, उस नए नोड को रूट नोड बनाता है, और इसे वापस करता है।
    /// इससे ऊंचाई 1 बढ़ जाती है और यह `pop_internal_level` के विपरीत है।
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, सिवाय इसके कि हम अभी भूल गए हैं कि हम अभी आंतरिक हैं:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// अपने पहले बच्चे को नए रूट नोड के रूप में उपयोग करते हुए, आंतरिक रूट नोड को हटा देता है।
    /// चूंकि इसका इरादा केवल तभी कहा जाता है जब रूट नोड में केवल एक बच्चा होता है, किसी भी कुंजी, मान और अन्य बच्चों पर कोई सफाई नहीं की जाती है।
    ///
    /// इससे ऊंचाई 1 कम हो जाती है और यह `push_internal_level` के विपरीत है।
    ///
    /// `Root` ऑब्जेक्ट तक विशेष पहुंच की आवश्यकता है लेकिन रूट नोड तक नहीं;
    /// यह रूट नोड के अन्य हैंडल या संदर्भों को अमान्य नहीं करेगा।
    ///
    /// Panics यदि कोई आंतरिक स्तर नहीं है, अर्थात, यदि रूट नोड एक पत्ता है।
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // सुरक्षा: हमने आंतरिक होने का दावा किया।
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // सुरक्षा: हमने `self` को विशेष रूप से उधार लिया है और इसका उधार प्रकार अनन्य है।
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // सुरक्षा: पहला edge हमेशा इनिशियलाइज़ होता है।
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` हमेशा `K` और `V` में सहसंयोजक होता है, भले ही `BorrowType` `Mut` हो।
// यह तकनीकी रूप से गलत है, लेकिन `NodeRef` के आंतरिक उपयोग के कारण किसी भी तरह की असुरक्षितता नहीं हो सकती क्योंकि हम `K` और `V` पर पूरी तरह से सामान्य रहते हैं।
//
// हालाँकि, जब भी कोई सार्वजनिक प्रकार `NodeRef` को लपेटता है, तो सुनिश्चित करें कि इसका सही विचरण है।
//
/// एक नोड का संदर्भ।
///
/// इस प्रकार के कई पैरामीटर हैं जो नियंत्रित करते हैं कि यह कैसे कार्य करता है:
/// - `BorrowType`: एक डमी प्रकार जो उधार के प्रकार का वर्णन करता है और जीवन भर वहन करता है।
///    - जब यह `Immut<'a>` होता है, तो `NodeRef` मोटे तौर पर `&'a Node` की तरह कार्य करता है।
///    - जब यह `ValMut<'a>` होता है, तो `NodeRef` चाबियों और पेड़ की संरचना के संबंध में लगभग `&'a Node` की तरह कार्य करता है, लेकिन साथ ही पूरे पेड़ में मूल्यों के कई परस्पर संदर्भों को सह-अस्तित्व की अनुमति देता है।
///    - जब यह `Mut<'a>` होता है, तो `NodeRef` मोटे तौर पर `&'a mut Node` की तरह कार्य करता है, हालांकि सम्मिलित विधियाँ एक परिवर्तनशील सूचक को एक मान के साथ-साथ रहने की अनुमति देती हैं।
///    - जब यह `Owned` होता है, तो `NodeRef` मोटे तौर पर `Box<Node>` की तरह कार्य करता है, लेकिन इसमें विध्वंसक नहीं होता है, और इसे मैन्युअल रूप से साफ किया जाना चाहिए।
///    - जब यह `Dying` होता है, तो `NodeRef` अभी भी मोटे तौर पर `Box<Node>` की तरह काम करता है, लेकिन इसमें पेड़ को थोड़ा-थोड़ा करके नष्ट करने के तरीके हैं, और सामान्य तरीके, जबकि कॉल करने के लिए असुरक्षित के रूप में चिह्नित नहीं हैं, गलत तरीके से कॉल किए जाने पर UB को लागू कर सकते हैं।
///
///   चूंकि कोई भी `NodeRef` पेड़ के माध्यम से नेविगेट करने की अनुमति देता है, `BorrowType` प्रभावी रूप से पूरे पेड़ पर लागू होता है, न कि केवल नोड पर ही।
/// - `K` और `V`: ये नोड्स में संग्रहीत कुंजियों और मूल्यों के प्रकार हैं।
/// - `Type`: यह `Leaf`, `Internal`, या `LeafOrInternal` हो सकता है।
/// जब यह `Leaf` होता है, तो `NodeRef` एक लीफ नोड को इंगित करता है, जब यह `Internal` होता है तो `NodeRef` एक आंतरिक नोड को इंगित करता है, और जब यह `LeafOrInternal` होता है तो `NodeRef` किसी भी प्रकार के नोड को इंगित कर सकता है।
///   `Type` `NodeRef` के बाहर उपयोग किए जाने पर `NodeType` नाम दिया गया है।
///
/// `BorrowType` और `NodeType` दोनों स्थिर प्रकार की सुरक्षा का फायदा उठाने के लिए हम किन तरीकों को लागू करते हैं, इसे प्रतिबंधित करते हैं।जिस तरह से हम इस तरह के प्रतिबंध लागू कर सकते हैं, उसकी सीमाएँ हैं:
/// - प्रत्येक प्रकार के पैरामीटर के लिए, हम केवल एक विधि को या तो सामान्य रूप से या एक विशेष प्रकार के लिए परिभाषित कर सकते हैं।
/// उदाहरण के लिए, हम सभी `BorrowType` के लिए सामान्य रूप से `into_kv` जैसी विधि को परिभाषित नहीं कर सकते हैं, या एक बार सभी प्रकार के लिए जो जीवन भर ले जाते हैं, क्योंकि हम चाहते हैं कि यह `&'a` संदर्भ लौटाए।
///   इसलिए, हम इसे केवल कम से कम शक्तिशाली प्रकार `Immut<'a>` के लिए परिभाषित करते हैं।
/// - हम `Mut<'a>` से `Immut<'a>` तक अंतर्निहित जबरदस्ती नहीं प्राप्त कर सकते हैं।
///   इसलिए, हमें `into_kv` जैसी विधि तक पहुंचने के लिए स्पष्ट रूप से `reborrow` को अधिक शक्तिशाली `NodeRef` पर कॉल करना होगा।
///
/// `NodeRef` पर सभी विधियां जो किसी प्रकार का संदर्भ लौटाती हैं, या तो:
/// - `self` को मान से लें, और `BorrowType` द्वारा किए गए जीवनकाल को वापस करें।
///   कभी-कभी, ऐसी विधि को लागू करने के लिए, हमें `reborrow_mut` को कॉल करने की आवश्यकता होती है।
/// - `self` को संदर्भ से लें, और (implicitly) `BorrowType` द्वारा किए गए जीवनकाल के बजाय उस संदर्भ के जीवनकाल को वापस कर दें।
/// इस तरह, उधार चेकर गारंटी देता है कि जब तक लौटाए गए संदर्भ का उपयोग किया जाता है, तब तक `NodeRef` उधार लिया जाता है।
///   इंसर्ट का समर्थन करने वाले तरीके इस नियम को बिना किसी जीवनकाल के एक कच्चे सूचक, यानी एक संदर्भ लौटाकर मोड़ते हैं।
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// स्तरों की संख्या जो नोड और पत्तियों का स्तर अलग है, नोड का एक स्थिरांक जिसे पूरी तरह से `Type` द्वारा वर्णित नहीं किया जा सकता है, और यह कि नोड स्वयं संग्रहीत नहीं करता है।
    /// हमें केवल रूट नोड की ऊंचाई को स्टोर करने की आवश्यकता है, और इससे हर दूसरे नोड की ऊंचाई प्राप्त करें।
    /// यदि `Type`, `Leaf` है तो शून्य होना चाहिए और यदि `Type`, `Internal` है तो शून्य नहीं होना चाहिए।
    ///
    ///
    height: usize,
    /// पत्ती या आंतरिक नोड का सूचक।
    /// `InternalNode` की परिभाषा यह सुनिश्चित करती है कि सूचक किसी भी तरह से मान्य है।
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// एक नोड संदर्भ को अनपैक करें जिसे `NodeRef::parent` के रूप में पैक किया गया था।
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// एक आंतरिक नोड के डेटा को उजागर करता है।
    ///
    /// इस नोड के अन्य संदर्भों को अमान्य करने से बचने के लिए एक कच्चा पीआरटी देता है।
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // सुरक्षा: स्थिर नोड प्रकार `Internal` है।
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// एक आंतरिक नोड के डेटा तक विशेष पहुंच उधार लेता है।
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// नोड की लंबाई पाता है।यह कुंजियों या मानों की संख्या है।
    /// किनारों की संख्या `len() + 1` है।
    /// ध्यान दें कि, सुरक्षित होने के बावजूद, इस फ़ंक्शन को कॉल करने से असुरक्षित कोड द्वारा बनाए गए परिवर्तनीय संदर्भों को अमान्य करने का दुष्प्रभाव हो सकता है।
    ///
    pub fn len(&self) -> usize {
        // महत्वपूर्ण रूप से, हम यहाँ केवल `len` फ़ील्ड तक पहुँच प्राप्त करते हैं।
        // यदि बॉरोटाइप marker::ValMut है, तो उन मानों के लिए उत्कृष्ट परिवर्तनशील संदर्भ हो सकते हैं जिन्हें हमें अमान्य नहीं करना चाहिए।
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// नोड और पत्तियों के अलग-अलग स्तरों की संख्या लौटाता है।
    /// शून्य ऊंचाई का मतलब है कि नोड एक पत्ता ही है।
    /// यदि आप शीर्ष पर जड़ वाले पेड़ों को चित्रित करते हैं, तो संख्या बताती है कि नोड किस ऊंचाई पर दिखाई देता है।
    /// यदि आप पेड़ों को शीर्ष पर पत्तियों के साथ चित्रित करते हैं, तो संख्या बताती है कि पेड़ नोड के ऊपर कितना ऊंचा है।
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// अस्थायी रूप से एक ही नोड के लिए एक और अपरिवर्तनीय संदर्भ निकालता है।
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// किसी भी पत्ते या आंतरिक नोड के पत्ते के हिस्से को उजागर करता है।
    ///
    /// इस नोड के अन्य संदर्भों को अमान्य करने से बचने के लिए एक कच्चा पीआरटी देता है।
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // नोड कम से कम लीफनोड भाग के लिए मान्य होना चाहिए।
        // यह NodeRef प्रकार में एक संदर्भ नहीं है क्योंकि हम नहीं जानते कि यह अद्वितीय होना चाहिए या साझा किया जाना चाहिए।
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// वर्तमान नोड के माता-पिता को ढूँढता है।
    /// यदि वर्तमान नोड में वास्तव में एक अभिभावक है, तो `Ok(handle)` लौटाता है, जहां `handle` माता-पिता के edge को इंगित करता है जो वर्तमान नोड को इंगित करता है।
    ///
    /// यदि वर्तमान नोड का कोई पैरेंट नहीं है, तो मूल `NodeRef` वापस देते हुए `Err(self)` लौटाता है।
    ///
    /// विधि का नाम मानता है कि आप शीर्ष पर रूट नोड वाले पेड़ को चित्रित करते हैं।
    ///
    /// `edge.descend().ascend().unwrap()` और `node.ascend().unwrap().descend()` दोनों को सफलता मिलने पर कुछ नहीं करना चाहिए।
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // हमें नोड्स के लिए कच्चे पॉइंटर्स का उपयोग करने की आवश्यकता है, क्योंकि यदि बॉरोटाइप marker::ValMut है, तो उन मानों के लिए उत्कृष्ट परिवर्तनशील संदर्भ हो सकते हैं जिन्हें हमें अमान्य नहीं करना चाहिए।
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// ध्यान दें कि `self` खाली नहीं होना चाहिए।
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// ध्यान दें कि `self` खाली नहीं होना चाहिए।
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// अपरिवर्तनीय पेड़ में किसी भी पत्ती या आंतरिक नोड के पत्ते के हिस्से को उजागर करता है।
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // सुरक्षा: `Immut` के रूप में उधार लिए गए इस पेड़ में कोई परिवर्तनशील संदर्भ नहीं हो सकता है।
        unsafe { &*ptr }
    }

    /// नोड में संग्रहीत कुंजियों में एक दृश्य उधार लेता है।
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` के समान, नोड के मूल नोड का संदर्भ प्राप्त करता है, लेकिन प्रक्रिया में वर्तमान नोड को भी हटा देता है।
    /// यह असुरक्षित है क्योंकि हटाए जाने के बावजूद वर्तमान नोड अभी भी सुलभ होगा।
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// संकलक को असुरक्षित रूप से स्थिर जानकारी देता है कि यह नोड एक `Leaf` है।
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// संकलक को असुरक्षित रूप से स्थिर जानकारी देता है कि यह नोड एक `Internal` है।
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// अस्थायी रूप से एक ही नोड के लिए एक और, परिवर्तनशील संदर्भ निकालता है।सावधान रहें, क्योंकि यह तरीका बहुत खतरनाक है, क्योंकि यह तुरंत खतरनाक नहीं लग सकता है।
    ///
    /// चूंकि परिवर्तनीय पॉइंटर्स पेड़ के चारों ओर कहीं भी घूम सकते हैं, लौटाए गए पॉइंटर का उपयोग मूल पॉइंटर को लटकने, सीमा से बाहर, या स्टैक्ड उधार नियमों के तहत अमान्य बनाने के लिए आसानी से किया जा सकता है।
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef` में एक अन्य प्रकार के पैरामीटर को जोड़ने पर विचार करें जो इस असुरक्षितता को रोकने के लिए पुनर्उधारित पॉइंटर्स पर नेविगेशन विधियों के उपयोग को प्रतिबंधित करता है।
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// किसी भी पत्ते या आंतरिक नोड के पत्ते के हिस्से तक विशेष पहुंच उधार लेता है।
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // सुरक्षा: हमारे पास पूरे नोड तक विशेष पहुंच है।
        unsafe { &mut *ptr }
    }

    /// किसी भी पत्ते या आंतरिक नोड के पत्ते के हिस्से तक विशेष पहुंच प्रदान करता है।
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // सुरक्षा: हमारे पास पूरे नोड तक विशेष पहुंच है।
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// कुंजी भंडारण क्षेत्र के एक तत्व के लिए विशेष पहुंच उधार लेता है।
    ///
    /// # Safety
    /// `index` 0. .क्षमता की सीमा में है
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // सुरक्षा: कॉलर स्वयं पर आगे के तरीकों को कॉल करने में सक्षम नहीं होगा
        // जब तक कि की स्लाइस रेफरेंस को हटा नहीं दिया जाता है, क्योंकि हमारे पास उधार के जीवनकाल के लिए अद्वितीय पहुंच है।
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// किसी तत्व या नोड के मूल्य भंडारण क्षेत्र के टुकड़े के लिए विशेष पहुंच उधार लेता है।
    ///
    /// # Safety
    /// `index` 0. .क्षमता की सीमा में है
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // सुरक्षा: कॉलर स्वयं पर आगे के तरीकों को कॉल करने में सक्षम नहीं होगा
        // जब तक मूल्य टुकड़ा संदर्भ हटा नहीं दिया जाता है, क्योंकि हमारे पास उधार के जीवनकाल के लिए अद्वितीय पहुंच है।
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge सामग्री के लिए नोड के भंडारण क्षेत्र के किसी तत्व या स्लाइस के लिए विशेष पहुंच उधार लेता है।
    ///
    /// # Safety
    /// `index` 0 की सीमा में है..क्षमता + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // सुरक्षा: कॉलर स्वयं पर आगे के तरीकों को कॉल करने में सक्षम नहीं होगा
        // जब तक edge स्लाइस संदर्भ को हटा नहीं दिया जाता है, क्योंकि हमारे पास उधार के जीवनकाल के लिए अद्वितीय पहुंच है।
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - नोड में `idx` से अधिक आरंभिक तत्व हैं।
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // हम केवल उस एक तत्व का संदर्भ बनाते हैं जिसमें हम रुचि रखते हैं, अन्य तत्वों के उत्कृष्ट संदर्भों के साथ अलियासिंग से बचने के लिए, विशेष रूप से, जो पहले के पुनरावृत्तियों में कॉलर को वापस कर दिए गए थे।
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust समस्या #74679 के कारण हमें अनसाइज़्ड ऐरे पॉइंटर्स के लिए बाध्य होना चाहिए।
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// नोड की लंबाई के लिए विशेष पहुंच उधार लेता है।
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// नोड के अन्य संदर्भों को अमान्य किए बिना, नोड के लिंक को उसके मूल edge से सेट करता है।
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// रूट के लिंक को उसके पैरेंट edge से साफ़ करता है।
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// नोड के अंत में एक की-वैल्यू पेयर जोड़ता है।
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` द्वारा लौटाया गया प्रत्येक आइटम नोड के लिए एक मान्य edge अनुक्रमणिका है।
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// नोड के अंत में, उस जोड़ी के दाईं ओर जाने के लिए एक कुंजी-मूल्य जोड़ी, और एक edge जोड़ता है।
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// जाँचता है कि कोई नोड `Internal` नोड है या `Leaf` नोड।
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// एक नोड के भीतर एक विशिष्ट कुंजी-मूल्य जोड़ी या edge का संदर्भ।
/// `Node` पैरामीटर एक `NodeRef` होना चाहिए, जबकि `Type` या तो `KV` (की-वैल्यू पेयर पर एक हैंडल को दर्शाता है) या `Edge` (edge पर एक हैंडल को दर्शाता है) हो सकता है।
///
/// ध्यान दें कि `Leaf` नोड्स में भी `Edge` हैंडल हो सकते हैं।
/// चाइल्ड नोड के लिए पॉइंटर का प्रतिनिधित्व करने के बजाय, ये उन रिक्त स्थान का प्रतिनिधित्व करते हैं जहां चाइल्ड पॉइंटर्स की-वैल्यू पेयर के बीच जाएंगे।
/// उदाहरण के लिए, लंबाई 2 वाले नोड में, 3 संभावित edge स्थान होंगे, एक नोड के बाईं ओर, एक दो जोड़े के बीच, और एक नोड के दाईं ओर।
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// हमें `#[derive(Clone)]` की पूर्ण व्यापकता की आवश्यकता नहीं है, क्योंकि केवल तभी `Node` `क्लोन` सक्षम होगा जब यह एक अपरिवर्तनीय संदर्भ हो और इसलिए `Copy`।
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// उस नोड को पुनः प्राप्त करता है जिसमें edge या कुंजी-मान युग्म होता है जिसे यह हैंडल इंगित करता है।
    pub fn into_node(self) -> Node {
        self.node
    }

    /// नोड में इस हैंडल की स्थिति लौटाता है।
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` में की-वैल्यू पेयर के लिए एक नया हैंडल बनाता है।
    /// असुरक्षित क्योंकि कॉलर को यह सुनिश्चित करना होगा कि `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq का सार्वजनिक कार्यान्वयन हो सकता है, लेकिन केवल इस मॉड्यूल में उपयोग किया जाता है।
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// अस्थायी रूप से उसी स्थान पर दूसरा, अपरिवर्तनीय हैंडल निकालता है।
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // हम Handle::new_kv या Handle::new_edge का उपयोग नहीं कर सकते क्योंकि हम अपने प्रकार को नहीं जानते हैं
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// संकलक को असुरक्षित रूप से स्थिर जानकारी देता है कि हैंडल का नोड एक `Leaf` है।
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// अस्थायी रूप से उसी स्थान पर दूसरा, परिवर्तनशील हैंडल निकालता है।
    /// सावधान रहें, क्योंकि यह तरीका बहुत खतरनाक है, क्योंकि यह तुरंत खतरनाक नहीं लग सकता है।
    ///
    ///
    /// विवरण के लिए, `NodeRef::reborrow_mut` देखें।
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // हम Handle::new_kv या Handle::new_edge का उपयोग नहीं कर सकते क्योंकि हम अपने प्रकार को नहीं जानते हैं
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` में edge के लिए एक नया हैंडल बनाता है।
    /// असुरक्षित क्योंकि कॉलर को यह सुनिश्चित करना होगा कि `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// edge इंडेक्स को देखते हुए जहां हम क्षमता से भरे नोड में सम्मिलित करना चाहते हैं, एक विभाजन बिंदु के एक समझदार केवी इंडेक्स की गणना करता है और जहां सम्मिलन करना है।
///
/// विभाजन बिंदु का लक्ष्य इसकी कुंजी और मान को मूल नोड में समाप्त करना है;
/// विभाजन बिंदु के बाईं ओर की कुंजियाँ, मान और किनारे बाएँ बच्चे बन जाते हैं;
/// विभाजन बिंदु के दाईं ओर की कुंजियाँ, मान और किनारे सही बच्चे बन जाते हैं।
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust अंक #74834 इन सममित नियमों को समझाने की कोशिश करता है।
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// इस edge के दाईं और बाईं ओर की-वैल्यू पेयर के बीच एक नया की-वैल्यू पेयर डालें।
    /// यह विधि मानती है कि नई जोड़ी के फिट होने के लिए नोड में पर्याप्त जगह है।
    ///
    /// लौटाया गया सूचक सम्मिलित मूल्य को इंगित करता है।
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// इस edge के दाईं और बाईं ओर की-वैल्यू पेयर के बीच एक नया की-वैल्यू पेयर डालें।
    /// यदि पर्याप्त जगह नहीं है तो यह विधि नोड को विभाजित करती है।
    ///
    /// लौटाया गया सूचक सम्मिलित मूल्य को इंगित करता है।
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// चाइल्ड नोड में पैरेंट पॉइंटर और इंडेक्स को ठीक करता है जिससे यह edge लिंक होता है।
    /// यह तब उपयोगी होता है जब किनारों का क्रम बदल दिया गया हो,
    fn correct_parent_link(self) {
        // नोड के अन्य संदर्भों को अमान्य किए बिना बैकपॉइंटर बनाएं।
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// एक नया की-वैल्यू पेयर और एक edge सम्मिलित करता है जो इस edge और इस edge के दाईं ओर की-वैल्यू पेयर के बीच उस नई जोड़ी के दाईं ओर जाएगा।
    /// यह विधि मानती है कि नई जोड़ी के फिट होने के लिए नोड में पर्याप्त जगह है।
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// एक नया की-वैल्यू पेयर और एक edge सम्मिलित करता है जो इस edge और इस edge के दाईं ओर की-वैल्यू पेयर के बीच उस नई जोड़ी के दाईं ओर जाएगा।
    /// यदि पर्याप्त जगह नहीं है तो यह विधि नोड को विभाजित करती है।
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// इस edge के दाईं और बाईं ओर की-वैल्यू पेयर के बीच एक नया की-वैल्यू पेयर डालें।
    /// यदि पर्याप्त जगह नहीं है तो यह विधि नोड को विभाजित करती है, और रूट तक पहुंचने तक विभाजित भाग को मूल नोड में पुनरावर्ती रूप से सम्मिलित करने का प्रयास करती है।
    ///
    ///
    /// यदि लौटा हुआ परिणाम एक `Fit` है, तो इसके हैंडल का नोड इस edge का नोड या पूर्वज हो सकता है।
    /// यदि लौटाया गया परिणाम `Split` है, तो `left` फ़ील्ड रूट नोड होगा।
    /// लौटाया गया सूचक सम्मिलित मूल्य को इंगित करता है।
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// इस edge द्वारा इंगित नोड ढूँढता है।
    ///
    /// विधि का नाम मानता है कि आप शीर्ष पर रूट नोड वाले पेड़ को चित्रित करते हैं।
    ///
    /// `edge.descend().ascend().unwrap()` और `node.ascend().unwrap().descend()` दोनों को सफलता मिलने पर कुछ नहीं करना चाहिए।
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // हमें नोड्स के लिए कच्चे पॉइंटर्स का उपयोग करने की आवश्यकता है, क्योंकि यदि बॉरोटाइप marker::ValMut है, तो उन मानों के लिए उत्कृष्ट परिवर्तनशील संदर्भ हो सकते हैं जिन्हें हमें अमान्य नहीं करना चाहिए।
        // ऊंचाई फ़ील्ड तक पहुंचने में कोई चिंता नहीं है क्योंकि उस मान की प्रतिलिपि बनाई गई है।
        // सावधान रहें कि, एक बार नोड पॉइंटर को संदर्भित करने के बाद, हम किनारों के सरणी को एक संदर्भ (Rust अंक #73987) के साथ एक्सेस करते हैं और सरणी के अंदर या अंदर किसी भी अन्य संदर्भ को अमान्य कर देते हैं, कोई भी आसपास होना चाहिए।
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // हम अलग-अलग कुंजी और मूल्य विधियों को कॉल नहीं कर सकते, क्योंकि दूसरे को कॉल करने से पहले द्वारा दिए गए संदर्भ को अमान्य कर दिया जाता है।
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// कुंजी और मान को बदलें जिसे KV हैंडल संदर्भित करता है।
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// लीफ डेटा का ध्यान रखते हुए, किसी विशेष `NodeType` के लिए `split` के कार्यान्वयन में मदद करता है।
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// अंतर्निहित नोड को तीन भागों में विभाजित करता है:
    ///
    /// - इस हैंडल के बाईं ओर केवल कुंजी-मान जोड़े रखने के लिए नोड को छोटा कर दिया गया है।
    /// - इस हैंडल द्वारा इंगित कुंजी और मूल्य निकाले जाते हैं।
    /// - इस हैंडल के दाईं ओर सभी कुंजी-मूल्य जोड़े एक नए आवंटित नोड में डाल दिए जाते हैं।
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// इस हैंडल द्वारा इंगित की-वैल्यू पेयर को हटाता है और इसे edge के साथ लौटाता है, जिसमें की-वैल्यू पेयर ढह जाता है।
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// अंतर्निहित नोड को तीन भागों में विभाजित करता है:
    ///
    /// - इस हैंडल के बाईं ओर केवल किनारों और कुंजी-मूल्य जोड़े को शामिल करने के लिए नोड को छोटा कर दिया गया है।
    /// - इस हैंडल द्वारा इंगित कुंजी और मूल्य निकाले जाते हैं।
    /// - इस हैंडल के दायीं ओर के सभी किनारों और की-वैल्यू पेयर को एक नए आवंटित नोड में डाल दिया जाता है।
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// एक आंतरिक कुंजी-मूल्य जोड़ी के आसपास संतुलन संचालन के मूल्यांकन और प्रदर्शन के लिए एक सत्र का प्रतिनिधित्व करता है।
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// एक बच्चे के रूप में नोड को शामिल करते हुए एक संतुलन संदर्भ चुनता है, इस प्रकार केवी के बीच तुरंत बाएं या दाएं पैरेंट नोड में।
    /// यदि कोई अभिभावक नहीं है तो `Err` लौटाता है।
    /// Panics यदि माता-पिता खाली है।
    ///
    /// बाईं ओर को प्राथमिकता देता है, यदि दिया गया नोड किसी तरह से कम भरा हुआ है, तो इसका मतलब केवल यह है कि इसमें इसके बाएं भाई की तुलना में कम तत्व हैं और इसके दाहिने भाई की तुलना में, यदि वे मौजूद हैं।
    /// उस स्थिति में, बाएं भाई-बहन के साथ विलय करना तेज़ होता है, क्योंकि हमें केवल नोड के एन तत्वों को स्थानांतरित करने की आवश्यकता होती है, बजाय उन्हें दाईं ओर स्थानांतरित करने और एन तत्वों से अधिक को आगे ले जाने की।
    /// बाएं भाई-बहन से चोरी करना भी आम तौर पर तेज़ होता है, क्योंकि हमें केवल नोड के एन तत्वों को बाईं ओर स्थानांतरित करने के बजाय, भाई के तत्वों में से कम से कम एन को स्थानांतरित करने की आवश्यकता होती है।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// यह लौटाता है कि क्या विलय संभव है, यानी, क्या एक नोड में केंद्रीय केवी को दोनों आसन्न चाइल्ड नोड्स के साथ संयोजित करने के लिए पर्याप्त जगह है।
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// एक मर्ज करता है और एक क्लोजर को यह तय करने देता है कि क्या वापस करना है।
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // सुरक्षा: मर्ज किए जा रहे नोड्स की ऊंचाई ऊंचाई से एक नीचे है
                // इस edge के नोड के, इस प्रकार शून्य से ऊपर, इसलिए वे आंतरिक हैं।
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// पैरेंट के की-वैल्यू पेयर और दोनों आसन्न चाइल्ड नोड्स को लेफ्ट चाइल्ड नोड में मर्ज करता है और सिकुड़ा हुआ पैरेंट नोड लौटाता है।
    ///
    ///
    /// Panics जब तक हम `.can_merge()` नहीं।
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// पैरेंट के की-वैल्यू पेयर और दोनों आसन्न चाइल्ड नोड्स को लेफ्ट चाइल्ड नोड में मर्ज करता है और उस चाइल्ड नोड को लौटाता है।
    ///
    ///
    /// Panics जब तक हम `.can_merge()` नहीं।
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// माता-पिता के की-वैल्यू पेयर और दोनों आसन्न चाइल्ड नोड्स को लेफ्ट चाइल्ड नोड में मर्ज करता है और उस चाइल्ड नोड में edge हैंडल लौटाता है जहाँ ट्रैक किया गया चाइल्ड edge समाप्त होता है,
    ///
    ///
    /// Panics जब तक हम `.can_merge()` नहीं।
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// बाएं बच्चे से एक की-वैल्यू पेयर को हटाता है और इसे पैरेंट के की-वैल्यू स्टोरेज में रखता है, जबकि पुराने पैरेंट की-वैल्यू पेयर को राइट चाइल्ड में धकेलता है।
    ///
    /// जहां `track_right_edge_idx` द्वारा निर्दिष्ट मूल edge समाप्त होता है, उसके अनुरूप दाएं बच्चे में edge को एक हैंडल देता है।
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// बाएं बच्चे पर पुराने पैरेंट की-वैल्यू जोड़ी को धकेलते हुए, दाहिने बच्चे से एक की-वैल्यू पेयर को हटाता है और इसे पैरेंट के की-वैल्यू स्टोरेज में रखता है।
    ///
    /// `track_left_edge_idx` द्वारा निर्दिष्ट बाएं बच्चे में edge को एक हैंडल लौटाता है, जो हिलता नहीं है।
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// यह `steal_left` के समान चोरी करता है लेकिन एक साथ कई तत्वों को चुराता है।
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // सुनिश्चित करें कि हम सुरक्षित रूप से चोरी कर सकते हैं।
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // पत्ता डेटा ले जाएँ।
            {
                // सही बच्चे में चोरी के तत्वों के लिए जगह बनाएं।
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // तत्वों को बाएं बच्चे से दाईं ओर ले जाएं।
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // सबसे बाएं जोड़े को माता-पिता के पास ले जाएं।
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // माता-पिता की कुंजी-मूल्य जोड़ी को दाहिने बच्चे में ले जाएं।
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // चोरी के किनारों के लिए जगह बनाएं।
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // किनारों को चुराओ।
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` का सममित क्लोन।
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // सुनिश्चित करें कि हम सुरक्षित रूप से चोरी कर सकते हैं।
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // पत्ता डेटा ले जाएँ।
            {
                // सबसे अधिक चोरी की गई जोड़ी को माता-पिता के पास ले जाएं।
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // माता-पिता की कुंजी-मूल्य जोड़ी को बाएं बच्चे में ले जाएं।
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // तत्वों को दाएं बच्चे से बाईं ओर ले जाएं।
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // जहां चोरी के सामान हुआ करते थे, वहां गैप भरें।
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // किनारों को चुराओ।
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // जहां चोरी के किनारे हुआ करते थे, वहां गैप भरें।
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// यह नोड एक `Leaf` नोड है, यह कहते हुए किसी भी स्थिर जानकारी को हटा देता है।
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// यह नोड एक `Internal` नोड होने का दावा करते हुए किसी भी स्थिर जानकारी को हटा देता है।
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// जाँचता है कि अंतर्निहित नोड `Internal` नोड है या `Leaf` नोड।
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` के बाद प्रत्यय को एक नोड से दूसरे नोड में ले जाएं।`right` खाली होना चाहिए।
    /// `right` का पहला edge अपरिवर्तित रहता है।
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// सम्मिलन का परिणाम, जब एक नोड को अपनी क्षमता से अधिक विस्तार करने की आवश्यकता होती है।
pub struct SplitResult<'a, K, V, NodeType> {
    // मौजूदा ट्री में तत्वों और किनारों के साथ परिवर्तित नोड जो `kv` के बाईं ओर हैं।
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // कुछ कुंजी और मूल्य अलग हो गए, कहीं और डालने के लिए।
    pub kv: (K, V),
    // `kv` के दाईं ओर से संबंधित तत्वों और किनारों के साथ स्वामित्व, अनासक्त, नया नोड।
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // क्या इस उधार प्रकार के नोड संदर्भ पेड़ में अन्य नोड्स को पार करने की अनुमति देते हैं।
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ट्रैवर्सल की आवश्यकता नहीं है, यह `borrow_mut` के परिणाम का उपयोग करके होता है।
        // ट्रैवर्सल को अक्षम करके, और केवल जड़ों के लिए नए संदर्भ बनाकर, हम जानते हैं कि `Owned` प्रकार का प्रत्येक संदर्भ रूट नोड के लिए है।
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// आरंभिक तत्वों के एक स्लाइस में एक मान सम्मिलित करता है जिसके बाद एक प्रारंभिक तत्व होता है।
///
/// # Safety
/// स्लाइस में `idx` से अधिक तत्व हैं।
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// सभी आरंभिक तत्वों के एक स्लाइस से एक मूल्य को हटाता है और लौटाता है, एक अनुगामी गैर-प्रारंभिक तत्व को पीछे छोड़ देता है।
///
///
/// # Safety
/// स्लाइस में `idx` से अधिक तत्व हैं।
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// एक स्लाइस `distance` स्थिति में तत्वों को बाईं ओर शिफ्ट करता है।
///
/// # Safety
/// स्लाइस में कम से कम `distance` तत्व होते हैं।
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// एक स्लाइस `distance` स्थिति में तत्वों को दाईं ओर शिफ्ट करता है।
///
/// # Safety
/// स्लाइस में कम से कम `distance` तत्व होते हैं।
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// सभी मानों को आरंभिक तत्वों के एक स्लाइस से अप्रारंभीकृत तत्वों के एक स्लाइस में ले जाता है, `src` को सभी अप्रारंभीकृत के रूप में पीछे छोड़ देता है।
///
/// `dst.copy_from_slice(src)` की तरह काम करता है लेकिन `T` को `Copy` होने की आवश्यकता नहीं है।
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;