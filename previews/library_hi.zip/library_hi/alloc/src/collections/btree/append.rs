use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// दो आरोही पुनरावृत्तियों के संघ से सभी कुंजी-मूल्य जोड़े जोड़ता है, रास्ते में एक `length` चर को बढ़ाता है।उत्तरार्द्ध कॉलर के लिए एक रिसाव से बचने के लिए आसान बनाता है जब एक ड्रॉप हैंडलर घबरा जाता है।
    ///
    /// यदि दोनों इटरेटर एक ही कुंजी उत्पन्न करते हैं, तो यह विधि जोड़ी को बाएं इटरेटर से छोड़ देती है और जोड़ी को दाएं इटरेटर से जोड़ती है।
    ///
    /// यदि आप चाहते हैं कि पेड़ सख्ती से आरोही क्रम में समाप्त हो जाए, जैसे कि `BTreeMap` के लिए, दोनों इटरेटर को सख्ती से आरोही क्रम में कुंजी का उत्पादन करना चाहिए, प्रत्येक पेड़ में सभी चाबियों से बड़ा होना चाहिए, जिसमें प्रवेश पर पहले से ही पेड़ में कोई भी कुंजी शामिल है।
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // हम रैखिक समय में `left` और `right` को एक क्रमबद्ध क्रम में मर्ज करने की तैयारी करते हैं।
        let iter = MergeIter(MergeIterInner::new(left, right));

        // इस बीच, हम रेखीय समय में क्रमबद्ध अनुक्रम से एक पेड़ का निर्माण करते हैं।
        self.bulk_push(iter, length)
    }

    /// सभी की-वैल्यू पेयर को ट्री के अंत तक धकेलता है, रास्ते में एक `length` वेरिएबल को बढ़ाता है।
    /// उत्तरार्द्ध कॉल करने वाले के लिए रिसाव से बचने के लिए आसान बनाता है जब इटरेटर घबरा जाता है।
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // सभी कुंजी-मूल्य जोड़े के माध्यम से पुनरावृति करें, उन्हें सही स्तर पर नोड्स में धकेलें।
        for (key, value) in iter {
            // की-वैल्यू पेयर को वर्तमान लीफ नोड में पुश करने का प्रयास करें।
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // कोई जगह नहीं बची, ऊपर जाओ और वहां धक्का दो।
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // एक नोड मिला जिसमें जगह बची है, यहां पुश करें।
                                open_node = parent;
                                break;
                            } else {
                                // फिर से ऊपर जाओ।
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // हम सबसे ऊपर हैं, एक नया रूट नोड बनाएं और वहां पुश करें।
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // की-वैल्यू पेयर और नया राइट सबट्री पुश करें।
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // फिर से सबसे दाएँ पत्ते पर जाएँ।
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // प्रत्येक पुनरावृत्ति की लंबाई बढ़ाएं, यह सुनिश्चित करने के लिए कि नक्शा संलग्न तत्वों को छोड़ देता है, भले ही इटरेटर पैनिक को आगे बढ़ाए।
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// दो क्रमबद्ध अनुक्रमों को एक में विलय करने के लिए एक पुनरावर्तक
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// यदि दो कुंजियाँ समान हैं, तो कुंजी-मान युग्म को सही स्रोत से लौटाता है।
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}