//! स्वामित्व वाली नोड्स के साथ एक डबल-लिंक्ड सूची।
//!
//! `LinkedList` निरंतर समय में किसी भी छोर पर तत्वों को धकेलने और पॉप करने की अनुमति देता है।
//!
//! NOTE: [`Vec`] या [`VecDeque`] का उपयोग करना लगभग हमेशा बेहतर होता है क्योंकि सरणी-आधारित कंटेनर आमतौर पर तेज़, अधिक मेमोरी कुशल होते हैं, और CPU कैश का बेहतर उपयोग करते हैं।
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// स्वामित्व वाली नोड्स के साथ एक डबल-लिंक्ड सूची।
///
/// `LinkedList` निरंतर समय में किसी भी छोर पर तत्वों को धकेलने और पॉप करने की अनुमति देता है।
///
/// NOTE: `Vec` या `VecDeque` का उपयोग करना लगभग हमेशा बेहतर होता है क्योंकि सरणी-आधारित कंटेनर आमतौर पर तेज़, अधिक मेमोरी कुशल होते हैं, और CPU कैश का बेहतर उपयोग करते हैं।
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// `LinkedList` के तत्वों पर एक पुनरावर्तक।
///
/// यह `struct` [`LinkedList::iter()`] द्वारा बनाया गया है।
/// अधिक के लिए इसके दस्तावेज़ देखें।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]`. के पक्ष में निकालें
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// `LinkedList` के तत्वों पर एक परिवर्तनशील पुनरावर्तक।
///
/// यह `struct` [`LinkedList::iter_mut()`] द्वारा बनाया गया है।
/// अधिक के लिए इसके दस्तावेज़ देखें।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // हम यहां पूरी सूची के *नहीं* विशेष रूप से स्वामी हैं, नोड के `element` के संदर्भ पुनरावर्तक द्वारा सौंपे गए हैं!तो इसका इस्तेमाल करते समय सावधान रहें;बुलाए गए तरीकों से अवगत होना चाहिए कि `element` में एलियासिंग पॉइंटर्स हो सकते हैं।
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// `LinkedList` के तत्वों पर एक स्वामित्व वाला पुनरावर्तक।
///
/// यह `struct` [`LinkedList`] पर [`into_iter`] विधि द्वारा बनाया गया है (`IntoIterator` trait द्वारा प्रदान किया गया)।
/// अधिक के लिए इसके दस्तावेज़ देखें।
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// निजी तरीके
impl<T> LinkedList<T> {
    /// दिए गए नोड को सूची के सामने जोड़ता है।
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // `element` में अलियासिंग पॉइंटर्स की वैधता बनाए रखने के लिए, यह विधि ध्यान रखती है कि पूरे नोड्स के लिए परस्पर संदर्भ न बनाएं।
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // `element` को ओवरलैप करने वाले नए परिवर्तनशील (unique!) संदर्भ नहीं बनाना।
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// सूची के सामने नोड को हटाता है और वापस करता है।
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // `element` में अलियासिंग पॉइंटर्स की वैधता बनाए रखने के लिए, यह विधि ध्यान रखती है कि पूरे नोड्स के लिए परस्पर संदर्भ न बनाएं।
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // `element` को ओवरलैप करने वाले नए परिवर्तनशील (unique!) संदर्भ नहीं बनाना।
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// दिए गए नोड को सूची के पीछे जोड़ता है।
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // `element` में अलियासिंग पॉइंटर्स की वैधता बनाए रखने के लिए, यह विधि ध्यान रखती है कि पूरे नोड्स के लिए परस्पर संदर्भ न बनाएं।
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // `element` को ओवरलैप करने वाले नए परिवर्तनशील (unique!) संदर्भ नहीं बनाना।
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// सूची के पीछे नोड को हटाता है और वापस करता है।
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // `element` में अलियासिंग पॉइंटर्स की वैधता बनाए रखने के लिए, यह विधि ध्यान रखती है कि पूरे नोड्स के लिए परस्पर संदर्भ न बनाएं।
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // `element` को ओवरलैप करने वाले नए परिवर्तनशील (unique!) संदर्भ नहीं बनाना।
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// निर्दिष्ट नोड को वर्तमान सूची से अलग करता है।
    ///
    /// चेतावनी: यह जाँच नहीं करेगा कि प्रदान किया गया नोड वर्तमान सूची से संबंधित है।
    ///
    /// एलियासिंग पॉइंटर्स की वैधता बनाए रखने के लिए, यह विधि `element` के लिए परस्पर संदर्भ नहीं बनाने का ध्यान रखती है।
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // यह अब हमारा है, हम एक &mut बना सकते हैं।

        // `element` को ओवरलैप करने वाले नए परिवर्तनशील (unique!) संदर्भ नहीं बनाना।
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // यह नोड हेड नोड है
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // यह नोड टेल नोड है
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// दो मौजूदा नोड्स के बीच नोड्स की एक श्रृंखला को विभाजित करता है।
    ///
    /// चेतावनी: यह जाँच नहीं करेगा कि प्रदान किया गया नोड दो मौजूदा सूचियों से संबंधित है।
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // `element` में अलियासिंग पॉइंटर्स की वैधता बनाए रखने के लिए, यह विधि एक ही समय में पूरे नोड्स के लिए एकाधिक परिवर्तनीय संदर्भ नहीं बनाने का ख्याल रखती है।
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// लिंक की गई सूची से सभी नोड्स को नोड्स की एक श्रृंखला के रूप में अलग करता है।
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // स्प्लिट नोड दूसरे भाग का नया हेड नोड है
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // दूसरे भाग के हेड पीटीआर को ठीक करें
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // स्प्लिट नोड पहले भाग का नया टेल नोड है और दूसरे भाग के हेड का मालिक होता है।
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // पहले भाग का टेल पीटीआर ठीक करें
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// एक खाली `LinkedList<T>` बनाता है।
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// एक खाली `LinkedList` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// सभी तत्वों को `other` से सूची के अंत तक ले जाता है।
    ///
    /// यह `other` से सभी नोड्स का पुन: उपयोग करता है और उन्हें `self` में ले जाता है।
    /// इस ऑपरेशन के बाद, `other` खाली हो जाता है।
    ///
    /// इस ऑपरेशन को *O*(1) समय और *O*(1) मेमोरी में परिकलित करना चाहिए।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` यहां ठीक है क्योंकि हमारे पास दोनों सूचियों की संपूर्णता तक विशेष पहुंच है।
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// सभी तत्वों को `other` से सूची की शुरुआत में ले जाता है।
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` यहां ठीक है क्योंकि हमारे पास दोनों सूचियों की संपूर्णता तक विशेष पहुंच है।
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// एक फॉरवर्ड इटरेटर प्रदान करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// परिवर्तनीय संदर्भों के साथ एक फॉरवर्ड इटरेटर प्रदान करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// सामने वाले तत्व पर एक कर्सर प्रदान करता है।
    ///
    /// सूची खाली होने पर कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है।
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// सामने वाले तत्व पर संपादन संचालन के साथ एक कर्सर प्रदान करता है।
    ///
    /// सूची खाली होने पर कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है।
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// पीछे के तत्व पर एक कर्सर प्रदान करता है।
    ///
    /// सूची खाली होने पर कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है।
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// पीछे के तत्व पर संपादन संचालन के साथ एक कर्सर प्रदान करता है।
    ///
    /// सूची खाली होने पर कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है।
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// यदि `LinkedList` खाली है तो `true` लौटाता है।
    ///
    /// इस ऑपरेशन की गणना *O*(1) समय में होनी चाहिए।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// `LinkedList` की लंबाई लौटाता है।
    ///
    /// इस ऑपरेशन की गणना *O*(1) समय में होनी चाहिए।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// `LinkedList` से सभी तत्वों को हटा देता है।
    ///
    /// इस ऑपरेशन को *O*(*n*) समय में गणना करनी चाहिए।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// यदि `LinkedList` में दिए गए मान के बराबर एक तत्व है, तो `true` लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// सूची खाली होने पर सामने वाले तत्व या `None` का संदर्भ प्रदान करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// सूची खाली होने पर सामने वाले तत्व या `None` के लिए एक परिवर्तनीय संदर्भ प्रदान करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// यदि सूची खाली है, तो बैक एलिमेंट या `None` का संदर्भ प्रदान करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// यदि सूची खाली है, तो बैक एलिमेंट या `None` के लिए एक परिवर्तनशील संदर्भ प्रदान करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// सूची में सबसे पहले एक तत्व जोड़ता है।
    ///
    /// इस ऑपरेशन की गणना *O*(1) समय में होनी चाहिए।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// पहले तत्व को हटाता है और इसे वापस करता है, या यदि सूची खाली है तो `None`।
    ///
    ///
    /// इस ऑपरेशन की गणना *O*(1) समय में होनी चाहिए।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// एक सूची के पीछे एक तत्व जोड़ता है।
    ///
    /// इस ऑपरेशन की गणना *O*(1) समय में होनी चाहिए।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// सूची से अंतिम तत्व को हटाता है और इसे वापस करता है, या यदि यह खाली है तो `None`।
    ///
    ///
    /// इस ऑपरेशन की गणना *O*(1) समय में होनी चाहिए।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// दी गई अनुक्रमणिका पर सूची को दो भागों में विभाजित करता है।
    /// दिए गए इंडेक्स के बाद सब कुछ लौटाता है, जिसमें इंडेक्स भी शामिल है।
    ///
    /// इस ऑपरेशन को *O*(*n*) समय में गणना करनी चाहिए।
    ///
    /// # Panics
    ///
    /// Panics अगर `at > len`।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // नीचे, हम शुरू या अंत से `i-1`वें नोड की ओर पुनरावृति करते हैं, जिसके आधार पर यह तेज़ होगा।
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // .skip() (जो एक नई संरचना बनाता है) का उपयोग करने के बजाय, हम मैन्युअल रूप से छोड़ते हैं ताकि हम छोड़ें के कार्यान्वयन विवरण के आधार पर हेड फ़ील्ड तक पहुंच सकें
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // अंत से शुरू करना बेहतर है
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// दिए गए सूचकांक में तत्व को हटाता है और उसे वापस करता है।
    ///
    /// इस ऑपरेशन को *O*(*n*) समय में गणना करनी चाहिए।
    ///
    /// # Panics
    /// Panics अगर>=लेन. पर
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // नीचे, हम दिए गए इंडेक्स पर नोड की ओर फिर से शुरू करते हैं, या तो शुरुआत से या अंत से, जो इस पर निर्भर करता है कि यह तेज़ होगा।
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// एक पुनरावर्तक बनाता है जो यह निर्धारित करने के लिए बंद का उपयोग करता है कि किसी तत्व को हटाया जाना चाहिए या नहीं।
    ///
    /// यदि क्लोजर सही हो जाता है, तो तत्व हटा दिया जाता है और उपज दिया जाता है।
    /// यदि क्लोजर गलत लौटाता है, तो तत्व सूची में बना रहेगा और इटरेटर द्वारा नहीं दिया जाएगा।
    ///
    /// ध्यान दें कि `drain_filter` आपको फिल्टर क्लोजर में प्रत्येक तत्व को म्यूटेट करने देता है, भले ही आप इसे रखना या हटाना चुनते हैं।
    ///
    ///
    /// # Examples
    ///
    /// मूल सूची का पुन: उपयोग करते हुए, सूची को सम और विषम में विभाजित करना:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // उधार के मुद्दों से बचें।
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // उसी लूप को जारी रखें जो हम नीचे करते हैं।यह तभी चलता है जब एक विध्वंसक घबरा जाता है।
                // अगर एक और panics यह निरस्त हो जाएगा।
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // 'ए' प्राप्त करने के लिए एक अनबाउंड जीवनकाल की आवश्यकता है
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // 'ए' प्राप्त करने के लिए एक अनबाउंड जीवनकाल की आवश्यकता है
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // 'ए' प्राप्त करने के लिए एक अनबाउंड जीवनकाल की आवश्यकता है
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // 'ए' प्राप्त करने के लिए एक अनबाउंड जीवनकाल की आवश्यकता है
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// एक `LinkedList` पर एक कर्सर।
///
/// एक `Cursor` एक पुनरावर्तक की तरह है, सिवाय इसके कि यह स्वतंत्र रूप से आगे-पीछे की तलाश कर सकता है।
///
/// कर्सर हमेशा सूची में दो तत्वों के बीच आराम करते हैं, और अनुक्रमणिका तार्किक रूप से गोलाकार तरीके से।
/// इसे समायोजित करने के लिए, एक "ghost" गैर-तत्व है जो सूची के सिर और पूंछ के बीच `None` उत्पन्न करता है।
///
///
/// जब बनाया जाता है, तो कर्सर सूची के सामने शुरू होता है, या यदि सूची खाली है तो "ghost" गैर-तत्व।
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// संपादन कार्यों के साथ `LinkedList` पर एक कर्सर।
///
/// एक `Cursor` एक पुनरावर्तक की तरह है, सिवाय इसके कि यह स्वतंत्र रूप से आगे-पीछे की तलाश कर सकता है, और पुनरावृत्ति के दौरान सूची को सुरक्षित रूप से बदल सकता है।
/// ऐसा इसलिए है क्योंकि इसके प्राप्त संदर्भों का जीवनकाल केवल अंतर्निहित सूची के बजाय अपने स्वयं के जीवनकाल से जुड़ा होता है।
/// इसका मतलब है कि कर्सर एक साथ कई तत्व नहीं दे सकते।
///
/// कर्सर हमेशा सूची में दो तत्वों के बीच आराम करते हैं, और अनुक्रमणिका तार्किक रूप से गोलाकार तरीके से।
/// इसे समायोजित करने के लिए, एक "ghost" गैर-तत्व है जो सूची के सिर और पूंछ के बीच `None` उत्पन्न करता है।
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// `LinkedList` के भीतर कर्सर स्थिति सूचकांक लौटाता है।
    ///
    /// यदि कर्सर वर्तमान में "ghost" गैर-तत्व को इंगित कर रहा है तो यह `None` लौटाता है।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// कर्सर को `LinkedList` के अगले तत्व पर ले जाता है।
    ///
    /// यदि कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है तो यह इसे `LinkedList` के पहले तत्व में ले जाएगा।
    /// यदि यह `LinkedList` के अंतिम तत्व की ओर इशारा कर रहा है तो यह इसे "ghost" गैर-तत्व में ले जाएगा।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // हमारे पास कोई वर्तमान तत्व नहीं था;कर्सर प्रारंभ स्थिति में बैठा था अगला तत्व सूची का प्रमुख होना चाहिए
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // हमारे पास एक पिछला तत्व था, तो चलिए इसके अगले पर चलते हैं
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// कर्सर को `LinkedList` के पिछले तत्व पर ले जाता है।
    ///
    /// यदि कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है तो यह इसे `LinkedList` के अंतिम तत्व पर ले जाएगा।
    /// यदि यह `LinkedList` के पहले तत्व की ओर इशारा कर रहा है तो यह इसे "ghost" गैर-तत्व में ले जाएगा।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // कोई करंट नहीं।हम सूची की शुरुआत में हैं।यील्ड कोई नहीं और अंत तक कूदें।
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // एक पिछला है।इसे प्राप्त करें और पिछले तत्व पर जाएं।
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// उस तत्व का संदर्भ देता है जिसे कर्सर वर्तमान में इंगित कर रहा है।
    ///
    /// यदि कर्सर वर्तमान में "ghost" गैर-तत्व को इंगित कर रहा है तो यह `None` लौटाता है।
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// अगले तत्व का संदर्भ देता है।
    ///
    /// यदि कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है तो यह `LinkedList` का पहला तत्व देता है।
    /// यदि यह `LinkedList` के अंतिम तत्व की ओर इशारा कर रहा है तो यह `None` लौटाता है।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// पिछले तत्व का संदर्भ देता है।
    ///
    /// यदि कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है तो यह `LinkedList` का अंतिम तत्व देता है।
    /// यदि यह `LinkedList` के पहले तत्व की ओर इशारा कर रहा है तो यह `None` लौटाता है।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// `LinkedList` के भीतर कर्सर स्थिति सूचकांक लौटाता है।
    ///
    /// यदि कर्सर वर्तमान में "ghost" गैर-तत्व को इंगित कर रहा है तो यह `None` लौटाता है।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// कर्सर को `LinkedList` के अगले तत्व पर ले जाता है।
    ///
    /// यदि कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है तो यह इसे `LinkedList` के पहले तत्व में ले जाएगा।
    /// यदि यह `LinkedList` के अंतिम तत्व की ओर इशारा कर रहा है तो यह इसे "ghost" गैर-तत्व में ले जाएगा।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // हमारे पास कोई वर्तमान तत्व नहीं था;कर्सर प्रारंभ स्थिति में बैठा था अगला तत्व सूची का प्रमुख होना चाहिए
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // हमारे पास एक पिछला तत्व था, तो चलिए इसके अगले पर चलते हैं
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// कर्सर को `LinkedList` के पिछले तत्व पर ले जाता है।
    ///
    /// यदि कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है तो यह इसे `LinkedList` के अंतिम तत्व पर ले जाएगा।
    /// यदि यह `LinkedList` के पहले तत्व की ओर इशारा कर रहा है तो यह इसे "ghost" गैर-तत्व में ले जाएगा।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // कोई करंट नहीं।हम सूची की शुरुआत में हैं।यील्ड कोई नहीं और अंत तक कूदें।
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // एक पिछला है।इसे प्राप्त करें और पिछले तत्व पर जाएं।
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// उस तत्व का संदर्भ देता है जिसे कर्सर वर्तमान में इंगित कर रहा है।
    ///
    /// यदि कर्सर वर्तमान में "ghost" गैर-तत्व को इंगित कर रहा है तो यह `None` लौटाता है।
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// अगले तत्व का संदर्भ देता है।
    ///
    /// यदि कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है तो यह `LinkedList` का पहला तत्व देता है।
    /// यदि यह `LinkedList` के अंतिम तत्व की ओर इशारा कर रहा है तो यह `None` लौटाता है।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// पिछले तत्व का संदर्भ देता है।
    ///
    /// यदि कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है तो यह `LinkedList` का अंतिम तत्व देता है।
    /// यदि यह `LinkedList` के पहले तत्व की ओर इशारा कर रहा है तो यह `None` लौटाता है।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// वर्तमान तत्व की ओर इशारा करते हुए केवल पढ़ने के लिए कर्सर देता है।
    ///
    /// लौटाए गए `Cursor` का जीवनकाल `CursorMut` के लिए बाध्य है, जिसका अर्थ है कि यह `CursorMut` से आगे नहीं बढ़ सकता है और `CursorMut` `Cursor` के जीवनकाल के लिए जमे हुए है।
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// अब सूची संपादन कार्य

impl<'a, T> CursorMut<'a, T> {
    /// वर्तमान के बाद `LinkedList` में एक नया तत्व सम्मिलित करता है।
    ///
    /// यदि कर्सर "ghost" गैर-तत्व पर इंगित कर रहा है तो नया तत्व `LinkedList` के सामने डाला गया है।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // "ghost" गैर-तत्व का सूचकांक बदल गया है।
                self.index = self.list.len;
            }
        }
    }

    /// वर्तमान से पहले `LinkedList` में एक नया तत्व सम्मिलित करता है।
    ///
    /// यदि कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है तो नया तत्व `LinkedList` के अंत में डाला जाता है।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// `LinkedList` से वर्तमान तत्व को हटाता है।
    ///
    /// हटाए गए तत्व को वापस कर दिया जाता है, और कर्सर को `LinkedList` में अगले तत्व की ओर इंगित करने के लिए ले जाया जाता है।
    ///
    ///
    /// यदि कर्सर वर्तमान में "ghost" गैर-तत्व की ओर इशारा कर रहा है तो कोई तत्व नहीं हटाया जाता है और `None` वापस आ जाता है।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// सूची नोड को हटाए बिना वर्तमान तत्व को `LinkedList` से हटा देता है।
    ///
    /// हटाए गए नोड को नए `LinkedList` के रूप में लौटाया जाता है जिसमें केवल यह नोड होता है।
    /// कर्सर को वर्तमान `LinkedList` में अगले तत्व की ओर इंगित करने के लिए ले जाया जाता है।
    ///
    /// यदि कर्सर वर्तमान में "ghost" गैर-तत्व की ओर इशारा कर रहा है तो कोई तत्व नहीं हटाया जाता है और `None` वापस आ जाता है।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// वर्तमान के बाद दिए गए `LinkedList` से तत्वों को सम्मिलित करता है।
    ///
    /// यदि कर्सर "ghost" गैर-तत्व पर इंगित कर रहा है तो नए तत्व `LinkedList` की शुरुआत में डाले जाते हैं।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // "ghost" गैर-तत्व का सूचकांक बदल गया है।
                self.index = self.list.len;
            }
        }
    }

    /// वर्तमान वाले से पहले दिए गए `LinkedList` से तत्वों को सम्मिलित करता है।
    ///
    /// यदि कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है तो नए तत्व `LinkedList` के अंत में डाले जाते हैं।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// वर्तमान तत्व के बाद सूची को दो भागों में विभाजित करता है।
    /// यह कर्सर के बाद सब कुछ से युक्त एक नई सूची लौटाएगा, मूल सूची पहले सब कुछ बरकरार रखेगी।
    ///
    ///
    /// यदि कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है तो `LinkedList` की संपूर्ण सामग्री को स्थानांतरित कर दिया जाता है।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // "ghost" गैर-तत्व का सूचकांक 0 में बदल गया है।
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// सूची को वर्तमान तत्व से पहले दो में विभाजित करता है।
    /// यह एक नई सूची लौटाएगा जिसमें कर्सर से पहले सब कुछ शामिल होगा, मूल सूची के बाद सब कुछ बरकरार रहेगा।
    ///
    ///
    /// यदि कर्सर "ghost" गैर-तत्व की ओर इशारा कर रहा है तो `LinkedList` की संपूर्ण सामग्री को स्थानांतरित कर दिया जाता है।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// LinkedList पर `drain_filter` को कॉल करके निर्मित एक पुनरावर्तक।
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` `element` संदर्भों को अलियासिंग के साथ ठीक है।
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// मूल्य के आधार पर तत्वों को पुनरावृत्त करने वाले तत्वों में सूची का उपभोग करता है।
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// सुनिश्चित करें कि `LinkedList` और इसके केवल-पढ़ने वाले इटरेटर अपने प्रकार के मापदंडों में सहसंयोजक हैं।
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}