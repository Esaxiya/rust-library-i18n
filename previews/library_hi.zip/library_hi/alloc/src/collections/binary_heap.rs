//! बाइनरी हीप के साथ लागू की गई प्राथमिकता कतार।
//!
//! सबसे बड़े तत्व को सम्मिलित करने और पॉप करने में *O*(log(*n*)) समय जटिलता होती है।
//! सबसे बड़े तत्व की जाँच करना *O*(1) है।vector को बाइनरी हीप में कनवर्ट करना इन-प्लेस में किया जा सकता है, और इसमें *O*(*n*) जटिलता है।
//! एक बाइनरी हीप को एक सॉर्ट किए गए vector इन-प्लेस में भी परिवर्तित किया जा सकता है, जिससे इसे *O*(*n*\*log(* n*)) इन-प्लेस हीपसॉर्ट के लिए उपयोग किया जा सकता है।
//!
//! # Examples
//!
//! यह एक बड़ा उदाहरण है जो [shortest path problem][sssp] को [directed graph][dir_graph] पर हल करने के लिए [Dijkstra's algorithm][dijkstra] को लागू करता है।
//!
//! यह दिखाता है कि कस्टम प्रकारों के साथ [`BinaryHeap`] का उपयोग कैसे करें।
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // प्राथमिकता कतार `Ord` पर निर्भर करती है।
//! // trait को स्पष्ट रूप से लागू करें ताकि कतार अधिकतम-ढेर के बजाय न्यूनतम-ढेर बन जाए।
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // ध्यान दें कि हम ऑर्डरिंग को लागतों पर फ़्लिप करते हैं।
//!         // एक टाई के मामले में हम पदों की तुलना करते हैं, `PartialEq` और `Ord` के कार्यान्वयन को सुसंगत बनाने के लिए यह कदम आवश्यक है।
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` लागू करने की भी जरूरत है।
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // छोटे कार्यान्वयन के लिए प्रत्येक नोड को `usize` के रूप में दर्शाया जाता है।
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // दिज्क्स्ट्रा का सबसे छोटा पथ एल्गोरिथ्म।
//!
//! // `start` से प्रारंभ करें और प्रत्येक नोड के लिए वर्तमान न्यूनतम दूरी को ट्रैक करने के लिए `dist` का उपयोग करें।यह कार्यान्वयन स्मृति-कुशल नहीं है क्योंकि यह कतार में डुप्लिकेट नोड्स छोड़ सकता है।
//! //
//! // यह सरल कार्यान्वयन के लिए `usize::MAX` को एक प्रहरी मूल्य के रूप में भी उपयोग करता है।
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // डिस्ट [नोड]= `start` से `node`. तक की वर्तमान सबसे छोटी दूरी
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // हम शून्य लागत के साथ `start` पर हैं
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // पहले कम लागत वाले नोड्स के साथ सीमा की जांच करें (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // वैकल्पिक रूप से हम सभी सबसे छोटे रास्तों को खोजना जारी रख सकते थे
//!         if position == goal { return Some(cost); }
//!
//!         // महत्वपूर्ण है क्योंकि हमें पहले से ही एक बेहतर तरीका मिल गया होगा
//!         if cost > dist[position] { continue; }
//!
//!         // प्रत्येक नोड के लिए हम पहुंच सकते हैं, देखें कि क्या हम इस नोड से गुजरने वाली कम लागत के साथ कोई रास्ता खोज सकते हैं
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // अगर ऐसा है, तो इसे सीमांत में जोड़ें और जारी रखें
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // आराम, अब हमें एक बेहतर तरीका मिल गया है
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // लक्ष्य तक नहीं पहुंचा जा सकता
//!     None
//! }
//!
//! fn main() {
//!     // यह निर्देशित ग्राफ है जिसका हम उपयोग करने जा रहे हैं।
//!     // नोड संख्याएं अलग-अलग राज्यों से मेल खाती हैं, और edge वज़न एक नोड से दूसरे नोड में जाने की लागत का प्रतीक है।
//!     //
//!     // ध्यान दें कि किनारे एकतरफा हैं।
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          वी 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // ग्राफ़ को एक आसन्न सूची के रूप में दर्शाया जाता है जहां प्रत्येक इंडेक्स, नोड मान के अनुरूप, आउटगोइंग किनारों की एक सूची होती है।
//!     // दक्षता के लिए चुना गया है।
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // नोड 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // नोड 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // नोड 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // नोड 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // नोड 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// बाइनरी हीप के साथ लागू की गई प्राथमिकता कतार।
///
/// यह एक अधिकतम ढेर होगा।
///
/// किसी आइटम को इस तरह संशोधित करने के लिए यह एक तर्क त्रुटि है कि किसी अन्य आइटम के सापेक्ष आइटम का क्रम, जैसा कि `Ord` trait द्वारा निर्धारित किया गया है, ढेर में होने पर बदल जाता है।
///
/// यह सामान्य रूप से केवल `Cell`, `RefCell`, वैश्विक स्थिति, I/O, या असुरक्षित कोड के माध्यम से ही संभव है।
/// ऐसी तर्क त्रुटि से उत्पन्न व्यवहार निर्दिष्ट नहीं है, लेकिन इसके परिणामस्वरूप अपरिभाषित व्यवहार नहीं होगा।
/// इसमें panics, गलत परिणाम, गर्भपात, मेमोरी लीक और गैर-समाप्ति शामिल हो सकते हैं।
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // प्रकार का अनुमान हमें एक स्पष्ट प्रकार के हस्ताक्षर को छोड़ देता है (जो इस उदाहरण में `BinaryHeap<i32>` होगा)।
/////
/// let mut heap = BinaryHeap::new();
///
/// // हम ढेर में अगले आइटम को देखने के लिए झांकना का उपयोग कर सकते हैं।
/// // इस मामले में, वहाँ अभी तक कोई आइटम नहीं है इसलिए हमें कोई नहीं मिलता है।
/// assert_eq!(heap.peek(), None);
///
/// // आइए कुछ अंक जोड़ें...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // अब झांकना ढेर में सबसे महत्वपूर्ण वस्तु दिखाता है।
/// assert_eq!(heap.peek(), Some(&5));
///
/// // हम ढेर की लंबाई की जांच कर सकते हैं।
/// assert_eq!(heap.len(), 3);
///
/// // हम ढेर में वस्तुओं पर पुनरावृति कर सकते हैं, हालांकि उन्हें एक यादृच्छिक क्रम में वापस कर दिया जाता है।
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // यदि हम इसके बजाय इन अंकों को पॉप करते हैं, तो उन्हें क्रम में वापस आना चाहिए।
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // हम किसी भी शेष वस्तुओं के ढेर को साफ कर सकते हैं।
/// heap.clear();
///
/// // ढेर अब खाली होना चाहिए।
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// `BinaryHeap` को मिन-हीप बनाने के लिए या तो `std::cmp::Reverse` या कस्टम `Ord` कार्यान्वयन का उपयोग किया जा सकता है।
/// इससे `heap.pop()` सबसे बड़े मान के बजाय सबसे छोटा मान लौटाता है।
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // `Reverse` में मान लपेटें
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // यदि हम इन अंकों को अभी पॉप करते हैं, तो उन्हें उल्टे क्रम में वापस आना चाहिए।
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # समय जटिलता
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push` का मान एक अपेक्षित लागत है;विधि प्रलेखन अधिक विस्तृत विश्लेषण देता है।
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// `BinaryHeap` पर सबसे बड़ी वस्तु के लिए एक परिवर्तनीय संदर्भ लपेटने वाली संरचना।
///
///
/// यह `struct` [`BinaryHeap`] पर [`peek_mut`] विधि द्वारा बनाया गया है।
/// अधिक के लिए इसके दस्तावेज़ देखें।
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // सुरक्षा: PeekMut केवल गैर-खाली ढेर के लिए तत्काल है।
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // सुरक्षित: PeekMut केवल गैर-खाली ढेर के लिए तत्काल है
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // सुरक्षित: PeekMut केवल गैर-खाली ढेर के लिए तत्काल है
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// ढेर से पीक मूल्य को हटाता है और इसे वापस करता है।
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// एक खाली `BinaryHeap<T>` बनाता है।
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// अधिकतम-ढेर के रूप में एक खाली `BinaryHeap` बनाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// एक विशिष्ट क्षमता के साथ एक खाली `BinaryHeap` बनाता है।
    /// यह `capacity` तत्वों के लिए पर्याप्त मेमोरी को पूर्व-आवंटित करता है, ताकि `BinaryHeap` को तब तक पुन: आवंटित न करना पड़े जब तक कि इसमें कम से कम इतने मान न हों।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// बाइनरी हीप में सबसे बड़ी वस्तु के लिए एक परिवर्तनशील संदर्भ देता है, या यदि यह खाली है तो `None`।
    ///
    /// Note: यदि `PeekMut` मान लीक हो गया है, तो हीप असंगत स्थिति में हो सकता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # समय जटिलता
    ///
    /// यदि आइटम संशोधित किया गया है तो सबसे खराब स्थिति समय जटिलता *O*(log(*n*)) है, अन्यथा यह *O*(1) है।
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// बाइनरी हीप से सबसे बड़ी वस्तु को हटाता है और इसे वापस करता है, या यदि यह खाली है तो `None`।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # समय जटिलता
    ///
    /// *n* तत्वों वाले ढेर पर `pop` की सबसे खराब स्थिति लागत *O*(log(*n*)) है।
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // सुरक्षा: !self.is_empty() का अर्थ है कि self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// किसी आइटम को बाइनरी हीप पर पुश करता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # समय जटिलता
    ///
    /// `push` की अपेक्षित लागत, धकेले जा रहे तत्वों के हर संभव क्रम पर और पर्याप्त रूप से बड़ी संख्या में धक्का देने पर,*O*(1) है।
    ///
    /// यह सबसे सार्थक लागत मीट्रिक है जब उन तत्वों को आगे बढ़ाया जाता है जो पहले से किसी भी क्रमबद्ध पैटर्न में *नहीं* हैं।
    ///
    /// यदि तत्वों को मुख्य रूप से आरोही क्रम में धकेला जाता है, तो समय की जटिलता कम हो जाती है।
    /// सबसे खराब स्थिति में, तत्वों को आरोही क्रमबद्ध क्रम में धकेला जाता है और *n* तत्वों वाले ढेर के मुकाबले प्रति पुश परिशोधन लागत *O*(log(*n*)) है।
    ///
    /// `push` को *सिंगल* कॉल की सबसे खराब स्थिति है *O*(*n*)।सबसे खराब स्थिति तब होती है जब क्षमता समाप्त हो जाती है और उसे आकार बदलने की आवश्यकता होती है।
    /// पिछले आंकड़ों में आकार बदलने की लागत का परिशोधन किया गया है।
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // सुरक्षा: चूंकि हमने एक नई वस्तु को आगे बढ़ाया है, इसका मतलब है कि
        //  Old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// `BinaryHeap` का उपभोग करता है और सॉर्ट किए गए (ascending) क्रम में vector लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // सुरक्षा: `end` `self.len() - 1` से 1 (दोनों शामिल) तक जाता है,
            //  इसलिए यह हमेशा एक्सेस करने के लिए एक वैध अनुक्रमणिका है।
            //  इंडेक्स 0 (यानी `ptr`) तक पहुंचना सुरक्षित है, क्योंकि
            //  1 <=अंत <self.len(), जिसका अर्थ है self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // सुरक्षा: `end` `self.len() - 1` से 1 (दोनों शामिल) तक जाता है, इसलिए:
            //  0 <1 <=अंत <= self.len(), 1 <self.len() जिसका अर्थ है 0 <अंत और अंत <self.len()।
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // vector (एक छेद के पीछे छोड़कर) से एक तत्व को स्थानांतरित करने के लिए sift_up और sift_down के कार्यान्वयन असुरक्षित ब्लॉक का उपयोग करते हैं, दूसरों के साथ स्थानांतरित करते हैं और हटाए गए तत्व को छेद के अंतिम स्थान पर vector में वापस ले जाते हैं।
    //
    // `Hole` प्रकार का उपयोग इसका प्रतिनिधित्व करने के लिए किया जाता है, और सुनिश्चित करें कि छेद को इसके दायरे के अंत में वापस भर दिया गया है, यहां तक कि panic पर भी।
    // एक छेद का उपयोग करने से स्वैप का उपयोग करने की तुलना में स्थिर कारक कम हो जाता है, जिसमें दो बार कई चालें शामिल होती हैं।
    //
    //
    //
    //

    /// # Safety
    ///
    /// कॉल करने वाले को यह गारंटी देनी होगी कि `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // `pos` पर मान निकालें और एक छेद बनाएं।
        // सुरक्षा: कॉलर गारंटी देता है कि स्थिति <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // सुरक्षा: hole.pos()> प्रारंभ>=0, जिसका अर्थ है hole.pos()> 0
            //  और इसलिए hole.pos(), 1 अंडरफ्लो नहीं हो सकता।
            //  यह गारंटी देता है कि माता-पिता <hole.pos() तो यह एक मान्य अनुक्रमणिका है और != hole.pos() भी।
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // सुरक्षा: ऊपर के समान
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// `pos` पर एक तत्व लें और इसे ढेर के नीचे ले जाएं, जबकि इसके बच्चे बड़े होते हैं।
    ///
    ///
    /// # Safety
    ///
    /// कॉल करने वाले को यह गारंटी देनी होगी कि `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // सुरक्षा: कॉलर गारंटी देता है कि pos <end <= self.len()।
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // लूप अपरिवर्तनीय: बच्चा==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // दो बच्चों में से बड़े के साथ तुलना करें सुरक्षा: बच्चा <अंत, 1 <self.len() और बच्चा + 1 <अंत <= self.len(), इसलिए वे मान्य अनुक्रमणिका हैं।
            //
            //  बच्चा==2 *hole.pos() + 1!= hole.pos() और बच्चा + 1==2* hole.pos() + 2!= hole.pos()।
            // FIXME: 2 *hole.pos() + 1 या 2* hole.pos() + 2 ओवरफ्लो हो सकता है यदि T एक ZST है
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // अगर हम पहले से ही क्रम में हैं, तो रुक जाओ।
            // सुरक्षा: बच्चा अब या तो बड़ा बच्चा है या बड़ा बच्चा+1
            //  हम पहले ही सिद्ध कर चुके हैं कि दोनों <self.len() और != hole.pos(). हैं
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // सुरक्षा: ऊपर के समान।
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // सुरक्षा: &&शॉर्ट सर्किट, जिसका अर्थ है कि में
        //  दूसरी शर्त यह पहले से ही सच है कि बच्चा==अंत, 1 <self.len()।
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // सुरक्षा: बच्चा पहले से ही एक वैध सूचकांक साबित हो चुका है और
            //  बच्चा==2 * hole.pos() + 1!= hole.pos()।
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// कॉल करने वाले को यह गारंटी देनी होगी कि `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // सुरक्षा: pos <लेन की गारंटी कॉलर द्वारा दी जाती है और
        //  स्पष्ट रूप से लेन= self.len() <= self.len()।
        unsafe { self.sift_down_range(pos, len) };
    }

    /// `pos` पर एक तत्व लें और इसे ढेर के नीचे ले जाएं, फिर इसे अपनी स्थिति तक ले जाएं।
    ///
    ///
    /// Note: यह तब तेज होता है जब तत्व को बड़ा माना जाता है/नीचे के करीब होना चाहिए।
    ///
    /// # Safety
    ///
    /// कॉल करने वाले को यह गारंटी देनी होगी कि `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // सुरक्षा: कॉलर गारंटी देता है कि स्थिति <self.len()।
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // लूप अपरिवर्तनीय: बच्चा==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // सुरक्षा: बच्चा <अंत, 1 <self.len() और
            //  चाइल्ड + 1 <एंड <= self.len(), इसलिए वे मान्य इंडेक्स हैं।
            //  बच्चा==2 *hole.pos() + 1!= hole.pos() और बच्चा + 1==2* hole.pos() + 2!= hole.pos()।
            //
            // FIXME: 2 *hole.pos() + 1 या 2* hole.pos() + 2 ओवरफ्लो हो सकता है यदि T एक ZST है
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // सुरक्षा: ऊपर के समान
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // सुरक्षा: बच्चा==अंत, 1 <self.len(), इसलिए यह एक मान्य सूचकांक है
            //  और बच्चा==2 * hole.pos() + 1!= hole.pos()।
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // सुरक्षा: स्थिति छेद में स्थिति है और पहले ही सिद्ध हो चुकी है
        //  एक वैध सूचकांक होने के लिए।
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // सुरक्षा: n self.len()/2 से शुरू होता है और 0 तक नीचे जाता है।
            //  एकमात्र मामला जब !(n <self.len()) यदि self.len() ==0 है, लेकिन इसे लूप की स्थिति से बाहर रखा गया है।
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// `other` के सभी तत्वों को `self` में ले जाता है, `other` को खाली छोड़ देता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` O(len1 + len2) संचालन लेता है और सबसे खराब स्थिति में लगभग 2 *(len1 + len2) तुलना करता है जबकि `extend` O(len2* log(len1)) संचालन लेता है और सबसे खराब स्थिति में लगभग 1 *len2* log_2(len1) तुलना करता है, len1>= len2 मानते हुए।
        // बड़े ढेर के लिए, क्रॉसओवर बिंदु अब इस तर्क का पालन नहीं करता है और अनुभवजन्य रूप से निर्धारित किया गया था।
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// एक पुनरावर्तक देता है जो तत्वों को ढेर क्रम में पुनर्प्राप्त करता है।
    /// पुनर्प्राप्त तत्व मूल ढेर से हटा दिए जाते हैं।
    /// शेष तत्वों को ढेर क्रम में गिरावट पर हटा दिया जाएगा।
    ///
    /// Note:
    /// * `.drain_sorted()` है *O*(*n*\*log(* n*)); `.drain()` की तुलना में बहुत धीमा।
    ///   आपको ज्यादातर मामलों के लिए बाद वाले का उपयोग करना चाहिए।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // ढेर क्रम में सभी तत्वों को हटा देता है
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// केवल विधेय द्वारा निर्दिष्ट तत्वों को बरकरार रखता है।
    ///
    /// दूसरे शब्दों में, सभी तत्वों को हटा दें `e` जैसे कि `f(&e)` `false` लौटाता है।
    /// तत्वों को अवर्गीकृत (और अनिर्दिष्ट) क्रम में देखा जाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // केवल सम संख्याएँ रखें
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// अंतर्निहित vector में सभी मानों पर मनमाना क्रम में विज़िट करने वाला एक पुनरावर्तक लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4 को मनमाना क्रम में प्रिंट करें
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// एक पुनरावर्तक देता है जो तत्वों को ढेर क्रम में पुनर्प्राप्त करता है।
    /// यह विधि मूल ढेर का उपभोग करती है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// बाइनरी हीप में सबसे बड़ा आइटम लौटाता है, या यदि यह खाली है तो `None` देता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # समय जटिलता
    ///
    /// सबसे खराब स्थिति में लागत *O*(1) है।
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// उन तत्वों की संख्या लौटाता है जिन्हें बाइनरी हीप पुन: आवंटित किए बिना धारण कर सकता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// दिए गए `BinaryHeap` में सटीक रूप से `additional` अधिक तत्वों को सम्मिलित करने के लिए न्यूनतम क्षमता सुरक्षित रखता है।
    /// अगर क्षमता पहले से ही पर्याप्त है तो कुछ भी नहीं करता है।
    ///
    /// ध्यान दें कि आवंटक संग्रह को अनुरोध से अधिक स्थान दे सकता है।
    /// इसलिए क्षमता को ठीक न्यूनतम होने पर भरोसा नहीं किया जा सकता है।
    /// [`reserve`] को प्राथमिकता दें यदि future सम्मिलन अपेक्षित हैं।
    ///
    /// # Panics
    ///
    /// Panics यदि नई क्षमता `usize` से अधिक हो जाती है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// `BinaryHeap` में कम से कम `additional` अधिक तत्वों को सम्मिलित करने की क्षमता सुरक्षित रखता है।
    /// बार-बार पुन: आवंटन से बचने के लिए संग्रह अधिक स्थान आरक्षित कर सकता है।
    ///
    /// # Panics
    ///
    /// Panics यदि नई क्षमता `usize` से अधिक हो जाती है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// जितना संभव हो उतना अतिरिक्त क्षमता त्यागें।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// निचली सीमा के साथ क्षमता को त्यागें।
    ///
    /// क्षमता कम से कम लंबाई और आपूर्ति मूल्य दोनों जितनी बड़ी रहेगी।
    ///
    ///
    /// यदि वर्तमान क्षमता निचली सीमा से कम है, तो यह नो-ऑप है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// `BinaryHeap` का उपभोग करता है और अंतर्निहित vector को मनमाने क्रम में लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // किसी क्रम में प्रिंट करेंगे
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// बाइनरी हीप की लंबाई लौटाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// जाँचता है कि बाइनरी हीप खाली है या नहीं।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// बाइनरी ढेर को साफ़ करता है, हटाए गए तत्वों पर एक पुनरावर्तक लौटाता है।
    ///
    /// तत्वों को मनमाने क्रम में हटा दिया जाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// बाइनरी हीप से सभी आइटम ड्रॉप करें।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// होल एक स्लाइस में एक छेद का प्रतिनिधित्व करता है, यानी, बिना वैध मूल्य के एक सूचकांक (क्योंकि इसे स्थानांतरित या डुप्लिकेट किया गया था)।
///
/// ड्रॉप में, `Hole` मूल रूप से हटाए गए मान के साथ छेद की स्थिति भरकर स्लाइस को पुनर्स्थापित करेगा।
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// इंडेक्स `pos` पर एक नया `Hole` बनाएं।
    ///
    /// असुरक्षित क्योंकि पॉज़ डेटा स्लाइस के भीतर होना चाहिए।
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // सुरक्षित: पॉज़ स्लाइस के अंदर होना चाहिए
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// हटाए गए तत्व का संदर्भ देता है।
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// `index` पर तत्व का संदर्भ देता है।
    ///
    /// असुरक्षित क्योंकि इंडेक्स डेटा स्लाइस के भीतर होना चाहिए और पॉज़ के बराबर नहीं होना चाहिए।
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// छेद को नए स्थान पर ले जाएं
    ///
    /// असुरक्षित क्योंकि इंडेक्स डेटा स्लाइस के भीतर होना चाहिए और पॉज़ के बराबर नहीं होना चाहिए।
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // छेद को फिर से भरें
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// `BinaryHeap` के तत्वों पर एक पुनरावर्तक।
///
/// यह `struct` [`BinaryHeap::iter()`] द्वारा बनाया गया है।
/// अधिक के लिए इसके दस्तावेज़ देखें।
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]`. के पक्ष में निकालें
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// `BinaryHeap` के तत्वों पर एक स्वामित्व वाला पुनरावर्तक।
///
/// यह `struct` [`BinaryHeap::into_iter()`] (`IntoIterator` trait द्वारा प्रदान किया गया) द्वारा बनाया गया है।
/// अधिक के लिए इसके दस्तावेज़ देखें।
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// एक `BinaryHeap` के तत्वों पर एक जल निकासी पुनरावर्तक।
///
/// यह `struct` [`BinaryHeap::drain()`] द्वारा बनाया गया है।
/// अधिक के लिए इसके दस्तावेज़ देखें।
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// एक `BinaryHeap` के तत्वों पर एक जल निकासी पुनरावर्तक।
///
/// यह `struct` [`BinaryHeap::drain_sorted()`] द्वारा बनाया गया है।
/// अधिक के लिए इसके दस्तावेज़ देखें।
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// ढेर तत्वों को ढेर क्रम में हटा देता है।
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// `Vec<T>` को `BinaryHeap<T>` में कनवर्ट करता है।
    ///
    /// यह रूपांतरण जगह में होता है, और इसमें *O*(*n*) समय जटिलता होती है।
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// `BinaryHeap<T>` को `Vec<T>` में कनवर्ट करता है।
    ///
    /// इस रूपांतरण के लिए किसी डेटा आंदोलन या आवंटन की आवश्यकता नहीं होती है, और इसमें निरंतर समय जटिलता होती है।
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// एक उपभोग करने वाला इटरेटर बनाता है, जो कि प्रत्येक मान को बाइनरी हीप से मनमाने क्रम में ले जाता है।
    /// इसे कॉल करने के बाद बाइनरी हीप का उपयोग नहीं किया जा सकता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4 को मनमाना क्रम में प्रिंट करें
    /// for x in heap.into_iter() {
    ///     // x का प्रकार i32 है, न कि &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}