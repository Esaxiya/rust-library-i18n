//! एक डबल-एंडेड कतार एक बढ़ने योग्य रिंग बफर के साथ लागू की गई।
//!
//! इस कतार में कंटेनर के दोनों सिरों से *O*(1) परिशोधित इन्सर्ट और रिमूवल हैं।
//! इसमें vector की तरह *O*(1) इंडेक्सिंग भी है।
//! निहित तत्वों को कॉपी करने योग्य होने की आवश्यकता नहीं है, और यदि निहित प्रकार भेजने योग्य है तो कतार भेजने योग्य होगी।
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2^3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // दो की सबसे बड़ी संभव शक्ति

/// एक डबल-एंडेड कतार एक बढ़ने योग्य रिंग बफर के साथ लागू की गई।
///
/// कतार के रूप में इस प्रकार का "default" उपयोग कतार में जोड़ने के लिए [`push_back`] और कतार से निकालने के लिए [`pop_front`] का उपयोग करना है।
///
/// [`extend`] और [`append`] इस तरह से पीछे की ओर धकेलता है, और `VecDeque` पर पुनरावृति आगे से पीछे की ओर जाती है।
///
/// चूंकि `VecDeque` एक रिंग बफर है, इसके तत्व जरूरी नहीं कि मेमोरी में सन्निहित हों।
/// यदि आप तत्वों को एकल स्लाइस के रूप में एक्सेस करना चाहते हैं, जैसे कि कुशल सॉर्टिंग के लिए, आप [`make_contiguous`] का उपयोग कर सकते हैं।
/// यह `VecDeque` को घुमाता है ताकि इसके तत्व लपेटे नहीं, और अब-सन्निहित तत्व अनुक्रम में एक परिवर्तनशील टुकड़ा लौटाता है।
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // पूंछ और सिर बफर में पॉइंटर्स हैं।
    // टेल हमेशा पहले तत्व की ओर इशारा करता है जिसे पढ़ा जा सकता है, हेड हमेशा इंगित करता है कि डेटा कहाँ लिखा जाना चाहिए।
    //
    // यदि पूंछ==सिर बफर खाली है।रिंगबफर की लंबाई को दोनों के बीच की दूरी के रूप में परिभाषित किया गया है।
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// स्लाइस में सभी वस्तुओं के लिए विनाशक चलाता है जब इसे गिरा दिया जाता है (सामान्य रूप से या खोलने के दौरान)।
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // [T]. के लिए ड्रॉप का उपयोग करें
            ptr::drop_in_place(front);
        }
        // RawVec डीललोकेशन को संभालता है
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// एक खाली `VecDeque<T>` बनाता है।
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// मामूली रूप से अधिक सुविधाजनक
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// मामूली रूप से अधिक सुविधाजनक
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // शून्य आकार के प्रकारों के लिए, हम हमेशा अधिकतम क्षमता पर होते हैं
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// पीटीआर को एक स्लाइस में बदल दें
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// पीटीआर को म्यूट स्लाइस में बदल दें
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// किसी तत्व को बफ़र से बाहर ले जाता है
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// एक तत्व को बफर में लिखता है, इसे स्थानांतरित करता है।
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// यदि बफ़र पूर्ण क्षमता पर है तो `true` लौटाता है।
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// किसी दिए गए तार्किक तत्व अनुक्रमणिका के लिए अंतर्निहित बफ़र में अनुक्रमणिका लौटाता है।
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// किसी दिए गए लॉजिकल एलिमेंट इंडेक्स + एडेंड के लिए अंतर्निहित बफर में इंडेक्स लौटाता है।
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// किसी दिए गए लॉजिकल एलीमेंट इंडेक्स, सबट्रेंड के लिए अंतर्निहित बफर में इंडेक्स लौटाता है।
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// src से dst. तक लंबे मेमोरी लेन के एक सन्निहित ब्लॉक की प्रतिलिपि बनाता है
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src से dst. तक लंबे मेमोरी लेन के एक सन्निहित ब्लॉक की प्रतिलिपि बनाता है
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// मेमोरी लेन के संभावित रैपिंग ब्लॉक को src से डेस्ट तक कॉपी करता है।
    /// (abs(dst - src) + लेन) cap() से बड़ा नहीं होना चाहिए (src और गंतव्य के बीच अधिकतम एक निरंतर अतिव्यापी क्षेत्र होना चाहिए)।
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src लपेटता नहीं है, dst लपेटता नहीं है
                //
                //        एस...
                // 1 [_ _ A A B B C C _]
                // 2 एक्स 00 एक्स डी।
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // src से पहले dst, src लपेटता नहीं है, dst लपेटता है
                //
                //
                //    एस...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. डी।
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // dst से पहले src, src लपेटता नहीं है, dst लपेटता है
                //
                //
                //              एस...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. डी।
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // src से पहले dst, src लपेटता है, dst लपेटता नहीं है
                //
                //
                //    .. एस.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 एक्स 00 एक्स डी।..
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // dst से पहले src, src लपेटता है, dst लपेटता नहीं है
                //
                //
                //    .. एस.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 एक्स 00 एक्स डी।..
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // src से पहले dst, src रैप्स, dst रैप्स
                //
                //
                //    ... एस.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. डी।.
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src dst से पहले, src रैप्स, dst रैप्स
                //
                //
                //    .. एस..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 एक्स 00 एक्स।.. डी।
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// इस तथ्य को संभालने के लिए कि हमने अभी-अभी पुनः आवंटित किया है, सिर और पूंछ के खंडों को चारों ओर घुमाता है।
    /// असुरक्षित क्योंकि यह पुरानी_क्षमता पर भरोसा करता है।
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // रिंग बफ़र के सबसे छोटे सन्निहित भाग को खिसकाएँ TH
        //
        //   [o o o o o o o . ]
        //    था [o o o o o o o . . . . . . . . . ] एचटी
        //   [o o . o o o o o ]
        //          टीएचबी [...ऊऊऊ.....
        //          ] एचटी
        //   [o o o o o . o o ]
        //              एचटीसी [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // ए नोपो
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// एक खाली `VecDeque` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// कम से कम `capacity` तत्वों के लिए स्थान के साथ एक खाली `VecDeque` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 चूंकि रिंगबफर हमेशा एक स्थान खाली छोड़ता है
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// दिए गए सूचकांक में तत्व का संदर्भ प्रदान करता है।
    ///
    /// इंडेक्स 0 पर एलिमेंट कतार में सबसे आगे है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// दिए गए सूचकांक में तत्व के लिए एक परिवर्तनीय संदर्भ प्रदान करता है।
    ///
    /// इंडेक्स 0 पर एलिमेंट कतार में सबसे आगे है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// सूचकांक `i` और `j` पर तत्वों को स्वैप करें।
    ///
    /// `i` और `j` बराबर हो सकता है।
    ///
    /// इंडेक्स 0 पर एलिमेंट कतार में सबसे आगे है।
    ///
    /// # Panics
    ///
    /// Panics यदि दोनों में से कोई भी सूचकांक सीमा से बाहर है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// उन तत्वों की संख्या लौटाता है जिन्हें `VecDeque` पुनः आवंटित किए बिना धारण कर सकता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// दिए गए `VecDeque` में बिल्कुल `additional` अधिक तत्वों को सम्मिलित करने के लिए न्यूनतम क्षमता सुरक्षित रखता है।
    /// अगर क्षमता पहले से ही पर्याप्त है तो कुछ भी नहीं करता है।
    ///
    /// ध्यान दें कि आवंटक संग्रह को अनुरोध से अधिक स्थान दे सकता है।
    /// इसलिए क्षमता को ठीक न्यूनतम होने पर भरोसा नहीं किया जा सकता है।
    /// [`reserve`] को प्राथमिकता दें यदि future सम्मिलन अपेक्षित हैं।
    ///
    /// # Panics
    ///
    /// Panics यदि नई क्षमता `usize` से अधिक हो जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// दिए गए `VecDeque` में कम से कम `additional` अधिक तत्वों को सम्मिलित करने की क्षमता सुरक्षित रखता है।
    /// बार-बार पुन: आवंटन से बचने के लिए संग्रह अधिक स्थान आरक्षित कर सकता है।
    ///
    /// # Panics
    ///
    /// Panics यदि नई क्षमता `usize` से अधिक हो जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// दिए गए `VecDeque<T>` में बिल्कुल `additional` अधिक तत्वों को सम्मिलित करने के लिए न्यूनतम क्षमता आरक्षित करने का प्रयास करता है।
    ///
    /// `try_reserve_exact` को कॉल करने के बाद, क्षमता `self.len() + additional` से अधिक या उसके बराबर होगी।
    /// अगर क्षमता पहले से ही पर्याप्त है तो कुछ भी नहीं करता है।
    ///
    /// ध्यान दें कि आवंटक संग्रह को अनुरोध से अधिक स्थान दे सकता है।
    /// इसलिए, क्षमता को ठीक न्यूनतम होने पर भरोसा नहीं किया जा सकता है।
    /// `reserve` को प्राथमिकता दें यदि future सम्मिलन अपेक्षित हैं।
    ///
    /// # Errors
    ///
    /// यदि क्षमता `usize` से अधिक हो जाती है, या आवंटक विफलता की रिपोर्ट करता है, तो एक त्रुटि वापस आ जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // मेमोरी को प्री-रिजर्व करें, अगर हम नहीं कर सकते हैं तो बाहर निकलें
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // अब हम जानते हैं कि यह हमारे जटिल कार्य के बीच में OOM(Out-Of-Memory) नहीं हो सकता
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // बहुत जटिल
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// दिए गए `VecDeque<T>` में कम से कम `additional` अधिक तत्वों को सम्मिलित करने के लिए क्षमता आरक्षित करने का प्रयास करता है।
    /// बार-बार पुन: आवंटन से बचने के लिए संग्रह अधिक स्थान आरक्षित कर सकता है।
    /// `try_reserve` को कॉल करने के बाद, क्षमता `self.len() + additional` से अधिक या उसके बराबर होगी।
    /// अगर क्षमता पहले से ही पर्याप्त है तो कुछ नहीं करता।
    ///
    /// # Errors
    ///
    /// यदि क्षमता `usize` से अधिक हो जाती है, या आवंटक विफलता की रिपोर्ट करता है, तो एक त्रुटि वापस आ जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // मेमोरी को प्री-रिजर्व करें, अगर हम नहीं कर सकते हैं तो बाहर निकलें
    ///     output.try_reserve(data.len())?;
    ///
    ///     // अब हम जानते हैं कि यह हमारे जटिल कार्य के बीच में OOM नहीं कर सकता
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // बहुत जटिल
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// जितना संभव हो `VecDeque` की क्षमता को सिकोड़ें।
    ///
    /// यह लंबाई के जितना करीब हो सके नीचे गिर जाएगा लेकिन आवंटक अभी भी `VecDeque` को सूचित कर सकता है कि कुछ और तत्वों के लिए जगह है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// `VecDeque` की क्षमता को कम सीमा के साथ सिकोड़ता है।
    ///
    /// क्षमता कम से कम लंबाई और आपूर्ति मूल्य दोनों जितनी बड़ी रहेगी।
    ///
    ///
    /// यदि वर्तमान क्षमता निचली सीमा से कम है, तो यह नो-ऑप है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // हमें अतिप्रवाह के बारे में चिंता करने की आवश्यकता नहीं है क्योंकि न तो `self.len()` और न ही `self.capacity()` कभी भी `usize::MAX` हो सकते हैं।
        // +1 क्योंकि रिंगबफर हमेशा एक स्थान खाली छोड़ता है।
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // ब्याज के तीन मामले हैं:
            //   सभी तत्व वांछित सीमा से बाहर हैं, तत्व सन्निहित हैं, और सिर वांछित सीमा से बाहर है तत्व असंबद्ध हैं, और पूंछ वांछित सीमा से बाहर है
            //
            //
            // अन्य सभी समयों पर, तत्व की स्थिति अप्रभावित रहती है।
            //
            // इंगित करता है कि सिर पर तत्वों को स्थानांतरित किया जाना चाहिए।
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // तत्वों को वांछित सीमा से बाहर ले जाएं (लक्ष्य_कैप के बाद की स्थिति)
            if self.tail >= target_cap && head_outside {
                // वें
                //   [. . . . . . . . o o o o o o o . ]
                //    वें
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // वें
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // हिंदुस्तान टाइम्स
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// `VecDeque` को छोटा करता है, पहले `len` तत्वों को रखता है और बाकी को छोड़ देता है।
    ///
    ///
    /// यदि `len` `VecDeque` की वर्तमान लंबाई से अधिक है, तो इसका कोई प्रभाव नहीं पड़ता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// स्लाइस में सभी वस्तुओं के लिए विनाशक चलाता है जब इसे गिरा दिया जाता है (सामान्य रूप से या खोलने के दौरान)।
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // सुरक्षित क्योंकि:
        //
        // * `drop_in_place` को दिया गया कोई भी टुकड़ा मान्य है;दूसरे मामले में `len <= front.len()` है और `len > self.len()` पर लौटने से पहले मामले में `begin <= back.len()` सुनिश्चित होता है
        //
        // * `drop_in_place` को कॉल करने से पहले VecDeque के प्रमुख को स्थानांतरित किया जाता है, इसलिए यदि `drop_in_place` panics कोई मान दो बार गिराया नहीं जाता है
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // सुनिश्चित करें कि दूसरी छमाही को तब भी गिराया जाता है जब पहले panics में एक विध्वंसक होता है।
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// एक फ्रंट-टू-बैक इटरेटर देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// एक फ्रंट-टू-बैक इटरेटर देता है जो परिवर्तनीय संदर्भ देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // सुरक्षा: आंतरिक `IterMut` सुरक्षा अपरिवर्तनीय स्थापित किया गया है क्योंकि
        // `ring` हम बनाते हैं जीवन भर के लिए एक dereferencable टुकड़ा है '_।
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// स्लाइस की एक जोड़ी देता है जिसमें क्रम में `VecDeque` की सामग्री होती है।
    ///
    /// यदि [`make_contiguous`] को पहले कॉल किया गया था, तो `VecDeque` के सभी तत्व पहले स्लाइस में होंगे और दूसरा स्लाइस खाली होगा।
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// स्लाइस की एक जोड़ी देता है जिसमें क्रम में `VecDeque` की सामग्री होती है।
    ///
    /// यदि [`make_contiguous`] को पहले कॉल किया गया था, तो `VecDeque` के सभी तत्व पहले स्लाइस में होंगे और दूसरा स्लाइस खाली होगा।
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// `VecDeque` में तत्वों की संख्या लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// यदि `VecDeque` खाली है तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// `VecDeque` में निर्दिष्ट सीमा को कवर करने वाला एक पुनरावर्तक बनाता है।
    ///
    /// # Panics
    ///
    /// Panics यदि प्रारंभिक बिंदु अंत बिंदु से बड़ा है या यदि अंत बिंदु vector की लंबाई से अधिक है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // एक पूरी श्रृंखला में सभी सामग्री शामिल है
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // &self में हमारे पास जो साझा संदर्भ है, उसे '_' Iter में रखा गया है।
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// `VecDeque` में निर्दिष्ट परिवर्तनशील श्रेणी को कवर करने वाला एक पुनरावर्तक बनाता है।
    ///
    /// # Panics
    ///
    /// Panics यदि प्रारंभिक बिंदु अंत बिंदु से बड़ा है या यदि अंत बिंदु vector की लंबाई से अधिक है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // एक पूरी श्रृंखला में सभी सामग्री शामिल है
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // सुरक्षा: आंतरिक `IterMut` सुरक्षा अपरिवर्तनीय स्थापित किया गया है क्योंकि
        // `ring` हम बनाते हैं जीवन भर के लिए एक dereferencable टुकड़ा है '_।
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// एक ड्रेनिंग इटरेटर बनाता है जो `VecDeque` में निर्दिष्ट श्रेणी को हटा देता है और हटाए गए आइटम उत्पन्न करता है।
    ///
    /// नोट 1: तत्व श्रेणी को हटा दिया जाता है, भले ही अंत तक इटरेटर का उपभोग न किया गया हो।
    ///
    /// नोट 2: यह निर्दिष्ट नहीं है कि कितने तत्वों को डेक से हटा दिया जाता है, यदि `Drain` मान गिराया नहीं जाता है, लेकिन उधार लिया गया समय समाप्त हो जाता है (उदाहरण के लिए, `mem::forget` के कारण)।
    ///
    ///
    /// # Panics
    ///
    /// Panics यदि प्रारंभिक बिंदु अंत बिंदु से बड़ा है या यदि अंत बिंदु vector की लंबाई से अधिक है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // एक पूरी श्रृंखला सभी सामग्री को साफ़ करती है
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // मेमोरी सुरक्षा
        //
        // जब Drain पहली बार बनाया जाता है, तो यह सुनिश्चित करने के लिए स्रोत डेक को छोटा कर दिया जाता है कि यदि Drain का विनाशक कभी नहीं चलता है तो कोई भी अप्रारंभ या स्थानांतरित-तत्वों तक पहुंच योग्य नहीं है।
        //
        //
        // Drain निकालने के लिए मानों को ptr::read कर देगा।
        // समाप्त होने पर, शेष डेटा को छेद को कवर करने के लिए वापस कॉपी किया जाएगा, और head/tail मान सही ढंग से पुनर्स्थापित किए जाएंगे।
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // डेक के तत्वों को तीन खंडों में विभाजित किया गया है:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // टी= self.tail;एच= self.head;टी=drain_tail;एच=drain_head
        //
        // हम drain_tail को self.head के रूप में, और drain_head और self.head को Drain पर क्रमशः after_tail और after_head के रूप में संग्रहीत करते हैं।
        // यह प्रभावी सरणी को भी छोटा कर देता है जैसे कि यदि Drain लीक हो जाता है, तो हम drain की शुरुआत के बाद संभावित स्थानांतरित मूल्यों के बारे में भूल गए हैं।
        //
        //
        //        टी वें एच
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" drain की शुरुआत के बाद के मूल्यों के बारे में जब तक drain पूरा नहीं हो जाता है और Drain विनाशक चलाया जाता है।
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // महत्वपूर्ण रूप से, हम यहां केवल `self` से साझा संदर्भ बनाते हैं और उससे पढ़ते हैं।
                // हम `self` को नहीं लिखते हैं और न ही किसी परिवर्तनशील संदर्भ के लिए पुनः उधार लेते हैं।
                // इसलिए `deque` के लिए हमने ऊपर जो रॉ पॉइंटर बनाया है, वह वैध रहता है।
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// सभी मानों को हटाते हुए `VecDeque` को साफ़ करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// यदि `VecDeque` में दिए गए मान के बराबर एक तत्व है, तो `true` लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// यदि `VecDeque` खाली है, तो सामने वाले तत्व या `None` का संदर्भ प्रदान करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// यदि `VecDeque` खाली है, तो सामने वाले तत्व या `None` के लिए एक परिवर्तनीय संदर्भ प्रदान करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// यदि `VecDeque` खाली है, तो बैक एलिमेंट या `None` का संदर्भ प्रदान करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// यदि `VecDeque` खाली है, तो बैक एलिमेंट या `None` के लिए एक परिवर्तनीय संदर्भ प्रदान करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// पहले तत्व को हटाता है और इसे वापस करता है, या यदि `VecDeque` खाली है तो `None`।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// `VecDeque` से अंतिम तत्व को हटाता है और इसे वापस करता है, या `None` यदि यह खाली है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// `VecDeque` के लिए एक तत्व तैयार करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// `VecDeque` के पीछे एक तत्व जोड़ता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: क्या हमें `head == 0` का मतलब समझना चाहिए
        // वह `self` सन्निहित है?
        self.tail <= self.head
    }

    /// `VecDeque` में कहीं से भी एक तत्व को हटाता है और इसे पहले तत्व के साथ बदलकर वापस कर देता है।
    ///
    ///
    /// यह आदेश को संरक्षित नहीं करता है, लेकिन *O*(1) है।
    ///
    /// यदि `index` सीमा से बाहर है, तो `None` लौटाता है।
    ///
    /// इंडेक्स 0 पर एलिमेंट कतार में सबसे आगे है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// `VecDeque` में कहीं से भी एक तत्व को हटाता है और इसे अंतिम तत्व के साथ बदलकर वापस कर देता है।
    ///
    ///
    /// यह आदेश को संरक्षित नहीं करता है, लेकिन *O*(1) है।
    ///
    /// यदि `index` सीमा से बाहर है, तो `None` लौटाता है।
    ///
    /// इंडेक्स 0 पर एलिमेंट कतार में सबसे आगे है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// `VecDeque` के भीतर `index` पर एक तत्व सम्मिलित करता है, सभी तत्वों को पीछे की ओर `index` से अधिक या उसके बराबर सूचकांकों के साथ स्थानांतरित करता है।
    ///
    ///
    /// इंडेक्स 0 पर एलिमेंट कतार में सबसे आगे है।
    ///
    /// # Panics
    ///
    /// Panics अगर `index` `VecDeque` की लंबाई से बड़ा है
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // रिंग बफ़र में कम से कम तत्वों को ले जाएँ और दिए गए ऑब्जेक्ट को सम्मिलित करें
        //
        // ज़्यादा से ज़्यादा len/2 पर, 1 तत्वों को स्थानांतरित किया जाएगा। O(min(n, n-i))
        //
        // तीन मुख्य मामले हैं:
        //  तत्व सन्निहित हैं
        //      - विशेष मामला जब टेल 0 होता है, एलिमेंट असतत होते हैं और इंसर्ट टेल सेक्शन में होता है एलिमेंट्स असतत होते हैं और इंसर्ट हेड सेक्शन में होता है
        //
        //
        // उनमें से प्रत्येक के लिए दो और मामले हैं:
        //  इंसर्ट टेल के करीब है इंसर्ट हेड के करीब है
        //
        // कुंजी: एच, self.head
        //      T, self.tail o, मान्य तत्व I, सम्मिलन तत्व A, वह तत्व जो सम्मिलन बिंदु M के बाद होना चाहिए, इंगित करता है कि तत्व स्थानांतरित हो गया था
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [एक oooooo।......
                //      .
                //      .]
                //
                //                       हिंदुस्तान टाइम्स
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // सन्निहित, पूंछ के करीब डालें:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           वें
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // सन्निहित, पूंछ के करीब डालें और पूंछ 0 है:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       हिंदुस्तान टाइम्स
                    //      [o I A o o o o o . . . . . . . o]
                    //       मिमी

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // पूंछ को पहले ही स्थानांतरित कर दिया गया है, इसलिए हम केवल `index - 1` तत्वों की प्रतिलिपि बनाते हैं।
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // सन्निहित, सिर के करीब डालें:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             वें
                    //      [. . . o o o o I A o o . . . . .]
                    //                       एमएमएम

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // असतत, पूंछ के करीब डालें, पूंछ खंड:
                    //
                    //                   एचटीआई
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   हिंदुस्तान टाइम्स
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // असंबद्ध, सिर के करीब डालें, पूंछ खंड:
                    //
                    //           एचटीआई
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             हिंदुस्तान टाइम्स
                    //      [o o o . . . . . . o o o o o I A]
                    //       एमएमएमएम

                    // तत्वों को नए शीर्ष तक कॉपी करें
                    self.copy(1, 0, self.head);

                    // अंतिम तत्व को बफर के नीचे खाली जगह पर कॉपी करें
                    self.copy(0, self.cap() - 1, 1);

                    // तत्वों को idx से आगे की ओर ले जाएं, जिसमें ^ तत्व शामिल नहीं है
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // असंबद्ध, सम्मिलित करें पूंछ, सिर अनुभाग के करीब है, और आंतरिक बफर में सूचकांक शून्य पर है:
                    //
                    //
                    //       आई एच टी
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           हिंदुस्तान टाइम्स
                    //      [A o o o o o o o o o . . o o o I]
                    //                               एमएमएम

                    // तत्वों को नई पूंछ तक कॉपी करें
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // अंतिम तत्व को बफर के नीचे खाली जगह पर कॉपी करें
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // असतत, पूंछ के करीब डालें, सिर अनुभाग:
                    //
                    //             आई एच टी
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           हिंदुस्तान टाइम्स
                    //      [o o I A o o o o o o . . o o o o]
                    //       एमएमएमएमएमएम

                    // तत्वों को नई पूंछ तक कॉपी करें
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // अंतिम तत्व को बफर के नीचे खाली जगह पर कॉपी करें
                    self.copy(self.cap() - 1, 0, 1);

                    // तत्वों को idx-1 से आगे की ओर ले जाएं, जिसमें ^ तत्व शामिल नहीं है
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // असतत, सिर के करीब डालें, हेड सेक्शन:
                    //
                    //               आई एच टी
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     हिंदुस्तान टाइम्स
                    //      [o o o o I A o o . . . . . o o o]
                    //                 एमएमएम

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // पूंछ बदल दी गई हो सकती है इसलिए हमें पुनर्गणना करने की आवश्यकता है
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// `VecDeque` से `index` पर तत्व को हटाता है और वापस करता है।
    /// जो भी छोर हटाने के बिंदु के करीब है, उसे जगह बनाने के लिए ले जाया जाएगा, और सभी प्रभावित तत्वों को नई स्थिति में ले जाया जाएगा।
    ///
    /// यदि `index` सीमा से बाहर है, तो `None` लौटाता है।
    ///
    /// इंडेक्स 0 पर एलिमेंट कतार में सबसे आगे है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // तीन मुख्य मामले हैं:
        //  तत्व सन्निहित हैं तत्व सन्निहित हैं और निष्कासन टेल सेक्शन में है तत्व असतत हैं और निष्कासन हेड सेक्शन में है
        //
        //      - विशेष मामला जब तत्व तकनीकी रूप से सन्निहित हैं, लेकिन self.head =0
        //
        // उनमें से प्रत्येक के लिए दो और मामले हैं:
        //  इंसर्ट टेल के करीब है इंसर्ट हेड के करीब है
        //
        // कुंजी: एच, self.head
        //      T, self.tail o, मान्य तत्व x, हटाने के लिए चिह्नित तत्व R, हटाए जा रहे तत्व को इंगित करता है M, इंगित करता है कि तत्व को स्थानांतरित किया गया था
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // सन्निहित, पूंछ के करीब हटा दें:
                    //
                    //             टीआरएच
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               वें
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // सन्निहित, सिर के करीब हटा दें:
                    //
                    //             टीआरएच
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             वें
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // असतत, पूंछ के करीब हटा दें, पूंछ अनुभाग:
                    //
                    //                   एचटीआर
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   हिंदुस्तान टाइम्स
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // असंबद्ध, सिर के करीब हटा दें, सिर अनुभाग:
                    //
                    //               आरएचटी
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   हिंदुस्तान टाइम्स
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // असंबद्ध, सिर के करीब हटा दें, पूंछ अनुभाग:
                    //
                    //             एचटीआर
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           हिंदुस्तान टाइम्स
                    //      [o o . . . . . . . o o o o o o o]
                    //       एमएमएमएम
                    //
                    // या अर्ध-असंतत, सिर के बगल में हटा दें, पूंछ अनुभाग:
                    //
                    //       एचटीआर
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         वें
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // टेल सेक्शन में तत्वों को ड्रा करें
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // अंडरफ्लो को रोकता है।
                    if self.head != 0 {
                        // पहले तत्व को खाली जगह पर कॉपी करें
                        self.copy(self.cap() - 1, 0, 1);

                        // तत्वों को हेड सेक्शन में पीछे की ओर ले जाएं
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // असंबद्ध, पूंछ के करीब हटा दें, सिर अनुभाग:
                    //
                    //           आरएचटी
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           हिंदुस्तान टाइम्स
                    //      [o o o o o o o o o o . . . . o o]
                    //       एमएमएमएमएम

                    // idx तक के तत्वों को ड्रा करें
                    self.copy(1, 0, idx);

                    // अंतिम तत्व को खाली स्थान पर कॉपी करें
                    self.copy(0, self.cap() - 1, 1);

                    // पिछले एक को छोड़कर, तत्वों को पूंछ से अंत तक आगे की ओर ले जाएं
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// दिए गए इंडेक्स पर `VecDeque` को दो में विभाजित करता है।
    ///
    /// एक नया आवंटित `VecDeque` देता है।
    /// `self` `[0, at)` तत्व शामिल हैं, और लौटाए गए `VecDeque` में `[at, len)` तत्व शामिल हैं।
    ///
    /// ध्यान दें कि `self` की क्षमता नहीं बदलती है।
    ///
    /// इंडेक्स 0 पर एलिमेंट कतार में सबसे आगे है।
    ///
    /// # Panics
    ///
    /// Panics अगर `at > len`।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` पहले हाफ में है।
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // बस दूसरी छमाही के सभी ले लो।
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` दूसरी छमाही में निहित है, उन तत्वों को ध्यान में रखना चाहिए जिन्हें हमने पहली छमाही में छोड़ दिया था।
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // सफाई जहां बफ़र्स के सिरे हैं
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// `other` के सभी तत्वों को `self` में ले जाता है, `other` को खाली छोड़ देता है।
    ///
    /// # Panics
    ///
    /// Panics यदि स्वयं में तत्वों की नई संख्या `usize` को ओवरफ्लो करती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // भोला भाव
        self.extend(other.drain(..));
    }

    /// केवल विधेय द्वारा निर्दिष्ट तत्वों को बरकरार रखता है।
    ///
    /// दूसरे शब्दों में, सभी तत्वों को हटा दें `e` जैसे कि `f(&e)` झूठी वापसी करता है।
    /// यह विधि जगह पर काम करती है, प्रत्येक तत्व को मूल क्रम में बिल्कुल एक बार देखती है, और बनाए गए तत्वों के क्रम को संरक्षित करती है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// एक इंडेक्स की तरह बाहरी स्थिति को ट्रैक करने के लिए सटीक ऑर्डर उपयोगी हो सकता है।
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // यह panic या निरस्त हो सकता है
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // बफर आकार को दोगुना करें।
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// `VecDeque` को इन-प्लेस में संशोधित करता है ताकि `len()` `new_len` के बराबर हो, या तो पीछे से अतिरिक्त तत्वों को हटाकर या `generator` को पीछे से कॉल करके उत्पन्न तत्वों को जोड़कर।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// इस डेक के आंतरिक भंडारण को पुनर्व्यवस्थित करता है ताकि यह एक सन्निहित टुकड़ा हो, जिसे फिर वापस कर दिया जाता है।
    ///
    /// यह विधि आवंटित नहीं करती है और सम्मिलित तत्वों के क्रम को नहीं बदलती है।चूंकि यह एक परिवर्तनशील टुकड़ा देता है, इसका उपयोग एक डेक को सॉर्ट करने के लिए किया जा सकता है।
    ///
    /// एक बार आंतरिक भंडारण सन्निहित हो जाने पर, [`as_slices`] और [`as_mut_slices`] विधियाँ `VecDeque` की संपूर्ण सामग्री को एक ही स्लाइस में वापस कर देंगी।
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// एक डेक की सामग्री को क्रमबद्ध करना।
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // डेक को छांटना
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // इसे उल्टे क्रम में छाँटना
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// सन्निहित स्लाइस के लिए अपरिवर्तनीय पहुँच प्राप्त करना।
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // अब हम यह सुनिश्चित कर सकते हैं कि `slice` में डेक के सभी तत्व शामिल हैं, जबकि अभी भी `buf` तक अपरिवर्तनीय पहुंच है।
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // पूंछ को एक बार में कॉपी करने के लिए पर्याप्त खाली जगह है, इसका मतलब है कि हम पहले सिर को पीछे की ओर ले जाते हैं, और फिर पूंछ को सही स्थिति में कॉपी करते हैं।
            //
            //
            // से: डीईएफजीएच....एबीसी
            // को: एबीसीडीईएफजीएच....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: हम वर्तमान में ....ABCDEFGH. पर विचार नहीं करते हैं
            // सन्निहित होना क्योंकि इस मामले में `head` `0` होगा।
            // जबकि हम शायद इसे बदलना चाहते हैं, यह मामूली नहीं है क्योंकि कुछ जगहों पर `is_contiguous` का मतलब यह है कि हम `buf[tail..head]` का उपयोग करके सिर्फ स्लाइस कर सकते हैं।
            //
            //

            // सिर को एक बार में कॉपी करने के लिए पर्याप्त खाली जगह है, इसका मतलब है कि हम पहले पूंछ को आगे की ओर शिफ्ट करते हैं, और फिर सिर को सही स्थिति में कॉपी करते हैं।
            //
            //
            // से: एफजीएच....एबीसीडीई
            // को: ...एबीसीडीईएफजीएच।
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // फ्री हेड और टेल दोनों से छोटा है, इसका मतलब है कि हमें टेल और हेड को धीरे-धीरे "swap" करना होगा।
            //
            //
            // से: EFGHI...ABCD या HIJK.ABCDEFG
            // to: ABCDEFGHI... या ABCDEFGHIJK।
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // सामान्य समस्या इस तरह दिखती है GHIJKLM...ABCDEF, किसी भी स्वैप से पहले ABCDEFM...GHIJKL, स्वैप के 1 पास के बाद ABCDEFGHIJM...KL, तब तक स्वैप करें जब तक कि बाईं ओर edge टेम्प स्टोर तक न पहुंच जाए
                //                  - फिर एक नए (smaller) स्टोर के साथ एल्गोरिदम को पुनरारंभ करें कभी-कभी अस्थायी स्टोर तक पहुंच जाता है जब सही edge बफर के अंत में होता है, इसका मतलब है कि हमने कम स्वैप के साथ सही ऑर्डर मारा है!
                //
                // E.g
                // EF..ABCD ABCDEF.., केवल चार स्वैप के बाद हम समाप्त कर चुके हैं
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// डबल-एंडेड क्यू `mid` स्थानों को बाईं ओर घुमाता है।
    ///
    /// Equivalently,
    /// - आइटम `mid` को पहली स्थिति में घुमाता है।
    /// - पहले `mid` आइटम को पॉप करता है और उन्हें अंत तक धकेलता है।
    /// - `len() - mid` स्थानों को दाईं ओर घुमाता है।
    ///
    /// # Panics
    ///
    /// यदि `mid`, `len()` से बड़ा है।
    /// ध्यान दें कि `mid == len()` _not_ panic करता है और एक नो-ऑप रोटेशन है।
    ///
    /// # Complexity
    ///
    /// `*O*(min(mid, len() - mid))` समय लेता है और कोई अतिरिक्त स्थान नहीं लेता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// डबल-एंडेड क्यू `k` स्थानों को दाईं ओर घुमाता है।
    ///
    /// Equivalently,
    /// - पहले आइटम को स्थिति `k` में घुमाता है।
    /// - पिछले `k` आइटम को पॉप करता है और उन्हें सामने की ओर धकेलता है।
    /// - `len() - k` स्थानों को बाईं ओर घुमाता है।
    ///
    /// # Panics
    ///
    /// यदि `k`, `len()` से बड़ा है।
    /// ध्यान दें कि `k == len()` _not_ panic करता है और एक नो-ऑप रोटेशन है।
    ///
    /// # Complexity
    ///
    /// `*O*(min(k, len() - k))` समय लेता है और कोई अतिरिक्त स्थान नहीं लेता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // सुरक्षा: निम्नलिखित दो विधियों के लिए आवश्यक है कि रोटेशन राशि
    // डेक की लंबाई के आधे से कम हो।
    //
    // `wrap_copy` उस `min(x, cap() - x) + copy_len <= cap()` की आवश्यकता है, लेकिन `min` की तुलना में x की परवाह किए बिना कभी भी आधे से अधिक क्षमता नहीं होती है, इसलिए यहां कॉल करना उचित है क्योंकि हम आधे से कम लंबाई के साथ कॉल कर रहे हैं, जो कभी भी आधी क्षमता से अधिक नहीं है।
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// बाइनरी किसी दिए गए तत्व के लिए इस सॉर्ट किए गए `VecDeque` को खोजता है।
    ///
    /// यदि मान पाया जाता है तो [`Result::Ok`] लौटाया जाता है, जिसमें मिलान करने वाले तत्व का सूचकांक होता है।
    /// यदि कई मैच हैं, तो किसी एक मैच को वापस किया जा सकता है।
    /// यदि मान नहीं मिलता है तो [`Result::Err`] लौटाया जाता है, जिसमें अनुक्रमणिका होती है जहां क्रमबद्ध क्रम बनाए रखते हुए एक मिलान तत्व डाला जा सकता है।
    ///
    ///
    /// # Examples
    ///
    /// चार तत्वों की एक श्रृंखला को देखता है।
    /// पहला पाया जाता है, एक विशिष्ट रूप से निर्धारित स्थिति के साथ;दूसरा और तीसरा नहीं मिला;चौथा `[1, 4]` में किसी भी स्थिति से मेल खा सकता है।
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// यदि आप सॉर्ट क्रम को बनाए रखते हुए किसी आइटम को सॉर्ट किए गए `VecDeque` में सम्मिलित करना चाहते हैं:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// बाइनरी इस सॉर्ट किए गए `VecDeque` को एक तुलनित्र फ़ंक्शन के साथ खोजता है।
    ///
    /// तुलनित्र फ़ंक्शन को अंतर्निहित `VecDeque` के सॉर्ट ऑर्डर के अनुरूप ऑर्डर लागू करना चाहिए, एक ऑर्डर कोड लौटाना जो इंगित करता है कि इसका तर्क वांछित लक्ष्य से `Less`, `Equal` या `Greater` है या नहीं।
    ///
    ///
    /// यदि मान पाया जाता है तो [`Result::Ok`] लौटाया जाता है, जिसमें मिलान करने वाले तत्व का सूचकांक होता है।यदि कई मैच हैं, तो किसी एक मैच को वापस किया जा सकता है।
    /// यदि मान नहीं मिलता है तो [`Result::Err`] लौटाया जाता है, जिसमें अनुक्रमणिका होती है जहां क्रमबद्ध क्रम बनाए रखते हुए एक मिलान तत्व डाला जा सकता है।
    ///
    /// # Examples
    ///
    /// चार तत्वों की एक श्रृंखला को देखता है।पहला पाया जाता है, एक विशिष्ट रूप से निर्धारित स्थिति के साथ;दूसरा और तीसरा नहीं मिला;चौथा `[1, 4]` में किसी भी स्थिति से मेल खा सकता है।
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// बाइनरी इस सॉर्ट किए गए `VecDeque` को एक कुंजी निष्कर्षण फ़ंक्शन के साथ खोजता है।
    ///
    /// मान लें कि `VecDeque` को कुंजी द्वारा क्रमबद्ध किया गया है, उदाहरण के लिए [`make_contiguous().sort_by_key()`](#method.make_contiguous) के साथ समान कुंजी निष्कर्षण फ़ंक्शन का उपयोग करना।
    ///
    ///
    /// यदि मान पाया जाता है तो [`Result::Ok`] लौटाया जाता है, जिसमें मिलान करने वाले तत्व का सूचकांक होता है।
    /// यदि कई मैच हैं, तो किसी एक मैच को वापस किया जा सकता है।
    /// यदि मान नहीं मिलता है तो [`Result::Err`] लौटाया जाता है, जिसमें अनुक्रमणिका होती है जहां क्रमबद्ध क्रम बनाए रखते हुए एक मिलान तत्व डाला जा सकता है।
    ///
    /// # Examples
    ///
    /// चार तत्वों की एक श्रृंखला को उनके दूसरे तत्वों द्वारा क्रमबद्ध जोड़े के एक टुकड़े में देखता है।
    /// पहला पाया जाता है, एक विशिष्ट रूप से निर्धारित स्थिति के साथ;दूसरा और तीसरा नहीं मिला;चौथा `[1, 4]` में किसी भी स्थिति से मेल खा सकता है।
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// `VecDeque` को इन-प्लेस संशोधित करता है ताकि `len()` new_len के बराबर हो, या तो पीछे से अतिरिक्त तत्वों को हटाकर या `value` के क्लोन को पीछे से जोड़कर।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// किसी दिए गए तार्किक तत्व अनुक्रमणिका के लिए अंतर्निहित बफ़र में अनुक्रमणिका लौटाता है।
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // आकार हमेशा 2. की शक्ति होता है
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// बफ़र में पढ़ने के लिए शेष तत्वों की संख्या की गणना करें
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // आकार हमेशा 2. की शक्ति होता है
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // हमेशा तीन खंडों में विभाज्य, उदाहरण के लिए: स्वयं: [a b c|d e f] अन्य: [0 1 2 3|4 5] सामने=3, मध्य=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // as_slices विधि द्वारा लौटाए गए स्लाइस पर Hash::hash_slice का उपयोग करना संभव नहीं है क्योंकि उनकी लंबाई अन्यथा समान डेक में भिन्न हो सकती है।
        //
        //
        // हैशर केवल अपने तरीकों के लिए कॉल के समान सेट के लिए समानता की गारंटी देता है।
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// मूल्य के आधार पर `VecDeque` को एक फ्रंट-टू-बैक इटरेटर यील्डिंग एलिमेंट्स में शामिल करता है।
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // यह कार्य नैतिक समकक्ष होना चाहिए:
        //
        //      iter.into_iter() में आइटम के लिए {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// [`Vec<T>`] को [`VecDeque<T>`] में बदलें।
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// यह जहां संभव हो, पुन: आवंटित करने से बचता है, लेकिन इसके लिए शर्तें सख्त हैं, और परिवर्तन के अधीन हैं, और इसलिए इस पर तब तक भरोसा नहीं किया जाना चाहिए जब तक कि `Vec<T>` `From<VecDeque<T>>` से नहीं आया और फिर से आवंटित नहीं किया गया है।
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // क्षमता के बारे में चिंता करने के लिए ZST के लिए कोई वास्तविक आवंटन नहीं है, लेकिन `VecDeque` `Vec` जितनी लंबाई को संभाल नहीं सकता है।
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // हमें आकार बदलने की जरूरत है अगर क्षमता दो की शक्ति नहीं है, बहुत छोटी है या कम से कम एक खाली जगह नहीं है।
            // हम ऐसा तब करते हैं जब यह अभी भी `Vec` में है इसलिए आइटम panic पर गिर जाएंगे।
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// [`VecDeque<T>`] को [`Vec<T>`] में बदलें।
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// इसे फिर से आवंटित करने की आवश्यकता नहीं है, लेकिन यदि आवंटन की शुरुआत में परिपत्र बफर नहीं होता है तो *O*(*n*) डेटा आंदोलन करने की आवश्यकता होती है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // यह *ओ*(1) है।
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // इसे डेटा पुनर्व्यवस्थित करने की आवश्यकता है।
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}