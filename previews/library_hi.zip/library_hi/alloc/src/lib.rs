//! # Rust कोर आवंटन और संग्रह पुस्तकालय
//!
//! यह पुस्तकालय ढेर-आवंटित मूल्यों के प्रबंधन के लिए स्मार्ट पॉइंटर्स और संग्रह प्रदान करता है।
//!
//! यह पुस्तकालय, libcore की तरह, सामान्य रूप से सीधे उपयोग करने की आवश्यकता नहीं है क्योंकि इसकी सामग्री [`std` crate](../std/index.html) में फिर से निर्यात की जाती है।
//! Crates जो `#![no_std]` विशेषता का उपयोग करते हैं, हालांकि आमतौर पर `std` पर निर्भर नहीं होंगे, इसलिए वे इसके बजाय इस crate का उपयोग करेंगे।
//!
//! ## बॉक्सिंग मान
//!
//! [`Box`] प्रकार एक स्मार्ट सूचक प्रकार है।एक [`Box`] का केवल एक स्वामी हो सकता है, और स्वामी उस सामग्री को बदलने का निर्णय ले सकता है, जो ढेर पर रहती है।
//!
//! इस प्रकार को थ्रेड्स के बीच कुशलता से भेजा जा सकता है क्योंकि `Box` मान का आकार एक पॉइंटर के समान होता है।
//! पेड़ की तरह डेटा संरचनाएं अक्सर बक्से के साथ बनाई जाती हैं क्योंकि प्रत्येक नोड में अक्सर केवल एक मालिक होता है, माता-पिता।
//!
//! ## संदर्भ गिने हुए संकेत
//!
//! [`Rc`] प्रकार एक गैर-थ्रेडसेफ संदर्भ-गिनती सूचक प्रकार है जिसका उद्देश्य थ्रेड के भीतर स्मृति साझा करना है।
//! एक [`Rc`] पॉइंटर एक प्रकार, `T` को लपेटता है, और केवल `&T`, एक साझा संदर्भ तक पहुंच की अनुमति देता है।
//!
//! यह प्रकार तब उपयोगी होता है जब विरासत में मिली परिवर्तनशीलता (जैसे कि [`Box`] का उपयोग करना) किसी अनुप्रयोग के लिए बहुत विवश है, और उत्परिवर्तन की अनुमति देने के लिए इसे अक्सर [`Cell`] या [`RefCell`] प्रकारों के साथ जोड़ा जाता है।
//!
//!
//! ## एटॉमिकली रेफरेंस काउंटेड पॉइंटर्स
//!
//! [`Arc`] प्रकार [`Rc`] प्रकार के बराबर थ्रेडसेफ है।यह [`Rc`] की सभी समान कार्यक्षमता प्रदान करता है, सिवाय इसके कि निहित प्रकार `T` साझा करने योग्य है।
//! इसके अतिरिक्त, [`Arc<T>`][`Arc`] स्वयं भेजने योग्य है जबकि [`Rc<T>`][`Rc`] नहीं है।
//!
//! यह प्रकार निहित डेटा तक साझा पहुंच की अनुमति देता है, और अक्सर साझा संसाधनों के उत्परिवर्तन की अनुमति देने के लिए म्यूटेक्स जैसे सिंक्रनाइज़ेशन प्राइमेटिव के साथ जोड़ा जाता है।
//!
//! ## Collections
//!
//! सबसे सामान्य सामान्य प्रयोजन डेटा संरचनाओं के कार्यान्वयन को इस पुस्तकालय में परिभाषित किया गया है।उन्हें [standard collections library](../std/collections/index.html) के माध्यम से पुनः निर्यात किया जाता है।
//!
//! ## ढेर इंटरफेस
//!
//! [`alloc`](alloc/index.html) मॉड्यूल निम्न-स्तरीय इंटरफ़ेस को डिफ़ॉल्ट वैश्विक आवंटनकर्ता के लिए परिभाषित करता है।यह libc आवंटक API के साथ संगत नहीं है।
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// तकनीकी रूप से, यह रस्टडॉक में एक बग है: रस्टडॉक देखता है कि `#[lang = slice_alloc]` ब्लॉक पर प्रलेखन `&[T]` के लिए है, जिसमें `core` में इस सुविधा का उपयोग करते हुए प्रलेखन भी है, और यह पागल हो जाता है कि फीचर-गेट सक्षम नहीं है।
// आदर्श रूप से, यह अन्य crates से डॉक्स के लिए फीचर गेट की जांच नहीं करेगा, लेकिन चूंकि यह केवल लैंग आइटम के लिए प्रकट हो सकता है, यह ठीक करने लायक नहीं लगता है।
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// इस पुस्तकालय के परीक्षण की अनुमति दें

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// अन्य मॉड्यूल द्वारा उपयोग किए जाने वाले आंतरिक मैक्रो के साथ मॉड्यूल (अन्य मॉड्यूल से पहले शामिल किए जाने की आवश्यकता है)।
#[macro_use]
mod macros;

// निम्न-स्तरीय आवंटन रणनीतियों के लिए ढेर उपलब्ध कराए गए

pub mod alloc;

// ऊपर के ढेर का उपयोग करते हुए आदिम प्रकार types

// परीक्षण cfg में निर्माण करते समय लैंग-आइटम को डुप्लिकेट करने से बचने के लिए `boxed.rs` से मॉड को सशर्त रूप से परिभाषित करने की आवश्यकता है;लेकिन कोड को `use boxed::Box;` घोषणाओं की अनुमति देने की भी आवश्यकता है।
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}