//! एक सन्निहित अनुक्रम में एक गतिशील रूप से आकार का दृश्य, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! स्लाइस एक पॉइंटर और लंबाई के रूप में दर्शाए गए मेमोरी के ब्लॉक में एक दृश्य है।
//!
//! ```
//! // एक Vec. टुकड़ा करना
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // एक सरणी को एक स्लाइस के लिए मजबूर करना
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! स्लाइस या तो परिवर्तनशील या साझा किए जाते हैं।
//! साझा स्लाइस प्रकार `&[T]` है, जबकि परिवर्तनशील स्लाइस प्रकार `&mut [T]` है, जहां `T` तत्व प्रकार का प्रतिनिधित्व करता है।
//! उदाहरण के लिए, आप स्मृति के उस ब्लॉक को बदल सकते हैं जो एक परिवर्तनशील टुकड़ा इंगित करता है:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! यहाँ कुछ चीजें इस मॉड्यूल में शामिल हैं:
//!
//! ## Structs
//!
//! स्लाइस के लिए उपयोगी कई संरचनाएं हैं, जैसे कि [`Iter`], जो एक स्लाइस पर पुनरावृत्ति का प्रतिनिधित्व करता है।
//!
//! ## Trait कार्यान्वयन
//!
//! स्लाइस के लिए सामान्य traits के कई कार्यान्वयन हैं।कुछ उदाहरणों में शामिल हैं:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], स्लाइस के लिए जिसका तत्व प्रकार [`Eq`] या [`Ord`] है।
//! * [`Hash`] - स्लाइस के लिए जिसका तत्व प्रकार [`Hash`] है।
//!
//! ## Iteration
//!
//! स्लाइस `IntoIterator` लागू करते हैं।इटरेटर स्लाइस तत्वों के संदर्भ देता है।
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! परिवर्तनीय टुकड़ा तत्वों के लिए परिवर्तनीय संदर्भ उत्पन्न करता है:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! यह इटरेटर स्लाइस के तत्वों के लिए परस्पर संदर्भ देता है, इसलिए जबकि स्लाइस का तत्व प्रकार `i32` है, इटरेटर का तत्व प्रकार `&mut i32` है।
//!
//!
//! * [`.iter`] और [`.iter_mut`] डिफ़ॉल्ट पुनरावृत्तियों को वापस करने के लिए स्पष्ट तरीके हैं।
//! * आगे के तरीके जो इटरेटर लौटाते हैं, वे हैं [`.split`], [`.splitn`], [`.chunks`], [`.windows`] और बहुत कुछ।
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// इस मॉड्यूल में कई प्रयोग केवल परीक्षण विन्यास में उपयोग किए जाते हैं।
// unused_imports चेतावनी को ठीक करने के बजाय उसे बंद करना अधिक आसान है।
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// मूल टुकड़ा विस्तार के तरीके
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) परीक्षण NB के दौरान `vec!` मैक्रो के कार्यान्वयन के लिए आवश्यक, अधिक विवरण के लिए इस फ़ाइल में `hack` मॉड्यूल देखें।
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) परीक्षण NB के दौरान `Vec::clone` के कार्यान्वयन के लिए आवश्यक, अधिक विवरण के लिए इस फ़ाइल में `hack` मॉड्यूल देखें।
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` उपलब्ध नहीं है, ये तीन फ़ंक्शन वास्तव में `impl [T]` में हैं लेकिन `core::slice::SliceExt` में नहीं हैं, हमें `test_permutations` परीक्षण के लिए इन कार्यों की आपूर्ति करने की आवश्यकता है
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // हमें इसमें इनलाइन विशेषता नहीं जोड़नी चाहिए क्योंकि इसका उपयोग ज्यादातर `vec!` मैक्रो में किया जाता है और यह पूर्ण प्रतिगमन का कारण बनता है।
    // चर्चा और पूर्ण परिणामों के लिए #71204 देखें।
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // आइटम को नीचे दिए गए लूप में इनिशियलाइज़ किया गया था
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) एलएलवीएम के लिए सीमा जांच को हटाने के लिए आवश्यक है और ज़िप से बेहतर कोडजन है।
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec आवंटित किया गया था और कम से कम इस लंबाई के ऊपर प्रारंभ किया गया था।
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` की क्षमता के साथ ऊपर आवंटित, और नीचे ptr::copy_to_non_overlapping में `s.len()` को प्रारंभ करें।
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// टुकड़ा क्रमबद्ध करता है।
    ///
    /// यह प्रकार स्थिर है (यानी, समान तत्वों को पुन: व्यवस्थित नहीं करता है) और *O*(*n*\*log(* n*)) सबसे खराब स्थिति।
    ///
    /// लागू होने पर, अस्थिर सॉर्टिंग को प्राथमिकता दी जाती है क्योंकि यह आमतौर पर स्थिर सॉर्टिंग से तेज़ होती है और यह सहायक मेमोरी आवंटित नहीं करती है।
    /// [`sort_unstable`](slice::sort_unstable) देखें।
    ///
    /// # वर्तमान कार्यान्वयन
    ///
    /// वर्तमान एल्गोरिदम [timsort](https://en.wikipedia.org/wiki/Timsort) से प्रेरित एक अनुकूली, पुनरावृत्त मर्ज सॉर्ट है।
    /// यह उन मामलों में बहुत तेज़ होने के लिए डिज़ाइन किया गया है जहां टुकड़ा लगभग सॉर्ट किया गया है, या इसमें एक के बाद एक दो या दो से अधिक सॉर्ट किए गए अनुक्रम शामिल हैं।
    ///
    ///
    /// इसके अलावा, यह अस्थायी भंडारण को `self` के आकार का आधा आवंटित करता है, लेकिन छोटे स्लाइस के लिए इसके बजाय एक गैर-आवंटन सम्मिलन प्रकार का उपयोग किया जाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// एक तुलनित्र फ़ंक्शन के साथ स्लाइस को सॉर्ट करता है।
    ///
    /// यह प्रकार स्थिर है (यानी, समान तत्वों को पुन: व्यवस्थित नहीं करता है) और *O*(*n*\*log(* n*)) सबसे खराब स्थिति।
    ///
    /// तुलनित्र फ़ंक्शन को स्लाइस में तत्वों के लिए कुल क्रम को परिभाषित करना चाहिए।यदि आदेश कुल नहीं है, तो तत्वों का क्रम अनिर्दिष्ट है।
    /// एक आदेश एक कुल आदेश है यदि यह (सभी `a`, `b` और `c` के लिए) है:
    ///
    /// * टोटल और एंटीसिमेट्रिक: बिल्कुल `a < b`, `a == b` या `a > b` में से एक सही है, और
    /// * सकर्मक, `a < b` और `b < c` का अर्थ है `a < c`।`==` और `>` दोनों के लिए समान होना चाहिए।
    ///
    /// उदाहरण के लिए, जबकि [`f64`] [`Ord`] को `NaN != NaN` के कारण लागू नहीं करता है, हम `partial_cmp` को अपने सॉर्ट फ़ंक्शन के रूप में उपयोग कर सकते हैं जब हम जानते हैं कि स्लाइस में `NaN` नहीं है।
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// लागू होने पर, अस्थिर सॉर्टिंग को प्राथमिकता दी जाती है क्योंकि यह आमतौर पर स्थिर सॉर्टिंग से तेज़ होती है और यह सहायक मेमोरी आवंटित नहीं करती है।
    /// [`sort_unstable_by`](slice::sort_unstable_by) देखें।
    ///
    /// # वर्तमान कार्यान्वयन
    ///
    /// वर्तमान एल्गोरिदम [timsort](https://en.wikipedia.org/wiki/Timsort) से प्रेरित एक अनुकूली, पुनरावृत्त मर्ज सॉर्ट है।
    /// यह उन मामलों में बहुत तेज़ होने के लिए डिज़ाइन किया गया है जहां टुकड़ा लगभग सॉर्ट किया गया है, या इसमें एक के बाद एक दो या दो से अधिक सॉर्ट किए गए अनुक्रम शामिल हैं।
    ///
    /// इसके अलावा, यह अस्थायी भंडारण को `self` के आकार का आधा आवंटित करता है, लेकिन छोटे स्लाइस के लिए इसके बजाय एक गैर-आवंटन सम्मिलन प्रकार का उपयोग किया जाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // रिवर्स सॉर्टिंग
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// एक कुंजी निष्कर्षण फ़ंक्शन के साथ स्लाइस को सॉर्ट करें।
    ///
    /// यह प्रकार स्थिर है (अर्थात, समान तत्वों को पुन: व्यवस्थित नहीं करता है) और *O*(*m*\* * n *\* log(*n*)) सबसे खराब स्थिति, जहां मुख्य कार्य *O*(*m*) है।
    ///
    /// महंगे प्रमुख कार्यों के लिए (जैसे
    /// ऐसे फ़ंक्शन जो साधारण संपत्ति एक्सेस या बुनियादी संचालन नहीं हैं), [`sort_by_cached_key`](slice::sort_by_cached_key) के काफी तेज होने की संभावना है, क्योंकि यह तत्व कुंजियों की पुनर्गणना नहीं करता है।
    ///
    ///
    /// लागू होने पर, अस्थिर सॉर्टिंग को प्राथमिकता दी जाती है क्योंकि यह आमतौर पर स्थिर सॉर्टिंग से तेज़ होती है और यह सहायक मेमोरी आवंटित नहीं करती है।
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) देखें।
    ///
    /// # वर्तमान कार्यान्वयन
    ///
    /// वर्तमान एल्गोरिदम [timsort](https://en.wikipedia.org/wiki/Timsort) से प्रेरित एक अनुकूली, पुनरावृत्त मर्ज सॉर्ट है।
    /// यह उन मामलों में बहुत तेज़ होने के लिए डिज़ाइन किया गया है जहां टुकड़ा लगभग सॉर्ट किया गया है, या इसमें एक के बाद एक दो या दो से अधिक सॉर्ट किए गए अनुक्रम शामिल हैं।
    ///
    /// इसके अलावा, यह अस्थायी भंडारण को `self` के आकार का आधा आवंटित करता है, लेकिन छोटे स्लाइस के लिए इसके बजाय एक गैर-आवंटन सम्मिलन प्रकार का उपयोग किया जाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// एक कुंजी निष्कर्षण फ़ंक्शन के साथ स्लाइस को सॉर्ट करें।
    ///
    /// छँटाई के दौरान, कुंजी फ़ंक्शन को प्रति तत्व केवल एक बार कहा जाता है।
    ///
    /// यह प्रकार स्थिर है (अर्थात, समान तत्वों को पुन: व्यवस्थित नहीं करता है) और *O*(*m*\* * n *+* n *\* log(*n*)) सबसे खराब स्थिति, जहां मुख्य कार्य *O*(*m*) है .
    ///
    /// सरल कुंजी कार्यों के लिए (उदाहरण के लिए, संपत्ति का उपयोग या बुनियादी संचालन वाले कार्य), [`sort_by_key`](slice::sort_by_key) के तेज होने की संभावना है।
    ///
    /// # वर्तमान कार्यान्वयन
    ///
    /// वर्तमान एल्गोरिथ्म ओर्सन पीटर्स द्वारा [pattern-defeating quicksort][pdqsort] पर आधारित है, जो कुछ पैटर्न के साथ स्लाइस पर रैखिक समय प्राप्त करते हुए, हेपसॉर्ट के सबसे खराब मामले के साथ यादृच्छिक त्वरित सॉर्ट के तेज औसत मामले को जोड़ता है।
    /// यह पतित मामलों से बचने के लिए कुछ यादृच्छिकरण का उपयोग करता है, लेकिन एक निश्चित seed के साथ हमेशा नियतात्मक व्यवहार प्रदान करता है।
    ///
    /// सबसे खराब स्थिति में, एल्गोरिथ्म एक `Vec<(K, usize)>` स्लाइस की लंबाई में अस्थायी भंडारण आवंटित करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // आवंटन को कम करने के लिए हमारे vector को सबसे छोटे संभव प्रकार से अनुक्रमित करने के लिए हेल्पर मैक्रो।
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` के तत्व अद्वितीय हैं, क्योंकि वे अनुक्रमित हैं, इसलिए मूल स्लाइस के संबंध में कोई भी प्रकार स्थिर रहेगा।
                // हम यहां `sort_unstable` का उपयोग करते हैं क्योंकि इसके लिए कम मेमोरी आवंटन की आवश्यकता होती है।
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` को नए `Vec` में कॉपी करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // यहां, `s` और `x` को स्वतंत्र रूप से संशोधित किया जा सकता है।
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// एक आवंटक के साथ `self` को एक नए `Vec` में कॉपी करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // यहां, `s` और `x` को स्वतंत्र रूप से संशोधित किया जा सकता है।
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // एनबी, अधिक विवरण के लिए इस फ़ाइल में `hack` मॉड्यूल देखें।
        hack::to_vec(self, alloc)
    }

    /// क्लोन या आवंटन के बिना `self` को vector में कनवर्ट करता है।
    ///
    /// परिणामी vector को `Vec. के माध्यम से वापस एक बॉक्स में परिवर्तित किया जा सकता है<T>` की `into_boxed_slice` विधि।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` अब उपयोग नहीं किया जा सकता क्योंकि इसे `x` में बदल दिया गया है।
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // एनबी, अधिक विवरण के लिए इस फ़ाइल में `hack` मॉड्यूल देखें।
        hack::into_vec(self)
    }

    /// एक स्लाइस `n` बार दोहराकर vector बनाता है।
    ///
    /// # Panics
    ///
    /// यदि क्षमता अतिप्रवाह होगी तो यह फ़ंक्शन panic होगा।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// अतिप्रवाह पर एक panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // यदि `n` शून्य से बड़ा है, तो इसे `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` के रूप में विभाजित किया जा सकता है।
        // `2^expn` `n` के सबसे बाएं '1' बिट द्वारा दर्शाई गई संख्या है, और `rem` `n` का शेष भाग है।
        //
        //

        // `set_len()` तक पहुँचने के लिए `Vec` का उपयोग करना।
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` दोहराव `buf` `expn`-बार को दोगुना करके किया जाता है।
        buf.extend(self);
        {
            let mut m = n >> 1;
            // यदि `m > 0`, बाईं ओर '1' तक शेष बिट्स हैं।
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` की क्षमता है।
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2^expn`) दोहराव `buf` से ही पहले `rem` दोहराव को कॉपी करके किया जाता है।
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // यह `2^expn > rem` के बाद से गैर-अतिव्यापी है।
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` के बराबर (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` के एक स्लाइस को एकल मान `Self::Output` में समतल करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// प्रत्येक के बीच दिए गए विभाजक को रखते हुए, `T` के एक स्लाइस को एकल मान `Self::Output` में समतल करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// प्रत्येक के बीच दिए गए विभाजक को रखते हुए, `T` के एक स्लाइस को एकल मान `Self::Output` में समतल करता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// एक vector देता है जिसमें इस स्लाइस की एक प्रति होती है जहां प्रत्येक बाइट को इसके ASCII अपर केस के बराबर मैप किया जाता है।
    ///
    ///
    /// ASCII अक्षर 'a' से 'z' को 'A' से 'Z' में मैप किया गया है, लेकिन गैर-ASCII अक्षर अपरिवर्तित हैं।
    ///
    /// इन-प्लेस मान को अपरकेस करने के लिए, [`make_ascii_uppercase`] का उपयोग करें।
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// एक vector देता है जिसमें इस स्लाइस की एक प्रति होती है जहां प्रत्येक बाइट को इसके ASCII लोअर केस समकक्ष में मैप किया जाता है।
    ///
    ///
    /// ASCII अक्षर 'A' से 'Z' को 'a' से 'z' में मैप किया गया है, लेकिन गैर-ASCII अक्षर अपरिवर्तित हैं।
    ///
    /// इन-प्लेस मान को कम करने के लिए, [`make_ascii_lowercase`] का उपयोग करें।
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// विशिष्ट प्रकार के डेटा पर स्लाइस के लिए एक्सटेंशन traits
////////////////////////////////////////////////////////////////////////////////

/// [`[T]: :concat`](slice::concat) के लिए हेल्पर trait।
///
/// Note: इस trait में `Item` प्रकार पैरामीटर का उपयोग नहीं किया गया है, लेकिन यह impls को अधिक सामान्य बनाने की अनुमति देता है।
/// इसके बिना, हमें यह त्रुटि मिलती है:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// ऐसा इसलिए है क्योंकि कई `Borrow<[_]>` इम्प्लांट्स के साथ `V` प्रकार मौजूद हो सकते हैं, जैसे कि कई `T` प्रकार लागू होंगे:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// संयोजन के बाद परिणामी प्रकार
    type Output;

    /// [`[T]: :concat`](slice::concat) का कार्यान्वयन
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: :join`] के लिए हेल्पर trait (स्लाइस::ज्वाइन)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// संयोजन के बाद परिणामी प्रकार
    type Output;

    /// [`[T]: :join`](slice::join) का कार्यान्वयन
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// स्लाइस के लिए मानक trait कार्यान्वयन
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // लक्ष्य में कुछ भी छोड़ दें जिसे अधिलेखित नहीं किया जाएगा
        target.truncate(self.len());

        // target.len <= self.len ऊपर काटे जाने के कारण, इसलिए यहां के स्लाइस हमेशा इन-बाउंड होते हैं।
        //
        let (init, tail) = self.split_at(target.len());

        // निहित मान allocations/resources का पुन: उपयोग करें।
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` को पूर्व-सॉर्ट किए गए अनुक्रम `v[1..]` में सम्मिलित करता है ताकि संपूर्ण `v[..]` सॉर्ट हो जाए।
///
/// यह सम्मिलन प्रकार का अभिन्न सबरूटीन है।
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // यहां सम्मिलन को लागू करने के तीन तरीके हैं:
            //
            // 1. आसन्न तत्वों को तब तक स्वैप करें जब तक कि पहला अपने अंतिम गंतव्य तक न पहुंच जाए।
            //    हालांकि, इस तरह हम जरूरत से ज्यादा डेटा कॉपी करते हैं।
            //    यदि तत्व बड़ी संरचनाएं हैं (प्रतिलिपि बनाना महंगा है), तो यह विधि धीमी होगी।
            //
            // 2. पहले तत्व के लिए सही जगह मिलने तक पुनरावृति करें।
            // फिर इसके बाद के तत्वों को इसके लिए जगह बनाने के लिए शिफ्ट करें और अंत में इसे शेष छेद में रखें।
            // यह एक अच्छा तरीका है।
            //
            // 3. पहले तत्व को अस्थायी चर में कॉपी करें।इसके लिए सही जगह मिलने तक पुनरावृति करें।
            // जैसे-जैसे हम आगे बढ़ते हैं, प्रत्येक ट्रैवर्स किए गए तत्व को उसके पहले वाले स्लॉट में कॉपी करें।
            // अंत में, अस्थायी चर से डेटा को शेष छेद में कॉपी करें।
            // यह तरीका बहुत अच्छा है।
            // बेंचमार्क ने दूसरी विधि की तुलना में थोड़ा बेहतर प्रदर्शन किया।
            //
            // सभी विधियों को बेंचमार्क किया गया था, और तीसरे ने सर्वोत्तम परिणाम दिखाए।इसलिए हमने उसे चुना।
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // सम्मिलन प्रक्रिया की मध्यवर्ती स्थिति को हमेशा `hole` द्वारा ट्रैक किया जाता है, जो दो उद्देश्यों को पूरा करता है:
            // 1. `is_less` में panics से `v` की अखंडता की रक्षा करता है।
            // 2. `v` में बचे हुए छेद को अंत में भरता है।
            //
            // Panic सुरक्षा:
            //
            // यदि प्रक्रिया के दौरान किसी भी बिंदु पर `is_less` panics, `hole` गिरा दिया जाएगा और `v` में `tmp` के साथ छेद को भर देगा, इस प्रकार यह सुनिश्चित करता है कि `v` अभी भी प्रत्येक ऑब्जेक्ट को शुरू में ठीक एक बार रखता है।
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` गिरा दिया जाता है और इस प्रकार `tmp` को `v` में शेष छेद में कॉपी करता है।
        }
    }

    // गिराए जाने पर, `src` से `dest` में कॉपी हो जाती है।
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// अस्थायी भंडारण के रूप में `buf` का उपयोग करके गैर-घटते रन `v[..mid]` और `v[mid..]` को मर्ज करता है, और परिणाम को `v[..]` में संग्रहीत करता है।
///
/// # Safety
///
/// दो स्लाइस गैर-रिक्त होने चाहिए और `mid` सीमा में होना चाहिए।
/// बफ़र `buf` छोटे स्लाइस की एक प्रति रखने के लिए पर्याप्त लंबा होना चाहिए।
/// साथ ही, `T` शून्य-आकार का प्रकार नहीं होना चाहिए।
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // मर्ज प्रक्रिया पहले छोटे रन को `buf` में कॉपी करती है।
    // फिर यह नए कॉपी किए गए रन और लंबे रन फॉरवर्ड (या पीछे की ओर) का पता लगाता है, उनके अगले अप्रयुक्त तत्वों की तुलना करता है और कम (या अधिक) को `v` में कॉपी करता है।
    //
    // जैसे ही छोटी दौड़ पूरी तरह से समाप्त हो जाती है, प्रक्रिया पूरी हो जाती है।यदि लंबी दौड़ पहले खपत हो जाती है, तो हमें `v` में शेष छेद में जो कुछ भी बचा है उसे कॉपी करना होगा।
    //
    // प्रक्रिया की मध्यवर्ती स्थिति को हमेशा `hole` द्वारा ट्रैक किया जाता है, जो दो उद्देश्यों को पूरा करता है:
    // 1. `is_less` में panics से `v` की अखंडता की रक्षा करता है।
    // 2. `v` में शेष छेद को भरता है यदि लंबी अवधि पहले खपत हो जाती है।
    //
    // Panic सुरक्षा:
    //
    // यदि प्रक्रिया के दौरान किसी भी बिंदु पर `is_less` panics, `hole` गिरा दिया जाएगा और `buf` में बिना खपत वाले रेंज के साथ `v` में छेद भर देगा, इस प्रकार यह सुनिश्चित करता है कि `v` अभी भी प्रत्येक ऑब्जेक्ट को शुरू में ठीक एक बार रखता है।
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // बायां रन छोटा है।
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // प्रारंभ में, ये संकेत उनके सरणियों की शुरुआत की ओर इशारा करते हैं।
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // कम पक्ष का सेवन करें।
            // यदि बराबर है, तो स्थिरता बनाए रखने के लिए बाएं रन को प्राथमिकता दें।
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // राइट रन छोटा है।
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // प्रारंभ में, ये पॉइंटर्स अपने सरणियों के सिरों को इंगित करते हैं।
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // बड़े पक्ष का सेवन करें।
            // यदि बराबर है, तो स्थिरता बनाए रखने के लिए सही रन को प्राथमिकता दें।
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // अंत में, `hole` गिरा दिया जाता है।
    // यदि छोटी दौड़ का पूरी तरह से उपभोग नहीं किया गया था, तो इसके जो भी अवशेष बचे हैं, उन्हें अब `v` में होल में कॉपी किया जाएगा।

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // गिराए जाने पर, श्रेणी `start..end` को `dest..` में कॉपी करता है।
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` शून्य आकार का प्रकार नहीं है, इसलिए इसके आकार से विभाजित करना ठीक है।
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// यह मर्ज सॉर्ट टिमसॉर्ट से कुछ (लेकिन सभी नहीं) विचारों को उधार लेता है, जिसे विस्तार से [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) में वर्णित किया गया है।
///
///
/// एल्गोरिदम सख्ती से अवरोही और गैर-अवरोही अनुक्रमों की पहचान करता है, जिन्हें प्राकृतिक रन कहा जाता है।मर्ज किए जाने के लिए अभी तक लंबित रनों का ढेर है।
/// प्रत्येक नए पाए गए रन को स्टैक पर धकेल दिया जाता है, और फिर आसन्न रनों के कुछ जोड़े तब तक मर्ज किए जाते हैं जब तक कि ये दो अपरिवर्तनीय संतुष्ट न हों:
///
/// 1. `1..runs.len()` में प्रत्येक `i` के लिए: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()` में प्रत्येक `i` के लिए: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// अपरिवर्तनीय यह सुनिश्चित करते हैं कि कुल चलने का समय *O*(*n*\*log(* n*)) सबसे खराब स्थिति है।
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // इस लंबाई तक के स्लाइस को इंसर्शन सॉर्ट का उपयोग करके सॉर्ट किया जाता है।
    const MAX_INSERTION: usize = 20;
    // कम से कम इतने सारे तत्वों को फैलाने के लिए सम्मिलन प्रकार का उपयोग करके बहुत कम रन बढ़ाए जाते हैं।
    const MIN_RUN: usize = 10;

    // शून्य-आकार के प्रकारों पर छँटाई का कोई सार्थक व्यवहार नहीं है।
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // आवंटन से बचने के लिए सम्मिलन प्रकार के माध्यम से लघु सरणी को जगह में क्रमबद्ध किया जाता है।
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // स्क्रैच मेमोरी के रूप में उपयोग करने के लिए बफर आवंटित करें।हम लंबाई 0 रखते हैं ताकि हम इसमें `v` की सामग्री की उथली प्रतियां रख सकें, यदि `is_less` panics प्रतियों पर चलने वाले dtors को जोखिम में डाले बिना।
    //
    // दो सॉर्ट किए गए रनों को मर्ज करते समय, यह बफ़र छोटे रन की एक प्रति रखता है, जिसकी लंबाई हमेशा अधिकतम `len / 2` होगी।
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v` में प्राकृतिक रनों की पहचान करने के लिए, हम इसे पीछे की ओर ले जाते हैं।
    // यह एक अजीब निर्णय की तरह लग सकता है, लेकिन इस तथ्य पर विचार करें कि विलय अधिक बार विपरीत दिशा में जाते हैं (forwards)।
    // बेंचमार्क के अनुसार, पीछे की ओर विलय की तुलना में आगे की ओर विलय करना थोड़ा तेज है।
    // निष्कर्ष निकालने के लिए, पीछे की ओर ट्रैवर्स करके रनों की पहचान करने से प्रदर्शन में सुधार होता है।
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // अगला प्राकृतिक रन ढूंढें, और अगर यह सख्ती से उतर रहा है तो इसे उलट दें।
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // यदि यह बहुत छोटा है तो रन में कुछ और तत्व डालें।
        // सम्मिलन क्रम छोटे अनुक्रमों पर मर्ज सॉर्ट की तुलना में तेज़ है, इसलिए यह प्रदर्शन में उल्लेखनीय रूप से सुधार करता है।
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // इस रन को स्टैक पर पुश करें।
        runs.push(Run { start, len: end - start });
        end = start;

        // अपरिवर्तनीयों को संतुष्ट करने के लिए आसन्न रनों के कुछ जोड़े को मिलाएं।
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // अंत में, स्टैक में ठीक एक रन बना रहना चाहिए।
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // रनों के ढेर की जांच करता है और विलय के लिए रनों की अगली जोड़ी की पहचान करता है।
    // अधिक विशेष रूप से, यदि `Some(r)` लौटाया जाता है, तो इसका अर्थ है कि `runs[r]` और `runs[r + 1]` को आगे मर्ज किया जाना चाहिए।
    // यदि एल्गोरिथ्म को इसके बजाय एक नया रन बनाना जारी रखना चाहिए, तो `None` वापस आ जाता है।
    //
    // टिमसॉर्ट अपने बग्गी कार्यान्वयन के लिए बदनाम है, जैसा कि यहां बताया गया है:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // कहानी का सार यह है: हमें स्टैक पर शीर्ष चार रनों पर अपरिवर्तनीयों को लागू करना चाहिए।
    // केवल शीर्ष तीन पर उन्हें लागू करना यह सुनिश्चित करने के लिए पर्याप्त नहीं है कि इनवेरिएंट अभी भी स्टैक में *सभी* रन के लिए धारण करेगा।
    //
    // यह फ़ंक्शन शीर्ष चार रनों के लिए इनवेरिएंट की सही जांच करता है।
    // इसके अतिरिक्त, यदि टॉप रन इंडेक्स 0 से शुरू होता है, तो यह हमेशा मर्ज ऑपरेशन की मांग करेगा जब तक कि स्टैक पूरी तरह से ध्वस्त न हो जाए, ताकि सॉर्ट को पूरा किया जा सके।
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}