//! सिंगल-थ्रेडेड रेफरेंस-काउंटिंग पॉइंटर्स।'Rc' का मतलब 'संदर्भ' है
//! Counted'.
//!
//! प्रकार [`Rc<T>`][`Rc`] ढेर में आवंटित प्रकार `T` के मान का साझा स्वामित्व प्रदान करता है।
//! [`Rc`] पर [`clone`][clone] को आमंत्रित करने से ढेर में समान आवंटन के लिए एक नया सूचक उत्पन्न होता है।
//! जब किसी दिए गए आवंटन का अंतिम [`Rc`] सूचक नष्ट हो जाता है, तो उस आवंटन में संग्रहीत मूल्य (जिसे अक्सर "inner value" कहा जाता है) भी गिरा दिया जाता है।
//!
//! Rust में साझा संदर्भ डिफ़ॉल्ट रूप से उत्परिवर्तन को अस्वीकार करते हैं, और [`Rc`] कोई अपवाद नहीं है: आप आमतौर पर [`Rc`] के अंदर किसी चीज़ के लिए एक परिवर्तनशील संदर्भ प्राप्त नहीं कर सकते।
//! यदि आपको परिवर्तनशीलता की आवश्यकता है, तो [`Rc`] के अंदर [`Cell`] या [`RefCell`] डालें;[an example of mutability inside an `Rc`][mutability] देखें।
//!
//! [`Rc`] गैर-परमाणु संदर्भ गणना का उपयोग करता है।
//! इसका मतलब है कि ओवरहेड बहुत कम है, लेकिन थ्रेड्स के बीच [`Rc`] नहीं भेजा जा सकता है, और फलस्वरूप [`Rc`] [`Send`][send] को लागू नहीं करता है।
//! परिणामस्वरूप, Rust कंपाइलर *संकलन समय* पर जांच करेगा कि आप थ्रेड्स के बीच [`Rc`] s नहीं भेज रहे हैं।
//! यदि आपको बहु-थ्रेडेड, परमाणु संदर्भ गणना की आवश्यकता है, तो [`sync::Arc`][arc] का उपयोग करें।
//!
//! [`downgrade`][downgrade] विधि का उपयोग गैर-स्वामित्व वाले [`Weak`] पॉइंटर बनाने के लिए किया जा सकता है।
//! एक [`Weak`] पॉइंटर [`अपग्रेड`][अपग्रेड] d से [`Rc`] हो सकता है, लेकिन यदि आवंटन में संग्रहीत मान पहले ही गिरा दिया गया है, तो यह [`None`] लौटाएगा।
//! दूसरे शब्दों में, `Weak` पॉइंटर्स आवंटन के अंदर मूल्य को जीवित नहीं रखते हैं;हालांकि, वे आवंटन (आंतरिक मूल्य के लिए बैकिंग स्टोर) को जीवित रखते हैं।
//!
//! [`Rc`] पॉइंटर्स के बीच एक चक्र को कभी भी डील नहीं किया जाएगा।
//! इस कारण से, [`Weak`] का उपयोग साइकिल को तोड़ने के लिए किया जाता है।
//! उदाहरण के लिए, एक पेड़ में माता-पिता नोड्स से बच्चों के लिए मजबूत [`Rc`] पॉइंटर्स हो सकते हैं, और बच्चों से [`Weak`] पॉइंटर्स वापस उनके माता-पिता के पास हो सकते हैं।
//!
//! `Rc<T>` `T` ([`Deref`] trait के माध्यम से) के लिए स्वचालित रूप से dereferences, ताकि आप [`Rc<T>`][`Rc`] प्रकार के मान पर `T` के तरीकों को कॉल कर सकें।
//! 'T' के तरीकों के साथ नाम के टकराव से बचने के लिए, [`Rc<T>`][`Rc`] की विधियाँ ही संबद्ध कार्य हैं, जिन्हें [fully qualified syntax] का उपयोग करके कहा जाता है:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `आरसी<T>`Clone` की तरह traits के कार्यान्वयन को भी पूरी तरह से योग्य सिंटैक्स का उपयोग करके बुलाया जा सकता है।
//! कुछ लोग पूरी तरह से योग्य सिंटैक्स का उपयोग करना पसंद करते हैं, जबकि अन्य मेथड-कॉल सिंटैक्स का उपयोग करना पसंद करते हैं।
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // विधि-कॉल सिंटैक्सcall
//! let rc2 = rc.clone();
//! // पूरी तरह से योग्य वाक्यविन्यास
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T` को ऑटो-डीरेफरेंस नहीं करता है, क्योंकि हो सकता है कि आंतरिक मान पहले ही गिरा दिया गया हो।
//!
//! # क्लोनिंग संदर्भ
//!
//! मौजूदा संदर्भ गणना सूचक के समान आवंटन के लिए एक नया संदर्भ बनाना [`Rc<T>`][`Rc`] और [`Weak<T>`][`Weak`] के लिए कार्यान्वित `Clone` trait का उपयोग करके किया जाता है।
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // नीचे दिए गए दो सिंटैक्स समकक्ष हैं।
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // ए और बी दोनों एक ही स्मृति स्थान को फू के रूप में इंगित करते हैं।
//! ```
//!
//! `Rc::clone(&from)` सिंटैक्स सबसे मुहावरेदार है क्योंकि यह कोड के अर्थ को अधिक स्पष्ट रूप से बताता है।
//! उपरोक्त उदाहरण में, यह सिंटैक्स यह देखना आसान बनाता है कि यह कोड foo की संपूर्ण सामग्री को कॉपी करने के बजाय एक नया संदर्भ बना रहा है।
//!
//! # Examples
//!
//! एक ऐसे परिदृश्य पर विचार करें जहां `गैजेट` का एक सेट किसी दिए गए `Owner` के स्वामित्व में है।
//! हम चाहते हैं कि हमारा `गैजेट` बिंदु उनके `Owner` की ओर हो।हम अद्वितीय स्वामित्व के साथ ऐसा नहीं कर सकते, क्योंकि एक से अधिक गैजेट एक ही `Owner` से संबंधित हो सकते हैं।
//! [`Rc`] हमें कई `गैजेट` के बीच एक `Owner` साझा करने की अनुमति देता है, और `Owner` को तब तक आवंटित किया जाता है जब तक कि उस पर कोई भी `Gadget` अंक हो।
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ...अन्य क्षेत्र
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ...अन्य क्षेत्र
//! }
//!
//! fn main() {
//!     // एक संदर्भ-गिनती `Owner` बनाएं।
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` से संबंधित `गैजेट` बनाएं।
//!     // `Rc<Owner>` का क्लोनिंग हमें उसी `Owner` आवंटन के लिए एक नया सूचक देता है, जो प्रक्रिया में संदर्भ संख्या को बढ़ाता है।
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // हमारे स्थानीय चर `gadget_owner` का निपटान करें।
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` छोड़ने के बावजूद, हम अभी भी `गैजेट` के `Owner` के नाम का प्रिंट आउट लेने में सक्षम हैं।
//!     // ऐसा इसलिए है क्योंकि हमने केवल एक `Rc<Owner>` गिराया है, न कि उस `Owner` को जो यह इंगित करता है।
//!     // जब तक अन्य `Rc<Owner>` समान `Owner` आवंटन की ओर इशारा करते हैं, तब तक यह लाइव रहेगा।
//!     // फ़ील्ड प्रोजेक्शन `gadget1.owner.name` काम करता है क्योंकि `Rc<Owner>` स्वचालित रूप से `Owner` को डीरेफरेंस करता है।
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // फ़ंक्शन के अंत में, `gadget1` और `gadget2` नष्ट हो जाते हैं, और उनके साथ हमारे `Owner` के अंतिम गिने गए संदर्भ।
//!     // गैजेट मैन अब भी नष्ट हो जाता है।
//!     //
//! }
//! ```
//!
//! यदि हमारी आवश्यकताएं बदलती हैं, और हमें `Owner` से `Gadget` तक जाने में सक्षम होने की भी आवश्यकता है, तो हम समस्याओं में भाग लेंगे।
//! `Owner` से `Gadget` तक एक [`Rc`] सूचक एक चक्र का परिचय देता है।
//! इसका मतलब है कि उनकी संदर्भ संख्या कभी भी 0 तक नहीं पहुंच सकती है, और आवंटन कभी नष्ट नहीं होगा:
//! एक स्मृति रिसाव।इसे दूर करने के लिए, हम [`Weak`] पॉइंटर्स का उपयोग कर सकते हैं।
//!
//! Rust वास्तव में इस लूप को पहले स्थान पर बनाना कुछ मुश्किल बनाता है।एक दूसरे को इंगित करने वाले दो मूल्यों के साथ समाप्त होने के लिए, उनमें से एक को परिवर्तनीय होना चाहिए।
//! यह मुश्किल है क्योंकि [`Rc`] केवल लपेटे गए मूल्य के साझा संदर्भ देकर स्मृति सुरक्षा को लागू करता है, और ये प्रत्यक्ष उत्परिवर्तन की अनुमति नहीं देते हैं।
//! हमें उस मूल्य के हिस्से को लपेटने की आवश्यकता है जिसे हम [`RefCell`] में बदलना चाहते हैं, जो *आंतरिक परिवर्तनशीलता* प्रदान करता है: एक साझा संदर्भ के माध्यम से परिवर्तनशीलता प्राप्त करने की एक विधि।
//! [`RefCell`] रनटाइम पर Rust के उधार नियमों को लागू करता है।
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ...अन्य क्षेत्र
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ...अन्य क्षेत्र
//! }
//!
//! fn main() {
//!     // एक संदर्भ-गिनती `Owner` बनाएं।
//!     // ध्यान दें कि हमने 'गैजेट' के 'मालिक' के vector को एक `RefCell` के अंदर रखा है ताकि हम इसे एक साझा संदर्भ के माध्यम से बदल सकें।
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // पहले की तरह `gadget_owner` से संबंधित `गैजेट` बनाएं।
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // 'गैजेट' को उनके `Owner` में जोड़ें।
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` गतिशील उधार यहाँ समाप्त होता है।
//!     }
//!
//!     // हमारे `गैजेट` पर पुनरावृति करें, उनके विवरण प्रिंट करें।
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` एक `Weak<Gadget>` है।
//!         // चूंकि `Weak` पॉइंटर्स गारंटी नहीं दे सकते कि आवंटन अभी भी मौजूद है, हमें `upgrade` को कॉल करने की आवश्यकता है, जो `Option<Rc<Gadget>>` देता है।
//!         //
//!         //
//!         // इस मामले में हम जानते हैं कि आवंटन अभी भी मौजूद है, इसलिए हम केवल `unwrap` `Option` हैं।
//!         // अधिक जटिल प्रोग्राम में, आपको `None` परिणाम के लिए सुंदर त्रुटि प्रबंधन की आवश्यकता हो सकती है।
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // फ़ंक्शन के अंत में, `gadget_owner`, `gadget1`, और `gadget2` नष्ट हो जाते हैं।
//!     // गैजेट्स के लिए अब कोई मजबूत (`Rc`) पॉइंटर्स नहीं हैं, इसलिए वे नष्ट हो जाते हैं।
//!     // यह गैजेट मैन पर संदर्भ संख्या को शून्य कर देता है, इसलिए वह भी नष्ट हो जाता है।
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// यह संभावित फ़ील्ड-रीऑर्डरिंग के विरुद्ध repr(C) से future-प्रूफ है, जो ट्रांसम्यूटेबल आंतरिक प्रकारों के अन्यथा सुरक्षित [into|from]_raw() में हस्तक्षेप करेगा।
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// सिंगल-थ्रेडेड रेफरेंस-काउंटिंग पॉइंटर।'Rc' का मतलब 'संदर्भ' है
/// Counted'.
///
/// अधिक जानकारी के लिए [module-level documentation](./index.html) देखें।
///
/// `Rc` की अंतर्निहित विधियां सभी संबद्ध कार्य हैं, जिसका अर्थ है कि आपको उन्हें कॉल करना होगा जैसे, `value.get_mut()` के बजाय [`Rc::get_mut(&mut value)`][get_mut]।
/// यह आंतरिक प्रकार `T` के तरीकों के साथ विरोध से बचा जाता है।
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // यह असुरक्षितता ठीक है क्योंकि जब तक यह आरसी जीवित है, हम गारंटी देते हैं कि आंतरिक सूचक मान्य है।
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// एक नया `Rc<T>` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // सभी मजबूत पॉइंटर्स के स्वामित्व में एक निहित कमजोर सूचक है, जो यह सुनिश्चित करता है कि कमजोर विनाशक कभी भी आवंटन को मुक्त नहीं करता है, जबकि मजबूत विनाशक चल रहा है, भले ही कमजोर सूचक मजबूत के अंदर संग्रहीत हो।
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// अपने आप में एक कमजोर संदर्भ का उपयोग करके एक नया `Rc<T>` बनाता है।
    /// इस फ़ंक्शन के वापस आने से पहले कमजोर संदर्भ को अपग्रेड करने का प्रयास करने से `None` मान आएगा।
    ///
    /// हालांकि, कमजोर संदर्भ को स्वतंत्र रूप से क्लोन किया जा सकता है और बाद में उपयोग के लिए संग्रहीत किया जा सकता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... और क्षेत्र
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // एक कमजोर संदर्भ के साथ "uninitialized" स्थिति में आंतरिक निर्माण करें।
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // यह महत्वपूर्ण है कि हम कमजोर पॉइंटर का स्वामित्व न छोड़ें, अन्यथा `data_fn` के वापस आने तक मेमोरी मुक्त हो सकती है।
        // यदि हम वास्तव में स्वामित्व पारित करना चाहते हैं, तो हम अपने लिए एक अतिरिक्त कमजोर सूचक बना सकते हैं, लेकिन इसके परिणामस्वरूप कमजोर संदर्भ संख्या के अतिरिक्त अपडेट होंगे जो अन्यथा आवश्यक नहीं हो सकते हैं।
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // मजबूत संदर्भ सामूहिक रूप से एक साझा कमजोर संदर्भ का स्वामी होना चाहिए, इसलिए हमारे पुराने कमजोर संदर्भ के लिए विनाशक को न चलाएं।
        //
        mem::forget(weak);
        strong
    }

    /// अप्रारंभीकृत सामग्री के साथ एक नया `Rc` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // आस्थगित आरंभीकरण:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// प्रारंभिक सामग्री के साथ एक नया `Rc` बनाता है, जिसमें मेमोरी `0` बाइट्स से भरी जाती है।
    ///
    ///
    /// इस पद्धति के सही और गलत उपयोग के उदाहरणों के लिए [`MaybeUninit::zeroed`][zeroed] देखें।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// एक नया `Rc<T>` बनाता है, आवंटन विफल होने पर एक त्रुटि लौटाता है
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // सभी मजबूत पॉइंटर्स के स्वामित्व में एक निहित कमजोर सूचक है, जो यह सुनिश्चित करता है कि कमजोर विनाशक कभी भी आवंटन को मुक्त नहीं करता है, जबकि मजबूत विनाशक चल रहा है, भले ही कमजोर सूचक मजबूत के अंदर संग्रहीत हो।
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// अप्रारंभीकृत सामग्री के साथ एक नया `Rc` बनाता है, यदि आवंटन विफल रहता है तो एक त्रुटि लौटाता है
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // आस्थगित आरंभीकरण:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// प्रारंभिक सामग्री के साथ एक नया `Rc` बनाता है, जिसमें मेमोरी `0` बाइट्स से भरी जाती है, आवंटन विफल होने पर एक त्रुटि लौटाता है
    ///
    ///
    /// इस पद्धति के सही और गलत उपयोग के उदाहरणों के लिए [`MaybeUninit::zeroed`][zeroed] देखें।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// एक नया `Pin<Rc<T>>` बनाता है।
    /// यदि `T` `Unpin` को लागू नहीं करता है, तो `value` को मेमोरी में पिन किया जाएगा और स्थानांतरित करने में असमर्थ होगा।
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// आंतरिक मान लौटाता है, यदि `Rc` में बिल्कुल एक सशक्त संदर्भ है।
    ///
    /// अन्यथा, एक [`Err`] उसी `Rc` के साथ लौटाया जाता है जिसे पास किया गया था।
    ///
    ///
    /// बकाया कमजोर संदर्भ होने पर भी यह सफल होगा।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // निहित वस्तु की प्रतिलिपि बनाएँ

                // कमजोरों को संकेत दें कि उन्हें मजबूत गिनती को कम करके प्रचारित नहीं किया जा सकता है, और फिर केवल नकली कमजोर को क्राफ्ट करके ड्रॉप लॉजिक को संभालने के दौरान निहित "strong weak" पॉइंटर को हटा दें।
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// गैर-प्रारंभिक सामग्री के साथ एक नया संदर्भ-गिनती टुकड़ा बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // आस्थगित आरंभीकरण:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// प्रारंभिक सामग्री के साथ एक नया संदर्भ-गिनती टुकड़ा बनाता है, जिसमें स्मृति `0` बाइट्स से भरी जाती है।
    ///
    ///
    /// इस पद्धति के सही और गलत उपयोग के उदाहरणों के लिए [`MaybeUninit::zeroed`][zeroed] देखें।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` में कनवर्ट करता है।
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] के साथ, यह गारंटी देने के लिए कॉलर पर निर्भर है कि आंतरिक मूल्य वास्तव में प्रारंभिक स्थिति में है।
    ///
    /// जब सामग्री अभी तक पूरी तरह से प्रारंभ नहीं हुई है तो इसे कॉल करना तत्काल अपरिभाषित व्यवहार का कारण बनता है।
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // आस्थगित आरंभीकरण:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` में कनवर्ट करता है।
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] के साथ, यह गारंटी देने के लिए कॉलर पर निर्भर है कि आंतरिक मूल्य वास्तव में प्रारंभिक स्थिति में है।
    ///
    /// जब सामग्री अभी तक पूरी तरह से प्रारंभ नहीं हुई है तो इसे कॉल करना तत्काल अपरिभाषित व्यवहार का कारण बनता है।
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // आस्थगित आरंभीकरण:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// लपेटे हुए सूचक को वापस करते हुए, `Rc` का उपभोग करता है।
    ///
    /// स्मृति रिसाव से बचने के लिए पॉइंटर को [`Rc::from_raw`][from_raw] का उपयोग करके वापस `Rc` में परिवर्तित किया जाना चाहिए।
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// डेटा के लिए एक कच्चा सूचक प्रदान करता है।
    ///
    /// काउंट्स किसी भी तरह से प्रभावित नहीं होते हैं और `Rc` का उपभोग नहीं किया जाता है।
    /// सूचक तब तक मान्य है जब तक `Rc` में मजबूत संख्याएँ हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // सुरक्षा: यह Deref::deref या Rc::inner के माध्यम से नहीं जा सकता क्योंकि
        // यह raw/mut उद्गम को बनाए रखने के लिए आवश्यक है जैसे कि
        // `get_mut` `from_raw` के माध्यम से आरसी पुनर्प्राप्त होने के बाद सूचक के माध्यम से लिख सकते हैं।
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// एक कच्चे सूचक से एक `Rc<T>` का निर्माण करता है।
    ///
    /// रॉ पॉइंटर को पहले [`Rc<U>::into_raw`][into_raw] पर कॉल द्वारा लौटाया जाना चाहिए, जहां `U` का आकार और संरेखण `T` के समान होना चाहिए।
    /// यदि `U`, `T` है तो यह तुच्छ रूप से सत्य है।
    /// ध्यान दें कि यदि `U` `T` नहीं है, लेकिन उसका आकार और संरेखण समान है, तो यह मूल रूप से विभिन्न प्रकार के संदर्भों को प्रसारित करने जैसा है।
    /// इस मामले में कौन से प्रतिबंध लागू होते हैं, इस बारे में अधिक जानकारी के लिए [`mem::transmute`][transmute] देखें।
    ///
    /// `from_raw` के उपयोगकर्ता को यह सुनिश्चित करना होगा कि `T` का एक विशिष्ट मान केवल एक बार गिराया जाए।
    ///
    /// यह फ़ंक्शन असुरक्षित है क्योंकि अनुचित उपयोग से स्मृति असुरक्षित हो सकती है, भले ही लौटा हुआ `Rc<T>` कभी एक्सेस न किया गया हो।
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // रिसाव को रोकने के लिए वापस `Rc` में कनवर्ट करें।
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` पर आगे की कॉल स्मृति-असुरक्षित होगी।
    /// }
    ///
    /// // मेमोरी मुक्त हो गई थी जब `x` ऊपर के दायरे से बाहर हो गया था, इसलिए `x_ptr` अब लटक रहा है!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // मूल RcBox खोजने के लिए ऑफ़सेट को उल्टा करें।
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// इस आवंटन के लिए एक नया [`Weak`] सूचक बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // सुनिश्चित करें कि हम झूलने वाले कमजोर नहीं बनाते हैं
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// इस आवंटन के लिए [`Weak`] पॉइंटर्स की संख्या प्राप्त करें।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// इस आवंटन के लिए मजबूत (`Rc`) पॉइंटर्स की संख्या प्राप्त करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// यदि इस आवंटन में कोई अन्य `Rc` या [`Weak`] पॉइंटर्स नहीं हैं, तो `true` लौटाता है।
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// यदि समान आवंटन के लिए कोई अन्य `Rc` या [`Weak`] पॉइंटर्स नहीं हैं, तो दिए गए `Rc` में एक परिवर्तनशील संदर्भ देता है।
    ///
    ///
    /// अन्यथा [`None`] लौटाता है, क्योंकि साझा मान को बदलना सुरक्षित नहीं है।
    ///
    /// [`make_mut`][make_mut] भी देखें, जो अन्य पॉइंटर्स होने पर आंतरिक मान [`clone`][clone] करेगा।
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// दिए गए `Rc` में बिना किसी जांच के एक परिवर्तनीय संदर्भ देता है।
    ///
    /// [`get_mut`] भी देखें, जो सुरक्षित है और उचित जांच करता है।
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// किसी भी अन्य `Rc` या [`Weak`] पॉइंटर्स को समान आवंटन के लिए लौटाए गए उधार की अवधि के लिए संदर्भित नहीं किया जाना चाहिए।
    ///
    /// यह मामूली मामला है यदि ऐसा कोई संकेतक मौजूद नहीं है, उदाहरण के लिए `Rc::new` के तुरंत बाद।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // हम "count" फ़ील्ड्स को कवर करने वाले संदर्भ को *नहीं* बनाने के लिए सावधान हैं, क्योंकि यह संदर्भ गणनाओं तक पहुंच के साथ विरोध करेगा (उदाहरण के लिए)
        // `Weak` द्वारा)।
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// यदि दो `Rc` समान आवंटन की ओर इशारा करते हैं ([`ptr::eq`] के समान एक नस में) तो `true` लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// दिए गए `Rc` में एक परिवर्तनीय संदर्भ बनाता है।
    ///
    /// यदि समान आवंटन के लिए अन्य `Rc` पॉइंटर्स हैं, तो अद्वितीय स्वामित्व सुनिश्चित करने के लिए `make_mut` एक नए आवंटन के आंतरिक मूल्य को [`clone`] करेगा।
    /// इसे क्लोन-ऑन-राइट भी कहा जाता है।
    ///
    /// यदि इस आवंटन के लिए कोई अन्य `Rc` पॉइंटर्स नहीं हैं, तो इस आवंटन के लिए [`Weak`] पॉइंटर्स अलग हो जाएंगे।
    ///
    /// [`get_mut`] भी देखें, जो क्लोनिंग के बजाय विफल हो जाएगा।
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // कुछ भी क्लोन नहीं करेंगे
    /// let mut other_data = Rc::clone(&data);    // आंतरिक डेटा क्लोन नहीं करेगा
    /// *Rc::make_mut(&mut data) += 1;        // क्लोन आंतरिक डेटा
    /// *Rc::make_mut(&mut data) += 1;        // कुछ भी क्लोन नहीं करेंगे
    /// *Rc::make_mut(&mut other_data) *= 2;  // कुछ भी क्लोन नहीं करेंगे
    ///
    /// // अब `data` और `other_data` अलग-अलग आवंटन की ओर इशारा करते हैं।
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] पॉइंटर्स अलग हो जाएंगे:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // डेटा क्लोन करना होगा, अन्य आरसीएस हैं।
            // क्लोन किए गए मान को सीधे लिखने की अनुमति देने के लिए स्मृति को पूर्व-आवंटित करें।
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // केवल डेटा चुरा सकते हैं, जो कुछ बचा है वह कमजोर है
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // निहित मजबूत-कमजोर रेफरी निकालें (यहां नकली कमजोर को तैयार करने की कोई आवश्यकता नहीं है-हम जानते हैं कि अन्य कमजोर हमारे लिए सफाई कर सकते हैं)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // यह असुरक्षितता ठीक है क्योंकि हमें गारंटी है कि लौटाया गया पॉइंटर *only* पॉइंटर है जिसे कभी भी टी पर वापस कर दिया जाएगा।
        // इस बिंदु पर हमारी संदर्भ संख्या 1 होने की गारंटी है, और हमें `Rc<T>` को स्वयं `mut` होने की आवश्यकता है, इसलिए हम आवंटन का एकमात्र संभावित संदर्भ वापस कर रहे हैं।
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>` को एक ठोस प्रकार में डाउनकास्ट करने का प्रयास करें।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// एक संभावित-अनसाइज्ड आंतरिक मान के लिए पर्याप्त स्थान के साथ एक `RcBox<T>` आवंटित करता है जहां मान में लेआउट प्रदान किया गया है।
    ///
    /// फ़ंक्शन `mem_to_rcbox` को डेटा पॉइंटर के साथ बुलाया जाता है और `RcBox<T>` के लिए एक (संभावित रूप से वसा)-पॉइंटर वापस करना चाहिए।
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // दिए गए मान लेआउट का उपयोग करके लेआउट की गणना करें।
        // पहले, लेआउट की गणना `&*(ptr as* const RcBox<T>)` अभिव्यक्ति पर की गई थी, लेकिन इसने एक गलत संरेखित संदर्भ बनाया (देखें #54908)।
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// एक संभावित-अनसाइज्ड आंतरिक मान के लिए पर्याप्त स्थान के साथ एक `RcBox<T>` आवंटित करता है जहां मान में लेआउट प्रदान किया गया है, आवंटन विफल होने पर एक त्रुटि लौटाता है।
    ///
    ///
    /// फ़ंक्शन `mem_to_rcbox` को डेटा पॉइंटर के साथ बुलाया जाता है और `RcBox<T>` के लिए एक (संभावित रूप से वसा)-पॉइंटर वापस करना चाहिए।
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // दिए गए मान लेआउट का उपयोग करके लेआउट की गणना करें।
        // पहले, लेआउट की गणना `&*(ptr as* const RcBox<T>)` अभिव्यक्ति पर की गई थी, लेकिन इसने एक गलत संरेखित संदर्भ बनाया (देखें #54908)।
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // लेआउट के लिए आवंटित करें।
        let ptr = allocate(layout)?;

        // आरसीबॉक्स को इनिशियलाइज़ करें
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// एक अनसाइज़्ड आंतरिक मान के लिए पर्याप्त स्थान के साथ एक `RcBox<T>` आवंटित करता है
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // दिए गए मान का उपयोग करके `RcBox<T>` के लिए आवंटन करें।
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // मूल्य को बाइट्स के रूप में कॉपी करें
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // इसकी सामग्री को छोड़े बिना आवंटन को मुक्त करें
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// दी गई लंबाई के साथ एक `RcBox<[T]>` आवंटित करता है।
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// स्लाइस से तत्वों को नए आवंटित आरसी में कॉपी करें<\[T\]>
    ///
    /// असुरक्षित क्योंकि कॉल करने वाले को या तो स्वामित्व लेना चाहिए या `T: Copy` को बाध्य करना चाहिए
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// एक निश्चित आकार के ज्ञात पुनरावर्तक से `Rc<[T]>` का निर्माण करता है।
    ///
    /// आकार गलत होना चाहिए व्यवहार अपरिभाषित है।
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // T तत्वों की क्लोनिंग करते समय Panic गार्ड।
        // panic की स्थिति में, नए RcBox में लिखे गए तत्वों को हटा दिया जाएगा, फिर मेमोरी मुक्त हो जाएगी।
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // पहले तत्व के लिए सूचक
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // सब साफ़।गार्ड को भूल जाओ ताकि यह नया आरसीबॉक्स मुक्त न करे।
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// विशेषज्ञता trait `From<&[T]>` के लिए प्रयुक्त।
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` गिराता है।
    ///
    /// यह मजबूत संदर्भ संख्या में कमी करेगा।
    /// यदि मजबूत संदर्भ संख्या शून्य तक पहुंच जाती है तो केवल अन्य संदर्भ (यदि कोई हो) [`Weak`] हैं, इसलिए हम आंतरिक मान `drop` करते हैं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // कुछ भी नहीं छापता
    /// drop(foo2);   // प्रिंट "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // निहित वस्तु को नष्ट करें
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // हमने सामग्री को नष्ट कर दिया है, अब निहित "strong weak" सूचक को हटा दें।
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` पॉइंटर का क्लोन बनाता है।
    ///
    /// यह समान आवंटन के लिए एक और सूचक बनाता है, मजबूत संदर्भ संख्या को बढ़ाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` के लिए `Default` मान के साथ एक नया `Rc<T>` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` पर विशेषज्ञता की अनुमति देने के लिए हैक करें, भले ही `Eq` में एक विधि हो।
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// हम यह विशेषज्ञता यहां कर रहे हैं, न कि `&T` पर अधिक सामान्य अनुकूलन के रूप में, क्योंकि यह अन्यथा रेफरी पर सभी समानता जांचों के लिए एक लागत जोड़ देगा।
/// हम मानते हैं कि `Rc` का उपयोग बड़े मूल्यों को संग्रहीत करने के लिए किया जाता है, जो क्लोन करने के लिए धीमे होते हैं, लेकिन समानता की जांच करने के लिए भारी भी होते हैं, जिससे यह लागत अधिक आसानी से चुकानी पड़ती है।
///
/// इसमें दो `Rc` क्लोन होने की भी अधिक संभावना है, जो दो `&T` की तुलना में समान मान की ओर इशारा करते हैं।
///
/// हम ऐसा तभी कर सकते हैं जब `T: Eq` एक `PartialEq` के रूप में जानबूझकर अपरिवर्तनीय हो।
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// दो `आरसी` के लिए समानता।
    ///
    /// दो `Rc` बराबर हैं यदि उनके आंतरिक मूल्य समान हैं, भले ही वे अलग-अलग आवंटन में संग्रहीत हों।
    ///
    /// यदि `T` भी `Eq` (समानता की परावर्तकता को लागू करता है) को लागू करता है, तो दो `Rc` जो समान आवंटन को इंगित करते हैं, हमेशा बराबर होते हैं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// दो `आरसी` के लिए असमानता।
    ///
    /// दो `Rc` असमान हैं यदि उनके आंतरिक मूल्य असमान हैं।
    ///
    /// यदि `T` भी `Eq` को लागू करता है (समानता की रिफ्लेक्सिविटी को लागू करता है), तो दो `Rc` जो समान आवंटन को इंगित करते हैं, कभी भी असमान नहीं होते हैं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// दो `आरसी` के लिए आंशिक तुलना।
    ///
    /// `partial_cmp()` को उनके आंतरिक मूल्यों पर कॉल करके दोनों की तुलना की जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// दो `आरसी` के लिए तुलना से कम।
    ///
    /// `<` को उनके आंतरिक मूल्यों पर कॉल करके दोनों की तुलना की जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// दो `Rc` के लिए तुलना 'से कम या इसके बराबर'।
    ///
    /// `<=` को उनके आंतरिक मूल्यों पर कॉल करके दोनों की तुलना की जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// दो `आरसी` के लिए तुलना से बड़ा।
    ///
    /// `>` को उनके आंतरिक मूल्यों पर कॉल करके दोनों की तुलना की जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// दो `Rc` के लिए तुलना 'से बड़ा या इसके बराबर'।
    ///
    /// `>=` को उनके आंतरिक मूल्यों पर कॉल करके दोनों की तुलना की जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// दो `आरसी` के लिए तुलना।
    ///
    /// `cmp()` को उनके आंतरिक मूल्यों पर कॉल करके दोनों की तुलना की जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// एक संदर्भ-गिनती टुकड़ा आवंटित करें और `v` की वस्तुओं को क्लोन करके इसे भरें।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// एक संदर्भ-गिनती स्ट्रिंग स्लाइस आवंटित करें और उसमें `v` की प्रतिलिपि बनाएँ।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// एक संदर्भ-गिनती स्ट्रिंग स्लाइस आवंटित करें और उसमें `v` की प्रतिलिपि बनाएँ।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// एक बॉक्स किए गए ऑब्जेक्ट को एक नए, संदर्भ गिने, आवंटन में ले जाएं।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// एक संदर्भ-गिनती टुकड़ा आवंटित करें और उसमें `v` की वस्तुओं को स्थानांतरित करें।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec को उसकी मेमोरी को मुक्त करने दें, लेकिन उसकी सामग्री को नष्ट न करें
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// प्रत्येक तत्व को `Iterator` में लेता है और उसे `Rc<[T]>` में एकत्रित करता है।
    ///
    /// # प्रदर्शन गुण
    ///
    /// ## सामान्य मामला
    ///
    /// सामान्य स्थिति में, `Rc<[T]>` में एकत्रित करना पहले `Vec<T>` में एकत्रित करके किया जाता है।अर्थात्, निम्नलिखित लिखते समय:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// यह ऐसा व्यवहार करता है जैसे हमने लिखा है:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // आवंटन का पहला सेट यहां होता है।
    ///     .into(); // `Rc<[T]>` के लिए दूसरा आवंटन यहां होता है।
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// यह `Vec<T>` के निर्माण के लिए जितनी बार आवश्यक हो उतनी बार आवंटित करेगा और फिर `Vec<T>` को `Rc<[T]>` में बदलने के लिए एक बार आवंटित करेगा।
    ///
    ///
    /// ## ज्ञात लंबाई के पुनरावर्तक
    ///
    /// जब आपका `Iterator` `TrustedLen` लागू करता है और सटीक आकार का होता है, तो `Rc<[T]>` के लिए एक ही आवंटन किया जाएगा।उदाहरण के लिए:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // यहां केवल एक आवंटन होता है।
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// विशेषज्ञता trait `Rc<[T]>` में एकत्रित करने के लिए उपयोग की जाती है।
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // यह एक `TrustedLen` इटरेटर का मामला है।
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // सुरक्षा: हमें यह सुनिश्चित करने की ज़रूरत है कि इटरेटर की सटीक लंबाई है और हमारे पास है।
                Rc::from_iter_exact(self, low)
            }
        } else {
            // सामान्य कार्यान्वयन पर वापस जाएं।
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` [`Rc`] का एक संस्करण है जो प्रबंधित आवंटन के लिए एक गैर-स्वामित्व वाला संदर्भ रखता है।आवंटन को `Weak` पॉइंटर पर [`upgrade`] को कॉल करके एक्सेस किया जाता है, जो एक [`Option`]`<`[`Rc`]`लौटाता है।<T>>`।
///
/// चूंकि `Weak` संदर्भ स्वामित्व की ओर नहीं गिना जाता है, यह आवंटन में संग्रहीत मूल्य को गिराए जाने से नहीं रोकेगा, और `Weak` स्वयं अभी भी मौजूद मूल्य के बारे में कोई गारंटी नहीं देता है।
/// इस प्रकार यह [`None`] वापस आ सकता है जब [`अपग्रेड`] डी।
/// ध्यान दें कि एक `Weak` संदर्भ *करता है* आवंटन को स्वयं (बैकिंग स्टोर) को हटाए जाने से रोकता है।
///
/// एक `Weak` पॉइंटर [`Rc`] द्वारा प्रबंधित आवंटन के लिए एक अस्थायी संदर्भ रखने के लिए उपयोगी है, इसके आंतरिक मूल्य को गिराए बिना रोके।
/// इसका उपयोग [`Rc`] पॉइंटर्स के बीच परिपत्र संदर्भों को रोकने के लिए भी किया जाता है, क्योंकि पारस्परिक स्वामित्व वाले संदर्भ कभी भी [`Rc`] को छोड़ने की अनुमति नहीं देंगे।
/// उदाहरण के लिए, एक पेड़ में माता-पिता नोड्स से बच्चों के लिए मजबूत [`Rc`] पॉइंटर्स हो सकते हैं, और बच्चों से `Weak` पॉइंटर्स वापस उनके माता-पिता के पास हो सकते हैं।
///
/// `Weak` पॉइंटर प्राप्त करने का सामान्य तरीका [`Rc::downgrade`] को कॉल करना है।
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // यह एक `NonNull` है जो इस प्रकार के आकार को एनम में अनुकूलित करने की अनुमति देता है, लेकिन यह आवश्यक रूप से एक वैध सूचक नहीं है।
    //
    // `Weak::new` इसे `usize::MAX` पर सेट करता है ताकि इसे ढेर पर स्थान आवंटित करने की आवश्यकता न हो।
    // यह एक मूल्य नहीं है जो एक वास्तविक सूचक के पास होगा क्योंकि आरसीबॉक्स में कम से कम 2 संरेखण है।
    // यह तभी संभव है जब `T: Sized`;अनसाइज़्ड `T` कभी नहीं लटकता।
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// कोई मेमोरी आवंटित किए बिना, एक नया `Weak<T>` बनाता है।
    /// रिटर्न वैल्यू पर [`upgrade`] को कॉल करना हमेशा [`None`] देता है।
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// डेटा फ़ील्ड के बारे में कोई दावा किए बिना संदर्भ गणना तक पहुंचने की अनुमति देने के लिए सहायक प्रकार।
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// इस `Weak<T>` द्वारा इंगित वस्तु `T` पर एक कच्चा सूचक लौटाता है।
    ///
    /// पॉइंटर तभी मान्य होता है जब कुछ मजबूत संदर्भ हों।
    /// सूचक लटकता हुआ, असंरेखित या अन्यथा [`null`] भी हो सकता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // दोनों एक ही वस्तु की ओर इशारा करते हैं
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // यहां मजबूत इसे जीवित रखता है, इसलिए हम अभी भी वस्तु तक पहुंच सकते हैं।
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // लेकिन अब और नहीं।
    /// // हम weak.as_ptr() कर सकते हैं, लेकिन पॉइंटर तक पहुंचने से अपरिभाषित व्यवहार हो जाएगा।
    /// // assert_eq! ("हैलो", असुरक्षित {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // यदि सूचक लटक रहा है, तो हम सीधे प्रहरी को वापस कर देते हैं।
            // यह एक वैध पेलोड पता नहीं हो सकता है, क्योंकि पेलोड कम से कम RcBox (usize) के समान संरेखित है।
            ptr as *const T
        } else {
            // सुरक्षा: यदि is_dangling झूठी वापसी करता है, तो सूचक dereferencable है।
            // इस बिंदु पर पेलोड गिराया जा सकता है, और हमें उत्पत्ति बनाए रखनी होगी, इसलिए कच्चे सूचक हेरफेर का उपयोग करें।
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` का उपभोग करता है और इसे एक कच्चे सूचक में बदल देता है।
    ///
    /// यह कमजोर सूचक को कच्चे सूचक में परिवर्तित करता है, जबकि अभी भी एक कमजोर संदर्भ के स्वामित्व को संरक्षित करता है (कमजोर गणना इस ऑपरेशन द्वारा संशोधित नहीं की जाती है)।
    /// इसे [`from_raw`] के साथ `Weak<T>` में वापस बदला जा सकता है।
    ///
    /// [`as_ptr`] के साथ पॉइंटर के लक्ष्य तक पहुँचने के समान प्रतिबंध लागू होते हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`] द्वारा पहले बनाए गए कच्चे पॉइंटर को वापस `Weak<T>` में कनवर्ट करता है।
    ///
    /// इसका उपयोग सुरक्षित रूप से एक मजबूत संदर्भ प्राप्त करने के लिए किया जा सकता है (बाद में [`upgrade`] को कॉल करके) या `Weak<T>` को गिराकर कमजोर गिनती को हटाने के लिए।
    ///
    /// यह एक कमजोर संदर्भ का स्वामित्व लेता है ([`new`] द्वारा बनाए गए पॉइंटर्स के अपवाद के साथ, क्योंकि इनके पास कुछ भी नहीं है; विधि अभी भी उन पर काम करती है)।
    ///
    /// # Safety
    ///
    /// सूचक [`into_raw`] से उत्पन्न हुआ होगा और अभी भी इसके संभावित कमजोर संदर्भ का स्वामी होना चाहिए।
    ///
    /// इसे कॉल करने के समय मजबूत गिनती 0 होने की अनुमति है।
    /// फिर भी, यह एक कमजोर संदर्भ का स्वामित्व लेता है जिसे वर्तमान में एक कच्चे सूचक के रूप में दर्शाया गया है (कमजोर गणना इस ऑपरेशन द्वारा संशोधित नहीं है) और इसलिए इसे [`into_raw`] के पिछले कॉल के साथ जोड़ा जाना चाहिए।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // अंतिम कमजोर गणना घटाएं।
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // इनपुट पॉइंटर कैसे प्राप्त होता है, इस संदर्भ के लिए Weak::as_ptr देखें।

        let ptr = if is_dangling(ptr as *mut T) {
            // यह एक लटकता हुआ कमजोर है।
            ptr as *mut RcBox<T>
        } else {
            // अन्यथा, हम गारंटी देते हैं कि सूचक एक गैर लटकने वाले कमजोर से आया है।
            // सुरक्षा: data_offset कॉल करने के लिए सुरक्षित है, क्योंकि ptr एक वास्तविक (संभावित रूप से गिरा हुआ) T को संदर्भित करता है।
            let offset = unsafe { data_offset(ptr) };
            // इस प्रकार, हम संपूर्ण RcBox प्राप्त करने के लिए ऑफ़सेट को उलट देते हैं।
            // सुरक्षा: सूचक कमजोर से उत्पन्न हुआ है, इसलिए यह ऑफ़सेट सुरक्षित है।
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // सुरक्षा: अब हमने मूल कमजोर सूचक को पुनः प्राप्त कर लिया है, इसलिए कमजोर बना सकते हैं।
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` पॉइंटर को [`Rc`] में अपग्रेड करने का प्रयास, सफल होने पर आंतरिक मान को छोड़ने में देरी करता है।
    ///
    ///
    /// यदि आंतरिक मान तब से गिरा दिया गया है, तो [`None`] लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // सभी मजबूत संकेतकों को नष्ट करें।
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// इस आवंटन को इंगित करने वाले मजबूत (`Rc`) पॉइंटर्स की संख्या प्राप्त करता है।
    ///
    /// यदि `self` को [`Weak::new`] का उपयोग करके बनाया गया था, तो यह 0 लौटाएगा।
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// इस आवंटन को इंगित करने वाले `Weak` पॉइंटर्स की संख्या प्राप्त करें।
    ///
    /// यदि कोई मजबूत संकेत नहीं रहता है, तो यह शून्य वापस आ जाएगा।
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // निहित कमजोर ptr. घटाएं
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// जब पॉइंटर लटकता है और कोई आवंटित `RcBox` नहीं होता है, तो `None` लौटाता है, (यानी, जब यह `Weak` `Weak::new` द्वारा बनाया गया था)।
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // हम "data" फ़ील्ड को कवर करने के लिए *नहीं* संदर्भ बनाने के लिए सावधान हैं, क्योंकि फ़ील्ड को समवर्ती रूप से उत्परिवर्तित किया जा सकता है (उदाहरण के लिए, यदि अंतिम `Rc` गिरा दिया जाता है, तो डेटा फ़ील्ड को जगह में छोड़ दिया जाएगा)।
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// यदि दो `कमजोर` समान आवंटन ([`ptr::eq`] के समान) की ओर इशारा करते हैं, या यदि दोनों किसी आवंटन को इंगित नहीं करते हैं, तो `true` लौटाता है (क्योंकि वे `Weak::new()`) के साथ बनाए गए थे।
    ///
    ///
    /// # Notes
    ///
    /// चूंकि यह पॉइंटर्स की तुलना करता है इसका मतलब है कि `Weak::new()` एक दूसरे के बराबर होगा, भले ही वे किसी आवंटन को इंगित न करें।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` की तुलना।
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` पॉइंटर को ड्रॉप करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // कुछ भी नहीं छापता
    /// drop(foo);        // प्रिंट "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // कमजोर गिनती 1 से शुरू होती है और केवल तभी शून्य होगी जब सभी मजबूत संकेत गायब हो जाएंगे।
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// `Weak` पॉइंटर का क्लोन बनाता है जो समान आवंटन की ओर इशारा करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// एक नए `Weak<T>` का निर्माण करता है, इसे प्रारंभ किए बिना `T` के लिए मेमोरी आवंटित करता है।
    /// रिटर्न वैल्यू पर [`upgrade`] को कॉल करना हमेशा [`None`] देता है।
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: हमने mem::forget से सुरक्षित रूप से निपटने के लिए यहां check_add किया है।विशेष रूप से
// यदि आप mem::forget Rcs (या कमजोर) हैं, तो रेफ-काउंट ओवरफ्लो हो सकता है, और फिर आप आवंटन को मुक्त कर सकते हैं जबकि बकाया Rcs (या कमजोर) मौजूद हैं।
//
// हम गर्भपात करते हैं क्योंकि यह एक ऐसा पतित परिदृश्य है कि हमें परवाह नहीं है कि क्या होता है-किसी भी वास्तविक कार्यक्रम को कभी भी इसका अनुभव नहीं करना चाहिए।
//
// यह नगण्य ओवरहेड होना चाहिए क्योंकि स्वामित्व और चाल-शब्दार्थ के लिए आपको वास्तव में Rust में इन्हें बहुत अधिक क्लोन करने की आवश्यकता नहीं है।
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // हम मूल्य छोड़ने के बजाय अतिप्रवाह पर निरस्त करना चाहते हैं।
        // जब इसे कहा जाता है तो संदर्भ संख्या कभी भी शून्य नहीं होगी;
        // फिर भी, हम एलएलवीएम को अन्यथा छूटे हुए अनुकूलन पर संकेत देने के लिए यहां एक गर्भपात सम्मिलित करते हैं।
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // हम मूल्य छोड़ने के बजाय अतिप्रवाह पर निरस्त करना चाहते हैं।
        // जब इसे कहा जाता है तो संदर्भ संख्या कभी भी शून्य नहीं होगी;
        // फिर भी, हम एलएलवीएम को अन्यथा छूटे हुए अनुकूलन पर संकेत देने के लिए यहां एक गर्भपात सम्मिलित करते हैं।
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// एक पॉइंटर के पीछे पेलोड के लिए `RcBox` के भीतर ऑफ़सेट प्राप्त करें।
///
/// # Safety
///
/// पॉइंटर को टी के पहले मान्य उदाहरण को इंगित करना चाहिए (और उसके लिए वैध मेटाडेटा होना चाहिए), लेकिन टी को छोड़ने की अनुमति है।
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // अनसाइज़्ड मान को RcBox के अंत में संरेखित करें।
    // क्योंकि RcBox repr(C) है, यह हमेशा मेमोरी में अंतिम फ़ील्ड होगा।
    // सुरक्षा: चूंकि केवल अनसाइज्ड प्रकार संभव हैं स्लाइस, trait ऑब्जेक्ट्स,
    // और बाहरी प्रकार, इनपुट सुरक्षा आवश्यकता वर्तमान में align_of_val_raw की आवश्यकताओं को पूरा करने के लिए पर्याप्त है;यह उस भाषा का कार्यान्वयन विवरण है जिस पर std के बाहर भरोसा नहीं किया जा सकता है।
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}