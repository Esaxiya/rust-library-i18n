use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// एक पुनरावर्तक जो यह निर्धारित करने के लिए बंद का उपयोग करता है कि किसी तत्व को हटाया जाना चाहिए या नहीं।
///
/// यह संरचना [`Vec::drain_filter`] द्वारा बनाई गई है।
/// अधिक के लिए इसके दस्तावेज़ देखें।
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// आइटम की अनुक्रमणिका जिसका निरीक्षण `next` पर अगली कॉल द्वारा किया जाएगा।
    pub(super) idx: usize,
    /// अब तक (removed) से निकाले गए आइटमों की संख्या।
    pub(super) del: usize,
    /// जल निकासी से पहले `vec` की मूल लंबाई।
    pub(super) old_len: usize,
    /// फ़िल्टर परीक्षण विधेय।
    pub(super) pred: F,
    /// फ़िल्टर परीक्षण विधेय में panic इंगित करने वाला ध्वज उत्पन्न हुआ है।
    /// यह शेष `DrainFilter` की खपत को रोकने के लिए ड्रॉप कार्यान्वयन में एक संकेत के रूप में उपयोग किया जाता है।
    /// किसी भी असंसाधित आइटम को `vec` में बैकशिफ्ट किया जाएगा, लेकिन फ़िल्टर विधेय द्वारा कोई और आइटम गिराया या परीक्षण नहीं किया जाएगा।
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// अंतर्निहित आवंटक का संदर्भ देता है।
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // इंडेक्स को अपडेट करें *के बाद* विधेय कहा जाता है।
                // यदि अनुक्रमणिका को पहले अद्यतन किया जाता है और panics विधेय किया जाता है, तो इस अनुक्रमणिका का तत्व लीक हो जाएगा।
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // यह एक बहुत ही गड़बड़ स्थिति है, और वास्तव में ऐसा करने के लिए स्पष्ट रूप से सही काम नहीं है।
                        // हम `pred` को निष्पादित करने का प्रयास नहीं करना चाहते हैं, इसलिए हम सभी असंसाधित तत्वों को बैकशिफ्ट करते हैं और vec को बताते हैं कि वे अभी भी मौजूद हैं।
                        //
                        // विधेय में panic से पहले अंतिम सफलतापूर्वक ड्रेन किए गए आइटम की डबल-ड्रॉप को रोकने के लिए बैकशिफ्ट की आवश्यकता होती है।
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // यदि फ़िल्टर विधेय अभी तक घबराया नहीं है, तो किसी भी शेष तत्व का उपभोग करने का प्रयास करें।
        // हम किसी भी शेष तत्व को बैकशिफ्ट करेंगे चाहे हम पहले ही घबरा चुके हों या यदि यहां खपत panics हो।
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}