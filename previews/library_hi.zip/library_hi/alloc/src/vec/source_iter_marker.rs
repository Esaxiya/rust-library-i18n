use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// स्रोत आवंटन का पुन: उपयोग करते समय एक पुनरावर्तक पाइपलाइन को Vec में एकत्रित करने के लिए विशेषज्ञता मार्कर, अर्थात
/// जगह-जगह पाइप लाइन चला रहे हैं।
///
/// सोर्सइटर पैरेंट trait विशेषज्ञता वाले फ़ंक्शन के लिए आवंटन को एक्सेस करने के लिए आवश्यक है जिसे पुन: उपयोग किया जाना है।
/// लेकिन विशेषज्ञता के वैध होने के लिए यह पर्याप्त नहीं है।
/// इम्प्लांट पर अतिरिक्त सीमाएं देखें।
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-आंतरिक SourceIter/InPlaceIterable traits केवल एडेप्टर की श्रृंखला द्वारा कार्यान्वित किया जाता है <Adapter<Adapter<IntoIter>>> (सभी core/std के स्वामित्व में हैं)।
// एडेप्टर कार्यान्वयन (`impl<I: Trait> Trait for Adapter<I>` से परे) पर अतिरिक्त सीमाएं केवल अन्य traits पर निर्भर करती हैं जिन्हें पहले से ही विशेषज्ञता traits (कॉपी, ट्रस्टेडरैंडमएक्सेस, फ्यूज्डइटरेटर) के रूप में चिह्नित किया गया है।
//
// I.e. मार्कर उपयोगकर्ता द्वारा आपूर्ति किए गए प्रकारों के जीवनकाल पर निर्भर नहीं करता है।मोडुलो द कॉपी होल, जिस पर कई अन्य विशेषज्ञता पहले से ही निर्भर हैं।
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // अतिरिक्त आवश्यकताएं जो trait bounds के माध्यम से व्यक्त नहीं की जा सकती हैं।हम इसके बजाय const eval पर भरोसा करते हैं:
        // ए) कोई जेडएसटी नहीं क्योंकि पुन: उपयोग के लिए कोई आवंटन नहीं होगा और पॉइंटर अंकगणित panic होगा बी) आवंटन अनुबंध द्वारा आवश्यक आकार मिलान सी) आवंटन अनुबंध द्वारा आवश्यक संरेखण मिलान
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // अधिक सामान्य कार्यान्वयन के लिए वापसी
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // ट्राइ-फोल्ड का उपयोग करें
        // - यह कुछ इटरेटर एडेप्टर के लिए बेहतर वेक्टर करता है
        // - अधिकांश आंतरिक पुनरावृत्ति विधियों के विपरीत, यह केवल &mut स्वयं लेता है
        // - यह हमें लिखने वाले सूचक को इसके अंदरूनी हिस्सों के माध्यम से थ्रेड करने देता है और इसे अंत में वापस लाता है
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // पुनरावृत्ति सफल रही, सिर न गिराएं
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // जांचें कि क्या SourceIter अनुबंध को बरकरार रखा गया था चेतावनी: यदि वे नहीं थे तो हम इसे इस बिंदु पर भी नहीं बना सकते हैं
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // InPlaceIterable अनुबंध की जाँच करें।यह तभी संभव है जब इटरेटर स्रोत सूचक को बिल्कुल उन्नत करे।
        // यदि यह TrustedRandomAccess के माध्यम से अनियंत्रित पहुंच का उपयोग करता है तो स्रोत सूचक अपनी प्रारंभिक स्थिति में रहेगा और हम इसे संदर्भ के रूप में उपयोग नहीं कर सकते हैं
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // स्रोत की पूंछ पर किसी भी शेष मान को छोड़ दें, लेकिन आवंटन की गिरावट को रोकें एक बार IntoIter गुंजाइश से बाहर हो जाता है यदि ड्रॉप panics तो हम dst_buf में एकत्र किए गए किसी भी तत्व को भी लीक करते हैं
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable अनुबंध को यहां सटीक रूप से सत्यापित नहीं किया जा सकता है क्योंकि try_fold में स्रोत सूचक के लिए एक विशेष संदर्भ है, हम केवल यह जांच सकते हैं कि यह अभी भी सीमा में है या नहीं
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}