use core::ptr::{self};
use core::slice::{self};

// इन-प्लेस पुनरावृत्ति के लिए एक सहायक संरचना जो पुनरावृत्ति के गंतव्य टुकड़ा, यानी सिर को छोड़ देती है।
// स्रोत टुकड़ा (पूंछ) IntoIter द्वारा गिरा दिया गया है।
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}