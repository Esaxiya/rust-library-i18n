//! ढेर-आवंटित सामग्री के साथ एक सन्निहित बढ़ने योग्य सरणी प्रकार, लिखित `Vec<T>`।
//!
//! Vectors में `O(1)` अनुक्रमण, परिशोधित `O(1)` पुश (अंत तक) और `O(1)` पॉप (अंत से) है।
//!
//!
//! Vectors सुनिश्चित करते हैं कि वे कभी भी `isize::MAX` बाइट्स से अधिक आवंटित न करें।
//!
//! # Examples
//!
//! आप स्पष्ट रूप से [`Vec::new`] के साथ [`Vec`] बना सकते हैं:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ...या [`vec!`] मैक्रो का उपयोग करके:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // दस शून्य
//! ```
//!
//! आप vector के अंत में [`push`] मान कर सकते हैं (जो आवश्यकतानुसार vector को बढ़ाएगा):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! पॉपिंग मान उसी तरह से काम करता है:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors भी अनुक्रमण का समर्थन करता है ([`Index`] और [`IndexMut`] traits के माध्यम से):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// एक सन्निहित बढ़ने योग्य सरणी प्रकार, जिसे `Vec<T>` के रूप में लिखा गया है और 'vector' का उच्चारण किया गया है।
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// आरंभीकरण को और अधिक सुविधाजनक बनाने के लिए [`vec!`] मैक्रो प्रदान किया गया है:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// यह किसी दिए गए मान के साथ `Vec<T>` के प्रत्येक तत्व को इनिशियलाइज़ भी कर सकता है।
/// यह अलग-अलग चरणों में आवंटन और आरंभीकरण करने से अधिक कुशल हो सकता है, खासकर जब शून्य के vector को प्रारंभ करना:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // निम्नलिखित समतुल्य है, लेकिन संभावित रूप से धीमा है:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// अधिक जानकारी के लिए, [Capacity and Reallocation](#capacity-and-reallocation) देखें।
///
/// एक कुशल स्टैक के रूप में `Vec<T>` का उपयोग करें:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // प्रिंट 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` प्रकार इंडेक्स द्वारा मूल्यों तक पहुंचने की अनुमति देता है, क्योंकि यह [`Index`] trait को लागू करता है।एक उदाहरण अधिक स्पष्ट होगा:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // यह '2' प्रदर्शित करेगा
/// ```
///
/// हालाँकि सावधान रहें: यदि आप किसी ऐसे इंडेक्स तक पहुँचने का प्रयास करते हैं जो `Vec` में नहीं है, तो आपका सॉफ़्टवेयर panic!तुम यह नहीं कर सकते:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// यदि आप यह जांचना चाहते हैं कि अनुक्रमणिका `Vec` में है या नहीं, तो [`get`] और [`get_mut`] का उपयोग करें।
///
/// # Slicing
///
/// एक `Vec` परिवर्तनशील हो सकता है।दूसरी ओर, स्लाइस केवल-पढ़ने के लिए ऑब्जेक्ट हैं।
/// [slice][prim@slice] प्राप्त करने के लिए, [`&`] का उपयोग करें।उदाहरण:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... और यह सबकुछ है!
/// // आप इसे इस तरह भी कर सकते हैं:
/// let u: &[usize] = &v;
/// // या इस तरह:
/// let u: &[_] = &v;
/// ```
///
/// Rust में, जब आप केवल रीड एक्सेस प्रदान करना चाहते हैं, तो vectors के बजाय स्लाइस को तर्क के रूप में पास करना अधिक सामान्य है।वही [`String`] और [`&str`] के लिए जाता है।
///
/// # क्षमता और पुनः आवंटन
///
/// vector की क्षमता किसी भी future तत्वों के लिए आवंटित स्थान की मात्रा है जिसे vector पर जोड़ा जाएगा।इसे vector की *लंबाई* के साथ भ्रमित नहीं होना है, जो vector के भीतर वास्तविक तत्वों की संख्या निर्दिष्ट करता है।
/// यदि vector की लंबाई इसकी क्षमता से अधिक है, तो इसकी क्षमता स्वचालित रूप से बढ़ जाएगी, लेकिन इसके तत्वों को फिर से आवंटित करना होगा।
///
/// उदाहरण के लिए, एक vector क्षमता 10 और लंबाई 0 के साथ एक खाली vector होगा जिसमें 10 और तत्वों के लिए जगह होगी।vector पर 10 या उससे कम तत्वों को धकेलने से इसकी क्षमता में कोई बदलाव नहीं आएगा या फिर से आवंटन नहीं होगा।
/// हालांकि, अगर vector की लंबाई बढ़ाकर 11 कर दी जाती है, तो इसे फिर से आवंटित करना होगा, जो धीमा हो सकता है।इस कारण से, जब भी संभव हो [`Vec::with_capacity`] का उपयोग करने की सिफारिश की जाती है ताकि यह निर्दिष्ट किया जा सके कि vector को कितना बड़ा मिलने की उम्मीद है।
///
/// # Guarantees
///
/// इसकी अविश्वसनीय रूप से मौलिक प्रकृति के कारण, `Vec` इसके डिजाइन के बारे में बहुत सारी गारंटी देता है।यह सुनिश्चित करता है कि यह सामान्य मामले में जितना संभव हो उतना कम ओवरहेड है, और असुरक्षित कोड द्वारा आदिम तरीकों से सही ढंग से हेरफेर किया जा सकता है।ध्यान दें कि ये गारंटी एक अयोग्य `Vec<T>` को संदर्भित करती है।
/// यदि अतिरिक्त प्रकार के पैरामीटर जोड़े जाते हैं (उदाहरण के लिए, कस्टम आवंटकों का समर्थन करने के लिए), तो उनके डिफ़ॉल्ट को ओवरराइड करने से व्यवहार बदल सकता है।
///
/// सबसे मौलिक रूप से, `Vec` एक (सूचक, क्षमता, लंबाई) ट्रिपलेट है और हमेशा रहेगा।ना ज्य़ादा ना कम।इन क्षेत्रों का क्रम पूरी तरह से अनिर्दिष्ट है, और आपको इन्हें संशोधित करने के लिए उपयुक्त विधियों का उपयोग करना चाहिए।
/// सूचक कभी भी अशक्त नहीं होगा, इसलिए यह प्रकार अशक्त-सूचक-अनुकूलित है।
///
/// हालांकि, पॉइंटर वास्तव में आवंटित स्मृति को इंगित नहीं कर सकता है।
/// विशेष रूप से, यदि आप [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] के माध्यम से क्षमता 0 के साथ `Vec` का निर्माण करते हैं, या खाली Vec पर [`shrink_to_fit`] को कॉल करके, यह मेमोरी आवंटित नहीं करेगा।इसी तरह, यदि आप `Vec` के अंदर शून्य-आकार के प्रकारों को संग्रहीत करते हैं, तो यह उनके लिए स्थान आवंटित नहीं करेगा।
/// *ध्यान दें कि इस मामले में `Vec` 0* के [`capacity`] की रिपोर्ट नहीं कर सकता है।
/// `Vec` आवंटित करेगा यदि और केवल यदि [`mem: :size_of::<T>`]`() * capacity()> 0`।
/// सामान्य तौर पर, `Vec` का आवंटन विवरण बहुत सूक्ष्म होता है-यदि आप `Vec` का उपयोग करके मेमोरी आवंटित करना चाहते हैं और इसे किसी और चीज़ के लिए उपयोग करना चाहते हैं (या तो असुरक्षित कोड को पास करने के लिए, या अपना स्वयं का मेमोरी-समर्थित संग्रह बनाने के लिए), सुनिश्चित करें `Vec` को पुनर्प्राप्त करने और फिर इसे छोड़ने के लिए `from_raw_parts` का उपयोग करके इस स्मृति को हटाने के लिए।
///
/// यदि एक `Vec`*में* आवंटित मेमोरी है, तो वह जिस मेमोरी को इंगित करता है वह हीप पर है (जैसा कि आवंटक Rust द्वारा परिभाषित किया गया है, डिफ़ॉल्ट रूप से उपयोग करने के लिए कॉन्फ़िगर किया गया है), और इसका पॉइंटर [`len`] आरंभिक, सन्निहित तत्वों को क्रम में इंगित करता है (आप क्या करेंगे देखें कि क्या आपने इसे एक स्लाइस के लिए मजबूर किया है), इसके बाद [`क्षमता`]`,`[`लेन`] तार्किक रूप से अप्रारंभीकृत, सन्निहित तत्व हैं।
///
///
/// क्षमता 4 के साथ `'a'` और `'b'` तत्वों वाले vector को नीचे के रूप में देखा जा सकता है।शीर्ष भाग `Vec` संरचना है, इसमें ढेर, लंबाई और क्षमता में आवंटन के शीर्ष पर एक सूचक होता है।
/// निचला हिस्सा ढेर पर आवंटन है, एक सन्निहित मेमोरी ब्लॉक।
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** स्मृति का प्रतिनिधित्व करता है जो आरंभिक नहीं है, [`MaybeUninit`] देखें।
/// - Note: ABI स्थिर नहीं है और `Vec` इसके मेमोरी लेआउट (फ़ील्ड के क्रम सहित) के बारे में कोई गारंटी नहीं देता है।
///
/// `Vec` "small optimization" कभी भी प्रदर्शन नहीं करेगा जहां तत्व वास्तव में दो कारणों से स्टैक पर संग्रहीत होते हैं:
///
/// * यह असुरक्षित कोड के लिए `Vec` को सही ढंग से हेरफेर करना अधिक कठिन बना देगा।`Vec` की सामग्री का एक स्थिर पता नहीं होगा यदि इसे केवल स्थानांतरित किया गया था, और यह निर्धारित करना अधिक कठिन होगा कि क्या `Vec` ने वास्तव में स्मृति आवंटित की थी।
///
/// * यह सामान्य मामले को दंडित करेगा, प्रत्येक एक्सेस पर एक अतिरिक्त branch खर्च करेगा।
///
/// `Vec` पूरी तरह से खाली होने पर भी, अपने आप कभी नहीं सिकुड़ेगा।यह सुनिश्चित करता है कि कोई अनावश्यक आवंटन या डीललोकेशन न हो।एक `Vec` को खाली करना और फिर उसे वापस उसी [`len`] में भरना आवंटक को कोई कॉल नहीं करना चाहिए।यदि आप अप्रयुक्त मेमोरी को खाली करना चाहते हैं, तो [`shrink_to_fit`] या [`shrink_to`] का उपयोग करें।
///
/// [`push`] और यदि रिपोर्ट की गई क्षमता पर्याप्त है तो [`insert`] कभी भी (पुनः) आवंटित नहीं करेगा।यदि [`लेन`]`==`[`क्षमता`] हो तो [`push`] और [`insert`] *(पुनः) आवंटित करेंगे।यही है, रिपोर्ट की गई क्षमता पूरी तरह से सटीक है, और इस पर भरोसा किया जा सकता है।यदि वांछित हो तो इसका उपयोग `Vec` द्वारा आवंटित स्मृति को मैन्युअल रूप से मुक्त करने के लिए भी किया जा सकता है।
/// बल्क इंसर्शन मेथड्स *फिर से आवंटित* हो सकता है, तब भी जब आवश्यक न हो।
///
/// `Vec` पूर्ण होने पर पुन: आवंटन करते समय किसी विशेष विकास रणनीति की गारंटी नहीं देता है, न ही जब [`reserve`] कहा जाता है।वर्तमान रणनीति बुनियादी है और गैर-स्थिर विकास कारक का उपयोग करना वांछनीय साबित हो सकता है।जो भी रणनीति का उपयोग किया जाता है वह निश्चित रूप से *O*(1) परिशोधन [`push`] की गारंटी देगा।
///
/// `vec![x; n]`, `vec![a, b, c, d]`, और [`Vec::with_capacity(n)`][`Vec::with_capacity`], बिल्कुल अनुरोधित क्षमता के साथ `Vec` का उत्पादन करेंगे।
/// यदि [`len`]`==`[`क्षमता`], (जैसा कि [`vec!`] मैक्रो के मामले में है), तो एक `Vec<T>` को तत्वों को फिर से आवंटित या स्थानांतरित किए बिना [`Box<[T]>`][owned slice] में और उससे परिवर्तित किया जा सकता है।
///
/// `Vec` इससे निकाले गए किसी भी डेटा को विशेष रूप से अधिलेखित नहीं करेगा, लेकिन विशेष रूप से इसे संरक्षित भी नहीं करेगा।इसकी अप्रारंभीकृत मेमोरी स्क्रैच स्पेस है जिसे वह अपनी इच्छानुसार उपयोग कर सकता है।यह आम तौर पर वही करेगा जो सबसे कुशल या अन्यथा लागू करने में आसान है।सुरक्षा उद्देश्यों के लिए हटाए गए डेटा को मिटाने पर भरोसा न करें।
/// यहां तक कि अगर आप एक `Vec` छोड़ते हैं, तो इसके बफर को दूसरे `Vec` द्वारा पुन: उपयोग किया जा सकता है।
/// यहां तक कि अगर आप पहले एक `Vec` की मेमोरी को शून्य करते हैं, तो वास्तव में ऐसा नहीं हो सकता है क्योंकि ऑप्टिमाइज़र इसे एक साइड-इफ़ेक्ट नहीं मानता है जिसे संरक्षित किया जाना चाहिए।
/// एक मामला है जिसे हम नहीं तोड़ेंगे, हालांकि: अतिरिक्त क्षमता को लिखने के लिए `unsafe` कोड का उपयोग करना, और फिर मिलान करने के लिए लंबाई बढ़ाना, हमेशा मान्य होता है।
///
/// वर्तमान में, `Vec` उस क्रम की गारंटी नहीं देता है जिसमें तत्व गिराए जाते हैं।
/// आदेश अतीत में बदल गया है और फिर से बदल सकता है।
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// अंतर्निहित तरीके
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// एक नया, खाली `Vec<T>` बनाता है।
    ///
    /// vector तब तक आवंटित नहीं होगा जब तक कि उस पर तत्वों को धक्का नहीं दिया जाता।
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// निर्दिष्ट क्षमता के साथ एक नया, खाली `Vec<T>` बनाता है।
    ///
    /// vector बिना पुन: आवंटन के बिल्कुल `capacity` तत्वों को धारण करने में सक्षम होगा।
    /// यदि `capacity` 0 है, तो vector आवंटित नहीं किया जाएगा।
    ///
    /// यह नोट करना महत्वपूर्ण है कि हालांकि लौटाए गए vector में निर्दिष्ट *क्षमता* है, vector में शून्य *लंबाई* होगी।
    ///
    /// लंबाई और क्षमता के बीच अंतर की व्याख्या के लिए, देखें *[क्षमता और पुनः आवंटन]*।
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector में कोई आइटम नहीं है, भले ही इसमें अधिक क्षमता हो
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ये सभी पुन: आवंटित किए बिना किए जाते हैं ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ...लेकिन यह vector को फिर से आवंटित कर सकता है
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// दूसरे vector के कच्चे घटकों से सीधे `Vec<T>` बनाता है।
    ///
    /// # Safety
    ///
    /// चेक नहीं किए गए इनवेरिएंट की संख्या के कारण यह अत्यधिक असुरक्षित है:
    ///
    /// * `ptr` पहले [`स्ट्रिंग`]/`Vec के माध्यम से आवंटित करने की आवश्यकता है<T>` (कम से कम, यह गलत होने की अत्यधिक संभावना है यदि यह नहीं था)।
    /// * `T` उसी आकार और संरेखण की आवश्यकता है जिसे `ptr` के साथ आवंटित किया गया था।
    ///   (`T` कम सख्त संरेखण होना पर्याप्त नहीं है, संरेखण को वास्तव में [`dealloc`] आवश्यकता को पूरा करने के लिए बराबर होना चाहिए कि स्मृति को उसी लेआउट के साथ आवंटित और हटा दिया जाना चाहिए।)
    ///
    /// * `length` `capacity` से कम या उसके बराबर होना चाहिए।
    /// * `capacity` वह क्षमता होनी चाहिए जिसके साथ सूचक को आवंटित किया गया था।
    ///
    /// इनका उल्लंघन करने से आवंटक की आंतरिक डेटा संरचनाओं को दूषित करने जैसी समस्याएं हो सकती हैं।उदाहरण के लिए, एक पॉइंटर से C `char` सरणी में लंबाई `size_t` के साथ `Vec<u8>` बनाना सुरक्षित नहीं है।
    /// `Vec<u16>` और उसकी लंबाई से एक का निर्माण करना भी सुरक्षित नहीं है, क्योंकि आवंटक संरेखण की परवाह करता है, और इन दो प्रकारों में अलग-अलग संरेखण होते हैं।
    /// बफर को संरेखण 2 (`u16` के लिए) के साथ आवंटित किया गया था, लेकिन इसे `Vec<u8>` में बदलने के बाद इसे संरेखण 1 से हटा दिया जाएगा।
    ///
    /// `ptr` का स्वामित्व प्रभावी रूप से `Vec<T>` को स्थानांतरित कर दिया जाता है जो तब पॉइंटर द्वारा इंगित स्मृति की सामग्री को हटा सकता है, पुनः आवंटित या बदल सकता है।
    /// सुनिश्चित करें कि इस फ़ंक्शन को कॉल करने के बाद और कुछ भी पॉइंटर का उपयोग नहीं करता है।
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME इसे अपडेट करें जब vec_into_raw_parts स्थिर हो जाए।
    ///     // `v` के विनाशक को चलाने से रोकें ताकि हम आवंटन के पूर्ण नियंत्रण में हों।
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v`. के बारे में जानकारी के विभिन्न महत्वपूर्ण अंशों को बाहर निकालें
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // स्मृति को 4, 5, 6 with से अधिलेखित करें
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // सब कुछ वापस एक साथ एक Vec. में डाल दें
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// एक नया, खाली `Vec<T, A>` बनाता है।
    ///
    /// vector तब तक आवंटित नहीं होगा जब तक कि उस पर तत्वों को धक्का नहीं दिया जाता।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// प्रदान किए गए आवंटनकर्ता के साथ निर्दिष्ट क्षमता के साथ एक नया, खाली `Vec<T, A>` बनाता है।
    ///
    /// vector बिना पुन: आवंटन के बिल्कुल `capacity` तत्वों को धारण करने में सक्षम होगा।
    /// यदि `capacity` 0 है, तो vector आवंटित नहीं किया जाएगा।
    ///
    /// यह नोट करना महत्वपूर्ण है कि हालांकि लौटाए गए vector में निर्दिष्ट *क्षमता* है, vector में शून्य *लंबाई* होगी।
    ///
    /// लंबाई और क्षमता के बीच अंतर की व्याख्या के लिए, देखें *[क्षमता और पुनः आवंटन]*।
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector में कोई आइटम नहीं है, भले ही इसमें अधिक क्षमता हो
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ये सभी पुन: आवंटित किए बिना किए जाते हैं ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ...लेकिन यह vector को फिर से आवंटित कर सकता है
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// दूसरे vector के कच्चे घटकों से सीधे `Vec<T, A>` बनाता है।
    ///
    /// # Safety
    ///
    /// चेक नहीं किए गए इनवेरिएंट की संख्या के कारण यह अत्यधिक असुरक्षित है:
    ///
    /// * `ptr` पहले [`स्ट्रिंग`]/`Vec के माध्यम से आवंटित करने की आवश्यकता है<T>` (कम से कम, यह गलत होने की अत्यधिक संभावना है यदि यह नहीं था)।
    /// * `T` उसी आकार और संरेखण की आवश्यकता है जिसे `ptr` के साथ आवंटित किया गया था।
    ///   (`T` कम सख्त संरेखण होना पर्याप्त नहीं है, संरेखण को वास्तव में [`dealloc`] आवश्यकता को पूरा करने के लिए बराबर होना चाहिए कि स्मृति को उसी लेआउट के साथ आवंटित और हटा दिया जाना चाहिए।)
    ///
    /// * `length` `capacity` से कम या उसके बराबर होना चाहिए।
    /// * `capacity` वह क्षमता होनी चाहिए जिसके साथ सूचक को आवंटित किया गया था।
    ///
    /// इनका उल्लंघन करने से आवंटक की आंतरिक डेटा संरचनाओं को दूषित करने जैसी समस्याएं हो सकती हैं।उदाहरण के लिए, एक पॉइंटर से C `char` सरणी में लंबाई `size_t` के साथ `Vec<u8>` बनाना सुरक्षित नहीं है।
    /// `Vec<u16>` और उसकी लंबाई से एक का निर्माण करना भी सुरक्षित नहीं है, क्योंकि आवंटक संरेखण की परवाह करता है, और इन दो प्रकारों में अलग-अलग संरेखण होते हैं।
    /// बफर को संरेखण 2 (`u16` के लिए) के साथ आवंटित किया गया था, लेकिन इसे `Vec<u8>` में बदलने के बाद इसे संरेखण 1 से हटा दिया जाएगा।
    ///
    /// `ptr` का स्वामित्व प्रभावी रूप से `Vec<T>` को स्थानांतरित कर दिया जाता है जो तब पॉइंटर द्वारा इंगित स्मृति की सामग्री को हटा सकता है, पुनः आवंटित या बदल सकता है।
    /// सुनिश्चित करें कि इस फ़ंक्शन को कॉल करने के बाद और कुछ भी पॉइंटर का उपयोग नहीं करता है।
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME इसे अपडेट करें जब vec_into_raw_parts स्थिर हो जाए।
    ///     // `v` के विनाशक को चलाने से रोकें ताकि हम आवंटन के पूर्ण नियंत्रण में हों।
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v`. के बारे में जानकारी के विभिन्न महत्वपूर्ण अंशों को बाहर निकालें
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // स्मृति को 4, 5, 6 with से अधिलेखित करें
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // सब कुछ वापस एक साथ एक Vec. में डाल दें
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// अपने कच्चे घटकों में एक `Vec<T>` को विघटित करता है।
    ///
    /// कच्चे सूचक को अंतर्निहित डेटा, vector की लंबाई (तत्वों में), और डेटा की आवंटित क्षमता (तत्वों में) देता है।
    /// [`from_raw_parts`] के तर्कों के समान क्रम में ये समान तर्क हैं।
    ///
    /// इस फ़ंक्शन को कॉल करने के बाद, कॉलर पहले `Vec` द्वारा प्रबंधित मेमोरी के लिए ज़िम्मेदार है।
    /// ऐसा करने का एकमात्र तरीका कच्चे सूचक, लंबाई और क्षमता को [`from_raw_parts`] फ़ंक्शन के साथ वापस `Vec` में परिवर्तित करना है, जिससे विध्वंसक को सफाई करने की अनुमति मिलती है।
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // अब हम घटकों में परिवर्तन कर सकते हैं, जैसे कि रॉ पॉइंटर को संगत प्रकार में बदलना।
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// अपने कच्चे घटकों में एक `Vec<T>` को विघटित करता है।
    ///
    /// कच्चे सूचक को अंतर्निहित डेटा, vector की लंबाई (तत्वों में), डेटा की आवंटित क्षमता (तत्वों में), और आवंटक देता है।
    /// [`from_raw_parts_in`] के तर्कों के समान क्रम में ये समान तर्क हैं।
    ///
    /// इस फ़ंक्शन को कॉल करने के बाद, कॉलर पहले `Vec` द्वारा प्रबंधित मेमोरी के लिए ज़िम्मेदार है।
    /// ऐसा करने का एकमात्र तरीका कच्चे सूचक, लंबाई और क्षमता को [`from_raw_parts_in`] फ़ंक्शन के साथ वापस `Vec` में परिवर्तित करना है, जिससे विध्वंसक को सफाई करने की अनुमति मिलती है।
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // अब हम घटकों में परिवर्तन कर सकते हैं, जैसे कि रॉ पॉइंटर को संगत प्रकार में बदलना।
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// उन तत्वों की संख्या लौटाता है जिन्हें vector पुनः आवंटित किए बिना धारण कर सकता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// दिए गए `Vec<T>` में कम से कम `additional` अधिक तत्वों को सम्मिलित करने की क्षमता सुरक्षित रखता है।
    /// बार-बार पुन: आवंटन से बचने के लिए संग्रह अधिक स्थान आरक्षित कर सकता है।
    /// `reserve` को कॉल करने के बाद, क्षमता `self.len() + additional` से अधिक या उसके बराबर होगी।
    /// अगर क्षमता पहले से ही पर्याप्त है तो कुछ नहीं करता।
    ///
    /// # Panics
    ///
    /// Panics यदि नई क्षमता `isize::MAX` बाइट्स से अधिक है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// दिए गए `Vec<T>` में बिल्कुल `additional` अधिक तत्वों को सम्मिलित करने के लिए न्यूनतम क्षमता सुरक्षित रखता है।
    ///
    /// `reserve_exact` को कॉल करने के बाद, क्षमता `self.len() + additional` से अधिक या उसके बराबर होगी।
    /// अगर क्षमता पहले से ही पर्याप्त है तो कुछ भी नहीं करता है।
    ///
    /// ध्यान दें कि आवंटक संग्रह को अनुरोध से अधिक स्थान दे सकता है।
    /// इसलिए, क्षमता को ठीक न्यूनतम होने पर भरोसा नहीं किया जा सकता है।
    /// `reserve` को प्राथमिकता दें यदि future सम्मिलन अपेक्षित हैं।
    ///
    /// # Panics
    ///
    /// Panics यदि नई क्षमता `usize` से अधिक हो जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// दिए गए `Vec<T>` में कम से कम `additional` अधिक तत्वों को सम्मिलित करने के लिए क्षमता आरक्षित करने का प्रयास करता है।
    /// बार-बार पुन: आवंटन से बचने के लिए संग्रह अधिक स्थान आरक्षित कर सकता है।
    /// `try_reserve` को कॉल करने के बाद, क्षमता `self.len() + additional` से अधिक या उसके बराबर होगी।
    /// अगर क्षमता पहले से ही पर्याप्त है तो कुछ नहीं करता।
    ///
    /// # Errors
    ///
    /// यदि क्षमता ओवरफ्लो हो जाती है, या आवंटक विफलता की रिपोर्ट करता है, तो एक त्रुटि वापस कर दी जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // मेमोरी को प्री-रिजर्व करें, अगर हम नहीं कर सकते हैं तो बाहर निकलें
    ///     output.try_reserve(data.len())?;
    ///
    ///     // अब हम जानते हैं कि यह हमारे जटिल कार्य के बीच में OOM नहीं कर सकता
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // बहुत जटिल
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// दिए गए `Vec<T>` में बिल्कुल `additional` तत्वों को सम्मिलित करने के लिए न्यूनतम क्षमता आरक्षित करने का प्रयास करता है।
    /// `try_reserve_exact` को कॉल करने के बाद, क्षमता `self.len() + additional` से अधिक या उसके बराबर होगी यदि वह `Ok(())` लौटाता है।
    ///
    /// अगर क्षमता पहले से ही पर्याप्त है तो कुछ भी नहीं करता है।
    ///
    /// ध्यान दें कि आवंटक संग्रह को अनुरोध से अधिक स्थान दे सकता है।
    /// इसलिए, क्षमता को ठीक न्यूनतम होने पर भरोसा नहीं किया जा सकता है।
    /// `reserve` को प्राथमिकता दें यदि future सम्मिलन अपेक्षित हैं।
    ///
    /// # Errors
    ///
    /// यदि क्षमता ओवरफ्लो हो जाती है, या आवंटक विफलता की रिपोर्ट करता है, तो एक त्रुटि वापस कर दी जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // मेमोरी को प्री-रिजर्व करें, अगर हम नहीं कर सकते हैं तो बाहर निकलें
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // अब हम जानते हैं कि यह हमारे जटिल कार्य के बीच में OOM नहीं कर सकता
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // बहुत जटिल
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// जितना संभव हो vector की क्षमता को सिकोड़ें।
    ///
    /// यह लंबाई के जितना करीब हो सके नीचे गिर जाएगा लेकिन आवंटक अभी भी vector को सूचित कर सकता है कि कुछ और तत्वों के लिए जगह है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // क्षमता कभी भी लंबाई से कम नहीं होती है, और जब वे बराबर होते हैं तो कुछ भी नहीं करना होता है, इसलिए हम `RawVec::shrink_to_fit` में panic मामले को केवल अधिक क्षमता के साथ कॉल करके टाल सकते हैं।
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// vector की क्षमता को कम बाउंड के साथ सिकोड़ता है।
    ///
    /// क्षमता कम से कम लंबाई और आपूर्ति मूल्य दोनों जितनी बड़ी रहेगी।
    ///
    ///
    /// यदि वर्तमान क्षमता निचली सीमा से कम है, तो यह नो-ऑप है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector को [`Box<[T]>`][owned slice] में कनवर्ट करता है।
    ///
    /// ध्यान दें कि यह किसी भी अतिरिक्त क्षमता को गिरा देगा।
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// किसी भी अतिरिक्त क्षमता को हटा दिया जाता है:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// vector को छोटा करता है, पहले `len` तत्वों को रखता है और बाकी को छोड़ देता है।
    ///
    /// यदि `len` vector की वर्तमान लंबाई से अधिक है, तो इसका कोई प्रभाव नहीं पड़ता है।
    ///
    /// [`drain`] विधि `truncate` का अनुकरण कर सकती है, लेकिन अतिरिक्त तत्वों को गिराए जाने के बजाय वापस कर देती है।
    ///
    ///
    /// ध्यान दें कि इस पद्धति का vector की आवंटित क्षमता पर कोई प्रभाव नहीं पड़ता है।
    ///
    /// # Examples
    ///
    /// पांच तत्वों vector को दो तत्वों में छोटा करना:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// जब `len` vector की वर्तमान लंबाई से अधिक हो तो कोई काट-छांट नहीं होती है:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// जब `len == 0` [`clear`] विधि को कॉल करने के बराबर है, तो काट-छाँट करना।
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // यह सुरक्षित है क्योंकि:
        //
        // * `drop_in_place` को दिया गया टुकड़ा मान्य है;`len > self.len` मामला अमान्य टुकड़ा बनाने से बचता है, और
        // * vector का `len` `drop_in_place` को कॉल करने से पहले सिकुड़ जाता है, जैसे कि `drop_in_place` के panic में एक बार होने पर (यदि यह panics दो बार, प्रोग्राम बंद हो जाता है, तो कोई मान दो बार नहीं गिराया जाएगा)।
        //
        //
        //
        unsafe {
            // Note: यह जानबूझकर है कि यह `>` है न कि `>=`।
            //       इसे `>=` में बदलने से कुछ मामलों में नकारात्मक प्रदर्शन प्रभाव पड़ता है।
            //       अधिक के लिए #78884 देखें।
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// संपूर्ण vector युक्त एक टुकड़ा निकालता है।
    ///
    /// `&s[..]` के बराबर।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// संपूर्ण vector का एक परिवर्तनशील टुकड़ा निकालता है।
    ///
    /// `&mut s[..]` के बराबर।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// vector के बफर में एक कच्चा सूचक देता है।
    ///
    /// कॉल करने वाले को यह सुनिश्चित करना चाहिए कि vector इस फ़ंक्शन के वापस आने वाले पॉइंटर से अधिक जीवित है, अन्यथा यह कचरे की ओर इशारा करेगा।
    /// vector को संशोधित करने से इसके बफर को फिर से आवंटित किया जा सकता है, जो इसके किसी भी संकेत को अमान्य बना देगा।
    ///
    /// कॉलर को यह भी सुनिश्चित करना चाहिए कि पॉइंटर (non-transitively) जिस मेमोरी को इंगित करता है वह इस पॉइंटर या इससे प्राप्त किसी भी पॉइंटर का उपयोग करके (`UnsafeCell` के अंदर को छोड़कर) कभी नहीं लिखा जाता है।
    /// यदि आपको स्लाइस की सामग्री को बदलने की आवश्यकता है, तो [`as_mut_ptr`] का उपयोग करें।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // हम `deref` से गुजरने से बचने के लिए उसी नाम की स्लाइस विधि को छायांकित करते हैं, जो एक मध्यवर्ती संदर्भ बनाता है।
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// vector के बफर में एक असुरक्षित परिवर्तनशील सूचक देता है।
    ///
    /// कॉल करने वाले को यह सुनिश्चित करना चाहिए कि vector इस फ़ंक्शन के वापस आने वाले पॉइंटर से अधिक जीवित है, अन्यथा यह कचरे की ओर इशारा करेगा।
    ///
    /// vector को संशोधित करने से इसके बफर को फिर से आवंटित किया जा सकता है, जो इसके किसी भी संकेत को अमान्य बना देगा।
    ///
    /// # Examples
    ///
    /// ```
    /// // vector को 4 तत्वों के लिए काफी बड़ा आवंटित करें।
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // कच्चे सूचक लिखने के माध्यम से तत्वों को प्रारंभ करें, फिर लंबाई निर्धारित करें।
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // हम `deref_mut` से गुजरने से बचने के लिए उसी नाम की स्लाइस विधि को छायांकित करते हैं, जो एक मध्यवर्ती संदर्भ बनाता है।
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// अंतर्निहित आवंटक का संदर्भ देता है।
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// vector से `new_len` की लंबाई को बल देता है।
    ///
    /// यह एक निम्न-स्तरीय ऑपरेशन है जो किसी भी प्रकार के सामान्य इनवेरिएंट को बनाए नहीं रखता है।
    /// आम तौर पर vector की लंबाई बदलना सुरक्षित संचालन में से एक का उपयोग करके किया जाता है, जैसे कि [`truncate`], [`resize`], [`extend`], या [`clear`]।
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`] से कम या उसके बराबर होना चाहिए।
    /// - `old_len..new_len` पर तत्वों को प्रारंभ किया जाना चाहिए।
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// यह विधि उन स्थितियों के लिए उपयोगी हो सकती है जिनमें vector अन्य कोड के लिए बफर के रूप में कार्य कर रहा है, विशेष रूप से FFI पर:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // दस्तावेज़ उदाहरण के लिए यह केवल एक न्यूनतम कंकाल है;
    /// # // इसे वास्तविक पुस्तकालय के लिए शुरुआती बिंदु के रूप में उपयोग न करें।
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // एफएफआई विधि के दस्तावेज़ों के अनुसार, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // सुरक्षा: जब `deflateGetDictionary` `Z_OK` लौटाता है, तो यह मानता है कि:
    ///     // 1. `dict_length` तत्वों को प्रारंभ किया गया।
    ///     // 2.
    ///     // `dict_length` <=क्षमता (32_768) जो `set_len` को कॉल करने के लिए सुरक्षित बनाती है।
    ///     unsafe {
    ///         // एफएफआई कॉल करें ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... और जो प्रारंभ किया गया था उसकी लंबाई अपडेट करें।
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// जबकि निम्न उदाहरण ध्वनि है, एक स्मृति रिसाव है क्योंकि आंतरिक vectors को `set_len` कॉल से पहले मुक्त नहीं किया गया था:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` खाली है इसलिए किसी तत्व को प्रारंभ करने की आवश्यकता नहीं है।
    /// // 2. `0 <= capacity` `capacity` जो कुछ भी है उसे हमेशा धारण करता है।
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// आम तौर पर, यहां, सामग्री को सही ढंग से छोड़ने के लिए कोई [`clear`] का उपयोग करेगा और इस प्रकार स्मृति को रिसाव नहीं करेगा।
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// vector से एक तत्व को हटाता है और उसे वापस करता है।
    ///
    /// हटाए गए तत्व को vector के अंतिम तत्व से बदल दिया जाता है।
    ///
    /// यह ऑर्डरिंग को संरक्षित नहीं करता है, लेकिन O(1) है।
    ///
    /// # Panics
    ///
    /// Panics अगर `index` सीमा से बाहर है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // हम स्वयं [सूचकांक] को अंतिम तत्व से प्रतिस्थापित करते हैं।
            // ध्यान दें कि यदि उपरोक्त सीमा जांच सफल होती है तो एक अंतिम तत्व होना चाहिए (जो स्वयं [अनुक्रमणिका] स्वयं हो सकता है)।
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// vector के भीतर `index` की स्थिति में एक तत्व सम्मिलित करता है, इसके बाद सभी तत्वों को दाईं ओर स्थानांतरित करता है।
    ///
    ///
    /// # Panics
    ///
    /// Panics अगर `index > len`।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // नए तत्व के लिए जगह
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // अचूक नया मूल्य डालने का स्थान
            //
            {
                let p = self.as_mut_ptr().add(index);
                // जगह बनाने के लिए सब कुछ शिफ्ट करें।
                // ('सूचकांक' तत्व को लगातार दो स्थानों पर डुप्लिकेट करना।)
                ptr::copy(p, p.offset(1), len - index);
                // 'इंडेक्स' तत्व की पहली प्रति को ओवरराइट करते हुए इसे लिखें।
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// vector के भीतर `index` की स्थिति में तत्व को हटाता है और लौटाता है, इसके बाद सभी तत्वों को बाईं ओर स्थानांतरित करता है।
    ///
    ///
    /// # Panics
    ///
    /// Panics अगर `index` सीमा से बाहर है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // जिस जगह से हम ले रहे हैं।
                let ptr = self.as_mut_ptr().add(index);
                // इसे कॉपी करें, असुरक्षित रूप से स्टैक पर और vector में एक ही समय में मूल्य की एक प्रति है।
                //
                ret = ptr::read(ptr);

                // उस जगह को भरने के लिए सब कुछ नीचे शिफ्ट करें।
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// केवल विधेय द्वारा निर्दिष्ट तत्वों को बरकरार रखता है।
    ///
    /// दूसरे शब्दों में, सभी तत्वों को हटा दें `e` जैसे कि `f(&e)` `false` लौटाता है।
    /// यह विधि जगह पर काम करती है, प्रत्येक तत्व को मूल क्रम में बिल्कुल एक बार देखती है, और बनाए गए तत्वों के क्रम को संरक्षित करती है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// चूंकि तत्वों को मूल क्रम में बिल्कुल एक बार देखा जाता है, बाहरी स्थिति का उपयोग यह तय करने के लिए किया जा सकता है कि कौन से तत्व रखना है।
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // यदि ड्रॉप गार्ड निष्पादित नहीं किया जाता है, तो डबल ड्रॉप से बचें, क्योंकि हम प्रक्रिया के दौरान कुछ छेद कर सकते हैं।
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      |<-संसाधित लेन->|^-चेक के आगे
        //                  |<-हटाए गए cnt->|
        //      |<-मूल_लेन->|केप्ट: विधेय करने वाले तत्व सत्य पर लौटते हैं।
        //
        // होल: स्थानांतरित या गिरा हुआ तत्व स्लॉट।
        // अनचेक: अनचेक मान्य तत्व।
        //
        // यह ड्रॉप गार्ड तब लागू किया जाएगा जब विधेय या `drop` तत्व घबरा गया हो।
        // यह अनियंत्रित तत्वों को छेद और `set_len` को सही लंबाई में कवर करने के लिए स्थानांतरित करता है।
        // ऐसे मामलों में जब विधेय और `drop` कभी घबराते नहीं हैं, इसे अनुकूलित किया जाएगा।
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // सुरक्षा: अनचेक किए गए आइटम का पिछला भाग मान्य होना चाहिए क्योंकि हम उन्हें कभी नहीं छूते हैं।
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // सुरक्षा: छेद भरने के बाद, सभी आइटम सन्निहित मेमोरी में हैं।
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // सुरक्षा: अनियंत्रित तत्व मान्य होना चाहिए।
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // अगर `drop_in_place` घबराया हुआ है तो डबल ड्रॉप से बचने के लिए जल्दी आगे बढ़ें।
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // सुरक्षा: हम इस तत्व को गिराने के बाद फिर कभी नहीं छूते हैं।
                unsafe { ptr::drop_in_place(cur) };
                // हम पहले ही काउंटर को आगे बढ़ा चुके हैं।
                continue;
            }
            if g.deleted_cnt > 0 {
                // सुरक्षा: `deleted_cnt`> 0, इसलिए होल स्लॉट वर्तमान तत्व के साथ ओवरलैप नहीं होना चाहिए।
                // हम स्थानांतरित करने के लिए प्रतिलिपि का उपयोग करते हैं, और इस तत्व को फिर कभी स्पर्श नहीं करते हैं।
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // सभी आइटम संसाधित होते हैं।इसे LLVM द्वारा `set_len` में अनुकूलित किया जा सकता है।
        drop(g);
    }

    /// vector में लगातार पहले तत्वों को हटाता है जो एक ही कुंजी को हल करते हैं।
    ///
    ///
    /// यदि vector को सॉर्ट किया जाता है, तो यह सभी डुप्लिकेट को हटा देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// किसी दिए गए समानता संबंध को संतुष्ट करने वाले vector में लगातार तत्वों में से सभी को हटा देता है।
    ///
    /// `same_bucket` फ़ंक्शन को vector से दो तत्वों के संदर्भ में पारित किया गया है और यह निर्धारित करना होगा कि क्या तत्व समान की तुलना करते हैं।
    /// तत्वों को स्लाइस में उनके क्रम से विपरीत क्रम में पारित किया जाता है, इसलिए यदि `same_bucket(a, b)` `true` लौटाता है, तो `a` हटा दिया जाता है।
    ///
    ///
    /// यदि vector को सॉर्ट किया जाता है, तो यह सभी डुप्लिकेट को हटा देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// संग्रह के पीछे एक तत्व जोड़ता है।
    ///
    /// # Panics
    ///
    /// Panics यदि नई क्षमता `isize::MAX` बाइट्स से अधिक है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // यह panic या निरस्त होगा यदि हम> isize::MAX बाइट्स आवंटित करेंगे या यदि लंबाई वृद्धि शून्य-आकार के प्रकारों के लिए अतिप्रवाह होगी।
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// vector से अंतिम तत्व को हटाता है और इसे वापस करता है, या [`None`] यदि यह खाली है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `other` के सभी तत्वों को `Self` में ले जाता है, `other` को खाली छोड़ देता है।
    ///
    /// # Panics
    ///
    /// Panics यदि vector में तत्वों की संख्या `usize` से अधिक हो जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// अन्य बफर से तत्वों को `Self` में जोड़ता है।
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// एक ड्रेनिंग इटरेटर बनाता है जो vector में निर्दिष्ट सीमा को हटा देता है और हटाए गए आइटम उत्पन्न करता है।
    ///
    /// जब इटरेटर **है** गिरा दिया जाता है, तो श्रेणी के सभी तत्व vector से हटा दिए जाते हैं, भले ही इटरेटर पूरी तरह से उपभोग न किया गया हो।
    /// यदि इटरेटर **नहीं** गिराया गया है (उदाहरण के लिए [`mem::forget`] के साथ), यह निर्दिष्ट नहीं है कि कितने तत्व हटा दिए गए हैं।
    ///
    /// # Panics
    ///
    /// Panics यदि प्रारंभिक बिंदु अंत बिंदु से बड़ा है या यदि अंत बिंदु vector की लंबाई से अधिक है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // एक पूरी श्रृंखला vector. को साफ करती है
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // मेमोरी सुरक्षा
        //
        // जब Drain पहली बार बनाया जाता है, तो यह सुनिश्चित करने के लिए स्रोत vector की लंबाई को छोटा कर देता है कि यदि Drain का विनाशक कभी नहीं चलता है तो कोई भी अप्रारंभीकृत या स्थानांतरित-तत्वों तक पहुंच योग्य नहीं है।
        //
        //
        // Drain निकालने के लिए मानों को ptr::read कर देगा।
        // समाप्त होने पर, vec की शेष पूंछ को छेद को कवर करने के लिए वापस कॉपी किया जाता है, और vector लंबाई को नई लंबाई में बहाल किया जाता है।
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // Drain लीक होने की स्थिति में सुरक्षित रहने के लिए, self.vec लंबाई शुरू करने के लिए सेट करें
            self.set_len(start);
            // संपूर्ण Drain इटरेटर (जैसे &mut T) के उधार व्यवहार को इंगित करने के लिए IterMut में उधार का उपयोग करें।
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// सभी मानों को हटाते हुए vector को साफ़ करता है।
    ///
    /// ध्यान दें कि इस पद्धति का vector की आवंटित क्षमता पर कोई प्रभाव नहीं पड़ता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// vector में तत्वों की संख्या देता है, जिसे इसका 'length' भी कहा जाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// यदि vector में कोई तत्व नहीं है तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// दिए गए इंडेक्स पर संग्रह को दो भागों में विभाजित करता है।
    ///
    /// एक नया आवंटित vector देता है जिसमें `[at, len)` श्रेणी के तत्व होते हैं।
    /// कॉल के बाद, मूल vector को `[0, at)` तत्वों से युक्त छोड़ दिया जाएगा, जिसकी पिछली क्षमता अपरिवर्तित रहेगी।
    ///
    ///
    /// # Panics
    ///
    /// Panics अगर `at > len`।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // नया vector मूल बफर ले सकता है और कॉपी से बच सकता है
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // असुरक्षित रूप से `set_len` और आइटम को `other` पर कॉपी करें।
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `Vec` को इन-प्लेस आकार देता है ताकि `len` `new_len` के बराबर हो।
    ///
    /// यदि `new_len` `len` से बड़ा है, तो `Vec` को अंतर से बढ़ाया जाता है, जिसमें प्रत्येक अतिरिक्त स्लॉट क्लोजर `f` को कॉल करने के परिणाम से भरा होता है।
    ///
    /// `f` से वापसी मान `Vec` में उसी क्रम में समाप्त हो जाएंगे जिस क्रम में वे उत्पन्न हुए हैं।
    ///
    /// यदि `new_len`, `len` से छोटा है, तो `Vec` को छोटा कर दिया जाता है।
    ///
    /// यह विधि प्रत्येक पुश पर नए मान बनाने के लिए क्लोजर का उपयोग करती है।यदि आप किसी दिए गए मान के बजाय [`Clone`] चाहते हैं, तो [`Vec::resize`] का उपयोग करें।
    /// यदि आप मान उत्पन्न करने के लिए [`Default`] trait का उपयोग करना चाहते हैं, तो आप [`Default::default`] को दूसरे तर्क के रूप में पास कर सकते हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec` का उपभोग करता है और लीक करता है, सामग्री के लिए एक परिवर्तनीय संदर्भ लौटाता है, `&'a mut [T]`.
    /// ध्यान दें कि प्रकार `T` को चुने हुए जीवनकाल `'a` से अधिक जीवित रहना चाहिए।
    /// यदि प्रकार में केवल स्थिर संदर्भ हैं, या कोई भी नहीं है, तो इसे `'static` चुना जा सकता है।
    ///
    /// यह फ़ंक्शन [`Box`] पर [`leak`][Box::leak] फ़ंक्शन के समान है, सिवाय इसके कि लीक हुई मेमोरी को पुनर्प्राप्त करने का कोई तरीका नहीं है।
    ///
    ///
    /// यह फ़ंक्शन मुख्य रूप से डेटा के लिए उपयोगी है जो प्रोग्राम के शेष जीवन के लिए रहता है।
    /// लौटाए गए संदर्भ को छोड़ने से स्मृति रिसाव हो जाएगा।
    ///
    /// # Examples
    ///
    /// सरल उपयोग:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// vector की शेष अतिरिक्त क्षमता को `MaybeUninit<T>` के एक स्लाइस के रूप में लौटाता है।
    ///
    /// लौटे हुए स्लाइस का उपयोग vector को डेटा से भरने के लिए किया जा सकता है (जैसे
    /// एक फ़ाइल से पढ़कर) [`set_len`] पद्धति का उपयोग करके डेटा को आरंभिक के रूप में चिह्नित करने से पहले।
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // vector को 10 तत्वों के लिए काफी बड़ा आवंटित करें।
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // पहले 3 तत्वों को भरें।
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // vector के पहले 3 तत्वों को आरंभिक के रूप में चिह्नित करें।
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // इस विधि को `split_at_spare_mut` के संदर्भ में लागू नहीं किया गया है, ताकि बफर को पॉइंटर्स की अमान्यता को रोका जा सके।
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// vector सामग्री को `T` के एक स्लाइस के रूप में लौटाता है, साथ ही vector की शेष अतिरिक्त क्षमता `MaybeUninit<T>` के एक स्लाइस के रूप में देता है।
    ///
    /// [`set_len`] विधि का उपयोग करके डेटा को आरंभिक के रूप में चिह्नित करने से पहले लौटाई गई अतिरिक्त क्षमता स्लाइस का उपयोग डेटा के साथ vector को भरने के लिए किया जा सकता है (उदाहरण के लिए फ़ाइल से पढ़कर)।
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// ध्यान दें कि यह एक निम्न-स्तरीय एपीआई है, जिसका उपयोग अनुकूलन उद्देश्यों के लिए सावधानी से किया जाना चाहिए।
    /// यदि आपको `Vec` में डेटा जोड़ने की आवश्यकता है, तो आप अपनी सटीक आवश्यकताओं के आधार पर [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] या [`resize_with`] का उपयोग कर सकते हैं।
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // 10 तत्वों के लिए पर्याप्त अतिरिक्त स्थान आरक्षित करें।
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // अगले 4 तत्वों को भरें।
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // vector के 4 तत्वों को प्रारंभ के रूप में चिह्नित करें।
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - लेन को नजरअंदाज किया जाता है और इसलिए कभी नहीं बदला
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// सुरक्षा: लौटाए गए .2 (&mut उपयोग) को बदलना `.set_len(_)` को कॉल करने जैसा ही माना जाता है।
    ///
    /// इस विधि का उपयोग `extend_from_within` में एक बार में सभी vec भागों तक अद्वितीय पहुंच प्राप्त करने के लिए किया जाता है।
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` `len` तत्वों के लिए मान्य होने की गारंटी है
        // - `spare_ptr` बफर के पिछले एक तत्व को इंगित कर रहा है, इसलिए यह `initialized`. के साथ ओवरलैप नहीं होता है
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `Vec` को इन-प्लेस आकार देता है ताकि `len` `new_len` के बराबर हो।
    ///
    /// यदि `new_len` `len` से बड़ा है, तो `Vec` को अंतर से बढ़ाया जाता है, प्रत्येक अतिरिक्त स्लॉट `value` से भरा होता है।
    ///
    /// यदि `new_len`, `len` से छोटा है, तो `Vec` को छोटा कर दिया जाता है।
    ///
    /// पारित मान को क्लोन करने में सक्षम होने के लिए, इस विधि को [`Clone`] को लागू करने के लिए `T` की आवश्यकता होती है।
    /// यदि आपको अधिक लचीलेपन की आवश्यकता है (या [`Clone`] के बजाय [`Default`] पर भरोसा करना चाहते हैं), तो [`Vec::resize_with`] का उपयोग करें।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// क्लोन और सभी तत्वों को एक स्लाइस में `Vec` में जोड़ता है।
    ///
    /// स्लाइस `other` पर पुनरावृति करता है, प्रत्येक तत्व को क्लोन करता है, और फिर इसे इस `Vec` में जोड़ता है।
    /// `other` vector को क्रम में ट्रैवर्स किया गया है।
    ///
    /// ध्यान दें कि यह फ़ंक्शन [`extend`] जैसा ही है, सिवाय इसके कि यह स्लाइस के साथ काम करने के लिए विशिष्ट है।
    ///
    /// यदि और जब Rust को विशेषज्ञता प्राप्त हो जाती है, तो यह फ़ंक्शन संभवतः पदावनत हो जाएगा (लेकिन अभी भी उपलब्ध है)।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src` श्रेणी के तत्वों को vector के अंत तक कॉपी करता है।
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` गारंटी देता है कि दी गई सीमा स्वयं को अनुक्रमणित करने के लिए मान्य है
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// यह कोड `extend_with_{element,default}` को सामान्यीकृत करता है।
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// दिए गए जनरेटर का उपयोग करके vector को `n` मानों से बढ़ाएँ।
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // बग के आसपास काम करने के लिए SetLenOnDrop का उपयोग करें जहां संकलक को `ptr` के माध्यम से self.set_len() के माध्यम से स्टोर का एहसास नहीं हो सकता है।
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // पिछले एक को छोड़कर सभी तत्वों को लिखें
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // next() panics. के मामले में हर चरण में लंबाई बढ़ाएँ
                local_len.increment_len(1);
            }

            if n > 0 {
                // हम अनावश्यक रूप से क्लोनिंग के बिना सीधे अंतिम तत्व लिख सकते हैं
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // स्कोप गार्ड द्वारा निर्धारित लेन
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// [`PartialEq`] trait कार्यान्वयन के अनुसार vector में लगातार दोहराए गए तत्वों को हटाता है।
    ///
    ///
    /// यदि vector को सॉर्ट किया जाता है, तो यह सभी डुप्लिकेट को हटा देता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// आंतरिक तरीके और कार्य
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` वैध सूचकांक होने की जरूरत है
    /// - `self.capacity() - self.len()` `>= src.len()`. होना चाहिए
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - तत्वों को प्रारंभ करने के बाद ही लेन को बढ़ाया जाता है
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - कॉलर गारंटी देता है कि src एक मान्य अनुक्रमणिका है
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - एलिमेंट को अभी `MaybeUninit::write` के साथ इनिशियलाइज़ किया गया था, इसलिए लेन को बढ़ाना ठीक है
            // - लीक को रोकने के लिए प्रत्येक तत्व के बाद लेन बढ़ा दी जाती है (समस्या #82533 देखें)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - कॉलर गारंटी देता है कि `src` एक मान्य अनुक्रमणिका है
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - दोनों पॉइंटर्स अद्वितीय स्लाइस संदर्भों (`&mut [_]`) से बनाए गए हैं, इसलिए वे मान्य हैं और ओवरलैप नहीं करते हैं।
            //
            // - तत्व हैं: प्रतिलिपि इसलिए मूल मूल्यों के साथ कुछ भी किए बिना, उन्हें कॉपी करना ठीक है
            // - `count` `source` के लेन के बराबर है, इसलिए स्रोत `count` पढ़ने के लिए मान्य है
            // - `.reserve(count)` गारंटी देता है कि `spare.len() >= count` इतना अतिरिक्त `count` लिखने के लिए मान्य है
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - तत्वों को अभी `copy_nonoverlapping`. द्वारा प्रारंभ किया गया था
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Vec. के लिए सामान्य trait कार्यान्वयन
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test) के साथ अंतर्निहित `[T]::to_vec` विधि, जो इस विधि परिभाषा के लिए आवश्यक है, उपलब्ध नहीं है।
    // इसके बजाय `slice::to_vec` फ़ंक्शन का उपयोग करें जो केवल cfg(test) NB के साथ उपलब्ध है, अधिक जानकारी के लिए slice.rs में slice::hack मॉड्यूल देखें।
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // कुछ भी छोड़ दें जिसे अधिलेखित नहीं किया जाएगा
        self.truncate(other.len());

        // self.len <= other.len ऊपर काटे जाने के कारण, इसलिए यहां के स्लाइस हमेशा इन-बाउंड होते हैं।
        //
        let (init, tail) = other.split_at(self.len());

        // निहित मान allocations/resources का पुन: उपयोग करें।
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// एक उपभोग करने वाला इटरेटर बनाता है, जो कि प्रत्येक मान को vector (शुरू से अंत तक) से बाहर ले जाता है।
    /// इसे कॉल करने के बाद vector का उपयोग नहीं किया जा सकता है।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s में स्ट्रिंग टाइप है, &String नहीं not
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // लीफ विधि जिसमें विभिन्न SpecFrom/SpecExtend कार्यान्वयन तब प्रतिनिधि होते हैं जब उनके पास लागू करने के लिए कोई और अनुकूलन नहीं होता है
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // एक सामान्य पुनरावर्तक के लिए यह मामला है।
        //
        // यह कार्य नैतिक समकक्ष होना चाहिए:
        //
        //      इटरेटर में आइटम के लिए {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB अतिप्रवाह नहीं हो सकता क्योंकि हमें पता स्थान आवंटित करना होगा
                self.set_len(len + 1);
            }
        }
    }

    /// एक स्प्लिसिंग इटरेटर बनाता है जो निर्दिष्ट श्रेणी को vector में दिए गए `replace_with` इटरेटर के साथ बदल देता है और हटाए गए आइटम उत्पन्न करता है।
    ///
    /// `replace_with` `range` के समान लंबाई होने की आवश्यकता नहीं है।
    ///
    /// `range` भले ही अंत तक इटरेटर का उपभोग न किया गया हो, फिर भी हटा दिया जाता है।
    ///
    /// यह निर्दिष्ट नहीं है कि `Splice` मान लीक होने पर vector से कितने तत्व हटा दिए जाते हैं।
    ///
    /// इनपुट इटरेटर `replace_with` केवल तभी खपत होता है जब `Splice` मान गिरा दिया जाता है।
    ///
    /// यह इष्टतम है यदि:
    ///
    /// * पूंछ (`range` के बाद vector में तत्व) खाली है,
    /// * या `replace_with` `श्रेणी` की लंबाई. से कम या समान तत्व देता है
    /// * या इसके `size_hint()` की निचली सीमा सटीक है।
    ///
    /// अन्यथा, एक अस्थायी vector आवंटित किया जाता है और पूंछ को दो बार स्थानांतरित किया जाता है।
    ///
    /// # Panics
    ///
    /// Panics यदि प्रारंभिक बिंदु अंत बिंदु से बड़ा है या यदि अंत बिंदु vector की लंबाई से अधिक है।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// एक पुनरावर्तक बनाता है जो यह निर्धारित करने के लिए बंद का उपयोग करता है कि किसी तत्व को हटाया जाना चाहिए या नहीं।
    ///
    /// यदि क्लोजर सही हो जाता है, तो तत्व हटा दिया जाता है और उपज दिया जाता है।
    /// यदि क्लोजर गलत लौटाता है, तो तत्व vector में रहेगा और इटरेटर द्वारा नहीं दिया जाएगा।
    ///
    /// इस पद्धति का उपयोग निम्न कोड के बराबर है:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // आपका कोड यहाँ
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// लेकिन `drain_filter` का उपयोग करना आसान है।
    /// `drain_filter` यह अधिक कुशल भी है, क्योंकि यह सरणी के तत्वों को थोक में बैकशिफ्ट कर सकता है।
    ///
    /// ध्यान दें कि `drain_filter` आपको फिल्टर क्लोजर में प्रत्येक तत्व को म्यूट करने देता है, भले ही आप इसे रखना या हटाना चुनते हैं।
    ///
    ///
    /// # Examples
    ///
    /// मूल आवंटन का पुन: उपयोग करते हुए, एक सरणी को शाम और बाधाओं में विभाजित करना:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // हमारे लीक होने से बचाव (रिसाव प्रवर्धन)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// कार्यान्वयन बढ़ाएँ जो तत्वों को Vec पर धकेलने से पहले संदर्भों से बाहर कर देता है।
///
/// यह कार्यान्वयन स्लाइस इटरेटर्स के लिए विशिष्ट है, जहां यह पूरे स्लाइस को एक साथ जोड़ने के लिए [`copy_from_slice`] का उपयोग करता है।
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// vectors की तुलना लागू करता है, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors के आदेश को लागू करता है, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // [T] के लिए ड्रॉप का उपयोग करें vector के तत्वों को सबसे कमजोर आवश्यक प्रकार के रूप में संदर्भित करने के लिए कच्चे स्लाइस का उपयोग करें;
            //
            // कुछ मामलों में वैधता के सवालों से बच सकते हैं
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec डीललोकेशन को संभालता है
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// एक खाली `Vec<T>` बनाता है।
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: परीक्षण libstd में खींचता है, जो यहां त्रुटियों का कारण बनता है
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: परीक्षण libstd में खींचता है, जो यहां त्रुटियों का कारण बनता है
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// `Vec<T>` की संपूर्ण सामग्री को एक सरणी के रूप में प्राप्त करता है, यदि इसका आकार अनुरोधित सरणी से बिल्कुल मेल खाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// यदि लंबाई मेल नहीं खाती है, तो इनपुट `Err` में वापस आता है:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// यदि आप केवल `Vec<T>` का उपसर्ग प्राप्त करने के साथ ठीक हैं, तो आप पहले [`.truncate(N)`](Vec::truncate) को कॉल कर सकते हैं।
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // सुरक्षा: `.set_len(0)` हमेशा स्वस्थ रहता है।
        unsafe { vec.set_len(0) };

        // सुरक्षा: एक `Vec` का सूचक हमेशा ठीक से संरेखित होता है, और
        // सरणी को जिस संरेखण की आवश्यकता है वह आइटम के समान है।
        // हमने पहले जाँच की थी कि हमारे पास पर्याप्त वस्तुएँ हैं।
        // आइटम डबल-ड्रॉप नहीं होंगे क्योंकि `set_len` `Vec` को उन्हें भी नहीं छोड़ने के लिए कहता है।
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}