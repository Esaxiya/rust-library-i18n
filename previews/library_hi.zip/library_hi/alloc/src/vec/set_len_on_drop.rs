// vec की लंबाई सेट करें जब `SetLenOnDrop` मान दायरे से बाहर हो जाए।
//
// विचार यह है: SetLenOnDrop में लंबाई फ़ील्ड एक स्थानीय चर है जिसे ऑप्टिमाइज़र देखेगा कि वीईसी के डेटा पॉइंटर के माध्यम से किसी भी स्टोर के साथ उपनाम नहीं है।
// यह उपनाम विश्लेषण समस्या #32155 के लिए एक वैकल्पिक हल है
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}