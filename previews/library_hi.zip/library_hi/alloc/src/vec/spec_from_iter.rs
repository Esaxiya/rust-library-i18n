use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// विशेषज्ञता trait Vec::from_iter. के लिए प्रयोग किया जाता है
///
/// ## प्रतिनिधिमंडल ग्राफ:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // एक सामान्य मामला vector को एक फ़ंक्शन में पास कर रहा है जो तुरंत vector में फिर से एकत्रित हो जाता है।
        // हम इसे शॉर्ट सर्किट कर सकते हैं यदि IntoIter को बिल्कुल भी उन्नत नहीं किया गया है।
        // जब इसे उन्नत किया गया है तो हम स्मृति का पुन: उपयोग भी कर सकते हैं और डेटा को सामने ले जा सकते हैं।
        // लेकिन हम ऐसा केवल तभी करते हैं जब परिणामी Vec में जेनेरिक FromIterator कार्यान्वयन के माध्यम से इसे बनाने की तुलना में अधिक अप्रयुक्त क्षमता नहीं होगी।
        //
        // वह सीमा सख्ती से जरूरी नहीं है क्योंकि वीईसी का आवंटन व्यवहार जानबूझकर अनिर्दिष्ट है।
        // लेकिन यह एक रूढ़िवादी विकल्प है।
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // spec_extend() को प्रतिनिधि होना चाहिए क्योंकि extend() स्वयं खाली Vecs के लिए spec_from को प्रतिनिधि करता है
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// यह `iterator.as_slice().to_vec()` का उपयोग करता है क्योंकि spec_extend को अंतिम क्षमता + लंबाई के बारे में तर्क करने के लिए और कदम उठाने चाहिए और इस प्रकार अधिक काम करना चाहिए।
// `to_vec()` सीधे सही राशि आवंटित करता है और इसे ठीक से भरता है।
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) के साथ अंतर्निहित `[T]::to_vec` विधि, जो इस विधि परिभाषा के लिए आवश्यक है, उपलब्ध नहीं है।
    // इसके बजाय `slice::to_vec` फ़ंक्शन का उपयोग करें जो केवल cfg(test) NB के साथ उपलब्ध है, अधिक जानकारी के लिए slice.rs में slice::hack मॉड्यूल देखें।
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}