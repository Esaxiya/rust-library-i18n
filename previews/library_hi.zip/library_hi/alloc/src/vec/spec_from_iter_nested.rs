use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// अतिव्यापी विशेषज्ञताओं को मैन्युअल रूप से प्राथमिकता देने के लिए आवश्यक Vec::from_iter के लिए एक और विशेषज्ञता trait विवरण के लिए [`SpecFromIter`](super::SpecFromIter) देखें।
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // पहले पुनरावृत्ति को अनियंत्रित करें, क्योंकि vector इस पुनरावृत्ति पर हर मामले में विस्तारित होने जा रहा है जब पुनरावर्तनीय खाली नहीं है, लेकिन extend_desugared() में लूप vector को कुछ बाद के लूप पुनरावृत्तियों में पूर्ण होने के लिए नहीं देख रहा है।
        //
        // तो हमें बेहतर branch भविष्यवाणी मिलती है।
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // spec_extend() को प्रतिनिधि होना चाहिए क्योंकि extend() स्वयं खाली Vecs के लिए spec_from को प्रतिनिधि करता है
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // spec_extend() को प्रतिनिधि होना चाहिए क्योंकि extend() स्वयं खाली Vecs के लिए spec_from को प्रतिनिधि करता है
        //
        vector.spec_extend(iterator);
        vector
    }
}