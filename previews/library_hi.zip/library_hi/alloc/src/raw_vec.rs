#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// नई मेमोरी की सामग्री को प्रारंभ नहीं किया गया है।
    Uninitialized,
    /// नई मेमोरी के शून्य होने की गारंटी है।
    Zeroed,
}

/// अधिक एर्गोनोमिक रूप से आवंटित करने, पुन: आवंटित करने और ढेर पर मेमोरी के बफर को हटाने के लिए एक निम्न-स्तरीय उपयोगिता, इसमें शामिल सभी कोने के मामलों के बारे में चिंता किए बिना।
///
/// यह प्रकार Vec और VecDeque जैसी आपकी अपनी डेटा संरचनाएँ बनाने के लिए उत्कृष्ट है।
/// विशेष रूप से:
///
/// * शून्य-आकार के प्रकारों पर `Unique::dangling()` का उत्पादन करता है।
/// * शून्य-लंबाई आवंटन पर `Unique::dangling()` का उत्पादन करता है।
/// * `Unique::dangling()` को मुक्त करने से बचता है।
/// * क्षमता गणना में सभी अतिप्रवाह को पकड़ता है (उन्हें "capacity overflow" panics में बढ़ावा देता है)।
/// * isize::MAX से अधिक बाइट्स आवंटित करने वाले 32-बिट सिस्टम के विरुद्ध गार्ड।
/// * आपकी लंबाई के अतिप्रवाह के खिलाफ गार्ड।
/// * गलत आवंटन के लिए `handle_alloc_error` को कॉल करता है।
/// * एक `ptr::Unique` शामिल है और इस प्रकार उपयोगकर्ता को सभी संबंधित लाभ प्रदान करता है।
/// * सबसे बड़ी उपलब्ध क्षमता का उपयोग करने के लिए आवंटक से लौटाए गए अतिरिक्त का उपयोग करता है।
///
/// यह प्रकार वैसे भी उस स्मृति का निरीक्षण नहीं करता है जिसे वह प्रबंधित करता है।जब इसे गिराया जाता है तो यह इसकी स्मृति को *मुक्त* कर देता है, लेकिन यह इसकी सामग्री को गिराने का प्रयास नहीं करता है।
/// यह `RawVec` के उपयोगकर्ता पर निर्भर है कि वह `RawVec` के अंदर *संग्रहीत* वास्तविक चीजों को संभाले।
///
/// ध्यान दें कि शून्य-आकार के प्रकारों की अधिकता हमेशा अनंत होती है, इसलिए `capacity()` हमेशा `usize::MAX` लौटाता है।
/// इसका मतलब है कि इस प्रकार को `Box<[T]>` के साथ राउंड-ट्रिपिंग करते समय आपको सावधान रहने की आवश्यकता है, क्योंकि `capacity()` लंबाई नहीं देगा।
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): यह मौजूद है क्योंकि `#[unstable]` `const fn` को `min_const_fn` के अनुरूप नहीं होना चाहिए और इसलिए उन्हें `min_const_fn` में भी नहीं कहा जा सकता है।
    ///
    /// यदि आप `RawVec<T>::new` या निर्भरता को बदलते हैं, तो कृपया ध्यान रखें कि ऐसा कुछ भी पेश न करें जो वास्तव में `min_const_fn` का उल्लंघन करे।
    ///
    /// NOTE: हम इस हैक से बच सकते हैं और कुछ `#[rustc_force_min_const_fn]` विशेषता के साथ अनुरूपता की जांच कर सकते हैं जिसके लिए `min_const_fn` के साथ अनुरूपता की आवश्यकता होती है, लेकिन जरूरी नहीं कि इसे `stable(...) const fn`/उपयोगकर्ता कोड में कॉल करने की अनुमति दें, `#[rustc_const_unstable(feature = "foo", issue = "01234")]` मौजूद होने पर `foo` को सक्षम न करें।
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// आवंटित किए बिना सबसे बड़ा संभव `RawVec` (सिस्टम हीप पर) बनाता है।
    /// यदि `T` का आकार धनात्मक है, तो यह `0` क्षमता वाला `RawVec` बनाता है।
    /// यदि `T` शून्य आकार का है, तो यह `usize::MAX` क्षमता वाला `RawVec` बनाता है।
    /// विलंबित आवंटन को लागू करने के लिए उपयोगी।
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]` के लिए बिल्कुल क्षमता और संरेखण आवश्यकताओं के साथ एक `RawVec` (सिस्टम हीप पर) बनाता है।
    /// यह `RawVec::new` को कॉल करने के बराबर है जब `capacity` `0` है या `T` शून्य-आकार का है।
    /// ध्यान दें कि यदि `T` शून्य-आकार का है, तो इसका मतलब है कि आपको अनुरोधित क्षमता वाला `RawVec`*नहीं* मिलेगा।
    ///
    /// # Panics
    ///
    /// Panics यदि अनुरोधित क्षमता `isize::MAX` बाइट्स से अधिक है।
    ///
    /// # Aborts
    ///
    /// ओओएम पर गर्भपात।
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` की तरह, लेकिन गारंटी देता है कि बफर शून्य है।
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// एक सूचक और क्षमता से `RawVec` का पुनर्गठन करता है।
    ///
    /// # Safety
    ///
    /// `ptr` को आवंटित किया जाना चाहिए (सिस्टम हीप पर), और दिए गए `capacity` के साथ।
    /// `capacity` आकार के प्रकारों के लिए `isize::MAX` से अधिक नहीं हो सकता।(केवल 32-बिट सिस्टम पर चिंता)।
    /// ZST vectors की क्षमता `usize::MAX` तक हो सकती है।
    /// यदि `ptr` और `capacity` `RawVec` से आते हैं, तो इसकी गारंटी है।
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // छोटे Vecs गूंगा हैं।छलांग लगाओ:
    // - 8 यदि तत्व का आकार 1 है, क्योंकि कोई भी ढेर आवंटक 8 बाइट्स से कम के अनुरोध को कम से कम 8 बाइट्स तक पूरा करने की संभावना है।
    //
    // - 4 यदि तत्व मध्यम आकार के हैं (<=1 KiB)।
    // - 1 अन्यथा, बहुत कम Vecs के लिए बहुत अधिक स्थान बर्बाद करने से बचने के लिए।
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` की तरह, लेकिन लौटाए गए `RawVec` के लिए आवंटक की पसंद पर पैरामीटरयुक्त।
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` मतलब "unallocated"।शून्य-आकार के प्रकारों को अनदेखा किया जाता है।
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` की तरह, लेकिन लौटाए गए `RawVec` के लिए आवंटक की पसंद पर पैरामीटरयुक्त।
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` की तरह, लेकिन लौटाए गए `RawVec` के लिए आवंटक की पसंद पर पैरामीटरयुक्त।
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` को `RawVec<T>` में कनवर्ट करता है।
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// निर्दिष्ट `len` के साथ संपूर्ण बफ़र को `Box<[MaybeUninit<T>]>` में कनवर्ट करता है।
    ///
    /// ध्यान दें कि यह किसी भी `cap` परिवर्तनों को सही ढंग से पुनर्गठित करेगा जो कि निष्पादित हो सकते हैं।(विवरण के लिए प्रकार का विवरण देखें।)
    ///
    /// # Safety
    ///
    /// * `len` सबसे हाल ही में अनुरोधित क्षमता से अधिक या उसके बराबर होना चाहिए, और
    /// * `len` `self.capacity()` से कम या उसके बराबर होना चाहिए।
    ///
    /// ध्यान दें, अनुरोधित क्षमता और `self.capacity()` भिन्न हो सकते हैं, क्योंकि एक आवंटक अनुरोध से अधिक मेमोरी ब्लॉक को समग्र रूप से आवंटित और वापस कर सकता है।
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // सुरक्षा आवश्यकता के आधे हिस्से की जांच करें (हम दूसरे आधे हिस्से की जांच नहीं कर सकते हैं)।
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // हम यहां `unwrap_or_else` से बचते हैं क्योंकि यह उत्पन्न LLVM IR की मात्रा को बढ़ा देता है।
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// एक सूचक, क्षमता और आवंटक से `RawVec` का पुनर्गठन करता है।
    ///
    /// # Safety
    ///
    /// `ptr` को आवंटित किया जाना चाहिए (दिए गए आवंटक `alloc` के माध्यम से), और दिए गए `capacity` के साथ।
    /// `capacity` आकार के प्रकारों के लिए `isize::MAX` से अधिक नहीं हो सकता।
    /// (केवल 32-बिट सिस्टम पर चिंता)।
    /// ZST vectors की क्षमता `usize::MAX` तक हो सकती है।
    /// यदि `ptr` और `capacity` `alloc` के माध्यम से बनाए गए `RawVec` से आते हैं, तो इसकी गारंटी है।
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// आवंटन की शुरुआत के लिए एक कच्चा सूचक प्राप्त करें।
    /// ध्यान दें कि यदि `capacity == 0` या `T` शून्य-आकार का है तो यह `Unique::dangling()` है।
    /// पूर्व मामले में, आपको सावधान रहना चाहिए।
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// आवंटन की क्षमता प्राप्त करता है।
    ///
    /// यदि `T` शून्य-आकार का है तो यह हमेशा `usize::MAX` होगा।
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// इस `RawVec` का समर्थन करने वाले आवंटक के लिए एक साझा संदर्भ देता है।
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // हमारे पास मेमोरी का एक आवंटित हिस्सा है, इसलिए हम अपना वर्तमान लेआउट प्राप्त करने के लिए रनटाइम चेक को बायपास कर सकते हैं।
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// सुनिश्चित करता है कि बफर में `len + additional` तत्वों को रखने के लिए कम से कम पर्याप्त स्थान है।
    /// यदि इसमें पहले से ही पर्याप्त क्षमता नहीं है, तो यह पर्याप्त स्थान और आरामदेह सुस्त स्थान को फिर से आवंटित करेगा ताकि परिशोधन *O*(1) व्यवहार प्राप्त किया जा सके।
    ///
    /// इस व्यवहार को सीमित कर देगा यदि यह अनावश्यक रूप से खुद को panic का कारण बनता है।
    ///
    /// यदि `len` `self.capacity()` से अधिक है, तो यह वास्तव में अनुरोधित स्थान आवंटित करने में विफल हो सकता है।
    /// यह वास्तव में असुरक्षित नहीं है, लेकिन असुरक्षित कोड *आप* जो इस फ़ंक्शन के व्यवहार पर निर्भर करता है, टूट सकता है।
    ///
    /// यह `extend` जैसे बल्क-पुश ऑपरेशन को लागू करने के लिए आदर्श है।
    ///
    /// # Panics
    ///
    /// Panics यदि नई क्षमता `isize::MAX` बाइट्स से अधिक है।
    ///
    /// # Aborts
    ///
    /// ओओएम पर गर्भपात।
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // यदि लेन `isize::MAX` से अधिक हो जाती है तो रिजर्व निरस्त या घबरा जाता है, इसलिए अब अनियंत्रित करना सुरक्षित है।
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` के समान, लेकिन घबराने या गर्भपात करने के बजाय त्रुटियों पर वापस आ जाता है।
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// सुनिश्चित करता है कि बफर में `len + additional` तत्वों को रखने के लिए कम से कम पर्याप्त स्थान है।
    /// यदि यह पहले से नहीं है, तो आवश्यक न्यूनतम संभव मात्रा में स्मृति को पुन: आवंटित करेगा।
    /// आम तौर पर यह बिल्कुल आवश्यक स्मृति की मात्रा होगी, लेकिन सिद्धांत रूप में आवंटक हमारे द्वारा मांगे जाने से अधिक वापस देने के लिए स्वतंत्र है।
    ///
    ///
    /// यदि `len` `self.capacity()` से अधिक है, तो यह वास्तव में अनुरोधित स्थान आवंटित करने में विफल हो सकता है।
    /// यह वास्तव में असुरक्षित नहीं है, लेकिन असुरक्षित कोड *आप* जो इस फ़ंक्शन के व्यवहार पर निर्भर करता है, टूट सकता है।
    ///
    /// # Panics
    ///
    /// Panics यदि नई क्षमता `isize::MAX` बाइट्स से अधिक है।
    ///
    /// # Aborts
    ///
    /// ओओएम पर गर्भपात।
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` के समान, लेकिन घबराने या गर्भपात करने के बजाय त्रुटियों पर वापस आ जाता है।
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// आवंटन को निर्दिष्ट राशि तक कम कर देता है।
    /// यदि दी गई राशि 0 है, तो वास्तव में पूरी तरह से हटा दिया जाता है।
    ///
    /// # Panics
    ///
    /// Panics यदि दी गई राशि वर्तमान क्षमता से *बड़ी* है।
    ///
    /// # Aborts
    ///
    /// ओओएम पर गर्भपात।
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// यदि आवश्यक अतिरिक्त क्षमता को पूरा करने के लिए बफ़र को बढ़ने की आवश्यकता है तो वापस आ जाता है
    /// मुख्य रूप से `grow` को इनलाइन किए बिना इनलाइनिंग रिजर्व-कॉल को संभव बनाने के लिए उपयोग किया जाता है।
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // यह विधि आमतौर पर कई बार त्वरित होती है।इसलिए हम चाहते हैं कि संकलन समय में सुधार करने के लिए यह जितना संभव हो उतना छोटा हो।
    // लेकिन हम यह भी चाहते हैं कि उत्पन्न कोड को तेजी से चलाने के लिए इसकी अधिक से अधिक सामग्री सांख्यिकीय रूप से गणना योग्य हो।
    // इसलिए, इस पद्धति को सावधानी से लिखा गया है ताकि `T` पर निर्भर सभी कोड इसके भीतर हों, जबकि जितना संभव हो उतना कोड जो `T` पर निर्भर नहीं है, वह उन कार्यों में है जो `T` पर गैर-जेनेरिक हैं।
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // यह कॉलिंग संदर्भों द्वारा सुनिश्चित किया जाता है।
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // चूंकि `elem_size` होने पर हम `usize::MAX` की क्षमता लौटाते हैं
            // 0, यहां पहुंचने का मतलब है कि `RawVec` ओवरफुल है।
            return Err(CapacityOverflow);
        }

        // दुख की बात है कि हम इन जाँचों के बारे में वास्तव में कुछ नहीं कर सकते।
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // यह घातीय वृद्धि की गारंटी देता है।
        // दोहरीकरण अतिप्रवाह नहीं हो सकता क्योंकि `cap <= isize::MAX` और `cap` का प्रकार `usize` है।
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` पर गैर-सामान्य है।
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // इस पद्धति की बाधाएं `grow_amortized` के समान ही हैं, लेकिन यह विधि आमतौर पर कम बार त्वरित होती है इसलिए यह कम महत्वपूर्ण है।
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // चूंकि हम प्रकार आकार के होने पर `usize::MAX` की क्षमता लौटाते हैं
            // 0, यहां पहुंचने का मतलब है कि `RawVec` ओवरफुल है।
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` पर गैर-सामान्य है।
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// संकलन समय को कम करने के लिए यह फ़ंक्शन `RawVec` के बाहर है।विवरण के लिए `RawVec::grow_amortized` के ऊपर टिप्पणी देखें।
// (`A` पैरामीटर महत्वपूर्ण नहीं है, क्योंकि व्यवहार में देखे जाने वाले विभिन्न `A` प्रकारों की संख्या `T` प्रकारों की संख्या से बहुत कम है।)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` के आकार को कम करने के लिए यहां त्रुटि की जांच करें।
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // संरेखण समानता के लिए आवंटनकर्ता जाँच करता है
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec` के स्वामित्व वाली मेमोरी को *उसकी सामग्री को छोड़ने की कोशिश किए बिना* मुक्त करता है।
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// रिजर्व त्रुटि प्रबंधन के लिए केंद्रीय कार्य।
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// हमें निम्नलिखित की गारंटी देने की आवश्यकता है:
// * हम कभी भी `> isize::MAX` बाइट-साइज़ ऑब्जेक्ट आवंटित नहीं करते हैं।
// * हम `usize::MAX` को ओवरफ्लो नहीं करते हैं और वास्तव में बहुत कम आवंटित करते हैं।
//
// 64-बिट पर हमें केवल अतिप्रवाह की जांच करने की आवश्यकता है क्योंकि `> isize::MAX` बाइट्स आवंटित करने का प्रयास निश्चित रूप से विफल हो जाएगा।
// 32-बिट और 16-बिट पर हमें इसके लिए एक अतिरिक्त गार्ड जोड़ने की आवश्यकता है यदि हम एक ऐसे प्लेटफॉर्म पर चल रहे हैं जो उपयोगकर्ता-स्थान में सभी 4GB का उपयोग कर सकता है, जैसे, PAE या x32।
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// क्षमता अतिप्रवाह रिपोर्टिंग के लिए जिम्मेदार एक केंद्रीय कार्य।
// यह सुनिश्चित करेगा कि इन panics से संबंधित कोड जनरेशन न्यूनतम है क्योंकि पूरे मॉड्यूल में एक गुच्छा के बजाय केवल एक स्थान है जो panics है।
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}