#![stable(feature = "rust1", since = "1.0.0")]

//! थ्रेड-सुरक्षित संदर्भ-गिनती पॉइंटर्स।
//!
//! अधिक विवरण के लिए [`Arc<T>`][Arc] दस्तावेज़ीकरण देखें।

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc` में किए जा सकने वाले संदर्भों की मात्रा पर एक नरम सीमा।
///
/// इस सीमा से ऊपर जाने से आपका प्रोग्राम _exactly_ `MAX_REFCOUNT + 1` संदर्भों पर (हालांकि जरूरी नहीं) निरस्त हो जाएगा।
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// थ्रेडसैनिटाइज़र मेमोरी फ़ेंस का समर्थन नहीं करता है।
// आर्क/कमजोर कार्यान्वयन में झूठी सकारात्मक रिपोर्ट से बचने के लिए इसके बजाय सिंक्रनाइज़ेशन के लिए परमाणु भार का उपयोग करें।
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// एक थ्रेड-सुरक्षित संदर्भ-गिनती सूचक।'Arc' का अर्थ है 'परमाणु संदर्भ गणना'।
///
/// प्रकार `Arc<T>` ढेर में आवंटित प्रकार `T` के मान का साझा स्वामित्व प्रदान करता है।`Arc` पर [`clone`][clone] को आमंत्रित करने से एक नया `Arc` इंस्टेंस उत्पन्न होता है, जो संदर्भ संख्या को बढ़ाते हुए स्रोत `Arc` के समान ही आवंटन को इंगित करता है।
/// जब किसी दिए गए आवंटन का अंतिम `Arc` सूचक नष्ट हो जाता है, तो उस आवंटन में संग्रहीत मूल्य (जिसे अक्सर "inner value" कहा जाता है) भी गिरा दिया जाता है।
///
/// Rust में साझा संदर्भ डिफ़ॉल्ट रूप से उत्परिवर्तन को अस्वीकार करते हैं, और `Arc` कोई अपवाद नहीं है: आप आमतौर पर `Arc` के अंदर किसी चीज़ के लिए एक परिवर्तनशील संदर्भ प्राप्त नहीं कर सकते।यदि आपको `Arc` के माध्यम से उत्परिवर्तित करने की आवश्यकता है, तो [`Mutex`][mutex], [`RwLock`][rwlock], या [`Atomic`][atomic] प्रकारों में से एक का उपयोग करें।
///
/// ## धागा सुरक्षा
///
/// [`Rc<T>`] के विपरीत, `Arc<T>` अपने संदर्भ गणना के लिए परमाणु संचालन का उपयोग करता है।इसका मतलब है कि यह थ्रेड-सुरक्षित है।नुकसान यह है कि परमाणु संचालन सामान्य मेमोरी एक्सेस की तुलना में अधिक महंगे हैं।यदि आप थ्रेड के बीच संदर्भ-गणना आवंटन साझा नहीं कर रहे हैं, तो कम ओवरहेड के लिए [`Rc<T>`] का उपयोग करने पर विचार करें।
/// [`Rc<T>`] एक सुरक्षित डिफ़ॉल्ट है, क्योंकि संकलक धागे के बीच [`Rc<T>`] भेजने के किसी भी प्रयास को पकड़ लेगा।
/// हालाँकि, पुस्तकालय उपभोक्ताओं को अधिक लचीलापन देने के लिए एक पुस्तकालय `Arc<T>` चुन सकता है।
///
/// `Arc<T>` [`Send`] और [`Sync`] को तब तक लागू करेगा जब तक `T` [`Send`] और [`Sync`] को लागू करता है।
/// आप इसे थ्रेड-सुरक्षित बनाने के लिए `Arc<T>` में एक गैर-थ्रेड-सुरक्षित प्रकार `T` क्यों नहीं डाल सकते हैं?यह पहली बार में थोड़ा प्रति-सहज हो सकता है: आखिरकार, `Arc<T>` थ्रेड सुरक्षा की बात नहीं है?कुंजी यह है: `Arc<T>` एक ही डेटा के एकाधिक स्वामित्व के लिए इसे थ्रेड सुरक्षित बनाता है, लेकिन यह अपने डेटा में थ्रेड सुरक्षा नहीं जोड़ता है।
///
/// `आर्क<`[`RefCell. पर विचार करें<T>`]`>`।
/// [`RefCell<T>`] [`Sync`] नहीं है, और यदि `Arc<T>` हमेशा [`Send`] था, तो `आर्क<`[`RefCell<T>`]`>` भी होगा।
/// लेकिन तब हमें एक समस्या होगी:
/// [`RefCell<T>`] धागा सुरक्षित नहीं है;यह गैर-परमाणु संचालन का उपयोग करके उधार लेने की संख्या का ट्रैक रखता है।
///
/// अंत में, इसका मतलब है कि आपको `Arc<T>` को किसी प्रकार के [`std::sync`] प्रकार, आमतौर पर [`Mutex<T>`][mutex] के साथ जोड़ना पड़ सकता है।
///
/// ## `Weak`. के साथ ब्रेकिंग साइकिल
///
/// [`downgrade`][downgrade] विधि का उपयोग गैर-मालिक [`Weak`] पॉइंटर बनाने के लिए किया जा सकता है।एक [`Weak`] पॉइंटर [`अपग्रेड`][अपग्रेड] d एक `Arc` हो सकता है, लेकिन यह [`None`] लौटाएगा यदि आवंटन में संग्रहीत मान पहले ही गिरा दिया गया है।
/// दूसरे शब्दों में, `Weak` पॉइंटर्स आवंटन के अंदर मूल्य को जीवित नहीं रखते हैं;हालांकि, वे *करते हैं* आवंटन (मूल्य के लिए बैकिंग स्टोर) को जीवित रखते हैं।
///
/// `Arc` पॉइंटर्स के बीच एक चक्र को कभी भी डील नहीं किया जाएगा।
/// इस कारण से, [`Weak`] का उपयोग साइकिल को तोड़ने के लिए किया जाता है।उदाहरण के लिए, एक पेड़ में माता-पिता नोड्स से बच्चों के लिए मजबूत `Arc` पॉइंटर्स हो सकते हैं, और बच्चों से [`Weak`] पॉइंटर्स वापस उनके माता-पिता के पास हो सकते हैं।
///
/// # क्लोनिंग संदर्भ
///
/// मौजूदा संदर्भ-गिनती सूचक से एक नया संदर्भ बनाना [`Arc<T>`][Arc] और [`Weak<T>`][Weak] के लिए कार्यान्वित `Clone` trait का उपयोग करके किया जाता है।
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // नीचे दिए गए दो सिंटैक्स समकक्ष हैं।
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // ए, बी, और फू सभी आर्क हैं जो एक ही मेमोरी लोकेशन की ओर इशारा करते हैं
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` `T` ([`Deref`][deref] trait के माध्यम से) के लिए स्वचालित रूप से dereferences, ताकि आप `Arc<T>` प्रकार के मान पर `T` के तरीकों को कॉल कर सकें।'T' के तरीकों के साथ नाम के टकराव से बचने के लिए, `Arc<T>` की विधियाँ ही संबद्ध कार्य हैं, जिन्हें [fully qualified syntax] का उपयोग करके कहा जाता है:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `आर्क<T>`Clone` की तरह traits के कार्यान्वयन को भी पूरी तरह से योग्य सिंटैक्स का उपयोग करके बुलाया जा सकता है।
/// कुछ लोग पूरी तरह से योग्य सिंटैक्स का उपयोग करना पसंद करते हैं, जबकि अन्य मेथड-कॉल सिंटैक्स का उपयोग करना पसंद करते हैं।
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // विधि-कॉल सिंटैक्सcall
/// let arc2 = arc.clone();
/// // पूरी तरह से योग्य वाक्यविन्यास
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T` को ऑटो-डीरेफरेंस नहीं करता है, क्योंकि हो सकता है कि आंतरिक मान पहले ही गिरा दिया गया हो।
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// थ्रेड्स के बीच कुछ अपरिवर्तनीय डेटा साझा करना:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// ध्यान दें कि हम यहां ये परीक्षण **नहीं** चलाते हैं।
// windows बिल्डर्स सुपर नाखुश हो जाते हैं यदि कोई थ्रेड मुख्य थ्रेड से बाहर निकलता है और फिर उसी समय (कुछ गतिरोध) से बाहर निकलता है, तो हम इन परीक्षणों को न चलाकर पूरी तरह से इससे बचते हैं।
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// एक परिवर्तनीय [`AtomicUsize`] साझा करना:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// सामान्य रूप से संदर्भ गणना के अधिक उदाहरणों के लिए [`rc` documentation][rc_examples] देखें।
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` [`Arc`] का एक संस्करण है जो प्रबंधित आवंटन के लिए एक गैर-स्वामित्व वाला संदर्भ रखता है।
/// आवंटन को `Weak` पॉइंटर पर [`upgrade`] को कॉल करके एक्सेस किया जाता है, जो एक [`Option`]`<`[`Arc`]`देता है।<T>>`।
///
/// चूंकि `Weak` संदर्भ स्वामित्व की ओर नहीं गिना जाता है, यह आवंटन में संग्रहीत मूल्य को गिराए जाने से नहीं रोकेगा, और `Weak` स्वयं अभी भी मौजूद मूल्य के बारे में कोई गारंटी नहीं देता है।
///
/// इस प्रकार यह [`None`] वापस आ सकता है जब [`अपग्रेड`] डी।
/// ध्यान दें कि एक `Weak` संदर्भ *करता है* आवंटन को स्वयं (बैकिंग स्टोर) को हटाए जाने से रोकता है।
///
/// एक `Weak` पॉइंटर [`Arc`] द्वारा प्रबंधित आवंटन के लिए एक अस्थायी संदर्भ रखने के लिए उपयोगी है, इसके आंतरिक मूल्य को गिराए बिना रोके।
/// इसका उपयोग [`Arc`] पॉइंटर्स के बीच परिपत्र संदर्भों को रोकने के लिए भी किया जाता है, क्योंकि पारस्परिक स्वामित्व वाले संदर्भ कभी भी [`Arc`] को छोड़ने की अनुमति नहीं देंगे।
/// उदाहरण के लिए, एक पेड़ में माता-पिता नोड्स से बच्चों के लिए मजबूत [`Arc`] पॉइंटर्स हो सकते हैं, और बच्चों से `Weak` पॉइंटर्स वापस उनके माता-पिता के पास हो सकते हैं।
///
/// `Weak` पॉइंटर प्राप्त करने का सामान्य तरीका [`Arc::downgrade`] को कॉल करना है।
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // यह एक `NonNull` है जो इस प्रकार के आकार को एनम में अनुकूलित करने की अनुमति देता है, लेकिन यह आवश्यक रूप से एक वैध सूचक नहीं है।
    //
    // `Weak::new` इसे `usize::MAX` पर सेट करता है ताकि इसे ढेर पर स्थान आवंटित करने की आवश्यकता न हो।
    // यह एक मूल्य नहीं है जो एक वास्तविक सूचक के पास होगा क्योंकि आरसीबॉक्स में कम से कम 2 संरेखण है।
    // यह तभी संभव है जब `T: Sized`;अनसाइज़्ड `T` कभी नहीं लटकता।
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// यह संभावित फ़ील्ड-रीऑर्डरिंग के विरुद्ध repr(C) से future-प्रूफ है, जो ट्रांसम्यूटेबल आंतरिक प्रकारों के अन्यथा सुरक्षित [into|from]_raw() में हस्तक्षेप करेगा।
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // मान usize::MAX अस्थायी रूप से "locking" के लिए एक प्रहरी के रूप में कार्य करता है जो कमजोर पॉइंटर्स को अपग्रेड करने या मजबूत पॉइंटर्स को डाउनग्रेड करने की क्षमता रखता है;इसका उपयोग `make_mut` और `get_mut` में दौड़ से बचने के लिए किया जाता है।
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// एक नया `Arc<T>` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // कमजोर पॉइंटर गिनती को 1 के रूप में प्रारंभ करें जो कि कमजोर पॉइंटर है जो सभी मजबूत पॉइंटर्स (kinda) द्वारा आयोजित किया जाता है, अधिक जानकारी के लिए std/rc.rs देखें
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// अपने आप में एक कमजोर संदर्भ का उपयोग करके एक नया `Arc<T>` बनाता है।
    /// इस फ़ंक्शन के वापस आने से पहले कमजोर संदर्भ को अपग्रेड करने का प्रयास करने से `None` मान आएगा।
    /// हालांकि, कमजोर संदर्भ को स्वतंत्र रूप से क्लोन किया जा सकता है और बाद में उपयोग के लिए संग्रहीत किया जा सकता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // एक कमजोर संदर्भ के साथ "uninitialized" स्थिति में आंतरिक निर्माण करें।
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // यह महत्वपूर्ण है कि हम कमजोर पॉइंटर का स्वामित्व न छोड़ें, अन्यथा `data_fn` के वापस आने तक मेमोरी मुक्त हो सकती है।
        // यदि हम वास्तव में स्वामित्व पारित करना चाहते हैं, तो हम अपने लिए एक अतिरिक्त कमजोर सूचक बना सकते हैं, लेकिन इसके परिणामस्वरूप कमजोर संदर्भ संख्या के अतिरिक्त अपडेट होंगे जो अन्यथा आवश्यक नहीं हो सकते हैं।
        //
        //
        //
        //
        let data = data_fn(&weak);

        // अब हम आंतरिक मूल्य को ठीक से शुरू कर सकते हैं और अपने कमजोर संदर्भ को एक मजबूत संदर्भ में बदल सकते हैं।
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // डेटा फ़ील्ड के लिए उपरोक्त लेखन किसी भी थ्रेड के लिए दृश्यमान होना चाहिए जो एक गैर-शून्य मजबूत गणना का निरीक्षण करता है।
            // इसलिए हमें `Weak::upgrade` में `compare_exchange_weak` के साथ सिंक्रनाइज़ करने के लिए कम से कम "Release" ऑर्डरिंग की आवश्यकता है।
            //
            // "Acquire" आदेश देने की आवश्यकता नहीं है।
            // `data_fn` के संभावित व्यवहारों पर विचार करते समय हमें केवल यह देखने की आवश्यकता है कि यह गैर-अपग्रेड करने योग्य `Weak` के संदर्भ में क्या कर सकता है:
            //
            // - यह कमजोर संदर्भ संख्या को बढ़ाते हुए `Weak` को *क्लोन* कर सकता है।
            // - यह कमजोर संदर्भ संख्या को कम करते हुए उन क्लोनों को गिरा सकता है (लेकिन कभी भी शून्य नहीं)।
            //
            // ये दुष्प्रभाव हमें किसी भी तरह से प्रभावित नहीं करते हैं, और अकेले सुरक्षित कोड के साथ कोई अन्य दुष्प्रभाव संभव नहीं है।
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // मजबूत संदर्भ सामूहिक रूप से एक साझा कमजोर संदर्भ का स्वामी होना चाहिए, इसलिए हमारे पुराने कमजोर संदर्भ के लिए विनाशक को न चलाएं।
        //
        mem::forget(weak);
        strong
    }

    /// अप्रारंभीकृत सामग्री के साथ एक नया `Arc` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // आस्थगित आरंभीकरण:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// प्रारंभिक सामग्री के साथ एक नया `Arc` बनाता है, जिसमें मेमोरी `0` बाइट्स से भरी जाती है।
    ///
    ///
    /// इस पद्धति के सही और गलत उपयोग के उदाहरणों के लिए [`MaybeUninit::zeroed`][zeroed] देखें।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// एक नया `Pin<Arc<T>>` बनाता है।
    /// यदि `T` `Unpin` को लागू नहीं करता है, तो `data` को मेमोरी में पिन किया जाएगा और स्थानांतरित करने में असमर्थ होगा।
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// एक नया `Arc<T>` बनाता है, आवंटन विफल होने पर एक त्रुटि लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // कमजोर पॉइंटर गिनती को 1 के रूप में प्रारंभ करें जो कि कमजोर पॉइंटर है जो सभी मजबूत पॉइंटर्स (kinda) द्वारा आयोजित किया जाता है, अधिक जानकारी के लिए std/rc.rs देखें
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// अप्रारंभीकृत सामग्री के साथ एक नया `Arc` बनाता है, यदि आवंटन विफल हो जाता है तो एक त्रुटि लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // आस्थगित आरंभीकरण:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// प्रारंभिक सामग्री के साथ एक नया `Arc` बनाता है, जिसमें मेमोरी `0` बाइट्स से भरी जाती है, आवंटन विफल होने पर एक त्रुटि लौटाता है।
    ///
    ///
    /// इस पद्धति के सही और गलत उपयोग के उदाहरणों के लिए [`MaybeUninit::zeroed`][zeroed] देखें।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// आंतरिक मान लौटाता है, यदि `Arc` में बिल्कुल एक सशक्त संदर्भ है।
    ///
    /// अन्यथा, एक [`Err`] उसी `Arc` के साथ लौटाया जाता है जिसे पास किया गया था।
    ///
    ///
    /// बकाया कमजोर संदर्भ होने पर भी यह सफल होगा।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // निहित मजबूत-कमजोर संदर्भ को साफ करने के लिए एक कमजोर सूचक बनाएं
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// प्रारंभिक सामग्री के साथ एक नया परमाणु संदर्भ-गिनती टुकड़ा बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // आस्थगित आरंभीकरण:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// `0` बाइट्स से भरी हुई मेमोरी के साथ, गैर-आरंभिक सामग्री के साथ एक नए परमाणु संदर्भ-गिनती स्लाइस का निर्माण करता है।
    ///
    ///
    /// इस पद्धति के सही और गलत उपयोग के उदाहरणों के लिए [`MaybeUninit::zeroed`][zeroed] देखें।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` में कनवर्ट करता है।
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] के साथ, यह गारंटी देने के लिए कॉलर पर निर्भर है कि आंतरिक मूल्य वास्तव में प्रारंभिक स्थिति में है।
    ///
    /// जब सामग्री अभी तक पूरी तरह से प्रारंभ नहीं हुई है तो इसे कॉल करना तत्काल अपरिभाषित व्यवहार का कारण बनता है।
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // आस्थगित आरंभीकरण:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` में कनवर्ट करता है।
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] के साथ, यह गारंटी देने के लिए कॉलर पर निर्भर है कि आंतरिक मूल्य वास्तव में प्रारंभिक स्थिति में है।
    ///
    /// जब सामग्री अभी तक पूरी तरह से प्रारंभ नहीं हुई है तो इसे कॉल करना तत्काल अपरिभाषित व्यवहार का कारण बनता है।
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // आस्थगित आरंभीकरण:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// लपेटे हुए सूचक को वापस करते हुए, `Arc` का उपभोग करता है।
    ///
    /// स्मृति रिसाव से बचने के लिए पॉइंटर को [`Arc::from_raw`] का उपयोग करके वापस `Arc` में परिवर्तित किया जाना चाहिए।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// डेटा के लिए एक कच्चा सूचक प्रदान करता है।
    ///
    /// काउंट्स किसी भी तरह से प्रभावित नहीं होते हैं और `Arc` का उपभोग नहीं किया जाता है।
    /// पॉइंटर तब तक के लिए मान्य है जब तक कि `Arc` में मजबूत संख्याएं हों।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // सुरक्षा: यह Deref::deref या RcBoxPtr::inner के माध्यम से नहीं जा सकता क्योंकि
        // यह raw/mut उद्गम को बनाए रखने के लिए आवश्यक है जैसे कि
        // `get_mut` `from_raw` के माध्यम से आरसी पुनर्प्राप्त होने के बाद सूचक के माध्यम से लिख सकते हैं।
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// एक कच्चे सूचक से एक `Arc<T>` का निर्माण करता है।
    ///
    /// रॉ पॉइंटर को पहले [`Arc<U>::into_raw`][into_raw] पर कॉल द्वारा लौटाया जाना चाहिए, जहां `U` का आकार और संरेखण `T` के समान होना चाहिए।
    /// यदि `U`, `T` है तो यह तुच्छ रूप से सत्य है।
    /// ध्यान दें कि यदि `U` `T` नहीं है, लेकिन उसका आकार और संरेखण समान है, तो यह मूल रूप से विभिन्न प्रकार के संदर्भों को प्रसारित करने जैसा है।
    /// इस मामले में कौन से प्रतिबंध लागू होते हैं, इस बारे में अधिक जानकारी के लिए [`mem::transmute`][transmute] देखें।
    ///
    /// `from_raw` के उपयोगकर्ता को यह सुनिश्चित करना होगा कि `T` का एक विशिष्ट मान केवल एक बार गिराया जाए।
    ///
    /// यह फ़ंक्शन असुरक्षित है क्योंकि अनुचित उपयोग से स्मृति असुरक्षित हो सकती है, भले ही लौटा हुआ `Arc<T>` कभी एक्सेस न किया गया हो।
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // रिसाव को रोकने के लिए वापस `Arc` में कनवर्ट करें।
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` पर आगे की कॉल स्मृति-असुरक्षित होगी।
    /// }
    ///
    /// // मेमोरी मुक्त हो गई थी जब `x` ऊपर के दायरे से बाहर हो गया था, इसलिए `x_ptr` अब लटक रहा है!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // मूल आर्कइनर को खोजने के लिए ऑफ़सेट को उल्टा करें।
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// इस आवंटन के लिए एक नया [`Weak`] सूचक बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // यह आराम ठीक है क्योंकि हम नीचे CAS में मान की जाँच कर रहे हैं।
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // जांचें कि क्या कमजोर काउंटर वर्तमान में "locked" है;यदि हां, तो स्पिन करें।
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: यह कोड वर्तमान में अतिप्रवाह की संभावना को अनदेखा करता है
            // usize::MAX में;सामान्य तौर पर आरसी और आर्क दोनों को अतिप्रवाह से निपटने के लिए समायोजित करने की आवश्यकता होती है।
            //

            // Clone() के विपरीत, हमें इसे `is_unique` से आने वाले लेखन के साथ सिंक्रनाइज़ करने के लिए एक एक्वायर रीड होने की आवश्यकता है, ताकि उस राइट से पहले की घटनाएं इस रीड से पहले हो सकें।
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // सुनिश्चित करें कि हम झूलने वाले कमजोर नहीं बनाते हैं
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// इस आवंटन के लिए [`Weak`] पॉइंटर्स की संख्या प्राप्त करें।
    ///
    /// # Safety
    ///
    /// यह तरीका अपने आप में सुरक्षित है, लेकिन इसका सही तरीके से उपयोग करने के लिए अतिरिक्त देखभाल की आवश्यकता होती है।
    /// एक और धागा किसी भी समय कमजोर गिनती को बदल सकता है, जिसमें संभावित रूप से इस विधि को कॉल करने और परिणाम पर कार्य करने के बीच संभावित रूप से शामिल है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // यह अभिकथन नियतात्मक है क्योंकि हमने `Arc` या `Weak` को थ्रेड्स के बीच साझा नहीं किया है।
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // यदि कमजोर गिनती वर्तमान में बंद है, तो गिनती का मूल्य ताला लेने से ठीक पहले 0 था।
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// इस आवंटन के लिए मजबूत (`Arc`) पॉइंटर्स की संख्या प्राप्त करता है।
    ///
    /// # Safety
    ///
    /// यह तरीका अपने आप में सुरक्षित है, लेकिन इसका सही तरीके से उपयोग करने के लिए अतिरिक्त देखभाल की आवश्यकता होती है।
    /// एक और धागा किसी भी समय मजबूत गिनती को बदल सकता है, जिसमें संभावित रूप से इस विधि को कॉल करने और परिणाम पर कार्य करने के बीच संभावित रूप से शामिल है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // यह अभिकथन नियतात्मक है क्योंकि हमने `Arc` को थ्रेड्स के बीच साझा नहीं किया है।
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// प्रदान किए गए पॉइंटर से जुड़े `Arc<T>` पर मजबूत संदर्भ संख्या को एक-एक करके बढ़ाता है।
    ///
    /// # Safety
    ///
    /// सूचक `Arc::into_raw` के माध्यम से प्राप्त किया जाना चाहिए, और संबंधित `Arc` उदाहरण मान्य होना चाहिए (यानी
    /// इस पद्धति की अवधि के लिए मजबूत गणना कम से कम 1) होनी चाहिए।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // यह अभिकथन नियतात्मक है क्योंकि हमने `Arc` को थ्रेड्स के बीच साझा नहीं किया है।
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // आर्क बनाए रखें, लेकिन मैन्युअलीड्रॉप में रैप करके रीफ़काउंट को स्पर्श न करें
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // अब रीफ़काउंट बढ़ाएँ, लेकिन नया रीफ़काउंट भी न छोड़ें
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// प्रदान किए गए पॉइंटर से जुड़े `Arc<T>` पर मजबूत संदर्भ संख्या को एक से घटाता है।
    ///
    /// # Safety
    ///
    /// सूचक `Arc::into_raw` के माध्यम से प्राप्त किया जाना चाहिए, और संबंधित `Arc` उदाहरण मान्य होना चाहिए (यानी
    /// इस पद्धति को लागू करते समय मजबूत गणना कम से कम 1) होनी चाहिए।
    /// इस विधि का उपयोग अंतिम `Arc` और बैकिंग स्टोरेज को रिलीज करने के लिए किया जा सकता है, लेकिन अंतिम `Arc` जारी होने के बाद **नहीं** को कॉल किया जाना चाहिए।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // वे दावे नियतात्मक हैं क्योंकि हमने `Arc` को थ्रेड्स के बीच साझा नहीं किया है।
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // यह असुरक्षितता ठीक है क्योंकि जब तक यह चाप जीवित है, हम गारंटी देते हैं कि आंतरिक सूचक मान्य है।
        // इसके अलावा, हम जानते हैं कि `ArcInner` संरचना स्वयं `Sync` है क्योंकि आंतरिक डेटा भी `Sync` है, इसलिए हम इन सामग्रियों के लिए एक अपरिवर्तनीय सूचक उधार दे रहे हैं।
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` का गैर-रेखांकित भाग।
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // इस समय डेटा को नष्ट कर दें, भले ही हम बॉक्स आवंटन को स्वयं मुक्त न करें (अभी भी कमजोर पॉइंटर्स झूठ बोल रहे हैं)।
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // सभी मजबूत संदर्भों द्वारा सामूहिक रूप से रखे गए कमजोर रेफरी को छोड़ दें
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// यदि दो `आर्क` समान आवंटन ([`ptr::eq`] के समान शिरा में) की ओर इंगित करते हैं, तो `true` लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// एक संभावित-अनसाइज्ड आंतरिक मान के लिए पर्याप्त स्थान के साथ एक `ArcInner<T>` आवंटित करता है जहां मान में लेआउट प्रदान किया गया है।
    ///
    /// फ़ंक्शन `mem_to_arcinner` को डेटा पॉइंटर के साथ बुलाया जाता है और `ArcInner<T>` के लिए एक (संभावित रूप से वसा)-पॉइंटर वापस करना चाहिए।
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // दिए गए मान लेआउट का उपयोग करके लेआउट की गणना करें।
        // पहले, लेआउट की गणना `&*(ptr as* const ArcInner<T>)` अभिव्यक्ति पर की गई थी, लेकिन इसने एक गलत संरेखित संदर्भ बनाया (देखें #54908)।
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// एक संभावित-अनसाइज्ड आंतरिक मान के लिए पर्याप्त स्थान के साथ एक `ArcInner<T>` आवंटित करता है जहां मान में लेआउट प्रदान किया गया है, आवंटन विफल होने पर एक त्रुटि लौटाता है।
    ///
    ///
    /// फ़ंक्शन `mem_to_arcinner` को डेटा पॉइंटर के साथ बुलाया जाता है और `ArcInner<T>` के लिए एक (संभावित रूप से वसा)-पॉइंटर वापस करना चाहिए।
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // दिए गए मान लेआउट का उपयोग करके लेआउट की गणना करें।
        // पहले, लेआउट की गणना `&*(ptr as* const ArcInner<T>)` अभिव्यक्ति पर की गई थी, लेकिन इसने एक गलत संरेखित संदर्भ बनाया (देखें #54908)।
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // आर्कइनर को इनिशियलाइज़ करें
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// एक अनसाइज़्ड आंतरिक मान के लिए पर्याप्त स्थान के साथ एक `ArcInner<T>` आवंटित करता है।
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // दिए गए मान का उपयोग करके `ArcInner<T>` के लिए आवंटन करें।
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // मूल्य को बाइट्स के रूप में कॉपी करें
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // इसकी सामग्री को छोड़े बिना आवंटन को मुक्त करें
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// दी गई लंबाई के साथ एक `ArcInner<[T]>` आवंटित करता है।
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// स्लाइस से तत्वों को नए आवंटित आर्क में कॉपी करें<\[T\]>
    ///
    /// असुरक्षित क्योंकि कॉल करने वाले को या तो स्वामित्व लेना होगा या `T: Copy` को बाध्य करना होगा।
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// एक निश्चित आकार के ज्ञात पुनरावर्तक से `Arc<[T]>` का निर्माण करता है।
    ///
    /// आकार गलत होना चाहिए व्यवहार अपरिभाषित है।
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // T तत्वों की क्लोनिंग करते समय Panic गार्ड।
        // panic की स्थिति में, नए ArcInner में लिखे गए तत्वों को हटा दिया जाएगा, फिर मेमोरी मुक्त हो जाएगी।
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // पहले तत्व के लिए सूचक
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // सब साफ़।गार्ड को भूल जाइए ताकि वह नए आर्कइनर को मुक्त न करे।
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// विशेषज्ञता trait `From<&[T]>` के लिए प्रयुक्त।
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` पॉइंटर का क्लोन बनाता है।
    ///
    /// यह समान आवंटन के लिए एक और सूचक बनाता है, मजबूत संदर्भ संख्या को बढ़ाता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // आराम से आदेश का उपयोग करना यहां ठीक है, क्योंकि मूल संदर्भ का ज्ञान अन्य धागे को वस्तु को गलती से हटाने से रोकता है।
        //
        // जैसा कि [Boost documentation][1] में बताया गया है, संदर्भ काउंटर को बढ़ाना हमेशा मेमोरी_ऑर्डर_रिलैक्स्ड के साथ किया जा सकता है: किसी ऑब्जेक्ट के नए संदर्भ केवल मौजूदा संदर्भ से ही बनाए जा सकते हैं, और मौजूदा संदर्भ को एक थ्रेड से दूसरे में पास करना पहले से ही कोई आवश्यक सिंक्रनाइज़ेशन प्रदान करना चाहिए।
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // हालाँकि, यदि कोई व्यक्ति `मेम: : भूल गया` आर्क्स है, तो हमें बड़े पैमाने पर पुनर्भुगतान से सावधान रहने की आवश्यकता है।
        // अगर हम ऐसा नहीं करते हैं तो गिनती ओवरफ्लो हो सकती है और उपयोगकर्ता फ्री-आफ्टर का उपयोग करेंगे।
        // हम इस धारणा के आधार पर `isize::MAX` में तेजी से संतृप्त होते हैं कि ~2 बिलियन थ्रेड्स एक बार में संदर्भ संख्या में वृद्धि नहीं कर रहे हैं।
        //
        // इस branch को कभी भी किसी यथार्थवादी कार्यक्रम में नहीं लिया जाएगा।
        //
        // हम निरस्त करते हैं क्योंकि ऐसा कार्यक्रम अविश्वसनीय रूप से पतित है, और हम इसका समर्थन करने की परवाह नहीं करते हैं।
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// दिए गए `Arc` में एक परिवर्तनीय संदर्भ बनाता है।
    ///
    /// यदि समान आवंटन के लिए अन्य `Arc` या [`Weak`] पॉइंटर्स हैं, तो `make_mut` एक नया आवंटन बनाएगा और अद्वितीय स्वामित्व सुनिश्चित करने के लिए आंतरिक मूल्य पर [`clone`][clone] को लागू करेगा।
    /// इसे क्लोन-ऑन-राइट भी कहा जाता है।
    ///
    /// ध्यान दें कि यह [`Rc::make_mut`] के व्यवहार से भिन्न है जो किसी भी शेष `Weak` पॉइंटर्स को अलग करता है।
    ///
    /// [`get_mut`][get_mut] भी देखें, जो क्लोनिंग के बजाय विफल हो जाएगा।
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // कुछ भी क्लोन नहीं करेंगे
    /// let mut other_data = Arc::clone(&data); // आंतरिक डेटा क्लोन नहीं करेगा
    /// *Arc::make_mut(&mut data) += 1;         // क्लोन आंतरिक डेटा
    /// *Arc::make_mut(&mut data) += 1;         // कुछ भी क्लोन नहीं करेंगे
    /// *Arc::make_mut(&mut other_data) *= 2;   // कुछ भी क्लोन नहीं करेंगे
    ///
    /// // अब `data` और `other_data` अलग-अलग आवंटन की ओर इशारा करते हैं।
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // ध्यान दें कि हमारे पास एक मजबूत संदर्भ और एक कमजोर संदर्भ दोनों हैं।
        // इस प्रकार, केवल हमारे मजबूत संदर्भ को जारी करने से, स्मृति को नष्ट नहीं किया जाएगा।
        //
        // यह सुनिश्चित करने के लिए एक्वायर का उपयोग करें कि हम `weak` को कोई भी लेखन देखते हैं जो `strong` को रिलीज़ राइट्स (यानी, कमी) से पहले होता है।
        // चूंकि हम एक कमजोर गिनती रखते हैं, इसलिए कोई मौका नहीं है कि आर्कइनर को ही हटा दिया जा सके।
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // एक और मजबूत सूचक मौजूद है, इसलिए हमें क्लोन करना होगा।
            // क्लोन किए गए मान को सीधे लिखने की अनुमति देने के लिए स्मृति को पूर्व-आवंटित करें।
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // उपरोक्त में आराम पर्याप्त है क्योंकि यह मूल रूप से एक अनुकूलन है: हम हमेशा कमजोर पॉइंटर्स को गिराए जाने के साथ दौड़ रहे हैं।
            // सबसे खराब स्थिति में, हम अनावश्यक रूप से एक नया आर्क आवंटित कर देते हैं।
            //

            // हमने पिछले मजबूत रेफरी को हटा दिया, लेकिन अतिरिक्त कमजोर रेफरी शेष हैं।
            // हम सामग्री को एक नए आर्क में ले जाएंगे, और अन्य कमजोर रेफरी को अमान्य कर देंगे।
            //

            // ध्यान दें कि `weak` के पढ़ने के लिए usize::MAX (यानी, लॉक) उत्पन्न करना संभव नहीं है, क्योंकि कमजोर गिनती को केवल एक मजबूत संदर्भ के साथ थ्रेड द्वारा लॉक किया जा सकता है।
            //
            //

            // हमारे अपने निहित कमजोर सूचक को अमल में लाएं, ताकि वह आवश्यकतानुसार आर्कइनर को साफ कर सके।
            //
            let _weak = Weak { ptr: this.ptr };

            // केवल डेटा चुरा सकते हैं, जो कुछ बचा है वह कमजोर है
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // हम किसी भी तरह के एकमात्र संदर्भ थे;मजबूत रेफरी गिनती वापस टक्कर।
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()` की तरह, असुरक्षितता ठीक है क्योंकि हमारा संदर्भ या तो शुरुआत के लिए अद्वितीय था, या सामग्री को क्लोन करने पर एक बन गया।
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// यदि समान आवंटन के लिए कोई अन्य `Arc` या [`Weak`] पॉइंटर्स नहीं हैं, तो दिए गए `Arc` में एक परिवर्तनशील संदर्भ देता है।
    ///
    ///
    /// अन्यथा [`None`] लौटाता है, क्योंकि साझा मान को बदलना सुरक्षित नहीं है।
    ///
    /// [`make_mut`][make_mut] भी देखें, जो अन्य पॉइंटर्स होने पर आंतरिक मान [`clone`][clone] करेगा।
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // यह असुरक्षितता ठीक है क्योंकि हमें गारंटी है कि लौटाया गया पॉइंटर *only* पॉइंटर है जिसे कभी भी टी पर वापस कर दिया जाएगा।
            // इस बिंदु पर हमारी संदर्भ संख्या 1 होने की गारंटी है, और हमें आर्क को स्वयं `mut` होना चाहिए, इसलिए हम आंतरिक डेटा का एकमात्र संभावित संदर्भ लौटा रहे हैं।
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// दिए गए `Arc` में बिना किसी जांच के एक परिवर्तनीय संदर्भ देता है।
    ///
    /// [`get_mut`] भी देखें, जो सुरक्षित है और उचित जांच करता है।
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// किसी भी अन्य `Arc` या [`Weak`] पॉइंटर्स को समान आवंटन के लिए लौटाए गए उधार की अवधि के लिए संदर्भित नहीं किया जाना चाहिए।
    ///
    /// यह मामूली मामला है यदि ऐसा कोई संकेतक मौजूद नहीं है, उदाहरण के लिए `Arc::new` के तुरंत बाद।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // हम "count" फ़ील्ड को कवर करते हुए एक संदर्भ *नहीं* बनाने के लिए सावधान हैं, क्योंकि यह संदर्भ गणना के समवर्ती पहुंच के साथ उपनाम होगा (उदाहरण के लिए)
        // `Weak` द्वारा)।
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// निर्धारित करें कि क्या यह अंतर्निहित डेटा के लिए अद्वितीय संदर्भ (कमजोर रेफरी सहित) है।
    ///
    ///
    /// ध्यान दें कि इसके लिए कमजोर रेफरी गिनती को लॉक करने की आवश्यकता है।
    fn is_unique(&mut self) -> bool {
        // कमजोर पॉइंटर काउंट को लॉक करें यदि हम एकमात्र कमजोर पॉइंटर होल्डर प्रतीत होते हैं।
        //
        // यहां अधिग्रहण लेबल `weak` गिनती (`Weak::drop` के माध्यम से, जो रिलीज का उपयोग करता है) की कमी से पहले `strong` (विशेष रूप से `Weak::upgrade` में) को किसी भी लिखने के साथ होता है-पहले संबंध सुनिश्चित करता है।
        // यदि अपग्रेड किया गया कमजोर रेफरी कभी गिराया नहीं गया था, तो यहां सीएएस विफल हो जाएगा इसलिए हम सिंक्रनाइज़ करने की परवाह नहीं करते हैं।
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // `drop` में `strong` काउंटर की कमी के साथ सिंक्रनाइज़ करने के लिए इसे `Acquire` होना चाहिए-एकमात्र एक्सेस जो तब होता है जब कोई भी अंतिम संदर्भ छोड़ दिया जाता है।
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // यहाँ रिलीज़ राइट `downgrade` में रीड के साथ सिंक्रोनाइज़ करता है, प्रभावी रूप से `strong` के उपरोक्त रीड को राइटिंग के बाद होने से रोकता है।
            //
            //
            self.inner().weak.store(1, Release); // ताला छोड़ो
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` गिराता है।
    ///
    /// यह मजबूत संदर्भ संख्या में कमी करेगा।
    /// यदि मजबूत संदर्भ संख्या शून्य तक पहुंच जाती है तो केवल अन्य संदर्भ (यदि कोई हो) [`Weak`] हैं, इसलिए हम आंतरिक मान `drop` करते हैं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // कुछ भी नहीं छापता
    /// drop(foo2);   // प्रिंट "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // क्योंकि `fetch_sub` पहले से ही परमाणु है, हमें अन्य थ्रेड्स के साथ सिंक्रनाइज़ करने की आवश्यकता नहीं है जब तक कि हम ऑब्जेक्ट को हटाने नहीं जा रहे हैं।
        // यही तर्क नीचे दिए गए `fetch_sub` से `weak` काउंट पर लागू होता है।
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // डेटा के उपयोग और डेटा को हटाने के पुन: क्रम को रोकने के लिए इस बाड़ की आवश्यकता है।
        // क्योंकि इसे `Release` चिह्नित किया गया है, संदर्भ संख्या में कमी इस `Acquire` बाड़ के साथ सिंक्रनाइज़ हो जाती है।
        // इसका मतलब है कि डेटा का उपयोग संदर्भ संख्या को कम करने से पहले होता है, जो इस बाड़ से पहले होता है, जो डेटा को हटाने से पहले होता है।
        //
        // जैसा कि [Boost documentation][1] में बताया गया है,
        //
        // > किसी एक में वस्तु तक किसी भी संभावित पहुंच को लागू करना महत्वपूर्ण है
        // > धागा (मौजूदा संदर्भ के माध्यम से)*हटाने से पहले* होने के लिए
        // > एक अलग धागे में वस्तु।यह एक "release". द्वारा हासिल किया गया है
        // > एक संदर्भ छोड़ने के बाद ऑपरेशन (ऑब्जेक्ट तक कोई भी पहुंच
        // > इस संदर्भ के माध्यम से स्पष्ट रूप से पहले हुआ होगा), और एक
        // > "acquire" ऑब्जेक्ट को हटाने से पहले ऑपरेशन।
        //
        // विशेष रूप से, जबकि एक आर्क की सामग्री आमतौर पर अपरिवर्तनीय होती है, यह संभव है कि इंटीरियर को म्यूटेक्स की तरह कुछ लिखा जाए<T>.
        // चूंकि म्यूटेक्स को हटाए जाने पर हासिल नहीं किया जाता है, हम थ्रेड ए में लिखने के लिए इसके सिंक्रोनाइज़ेशन लॉजिक पर भरोसा नहीं कर सकते हैं, जो थ्रेड बी में चल रहे डिस्ट्रक्टर को दिखाई देता है।
        //
        //
        // यह भी ध्यान दें कि यहां एक्वायर बाड़ को शायद एक एक्वायर लोड से बदला जा सकता है, जो अत्यधिक विवादित स्थितियों में प्रदर्शन में सुधार कर सकता है।[2] देखें।
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>` को एक ठोस प्रकार में डाउनकास्ट करने का प्रयास करें।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// कोई मेमोरी आवंटित किए बिना, एक नया `Weak<T>` बनाता है।
    /// रिटर्न वैल्यू पर [`upgrade`] को कॉल करना हमेशा [`None`] देता है।
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// डेटा फ़ील्ड के बारे में कोई दावा किए बिना संदर्भ गणना तक पहुंचने की अनुमति देने के लिए सहायक प्रकार।
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// इस `Weak<T>` द्वारा इंगित वस्तु `T` पर एक कच्चा सूचक लौटाता है।
    ///
    /// पॉइंटर तभी मान्य होता है जब कुछ मजबूत संदर्भ हों।
    /// सूचक लटकता हुआ, असंरेखित या अन्यथा [`null`] भी हो सकता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // दोनों एक ही वस्तु की ओर इशारा करते हैं
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // यहां मजबूत इसे जीवित रखता है, इसलिए हम अभी भी वस्तु तक पहुंच सकते हैं।
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // लेकिन अब और नहीं।
    /// // हम weak.as_ptr() कर सकते हैं, लेकिन पॉइंटर तक पहुंचने से अपरिभाषित व्यवहार हो जाएगा।
    /// // assert_eq! ("हैलो", असुरक्षित {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // यदि सूचक लटक रहा है, तो हम सीधे प्रहरी को वापस कर देते हैं।
            // यह एक वैध पेलोड पता नहीं हो सकता है, क्योंकि पेलोड कम से कम आर्कइनर (usize) के रूप में संरेखित है।
            ptr as *const T
        } else {
            // सुरक्षा: यदि is_dangling झूठी वापसी करता है, तो सूचक dereferencable है।
            // इस बिंदु पर पेलोड गिराया जा सकता है, और हमें उत्पत्ति बनाए रखनी होगी, इसलिए कच्चे सूचक हेरफेर का उपयोग करें।
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` का उपभोग करता है और इसे एक कच्चे सूचक में बदल देता है।
    ///
    /// यह कमजोर सूचक को कच्चे सूचक में परिवर्तित करता है, जबकि अभी भी एक कमजोर संदर्भ के स्वामित्व को संरक्षित करता है (कमजोर गणना इस ऑपरेशन द्वारा संशोधित नहीं की जाती है)।
    /// इसे [`from_raw`] के साथ `Weak<T>` में वापस बदला जा सकता है।
    ///
    /// [`as_ptr`] के साथ पॉइंटर के लक्ष्य तक पहुँचने के समान प्रतिबंध लागू होते हैं।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`] द्वारा पहले बनाए गए कच्चे पॉइंटर को वापस `Weak<T>` में कनवर्ट करता है।
    ///
    /// इसका उपयोग सुरक्षित रूप से एक मजबूत संदर्भ प्राप्त करने के लिए किया जा सकता है (बाद में [`upgrade`] को कॉल करके) या `Weak<T>` को गिराकर कमजोर गिनती को हटाने के लिए।
    ///
    /// यह एक कमजोर संदर्भ का स्वामित्व लेता है ([`new`] द्वारा बनाए गए पॉइंटर्स के अपवाद के साथ, क्योंकि इनके पास कुछ भी नहीं है; विधि अभी भी उन पर काम करती है)।
    ///
    /// # Safety
    ///
    /// सूचक [`into_raw`] से उत्पन्न हुआ होगा और अभी भी इसके संभावित कमजोर संदर्भ का स्वामी होना चाहिए।
    ///
    /// इसे कॉल करने के समय मजबूत गिनती 0 होने की अनुमति है।
    /// फिर भी, यह एक कमजोर संदर्भ का स्वामित्व लेता है जिसे वर्तमान में एक कच्चे सूचक के रूप में दर्शाया गया है (कमजोर गणना इस ऑपरेशन द्वारा संशोधित नहीं है) और इसलिए इसे [`into_raw`] के पिछले कॉल के साथ जोड़ा जाना चाहिए।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // अंतिम कमजोर गणना घटाएं।
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // इनपुट पॉइंटर कैसे प्राप्त होता है, इस संदर्भ के लिए Weak::as_ptr देखें।

        let ptr = if is_dangling(ptr as *mut T) {
            // यह एक लटकता हुआ कमजोर है।
            ptr as *mut ArcInner<T>
        } else {
            // अन्यथा, हम गारंटी देते हैं कि सूचक एक गैर लटकने वाले कमजोर से आया है।
            // सुरक्षा: data_offset कॉल करने के लिए सुरक्षित है, क्योंकि ptr एक वास्तविक (संभावित रूप से गिरा हुआ) T को संदर्भित करता है।
            let offset = unsafe { data_offset(ptr) };
            // इस प्रकार, हम संपूर्ण RcBox प्राप्त करने के लिए ऑफ़सेट को उलट देते हैं।
            // सुरक्षा: सूचक कमजोर से उत्पन्न हुआ है, इसलिए यह ऑफ़सेट सुरक्षित है।
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // सुरक्षा: अब हमने मूल कमजोर सूचक को पुनः प्राप्त कर लिया है, इसलिए कमजोर बना सकते हैं।
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` पॉइंटर को [`Arc`] में अपग्रेड करने का प्रयास, सफल होने पर आंतरिक मान को छोड़ने में देरी करता है।
    ///
    ///
    /// यदि आंतरिक मान तब से गिरा दिया गया है, तो [`None`] लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // सभी मजबूत संकेतकों को नष्ट करें।
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // हम fetch_add के बजाय मजबूत गिनती बढ़ाने के लिए CAS लूप का उपयोग करते हैं क्योंकि इस फ़ंक्शन को कभी भी संदर्भ संख्या को शून्य से एक तक नहीं ले जाना चाहिए।
        //
        //
        let inner = self.inner()?;

        // आराम से लोड क्योंकि 0 का कोई भी लेखन जिसे हम देख सकते हैं वह क्षेत्र को स्थायी रूप से शून्य स्थिति में छोड़ देता है (इसलिए 0 का "stale" पढ़ना ठीक है), और किसी भी अन्य मान की पुष्टि नीचे CAS के माध्यम से की जाती है।
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // हम ऐसा क्यों करते हैं (`mem::forget` के लिए) इसके लिए `Arc::clone` में टिप्पणियाँ देखें।
            if n > MAX_REFCOUNT {
                abort();
            }

            // विफलता के मामले में आराम करना ठीक है क्योंकि हमें नए राज्य के बारे में कोई उम्मीद नहीं है।
            // सफलता के मामले को `Arc::new_cyclic` के साथ सिंक्रनाइज़ करने के लिए अधिग्रहण आवश्यक है, जब `Weak` संदर्भ पहले से ही बनाए जाने के बाद आंतरिक मान प्रारंभ किया जा सकता है।
            // उस स्थिति में, हम पूरी तरह से आरंभिक मूल्य का निरीक्षण करने की अपेक्षा करते हैं।
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // शून्य ऊपर चेक किया गया
                Err(old) => n = old,
            }
        }
    }

    /// इस आवंटन को इंगित करने वाले मजबूत (`Arc`) पॉइंटर्स की संख्या प्राप्त करता है।
    ///
    /// यदि `self` को [`Weak::new`] का उपयोग करके बनाया गया था, तो यह 0 लौटाएगा।
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// इस आवंटन को इंगित करने वाले `Weak` पॉइंटर्स की संख्या का अनुमान प्राप्त करता है।
    ///
    /// यदि `self` [`Weak::new`] का उपयोग करके बनाया गया था, या यदि कोई शेष मजबूत पॉइंटर्स नहीं हैं, तो यह 0 वापस आ जाएगा।
    ///
    /// # Accuracy
    ///
    /// कार्यान्वयन विवरण के कारण, लौटाया गया मान किसी भी दिशा में 1 से बंद हो सकता है जब अन्य धागे समान आवंटन की ओर इशारा करते हुए किसी भी 'आर्क' या 'कमजोर' में हेरफेर कर रहे हों।
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // चूंकि हमने देखा कि कमजोर गिनती को पढ़ने के बाद कम से कम एक मजबूत सूचक था, हम जानते हैं कि निहित कमजोर संदर्भ (जब भी कोई मजबूत संदर्भ जीवित होता है) तब भी आसपास था जब हमने कमजोर गिनती देखी, और इसलिए इसे सुरक्षित रूप से घटाया जा सकता है।
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// जब पॉइंटर लटकता है और कोई आवंटित `ArcInner` नहीं होता है, तो `None` लौटाता है, (यानी, जब यह `Weak` `Weak::new` द्वारा बनाया गया था)।
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // हम "data" फ़ील्ड को कवर करने के लिए *नहीं* संदर्भ बनाने के लिए सावधान हैं, क्योंकि फ़ील्ड को समवर्ती रूप से उत्परिवर्तित किया जा सकता है (उदाहरण के लिए, यदि अंतिम `Arc` गिरा दिया जाता है, तो डेटा फ़ील्ड को जगह में छोड़ दिया जाएगा)।
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// यदि दो `कमजोर` समान आवंटन ([`ptr::eq`] के समान) की ओर इशारा करते हैं, या यदि दोनों किसी आवंटन को इंगित नहीं करते हैं, तो `true` लौटाता है (क्योंकि वे `Weak::new()`) के साथ बनाए गए थे।
    ///
    ///
    /// # Notes
    ///
    /// चूंकि यह पॉइंटर्स की तुलना करता है इसका मतलब है कि `Weak::new()` एक दूसरे के बराबर होगा, भले ही वे किसी आवंटन को इंगित न करें।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` की तुलना।
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// `Weak` पॉइंटर का क्लोन बनाता है जो समान आवंटन की ओर इशारा करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // इसमें ढील क्यों दी गई है, इसके लिए Arc::clone() में टिप्पणियां देखें।
        // यह एक fetch_add (ताला को अनदेखा कर रहा है) का उपयोग कर सकता है क्योंकि कमजोर गिनती केवल लॉक है जहां अस्तित्व में * कोई अन्य कमजोर पॉइंटर्स नहीं हैं।
        //
        // (इसलिए हम उस स्थिति में यह कोड नहीं चला सकते हैं)।
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // हम ऐसा क्यों करते हैं (mem::forget के लिए) इसके लिए Arc::clone() में टिप्पणियाँ देखें।
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// स्मृति आवंटित किए बिना एक नया `Weak<T>` बनाता है।
    /// रिटर्न वैल्यू पर [`upgrade`] को कॉल करना हमेशा [`None`] देता है।
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` पॉइंटर को ड्रॉप करता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // कुछ भी नहीं छापता
    /// drop(foo);        // प्रिंट "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // अगर हमें पता चलता है कि हम आखिरी कमजोर सूचक थे, तो यह डेटा को पूरी तरह से हटाने का समय है।मेमोरी ऑर्डरिंग के बारे में Arc::drop() में चर्चा देखें
        //
        // यहां लॉक की गई स्थिति की जांच करना आवश्यक नहीं है, क्योंकि कमजोर गिनती को केवल तभी लॉक किया जा सकता है जब ठीक एक कमजोर रेफरी हो, जिसका अर्थ है कि ड्रॉप केवल बाद में उस शेष कमजोर रेफरी पर चल सकता है, जो लॉक जारी होने के बाद ही हो सकता है।
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// हम यह विशेषज्ञता यहां कर रहे हैं, न कि `&T` पर अधिक सामान्य अनुकूलन के रूप में, क्योंकि यह अन्यथा रेफरी पर सभी समानता जांचों के लिए एक लागत जोड़ देगा।
/// हम मानते हैं कि `आर्क` का उपयोग बड़े मूल्यों को संग्रहीत करने के लिए किया जाता है, जो क्लोन करने के लिए धीमे होते हैं, लेकिन समानता की जांच करने के लिए भारी भी होते हैं, जिससे यह लागत अधिक आसानी से चुकानी पड़ती है।
///
/// इसमें दो `Arc` क्लोन होने की भी अधिक संभावना है, जो दो `&T` की तुलना में समान मान की ओर इशारा करते हैं।
///
/// हम ऐसा तभी कर सकते हैं जब `T: Eq` एक `PartialEq` के रूप में जानबूझकर अपरिवर्तनीय हो।
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// दो `आर्क` के लिए समानता।
    ///
    /// दो 'आर्क' बराबर होते हैं यदि उनके आंतरिक मान समान होते हैं, भले ही वे अलग-अलग आवंटन में संग्रहीत हों।
    ///
    /// यदि `T` भी `Eq` (समानता की परावर्तनशीलता को लागू करता है) को लागू करता है, तो दो `आर्क` जो समान आवंटन को इंगित करते हैं, हमेशा बराबर होते हैं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// दो `आर्क` के लिए असमानता।
    ///
    /// दो `आर्क` असमान हैं यदि उनके आंतरिक मूल्य असमान हैं।
    ///
    /// यदि `T` भी `Eq` (समानता की परावर्तनशीलता को लागू करता है) को लागू करता है, तो दो `आर्क` जो समान मान को इंगित करते हैं, कभी भी असमान नहीं होते हैं।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// दो `आर्क` के लिए आंशिक तुलना।
    ///
    /// `partial_cmp()` को उनके आंतरिक मूल्यों पर कॉल करके दोनों की तुलना की जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// दो `आर्क` के लिए तुलना से कम।
    ///
    /// `<` को उनके आंतरिक मूल्यों पर कॉल करके दोनों की तुलना की जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// दो `आर्क` के लिए तुलना 'से कम या इसके बराबर'।
    ///
    /// `<=` को उनके आंतरिक मूल्यों पर कॉल करके दोनों की तुलना की जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// दो `आर्क` के लिए तुलना से बड़ा।
    ///
    /// `>` को उनके आंतरिक मूल्यों पर कॉल करके दोनों की तुलना की जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// दो `आर्क` के लिए तुलना 'से बड़ा या इसके बराबर'।
    ///
    /// `>=` को उनके आंतरिक मूल्यों पर कॉल करके दोनों की तुलना की जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// दो `आर्क` के लिए तुलना।
    ///
    /// `cmp()` को उनके आंतरिक मूल्यों पर कॉल करके दोनों की तुलना की जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` के लिए `Default` मान के साथ एक नया `Arc<T>` बनाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// एक संदर्भ-गिनती टुकड़ा आवंटित करें और `v` की वस्तुओं को क्लोन करके इसे भरें।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// एक संदर्भ-गिनती `str` आवंटित करें और उसमें `v` की प्रतिलिपि बनाएँ।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// एक संदर्भ-गिनती `str` आवंटित करें और उसमें `v` की प्रतिलिपि बनाएँ।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// एक बॉक्स किए गए ऑब्जेक्ट को एक नए, संदर्भ-गणना आवंटन में ले जाएं।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// एक संदर्भ-गिनती टुकड़ा आवंटित करें और उसमें `v` की वस्तुओं को स्थानांतरित करें।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec को उसकी मेमोरी को मुक्त करने दें, लेकिन उसकी सामग्री को नष्ट न करें
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// प्रत्येक तत्व को `Iterator` में लेता है और उसे `Arc<[T]>` में एकत्रित करता है।
    ///
    /// # प्रदर्शन गुण
    ///
    /// ## सामान्य मामला
    ///
    /// सामान्य स्थिति में, `Arc<[T]>` में एकत्रित करना पहले `Vec<T>` में एकत्रित करके किया जाता है।अर्थात्, निम्नलिखित लिखते समय:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// यह ऐसा व्यवहार करता है जैसे हमने लिखा है:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // आवंटन का पहला सेट यहां होता है।
    ///     .into(); // `Arc<[T]>` के लिए दूसरा आवंटन यहां होता है।
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// यह `Vec<T>` के निर्माण के लिए जितनी बार आवश्यक हो उतनी बार आवंटित करेगा और फिर `Vec<T>` को `Arc<[T]>` में बदलने के लिए एक बार आवंटित करेगा।
    ///
    ///
    /// ## ज्ञात लंबाई के पुनरावर्तक
    ///
    /// जब आपका `Iterator` `TrustedLen` लागू करता है और सटीक आकार का होता है, तो `Arc<[T]>` के लिए एकल आवंटन किया जाएगा।उदाहरण के लिए:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // यहां केवल एक आवंटन होता है।
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// विशेषज्ञता trait `Arc<[T]>` में एकत्रित करने के लिए उपयोग की जाती है।
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // यह एक `TrustedLen` इटरेटर का मामला है।
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // सुरक्षा: हमें यह सुनिश्चित करने की ज़रूरत है कि इटरेटर की सटीक लंबाई है और हमारे पास है।
                Arc::from_iter_exact(self, low)
            }
        } else {
            // सामान्य कार्यान्वयन पर वापस जाएं।
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// एक पॉइंटर के पीछे पेलोड के लिए `ArcInner` के भीतर ऑफ़सेट प्राप्त करें।
///
/// # Safety
///
/// पॉइंटर को टी के पहले मान्य उदाहरण को इंगित करना चाहिए (और उसके लिए वैध मेटाडेटा होना चाहिए), लेकिन टी को छोड़ने की अनुमति है।
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // अनसाइज़्ड मान को ArcInner के अंत में संरेखित करें।
    // क्योंकि RcBox repr(C) है, यह हमेशा मेमोरी में अंतिम फ़ील्ड होगा।
    // सुरक्षा: चूंकि केवल अनसाइज्ड प्रकार संभव हैं स्लाइस, trait ऑब्जेक्ट्स,
    // और बाहरी प्रकार, इनपुट सुरक्षा आवश्यकता वर्तमान में align_of_val_raw की आवश्यकताओं को पूरा करने के लिए पर्याप्त है;यह उस भाषा का कार्यान्वयन विवरण है जिस पर std के बाहर भरोसा नहीं किया जा सकता है।
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}