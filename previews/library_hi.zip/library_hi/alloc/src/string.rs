//! एक UTF-8-एन्कोडेड, बढ़ने योग्य स्ट्रिंग।
//!
//! इस मॉड्यूल में [`String`] प्रकार, स्ट्रिंग में कनवर्ट करने के लिए [`ToString`] trait, और कई त्रुटि प्रकार शामिल हैं जो [`String`] s के साथ काम करने के परिणामस्वरूप हो सकते हैं।
//!
//!
//! # Examples
//!
//! स्ट्रिंग अक्षर से नया [`String`] बनाने के कई तरीके हैं:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! आप मौजूदा से एक नया [`String`] बना सकते हैं
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! यदि आपके पास वैध UTF-8 बाइट्स का vector है, तो आप इसमें से एक [`String`] बना सकते हैं।आप उल्टा भी कर सकते हैं।
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // हम जानते हैं कि ये बाइट मान्य हैं, इसलिए हम `unwrap()` का उपयोग करेंगे।
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// एक UTF-8-एन्कोडेड, बढ़ने योग्य स्ट्रिंग।
///
/// `String` प्रकार सबसे आम स्ट्रिंग प्रकार है जिसका स्ट्रिंग की सामग्री पर स्वामित्व है।इसका अपने उधार के समकक्ष, आदिम [`str`] के साथ घनिष्ठ संबंध है।
///
/// # Examples
///
/// आप [a literal string][`str`] से [`String::from`] के साथ `String` बना सकते हैं:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// आप [`push`] विधि के साथ [`char`] को `String` में जोड़ सकते हैं, और [`push_str`] विधि के साथ [`&str`] जोड़ सकते हैं:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// यदि आपके पास UTF-8 बाइट्स का vector है, तो आप [`from_utf8`] विधि से इससे `String` बना सकते हैं:
///
/// ```
/// // vector. में कुछ बाइट्स
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // हम जानते हैं कि ये बाइट मान्य हैं, इसलिए हम `unwrap()` का उपयोग करेंगे।
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `स्ट्रिंग` हमेशा मान्य UTF-8 होते हैं।इसके कुछ निहितार्थ हैं, जिनमें से पहला यह है कि यदि आपको गैर-UTF-8 स्ट्रिंग की आवश्यकता है, तो [`OsString`] पर विचार करें।यह समान है, लेकिन UTF-8 बाधा के बिना।दूसरा निहितार्थ यह है कि आप `String` में अनुक्रमित नहीं कर सकते हैं:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// अनुक्रमण का उद्देश्य निरंतर-समय का संचालन होना है, लेकिन UTF-8 एन्कोडिंग हमें ऐसा करने की अनुमति नहीं देता है।इसके अलावा, यह स्पष्ट नहीं है कि सूचकांक को किस प्रकार की चीज़ वापस करनी चाहिए: एक बाइट, एक कोडपॉइंट, या एक ग्रेफेम क्लस्टर।
/// [`bytes`] और [`chars`] विधियां क्रमशः पहले दो पर पुनरावर्तक लौटाती हैं।
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `स्ट्रिंग` कार्यान्वयन [`Deref`]`<Target=str>`, और इसलिए [`str`] की सभी विधियों को इनहेरिट करें।इसके अलावा, इसका मतलब है कि आप एक `String` को एक फ़ंक्शन में पास कर सकते हैं जो एक एम्परसेंड (`&`) का उपयोग करके एक [`&str`] लेता है:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// यह `String` से एक [`&str`] बनाएगा और इसे पास करेगा। यह रूपांतरण बहुत सस्ता है, और इसलिए आम तौर पर, फ़ंक्शन [`&str`] s को तर्क के रूप में स्वीकार करेंगे जब तक कि उन्हें किसी विशिष्ट कारण के लिए `String` की आवश्यकता न हो।
///
/// कुछ मामलों में Rust के पास इस रूपांतरण को करने के लिए पर्याप्त जानकारी नहीं है, जिसे [`Deref`] जबरदस्ती कहा जाता है।निम्नलिखित उदाहरण में एक स्ट्रिंग स्लाइस [`&'a str`][`&str`] trait `TraitExample` को लागू करता है, और फ़ंक्शन `example_func` कुछ भी लेता है जो trait को लागू करता है।
/// इस मामले में Rust को दो निहित रूपांतरण करने की आवश्यकता होगी, जो Rust के पास करने के लिए साधन नहीं है।
/// इस कारण से, निम्न उदाहरण संकलित नहीं होगा।
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// इसके बजाय दो विकल्प हैं जो काम करेंगे।सबसे पहले स्ट्रिंग वाले स्ट्रिंग स्लाइस को स्पष्ट रूप से निकालने के लिए [`as_str()`] विधि का उपयोग करके लाइन `example_func(&example_string);` को `example_func(example_string.as_str());` में बदलना होगा।
/// दूसरा तरीका `example_func(&example_string);` को `example_func(&*example_string);` में बदलता है।
/// इस मामले में हम `String` को [`str`][`&str`] में संदर्भित कर रहे हैं, फिर [`str`][`&str`] को वापस [`&str`] में संदर्भित कर रहे हैं।
/// दूसरा तरीका अधिक मुहावरेदार है, हालांकि दोनों ही अंतर्निहित रूपांतरण पर निर्भर होने के बजाय स्पष्ट रूप से रूपांतरण करने का काम करते हैं।
///
/// # Representation
///
/// एक `String` तीन घटकों से बना होता है: कुछ बाइट्स के लिए एक सूचक, एक लंबाई और एक क्षमता।सूचक एक आंतरिक बफर को इंगित करता है जो `String` अपने डेटा को संग्रहीत करने के लिए उपयोग करता है।लंबाई वर्तमान में बफर में संग्रहीत बाइट्स की संख्या है, और क्षमता बाइट्स में बफर का आकार है।
///
/// जैसे, लंबाई हमेशा क्षमता से कम या उसके बराबर होगी।
///
/// यह बफ़र हमेशा हीप पर संग्रहीत होता है।
///
/// आप इन्हें [`as_ptr`], [`len`], और [`capacity`] विधियों से देख सकते हैं:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME इसे अपडेट करें जब vec_into_raw_parts स्थिर हो जाए।
/// // स्ट्रिंग के डेटा को स्वचालित रूप से छोड़ने से रोकें
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // कहानी में उन्नीस बाइट्स हैं
/// assert_eq!(19, len);
///
/// // हम ptr, len, और क्षमता से एक स्ट्रिंग को फिर से बना सकते हैं।
/// // यह सब असुरक्षित है क्योंकि हम यह सुनिश्चित करने के लिए जिम्मेदार हैं कि घटक मान्य हैं:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// यदि `String` में पर्याप्त क्षमता है, तो इसमें तत्वों को जोड़ने से पुन: आवंटन नहीं होगा।उदाहरण के लिए, इस कार्यक्रम पर विचार करें:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// यह निम्नलिखित आउटपुट करेगा:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// सबसे पहले, हमारे पास कोई मेमोरी आवंटित नहीं है, लेकिन जैसे ही हम स्ट्रिंग में जोड़ते हैं, यह इसकी क्षमता को उचित रूप से बढ़ाता है।यदि हम प्रारंभ में सही क्षमता आवंटित करने के लिए [`with_capacity`] विधि का उपयोग करते हैं:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// हम एक अलग आउटपुट के साथ समाप्त होते हैं:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// यहां, लूप के अंदर अधिक मेमोरी आवंटित करने की कोई आवश्यकता नहीं है।
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// UTF-8 बाइट vector से `String` को कनवर्ट करते समय एक संभावित त्रुटि मान।
///
/// यह प्रकार [`String`] पर [`from_utf8`] विधि के लिए त्रुटि प्रकार है।
/// इसे इस तरह से डिज़ाइन किया गया है कि सावधानी से पुनर्वितरण से बचें: [`into_bytes`] विधि बाइट vector को वापस दे देगी जिसका उपयोग रूपांतरण प्रयास में किया गया था।
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] द्वारा प्रदान किया गया [`Utf8Error`] प्रकार एक त्रुटि का प्रतिनिधित्व करता है जो [`u8`] s के एक स्लाइस को [`&str`] में परिवर्तित करते समय हो सकती है।
/// इस अर्थ में, यह `FromUtf8Error` का एक एनालॉग है, और आप `FromUtf8Error` से [`utf8_error`] विधि के माध्यम से एक प्राप्त कर सकते हैं।
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// // vector. में कुछ अमान्य बाइट्स
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// UTF-16 बाइट स्लाइस से `String` को कनवर्ट करते समय एक संभावित त्रुटि मान।
///
/// यह प्रकार [`String`] पर [`from_utf16`] विधि के लिए त्रुटि प्रकार है।
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// मूल उपयोग:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// एक नया खाली `String` बनाता है।
    ///
    /// यह देखते हुए कि `String` खाली है, यह कोई प्रारंभिक बफर आवंटित नहीं करेगा।जबकि इसका मतलब है कि यह प्रारंभिक ऑपरेशन बहुत सस्ता है, बाद में जब आप डेटा जोड़ते हैं तो यह अत्यधिक आवंटन का कारण बन सकता है।
    ///
    /// यदि आपको इस बात का अंदाजा है कि `String` में कितना डेटा होगा, तो अत्यधिक पुन: आवंटन को रोकने के लिए [`with_capacity`] विधि पर विचार करें।
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// एक विशेष क्षमता के साथ एक नया खाली `String` बनाता है।
    ///
    /// `स्ट्रिंग` के पास अपना डेटा रखने के लिए एक आंतरिक बफर है।
    /// क्षमता उस बफर की लंबाई है, और [`capacity`] विधि से पूछताछ की जा सकती है।
    /// यह विधि एक खाली `String` बनाती है, लेकिन एक प्रारंभिक बफर के साथ जो `capacity` बाइट्स रख सकती है।
    /// यह तब उपयोगी होता है जब आप `String` में डेटा का एक गुच्छा जोड़ रहे होते हैं, जिससे इसे करने के लिए आवश्यक वास्तविक स्थानों की संख्या कम हो जाती है।
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// यदि दी गई क्षमता `0` है, तो कोई आवंटन नहीं होगा, और यह विधि [`new`] विधि के समान है।
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // स्ट्रिंग में कोई वर्ण नहीं है, भले ही इसमें अधिक क्षमता हो
    /// assert_eq!(s.len(), 0);
    ///
    /// // ये सभी पुन: आवंटित किए बिना किए जाते हैं ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ...लेकिन यह स्ट्रिंग को फिर से आवंटित कर सकता है
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) के साथ अंतर्निहित `[T]::to_vec` विधि, जो इस विधि परिभाषा के लिए आवश्यक है, उपलब्ध नहीं है।
    // चूंकि हमें परीक्षण उद्देश्यों के लिए इस पद्धति की आवश्यकता नहीं है, इसलिए मैं इसे केवल एनबी को अधिक जानकारी के लिए slice.rs में slice::hack मॉड्यूल देखूंगा।
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// vector बाइट्स को `String` में कनवर्ट करता है।
    ///
    /// एक स्ट्रिंग ([`String`]) बाइट्स ([`u8`]) से बना है, और vector बाइट्स ([`Vec<u8>`]) बाइट्स से बना है, इसलिए यह फ़ंक्शन दोनों के बीच कनवर्ट करता है।
    /// सभी बाइट स्लाइस वैध `स्ट्रिंग` नहीं हैं, हालांकि: `String` के लिए यह आवश्यक है कि यह वैध UTF-8 हो।
    /// `from_utf8()` यह सुनिश्चित करने के लिए जांच करता है कि बाइट वैध UTF-8 हैं, और फिर रूपांतरण करता है।
    ///
    /// यदि आप सुनिश्चित हैं कि बाइट स्लाइस वैध UTF-8 है, और आप वैधता जांच के ऊपरी हिस्से को नहीं लेना चाहते हैं, तो इस फ़ंक्शन का एक असुरक्षित संस्करण [`from_utf8_unchecked`] है, जिसका व्यवहार समान है लेकिन चेक को छोड़ देता है।
    ///
    ///
    /// दक्षता के लिए, यह विधि vector की नकल न करने का ध्यान रखेगी।
    ///
    /// यदि आपको `String` के बजाय [`&str`] की आवश्यकता है, तो [`str::from_utf8`] पर विचार करें।
    ///
    /// इस विधि का विलोम [`into_bytes`] है।
    ///
    /// # Errors
    ///
    /// यदि स्लाइस UTF-8 नहीं है तो इस विवरण के साथ [`Err`] लौटाता है कि प्रदान किए गए बाइट UTF-8 क्यों नहीं हैं।आप जिस vector में चले गए हैं वह भी शामिल है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// // vector. में कुछ बाइट्स
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // हम जानते हैं कि ये बाइट मान्य हैं, इसलिए हम `unwrap()` का उपयोग करेंगे।
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// गलत बाइट्स:
    ///
    /// ```
    /// // vector. में कुछ अमान्य बाइट्स
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// इस त्रुटि के साथ आप क्या कर सकते हैं, इस बारे में अधिक विवरण के लिए [`FromUtf8Error`] के लिए दस्तावेज़ देखें।
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// अमान्य वर्णों सहित बाइट्स के एक टुकड़े को एक स्ट्रिंग में कनवर्ट करता है।
    ///
    /// स्ट्रिंग्स बाइट्स ([`u8`]) से बने होते हैं, और बाइट्स का एक टुकड़ा ([`&[u8]`][byteslice]) बाइट्स से बना होता है, इसलिए यह फ़ंक्शन दोनों के बीच कनवर्ट करता है।सभी बाइट स्लाइस मान्य स्ट्रिंग नहीं हैं, हालांकि: स्ट्रिंग्स को मान्य UTF-8 होना आवश्यक है।
    /// इस रूपांतरण के दौरान, `from_utf8_lossy()` किसी भी अमान्य UTF-8 अनुक्रमों को [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] से बदल देगा, जो इस तरह दिखता है:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// यदि आप सुनिश्चित हैं कि बाइट स्लाइस वैध UTF-8 है, और आप रूपांतरण के ऊपरी हिस्से को नहीं लेना चाहते हैं, तो इस फ़ंक्शन का एक असुरक्षित संस्करण है, [`from_utf8_unchecked`], जिसका व्यवहार समान है लेकिन चेक को छोड़ देता है।
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// यह फ़ंक्शन [`Cow<'a, str>`] देता है।यदि हमारा बाइट स्लाइस अमान्य UTF-8 है, तो हमें प्रतिस्थापन वर्णों को सम्मिलित करने की आवश्यकता है, जो स्ट्रिंग के आकार को बदल देगा, और इसलिए, एक `String` की आवश्यकता होगी।
    /// लेकिन अगर यह पहले से ही मान्य UTF-8 है, तो हमें नए आवंटन की आवश्यकता नहीं है।
    /// यह वापसी प्रकार हमें दोनों मामलों को संभालने की अनुमति देता है।
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// // vector. में कुछ बाइट्स
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// गलत बाइट्स:
    ///
    /// ```
    /// // कुछ अमान्य बाइट्स
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// UTF-16-एन्कोडेड vector `v` को `String` में डिकोड करें, यदि `v` में कोई अमान्य डेटा है तो [`Err`] लौटाता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // यह संग्रह के माध्यम से नहीं किया जाता है: : <Result<_, _>>() प्रदर्शन कारणों से।
        // FIXME: #48994 बंद होने पर फ़ंक्शन को फिर से सरल बनाया जा सकता है।
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// एक UTF-16-एन्कोडेड स्लाइस `v` को एक `String` में डीकोड करें, अमान्य डेटा को [the replacement character (`U+FFFD`)][U+FFFD] से बदलें।
    ///
    /// [`from_utf8_lossy`] के विपरीत जो [`Cow<'a, str>`] देता है, `from_utf16_lossy` `String` देता है क्योंकि UTF-16 से UTF-8 रूपांतरण के लिए मेमोरी आवंटन की आवश्यकता होती है।
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// अपने कच्चे घटकों में एक `String` को विघटित करता है।
    ///
    /// कच्चे पॉइंटर को अंतर्निहित डेटा, स्ट्रिंग की लंबाई (बाइट्स में), और डेटा की आवंटित क्षमता (बाइट्स में) देता है।
    /// [`from_raw_parts`] के तर्कों के समान क्रम में ये समान तर्क हैं।
    ///
    /// इस फ़ंक्शन को कॉल करने के बाद, कॉलर पहले `String` द्वारा प्रबंधित मेमोरी के लिए ज़िम्मेदार है।
    /// ऐसा करने का एकमात्र तरीका कच्चे सूचक, लंबाई और क्षमता को [`from_raw_parts`] फ़ंक्शन के साथ वापस `String` में परिवर्तित करना है, जिससे विध्वंसक को सफाई करने की अनुमति मिलती है।
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// लंबाई, क्षमता और पॉइंटर से एक नया `String` बनाता है।
    ///
    /// # Safety
    ///
    /// चेक नहीं किए गए इनवेरिएंट की संख्या के कारण यह अत्यधिक असुरक्षित है:
    ///
    /// * `buf` पर मेमोरी को पहले उसी आवंटक द्वारा आवंटित किया जाना चाहिए जो मानक पुस्तकालय उपयोग करता है, ठीक 1 के आवश्यक संरेखण के साथ।
    /// * `length` `capacity` से कम या उसके बराबर होना चाहिए।
    /// * `capacity` सही मूल्य होना चाहिए।
    /// * `buf` पर पहले `length` बाइट्स मान्य UTF-8 होने चाहिए।
    ///
    /// इनका उल्लंघन करने से आवंटक की आंतरिक डेटा संरचनाओं को दूषित करने जैसी समस्याएं हो सकती हैं।
    ///
    /// `buf` का स्वामित्व प्रभावी रूप से `String` को स्थानांतरित कर दिया जाता है जो तब पॉइंटर द्वारा इंगित स्मृति की सामग्री को हटा सकता है, पुनः आवंटित या बदल सकता है।
    /// सुनिश्चित करें कि इस फ़ंक्शन को कॉल करने के बाद और कुछ भी पॉइंटर का उपयोग नहीं करता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME इसे अपडेट करें जब vec_into_raw_parts स्थिर हो जाए।
    ///     // स्ट्रिंग के डेटा को स्वचालित रूप से छोड़ने से रोकें
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// स्ट्रिंग में मान्य UTF-8 है या नहीं, इसकी जाँच किए बिना vector बाइट्स को `String` में कनवर्ट करता है।
    ///
    /// अधिक विवरण के लिए सुरक्षित संस्करण, [`from_utf8`] देखें।
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// यह फ़ंक्शन असुरक्षित है क्योंकि यह जाँच नहीं करता है कि इसमें दिए गए बाइट मान्य UTF-8 हैं।
    /// यदि इस बाधा का उल्लंघन किया जाता है, तो यह `String` के future उपयोगकर्ताओं के साथ मेमोरी असुरक्षितता की समस्या पैदा कर सकता है, क्योंकि बाकी मानक लाइब्रेरी मानती है कि `स्ट्रिंग` वैध UTF-8 हैं।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// // vector. में कुछ बाइट्स
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// एक `String` को एक बाइट vector में कनवर्ट करता है।
    ///
    /// यह `String` की खपत करता है, इसलिए हमें इसकी सामग्री को कॉपी करने की आवश्यकता नहीं है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// संपूर्ण `String` युक्त एक स्ट्रिंग स्लाइस निकालता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// एक `String` को एक परिवर्तनशील स्ट्रिंग स्लाइस में परिवर्तित करता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// इस `String` के अंत में दिए गए स्ट्रिंग स्लाइस को जोड़ता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// इस `स्ट्रिंग` की क्षमता को बाइट्स में लौटाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// सुनिश्चित करता है कि इस `स्ट्रिंग` की क्षमता इसकी लंबाई से कम से कम `additional` बाइट बड़ी है।
    ///
    /// बार-बार होने वाले पुन: आवंटन को रोकने के लिए, यदि वह चाहे तो क्षमता को `additional` बाइट्स से अधिक बढ़ा सकता है।
    ///
    ///
    /// यदि आप यह "at least" व्यवहार नहीं चाहते हैं, तो [`reserve_exact`] विधि देखें।
    ///
    /// # Panics
    ///
    /// Panics यदि नई क्षमता [`usize`] से अधिक हो जाती है।
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// यह वास्तव में क्षमता में वृद्धि नहीं कर सकता है:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s की अब लंबाई 2 और क्षमता 10. है
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // चूंकि हमारे पास पहले से ही अतिरिक्त 8 क्षमता है, इसे कॉल करना ...
    /// s.reserve(8);
    ///
    /// // ... वास्तव में नहीं बढ़ता है।
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// सुनिश्चित करता है कि इस `स्ट्रिंग` की क्षमता इसकी लंबाई से `additional` बाइट बड़ी है।
    ///
    /// [`reserve`] पद्धति का उपयोग करने पर विचार करें जब तक कि आप आवंटक से पूरी तरह से बेहतर नहीं जानते।
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics यदि नई क्षमता `usize` से अधिक हो जाती है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// यह वास्तव में क्षमता में वृद्धि नहीं कर सकता है:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s की अब लंबाई 2 और क्षमता 10. है
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // चूंकि हमारे पास पहले से ही अतिरिक्त 8 क्षमता है, इसे कॉल करना ...
    /// s.reserve_exact(8);
    ///
    /// // ... वास्तव में नहीं बढ़ता है।
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// दिए गए `String` में कम से कम `additional` अधिक तत्वों को सम्मिलित करने के लिए क्षमता आरक्षित करने का प्रयास करता है।
    /// बार-बार पुन: आवंटन से बचने के लिए संग्रह अधिक स्थान आरक्षित कर सकता है।
    /// `reserve` को कॉल करने के बाद, क्षमता `self.len() + additional` से अधिक या उसके बराबर होगी।
    /// अगर क्षमता पहले से ही पर्याप्त है तो कुछ नहीं करता।
    ///
    /// # Errors
    ///
    /// यदि क्षमता ओवरफ्लो हो जाती है, या आवंटक विफलता की रिपोर्ट करता है, तो एक त्रुटि वापस कर दी जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // मेमोरी को प्री-रिजर्व करें, अगर हम नहीं कर सकते हैं तो बाहर निकलें
    ///     output.try_reserve(data.len())?;
    ///
    ///     // अब हम जानते हैं कि यह हमारे जटिल कार्य के बीच में OOM नहीं कर सकता
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// दिए गए `String` में बिल्कुल `additional` अधिक तत्वों को सम्मिलित करने के लिए न्यूनतम क्षमता आरक्षित करने का प्रयास करता है।
    ///
    /// `reserve_exact` को कॉल करने के बाद, क्षमता `self.len() + additional` से अधिक या उसके बराबर होगी।
    /// अगर क्षमता पहले से ही पर्याप्त है तो कुछ भी नहीं करता है।
    ///
    /// ध्यान दें कि आवंटक संग्रह को अनुरोध से अधिक स्थान दे सकता है।
    /// इसलिए, क्षमता को ठीक न्यूनतम होने पर भरोसा नहीं किया जा सकता है।
    /// `reserve` को प्राथमिकता दें यदि future सम्मिलन अपेक्षित हैं।
    ///
    /// # Errors
    ///
    /// यदि क्षमता ओवरफ्लो हो जाती है, या आवंटक विफलता की रिपोर्ट करता है, तो एक त्रुटि वापस कर दी जाती है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // मेमोरी को प्री-रिजर्व करें, अगर हम नहीं कर सकते हैं तो बाहर निकलें
    ///     output.try_reserve(data.len())?;
    ///
    ///     // अब हम जानते हैं कि यह हमारे जटिल कार्य के बीच में OOM नहीं कर सकता
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// इस `String` की लंबाई से मेल खाने की क्षमता को सिकोड़ता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// इस `String` की क्षमता को निचली सीमा के साथ सिकोड़ता है।
    ///
    /// क्षमता कम से कम लंबाई और आपूर्ति मूल्य दोनों जितनी बड़ी रहेगी।
    ///
    ///
    /// यदि वर्तमान क्षमता निचली सीमा से कम है, तो यह नो-ऑप है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// दिए गए [`char`] को इस `String` के अंत में जोड़ता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// इस `स्ट्रिंग` की सामग्री का एक बाइट टुकड़ा देता है।
    ///
    /// इस विधि का विलोम [`from_utf8`] है।
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// इस `String` को निर्दिष्ट लंबाई तक छोटा करता है।
    ///
    /// यदि `new_len` स्ट्रिंग की वर्तमान लंबाई से अधिक है, तो इसका कोई प्रभाव नहीं पड़ता है।
    ///
    ///
    /// ध्यान दें कि इस पद्धति का स्ट्रिंग की आवंटित क्षमता पर कोई प्रभाव नहीं पड़ता है
    ///
    /// # Panics
    ///
    /// Panics यदि `new_len` [`char`] सीमा पर स्थित नहीं है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// स्ट्रिंग बफ़र से अंतिम वर्ण निकालता है और उसे वापस करता है।
    ///
    /// यदि यह `String` खाली है तो [`None`] लौटाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// इस `String` से एक बाइट स्थिति में एक [`char`] को हटाता है और उसे वापस करता है।
    ///
    /// यह एक *O*(*n*) ऑपरेशन है, क्योंकि इसके लिए बफर में प्रत्येक तत्व को कॉपी करने की आवश्यकता होती है।
    ///
    /// # Panics
    ///
    /// Panics यदि `idx` `स्ट्रिंग` की लंबाई से बड़ा या उसके बराबर है, या यदि यह [`char`] सीमा पर नहीं है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String` में पैटर्न `pat` के सभी मिलान निकालें।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// मिलानों का पता लगाया जाएगा और उन्हें पुनरावृत्त रूप से हटा दिया जाएगा, इसलिए ऐसे मामलों में जहां पैटर्न ओवरलैप होते हैं, केवल पहला पैटर्न हटा दिया जाएगा:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // सुरक्षा: प्रारंभ और अंत utf8 बाइट सीमाओं पर होगा
        // खोजकर्ता डॉक्स
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// केवल विधेय द्वारा निर्दिष्ट वर्णों को बनाए रखता है।
    ///
    /// दूसरे शब्दों में, सभी वर्णों को हटा दें `c` जैसे कि `f(c)` `false` लौटाता है।
    /// यह विधि जगह पर काम करती है, प्रत्येक वर्ण को मूल क्रम में ठीक एक बार देखती है, और बनाए गए वर्णों के क्रम को संरक्षित करती है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// एक इंडेक्स की तरह बाहरी स्थिति को ट्रैक करने के लिए सटीक ऑर्डर उपयोगी हो सकता है।
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // idx को अगले वर्ण की ओर इंगित करें
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// इस `String` में एक बाइट स्थिति में एक वर्ण सम्मिलित करता है।
    ///
    /// यह एक *O*(*n*) ऑपरेशन है क्योंकि इसे बफर में प्रत्येक तत्व की प्रतिलिपि बनाने की आवश्यकता होती है।
    ///
    /// # Panics
    ///
    /// Panics यदि `idx` `स्ट्रिंग` की लंबाई से बड़ा है, या यदि यह [`char`] सीमा पर नहीं है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// इस `String` में एक बाइट स्थिति में एक स्ट्रिंग स्लाइस डालें।
    ///
    /// यह एक *O*(*n*) ऑपरेशन है क्योंकि इसे बफर में प्रत्येक तत्व की प्रतिलिपि बनाने की आवश्यकता होती है।
    ///
    /// # Panics
    ///
    /// Panics यदि `idx` `स्ट्रिंग` की लंबाई से बड़ा है, या यदि यह [`char`] सीमा पर नहीं है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// इस `String` की सामग्री के लिए एक परिवर्तनशील संदर्भ देता है।
    ///
    /// # Safety
    ///
    /// यह फ़ंक्शन असुरक्षित है क्योंकि यह जाँच नहीं करता है कि इसमें दिए गए बाइट मान्य UTF-8 हैं।
    /// यदि इस बाधा का उल्लंघन किया जाता है, तो यह `String` के future उपयोगकर्ताओं के साथ मेमोरी असुरक्षितता की समस्या पैदा कर सकता है, क्योंकि बाकी मानक लाइब्रेरी मानती है कि `स्ट्रिंग` वैध UTF-8 हैं।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// इस `String` की लंबाई बाइट्स में लौटाता है, न कि [`char`] s या ग्रैफेम्स में।
    /// दूसरे शब्दों में, यह वह नहीं हो सकता है जिसे मनुष्य स्ट्रिंग की लंबाई मानता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// यदि इस `String` की लंबाई शून्य है, और अन्यथा `false` है, तो `true` लौटाता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// दिए गए बाइट इंडेक्स पर स्ट्रिंग को दो भागों में विभाजित करता है।
    ///
    /// एक नया आवंटित `String` देता है।
    /// `self` बाइट्स `[0, at)` हैं, और लौटाए गए `String` में बाइट्स `[at, len)` हैं।
    /// `at` UTF-8 कोड बिंदु की सीमा पर होना चाहिए।
    ///
    /// ध्यान दें कि `self` की क्षमता नहीं बदलती है।
    ///
    /// # Panics
    ///
    /// Panics यदि `at` `UTF-8` कोड बिंदु सीमा पर नहीं है, या यदि यह स्ट्रिंग के अंतिम कोड बिंदु से परे है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// सभी सामग्री को हटाते हुए, इस `String` को छोटा करता है।
    ///
    /// जबकि इसका मतलब है कि `String` की लंबाई शून्य होगी, यह इसकी क्षमता को नहीं छूता है।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// एक ड्रेनिंग इटरेटर बनाता है जो `String` में निर्दिष्ट सीमा को हटा देता है और हटाए गए `chars` को उत्पन्न करता है।
    ///
    ///
    /// Note: तत्व श्रेणी को हटा दिया जाता है, भले ही इटरेटर का अंत तक उपभोग न किया जाए।
    ///
    /// # Panics
    ///
    /// Panics यदि प्रारंभिक बिंदु या अंत बिंदु [`char`] सीमा पर नहीं है, या यदि वे सीमा से बाहर हैं।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // स्ट्रिंग से β तक की सीमा को हटा दें
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // एक पूरी श्रृंखला स्ट्रिंग को साफ़ करती है
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // मेमोरी सुरक्षा
        //
        // Drain के स्ट्रिंग संस्करण में vector संस्करण की स्मृति सुरक्षा समस्याएँ नहीं हैं।
        // डेटा सिर्फ सादा बाइट्स है।
        // क्योंकि ड्रॉप में रेंज रिमूवल होता है, अगर Drain इटरेटर लीक हो जाता है, तो रिमूवल नहीं होगा।
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // एक साथ दो उधार लें।
        // &mut स्ट्रिंग को ड्रॉप में पुनरावृति समाप्त होने तक एक्सेस नहीं किया जाएगा।
        let self_ptr = self as *mut _;
        // सुरक्षा: `slice::range` और `is_char_boundary` उचित सीमा जांच करते हैं।
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// स्ट्रिंग में निर्दिष्ट श्रेणी को हटाता है, और इसे दिए गए स्ट्रिंग से बदल देता है।
    /// दी गई स्ट्रिंग को सीमा के समान लंबाई की आवश्यकता नहीं है।
    ///
    /// # Panics
    ///
    /// Panics यदि प्रारंभिक बिंदु या अंत बिंदु [`char`] सीमा पर नहीं है, या यदि वे सीमा से बाहर हैं।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // सीमा को तब तक बदलें जब तक कि स्ट्रिंग से β न हो
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // मेमोरी सुरक्षा
        //
        // रिप्लेसमेंट_रेंज में vector स्प्लिस की मेमोरी सुरक्षा के मुद्दे नहीं हैं।
        // vector संस्करण का।डेटा सिर्फ सादा बाइट्स है।

        // चेतावनी: इस चर को इनलाइन करना गलत होगा (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // चेतावनी: इस चर को इनलाइन करना गलत होगा (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` का फिर से उपयोग करना खराब होगा (#81138) हम मानते हैं कि `range` द्वारा रिपोर्ट की गई सीमाएं वही रहती हैं, लेकिन कॉल के बीच एक प्रतिकूल कार्यान्वयन बदल सकता है
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// इस `String` को एक [`बॉक्स`]`<`[`str`]`>` में बदल देता है।
    ///
    /// यह किसी भी अतिरिक्त क्षमता को गिरा देगा।
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// [`u8`] s बाइट्स का एक टुकड़ा लौटाता है जिसे `String` में बदलने का प्रयास किया गया था।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// // vector. में कुछ अमान्य बाइट्स
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// उन बाइट्स को लौटाता है जिन्हें `String` में बदलने का प्रयास किया गया था।
    ///
    /// आवंटन से बचने के लिए इस पद्धति का निर्माण सावधानी से किया गया है।
    /// यह बाइट्स को बाहर ले जाने में त्रुटि का उपभोग करेगा, ताकि बाइट्स की एक प्रति बनाने की आवश्यकता न हो।
    ///
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// // vector. में कुछ अमान्य बाइट्स
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// रूपांतरण विफलता के बारे में अधिक विवरण प्राप्त करने के लिए `Utf8Error` प्राप्त करें।
    ///
    /// [`std::str`] द्वारा प्रदान किया गया [`Utf8Error`] प्रकार एक त्रुटि का प्रतिनिधित्व करता है जो [`u8`] s के एक स्लाइस को [`&str`] में परिवर्तित करते समय हो सकती है।
    /// इस अर्थ में, यह `FromUtf8Error` का एक एनालॉग है।
    /// इसका उपयोग करने के बारे में अधिक जानकारी के लिए इसके दस्तावेज़ देखें।
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// // vector. में कुछ अमान्य बाइट्स
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // पहली बाइट यहाँ अमान्य है
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // चूंकि हम 'स्ट्रिंग' पर पुनरावृति कर रहे हैं, हम इटरेटर से पहली स्ट्रिंग प्राप्त करके और बाद के सभी स्ट्रिंग्स को जोड़कर कम से कम एक आवंटन से बच सकते हैं।
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // क्योंकि हम CoWs पर पुनरावृति कर रहे हैं, हम (potentially) पहले आइटम को प्राप्त करके और उसके बाद के सभी आइटमों को जोड़कर कम से कम एक आवंटन से बच सकते हैं।
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// एक सुविधा संकेत जो `&str` के लिए इम्प्लांट को दर्शाता है।
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// एक खाली `String` बनाता है।
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// दो स्ट्रिंग्स को जोड़ने के लिए `+` ऑपरेटर को लागू करता है।
///
/// यह बाईं ओर `String` का उपभोग करता है और इसके बफर का पुन: उपयोग करता है (यदि आवश्यक हो तो इसे बढ़ाना)।
/// यह एक नया `String` आवंटित करने और प्रत्येक ऑपरेशन पर संपूर्ण सामग्री की प्रतिलिपि बनाने से बचने के लिए किया जाता है, जिससे *O*(*n*^2) बार-बार संयोजन द्वारा *n*-बाइट स्ट्रिंग का निर्माण करते समय चलने का समय हो जाएगा।
///
///
/// दाहिनी ओर की डोरी केवल उधार ली गई है;इसकी सामग्री को लौटाए गए `String` में कॉपी किया गया है।
///
/// # Examples
///
/// दो `स्ट्रिंग` को जोड़ना पहले मूल्य को लेता है और दूसरा उधार लेता है:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` ले जाया गया है और अब यहां उपयोग नहीं किया जा सकता है।
/// ```
///
/// यदि आप पहले `String` का उपयोग करना जारी रखना चाहते हैं, तो आप इसे क्लोन कर सकते हैं और इसके बजाय क्लोन में जोड़ सकते हैं:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` यहाँ अभी भी मान्य है।
/// ```
///
/// `&str` स्लाइस को पहले `String` में परिवर्तित करके किया जा सकता है:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `String` में जोड़ने के लिए `+=` ऑपरेटर को लागू करता है।
///
/// इसका व्यवहार [`push_str`][String::push_str] पद्धति के समान ही है।
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] के लिए एक प्रकार का उपनाम।
///
/// यह उपनाम पश्चगामी संगतता के लिए मौजूद है, और अंततः इसे बहिष्कृत किया जा सकता है।
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// एक मान को `String` में बदलने के लिए trait।
///
/// यह trait स्वचालित रूप से किसी भी प्रकार के लिए कार्यान्वित किया जाता है जो [`Display`] trait को लागू करता है।
/// जैसे, `ToString` को सीधे लागू नहीं किया जाना चाहिए:
/// [`Display`] इसके बजाय लागू किया जाना चाहिए, और आपको `ToString` कार्यान्वयन मुफ्त में मिलता है।
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// दिए गए मान को `String` में बदलता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// इस कार्यान्वयन में, `to_string` विधि panics यदि `Display` कार्यान्वयन एक त्रुटि देता है।
/// यह गलत `Display` कार्यान्वयन को इंगित करता है क्योंकि `fmt::Write for String` कभी भी स्वयं कोई त्रुटि नहीं लौटाता है।
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // एक सामान्य दिशानिर्देश सामान्य कार्यों को इनलाइन नहीं करना है।
    // हालाँकि, इस पद्धति से `#[inline]` को हटाने से गैर-नगण्य प्रतिगमन होता है।
    // <https://github.com/rust-lang/rust/pull/74852> देखें, इसे हटाने का प्रयास करने का अंतिम प्रयास।
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str` को `String` में कनवर्ट करता है।
    ///
    /// परिणाम ढेर पर आवंटित किया जाता है।
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: परीक्षण libstd में खींचता है, जो यहां त्रुटियों का कारण बनता है
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// दिए गए बॉक्सिंग `str` स्लाइस को `String` में कनवर्ट करता है।
    /// यह उल्लेखनीय है कि `str` स्लाइस का स्वामित्व है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// दिए गए `String` को स्वामित्व वाले बॉक्सिंग `str` स्लाइस में कनवर्ट करता है।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// एक स्ट्रिंग स्लाइस को उधार के रूप में परिवर्तित करता है।
    /// कोई ढेर आवंटन नहीं किया जाता है, और स्ट्रिंग की प्रतिलिपि नहीं बनाई जाती है।
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// एक स्ट्रिंग को एक स्वामित्व वाले संस्करण में परिवर्तित करता है।
    /// कोई ढेर आवंटन नहीं किया जाता है, और स्ट्रिंग की प्रतिलिपि नहीं बनाई जाती है।
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// एक स्ट्रिंग संदर्भ को उधार के रूप में परिवर्तित करता है।
    /// कोई ढेर आवंटन नहीं किया जाता है, और स्ट्रिंग की प्रतिलिपि नहीं बनाई जाती है।
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// दिए गए `String` को vector `Vec` में कनवर्ट करता है जिसमें `u8` प्रकार के मान होते हैं।
    ///
    /// # Examples
    ///
    /// मूल उपयोग:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` के लिए एक ड्रेनिंग इटरेटर।
///
/// यह संरचना [`String`] पर [`drain`] विधि द्वारा बनाई गई है।
/// अधिक के लिए इसके दस्तावेज़ देखें।
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// विध्वंसक में&'एक म्यूट स्ट्रिंग के रूप में उपयोग किया जाएगा
    string: *mut String,
    /// हटाने के लिए भाग की शुरुआत
    start: usize,
    /// हटाने के लिए भाग का अंत
    end: usize,
    /// हटाने के लिए वर्तमान शेष सीमा
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain का प्रयोग करें।
            // "Reaffirm" panic कोड को फिर से डालने से बचने के लिए बाउंड चेक करता है।
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// इस इटरेटर की शेष (उप) स्ट्रिंग को एक स्लाइस के रूप में लौटाता है।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: असम्बद्ध AsRef स्थिर होने पर नीचे निहित है।
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str` को स्थिर करते समय असहजता।
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl<'a> AsRef<str>Drain<'a> {fn as_ref(&self)-> &str {के लिए
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl<'a> AsRef<[u8]> Drain<'a> के लिए {fn as_ref(&self)-> और [u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}