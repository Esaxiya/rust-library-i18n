#![stable(feature = "wake_trait", since = "1.51.0")]
//! अतुल्यकालिक कार्यों के साथ काम करने के लिए प्रकार और Traits।
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// एक निष्पादक पर एक कार्य को जगाने का कार्यान्वयन।
///
/// इस trait का उपयोग [`Waker`] बनाने के लिए किया जा सकता है।
/// एक निष्पादक इस trait के कार्यान्वयन को परिभाषित कर सकता है, और उस निष्पादक पर निष्पादित कार्यों को पारित करने के लिए एक वेकर बनाने के लिए इसका उपयोग कर सकता है।
///
/// यह trait [`RawWaker`] के निर्माण के लिए एक मेमोरी-सुरक्षित और एर्गोनोमिक विकल्प है।
/// यह सामान्य निष्पादक डिज़ाइन का समर्थन करता है जिसमें किसी कार्य को जगाने के लिए उपयोग किया जाने वाला डेटा [`Arc`] में संग्रहीत होता है।
/// कुछ निष्पादक (विशेष रूप से एम्बेडेड सिस्टम के लिए) इस एपीआई का उपयोग नहीं कर सकते हैं, यही वजह है कि [`RawWaker`] उन सिस्टम के विकल्प के रूप में मौजूद है।
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// एक मूल `block_on` फ़ंक्शन जो future लेता है और इसे वर्तमान थ्रेड पर पूरा करने के लिए चलाता है।
///
/// **Note:** यह उदाहरण सादगी के लिए शुद्धता का व्यापार करता है।
/// गतिरोध को रोकने के लिए, प्रोडक्शन-ग्रेड कार्यान्वयन को `thread::unpark` के साथ-साथ नेस्टेड इनवोकेशन के लिए इंटरमीडिएट कॉल को संभालने की भी आवश्यकता होगी।
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// एक वेकर जो बुलाए जाने पर वर्तमान धागे को जगाता है।
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// वर्तमान थ्रेड पर पूरा करने के लिए future चलाएँ।
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // future पिन करें ताकि इसे पोल किया जा सके।
///     let mut fut = Box::pin(fut);
///
///     // future को पास करने के लिए एक नया संदर्भ बनाएं।
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // future को पूरा करने के लिए चलाएँ।
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// इस कार्य को जगाओ।
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// वेकर का सेवन किए बिना इस कार्य को जगाएं।
    ///
    /// यदि कोई निष्पादक वेकर का उपभोग किए बिना जागने के सस्ते तरीके का समर्थन करता है, तो उसे इस विधि को ओवरराइड करना चाहिए।
    /// डिफ़ॉल्ट रूप से, यह [`Arc`] को क्लोन करता है और क्लोन पर [`wake`] को कॉल करता है।
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // सुरक्षा: यह सुरक्षित है क्योंकि raw_waker सुरक्षित रूप से निर्माण करता है
        // Arc. से एक RawWaker<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: RawWaker के निर्माण के लिए इस निजी फ़ंक्शन का उपयोग किया जाता है, बजाय
// यह सुनिश्चित करने के लिए कि `From<Arc<W>> for Waker` की सुरक्षा सही trait डिस्पैच पर निर्भर नहीं है, `From<Arc<W>> for RawWaker` इम्प्लांट में इसे इनलाइन करना, इसके बजाय दोनों इम्प्लांट्स इस फ़ंक्शन को सीधे और स्पष्ट रूप से कॉल करते हैं।
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // इसे क्लोन करने के लिए चाप की संदर्भ संख्या बढ़ाएँ।
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // मूल्य से जागो, आर्क को Wake::wake फ़ंक्शन में ले जाना
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // संदर्भ के अनुसार जागो, वेकर को छोड़ने से बचने के लिए मैन्युअलीड्रॉप में लपेटें
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // ड्रॉप. पर चाप की संदर्भ संख्या घटाएं
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}