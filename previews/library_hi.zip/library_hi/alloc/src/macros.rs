/// तर्कों वाला एक [`Vec`] बनाता है।
///
/// `vec!` `Vec` को सरणी अभिव्यक्तियों के समान सिंटैक्स के साथ परिभाषित करने की अनुमति देता है।
/// इस मैक्रो के दो रूप हैं:
///
/// - तत्वों की दी गई सूची वाला एक [`Vec`] बनाएं:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - किसी दिए गए तत्व और आकार से [`Vec`] बनाएं:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// ध्यान दें कि सरणी अभिव्यक्तियों के विपरीत यह सिंटैक्स उन सभी तत्वों का समर्थन करता है जो [`Clone`] को लागू करते हैं और तत्वों की संख्या स्थिर नहीं होनी चाहिए।
///
/// यह एक एक्सप्रेशन को डुप्लिकेट करने के लिए `clone` का उपयोग करेगा, इसलिए एक गैर-मानक `Clone` कार्यान्वयन वाले प्रकारों के साथ इसका उपयोग करने में सावधानी बरतनी चाहिए।
/// उदाहरण के लिए, `vec![Rc::new(1);5]` समान बॉक्सिंग पूर्णांक मान के लिए पांच संदर्भों का vector बनाएगा, न कि पांच संदर्भ स्वतंत्र रूप से बॉक्स किए गए पूर्णांकों की ओर इशारा करते हुए।
///
///
/// साथ ही, ध्यान दें कि `vec![expr; 0]` की अनुमति है, और एक खाली vector उत्पन्न करता है।
/// हालांकि, यह अभी भी `expr` का मूल्यांकन करेगा, और परिणामी मूल्य को तुरंत छोड़ देगा, इसलिए दुष्प्रभावों से सावधान रहें।
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): cfg(test) के साथ अंतर्निहित `[T]::into_vec` विधि, जो इस मैक्रो परिभाषा के लिए आवश्यक है, उपलब्ध नहीं है।
// इसके बजाय `slice::into_vec` फ़ंक्शन का उपयोग करें जो केवल cfg(test) NB के साथ उपलब्ध है, अधिक जानकारी के लिए slice.rs में slice::hack मॉड्यूल देखें।
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// रनटाइम एक्सप्रेशन के इंटरपोलेशन का उपयोग करके `String` बनाता है।
///
/// पहला तर्क `format!` प्राप्त करता है एक प्रारूप स्ट्रिंग है।यह एक स्ट्रिंग अक्षरशः होना चाहिए।फ़ॉर्मेटिंग स्ट्रिंग की शक्ति `{}` में निहित है।
///
/// `format!` को दिए गए अतिरिक्त पैरामीटर दिए गए क्रम में फ़ॉर्मेटिंग स्ट्रिंग के भीतर `{}` को प्रतिस्थापित करते हैं, जब तक कि नामित या स्थितीय पैरामीटर का उपयोग नहीं किया जाता है;अधिक जानकारी के लिए [`std::fmt`] देखें।
///
///
/// `format!` के लिए एक सामान्य उपयोग स्ट्रिंग्स का संयोजन और प्रक्षेप है।
/// स्ट्रिंग के इच्छित गंतव्य के आधार पर, [`print!`] और [`write!`] मैक्रोज़ के साथ समान सम्मेलन का उपयोग किया जाता है।
///
/// एकल मान को स्ट्रिंग में बदलने के लिए, [`to_string`] विधि का उपयोग करें।यह [`Display`] स्वरूपण trait का उपयोग करेगा।
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics यदि स्वरूपण trait कार्यान्वयन एक त्रुटि देता है।
/// यह गलत कार्यान्वयन को इंगित करता है क्योंकि `fmt::Write for String` कभी भी स्वयं कोई त्रुटि नहीं लौटाता है।
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// पैटर्न स्थिति में निदान में सुधार करने के लिए एएसटी नोड को एक अभिव्यक्ति के लिए बाध्य करें।
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}