//! आवंटन Prelude
//!
//! इस मॉड्यूल का उद्देश्य मॉड्यूल के शीर्ष पर एक ग्लोब आयात जोड़कर `alloc` crate के सामान्य रूप से उपयोग की जाने वाली वस्तुओं के आयात को कम करना है:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;