//! प्लेटफार्म निर्भर प्रकार।

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// एक स्ट्रिंग का एक मंच स्वतंत्र प्रतिनिधित्व।
/// `std` सक्षम के साथ काम करते समय `std` प्रकारों में रूपांतरण प्रदान करने के लिए सुविधा विधियों की सिफारिश की जाती है।
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// एक टुकड़ा, आमतौर पर Unix प्लेटफॉर्म पर प्रदान किया जाता है।
    Bytes(&'a [u8]),
    /// आमतौर पर Windows से वाइड स्ट्रिंग्स।
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// हानिपूर्ण `Cow<str>` में कनवर्ट करता है, आवंटित करेगा यदि `Bytes` मान्य UTF-8 नहीं है या यदि `BytesOrWideString` `Wide` है।
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// `BytesOrWideString` का `Path` प्रतिनिधित्व प्रदान करता है।
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}