//! Windows. पर dbghelp बाइंडिंग के प्रबंधन में सहायता के लिए एक मॉड्यूल
//!
//! Windows (कम से कम MSVC के लिए) पर बैकट्रेस बड़े पैमाने पर `dbghelp.dll` और इसमें शामिल विभिन्न कार्यों के माध्यम से संचालित होते हैं।
//! ये फ़ंक्शन वर्तमान में `dbghelp.dll` से स्थिर रूप से लिंक करने के बजाय *गतिशील रूप से* लोड किए गए हैं।
//! यह वर्तमान में मानक पुस्तकालय द्वारा किया जाता है (और सिद्धांत रूप में वहां आवश्यक है), लेकिन पुस्तकालय की स्थिर डीएलएल निर्भरताओं को कम करने में मदद करने का एक प्रयास है क्योंकि बैकट्रैक आमतौर पर बहुत वैकल्पिक होते हैं।
//!
//! कहा जा रहा है, `dbghelp.dll` लगभग हमेशा Windows पर सफलतापूर्वक लोड होता है।
//!
//! ध्यान दें कि चूंकि हम इस सभी समर्थन को गतिशील रूप से लोड कर रहे हैं, हम वास्तव में `winapi` में कच्ची परिभाषाओं का उपयोग नहीं कर सकते हैं, बल्कि हमें फ़ंक्शन पॉइंटर प्रकारों को स्वयं परिभाषित करने और उसका उपयोग करने की आवश्यकता है।
//! हम वास्तव में winapi को डुप्लिकेट करने के व्यवसाय में नहीं होना चाहते हैं, इसलिए हमारे पास एक Cargo फीचर `verify-winapi` है जो दावा करता है कि सभी बाइंडिंग Winapi से मेल खाते हैं और यह सुविधा CI पर सक्षम है।
//!
//! अंत में, आप यहां ध्यान देंगे कि `dbghelp.dll` के लिए dll को कभी भी अनलोड नहीं किया जाता है, और यह वर्तमान में जानबूझकर किया गया है।
//! सोच यह है कि हम इसे विश्व स्तर पर कैश कर सकते हैं और एपीआई को कॉल के बीच इसका उपयोग कर सकते हैं, महंगे loads/unloads से बच सकते हैं।
//! यदि यह रिसाव डिटेक्टरों के लिए एक समस्या है या ऐसा कुछ है तो हम वहां पहुंचने पर पुल को पार कर सकते हैं।
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// `SymGetOptions` और `SymSetOptions` के आसपास काम करें जो कि winapi में ही मौजूद नहीं है।
// अन्यथा इसका उपयोग केवल तब किया जाता है जब हम winapi के खिलाफ डबल-चेकिंग प्रकार होते हैं।
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // अभी तक winapi में परिभाषित नहीं है
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // इसे winapi में परिभाषित किया गया है, लेकिन यह गलत है (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // अभी तक winapi में परिभाषित नहीं है
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// इस मैक्रो का उपयोग `Dbghelp` संरचना को परिभाषित करने के लिए किया जाता है जिसमें आंतरिक रूप से सभी फ़ंक्शन पॉइंटर्स होते हैं जिन्हें हम लोड कर सकते हैं।
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` के लिए लोड किया गया DLL
            dll: HMODULE,

            // प्रत्येक फ़ंक्शन के लिए प्रत्येक फ़ंक्शन पॉइंटर जिसका हम उपयोग कर सकते हैं
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // प्रारंभ में हमने डीएलएल लोड नहीं किया है
            dll: 0 as *mut _,
            // प्रारंभ में सभी कार्यों को यह कहने के लिए शून्य पर सेट किया गया है कि उन्हें गतिशील रूप से लोड करने की आवश्यकता है।
            //
            $($name: 0,)*
        };

        // प्रत्येक फ़ंक्शन प्रकार के लिए सुविधा टाइपिफ़।
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` खोलने का प्रयास।
            /// यदि यह काम करता है तो सफलता लौटाता है या `LoadLibraryW` विफल होने पर त्रुटि देता है।
            ///
            /// Panics अगर पुस्तकालय पहले ही लोड हो चुका है।
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // प्रत्येक विधि के लिए फ़ंक्शन जिसका हम उपयोग करना चाहते हैं।
            // जब कॉल किया जाता है तो यह कैश्ड फ़ंक्शन पॉइंटर को पढ़ेगा या इसे लोड करेगा और लोड किए गए मान को वापस कर देगा।
            // सफल होने के लिए भार का दावा किया जाता है।
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // dbghelp फ़ंक्शन को संदर्भित करने के लिए क्लीनअप लॉक का उपयोग करने के लिए सुविधा प्रॉक्सी।
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// इस crate से `dbghelp` API फ़ंक्शन को एक्सेस करने के लिए आवश्यक सभी समर्थन प्रारंभ करें।
///
///
/// ध्यान दें कि यह फ़ंक्शन **सुरक्षित** है, आंतरिक रूप से इसका अपना सिंक्रनाइज़ेशन है।
/// यह भी ध्यान दें कि इस फ़ंक्शन को कई बार पुनरावर्ती रूप से कॉल करना सुरक्षित है।
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // पहली चीज जो हमें करने की ज़रूरत है वह है इस फ़ंक्शन को सिंक्रनाइज़ करना।इसे अन्य थ्रेड्स से समवर्ती रूप से या एक थ्रेड के भीतर पुनरावर्ती रूप से कहा जा सकता है।
        // ध्यान दें कि यह उससे कहीं अधिक कठिन है क्योंकि हम यहां जो उपयोग कर रहे हैं, `dbghelp`,*भी* को इस प्रक्रिया में अन्य सभी कॉलर्स के साथ `dbghelp` के साथ सिंक्रनाइज़ करने की आवश्यकता है।
        //
        // आम तौर पर एक ही प्रक्रिया में `dbghelp` पर वास्तव में कई कॉल नहीं होते हैं और हम शायद सुरक्षित रूप से यह मान सकते हैं कि केवल हम ही इसे एक्सेस कर रहे हैं।
        // हालांकि, एक प्राथमिक अन्य उपयोगकर्ता है जिसके बारे में हमें चिंता करने की ज़रूरत है, जो खुद विडंबना है, लेकिन मानक पुस्तकालय में।
        // Rust मानक पुस्तकालय बैकट्रेस समर्थन के लिए इस crate पर निर्भर करता है, और यह crate भी crates.io पर मौजूद है।
        // इसका मतलब यह है कि यदि मानक पुस्तकालय panic बैकट्रेस प्रिंट कर रहा है तो यह crates.io से आने वाले इस crate के साथ दौड़ सकता है, जिससे segfaults हो सकता है।
        //
        // इस सिंक्रनाइज़ेशन समस्या को हल करने में सहायता के लिए हम यहां एक विंडोज़-विशिष्ट चाल को नियोजित करते हैं (आखिरकार, सिंक्रनाइज़ेशन के बारे में विंडोज़-विशिष्ट प्रतिबंध)।
        // हम इस कॉल की सुरक्षा के लिए म्यूटेक्स नाम का एक *सत्र-स्थानीय* बनाते हैं।
        // यहाँ इरादा यह है कि मानक पुस्तकालय और इस crate को यहाँ सिंक्रनाइज़ करने के लिए Rust-स्तरीय API साझा करने की आवश्यकता नहीं है, बल्कि यह सुनिश्चित करने के लिए पर्दे के पीछे काम कर सकते हैं कि वे एक दूसरे के साथ सिंक्रनाइज़ कर रहे हैं।
        //
        // इस तरह जब इस फ़ंक्शन को मानक पुस्तकालय के माध्यम से या crates.io के माध्यम से बुलाया जाता है तो हम सुनिश्चित हो सकते हैं कि वही म्यूटेक्स प्राप्त किया जा रहा है।
        //
        // तो बस इतना ही कहना है कि पहली चीज जो हम यहां करते हैं वह यह है कि हम परमाणु रूप से एक `HANDLE` बनाते हैं जो कि Windows पर एक नामित म्यूटेक्स है।
        // हम इस फ़ंक्शन को विशेष रूप से साझा करने वाले अन्य थ्रेड्स के साथ थोड़ा सिंक्रनाइज़ करते हैं और यह सुनिश्चित करते हैं कि इस फ़ंक्शन के प्रति उदाहरण केवल एक हैंडल बनाया जाए।
        // ध्यान दें कि वैश्विक में संग्रहीत होने के बाद हैंडल कभी बंद नहीं होता है।
        //
        // जब हम वास्तव में लॉक हो जाते हैं तो हम इसे आसानी से प्राप्त कर लेते हैं, और हमारे द्वारा दिया गया `Init` हैंडल अंततः इसे छोड़ने के लिए जिम्मेदार होगा।
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // ठीक है, भई!अब जबकि हम सभी सुरक्षित रूप से सिंक्रनाइज़ हो गए हैं, आइए वास्तव में सब कुछ संसाधित करना शुरू करें।
        // सबसे पहले हमें यह सुनिश्चित करने की आवश्यकता है कि `dbghelp.dll` वास्तव में इस प्रक्रिया में लोड है।
        // स्थिर निर्भरता से बचने के लिए हम इसे गतिशील रूप से करते हैं।
        // यह ऐतिहासिक रूप से अजीब लिंकिंग मुद्दों के आसपास काम करने के लिए किया गया है और इसका उद्देश्य बायनेरिज़ को थोड़ा अधिक पोर्टेबल बनाना है क्योंकि यह काफी हद तक सिर्फ एक डिबगिंग उपयोगिता है।
        //
        //
        // `dbghelp.dll` खोलने के बाद हमें इसमें कुछ इनिशियलाइज़ेशन फ़ंक्शंस को कॉल करने की आवश्यकता होती है, और इसका विवरण नीचे दिया गया है।
        // हालांकि, हम इसे केवल एक बार करते हैं, इसलिए हमारे पास एक वैश्विक बूलियन है जो दर्शाता है कि हम अभी तक कर चुके हैं या नहीं।
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // सुनिश्चित करें कि `SYMOPT_DEFERRED_LOADS` ध्वज सेट है, क्योंकि इस बारे में MSVC के स्वयं के दस्तावेज़ों के अनुसार: "This is the fastest, most efficient way to use the symbol handler.", तो चलिए ऐसा करते हैं!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // असल में एमएसवीसी के साथ प्रतीकों को प्रारंभ करें।ध्यान दें कि यह विफल हो सकता है, लेकिन हम इसे अनदेखा करते हैं।
        // इसके लिए पूर्व कला का एक टन नहीं है, लेकिन एलएलवीएम आंतरिक रूप से यहां वापसी मूल्य को अनदेखा करता है और एलएलवीएम में सेनिटाइज़र पुस्तकालयों में से एक एक डरावनी चेतावनी प्रिंट करता है यदि यह विफल रहता है लेकिन मूल रूप से लंबे समय तक इसे अनदेखा करता है।
        //
        //
        // Rust के लिए एक मामला यह है कि मानक पुस्तकालय और crates.io पर यह crate दोनों `SymInitializeW` के लिए प्रतिस्पर्धा करना चाहते हैं।
        // मानक पुस्तकालय ऐतिहासिक रूप से अधिकांश समय सफाई शुरू करना चाहता था, लेकिन अब जब यह इस crate का उपयोग कर रहा है तो इसका मतलब है कि किसी को पहले प्रारंभ करना होगा और दूसरा उस प्रारंभिकरण को उठाएगा।
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}