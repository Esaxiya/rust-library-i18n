//! libunwind/gcc_s/etc API का उपयोग करके बैकट्रेस समर्थन।
//!
//! इस मॉड्यूल में libunwind-style API का उपयोग करके स्टैक को खोलने की क्षमता है।
//! ध्यान दें कि लिबुनविंड-जैसे एपीआई के कार्यान्वयन का एक पूरा समूह है, और यह सिर्फ उन सभी के साथ संगत होने की बजाय एक बार में संगत होने की कोशिश कर रहा है।
//!
//!
//! लिबुनविंड एपीआई `_Unwind_Backtrace` द्वारा संचालित है और व्यवहार में एक बैकट्रेस उत्पन्न करने में बहुत विश्वसनीय है।
//! यह पूरी तरह से स्पष्ट नहीं है कि यह कैसे करता है (फ्रेम पॉइंटर्स? eh_frame जानकारी? दोनों?) लेकिन ऐसा लगता है कि यह काम करता है!
//!
//! इस मॉड्यूल की अधिकांश जटिलता लिबुनविंड कार्यान्वयन में विभिन्न प्लेटफ़ॉर्म अंतरों को संभाल रही है।
//! अन्यथा यह एक बहुत ही सरल Rust है जो libunwind API के लिए बाध्यकारी है।
//!
//! यह वर्तमान में सभी गैर-विंडोज प्लेटफॉर्म के लिए डिफ़ॉल्ट अनइंडिंग एपीआई है।
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// कच्चे लिबुनविंड पॉइंटर के साथ इसे केवल पढ़ने योग्य थ्रेडसेफ फैशन में ही एक्सेस किया जाना चाहिए, इसलिए यह `Sync` है।
// `Clone` के माध्यम से अन्य थ्रेड्स को भेजते समय हम हमेशा एक ऐसे संस्करण पर स्विच करते हैं जो इंटीरियर पॉइंटर्स को बरकरार नहीं रखता है, इसलिए हमें `Send` भी होना चाहिए।
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // ऐसा लगता है कि OSX पर `_Unwind_FindEnclosingFunction` एक पॉइंटर लौटाता है... कुछ ऐसा जो अस्पष्ट है।
        // यह निश्चित रूप से किसी भी कारण से हमेशा संलग्न कार्य नहीं होता है।
        // यह मेरे लिए पूरी तरह से स्पष्ट नहीं है कि यहां क्या हो रहा है, इसलिए इसे अभी के लिए निराशा करें और हमेशा आईपी वापस करें।
        //
        // ध्यान दें कि इस खंड के कारण OSX पर `skip_inner_frames.rs` परीक्षण छोड़ दिया गया है, और यदि यह तय हो गया है कि सिद्धांत में परीक्षण OSX पर चलाया जा सकता है!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// बैकट्रेस के लिए उपयोग किए जाने वाले लाइब्रेरी इंटरफ़ेस को खोलना
///
/// ध्यान दें कि मृत कोड की अनुमति है क्योंकि यहां केवल बाइंडिंग हैं आईओएस उन सभी का उपयोग नहीं करता है लेकिन अधिक प्लेटफ़ॉर्म-विशिष्ट कॉन्फ़िगरेशन जोड़ने से कोड बहुत अधिक प्रदूषित होता है
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // केवल एआरएम ईएबीआई द्वारा उपयोग किया जाता है
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // आईओएस पर कोई देशी _Unwind_Backtrace नहीं
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // GCC 4.2.0 के बाद से उपलब्ध, हमारे उद्देश्य के लिए ठीक होना चाहिए
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // यह फ़ंक्शन एक मिथ्या नाम है: इस फ़्रेम का कैननिकल फ़्रेम पता (उर्फ कॉलर फ़्रेम का SP) प्राप्त करने के बजाय यह इस फ़्रेम का SP लौटाता है।
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x एक पक्षपाती CFA मान का उपयोग करता है, इसलिए हमें _Unwind_GetCFA पर निर्भर होने के बजाय स्टैक पॉइंटर रजिस्टर (%r15) प्राप्त करने के लिए _Unwind_GetGR का उपयोग करने की आवश्यकता है।
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // android और आर्म पर, फ़ंक्शन `_Unwind_GetIP` और अन्य का एक गुच्छा मैक्रोज़ हैं, इसलिए हम मैक्रोज़ के विस्तार वाले फ़ंक्शंस को परिभाषित करते हैं।
    //
    //
    // TODO: हेडर फ़ाइल से लिंक करें जो इन मैक्रोज़ को परिभाषित करता है, यदि आप इसे पा सकते हैं।
    // (मैं, फिट्जजेन, हेडर फ़ाइल नहीं ढूंढ सकता है कि इनमें से कुछ मैक्रो विस्तार मूल रूप से उधार लिए गए थे।)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 बांह पर ढेर सूचक है।
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // यह फ़ंक्शन Android या ARM/Linux पर भी मौजूद नहीं है, इसलिए इसे नो-ऑप बनाएं।
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}