use core::ffi::c_void;
use core::fmt;

/// वर्तमान कॉल-स्टैक का निरीक्षण करता है, सभी सक्रिय फ़्रेमों को एक स्टैक ट्रेस की गणना करने के लिए प्रदान किए गए क्लोजर में पास करता है।
///
/// यह फ़ंक्शन किसी प्रोग्राम के लिए स्टैक ट्रेस की गणना में इस लाइब्रेरी का वर्कहॉर्स है।दिया गया क्लोजर `cb` एक `Frame` का यील्ड इंस्टेंस है जो स्टैक पर उस कॉल फ्रेम के बारे में जानकारी का प्रतिनिधित्व करता है।
/// क्लोजर को टॉप-डाउन फैशन में फ्रेम दिया जाता है (सबसे हाल ही में फ़ंक्शन पहले कहा जाता है)।
///
/// क्लोजर का रिटर्न वैल्यू इस बात का संकेत है कि बैकट्रेस जारी रहना चाहिए या नहीं।`false` का रिटर्न वैल्यू बैकट्रेस को समाप्त कर देगा और तुरंत वापस आ जाएगा।
///
/// एक बार `Frame` प्राप्त हो जाने के बाद आप `ip` (निर्देश सूचक) या प्रतीक पते को `Symbol` में बदलने के लिए `backtrace::resolve` को कॉल करना चाहेंगे, जिसके माध्यम से नाम और/या फ़ाइल नाम/लाइन नंबर सीखा जा सकता है।
///
///
/// ध्यान दें कि यह अपेक्षाकृत निम्न-स्तरीय फ़ंक्शन है और यदि आप चाहते हैं, उदाहरण के लिए, बाद में निरीक्षण करने के लिए बैकट्रेस कैप्चर करें, तो `Backtrace` प्रकार अधिक उपयुक्त हो सकता है।
///
/// # आवश्यक सुविधाएँ
///
/// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
///
/// # Panics
///
/// यह फ़ंक्शन panic कभी नहीं करने का प्रयास करता है, लेकिन यदि `cb` panics प्रदान करता है तो कुछ प्लेटफ़ॉर्म प्रक्रिया को निरस्त करने के लिए एक डबल panic को बाध्य करेंगे।
/// कुछ प्लेटफ़ॉर्म एक सी लाइब्रेरी का उपयोग करते हैं जो आंतरिक रूप से कॉलबैक का उपयोग करता है जिसे अनवाउंड नहीं किया जा सकता है, इसलिए `cb` से घबराने से प्रक्रिया निरस्त हो सकती है।
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // बैकट्रैक जारी रखें
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace` के समान, केवल असुरक्षित है क्योंकि यह अनसिंक्रनाइज़्ड है।
///
/// इस फ़ंक्शन में सिंक्रोनाइज़ेशन गारंटी नहीं है, लेकिन यह तब उपलब्ध होता है जब इस crate की `std` सुविधा को संकलित नहीं किया जाता है।
/// अधिक दस्तावेज़ीकरण और उदाहरणों के लिए `trace` फ़ंक्शन देखें।
///
/// # Panics
///
/// `cb` घबराहट पर चेतावनियों के लिए `trace` पर जानकारी देखें।
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// एक बैकट्रेस के एक फ्रेम का प्रतिनिधित्व करने वाला एक trait, इस crate के `trace` फ़ंक्शन के लिए निकला।
///
/// ट्रेसिंग फ़ंक्शन के बंद होने से फ़्रेम प्राप्त होंगे, और फ़्रेम को वस्तुतः भेजा जाता है क्योंकि अंतर्निहित कार्यान्वयन हमेशा रनटाइम तक ज्ञात नहीं होता है।
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// इस फ्रेम का वर्तमान निर्देश सूचक लौटाता है।
    ///
    /// यह आम तौर पर फ्रेम में निष्पादित करने के लिए अगला निर्देश है, लेकिन सभी कार्यान्वयन इसे 100% सटीकता के साथ सूचीबद्ध नहीं करते हैं (लेकिन यह आमतौर पर बहुत करीब है)।
    ///
    ///
    /// इसे प्रतीक नाम में बदलने के लिए इस मान को `backtrace::resolve` पर पास करने की अनुशंसा की जाती है।
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// इस फ्रेम का वर्तमान स्टैक पॉइंटर लौटाता है।
    ///
    /// इस मामले में कि बैकएंड इस फ्रेम के लिए स्टैक पॉइंटर को पुनर्प्राप्त नहीं कर सकता है, एक शून्य सूचक वापस कर दिया जाता है।
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// इस फ़ंक्शन के फ़्रेम का प्रारंभिक प्रतीक पता देता है।
    ///
    /// यह `ip` द्वारा फ़ंक्शन की शुरुआत में दिए गए निर्देश सूचक को वापस करने का प्रयास करेगा, उस मान को वापस कर देगा।
    ///
    /// हालांकि, कुछ मामलों में, बैकएंड इस फ़ंक्शन से केवल `ip` लौटाएगा।
    ///
    /// यदि ऊपर दिए गए `ip` पर `backtrace::resolve` विफल हो जाता है, तो लौटाए गए मान का कभी-कभी उपयोग किया जा सकता है।
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// उस मॉड्यूल का मूल पता लौटाता है जिससे फ्रेम संबंधित है।
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // यह सुनिश्चित करने के लिए पहले आने की जरूरत है कि मिरी मेजबान मंच पर प्राथमिकता लेता है
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // केवल dbghelp प्रतीक में उपयोग किया जाता है
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}