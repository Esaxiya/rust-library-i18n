use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr एक कॉलबैक लेता है जो प्रक्रिया में लिंक किए गए प्रत्येक DSO के लिए एक dl_phdr_info पॉइंटर प्राप्त करेगा।
    // dl_iterate_phdr यह भी सुनिश्चित करता है कि डायनामिक लिंकर पुनरावृत्ति के शुरू से अंत तक लॉक है।
    // यदि कॉलबैक एक गैर-शून्य मान देता है तो पुनरावृत्ति जल्दी समाप्त हो जाती है।
    // 'data' प्रत्येक कॉल पर कॉलबैक के तीसरे तर्क के रूप में पारित किया जाएगा।
    // 'size' dl_phdr_info का आकार देता है।
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// हमें बिल्ड आईडी और कुछ बुनियादी प्रोग्राम हेडर डेटा को पार्स करने की आवश्यकता है जिसका अर्थ है कि हमें ईएलएफ स्पेक से भी कुछ सामान चाहिए।
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// अब हमें फ्यूशिया के वर्तमान डायनेमिक लिंकर द्वारा उपयोग किए जाने वाले dl_phdr_info प्रकार की संरचना, बिट के लिए बिट को दोहराना होगा।
// क्रोमियम में यह ABI सीमा के साथ-साथ क्रैशपैड भी है।
// अंततः हम इन मामलों को योगिनी-खोज का उपयोग करने के लिए स्थानांतरित करना चाहते हैं, लेकिन हमें इसे एसडीके में प्रदान करना होगा और यह अभी तक नहीं किया गया है।
//
// इस प्रकार हम (और वे) इस पद्धति का उपयोग करने के लिए फंस गए हैं जो फ्यूशिया libc के साथ एक तंग युग्मन करता है।
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // हमारे पास यह जानने का कोई तरीका नहीं है कि e_phoff और e_phnum मान्य हैं या नहीं।
    // libc को हमारे लिए यह सुनिश्चित करना चाहिए, हालांकि यहां एक टुकड़ा बनाना सुरक्षित है।
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr लक्ष्य आर्किटेक्चर की अंतहीनता में 64-बिट ELF प्रोग्राम हेडर का प्रतिनिधित्व करता है।
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr एक मान्य ELF प्रोग्राम हेडर और उसकी सामग्री का प्रतिनिधित्व करता है।
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // हमारे पास यह जांचने का कोई तरीका नहीं है कि p_addr या p_memsz मान्य हैं या नहीं।
    // फ्यूशिया का libc पहले नोटों को पार्स करता है, हालांकि यहां होने के कारण ये शीर्षलेख मान्य होना चाहिए।
    //
    // NoteIter को मान्य होने के लिए अंतर्निहित डेटा की आवश्यकता नहीं है, लेकिन इसके लिए सीमाओं के मान्य होने की आवश्यकता है।
    // हमें विश्वास है कि libc ने यह सुनिश्चित किया है कि हमारे यहाँ भी यही स्थिति है।
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// बिल्ड आईडी के लिए नोट प्रकार।
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr लक्ष्य की अंतहीनता में एक ELF नोट हेडर का प्रतिनिधित्व करता है।
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// नोट एक ईएलएफ नोट (शीर्षलेख + सामग्री) का प्रतिनिधित्व करता है।
// नाम को u8 स्लाइस के रूप में छोड़ दिया गया है क्योंकि यह हमेशा शून्य समाप्त नहीं होता है और rust यह जांचना आसान बनाता है कि बाइट किसी भी तरह से मेल खाते हैं।
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter आपको नोट सेगमेंट पर सुरक्षित रूप से पुनरावृति करने देता है।
// जैसे ही कोई त्रुटि होती है या कोई और नोट नहीं होते हैं, यह समाप्त हो जाता है।
// यदि आप अमान्य डेटा पर पुनरावृति करते हैं तो यह कार्य करेगा जैसे कि कोई नोट नहीं मिला।
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // यह फ़ंक्शन का एक अपरिवर्तनीय है कि दिया गया सूचक और आकार बाइट्स की एक वैध श्रेणी को दर्शाता है जिसे सभी पढ़ा जा सकता है।
    // इन बाइट्स की सामग्री कुछ भी हो सकती है लेकिन सुरक्षित होने के लिए सीमा मान्य होनी चाहिए।
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to 'x' को 'to'-बाइट संरेखण में संरेखित करता है यह मानते हुए कि 'to' 2 की शक्ति है।
// यह C/C++ ELF पार्सिंग कोड में एक मानक पैटर्न का अनुसरण करता है जहां (x + to, 1) और -to का उपयोग किया जाता है।
// Rust आपको उपयोग को नकारने नहीं देता है इसलिए मैं उपयोग करता हूं
// इसे फिर से बनाने के लिए 2's-पूरक रूपांतरण।
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 स्लाइस (यदि मौजूद है) से संख्या बाइट्स की खपत करता है और इसके अतिरिक्त यह सुनिश्चित करता है कि अंतिम स्लाइस ठीक से संरेखित है।
// यदि या तो अनुरोधित बाइट्स की संख्या बहुत बड़ी है या पर्याप्त शेष बाइट्स मौजूद नहीं होने के कारण स्लाइस को बाद में पुन: व्यवस्थित नहीं किया जा सकता है, कोई भी वापस नहीं किया जाता है और टुकड़ा संशोधित नहीं होता है।
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// इस फ़ंक्शन में कोई वास्तविक इनवेरिएंट नहीं है, जिसे कॉल करने वाले को शायद 'bytes' को प्रदर्शन के लिए संरेखित किया जाना चाहिए (और कुछ आर्किटेक्चर शुद्धता पर) के अलावा अन्य को बनाए रखना चाहिए।
// Elf_Nhdr फ़ील्ड में मान बकवास हो सकते हैं लेकिन यह फ़ंक्शन ऐसी कोई चीज़ सुनिश्चित नहीं करता है।
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // यह तब तक सुरक्षित है जब तक पर्याप्त जगह है और हमने अभी पुष्टि की है कि ऊपर दिए गए कथन में यह असुरक्षित नहीं होना चाहिए।
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // ध्यान दें कि sice_of: :<Elf_Nhdr>() हमेशा 4-बाइट संरेखित होता है।
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // जांचें कि क्या हम अंत तक पहुंच गए हैं।
        if self.base.len() == 0 || self.error {
            return None;
        }
        // हम एक nhdr को ट्रांसम्यूट करते हैं लेकिन हम परिणामी संरचना पर ध्यान से विचार करते हैं।
        // हम namez या descsz पर भरोसा नहीं करते हैं और हम प्रकार के आधार पर कोई असुरक्षित निर्णय नहीं लेते हैं।
        //
        // इसलिए अगर हम पूरा कचरा बाहर निकाल भी दें तो भी हमें सुरक्षित रहना चाहिए।
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// इंगित करता है कि एक खंड निष्पादन योग्य है।
const PERM_X: u32 = 0b00000001;
/// इंगित करता है कि एक खंड लिखने योग्य है।
const PERM_W: u32 = 0b00000010;
/// इंगित करता है कि एक खंड पठनीय है।
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// रनटाइम पर एक ईएलएफ सेगमेंट का प्रतिनिधित्व करता है।
struct Segment {
    /// इस सेगमेंट की सामग्री का रनटाइम वर्चुअल पता देता है।
    addr: usize,
    /// इस खंड की सामग्री का स्मृति आकार देता है।
    size: usize,
    /// इस सेगमेंट का मॉड्यूल वर्चुअल एड्रेस ELF फाइल के साथ देता है।
    mod_rel_addr: usize,
    /// ELF फ़ाइल में मिली अनुमतियाँ देता है।
    /// ये अनुमतियाँ आवश्यक रूप से रनटाइम पर मौजूद अनुमतियाँ नहीं हैं।
    flags: Perm,
}

/// एक डीएसओ से सेगमेंट पर पुनरावृति करने देता है।
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// एक ईएलएफ डीएसओ (गतिशील साझा वस्तु) का प्रतिनिधित्व करता है।
/// यह प्रकार अपनी प्रतिलिपि बनाने के बजाय वास्तविक डीएसओ में संग्रहीत डेटा को संदर्भित करता है।
struct Dso<'a> {
    /// डायनामिक लिंकर हमेशा हमें एक नाम देता है, भले ही नाम खाली हो।
    /// मुख्य निष्पादन योग्य के मामले में यह नाम खाली होगा।
    /// साझा किए गए ऑब्जेक्ट के मामले में यह सोनाम होगा (देखें DT_SONAME)।
    name: &'a str,
    /// फ्यूशिया पर लगभग सभी बायनेरिज़ में बिल्ड आईडी हैं लेकिन यह सख्त आवश्यकता नहीं है।
    /// यदि कोई बिल्ड_आईडी नहीं है, तो बाद में वास्तविक ईएलएफ फ़ाइल के साथ डीएसओ जानकारी का मिलान करने का कोई तरीका नहीं है, इसलिए हमें आवश्यकता है कि प्रत्येक डीएसओ के पास यहां एक हो।
    ///
    /// बिना बिल्ड_आईडी के डीएसओ को नजरअंदाज कर दिया जाता है।
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// इस डीएसओ में सेगमेंट पर एक पुनरावर्तक देता है।
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// ये त्रुटियां प्रत्येक डीएसओ के बारे में जानकारी को पार्स करते समय उत्पन्न होने वाली समस्याओं को एन्कोड करती हैं।
///
enum Error {
    /// NameError का अर्थ है कि C शैली स्ट्रिंग को rust स्ट्रिंग में कनवर्ट करते समय एक त्रुटि हुई।
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError का अर्थ है कि हमें कोई बिल्ड आईडी नहीं मिली।
    /// यह या तो हो सकता है क्योंकि डीएसओ के पास कोई बिल्ड आईडी नहीं थी या क्योंकि बिल्ड आईडी वाला खंड विकृत था।
    ///
    BuildIDError,
}

/// डायनेमिक लिंकर द्वारा प्रक्रिया से जुड़े प्रत्येक DSO के लिए 'dso' या 'error' को कॉल करता है।
///
///
/// # Arguments
///
/// * `visitor` - एक डीएसओप्रिंटर जिसमें फ़ोरैच डीएसओ नामक ईट्स विधियों में से एक होगा।
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr सुनिश्चित करता है कि info.name एक मान्य स्थान की ओर संकेत करेगा।
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// यह फ़ंक्शन DSO में निहित सभी जानकारी के लिए Fuchsia प्रतीक चिह्न को प्रिंट करता है।
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}