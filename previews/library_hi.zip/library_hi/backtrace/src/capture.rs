use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// एक स्वामित्व और स्व-निहित बैकट्रेस का प्रतिनिधित्व।
///
/// इस संरचना का उपयोग एक कार्यक्रम में विभिन्न बिंदुओं पर एक बैकट्रेस को पकड़ने के लिए किया जा सकता है और बाद में उस समय बैकट्रेस का निरीक्षण करने के लिए उपयोग किया जाता है।
///
///
/// `Backtrace` अपने `Debug` कार्यान्वयन के माध्यम से बैकट्रेस की सुंदर-मुद्रण का समर्थन करता है।
///
/// # आवश्यक सुविधाएँ
///
/// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // यहां फ्रेम्स स्टैक के ऊपर से नीचे तक सूचीबद्ध हैं
    frames: Vec<BacktraceFrame>,
    // हम जो सूचकांक मानते हैं, वह बैकट्रेस की वास्तविक शुरुआत है, जिसमें `Backtrace::new` और `backtrace::trace` जैसे फ्रेम नहीं हैं।
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// बैकट्रेस में फ़्रेम का कैप्चर किया गया संस्करण।
///
/// इस प्रकार को `Backtrace::frames` से एक सूची के रूप में लौटाया जाता है और एक कैप्चर किए गए बैकट्रेस में एक स्टैक फ्रेम का प्रतिनिधित्व करता है।
///
/// # आवश्यक सुविधाएँ
///
/// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// बैकट्रेस में प्रतीक का कैप्चर किया गया संस्करण।
///
/// इस प्रकार को `BacktraceFrame::symbols` से एक सूची के रूप में लौटाया जाता है और बैकट्रेस में एक प्रतीक के लिए मेटाडेटा का प्रतिनिधित्व करता है।
///
/// # आवश्यक सुविधाएँ
///
/// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// एक स्वामित्व प्रतिनिधित्व लौटाते हुए, इस फ़ंक्शन के कॉलसाइट पर एक बैकट्रैक कैप्चर करता है।
    ///
    /// यह फ़ंक्शन Rust में ऑब्जेक्ट के रूप में बैकट्रेस का प्रतिनिधित्व करने के लिए उपयोगी है।इस लौटाए गए मूल्य को धागे में भेजा जा सकता है और कहीं और मुद्रित किया जा सकता है, और इस मूल्य का उद्देश्य पूरी तरह से स्वयं निहित होना है।
    ///
    /// ध्यान दें कि कुछ प्लेटफ़ॉर्म पर पूर्ण बैकट्रैक प्राप्त करना और इसे हल करना बेहद महंगा हो सकता है।
    /// यदि आपके आवेदन के लिए लागत बहुत अधिक है, तो इसके बजाय `Backtrace::new_unresolved()` का उपयोग करने की अनुशंसा की जाती है जो प्रतीक संकल्प चरण (जो आमतौर पर सबसे लंबा समय लेता है) से बचता है और इसे बाद की तारीख में स्थगित करने की अनुमति देता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // यह सुनिश्चित करना चाहते हैं कि हटाने के लिए यहां एक फ्रेम है
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new` के समान, सिवाय इसके कि यह किसी भी प्रतीक को हल नहीं करता है, यह केवल बैकट्रेस को पतों की सूची के रूप में कैप्चर करता है।
    ///
    /// बाद में इस बैकट्रेस के प्रतीकों को पढ़ने योग्य नामों में हल करने के लिए `resolve` फ़ंक्शन को कॉल किया जा सकता है।
    /// यह फ़ंक्शन मौजूद है क्योंकि रिज़ॉल्यूशन प्रक्रिया में कभी-कभी काफी समय लग सकता है जबकि कोई एक बैकट्रेस केवल शायद ही कभी मुद्रित हो सकता है।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // कोई प्रतीक नाम नहीं
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // प्रतीक नाम अब मौजूद हैं
    /// ```
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    ///
    ///
    #[inline(never)] // यह सुनिश्चित करना चाहते हैं कि हटाने के लिए यहां एक फ्रेम है
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// जब यह बैकट्रेस कैप्चर किया गया था तब से फ़्रेम लौटाता है।
    ///
    /// इस स्लाइस की पहली प्रविष्टि संभवतः फ़ंक्शन `Backtrace::new` है, और अंतिम फ़्रेम संभवतः इस बारे में कुछ है कि यह थ्रेड या मुख्य फ़ंक्शन कैसे शुरू हुआ।
    ///
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// यदि यह बैकट्रेस `new_unresolved` से बनाया गया था तो यह फ़ंक्शन बैकट्रेस में सभी पतों को उनके प्रतीकात्मक नामों में हल करेगा।
    ///
    ///
    /// यदि यह बैकट्रेस पहले हल किया गया है या `new` के माध्यम से बनाया गया है, तो यह फ़ंक्शन कुछ नहीं करता है।
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip`. के समान
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address`. के समान
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address`. के समान
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// उन प्रतीकों की सूची लौटाता है जिनसे यह फ़्रेम मेल खाता है।
    ///
    /// आम तौर पर प्रति फ्रेम केवल एक प्रतीक होता है, लेकिन कभी-कभी यदि कई कार्यों को एक फ्रेम में रेखांकित किया जाता है तो कई प्रतीकों को वापस कर दिया जाएगा।
    /// सूचीबद्ध पहला प्रतीक "innermost function" है, जबकि अंतिम प्रतीक सबसे बाहरी (अंतिम कॉलर) है।
    ///
    /// ध्यान दें कि यदि यह फ्रेम एक अनसुलझे बैकट्रेस से आया है तो यह एक खाली सूची लौटाएगा।
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name`. के समान
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr`. के समान
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename`. के समान
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno`. के समान
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno`. के समान
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // पथ प्रिंट करते समय हम cwd मौजूद होने पर स्ट्रिप करने का प्रयास करते हैं, अन्यथा हम पथ को वैसे ही प्रिंट करते हैं।
        // ध्यान दें कि हम इसे केवल लघु प्रारूप के लिए भी करते हैं, क्योंकि यदि यह भरा हुआ है तो हम संभवतः सब कुछ प्रिंट करना चाहते हैं।
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}