#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// बैकट्रैक के लिए एक फॉर्मेटर।
///
/// इस प्रकार का उपयोग बैकट्रेस को प्रिंट करने के लिए किया जा सकता है, भले ही बैकट्रेस स्वयं कहां से आए।
/// यदि आपके पास `Backtrace` प्रकार है तो इसका `Debug` कार्यान्वयन पहले से ही इस मुद्रण प्रारूप का उपयोग करता है।
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// मुद्रण की शैलियाँ जिन्हें हम प्रिंट कर सकते हैं
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// एक टेरसर बैकट्रेस प्रिंट करता है जिसमें आदर्श रूप से केवल प्रासंगिक जानकारी होती है
    Short,
    /// एक बैकट्रेस प्रिंट करता है जिसमें सभी संभावित जानकारी होती है
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// एक नया `BacktraceFmt` बनाएं जो दिए गए `fmt` को आउटपुट लिखे।
    ///
    /// `format` तर्क उस शैली को नियंत्रित करेगा जिसमें बैकट्रेस मुद्रित होता है, और `print_path` तर्क का उपयोग फ़ाइल नामों के `BytesOrWideString` उदाहरणों को मुद्रित करने के लिए किया जाएगा।
    /// यह प्रकार स्वयं फ़ाइल नामों की कोई छपाई नहीं करता है, लेकिन ऐसा करने के लिए इस कॉलबैक की आवश्यकता होती है।
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// प्रिंट किए जाने वाले बैकट्रेस के लिए एक प्रस्तावना प्रिंट करता है।
    ///
    /// बैकट्रेस को बाद में पूरी तरह से प्रतीकात्मक बनाने के लिए कुछ प्लेटफार्मों पर इसकी आवश्यकता होती है, और अन्यथा यह केवल पहली विधि होनी चाहिए जिसे आप `BacktraceFmt` बनाने के बाद कहते हैं।
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// बैकट्रेस आउटपुट में एक फ्रेम जोड़ता है।
    ///
    /// यह कमिट `BacktraceFrameFmt` का RAII उदाहरण देता है जिसका उपयोग वास्तव में एक फ्रेम को प्रिंट करने के लिए किया जा सकता है, और विनाश पर यह फ्रेम काउंटर को बढ़ा देगा।
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// बैकट्रेस आउटपुट को पूरा करता है।
    ///
    /// यह वर्तमान में एक नो-ऑप है लेकिन बैकट्रेस प्रारूपों के साथ future संगतता के लिए जोड़ा गया है।
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // future परिवर्धन के लिए अनुमति देने के लिए इस hook सहित वर्तमान में एक नो-ऑप--।
        Ok(())
    }
}

/// बैकट्रेस के सिर्फ एक फ्रेम के लिए एक फॉर्मेटर।
///
/// यह प्रकार `BacktraceFmt::frame` फ़ंक्शन द्वारा बनाया गया है।
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// इस फ्रेम फॉर्मेटर के साथ एक `BacktraceFrame` प्रिंट करता है।
    ///
    /// यह `BacktraceFrame` के भीतर सभी `BacktraceSymbol` उदाहरणों को पुनरावर्ती रूप से प्रिंट करेगा।
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// एक `BacktraceFrame` के भीतर एक `BacktraceSymbol` प्रिंट करता है।
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: यह बहुत अच्छा नहीं है कि हम कुछ भी प्रिंट नहीं करते हैं
            // गैर-utf8 फ़ाइल नामों के साथ।
            // शुक्र है कि लगभग सब कुछ utf8 है इसलिए यह बहुत बुरा नहीं होना चाहिए।
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// एक कच्चे ट्रेस किए गए `Frame` और `Symbol` को प्रिंट करता है, आमतौर पर इस crate के कच्चे कॉलबैक के भीतर से।
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// बैकट्रेस आउटपुट में एक कच्चा फ्रेम जोड़ता है।
    ///
    /// यह विधि, पिछले के विपरीत, अलग-अलग स्थानों से स्रोत होने की स्थिति में कच्चे तर्क लेती है।
    /// ध्यान दें कि इसे एक फ्रेम के लिए कई बार कहा जा सकता है।
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// कॉलम जानकारी सहित बैकट्रेस आउटपुट में एक कच्चा फ्रेम जोड़ता है।
    ///
    /// यह विधि, पिछले की तरह, अलग-अलग स्थानों से स्रोत होने की स्थिति में कच्चे तर्क लेती है।
    /// ध्यान दें कि इसे एक फ्रेम के लिए कई बार कहा जा सकता है।
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // फुकिया एक प्रक्रिया के भीतर प्रतीक करने में असमर्थ है, इसलिए इसका एक विशेष प्रारूप है जिसे बाद में प्रतीक के लिए इस्तेमाल किया जा सकता है।
        // यहां हमारे अपने प्रारूप में पतों को प्रिंट करने के बजाय प्रिंट करें।
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" फ्रेम को प्रिंट करने की कोई आवश्यकता नहीं है, इसका मूल रूप से मतलब है कि सिस्टम बैकट्रेस सुपर दूर का पता लगाने के लिए थोड़ा उत्सुक था।
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // एसजीएक्स एन्क्लेव में टीसीबी आकार को कम करने के लिए, हम प्रतीक संकल्प कार्यक्षमता को लागू नहीं करना चाहते हैं।
        // बल्कि, हम यहां पते के ऑफसेट को प्रिंट कर सकते हैं, जिसे बाद में सही कार्य के लिए मैप किया जा सकता है।
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // फ्रेम के सूचकांक के साथ-साथ फ्रेम के वैकल्पिक निर्देश सूचक को प्रिंट करें।
        // अगर हम इस फ्रेम के पहले प्रतीक से परे हैं, हालांकि हम उचित सफेद जगह प्रिंट करते हैं।
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // यदि हम एक पूर्ण बैकट्रेस हैं तो अधिक जानकारी के लिए वैकल्पिक स्वरूपण का उपयोग करते हुए, अगला प्रतीक नाम लिखें।
        // यहां हम उन प्रतीकों को भी संभालते हैं जिनका कोई नाम नहीं है,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // और अंत में, यदि उपलब्ध हों तो filename/line नंबर का प्रिंट आउट लें।
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line प्रतीक नाम के तहत लाइनों पर मुद्रित होते हैं, इसलिए खुद को राइट-अलाइन करने के लिए कुछ उपयुक्त व्हाइटस्पेस प्रिंट करें।
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // फ़ाइल नाम को प्रिंट करने के लिए हमारे आंतरिक कॉलबैक को सौंपें और फिर लाइन नंबर का प्रिंट आउट लें।
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // यदि उपलब्ध हो तो कॉलम नंबर जोड़ें।
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // हम केवल फ्रेम के पहले प्रतीक की परवाह करते हैं
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}