// अभी केवल Linux पर उपयोग किया जाता है, इसलिए मृत कोड को कहीं और अनुमति दें
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// बाइट बफ़र्स के लिए एक साधारण अखाड़ा आवंटक।
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// निर्दिष्ट आकार का बफर आवंटित करता है और इसके लिए एक परिवर्तनीय संदर्भ देता है।
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // सुरक्षा: यह एकमात्र ऐसा कार्य है जो कभी भी एक परिवर्तनशील का निर्माण करता है
        // `self.buffers` के संदर्भ में।
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // सुरक्षा: हम `self.buffers` से तत्वों को कभी नहीं हटाते हैं, इसलिए एक संदर्भ
        // किसी भी बफ़र के अंदर का डेटा तब तक जीवित रहेगा जब तक `self` करता है।
        &mut buffers[i]
    }
}