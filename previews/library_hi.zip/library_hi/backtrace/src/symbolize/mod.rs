use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// एक पते को एक प्रतीक के लिए हल करें, प्रतीक को निर्दिष्ट बंद करने के लिए पास करें।
///
/// यह फ़ंक्शन स्थानीय प्रतीक तालिका, गतिशील प्रतीक तालिका, या DWARF डिबग जानकारी (सक्रिय कार्यान्वयन के आधार पर) जैसे क्षेत्रों में दिए गए पते को देखने के लिए प्रतीकों को खोजने के लिए देखेगा।
///
///
/// यदि संकल्प निष्पादित नहीं किया जा सकता है, तो बंद नहीं किया जा सकता है, और इनलाइन कार्यों के मामले में इसे एक से अधिक बार भी बुलाया जा सकता है।
///
/// प्राप्त प्रतीक निर्दिष्ट `addr` पर निष्पादन का प्रतिनिधित्व करते हैं, उस पते के लिए file/line जोड़े लौटाते हैं (यदि उपलब्ध हो)।
///
/// ध्यान दें कि यदि आपके पास `Frame` है तो इसके बजाय `resolve_frame` फ़ंक्शन का उपयोग करने की अनुशंसा की जाती है।
///
/// # आवश्यक सुविधाएँ
///
/// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
///
/// # Panics
///
/// यह फ़ंक्शन panic कभी नहीं करने का प्रयास करता है, लेकिन यदि `cb` panics प्रदान करता है तो कुछ प्लेटफ़ॉर्म प्रक्रिया को निरस्त करने के लिए एक डबल panic को बाध्य करेंगे।
/// कुछ प्लेटफ़ॉर्म एक सी लाइब्रेरी का उपयोग करते हैं जो आंतरिक रूप से कॉलबैक का उपयोग करता है जिसे अनवाउंड नहीं किया जा सकता है, इसलिए `cb` से घबराने से प्रक्रिया निरस्त हो सकती है।
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // केवल शीर्ष फ्रेम को देखें
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// निर्दिष्ट बंद करने के लिए प्रतीक को पास करते हुए, पहले से कैप्चर किए गए फ़्रेम को एक प्रतीक पर हल करें।
///
/// यह functin `resolve` के समान कार्य करता है सिवाय इसके कि यह एक पते के बजाय एक `Frame` को तर्क के रूप में लेता है।
/// यह उदाहरण के लिए इनलाइन फ़्रेमों के बारे में अधिक सटीक प्रतीक जानकारी या जानकारी प्रदान करने के लिए बैकट्रेसिंग के कुछ प्लेटफ़ॉर्म कार्यान्वयन की अनुमति दे सकता है।
///
/// यदि आप कर सकते हैं तो इसका उपयोग करने की अनुशंसा की जाती है।
///
/// # आवश्यक सुविधाएँ
///
/// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
///
/// # Panics
///
/// यह फ़ंक्शन panic कभी नहीं करने का प्रयास करता है, लेकिन यदि `cb` panics प्रदान करता है तो कुछ प्लेटफ़ॉर्म प्रक्रिया को निरस्त करने के लिए एक डबल panic को बाध्य करेंगे।
/// कुछ प्लेटफ़ॉर्म एक सी लाइब्रेरी का उपयोग करते हैं जो आंतरिक रूप से कॉलबैक का उपयोग करता है जिसे अनवाउंड नहीं किया जा सकता है, इसलिए `cb` से घबराने से प्रक्रिया निरस्त हो सकती है।
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // केवल शीर्ष फ्रेम को देखें
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// स्टैक फ़्रेम से IP मान आमतौर पर (always?) निर्देश *बाद* कॉल है जो वास्तविक स्टैक ट्रेस है।
// इस पर प्रतीक करने से filename/line संख्या एक आगे और शायद शून्य में हो जाती है यदि यह फ़ंक्शन के अंत के पास है।
//
// ऐसा प्रतीत होता है कि मूल रूप से सभी प्लेटफार्मों पर हमेशा ऐसा ही होता है, इसलिए हम हमेशा एक को हल किए गए आईपी से घटाते हैं ताकि इसे पिछले कॉल निर्देश के बजाय निर्देश वापस किया जा सके।
//
//
// आदर्श रूप में हम ऐसा नहीं करेंगे।
// आदर्श रूप से हमें `resolve` API के कॉलर्स की आवश्यकता होगी ताकि वे मैन्युअल रूप से -1 कर सकें और यह बता सकें कि वे *पिछला* निर्देश के लिए स्थान की जानकारी चाहते हैं, वर्तमान नहीं।
// आदर्श रूप से हम `Frame` पर भी एक्सपोज़ करेंगे यदि हम वास्तव में अगले निर्देश या वर्तमान का पता हैं।
//
// अभी के लिए हालांकि यह एक बहुत ही विशिष्ट चिंता है इसलिए हम केवल आंतरिक रूप से हमेशा एक घटाते हैं।
// उपभोक्ताओं को काम करते रहना चाहिए और बहुत अच्छे परिणाम मिलते रहना चाहिए, इसलिए हमें काफी अच्छा होना चाहिए।
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` के समान, केवल असुरक्षित है क्योंकि यह अनसिंक्रनाइज़्ड है।
///
/// इस फ़ंक्शन में सिंक्रोनाइज़ेशन गारंटी नहीं है, लेकिन यह तब उपलब्ध होता है जब इस crate की `std` सुविधा को संकलित नहीं किया जाता है।
/// अधिक दस्तावेज़ीकरण और उदाहरणों के लिए `resolve` फ़ंक्शन देखें।
///
/// # Panics
///
/// `cb` घबराहट पर चेतावनियों के लिए `resolve` पर जानकारी देखें।
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` के समान, केवल असुरक्षित है क्योंकि यह अनसिंक्रनाइज़्ड है।
///
/// इस फ़ंक्शन में सिंक्रोनाइज़ेशन गारंटी नहीं है, लेकिन यह तब उपलब्ध होता है जब इस crate की `std` सुविधा को संकलित नहीं किया जाता है।
/// अधिक दस्तावेज़ीकरण और उदाहरणों के लिए `resolve_frame` फ़ंक्शन देखें।
///
/// # Panics
///
/// `cb` घबराहट पर चेतावनियों के लिए `resolve_frame` पर जानकारी देखें।
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// एक trait एक फ़ाइल में एक प्रतीक के संकल्प का प्रतिनिधित्व करता है।
///
/// यह trait `backtrace::resolve` फ़ंक्शन को दिए गए क्लोजर के लिए trait ऑब्जेक्ट के रूप में उत्पन्न होता है, और इसे वस्तुतः भेजा जाता है क्योंकि यह अज्ञात है कि इसके पीछे कौन सा कार्यान्वयन है।
///
///
/// एक प्रतीक किसी फ़ंक्शन के बारे में प्रासंगिक जानकारी दे सकता है, उदाहरण के लिए नाम, फ़ाइल नाम, लाइन नंबर, सटीक पता, आदि।
/// हालांकि, सभी जानकारी हमेशा एक प्रतीक में उपलब्ध नहीं होती है, इसलिए सभी विधियाँ एक `Option` लौटाती हैं।
///
///
pub struct Symbol {
    // TODO: इस आजीवन बाध्यता को अंततः `Symbol` तक बनाए रखने की आवश्यकता है,
    // लेकिन यह वर्तमान में एक महत्वपूर्ण बदलाव है।
    // अभी के लिए यह सुरक्षित है क्योंकि `Symbol` को केवल संदर्भ द्वारा ही दिया जाता है और इसे क्लोन नहीं किया जा सकता है।
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// इस फ़ंक्शन का नाम लौटाता है।
    ///
    /// लौटाई गई संरचना का उपयोग प्रतीक नाम के बारे में विभिन्न गुणों को क्वेरी करने के लिए किया जा सकता है:
    ///
    ///
    /// * `Display` कार्यान्वयन विघटित प्रतीक का प्रिंट आउट लेगा।
    /// * प्रतीक के कच्चे `str` मूल्य तक पहुँचा जा सकता है (यदि यह मान्य utf-8 है)।
    /// * प्रतीक नाम के लिए कच्चे बाइट्स तक पहुँचा जा सकता है।
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// इस फ़ंक्शन का प्रारंभिक पता देता है।
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// कच्चे फ़ाइल नाम को एक स्लाइस के रूप में लौटाता है।
    /// यह मुख्य रूप से `no_std` परिवेशों के लिए उपयोगी है।
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// उस कॉलम नंबर को लौटाता है जहां यह प्रतीक वर्तमान में निष्पादित हो रहा है।
    ///
    /// केवल गिमली वर्तमान में यहां एक मूल्य प्रदान करता है और तब भी केवल अगर `filename` `Some` लौटाता है, और इसलिए यह इसी तरह की चेतावनी के अधीन है।
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// जहां यह प्रतीक वर्तमान में क्रियान्वित हो रहा है, उसके लिए लाइन नंबर देता है।
    ///
    /// यदि `filename` `Some` लौटाता है, तो यह वापसी मान आम तौर पर `Some` होता है, और फलस्वरूप समान चेतावनी के अधीन होता है।
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// फ़ाइल का नाम देता है जहां यह फ़ंक्शन परिभाषित किया गया था।
    ///
    /// यह वर्तमान में केवल तभी उपलब्ध है जब libbacktrace या gimli का उपयोग किया जा रहा हो (उदा
    /// unix प्लेटफॉर्म अन्य) और जब एक बाइनरी को डिबगइन्फो के साथ संकलित किया जाता है।
    /// यदि इनमें से कोई भी शर्त पूरी नहीं होती है, तो यह `None` वापस आने की संभावना है।
    ///
    /// # आवश्यक सुविधाएँ
    ///
    /// इस फ़ंक्शन को सक्षम करने के लिए `backtrace` crate की `std` सुविधा की आवश्यकता है, और `std` सुविधा डिफ़ॉल्ट रूप से सक्षम है।
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // हो सकता है कि एक पार्स किया गया सी ++ प्रतीक, अगर मैंगल्ड प्रतीक को Rust के रूप में पार्स करना विफल रहा।
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // इस शून्य-आकार को रखना सुनिश्चित करें, ताकि अक्षम होने पर `cpp_demangle` सुविधा की कोई कीमत न हो।
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// एक प्रतीक नाम के चारों ओर एक आवरण जो विघटित नाम, कच्चे बाइट्स, कच्ची स्ट्रिंग आदि के लिए एर्गोनोमिक एक्सेसर्स प्रदान करता है।
///
// `cpp_demangle` सुविधा सक्षम न होने पर डेड कोड की अनुमति दें।
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// कच्चे अंतर्निहित बाइट्स से एक नया प्रतीक नाम बनाता है।
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// यदि प्रतीक मान्य utf-8 है, तो कच्चे (mangled) प्रतीक नाम को `str` के रूप में लौटाता है।
    ///
    /// यदि आप विघटित संस्करण चाहते हैं तो `Display` कार्यान्वयन का उपयोग करें।
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// कच्चे प्रतीक नाम को बाइट्स की सूची के रूप में लौटाता है
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // यह प्रिंट करने के लिए हो सकता है यदि विघटित प्रतीक वास्तव में मान्य नहीं है, इसलिए इसे बाहर की ओर प्रचारित न करके यहां त्रुटि को इनायत से संभालें।
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// उस कैश्ड मेमोरी को पुनः प्राप्त करने का प्रयास जो पतों का प्रतीक है।
///
/// यह विधि किसी भी वैश्विक डेटा संरचना को जारी करने का प्रयास करेगी जो अन्यथा वैश्विक स्तर पर या थ्रेड में कैश की गई है जो आमतौर पर पार्स की गई डीडब्ल्यूएआरएफ जानकारी या इसी तरह का प्रतिनिधित्व करती है।
///
///
/// # Caveats
///
/// हालांकि यह फ़ंक्शन हमेशा उपलब्ध होता है, यह वास्तव में अधिकांश कार्यान्वयनों पर कुछ भी नहीं करता है।
/// dbghelp या libbacktrace जैसे पुस्तकालय राज्य को हटाने और आवंटित स्मृति को प्रबंधित करने की सुविधा प्रदान नहीं करते हैं।
/// अभी के लिए इस crate का `gimli-symbolize` फीचर ही एकमात्र फीचर है जहां इस फंक्शन का कोई प्रभाव पड़ता है।
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}