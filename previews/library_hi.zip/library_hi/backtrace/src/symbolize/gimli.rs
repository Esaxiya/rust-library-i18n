//! crates.io पर `gimli` crate का उपयोग करके प्रतीकात्मकता के लिए समर्थन
//!
//! यह Rust के लिए डिफ़ॉल्ट प्रतीकात्मक कार्यान्वयन है।

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'स्थिर जीवनकाल स्व-संदर्भित संरचनाओं के समर्थन की कमी के आसपास हैक करने के लिए एक झूठ है।
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // 'स्थिर जीवनकाल' में कनवर्ट करें क्योंकि प्रतीकों को केवल `map` और `stash` उधार लेना चाहिए और हम उन्हें नीचे संरक्षित कर रहे हैं।
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows पर नेटिव लाइब्रेरी लोड करने के लिए, यहां विभिन्न रणनीतियों के लिए rust-lang/rust#71060 पर कुछ चर्चा देखें।
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // मिनीजीडब्ल्यू पुस्तकालय वर्तमान में एएसएलआर एक्स00एक्स का समर्थन नहीं करते हैं, लेकिन डीएलएल को अभी भी पता स्थान में स्थानांतरित किया जा सकता है।
            // ऐसा प्रतीत होता है कि डिबग जानकारी में सभी पते ऐसे हैं जैसे कि यह लाइब्रेरी अपने "image base" पर लोड की गई थी, जो कि इसके COFF फ़ाइल हेडर में एक फ़ील्ड है।
            // चूंकि डीबगइन्फो सूची में ऐसा लगता है कि हम प्रतीक तालिका और स्टोर पते को पार्स करते हैं जैसे कि पुस्तकालय "image base" पर भी लोड किया गया था।
            //
            // हालाँकि, लाइब्रेरी को "image base" पर लोड नहीं किया जा सकता है।
            // (संभवतः वहां कुछ और लोड किया जा सकता है?) यह वह जगह है जहां `bias` फ़ील्ड खेल में आती है, और हमें यहां `bias` के मान को समझने की आवश्यकता है।दुर्भाग्य से हालांकि यह स्पष्ट नहीं है कि इसे लोड किए गए मॉड्यूल से कैसे प्राप्त किया जाए।
            // हालाँकि, हमारे पास वास्तविक लोड पता (`modBaseAddr`) है।
            //
            // अभी के लिए एक कॉप-आउट के रूप में हम फ़ाइल को एमएमएपी करते हैं, फ़ाइल हेडर जानकारी पढ़ते हैं, फिर एमएमएपी ड्रॉप करते हैं।यह बेकार है क्योंकि हम शायद बाद में एमएमएपी को फिर से खोल देंगे, लेकिन यह अभी के लिए पर्याप्त रूप से काम करना चाहिए।
            //
            // एक बार जब हमारे पास `image_base` (वांछित लोड स्थान) और `base_addr` (वास्तविक लोड स्थान) हो जाता है, तो हम `bias` (वास्तविक और वांछित के बीच का अंतर) भर सकते हैं और फिर प्रत्येक खंड का निर्दिष्ट पता `image_base` होता है क्योंकि फ़ाइल यही कहती है।
            //
            //
            // अभी के लिए ऐसा प्रतीत होता है कि ELF/MachO के विपरीत हम पूरे आकार के रूप में `modBaseSize` का उपयोग करके प्रति पुस्तकालय एक खंड के साथ कर सकते हैं।
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS Mach-O फ़ाइल स्वरूप का उपयोग करता है और मूल पुस्तकालयों की सूची लोड करने के लिए DYLD-विशिष्ट API का उपयोग करता है जो अनुप्रयोग का हिस्सा हैं।
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // इस पुस्तकालय का नाम प्राप्त करें जो उस पथ से मेल खाता है जहां इसे लोड करना है।
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // इस लाइब्रेरी के इमेज हेडर को लोड करें और सभी लोड कमांड को पार्स करने के लिए `object` को डेलिगेट करें ताकि हम यहां शामिल सभी सेगमेंट का पता लगा सकें।
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // खंडों पर पुनरावृति करें और ज्ञात क्षेत्रों को उन खंडों के लिए पंजीकृत करें जो हमें मिलते हैं।
            // इसके अतिरिक्त बाद में प्रसंस्करण के लिए सूचना के बारे में पाठ खंडों को रिकॉर्ड करें, नीचे टिप्पणी देखें।
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // इस पुस्तकालय के लिए "slide" का निर्धारण करें जो कि पूर्वाग्रह के रूप में समाप्त होता है जिसका उपयोग हम यह पता लगाने के लिए करते हैं कि मेमोरी ऑब्जेक्ट कहाँ लोड किए गए हैं।
            // हालांकि यह एक अजीब गणना का एक सा है और जंगली में कुछ चीजों की कोशिश करने और यह देखने का नतीजा है कि क्या चिपक जाता है।
            //
            // सामान्य विचार यह है कि `bias` प्लस एक खंड का `stated_virtual_memory_address` वह स्थान होगा जहां वास्तविक पता स्थान में खंड रहता है।
            // दूसरी बात जिस पर हम भरोसा करते हैं, वह यह है कि एक वास्तविक पता शून्य से `bias` प्रतीक तालिका और डिबगइन्फो में देखने के लिए सूचकांक है।
            //
            // हालांकि, यह पता चला है कि सिस्टम लोडेड पुस्तकालयों के लिए ये गणना गलत हैं।मूल निष्पादन योग्य के लिए, हालांकि, यह सही प्रतीत होता है।
            // एलएलडीबी के स्रोत से कुछ तर्क उठाते हुए इसमें गैर-शून्य आकार के साथ फ़ाइल ऑफ़सेट 0 से लोड किए गए पहले `__TEXT` अनुभाग के लिए कुछ विशेष-आवरण है।
            // किसी भी कारण से जब यह मौजूद होता है तो इसका मतलब यह प्रतीत होता है कि प्रतीक तालिका पुस्तकालय के लिए सिर्फ vmaddr स्लाइड के सापेक्ष है।
            // यदि यह *नहीं* मौजूद है तो प्रतीक तालिका vmaddr स्लाइड और खंड के बताए गए पते के सापेक्ष है।
            //
            // इस स्थिति को संभालने के लिए यदि हमें फ़ाइल ऑफ़सेट शून्य पर टेक्स्ट सेक्शन *नहीं* मिलता है तो हम पहले टेक्स्ट सेक्शन के बताए गए पते से पूर्वाग्रह बढ़ाते हैं और उस राशि से सभी बताए गए पतों को भी घटाते हैं।
            //
            // इस तरह प्रतीक तालिका हमेशा पुस्तकालय की पूर्वाग्रह राशि के सापेक्ष दिखाई देती है।
            // ऐसा लगता है कि प्रतीक तालिका के माध्यम से प्रतीक के लिए सही परिणाम हैं।
            //
            // ईमानदारी से मुझे पूरी तरह से यकीन नहीं है कि यह सही है या अगर कुछ और है जो यह इंगित करना चाहिए कि यह कैसे करना है।
            // अभी के लिए हालांकि ऐसा लगता है कि यह काफी अच्छी तरह से काम करता है (?) और यदि आवश्यक हो तो हमें इसे समय के साथ बदलने में सक्षम होना चाहिए।
            //
            // कुछ और जानकारी के लिए देखें #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // अन्य Unix (जैसे
        // लिनक्स) प्लेटफॉर्म ईएलएफ को एक ऑब्जेक्ट फ़ाइल स्वरूप के रूप में उपयोग करते हैं और आम तौर पर देशी पुस्तकालयों को लोड करने के लिए `dl_iterate_phdr` नामक एपीआई को लागू करते हैं।
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` एक वैध संकेत होना चाहिए।
        // `vec` `std::Vec` के लिए एक वैध सूचक होना चाहिए।
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 मूल रूप से डीबग जानकारी का समर्थन नहीं करता है, लेकिन बिल्ड सिस्टम डीबग जानकारी को पथ `romfs:/debug_info.elf` पर रखेगा।
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // बाकी सब कुछ ईएलएफ का उपयोग करना चाहिए, लेकिन यह नहीं जानता कि देशी पुस्तकालयों को कैसे लोड किया जाए।
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// सभी ज्ञात साझा पुस्तकालय जो लोड किए गए हैं।
    libraries: Vec<Library>,

    /// मैपिंग कैश जहां हम पार्स की गई बौनी जानकारी रखते हैं।
    ///
    /// इस सूची में अपने पूरे भारोत्तोलन के लिए एक निश्चित क्षमता है जो कभी नहीं बढ़ती है।
    /// प्रत्येक जोड़ी का `usize` तत्व ऊपर `libraries` में एक सूचकांक है जहां `usize::max_value()` वर्तमान निष्पादन योग्य का प्रतिनिधित्व करता है।
    ///
    /// `Mapping` संबंधित पार्स की गई बौनी जानकारी है।
    ///
    /// ध्यान दें कि यह मूल रूप से एक एलआरयू कैश है और हम यहां चीजों को इधर-उधर कर देंगे क्योंकि हम पतों का प्रतीक हैं।
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// इस पुस्तकालय के खंड स्मृति में लोड किए गए हैं, और जहां वे लोड किए गए हैं।
    segments: Vec<LibrarySegment>,
    /// इस लाइब्रेरी का "bias", आमतौर पर जहां इसे मेमोरी में लोड किया जाता है।
    /// यह मान प्रत्येक खंड के बताए गए पते में जोड़ा जाता है ताकि वास्तविक वर्चुअल मेमोरी पता प्राप्त किया जा सके जिसमें खंड लोड किया गया हो।
    /// इसके अतिरिक्त इस पूर्वाग्रह को वास्तविक वर्चुअल मेमोरी एड्रेस से डिबगइन्फो और सिंबल टेबल में इंडेक्स में घटाया जाता है।
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// ऑब्जेक्ट फ़ाइल में इस खंड का बताया गया पता।
    /// यह वास्तव में वह जगह नहीं है जहां खंड लोड किया गया है, बल्कि यह पता प्लस युक्त पुस्तकालय का `bias` है जहां इसे ढूंढना है।
    ///
    stated_virtual_memory_address: usize,
    /// स्मृति में ths खंड का आकार।
    len: usize,
}

// असुरक्षित है क्योंकि इसे बाहरी रूप से सिंक्रनाइज़ करने की आवश्यकता है
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // असुरक्षित है क्योंकि इसे बाहरी रूप से सिंक्रनाइज़ करने की आवश्यकता है
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // डीबग जानकारी मैपिंग के लिए एक बहुत छोटा, बहुत ही सरल एलआरयू कैश।
        //
        // हिट दर बहुत अधिक होनी चाहिए, क्योंकि सामान्य स्टैक कई साझा पुस्तकालयों के बीच नहीं होता है।
        //
        // `addr2line::Context` संरचनाएं बनाने में काफी महंगी हैं।
        // इसकी लागत बाद के `locate` प्रश्नों द्वारा परिशोधित होने की उम्मीद है, जो अच्छी गति प्राप्त करने के लिए `addr2line: :Context` का निर्माण करते समय निर्मित संरचनाओं का लाभ उठाते हैं।
        //
        // यदि हमारे पास यह कैश नहीं होता, तो वह परिशोधन कभी नहीं होता, और बैकट्रेस का प्रतीक ssssllllooooowwww होगा।
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // सबसे पहले, परीक्षण करें कि क्या इस `lib` में `addr` (हैंडलिंग स्थानांतरण) वाला कोई खंड है।यदि यह चेक पास हो जाता है तो हम नीचे जारी रख सकते हैं और वास्तव में पते का अनुवाद कर सकते हैं।
                //
                // ध्यान दें कि हम अतिप्रवाह जांच से बचने के लिए यहां `wrapping_add` का उपयोग कर रहे हैं।यह जंगली में देखा गया है कि एसवीएमए + पूर्वाग्रह गणना ओवरफ्लो हो जाती है।
                // यह थोड़ा अजीब लगता है कि ऐसा होगा, लेकिन इसके बारे में हम कोई बड़ी राशि नहीं कर सकते हैं, इसके अलावा शायद उन खंडों को अनदेखा कर दें क्योंकि वे अंतरिक्ष में जाने की संभावना रखते हैं।
                //
                // यह मूल रूप से rust-lang/backtrace-rs#329 में आया था।
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // अब जब हम जानते हैं कि `lib` में `addr` है, तो हम बताए गए वायरल मेमोरी एड्रेस को खोजने के लिए पूर्वाग्रह के साथ ऑफसेट कर सकते हैं।
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // अपरिवर्तनीय: इस सशर्त के बाद जल्दी लौटने के बिना पूरा होता है
        // किसी त्रुटि से, इस पथ के लिए कैश प्रविष्टि अनुक्रमणिका 0 पर है।

        if let Some(idx) = idx {
            // जब मैपिंग पहले से ही कैशे में हो, तो उसे सामने की ओर ले जाएँ।
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // जब मैपिंग कैश में न हो, तो एक नई मैपिंग बनाएं, इसे कैशे के सामने डालें, और यदि आवश्यक हो तो सबसे पुरानी कैश प्रविष्टि को हटा दें।
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` जीवनकाल को लीक न करें, सुनिश्चित करें कि यह केवल स्वयं के दायरे में है
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // `sym` के जीवनकाल को `'static` तक बढ़ाएँ क्योंकि दुर्भाग्य से हमें यहाँ की आवश्यकता है, लेकिन यह कभी भी एक संदर्भ के रूप में बाहर जा रहा है, इसलिए इसका कोई भी संदर्भ इस फ्रेम से परे जारी नहीं रखा जाना चाहिए।
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // अंत में, कैश्ड मैपिंग प्राप्त करें या इस फ़ाइल के लिए एक नई मैपिंग बनाएं, और इस पते के लिए file/line/name खोजने के लिए DWARF जानकारी का मूल्यांकन करें।
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// हम इस प्रतीक के लिए फ्रेम जानकारी का पता लगाने में सक्षम थे, और `addr2line` के फ्रेम में आंतरिक रूप से सभी बारीक विवरण हैं।
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// डीबग जानकारी नहीं मिली, लेकिन हमने इसे योगिनी निष्पादन योग्य की प्रतीक तालिका में पाया।
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}