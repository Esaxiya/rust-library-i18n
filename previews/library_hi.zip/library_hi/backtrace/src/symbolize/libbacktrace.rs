//! libbacktrace में DWARF-पार्सिंग कोड का उपयोग करके प्रतीकात्मक रणनीति।
//!
//! libbacktrace C लाइब्रेरी, जिसे आमतौर पर gcc के साथ वितरित किया जाता है, न केवल एक बैकट्रेस (जिसका हम वास्तव में उपयोग नहीं करते हैं) उत्पन्न करने का समर्थन करता है, बल्कि बैकट्रेस का प्रतीक है और इनलाइन फ्रेम और व्हाट्नॉट जैसी चीजों के बारे में बौना डिबग जानकारी को संभालता है।
//!
//!
//! यहां बहुत सारी विभिन्न चिंताओं के कारण यह अपेक्षाकृत जटिल है, लेकिन मूल विचार यह है:
//!
//! * पहले हम `backtrace_syminfo` को कॉल करते हैं।यदि हम कर सकते हैं तो यह गतिशील प्रतीक तालिका से प्रतीक जानकारी प्राप्त करता है।
//! * आगे हम `backtrace_pcinfo` कहते हैं।यह डिबगइन्फो टेबल को पार्स करेगा यदि वे उपलब्ध हैं और हमें इनलाइन फ्रेम, फ़ाइल नाम, लाइन नंबर आदि के बारे में जानकारी पुनर्प्राप्त करने की अनुमति देते हैं।
//!
//! बौने तालिकाओं को libbacktrace में लाने के बारे में बहुत सारी चालबाजी है, लेकिन उम्मीद है कि यह दुनिया का अंत नहीं है और नीचे पढ़ते समय पर्याप्त स्पष्ट है।
//!
//! यह गैर-एमएसवीसी और गैर-ओएसएक्स प्लेटफॉर्म के लिए डिफ़ॉल्ट प्रतीकात्मक रणनीति है।libstd में हालांकि यह OSX के लिए डिफ़ॉल्ट रणनीति है।
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // यदि संभव हो तो `function` नाम पसंद करें जो डिबगइन्फो से आता है और उदाहरण के लिए इनलाइन फ्रेम के लिए आमतौर पर अधिक सटीक हो सकता है।
                // यदि वह मौजूद नहीं है, तो `symname` में निर्दिष्ट प्रतीक तालिका नाम पर वापस आएं।
                //
                // ध्यान दें कि कभी-कभी `function` कुछ हद तक कम सटीक महसूस कर सकता है, उदाहरण के लिए `try<i32,closure>` के रूप में सूचीबद्ध होने के कारण `std::panicking::try::do_call` नहीं है।
                //
                // यह वास्तव में स्पष्ट क्यों नहीं है, लेकिन कुल मिलाकर `function` नाम अधिक सटीक लगता है।
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // अभी के लिए कुछ मत करो
}

/// `data` पॉइंटर का प्रकार `syminfo_cb`. में पारित हुआ
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // एक बार जब यह कॉलबैक `backtrace_syminfo` से लागू हो जाता है, जब हम समाधान करना शुरू करते हैं तो हम `backtrace_pcinfo` को कॉल करने के लिए आगे बढ़ते हैं।
    // `backtrace_pcinfo` फ़ंक्शन डिबग जानकारी से परामर्श करेगा और file/line जानकारी के साथ-साथ इनलाइन फ़्रेमों को पुनर्प्राप्त करने जैसे काम करने का प्रयास करेगा।
    // ध्यान दें कि यदि डीबग जानकारी नहीं है तो `backtrace_pcinfo` विफल हो सकता है या बहुत कुछ नहीं कर सकता है, इसलिए यदि ऐसा होता है तो हम `syminfo_cb` से कम से कम एक प्रतीक के साथ कॉलबैक को कॉल करना सुनिश्चित कर सकते हैं।
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data` पॉइंटर का प्रकार `pcinfo_cb`. में पारित हुआ
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// libbacktrace एपीआई एक राज्य बनाने का समर्थन करता है, लेकिन यह एक राज्य को नष्ट करने का समर्थन नहीं करता है।
// मैं व्यक्तिगत रूप से इसका मतलब यह लेता हूं कि एक राज्य का निर्माण होता है और फिर हमेशा के लिए रहता है।
//
// मुझे एक at_exit() हैंडलर पंजीकृत करना अच्छा लगेगा जो इस स्थिति को साफ़ करता है, लेकिन libbacktrace ऐसा करने का कोई तरीका नहीं प्रदान करता है।
//
// इन बाधाओं के साथ, इस फ़ंक्शन में एक स्थिर रूप से कैश्ड स्थिति होती है जिसे पहली बार अनुरोध किए जाने पर गणना की जाती है।
//
// याद रखें कि बैकट्रैकिंग सभी क्रमिक रूप से होती है (एक वैश्विक लॉक)।
//
// ध्यान दें कि यहां सिंक्रनाइज़ेशन की कमी इस आवश्यकता के कारण है कि `resolve` बाहरी रूप से सिंक्रनाइज़ है।
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // libbacktrace की थ्रेडसेफ क्षमताओं का प्रयोग न करें क्योंकि हम इसे हमेशा एक सिंक्रनाइज़ फैशन में बुला रहे हैं।
        //
        0,
        error_cb,
        ptr::null_mut(), // कोई अतिरिक्त डेटा नहीं
    );

    return STATE;

    // ध्यान दें कि libbacktrace को संचालित करने के लिए इसे वर्तमान निष्पादन योग्य के लिए DWARF डीबग जानकारी खोजने की आवश्यकता है।यह आम तौर पर कई तंत्रों के माध्यम से करता है, लेकिन इन तक सीमित नहीं है:
    //
    // * /proc/self/exe समर्थित प्लेटफॉर्म पर
    // * राज्य बनाते समय फ़ाइल नाम स्पष्ट रूप से पारित हुआ
    //
    // libbacktrace लाइब्रेरी सी कोड का एक बड़ा हिस्सा है।इसका स्वाभाविक रूप से मतलब है कि इसमें मेमोरी सुरक्षा कमजोरियां हैं, खासकर जब विकृत डिबगइन्फो को संभालना।
    // लिबस्टड ऐतिहासिक रूप से इनमें से बहुत कुछ चला चुका है।
    //
    // यदि /proc/self/exe का उपयोग किया जाता है तो हम आम तौर पर इन्हें अनदेखा कर सकते हैं क्योंकि हम मानते हैं कि libbacktrace "mostly correct" है और अन्यथा "attempted to be correct" बौना डीबग जानकारी के साथ अजीब चीजें नहीं करता है।
    //
    //
    // हालांकि, अगर हम एक फ़ाइल नाम में पास करते हैं, तो यह कुछ प्लेटफार्मों (जैसे बीएसडी) पर संभव है, जहां एक दुर्भावनापूर्ण अभिनेता उस स्थान पर एक मनमानी फ़ाइल डाल सकता है।
    // इसका मतलब यह है कि अगर हम किसी फ़ाइल नाम के बारे में libbacktrace को बताते हैं तो यह एक मनमानी फ़ाइल का उपयोग कर सकता है, संभवतः segfaults का कारण बन सकता है।
    // अगर हम libbacktrace को कुछ भी नहीं बताते हैं, तो यह प्लेटफॉर्म पर कुछ भी नहीं करेगा जो /proc/self/exe जैसे पथों का समर्थन नहीं करता है!
    //
    // यह सब देखते हुए कि हम एक फ़ाइल नाम में *नहीं* पास करने के लिए यथासंभव कठिन प्रयास करते हैं, लेकिन हमें उन प्लेटफार्मों पर होना चाहिए जो बिल्कुल भी /proc/self/exe का समर्थन नहीं करते हैं।
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // ध्यान दें कि आदर्श रूप से हम `std::env::current_exe` का उपयोग करेंगे, लेकिन हमें यहां `std` की आवश्यकता नहीं है।
            //
            // वर्तमान निष्पादन योग्य पथ को स्थिर क्षेत्र में लोड करने के लिए `_NSGetExecutablePath` का उपयोग करें (यदि यह बहुत छोटा है तो बस छोड़ दें)।
            //
            //
            // ध्यान दें कि हम भ्रष्ट निष्पादन योग्य पर नहीं मरने के लिए यहां libbacktrace पर गंभीरता से भरोसा कर रहे हैं, लेकिन यह निश्चित रूप से करता है ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows फाइलों को खोलने का एक तरीका है जहां इसे खोलने के बाद इसे हटाया नहीं जा सकता है।
            // यह सामान्य रूप से हम यहां चाहते हैं क्योंकि हम यह सुनिश्चित करना चाहते हैं कि हमारे निष्पादन योग्य हमारे नीचे से बदल नहीं रहे हैं, जब हम इसे libbacktrace को सौंप देते हैं, उम्मीद है कि मनमाने ढंग से डेटा को libbacktrace (जिसे गलत तरीके से संभाला जा सकता है) में पारित करने की क्षमता को कम कर देता है।
            //
            //
            // यह देखते हुए कि हम अपनी छवि पर एक प्रकार का ताला लगाने का प्रयास करने के लिए यहां थोड़ा सा नृत्य करते हैं:
            //
            // * वर्तमान प्रक्रिया के लिए एक हैंडल प्राप्त करें, इसका फ़ाइल नाम लोड करें।
            // * उस फ़ाइल नाम के लिए एक फ़ाइल खोलें जिसमें सही झंडे हों।
            // * वर्तमान प्रक्रिया के फ़ाइल नाम को पुनः लोड करें, सुनिश्चित करें कि यह वही है
            //
            // यदि यह सब बीत जाता है तो हम सिद्धांत रूप में वास्तव में हमारी प्रक्रिया की फाइल खोल चुके हैं और हमें गारंटी है कि यह नहीं बदलेगा।एफडब्ल्यूआईडब्ल्यू इसका एक गुच्छा ऐतिहासिक रूप से libstd से कॉपी किया गया है, इसलिए जो हो रहा था उसकी यह मेरी सबसे अच्छी व्याख्या है।
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // यह स्थिर स्मृति में रहता है इसलिए हम इसे वापस कर सकते हैं।
                static mut BUF: [i8; N] = [0; N];
                // ... और यह ढेर पर रहता है क्योंकि यह अस्थायी है
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // जानबूझकर `handle` को यहां लीक करें क्योंकि उस खुले होने से इस फ़ाइल नाम पर हमारे लॉक को सुरक्षित रखना चाहिए।
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // हम एक टुकड़ा वापस करना चाहते हैं जो शून्य समाप्त हो गया है, इसलिए यदि सब कुछ भर गया था और यह कुल लंबाई के बराबर है तो इसे विफलता के बराबर करें।
                //
                //
                // अन्यथा सफलता लौटाते समय सुनिश्चित करें कि नल बाइट स्लाइस में शामिल है।
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // बैकट्रेस त्रुटियां वर्तमान में गलीचे के नीचे बह रही हैं
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` API को कॉल करें जो (कोड पढ़ने से) `syminfo_cb` को ठीक एक बार कॉल करना चाहिए (या संभावित रूप से एक त्रुटि के साथ विफल)।
    // हम तब `syminfo_cb` के भीतर और अधिक संभालते हैं।
    //
    // ध्यान दें कि हम ऐसा करते हैं क्योंकि `syminfo` प्रतीक तालिका से परामर्श करेगा, प्रतीक नाम ढूंढेगा भले ही बाइनरी में कोई डीबग जानकारी न हो।
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}