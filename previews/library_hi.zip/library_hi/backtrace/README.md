# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust के लिए रनटाइम पर बैकट्रेस प्राप्त करने के लिए एक पुस्तकालय।
इस पुस्तकालय का उद्देश्य काम करने के लिए प्रोग्रामेटिक इंटरफ़ेस प्रदान करके मानक पुस्तकालय के समर्थन को बढ़ाना है, लेकिन यह libstd के panics जैसे वर्तमान बैकट्रेस को आसानी से प्रिंट करने का भी समर्थन करता है।

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

बैकट्रेस को आसानी से कैप्चर करने और बाद के समय तक इसके साथ काम करने को स्थगित करने के लिए, आप शीर्ष-स्तरीय `Backtrace` प्रकार का उपयोग कर सकते हैं।

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

यदि, हालांकि, आप वास्तविक ट्रेसिंग कार्यक्षमता के लिए अधिक कच्ची पहुंच चाहते हैं, तो आप सीधे `trace` और `resolve` फ़ंक्शन का उपयोग कर सकते हैं।

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // इस निर्देश सूचक को एक प्रतीक नाम पर हल करें
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // अगले फ्रेम पर चलते रहें
    });
}
```

# License

यह परियोजना इनमें से किसी एक के तहत लाइसेंस प्राप्त है

 * Apache लाइसेंस, संस्करण 2.0, ([LICENSE-APACHE](LICENSE-APACHE) या http://www.apache.org/licenses/LICENSE-2.0)
 * एमआईटी लाइसेंस ([LICENSE-MIT](LICENSE-MIT) या http://opensource.org/licenses/MIT)

आपके विकल्प पर।

### Contribution

जब तक आप स्पष्ट रूप से अन्यथा नहीं बताते हैं, Apache-2.0 लाइसेंस में परिभाषित आपके द्वारा बैकट्रेस-आरएस में शामिल करने के लिए जानबूझकर सबमिट किया गया कोई भी योगदान, बिना किसी अतिरिक्त नियम या शर्तों के, उपरोक्त के रूप में दोहरे लाइसेंस के लिए होगा।







