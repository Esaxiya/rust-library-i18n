use backtrace::Backtrace;

// यह परीक्षण केवल उन प्लेटफॉर्म पर काम करता है जिनमें फ़्रेम के लिए एक कार्यशील `symbol_address` फ़ंक्शन होता है जो किसी प्रतीक के शुरुआती पते की रिपोर्ट करता है।
// परिणामस्वरूप यह केवल कुछ प्लेटफॉर्म पर ही सक्षम है।
//
const ENABLED: bool = cfg!(all(
    // Windows वास्तव में परीक्षण नहीं किया गया है, और OSX वास्तव में एक संलग्न फ्रेम खोजने का समर्थन नहीं करता है, इसलिए इसे अक्षम करें
    //
    target_os = "linux",
    // एआरएम पर संलग्न कार्य ढूंढना केवल आईपी को वापस कर रहा है।
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}