use backtrace::Backtrace;

// 50-वर्ण मॉड्यूल का नाम
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50-वर्ण संरचना का नाम
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// लंबे फ़ंक्शन नामों को (MAX_SYM_NAME, 1) वर्णों में छोटा किया जाना चाहिए।
// यह परीक्षण केवल msvc के लिए चलाएँ, क्योंकि gnu सभी फ़्रेमों के लिए "<no info>" प्रिंट करता है।
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // संरचना नाम के 10 दोहराव, इसलिए पूरी तरह से योग्य फ़ंक्शन नाम कम से कम 10 *(50 + 50)* 2=2000 वर्ण लंबा है।
    //
    // यह वास्तव में लंबा है क्योंकि इसमें `::`, `<>` और वर्तमान मॉड्यूल का नाम भी शामिल है
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}