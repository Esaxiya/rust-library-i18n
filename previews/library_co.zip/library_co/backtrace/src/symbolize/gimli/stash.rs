// adupratu solu in Linux avà, allora permettite un codice mortu in altrò
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Un semplice assignatore di arena per buffer di byte.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Alloca un buffer di a dimensione specificata è li restituisce un riferimentu mutevule.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SICUREZZA: questa hè a sola funzione chì hà mai custruitu un mutevule
        // riferenza à `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SICUREZZA: ùn eliminemu mai elementi da `self.buffers`, dunque una riferenza
        // à i dati in un buffer vivrà finu à chì `self` faci.
        &mut buffers[i]
    }
}