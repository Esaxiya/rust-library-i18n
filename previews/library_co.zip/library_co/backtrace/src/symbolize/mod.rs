use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Risolve un indirizzu à un simbulu, passendu u simbulu à a chjusura specificata.
///
/// Sta funzione cercarà l'indirizzu datu in e zone cum'è a tavula di simbuli lucali, a tavula di simboli dinamichi, o l'infurmazioni di debug DWARF (secondu l'implementazione attivata) per truvà simboli da cede.
///
///
/// A chjusura ùn pò micca esse chjamata se a risoluzione ùn puderia micca esse eseguita, è pò ancu esse chjamata più di una volta in casu di funzioni inline.
///
/// I simboli resi riprisentanu l'esecuzione à u `addr` specificatu, restituendu e coppie file/line per quell'indirizzu (se dispunibile).
///
/// Nutate bè chì s'è vo avete un `Frame` allora hè cunsigliatu d'utilizà a funzione `resolve_frame` invece di questu.
///
/// # Funzioni richieste
///
/// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
///
/// # Panics
///
/// Sta funzione s'impegna à ùn mai panic, ma se u `cb` hà furnitu panics allora alcune piattaforme furzeranu un doppiu panic per abbandunà u prucessu.
/// Alcune piattaforme utilizanu una libreria C chì utilizza internamente callbacks chì ùn ponu micca esse sbulicati, dunque u panicu da `cb` pò attivà un abortu di prucessu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // fighjate solu à u quadru superiore
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Risolve un quadru precedentemente catturatu à un simbulu, passendu u simbulu à a chjusura specificata.
///
/// Sta funzione svolge a stessa funzione cum'è `resolve` eccettu chì piglia un `Frame` cum'è argumentu invece di un indirizzu.
/// Questu pò permette alcune implementazioni di piattaforma di retrotrascrittura per furnisce infurmazioni di simboli più precisi o informazioni nantu à fotogrammi in linea per esempiu.
///
/// Hè cunsigliatu di aduprà questu se pudete.
///
/// # Funzioni richieste
///
/// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
///
/// # Panics
///
/// Sta funzione s'impegna à ùn mai panic, ma se u `cb` hà furnitu panics allora alcune piattaforme furzeranu un doppiu panic per abbandunà u prucessu.
/// Alcune piattaforme utilizanu una libreria C chì utilizza internamente callbacks chì ùn ponu micca esse sbulicati, dunque u panicu da `cb` pò attivà un abortu di prucessu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // fighjate solu à u quadru superiore
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// I valori IP da i quadri di stack sò tipicamente (always?) l'istruzione *dopu* a chjamata chì hè a traccia di stack attuale.
// Simbulizendu questu accende u numeru filename/line per esse unu avanti è forse in u viotu s'ellu hè vicinu à a fine di a funzione.
//
// Questu sembra essenzialmente sempre u casu nantu à tutte e piattaforme, allora restemu sempre una da una ip risolta per risolve la à l'istruzione di chjamata precedente invece di chì l'istruzione sia restituita.
//
//
// Idealmente ùn femu micca questu.
// Idealmente, avemu da dumandà à i chjamanti di l'API `resolve` quì per fà manualmente l -1 è cuntà chì volenu informazioni di situazione per l'istruzzione *precedente*, micca l'attuale.
// Idealmente avemu da espone ancu nantu à `Frame` se simu veramente l'indirizzu di a prossima istruzzione o di u currente.
//
// Per avà però questu hè un prublema di nicchia abbastanza cusì solu internamente ne restemu sempre unu.
// I consumatori devenu cuntinuà à travaglià è uttene risultati abbastanza boni, allora duvemu esse abbastanza boni.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Listessu cum'è `resolve`, solu periculosu perchè ùn hè micca sincronizatu.
///
/// Sta funzione ùn hà micca garantiti di sincronizazione ma hè dispunibule quandu a funzione `std` di stu crate ùn hè micca compilata in.
/// Vede a funzione `resolve` per più documentazione è esempi.
///
/// # Panics
///
/// Vede l'infurmazioni nantu à `resolve` per avvertenze nantu à u panicu `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Listessu cum'è `resolve_frame`, solu periculosu perchè ùn hè micca sincronizatu.
///
/// Sta funzione ùn hà micca garantiti di sincronizazione ma hè dispunibule quandu a funzione `std` di stu crate ùn hè micca compilata in.
/// Vede a funzione `resolve_frame` per più documentazione è esempi.
///
/// # Panics
///
/// Vede l'infurmazioni nantu à `resolve_frame` per avvertenze nantu à u panicu `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// A trait chì riprisenta a risoluzione di un simbulu in un schedariu.
///
/// Questu trait hè cedutu cum'è un oggettu trait à a chjusura data à a funzione `backtrace::resolve`, è hè praticamente speditu perchè ùn si sà quale implementazione hè daretu.
///
///
/// Un simbulu pò dà infurmazioni cuntestuali nantu à una funzione, per esempiu u nome, nome di schedariu, numaru di linea, indirizzu precisu, ecc.
/// Tuttavia, micca tutte l'infurmazioni sò sempre dispunibili in un simbulu, dunque tutti i metudi restituiscenu un `Option`.
///
///
pub struct Symbol {
    // TODO: questu ligame di a vita deve esse persistatu eventualmente à `Symbol`,
    // ma questu hè attualmente un cambiamentu rotante.
    // Per avà questu hè sicuru postu chì `Symbol` hè solu distribuitu solu per riferimentu è ùn pò micca esse clonatu.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Restituisce u nome di sta funzione.
    ///
    /// A struttura restituita pò esse aduprata per dumandà varie pruprietà nantu à u nome di u simbulu:
    ///
    ///
    /// * L'implementazione `Display` stamperà u simbulu demangled.
    /// * U valore crudu `str` di u simbulu si pò accede (se hè utf-8 validu).
    /// * Si pò accede à i bytes grezzi per u nome di u simbulu.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Restituisce l'indirizzu iniziale di sta funzione.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Restituisce u nome di schedariu crudu cum'è una fetta.
    /// Questu hè principalmente utile per ambienti `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Restituisce u numeru di colonna per induve stu simbulu hè attualmente in esecuzione.
    ///
    /// Solu gimli attualmente furnisce un valore quì è ancu allora solu se `filename` restituisce `Some`, è dunque hè dunque sottumessu à avvertenze simili.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Restituisce u numeru di linea per induve stu simbulu hè attualmente in esecuzione.
    ///
    /// Stu valore di ritornu hè tipicamente `Some` se `filename` restituisce `Some`, è hè dunque sottumessu à avvertenze simili.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Restituisce u nome di u schedariu induve questa funzione hè stata definita.
    ///
    /// Questu hè attualmente dispunibile solu quandu libbacktrace o gimli hè adupratu (per esempiu
    /// unix altre piattaforme) è quandu un binariu hè compilatu cù debuginfo.
    /// Sì nisuna di queste cundizioni hè soddisfatta allora questu probabilmente ritorna `None`.
    ///
    /// # Funzioni richieste
    ///
    /// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Forse un simbulu C++ analizatu, se l'analisi di u simbulu manghjatu cum'è Rust hà fiascatu.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Assicuratevi di mantene sta dimensione zero, in modo chì a funzione `cpp_demangle` ùn abbia alcun costu quandu hè disattivata.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Un involucru intornu à un nome di simbulu per furnisce accessori ergonomichi à u nome demangled, i byte grezzi, a stringa grezza, ecc.
///
// Permettite u codice mortu per quandu a funzione `cpp_demangle` ùn hè micca abilitata.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Crea un novu nome di simbulu da i bytes grezzi sottostanti.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Restituisce u nome crudu di u simbulu (mangled) cum'è `str` se u simbulu hè validu utf-8.
    ///
    /// Aduprate l'implementazione `Display` se vulete a versione demangled.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Restituisce u nome di simbulu crudu cum'è una lista di byte
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Questu pò stampà se u simbulu demangled ùn hè micca veramente validu, allora gestite l'errore quì cun grazia senza propagallu fora.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Pruvate à recuperà quella memoria in cache aduprata per simbolizà l'indirizzi.
///
/// Stu metudu pruvarà à liberà qualsiasi struttura di dati glubale chì altrimenti sò stati cache in u mondu o in u filu chì tipicamente rapprisentanu informazioni DWARF analizate o simili.
///
///
/// # Caveats
///
/// Mentre sta funzione hè sempre dispunibule ùn face nunda in a maiò parte di l'implementazioni.
/// Biblioteche cum'è dbghelp o libbacktrace ùn furniscenu micca facilità per deallocate u statu è gestisce a memoria attribuita.
/// Per avà a funzione `gimli-symbolize` di stu crate hè a sola caratteristica induve sta funzione hà qualchì effettu.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}