//! Supportu per a simbolica cù `gimli` crate in crates.io
//!
//! Questa hè l'implementazione predefinita di simbolica per Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'A vita statica hè una bugia per pirate intornu à a mancanza di supportu per e strutture autoreferenziali.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Cunvertisce in 'vita statica postu chì i simbuli devenu solu piglià in prestitu `map` è `stash` è li priservemu quì sottu.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Per carregà e biblioteche native in Windows, vedi qualchì discussione nantu à rust-lang/rust#71060 per e varie strategie quì.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // E biblioteche MinGW attualmente ùn supportanu micca ASLR (rust-lang/rust#16514), ma e DLL ponu sempre esse trasferite in u spaziu di l'indirizzu.
            // Sembra chì l'indirizzi in l'infurmazione di debug sò tutti cum'è-se sta biblioteca hè stata caricata in u so "image base", chì hè un campu in i so headers di file COFF.
            // Siccomu questu hè ciò chì debuginfo sembra listà analizzemu a tavula di simboli è guardemu l'indirizzi cum'è se a biblioteca sia stata caricata ancu in "image base".
            //
            // Tuttavia, a biblioteca ùn pò micca esse caricata in "image base".
            // (presumibilmente qualcosa d'altru pò esse caricatu quì?) Eccu induve entra in ghjocu u campu `bias`, è ci vole à capì u valore di `bias` quì.Sfurtunatamente però ùn hè micca chjaru cumu acquistà questu da un modulu carricu.
            // Ciò chì avemu, tuttavia, hè l'indirizzu di carica attuale (`modBaseAddr`).
            //
            // Cume un pocu di cop-out per avà mmapemu u fugliale, leghjemu l'infurmazioni di l'intestazione di u fugliale, poi lasciemu u mmap.Questu hè inutile perchè probabilmente riapriremu u mmap più tardi, ma questu deve funzionà abbastanza bè per avà.
            //
            // Una volta chì avemu u `image_base` (locu di carica desideratu) è u `base_addr` (posizione di carica attuale) pudemu inserisce u `bias` (differenza trà l'attuale è desideratu) è allora l'indirizzu dichjaratu di ogni segmentu hè u `image_base` postu chì hè ciò chì dice u fugliale.
            //
            //
            // Per avà pare chì, à u cuntrariu di ELF/MachO, pudemu fassi cun un segmentu per biblioteca, aduprendu `modBaseSize` cum'è a dimensione sana.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS utilizza u furmatu di schedariu Mach-O è usa API specifiche à DYLD per caricare un elencu di biblioteche native chì facenu parte di l'applicazione.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Cerca u nome di sta libreria chì currisponde à u percorsu di duve cargarla ancu.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Caricate l'intestazione di l'imaghjini di sta libreria è delegate à `object` per analizà tutti i cumandamenti di carica per pudemu capì tutti i segmenti implicati quì.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Iterate nantu à i segmenti è registrate e regioni cunnisciute per i segmenti chì truvemu.
            // Inoltre registra l'infurmazioni nantu à i segmenti di testu per l'elaborazione dopu, vede i cumenti sottu
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Determinate u "slide" per questa biblioteca chì finisce per esse u preghjudiziu chì avemu usatu per capisce induve in memoria sò carichi oggetti.
            // Questu hè un pocu di calculu stranu quantunque è hè u risultatu di pruvà unepoche di cose in natura è di vede ciò chì ferma.
            //
            // L'idea generale hè chì u `bias` plus un segmentu `stated_virtual_memory_address` serà induve induve in u spaziu di indirizzu propiu u segmentu risiede.
            // L'altra cosa chì ci basemu hè chì un veru indirizzu menu u `bias` hè l'indice per circà in a tavula di simboli è in debuginfo.
            //
            // Si scopre, però, chì per e bibliuteche caricate in sistema sti calculi sò sbagliati.Per l'eseguibili nativi, però, pare currettu.
            // Alzendu una certa logica da a fonte di LLDB hà qualchì casing speciale per a prima sezione `__TEXT` caricata da u file offset 0 cù una dimensione diversa da zero.
            // Qualunque sia a ragione quandu questu hè presente, pare significà chì a tavula di simboli hè relativa à solu a diapositiva vmaddr per a biblioteca.
            // S'ellu hè *micca* presente allora a tavula di simbuli hè parente à u slide vmaddr più l'indirizzu dichjaratu di u segmentu.
            //
            // Per trattà sta situazione se *ùn* truvemu micca una sezzione di testu à u file offset zero allora aumentemu u preghjudiziu da l'indirizzu dichjaratu di e prime sezioni di testu è diminuemu ancu tutti l'indirizzi dichjarati di quella quantità.
            //
            // In questu modu a tavula di simboli hè sempre apparente relative à a quantità di preghjudiziu di a biblioteca.
            // Ciò pare avè i risultati ghjusti per simbolizà via a tavula di simboli.
            //
            // Onestamente ùn sò micca sicuramente sicuru se questu hè ghjustu o se ci hè qualcosa d'altru chì duverebbe indicà cumu fà questu.
            // Per avà, però, questu sembra funzionà abbastanza bè (?) è duvemu sempre esse capaci di modificà questu cù u tempu, se necessariu.
            //
            // Per alcuni più infurmazioni vedi #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Altri Unix (es
        // Piattaforme Linux) utilizanu ELF cum'è un furmatu di fugliale di ughjettu è tipicamente implementanu una API chjamata `dl_iterate_phdr` per caricare librerie native.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` duverebbe esse un indicatore validu.
        // `vec` deve esse un puntatore validu à un `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ùn sustene micca nativamente l'infurmazioni di debug, ma u sistema di custruisce piazzerà l'infurmazioni di debug in u percorsu `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Tuttu u restu duveria aduprà ELF, ma ùn sà micca cumu caricà e biblioteche native.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Tutte e biblioteche cumune cunnisciute chì sò state caricate.
    libraries: Vec<Library>,

    /// Mappings cache induve cunservemu l'informazione nana analizzata.
    ///
    /// Questa lista hà una capacità fissa per tuttu u so lifime chì ùn cresce mai.
    /// L'elementu `usize` di ogni coppia hè un indice in `libraries` sopra induve `usize::max_value()` rappresenta l'eseguibile attuale.
    ///
    /// U `Mapping` hè una infurmazione nana analizzata currispundente.
    ///
    /// Innota chì questu hè basicamente un cache LRU è cambieremu e cose intornu quì simbulizendu l'indirizzi.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segmenti di sta libreria caricati in memoria, è induve sò caricati.
    segments: Vec<LibrarySegment>,
    /// U "bias" di sta libreria, tipicamente induve hè caricatu in memoria.
    /// Stu valore hè aghjuntu à l'indirizzu dichjaratu di ogni segmentu per uttene l'indirizzu di memoria virtuale propiu chì u segmentu hè caricatu in.
    /// Inoltre stu preghjudiziu hè sustrattu da l'indirizzi di memoria virtuale vera per indexà in debuginfo è a tavula di simboli.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// L'indirizzu dichjaratu di questu segmentu in u fugliale di l'ughjettu.
    /// Questu ùn hè micca veramente induve u segmentu hè caricatu, ma piuttostu questu indirizzu più u `bias` di a biblioteca cuntenente hè induve truvà lu.
    ///
    stated_virtual_memory_address: usize,
    /// A dimensione di u segmentu in memoria.
    len: usize,
}

// periculosu perchè questu hè necessariu per esse sincronizatu esternamente
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // periculosu perchè questu hè necessariu per esse sincronizatu esternamente
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Un cache LRU assai chjucu, assai sèmplice per i mappaggi di l'infurmazione di debug.
        //
        // U tassu di successu deve esse assai altu, postu chì a pila tipica ùn attraversa micca parechje biblioteche cumune.
        //
        // E strutture `addr2line::Context` sò abbastanza costose da creà.
        // Hè previstu chì u so costu sia ammortizatu da e successive richieste `locate`, chì sfruttanu e strutture custruite quandu si custruisce `addr2line: : Context`s per uttene belle accelerazioni.
        //
        // Se ùn avissimu micca sta cache, quellu ammortamentu ùn accaderebbe mai, è e tracce di ritornu simboliche seranu ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Prima, pruvate se stu `lib` hà un segmentu chì cuntene u `addr` (manipulazione di trasferimentu).Se sta verificazione passa allora pudemu cuntinuà quì sottu è traduce in realtà l'indirizzu.
                //
                // Innota chì avemu aduprà `wrapping_add` quì per evità cuntrolli di overflow.Hè statu vistu in natura chì u computazione di preghjudiziu SVMA + si trabocca.
                // Sembra un pocu stranu chì accaderebbe ma ùn ci hè micca una quantità enorme chì pudemu fà per quessa, fora di probabilmente solu ignorà questi segmenti, postu chì sò probabilmente indicati in u spaziu.
                //
                // Questu urigginariu hè ghjuntu in rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Avà chì sapemu chì `lib` cuntene `addr`, pudemu compensà cù u preghjudiziu per truvà l'indirizzu di memoria virutale dichjaratu.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariante: dopu stu cundiziunale si compie senza ritornu anticipatu
        // da un errore, l'entrata di cache per questu percorsu hè à l'indice 0.

        if let Some(idx) = idx {
            // Quandu a cartografia hè dighjà in cache, muvitela in fronte.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Quandu a cartografia ùn hè micca in cache, crea una nova cartografia, inseritila in a parte anteriore di a cache, è sfrattate a più antica entrata cache se necessariu.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // ùn perde micca a vita `'static`, assicuratevi chì sia scopu solu per noi stessi
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Prolungate a vita di `sym` à `'static` postu chì sfurtunatamente ci hè dumandatu quì, ma hè sempre surtitu cum'è riferimentu dunque nisuna riferenza à questu deve esse persista al di là di stu quadru quantunque.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Infine, uttene una cartografia in cache o crea una nova cartografia per stu fugliale, è valutate l'infurmazioni DWARF per truvà u file/line/name per questu indirizzu.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Avemu statu capace di truvà l'infurmazioni di u quadru per questu simbulu, è u quadru di "addr2line" hà in l'internu tutti i dettagli graziosi.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Ùn pudemu micca truvà l'infurmazione di debug, ma l'avemu trovu in a tavula di simboli di l'eseguibile elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}