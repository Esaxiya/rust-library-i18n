//! Strategia di simbolica cù u codice DWARF-parsing in libbacktrace.
//!
//! A libreria C libbacktrace, tipicamente distribuita cù gcc, supporta micca solu a generazione di un retrotrascorsu (chì ùn usemu micca in realtà) ma simbulizeghja dinò u ritrattu di ritruvamentu è a gestione di l'infurmazioni di debug nanu nantu à e cose cum'è i fotogrammi inline è qualcosa.
//!
//!
//! Questu hè relativamente cumplicatu per via di parechje preoccupazioni quì, ma l'idea di basa hè:
//!
//! * Prima chjamemu `backtrace_syminfo`.Questu uttene informazioni di simboli da a tavula di simboli dinamichi se pudemu.
//! * Dopu chjamemu `backtrace_pcinfo`.Questu analizerà e tàvule di debuginfo se sò dispunibili è ci permettenu di recuperà informazioni nantu à i fotogrammi in linea, i nomi di file, i numeri di linea, ecc.
//!
//! Ci hè assai ingannamentu per uttene i tavuli nani in libbacktrace, ma speremu chì ùn sia micca a fine di u mondu è hè abbastanza chjaru quandu si leghje quì sottu.
//!
//! Questa hè a strategia di simbolica predefinita per e piattaforme non MSVC è non OSX.In libstd però questu hè a strategia predefinita per OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Sè pussibule preferite u nome `function` chì vene da debuginfo è pò esse tipicamente più accuratu per i fotogrammi in linea per esempiu.
                // S'ellu ùn hè micca prisente quantunque torna à u nome di a tavula simbulu specificatu in `symname`.
                //
                // Nutate bè chì qualchì volta `function` pò sentesi un pocu menu precisu, per esempiu esse elencatu cum'è `try<i32,closure>` ùn hè micca capu di `std::panicking::try::do_call`.
                //
                // Ùn hè micca veramente chjaru perchè, ma in generale u nome `function` pare più precisu.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ùn fà nunda per avà
}

/// Tipu di puntatore `data` passatu in `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Una volta chì sta richiamata hè invucata da `backtrace_syminfo` quandu cuminciamu à risolve andemu più luntanu per chjamà `backtrace_pcinfo`.
    // A funzione `backtrace_pcinfo` cunsulterà l'infurmazioni di debug è attemp tto to do things like recover file/line information as well as frames inline.
    // Innota ancu chì `backtrace_pcinfo` pò fallu o micca fà assai se ùn ci hè micca infurmazione di debug, allora se accade, simu sicuri di chjamà a richiamata cù almenu un simbulu da u `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Tipu di puntatore `data` passatu in `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// L'API libbacktrace supporta a creazione di un statu, ma ùn supporta micca a distruzzione di un statu.
// Personalmente pigliu questu per significà chì un statu hè destinatu à esse creatu è dopu campà per sempre.
//
// Mi piacerebbe registrà un gestore at_exit() chì pulisce questu statu, ma libbacktrace ùn furnisce micca manera di fà.
//
// Cù queste limitazioni, sta funzione hà un statu staticamente in cache chì hè calculatu a prima volta chì questu hè dumandatu.
//
// Arricurdatevi chì u backtracing tuttu accade in serie (una serratura glubale).
//
// Nota chì a mancanza di sincronizazione hè duvuta à u requisitu chì `resolve` sia sincronizatu esternamente.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Ùn esercitate micca e capacità threadsafe di libbacktrace postu chì a chjamemu sempre in modu sincronizatu.
        //
        0,
        error_cb,
        ptr::null_mut(), // senza dati in più
    );

    return STATE;

    // Innota chì per libbacktrace per operà in tuttu, hà bisognu di truvà l'infurmazioni di debug DWARF per l'eseguibile attuale.Di solitu face ciò per mezu di una serie di meccanismi chì includenu, ma micca limitatu à:
    //
    // * /proc/self/exe nantu à e piattaforme supportate
    // * U nome di u filu hè passatu in modu esplicitu quandu crea u statu
    //
    // A libreria libbacktrace hè un grande wad di codice C.Ciò significa naturalmente chì hà vulnerabilità di sicurezza in memoria, soprattuttu quandu si tratta di debuginfo malformatu.
    // Libstd hà scappatu assai di questi storicamente.
    //
    // Se /proc/self/exe hè adupratu allora pudemu tipicamente ignorà questi cume supponemu chì libbacktrace sia "mostly correct" è altrimenti ùn faci cose strane cù l'infurmazione di debug nanu "attempted to be correct".
    //
    //
    // Se passemu in un nome di schedariu, però, allora hè pussibule in alcune piattaforme (cum'è BSD) induve un attore maliziosu pò causà un fugliale arbitrariu per esse piazzatu in quellu locu.
    // Ciò significa chì, se dicemu libbacktrace nantu à un nome di file, pò esse aduprendu un file arbitrariu, forse causendu segfaults.
    // Se ùn dicemu nunda à libbacktrace, allora ùn farà nunda in e piattaforme chì ùn supportanu micca percorsi cum'è /proc/self/exe!
    //
    // Datu tuttu ciò chì pruvemu u più pussibule à *micca* passà in un nome di schedariu, ma duvemu nantu à e piattaforme chì ùn supportanu micca /proc/self/exe affattu.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Innota chì idealmente avemu aduprà `std::env::current_exe`, ma ùn pudemu micca bisognu di `std` quì.
            //
            // Aduprate `_NSGetExecutablePath` per carregà u percorsu eseguibile attuale in una zona statica (chì s'ellu hè troppu chjucu solu rinuncia).
            //
            //
            // Innota chì avemu fiducia seriu in libbacktrace quì per ùn more nantu à eseguibili corrotti, ma sicuramente sì ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows hà un modu di apertura di file induve dopu avè apertu ùn pò micca esse cancellatu.
            // Hè in generale ciò chì vulemu quì perchè vulemu assicurà chì u nostru esecutivu ùn cambiessi da sottu à noi dopu chì l'avemu tramandatu à libbacktrace, sperendu mitigendu a capacità di passà in dati arbitrarii in libbacktrace (chì pò esse trattatu male).
            //
            //
            // Datu chì femu un pocu di ballu quì per pruvà à ottene una sorta di serratura à a nostra maghjina:
            //
            // * Uttenite una maniglia di u prucessu attuale, caricate u so nome di schedariu.
            // * Apri un fugliale à quellu nome di fugliale cù e bandiere ghjuste.
            // * Ricaricà u nome di schedariu di u prucedimentu attuale, assicurendu chì hè listessu
            //
            // Sì tuttu passa noi in teoria avemu daveru apertu u fugliale di u nostru prucessu è avemu a garanzia chì ùn cambierà micca.FWIW una mansa di questu hè copiata da libstd storicamente, allora questa hè a mo migliore interpretazione di ciò chì stava accadendu.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Questu vive in memoria statica per pudemu rende lu ..
                static mut BUF: [i8; N] = [0; N];
                // ... è questu vive nantu à a pila postu chì hè temporanea
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // perde intenzionalmente `handle` quì perchè avè quellu apertu deve cunservà a nostra serratura nant'à stu nome di schedariu.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Vulemu restituisce una fetta chì hè nul-terminated, allora se tuttu hè statu riempitu è uguale à a lunghezza totale allora uguale à u fallimentu.
                //
                //
                // Altrimenti, quandu riturnate u successu, assicuratevi chì u nul byte hè inclusu in a fetta.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // errori di rintraccia sò attualmente spazzati sottu u tappettu
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Chjamate l'API `backtrace_syminfo` chì (da a lettura di u codice) deve chjamà `syminfo_cb` esattamente una volta (o falla cun un errore presumibilmente).
    // Dopu trattemu più in u `syminfo_cb`.
    //
    // Nota chì femu questu postu chì `syminfo` cunsulterà a tavula di simboli, truvendu nomi di simbuli ancu s'ellu ùn ci hè nisuna infurmazione di debug in u binariu.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}