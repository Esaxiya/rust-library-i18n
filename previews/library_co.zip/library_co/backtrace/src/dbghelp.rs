//! Un modulu per aiutà à gestisce i ligami dbghelp nantu à Windows
//!
//! I Backtraces in Windows (almenu per MSVC) sò largamente alimentati per `dbghelp.dll` è e varie funzioni chì cuntene.
//! Queste funzioni sò attualmente caricate *dinamicamente* piuttostu chè ligà staticamente à `dbghelp.dll`.
//! Questu hè attualmente fattu da a biblioteca standard (è in teoria hè necessariu quì), ma hè un sforzu per aiutà à riduce e dipendenze statiche di dll di una libreria postu chì i retrotrascrizzioni sò tipicamente abbastanza facoltativi.
//!
//! Dittu chistu, `dbghelp.dll` guasi sempre carica cù successu in Windows.
//!
//! Innota quantunque chì postu chì carichemu tuttu stu sustegnu dinamicamente ùn pudemu micca usà in realtà e definizioni grezze in `winapi`, ma piuttostu ci vole à definisce noi stessi i tippi di puntatore di funzione è aduprà quellu.
//! Ùn vulemu micca veramente esse in l'attività di duplicà winapi, allora avemu una funzione Cargo `verify-winapi` chì afferma chì tutte e ligature corrispondenu à quelle in winapi è chì questa funzione hè attivata in CI.
//!
//! Infine, noterete quì chì u dll per `dbghelp.dll` ùn hè mai scaricatu, è chì hè attualmente intenzionale.
//! U penseru hè chì pudemu cache lu in u mondu è aduprà trà chjamate à l'API, evitendu loads/unloads costosi.
//! S'ellu hè un prublema per i rivelatori di perdite o qualcosa di simile pudemu attraversà u ponte quandu ghjunghjemu quì.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// U travagliu intornu à `SymGetOptions` è `SymSetOptions` chì ùn sò micca presenti in winapi stessu.
// Altrimenti questu hè adupratu solu quandu simu cuntrollendu i tippi contr'à winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Micca definitu in winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Questu hè definitu in winapi, ma hè incorrettu (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Micca definitu in winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Questa macro hè aduprata per definisce una struttura `Dbghelp` chì cuntene internamente tutti i punti di funzione chì pudemu caricare.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// A DLL caricata per `dbghelp.dll`
            dll: HMODULE,

            // Ogni puntatore di funzione per ogni funzione pudemu aduprà
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Inizialmente ùn avemu micca caricatu a DLL
            dll: 0 as *mut _,
            // Initiall tutte e funzioni sò messe à zeru per dì ch'elli devenu esse caricati dinamicamente.
            //
            $($name: 0,)*
        };

        // Convenience typedef per ogni tippu di funzione.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Pruvate d'apre `dbghelp.dll`.
            /// Restituisce u successu se funziona o errore se `LoadLibraryW` falla.
            ///
            /// Panics se a biblioteca hè dighjà caricata.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funzione per ogni metudu chì vulemu usà.
            // Quandu u chjamerà leghjerà u puntatore di a funzione in cache o u caricherà è restituverà u valore caricatu.
            // I carichi sò affirmati per riesce.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Cunvenzione proxy per aduprà i lucchetti di pulizia per riferisce à e funzioni dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inizializà tuttu u supportu necessariu per accede à e funzioni `dbghelp` API da questu crate.
///
///
/// Nutate bè chì sta funzione hè **sicura**, hà internamente a so propria sincronizazione.
/// Innota ancu chì hè sicuru di chjamà sta funzione più volte recursivamente.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Prima cosa chì duvemu fà hè di sincronizà sta funzione.Questa pò esse chjamata simultaneamente da altri fili o recursivamente in un filu.
        // Innota chì hè più complicatu di questu perchè perchè ciò chì avemu usatu quì, `dbghelp`,*ancu* deve esse sincronizatu cù tutti l'altri chjamanti à `dbghelp` in questu prucessu.
        //
        // Tipicamente ùn ci sò micca veramente tante chjamate à `dbghelp` in u stessu prucessu è pudemu probabilmente suppone di manera sicura chì simu i soli à accede.
        // Ci hè, tuttavia, un altru utilizatore primariu chì duvemu preoccupassi chì hè ironicamente noi stessi, ma in a biblioteca standard.
        // A libreria standard Rust dipende da questu crate per supportu di retrotrascrizione, è questu crate esiste ancu in crates.io.
        // Questu significa chì se a biblioteca standard stampa una panic retrotrascala pò correre cù questu crate chì vene da crates.io, causendu segfaults.
        //
        // Per aiutà à risolve stu prublema di sincronizazione adupremu quì un truccu specificu per Windows (hè, dopu tuttu, una restrizione specifica per Windows in quantu à a sincronizazione).
        // Creemu un *session-local* chjamatu mutex per prutege sta chjamata.
        // L'intenzione quì hè chì a biblioteca standard è questu crate ùn anu micca da sparte API di livellu Rust per sincronizà quì, ma ponu invece travaglià dietro le quinte per assicurassi chì si sincronizanu l'uni cun l'altri.
        //
        // In questu modu quandu sta funzione hè chjamata per mezu di a libreria standard o per crates.io pudemu esse sicuri chì u stessu mutex hè acquistatu.
        //
        // Dunque tuttu què vole dì chì a prima cosa chì femu quì hè di creà atomicamente un `HANDLE` chì hè un mutex chjamatu in Windows.
        // Simu sincronizati un pocu cù altri fili chì spartenu specificamente sta funzione è assicuremu chì una sola maniglia sia creata per istanza di sta funzione.
        // Innota chì u manicu ùn hè mai chjosu una volta chì hè guardatu in u mondu.
        //
        // Dopu avemu andatu in verità a serratura, simu solu l'acquistemu, è a nostra maniglia `Init` chì distribuiremu serà incaricata di lascià finisce.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Va bè, phew!Avà chì simu tutti sincronizzati in modu sicuru, cuminciamu à trattà tuttu.
        // Prima ci vole à assicurà chì `dbghelp.dll` sia effettivamente caricatu in questu prucessu.
        // Facemu questu dinamicamente per evità una dipendenza statica.
        // Questu hè statu storicamente fattu per travaglià intornu à prublemi di cunnessione strani è hè destinatu à rende i binari un pocu più portatili postu chì questu hè in gran parte solu una utilità di debugging.
        //
        //
        // Una volta avemu apertu `dbghelp.dll`, avemu bisognu di chjamà alcune funzioni di inizializazione in questu, è questu hè dettagliato più sottu.
        // Facemu solu una volta, però, cusì avemu un booleanu glubale chì indica se avemu finitu o micca.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Assicuratevi chì a bandiera `SYMOPT_DEFERRED_LOADS` sia piazzata, perchè secondu i documenti di MSVC nantu à questu: "This is the fastest, most efficient way to use the symbol handler.", allora femu què!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // In realtà inizializza simboli cù MSVC.Innota chì questu pò fallu, ma l'ignuremu.
        // Ùn ci hè micca una tonna d'arte precedente per questu per se, ma LLVM internamente pare ignorà u valore di ritornu quì è una di e biblioteche di disinfettanti in LLVM stampa un avvertimentu spaventosu se questu fiasca ma basicamente l'ignora à longu andà.
        //
        //
        // Un casu questu vene assai per Rust hè chì a biblioteca standard è questu crate nantu à crates.io vogliono entrambi competere per `SymInitializeW`.
        // A biblioteca standard hà vulsutu storicamente inizializà poi pulisce a maiò parte di u tempu, ma avà chì utilizza stu crate significa chì qualcunu ghjunghjerà prima à l'inizializazione è l'altru ripiglierà quella inizializazione.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}