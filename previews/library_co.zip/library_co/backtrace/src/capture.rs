use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Rapresentazione di una traccia di ritornu pusseduta è autonoma.
///
/// Questa struttura pò esse aduprata per catturà un ritrattu in vari punti di un prugramma è poi usata per ispezionà ciò chì era u ritrattu in quellu tempu.
///
///
/// `Backtrace` supporta una bella stampa di backtraces attraversu a so implementazione `Debug`.
///
/// # Funzioni richieste
///
/// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // I quadri quì sò elencati da cima à fondu di a pila
    frames: Vec<BacktraceFrame>,
    // L'indice chì cridemu hè l'iniziu propiu di u retrotrascorsu, omittendu frames cum'è `Backtrace::new` è `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Versione catturata di un quadru in un retrotrascorsu.
///
/// Stu tipu hè restituitu cum'è una lista da `Backtrace::frames` è rapprisenta un quadru di pila in un retrotrasessu catturatu.
///
/// # Funzioni richieste
///
/// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Versione catturata di un simbulu in un ritrattu.
///
/// Stu tipu hè restituitu cum'è una lista da `BacktraceFrame::symbols` è riprisenta i metadati per un simbulu in un retrotrasessu.
///
/// # Funzioni richieste
///
/// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Cattura un ritrattu in u callsite di sta funzione, restituendu una rapprisintazione di pruprietà.
    ///
    /// Sta funzione hè utile per rapprisentà un retrotrascorsu cum'è oggettu in Rust.Stu valore restituitu pò esse inviatu à traversu i fili è stampatu in altrò, è u scopu di stu valore hè di esse interamente autocuntenutu.
    ///
    /// Innota chì nantu à alcune piattaforme chì acquistanu un retrotrasessu cumpletu è a risolvenu pò esse estremamente caru.
    /// Se u costu hè troppu per a vostra applicazione, hè cunsigliatu d'utilizà invece `Backtrace::new_unresolved()` chì evita u passu di risoluzione di simbuli (chì tipicamente dura u più longu) è permette di rinviallu à una data successiva.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Funzioni richieste
    ///
    /// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // vogliu assicurà chì ci sia un quadru quì da caccià
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Simile à `new` eccettu chì questu ùn risolve alcun simbulu, questu semplicemente cattura a traccia di ritornu cum'è una lista di indirizzi.
    ///
    /// Più tardi a funzione `resolve` pò esse chjamata per risolve i simboli di sta retrotrascrizzione in nomi leghjibili.
    /// Sta funzione esiste perchè u prucessu di risuluzione pò à volte piglià una quantità significativa di tempu mentre chì una sola retrotrascrizione pò esse stampata raramente solu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // senza nomi di simbuli
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // nomi di simbuli avà prisenti
    /// ```
    ///
    /// # Funzioni richieste
    ///
    /// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
    ///
    ///
    ///
    #[inline(never)] // vogliu assicurà chì ci sia un quadru quì da caccià
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Restituisce i fotogrammi da quandu sta traccia di ritornu hè stata catturata.
    ///
    /// A prima entrata di sta fetta hè prubabile a funzione `Backtrace::new`, è l'ultimu quadru hè prubabile qualcosa di cumu stu filu o a funzione principale hà iniziatu.
    ///
    ///
    /// # Funzioni richieste
    ///
    /// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Se stu ritrattu hè statu creatu da `new_unresolved` allora sta funzione risolverà tutti l'indirizzi in u retrotrasessu per i so nomi simbolichi.
    ///
    ///
    /// Se sta retrotrascrizzione hè stata risolta prima o hè stata creata attraversu `new`, sta funzione ùn face nunda.
    ///
    /// # Funzioni richieste
    ///
    /// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Listessu chè `Frame::ip`
    ///
    /// # Funzioni richieste
    ///
    /// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Listessu chè `Frame::symbol_address`
    ///
    /// # Funzioni richieste
    ///
    /// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Listessu chè `Frame::module_base_address`
    ///
    /// # Funzioni richieste
    ///
    /// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Restituisce l'elencu di simbuli chì currisponde à stu quadru.
    ///
    /// Nurmalmente ci hè solu un simbulu per quadru, ma qualchì volta sì un certu numeru di funzioni sò inline in un quadru allora parechji simbuli seranu restituiti.
    /// U primu simbulu elencatu hè u "innermost function", invece chì l'ultimu simbulu hè u più esterno (l'ultimu chjamante).
    ///
    /// Nutate bè chì sè stu quatru venia da una traccia di ritornu irrisolvuta allora questu restituverà una lista viota.
    ///
    /// # Funzioni richieste
    ///
    /// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Listessu chè `Symbol::name`
    ///
    /// # Funzioni richieste
    ///
    /// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Listessu chè `Symbol::addr`
    ///
    /// # Funzioni richieste
    ///
    /// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Listessu chè `Symbol::filename`
    ///
    /// # Funzioni richieste
    ///
    /// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Listessu chè `Symbol::lineno`
    ///
    /// # Funzioni richieste
    ///
    /// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Listessu chè `Symbol::colno`
    ///
    /// # Funzioni richieste
    ///
    /// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Quandu stampemu i percorsi circhemu di spoglia u cwd s'ellu esiste, altrimenti simu solu stampà u percorsu cumu hè.
        // Innota chì femu dinò solu per u furmatu cortu, perchè s'ellu hè pienu vulemu presumibilmente stampà tuttu.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}