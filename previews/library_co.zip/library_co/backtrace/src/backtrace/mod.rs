use core::ffi::c_void;
use core::fmt;

/// Ispeziona l'attuale call-stack, passendu tutti i fotogrammi attivi in a chiusura prevista per calculà una traccia di stack.
///
/// Sta funzione hè u cavallu di travagliu di sta biblioteca in u calculu di e tracce di stack per un prugramma.A chiusura data `cb` hè ceduta istanze di un `Frame` chì rapprisentanu informazioni nantu à quellu quadru di chjamata in u stack.
/// A chjusura hè resa frames in una moda top-down (più recentemente chjamate funzioni prima).
///
/// U valore di ritornu di a chjusura hè un'indicazione di se u retrotrasessu duveria cuntinuà.Un valore di ritornu di `false` finirà u retrotrascorsu è u ritornu immediatamente.
///
/// Una volta chì un `Frame` hè acquistatu probabilmente vulete chjamà `backtrace::resolve` per cunvertisce u `ip` (puntatore d'istruzzioni) o l'indirizzu di u simbulu in un `Symbol` attraversu u quale u nome è/o nome di filu/numeru di linea pò esse amparatu.
///
///
/// Nutate bè chì si tratta di una funzione di livellu relativamente bassu è chì, per esempiu, vulete catturà un ritrattu per esse ispezionatu dopu, allora u tippu `Backtrace` pò esse più adattu.
///
/// # Funzioni richieste
///
/// Questa funzione richiede a funzione `std` di `backtrace` crate per esse attivata, è a funzione `std` hè attivata per difettu.
///
/// # Panics
///
/// Sta funzione s'impegna à ùn mai panic, ma se u `cb` hà furnitu panics allora alcune piattaforme furzeranu un doppiu panic per abbandunà u prucessu.
/// Alcune piattaforme utilizanu una libreria C chì utilizza internamente callbacks chì ùn ponu micca esse sbulicati, dunque u panicu da `cb` pò attivà un abortu di prucessu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // cuntinuà u ritrattu
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Listessu cum'è `trace`, solu periculosu perchè ùn hè micca sincronizatu.
///
/// Sta funzione ùn hà micca garantiti di sincronizazione ma hè dispunibule quandu a funzione `std` di stu crate ùn hè micca compilata in.
/// Vede a funzione `trace` per più documentazione è esempi.
///
/// # Panics
///
/// Vede l'infurmazioni nantu à `trace` per avvertenze nantu à u panicu `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Un trait chì rapprisenta un quadru di retrotrascorsu, cedutu à a funzione `trace` di stu crate.
///
/// A chjusura di a funzione di traccia serà resa frames, è u frame hè virtualmente speditu postu chì l'implementazione sottostante ùn hè micca sempre cunnisciuta finu à u runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Restituisce u puntatore d'istruzzioni attuale di stu quadru.
    ///
    /// Questa hè nurmalmente a prossima istruzzione da eseguisce in u quadru, ma micca tutte l'implementazioni listanu questu cun precisione 100% (ma hè generalmente abbastanza vicina).
    ///
    ///
    /// Hè cunsigliatu di passà stu valore à `backtrace::resolve` per trasformallu in un nome di simbulu.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Restituisce u puntatore di stack attuale di stu quadru.
    ///
    /// In u casu chì un backend ùn pò micca recuperà u puntatore stack per questu quadru, un puntatore nulu hè restituitu.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Restituisce l'indirizzu iniziale di u simbulu di u quadru di sta funzione.
    ///
    /// Questu pruvarà à riavviare u puntatore d'istruzione restituitu da `ip` à l'iniziu di a funzione, restituendu quellu valore.
    ///
    /// In certi casi, tuttavia, i backends restituiranu solu `ip` da sta funzione.
    ///
    /// U valore restituitu pò esse adupratu qualchì volta se `backtrace::resolve` hà fiascatu nantu à u `ip` datu sopra.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Restituisce l'indirizzu di basa di u modulu à quale appartene u quadru.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Questu deve vene prima, per assicurà chì Miri piglia a priorità nantu à a piattaforma ospitante
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // adupratu solu in dbghelp simbolizza
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}