use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr piglia un callback chì riceverà un puntatore dl_phdr_info per ogni DSO chì hè statu ligatu à u prucessu.
    // dl_iterate_phdr assicura ancu chì u ligame dinamicu sia bluccatu da u principiu à a fine di l'iterazione.
    // Se u callback restituisce un valore diversu da zero, l'iterazione hè finita prima.
    // 'data' serà passatu cum'è u terzu argumentu à u callback in ogni chjamata.
    // 'size' dà a dimensione di u dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Avemu bisognu di analisà l'ID di compilazione è alcuni dati di basa di l'intestazione di u prugramma chì significa chì avemu bisognu di un pocu di roba da a specifica ELF dinò.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Avà duvemu riplicà, bit per bit, a struttura di u tippu dl_phdr_info aduprata da l'attuali linker dinamicu di fucsia.
// Chromium hà ancu questu limite ABI è crashpad.
// Eventualmente ci piacerebbe spostà questi casi per aduprà elf-search ma averiamu bisognu di furnisce quellu in u SDK è chì ùn hè ancu statu fattu.
//
// Cusì noi (è elli) sò bluccati à avè da aduprà stu metudu chì incorre in un accoppiamentu strettu cù u fucsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Ùn avemu micca manera di sapè di verificà se e_phoff è e_phnum sò validi.
    // libc deve assicurà questu per noi, dunque hè sicuru di formà una fetta quì.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr rapprisenta un header di prugramma ELF 64-bit in l'endianness di l'architettura di destinazione.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr riprisenta un capu di prugramma ELF validu è u so cuntenutu.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Ùn avemu micca manera di verificà se p_addr o p_memsz sò validi.
    // U libc di Fuchsia analizza e note prima, dunque, in virtù di esse quì, queste intestazioni devenu esse valide.
    //
    // NoteIter ùn richiede micca chì i dati sottostanti sianu validi ma richiede chì i limiti sianu validi.
    // Speremu chì libc hà assicuratu chì questu hè u casu per noi quì.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// U tippu di nota per ID di compilazione.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr rapprisenta un header di nota ELF in l'endianness di u target.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Nota riprisenta una nota ELF (intestazione + cuntenutu).
// U nome hè lasciatu cum'è una fetta u8 perchè ùn hè micca sempre terminata nulla è rust facilita abbastanza per verificà chì i bytes currispondenu in ogni casu.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter vi permette di iterà in modu sicuru in un segmentu di note.
// Finisce appena si verifica un errore o ùn ci sò più note.
// Se iterate nantu à i dati invalidi, funziona cum'è se nisuna nota ùn sia stata trovata.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Hè un invariante di funzione chì u puntatore è a dimensione dati denotanu una gamma valida di bytes chì ponu esse tutti letti.
    // U cuntenutu di questi bytes pò esse qualsiasi, ma a gamma deve esse valida per chì questu sia sicuru.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to alignes 'x' à "to'-byte alignment assumendu chì 'to' hè una putenza di 2.
// Questu segue un mudellu standard in C/C ++ ELF parsing code induve (x + à, 1)&-to hè adupratu.
// Rust ùn vi lascia micca negà usize allora usu
// Cunversione di 2-cumplementu per ricreà quellu.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 cunsuma num bytes da a fetta (se presente) è assicura in più chì a fetta finale sia allineata currettamente.
// S'ellu hè u numeru di byte richiesti hè troppu grande o a fetta ùn pò micca esse riallineata dopu per via chì ùn esiste micca abbastanza bytes restanti, Nimu hè restituitu è a fetta ùn hè micca mudificata.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Sta funzione ùn hà micca invarianti veri chì u chjamante deve difende fora di forse chì 'bytes' duveria esse alliniatu per e prestazioni (è nantu à certe architetture currette).
// I valori in i campi Elf_Nhdr ponu esse assurdità ma sta funzione ùn assicura nunda.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Questu hè sicuru fintantu chì ci hè abbastanza spaziu è avemu solu cunfirmatu chì in a dichjarazione if sopra cusì ùn deve micca esse periculosa.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Nota chì sice_of: :<Elf_Nhdr>() hè sempre allinatu à 4 byte.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Verificate se avemu arrivatu à a fine.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Trasformemu un nhdr ma cunsideremu attentamente a struttura resultante.
        // Ùn avemu micca fiducia in u namesz o descsz è ùn pigliamu micca decisioni periculose basatu annantu à u tippu.
        //
        // Dunque, ancu se esciemu spazzatura cumpleta duvemu sempre esse salvi.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Indica chì un segmentu hè eseguibile.
const PERM_X: u32 = 0b00000001;
/// Indica chì un segmentu hè scrittu.
const PERM_W: u32 = 0b00000010;
/// Indica chì un segmentu hè leggibile.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Rappresenta un segment ELF in runtime.
struct Segment {
    /// Dà l'indirizzu virtuale di runtime di i cuntenuti di questu segmentu.
    addr: usize,
    /// Dà a dimensione di memoria di u cuntenutu di questu segmentu.
    size: usize,
    /// Dà l'indirizzu virtuale di u modulu di questu segmentu cù u fugliale ELF.
    mod_rel_addr: usize,
    /// Dà i permessi truvati in u fugliale ELF.
    /// Quessi permessi ùn sò micca necessariamente i permessi presenti in runtime però.
    flags: Perm,
}

/// Permette una iterazione nantu à i Segmenti da un DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Rapprisenta un ELF DSO (Ughjettu Cumunu Dinamicu).
/// Stu tippu face riferenza à i dati archiviati in u DSO propiu invece di fà a so propria copia.
struct Dso<'a> {
    /// U ligame dinamicu ci dà sempre un nome, ancu sì u nome hè viotu.
    /// In u casu di l'eseguibile principale stu nome serà vacante.
    /// In u casu di un ughjettu cumunu serà u soname (vede DT_SONAME).
    name: &'a str,
    /// In Fuchsia guasi tutti i binari anu ID di custru, ma questu ùn hè micca un rigore rigrettu.
    /// Ùn ci hè manera di assucià l'infurmazioni DSO cun un veru fugliale ELF dopu s'ellu ùn ci hè micca build_id allora avemu bisognu chì ogni DSO ne abbia unu quì.
    ///
    /// I DSO senza build_id sò ignorati.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Restituisce un iteratore nantu à i Segmenti in questu DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Questi errori codificanu i prublemi chì si presentanu mentre analizzanu l'infurmazioni nantu à ogni DSO.
///
enum Error {
    /// NameError significa chì un errore hè accadutu durante a cunversione di una stringa di stile C in una stringa rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError significa chì ùn avemu micca truvatu un ID di compilazione.
    /// Questu puderebbe esse perchè u DSO ùn avia micca ID di compilazione o perchè u segmentu chì cuntene l'ID di compilazione era malformatu.
    ///
    BuildIDError,
}

/// Chjama 'dso' o 'error' per ogni DSO ligatu à u prucessu da u ligame dinamicu.
///
///
/// # Arguments
///
/// * `visitor` - Un DsoPrinter chì avarà unu di i metudi di manghjà chjamati per ogni DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr assicura chì info.name punterà versu un locu validu.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Questa funzione stampa u marcatu di u simbolizatore Fuchsia per tutte l'infurmazioni cuntenute in un DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}