# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Una libreria per l'acquistu di backtraces in runtime per Rust.
Questa biblioteca hà u scopu di migliorà u supportu di a biblioteca standard fornendu un'interfaccia prugrammatica per travaglià, ma supporta ancu semplicemente stampà facilmente a traccia attuale cum'è panics di libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Per semplicemente catturà un retrotrascorsu è rinviate à trattà cun ellu finu à un mumentu dopu, pudete aduprà u tippu `Backtrace` di primu livello.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Tuttavia, se vulete più accessu crudu à a funzionalità di tracciatura attuale, pudete aduprà direttamente e funzioni `trace` è `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Risolve questu puntatore d'istruzzioni à un nome di simbulu
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // cuntinuvà à u prossimu quadru
    });
}
```

# License

Stu prughjettu hè licenziatu sottu à unu di i dui

 * Licenza Apache, Versione 2.0, ([LICENSE-APACHE](LICENSE-APACHE) o http://www.apache.org/licenses/LICENSE-2.0)
 * Licenza MIT ([LICENSE-MIT](LICENSE-MIT) o http://opensource.org/licenses/MIT)

à a vostra scelta.

### Contribution

A menu chì ùn dicite micca esplicitamente altrimenti, qualsiasi cuntribuzione intenzionalmente presentata per l'inclusione in backtrace-rs da voi, cum'è definita in a licenza Apache-2.0, serà licenziata duale cum'è sopra, senza alcun termini o cundizioni addiziunali.







