# U `rustc-std-workspace-core` crate

Questu crate hè un crate shim è vacante chì dipende solu da `libcore` è riesporta tuttu u so cuntenutu.
U crate hè u core di empowering a biblioteca standard per dipende da crates da crates.io

Crates nantu à crates.io chì a biblioteca standard dipende da a necessità di dipende da u `rustc-std-workspace-core` crate da crates.io, chì hè viotu.

Adupremu `[patch]` per annullallu in questu crate in questu repository.
Di conseguenza, crates nantu à crates.io tirerà una dipendenza edge à `libcore`, a versione definita in questu repository.
Chì duverebbe disegnà tutti i bordi di dipendenza per assicurà chì Cargo custruisce crates cù successu!

Innota chì crates nantu à crates.io hà bisognu di dipende da questu crate cù u nome `core` per chì tuttu funziona currettamente.Per fà ciò ponu aduprà:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Attraversu l'usu di a chjave `package` u crate hè rinominatu in `core`, significendu chì pare

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

quandu Cargo invoca u compilatore, suddisfendu a direttiva `extern crate core` implicita injettata da u compilatore.




