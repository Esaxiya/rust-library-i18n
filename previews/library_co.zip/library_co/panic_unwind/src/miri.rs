//! Unwinding panics per Miri.
use alloc::boxed::Box;
use core::any::Any;

// U tippu di carica utile chì u mutore Miri si propaga attraversu u rilassamentu per noi.
// Deve esse dimensione di l'indicatore.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Funzione esterna furnita da Miri per cumincià à rilassassi.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // A carica utile chì passemu à `miri_start_panic` serà esattamente l'argumentu chì avemu in `cleanup` sottu.
    // Allora u boxemu solu una volta, per uttene qualcosa di dimensione di puntatore.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Ritruvate u `Box` sottostante.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}