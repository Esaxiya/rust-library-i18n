//! Svolgimentu per u scopu *emscripten*.
//!
//! Mentre chì a solita implementazione di sbloccamentu di Rust per e piattaforme Unix chjama direttamente à l'API libunwind, in Emscripten chjamemu invece in l'APIs di sbloccamentu C++ .
//! Questa hè solu una spidienza postu chì u runtime di Emscripten implementa sempre quelle API è ùn implementa micca libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Questu currisponde à u schema di std::type_info in C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // U primu byte `\x01` quì hè in realtà un signale magicu à LLVM per *ùn* applicà alcuna altra mangiatura cum'è prefissazione cù un caratteru `_`.
    //
    //
    // Stu simbulu hè a vtable aduprata da `std::type_info` di C++ .
    // Ughjetti di tippu `std::type_info`, descrittori di tippu, anu un puntatore à sta tavula.
    // I descrittori di tippu sò riferiti da e strutture C++ EH definite sopra è chì custruimu quì sottu.
    //
    // Innota chì a dimensione vera hè più grande di 3 usize, ma avemu solu bisognu di a nostra vtable per indicà u terzu elementu.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info per una classa rust_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Normalmente avemu aduprà .as_ptr().add(2) ma questu ùn funziona micca in un cuntestu const.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Questu intenzionalmente ùn utilizza micca u schema normale di mangiatura di i nomi perchè ùn vulemu micca chì C++ sia capace di pruduce o catturà Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Questu hè necessariu perchè u codice C++ pò catturà a nostra execption cù std::exception_ptr è ripiglià lu più volte, forse ancu in un altru filu.
    //
    //
    caught: AtomicBool,

    // Questa deve esse una Opzione perchè a vita di l'ughjettu segue a semantica C++ : quandu catch_unwind sposta a Casella fora di l'eccezione deve ancu lascià l'oggettu d'eccezione in un statu validu perchè u so distruttore serà sempre chjamatu da __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try in realtà ci dà un puntatore per sta struttura.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Postu chì cleanup() ùn hè micca permessu à panic, avemu solu abbandunà invece.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}