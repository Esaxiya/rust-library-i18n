//! Windows SEH
//!
//! In Windows (attualmente solu in MSVC), u mecanismu di gestione di l'eccezzioni predefinitu hè Gestione di l'Ecezzioni Strutturate (SEH).
//! Questu hè assai sfarente di a gestione di l'eccezzioni basata in Dwarf (per esempiu, ciò chì altre piattaforme unix utilizanu) in termini di internu di compilatore, dunque LLVM hè tenutu à avè una bona quantità di supportu extra per SEH.
//!
//! In poche parole, ciò chì accade quì hè:
//!
//! 1. A funzione `panic` chjama a funzione Windows standard `_CxxThrowException` per lancià una eccezione cum'è C++ , attivendu u prucessu di svolgimentu.
//! 2.
//! Tutti i pads di sbarcu generati da u compilatore utilizanu a funzione di personalità `__CxxFrameHandler3`, una funzione in u CRT, è u codice di rilassamentu in Windows utilizerà sta funzione di personalità per eseguisce tuttu u codice di pulizia in a pila.
//!
//! 3. Tutte e chjamate generate da u compilatore à `invoke` anu un pad d'atterrazione stabilitu cum'è una struzzione `cleanuppad` LLVM, chì indica l'iniziu di a rutina di pulizia.
//! A personalità (in a tappa 2, definita in u CRT) hè incaricata di gestisce e rutine di pulizia.
//! 4. Eventualmente u codice "catch" in u `try` intrinsicu (generatu da u compilatore) hè eseguitu è indica chì u cuntrollu deve tornà à Rust.
//! Questu hè fattu per mezu di un `catchswitch` più un'istruzione `catchpad` in termini LLVM IR, restituendu infine u cuntrollu normale à u prugramma cun un'istruzione `catchret`.
//!
//! Alcune differenze specifiche da a gestione di l'eccezzioni basate in gcc sò:
//!
//! * Rust ùn hà alcuna funzione di personalità persunalizata, hè invece *sempre*`__CxxFrameHandler3`.Inoltre, nisun filtru supplementu hè realizatu, cusì finiscemu per catturà qualsiasi eccezzioni C++ chì accadenu per esse cum'è u tippu chì tiremu.
//! Nutate bè chì lancià una eccezzione in Rust hè un cumpurtamentu indefinitu quantunque, dunque duverebbe esse bè.
//! * Avemu qualchì dati da trasmette attraversu u cunfini di rilassamentu, specificamente un `Box<dyn Any + Send>`.Cum'è cù eccezioni Dwarf questi dui indicatori sò memorizzati cum'è una carica utile in l'eccezione stessa.
//! In MSVC, tuttavia, ùn ci hè bisognu di una allocazione di muntone in più perchè a pila di chjamate hè cunservata mentre e funzioni di filtru sò in esecuzione.
//! Ciò significa chì i puntatori sò passati direttamente à `_CxxThrowException` chì sò poi recuperati in a funzione di filtru da scrive in u quadru di pila di l'intrinsicu `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Questu deve esse una Opzione perchè catturemu l'eccezione per riferimentu è u so distruttore hè eseguitu da u runtime C++ .
    // Quandu pigliemu a Casella fora di l'eccezzione, avemu bisognu di lascià l'eccezzione in un statu validu per chì u so destructore sia eseguitu senza duppià a Casella.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Prima, una mansa di definizioni di tippu.Ci hè parechje stranezze specifiche à a piattaforma quì, è assai chì sò solu copiatamente scherzosamente da LLVM.U scopu di tuttu què hè di implementà a funzione `panic` sottu per mezu di una chjamata à `_CxxThrowException`.
//
// Sta funzione piglia dui argumenti.U primu hè un puntatore à i dati chì passemu, chì in questu casu hè u nostru oggettu trait.Piuttostu faciule da truvà!U prossimu, però, hè più cumplicatu.
// Questu hè un indicatore per una struttura `_ThrowInfo`, è generalmente hè destinatu solu à descrive solu l'eccezione chì hè stata lanciata.
//
// Attualmente a definizione di stu tippu [1] hè un pocu pilosa, è a curiosità principale (è a differenza da l'articulu in linea) hè chì nantu à 32-bit i puntatori sò puntatori ma in 64-bit i puntatori sò espressi cum'è offset 32-bit da u Simbulu `__ImageBase`.
//
// A macro `ptr_t` è `ptr!` in i moduli sottu sò aduprati per esprimelu.
//
// U labirintu di e definizioni di tippu seguita dinò attentamente ciò chì LLVM emette per questa sorte di operazione.Per esempiu, se compilate stu codice C++ in MSVC è emette u LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      nullu foo() { rust_panic a = {0, 1};
//          lancià una;}
//
// Hè essenzialmente ciò chì pruvemu à emulà.A maiò parte di i valori custanti sottu sò stati appena copiati da LLVM,
//
// In ogni casu, queste strutture sò tutte custruite in una manera simile, è hè solu un pocu verbosa per noi.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Nutate bè chì ignoremu intenzionalmente e regule di manipulazione di nomi quì: ùn vulemu micca chì C++ sia capace di catturà Rust panics semplicemente dichjarendu un `struct rust_panic`.
//
//
// Quandu mudificate, assicuratevi chì a stringa di nome di tippu currisponde esattamente à quella aduprata in `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // U primu byte `\x01` quì hè in realtà un signale magicu à LLVM per *ùn* applicà alcuna altra mangiatura cum'è prefissazione cù un caratteru `_`.
    //
    //
    // Stu simbulu hè a vtable aduprata da `std::type_info` di C++ .
    // Ughjetti di tippu `std::type_info`, descrittori di tippu, anu un puntatore à sta tavula.
    // I descrittori di tippu sò riferiti da e strutture C++ EH definite sopra è chì custruimu quì sottu.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Stu tipu descrittore hè adupratu solu quandu si lancia una eccezione.
// A parte di cattura hè trattata da u pruvucu intrinsicu, chì genera u so propiu TypeDescriptor.
//
// Va bè postu chì u runtime di MSVC utilizza u paragone di stringe nantu à u nome di u tippu per currisponde à TypeDescriptors piuttostu chè l'ugualità di i puntatori.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// U distruttore hè adupratu se u codice C++ decide di catturà l'eccezione è lasciallu senza propagallu.
// A parte catch di u try intrinsicu hà da mette a prima parolla di l'ughjettu d'eccezione à 0 in modu chì sia saltata da u distruttore.
//
// Innota chì x86 Windows utilizza a cunvenzione di chjamata "thiscall" per funzioni di membru C++ invece di a cunvenzione di chjamata "C" predefinita.
//
// A funzione exception_copy hè un pocu speciale quì: hè invucata da u runtime MSVC sottu un bloccu try/catch è u panic chì generemu quì serà adupratu cum'è u risultatu di a copia d'eccezione.
//
// Questu hè adupratu da u runtime C++ per supportà a cattura di eccezioni cù std::exception_ptr, chì ùn pudemu micca supportà perchè Box<dyn Any>ùn hè micca clonabile.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException esegue interamente nantu à stu quadru di stack, allora ùn ci hè bisognu di altrimenti trasferisce `data` à a mansa.
    // Passemu solu un puntatore stack à sta funzione.
    //
    // U ManuallyDrop hè necessariu quì postu chì ùn vulemu micca chì Eccezione sia abbandunata quandu si rilassa.
    // Invece serà abbandunatu da exception_cleanup chì hè invucatu da u runtime C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Questu ... pò sembra sorprendente, è ghjustamente.In MSVC à 32 bit, i puntatori trà queste strutture sò solu quessi, i puntatori.
    // In MSVC 64-bit, tuttavia, i puntatori trà strutture sò piuttostu espressi cum'è offset 32-bit da `__ImageBase`.
    //
    // Di cunsiguenza, nantu à MSVC 32-bit pudemu dichjarà tutti questi indicatori in u `staticu` sopra.
    // In MSVC à 64 bit, duveriamu sprime sottrazione di puntatori in statica, ciò chì Rust ùn permette micca attualmente, allora ùn pudemu micca fà veramente.
    //
    // A prossima cosa migliore, allora hè di riempie queste strutture in runtime (u panicu hè dighjà u "slow path" quantunque).
    // Dunque quì reinterpretemu tutti questi campi di puntatore cum'è numeri interi à 32 bit è poi guardemu u valore pertinente in ellu (atomicamente, cume pò accadere panics concurrente).
    //
    // Tecnicamente u runtime farà probabilmente una lettura nonatomica di questi campi, ma in teoria ùn anu mai lettu u valore *sbagliatu* dunque ùn deve micca esse troppu male ...
    //
    // In ogni casu, basicamente avemu bisognu di fà qualcosa cusì finu à chì pudemu sprime più operazioni in statica (è ùn pudemu mai esse capace).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Una carica NULL quì significa chì simu ghjunti quì da a cattura (...) di __rust_try.
    // Questu accade quandu una eccezione straniera non Rust hè catturata.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Questu hè necessariu da u compilatore per esiste (per esempiu, hè un articulu lang), ma ùn hè mai veramente chjamatu da u compilatore perchè __C_specific_handler o_except_handler3 hè a funzione di personalità chì hè sempre aduprata.
//
// Dunque questu hè solu un ceppu abortante.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}