//! Svolgimentu per u target *wasm32*.
//!
//! In questu momentu ùn sustenemu micca questu, allora questu hè solu stubs.

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}