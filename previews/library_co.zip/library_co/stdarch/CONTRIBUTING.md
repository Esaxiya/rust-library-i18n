# Cuntribuisce à stdarch

U `stdarch` crate hè più cà dispostu à accettà cuntribuzioni!Prima vi vulete probabilmente verificà u repositoriu è assicuratevi chì i testi passanu per voi:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Induve `<your-target-arch>` hè u triplu di destinazione cum'è adupratu da `rustup`, per esempiu `x86_x64-unknown-linux-gnu` (senza alcunu `nightly-` precedente o simile).
Arricurdatevi dinò chì stu repositoriu richiede u canale di notte di Rust!
I testi sopra richiesti richiedenu in realtà rust di notte per esse u predefinitu in u vostru sistema, per impostà chì utilizanu `rustup default nightly` (è `rustup default stable` per tornà).

Se unu di i passi sopra ùn funziona micca, [please let us know][new]!

Dopu pudete [find an issue][issues] per aiutà, avemu sceltu uni pochi cù i tag [`help wanted`][help] è [`impl-period`][impl] chì puderebbenu particularmente aduprà qualchì aiutu. 
Pudete esse più interessatu à [#40][vendor], implementendu tutti i venditori intrinsici nantu à x86.Questu numeru hà alcuni boni suggerimenti nantu à induve cumincià!

Se avete domande generali sentitevi liberi di [join us on gitter][gitter] è dumandate intornu!Fate liberu di ping@BurntSushi o@alexcrichton cù dumande.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Cumu scrive esempi per l'intrinsicu stdarch

Ci hè parechje caratteristiche chì devenu esse attivate per l'intrinsicu datu per travaglià bè è l'esempiu deve esse gestitu solu da `cargo test --doc` quandu a funzione hè supportata da u CPU.

Di conseguenza, u `fn main` predefinitu generatu da `rustdoc` ùn funziona (in a maiò parte di i casi).
Pensate à aduprà i seguenti cum'è una guida per assicurà chì u vostru esempiu funziona cum'è previsto.

```rust
/// # // Avemu bisognu di cfg_target_feature per assicurà chì l'esempiu sia solu
/// # // gestitu da `cargo test --doc` quandu u CPU supporta a funzione
/// # #![feature(cfg_target_feature)]
/// # // Avemu bisognu di target_feature per l'intrinsicu per travaglià
/// # #![feature(target_feature)]
/// #
/// # // rustdoc per difettu usa `extern crate stdarch`, ma avemu bisognu di u
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // A vera funzione principale
/// # fn main() {
/// #     // Eseguite solu se `<target feature>` hè supportatu
/// #     se cfg_feature_enabled! ("<target feature>"){
/// #         // Crea una funzione `worker` chì serà eseguita solu se a funzione di destinazione
/// #         // hè supportatu è assicuratevi chì `target_feature` sia attivatu per u vostru travagliadore
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         periculosu fn worker() {
/// // Scrivi quì u to esempiu.A funzione intrinsica specifica funziona quì!Andate salvaticu!
///
/// #         }
///
/// #         { worker(); } periculosu
/// #     }
/// # }
```

Se alcune di a sintassi sopra ùn sembranu micca familiari, a sezione [Documentation as tests] di [Rust Book] descrive abbastanza bè a sintassi `rustdoc`.
Cum'è sempre, sentitevi liberi di [join us on gitter][gitter] è dumandateci se avete colpitu qualchì intoppu, è vi ringraziu per avè aiutatu à migliurà a documentazione di `stdarch`!

# Istruzzioni di Prove Alternative

Hè generalmente raccomandatu di aduprà `ci/run.sh` per eseguisce e prove.
Tuttavia questu puderia micca funzionà per voi, per esempiu, sì site in Windows.

In questu casu, pudete rientre in corsa `cargo +nightly test` è `cargo +nightly test --release -p core_arch` per pruvà a generazione di codice.
Innota chì questi richiedenu chì a catena di strumenti di notte sia installata è chì `rustc` sappia nantu à u vostru triplu target è a so CPU.
In particulare avete bisognu di impostà a variabile d'ambiente `TARGET` cum'è per `ci/run.sh`.
Inoltre avete bisognu di mette `RUSTCFLAGS` (bisognu di u `C`) per indicà e caratteristiche di destinazione, per esempiu `RUSTCFLAGS="-C -target-features=+avx2"`.
Pudete ancu definisce `-C -target-cpu=native` se site "just" sviluppatu contru à a vostra CPU attuale.

Attenti chì quandu aduprate ste istruzzioni alternative, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], per esempiu
i test di generazione d'istruzzioni ponu fiascà perchè u disassembler li hà numinati diversamente, per esempiu
pò generà `vaesenc` invece di istruzzioni `aesenc` malgradu chì si comportinu listessi.
Inoltre st'istruzzioni eseguiscenu menu testi di quelli chì nurmalmente si ferianu, allora ùn vi maravigghiate chì quandu avete eventualmente pull-request alcuni errori ponu apparì per testi micca cuperti quì.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






