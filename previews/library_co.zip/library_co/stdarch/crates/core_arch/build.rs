use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Adupratu per dì à e nostre annotazioni `#[assert_instr]` chì tutti i simd intrinsichi sò dispunibuli per pruvà i so codegen, postu chì certi sò chjusi daretu à un `-Ctarget-feature=+unimplemented-simd128` in più chì ùn hà alcunu equivalente in `#[target_feature]` avà.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}