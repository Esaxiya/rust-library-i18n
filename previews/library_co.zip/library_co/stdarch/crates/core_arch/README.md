`core::arch` - A biblioteca di core principale di Rust intrinsica specifica
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

U modulu `core::arch` implementa intrinsici dipendenti di l'architettura (per esempiu SIMD).

# Usage 

`core::arch` hè dispunibule cum'è parte di `libcore` è hè riesportatu da `libstd`.Preferite aduprà cù `core::arch` o `std::arch` chè via stu crate.
E caratteristiche instabili sò spessu dispunibili in notte Rust via `feature(stdsimd)`.

Aduprà `core::arch` via questu crate richiede a notte Rust, è pò (è si) rompe spessu.I soli casi in cui duvete cunsiderà aduprà cù questu crate sò:

* se avete bisognu di ricumpilà voi stessu `core::arch`, per esempiu, cù particularità di destinazione attivate chì ùn sò micca abilitate per `libcore`/`libstd`.
Note: se avete bisognu di ricumpilallu per un target micca standard, per piacè preferite aduprà `xargo` è ricumpilà `libcore`/`libstd` cum'è appropritatu invece di aduprà stu crate.
  
* aduprendu alcune caratteristiche chì puderebbenu micca esse dispunibili ancu daretu à e caratteristiche instabili Rust.Pruvemu à tene questi à u minimu.
Se avete bisognu di aduprà alcune di queste funzionalità, per piacè aprite un prublema per chì pudemu esposeli in a notte Rust è pudete aduprà da quì.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` hè distribuitu principalmente in i termini di a licenza MIT è di a Licenza Apache (Versione 2.0), cù porzioni cuparti da diverse licenze cum'è BSD.

Vede LICENZIA-APACHE, è LICENZIA-MIT per i dettagli.

# Contribution

A menu chì ùn dicite micca esplicitamente altrimenti, ogni cuntribuzione intenzionalmente presentata per l'inclusione in `core_arch` da voi, cum'è definita in a licenza Apache-2.0, serà licenziata duale cum'è sopra, senza alcunu termini o cundizioni addiziunali.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












