#![stable(feature = "wake_trait", since = "1.51.0")]
//! Tipi è Traits per travaglià cù compiti asincroni.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// L'implementazione di svegliu un compitu nantu à un esecutore.
///
/// Questu trait pò esse adupratu per creà un [`Waker`].
/// Un esecutore pò definisce un'implementazione di questu trait, è aduprà quellu per custruisce un Waker per passà à i compiti chì sò eseguiti annantu à quellu esecutore.
///
/// Questu trait hè una alternativa sicura in memoria è ergonomica per custruisce un [`RawWaker`].
/// Supporta u cuncepimentu di l'esecutore cumunu in u quale i dati aduprati per svegliare un compitu sò conservati in un [`Arc`].
/// Alcuni esecutori (in particulare quelli per i sistemi integrati) ùn ponu micca aduprà questa API, hè per quessa chì [`RawWaker`] esiste cum'è alternativa per questi sistemi.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Una funzione `block_on` di basa chì piglia un future è u corre finu à a fine nantu à u filu attuale.
///
/// **Note:** Questu esempiu scambia currettezza per simplicità.
/// Per prevene i blocchi, l'implementazioni di qualità produttrice anu ancu bisognu di gestisce chjamate intermedie à `thread::unpark` è invocazioni annidate.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Un waker chì sveglia u filu attuale quandu hè chjamatu.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Executà un future finu à a fine nantu à u filu attuale.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pin u future in modu chì pò esse scrutinatu.
///     let mut fut = Box::pin(fut);
///
///     // Crea un novu cuntestu per esse passatu à u future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Executà u future à a fine.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Svegliu stu compitu.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Svegliu stu compitu senza cunsumà u waker.
    ///
    /// Se un esecutore supporta un modu più economicu per svegliarsi senza cunsumà u waker, deve annullà stu metudu.
    /// Per automaticamente, clone u [`Arc`] è chjama [`wake`] nantu à u clone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SICUREZZA: Questu hè sicuru perchè raw_waker custruisce in modu sicuru
        // un RawWaker da Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Sta funzione privata per custruisce un RawWaker hè aduprata, invece di
// inserendu questu in u `From<Arc<W>> for RawWaker` impl, per assicurà chì a sicurezza di `From<Arc<W>> for Waker` ùn dipenda micca da u dispacciu currettu di trait, invece entrambi i impls chjamanu questa funzione direttamente è esplicitamente.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Aumenta u numeru di riferenza di l'arcu per clonallu.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Svegliu per valore, muvendu l'Arc in a funzione Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Svegliu per riferimentu, avvolge u waker in ManuallyDrop per evità di lascià cascà
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Diminuisce u numeru di riferenza di l'Arc in goccia
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}