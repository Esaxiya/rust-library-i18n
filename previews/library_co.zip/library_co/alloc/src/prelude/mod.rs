//! U alloc Prelude
//!
//! U scopu di stu modulu hè di alleviare l'importazioni di articuli cumunemente usati di u `alloc` crate aghjunghjendu una importazione glob in cima di i moduli:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;