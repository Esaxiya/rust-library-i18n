//! Puntatori di cuntezione di riferenze à filu unicu.'Rc' significa 'Riferimentu
//! Counted'.
//!
//! U tippu [`Rc<T>`][`Rc`] furnisce pruprietà cumuna di un valore di tippu `T`, attribuitu in a mansa.
//! Invucà [`clone`][clone] nantu à [`Rc`] produce un novu puntatore à a listessa assignazione in a mansa.
//! Quandu l'ultimu puntatore [`Rc`] à una attribuzione data hè distruttu, u valore almacenatu in quella attribuzione (spessu chjamatu "inner value") hè ancu calatu.
//!
//! E referenze cumune in Rust ùn permettenu micca a mutazione per difettu, è [`Rc`] ùn face micca eccezione: ùn pudete micca generalmente ottene una riferenza mutevule à qualcosa in un [`Rc`].
//! Se avete bisognu di mutabilità, mette un [`Cell`] o [`RefCell`] in u [`Rc`];vede [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] adopra u cuntu di riferenza non atomicu.
//! Questu significa chì u soprappu hè assai bassu, ma un [`Rc`] ùn pò micca esse mandatu trà fili, è dunque [`Rc`] ùn implementa micca [`Send`][send].
//! Di conseguenza, u compilatore Rust verificerà *à u mumentu di a compilazione* chì ùn inviate micca [`Rc`] s trà filetti.
//! Se avete bisognu di contà di riferenze atomiche multi-threaded, aduprate [`sync::Arc`][arc].
//!
//! U metudu [`downgrade`][downgrade] pò esse adupratu per creà un puntatore [`Weak`] chì ùn hè micca pruprietariu.
//! Un puntatore [`Weak`] pò esse [`aghjurnamentu`][aghjurnamentu] d à un [`Rc`], ma questu restituverà [`None`] se u valore almacenatu in l'allocazione hè digià statu abbandunatu.
//! In altre parole, i puntatori `Weak` ùn mantenenu micca u valore in l'internu di l'attribuzione;però,*facenu* mantenenu viva l'allocazione (u magazinu di sustegnu per u valore internu).
//!
//! Un ciclu trà i puntatori [`Rc`] ùn serà mai dislocatu.
//! Per questa ragione, [`Weak`] hè adupratu per rompe i cicli.
//! Per esempiu, un arburu puderia avè forti puntatori [`Rc`] da i nodi genitori à i zitelli, è puntelli [`Weak`] da i zitelli à i so genitori.
//!
//! `Rc<T>` dereferenze automaticamente à `T` (via [`Deref`] trait), dunque pudete chjamà i metudi di `T 'per un valore di tippu [`Rc<T>`][`Rc`].
//! Per evità scontri di nomi cù i metudi di `T`, i metudi di [`Rc<T>`][`Rc`] stessu sò funzioni associate, chjamate aduprendu [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>L'implementazioni di traits cum'è `Clone` ponu ancu esse chjamate cù sintassi cumpletamente qualificata.
//! Alcune persone preferenu aduprà una sintassi cumpletamente qualificata, mentre chì altri preferenu aduprà una sintassi di metudu-chjamata.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sintassi di metudu-chjama
//! let rc2 = rc.clone();
//! // Sintassi cumpletamente qualificata
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] ùn dereca micca automaticamente à `T`, perchè u valore internu pò esse digià statu abbandunatu.
//!
//! # Riferimenti di clonazione
//!
//! A creazione di una nova riferenza à a listessa assignazione cum'è un puntatore cuntatu di riferenza esistente hè fatta cù `Clone` trait implementatu per [`Rc<T>`][`Rc`] è [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // E duie sintassi sottu sò equivalenti.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a è b puntanu tramindui à u listessu locu di memoria cum'è foo.
//! ```
//!
//! A sintassi `Rc::clone(&from)` hè a più idiomatica perchè trasmette più esplicitamente u significatu di u codice.
//! In l'esempiu di sopra, sta sintassi rende più faciule di vede chì stu codice crea una nova riferenza invece di copià tuttu u cuntenutu di foo.
//!
//! # Examples
//!
//! Cunsiderate un scenariu induve un inseme di `Gadget` hè pruprietà di un determinatu `Owner`.
//! Vulemu avè u nostru puntu "Gadget" versu u so `Owner`.Ùn pudemu micca fà questu cun pruprietà unica, perchè più di un gadget pò appartene à u listessu `Owner`.
//! [`Rc`] ci permette di sparte un `Owner` trà più `Gadget`s, è avè u `Owner` fermu attribuitu finchè tutti i punti `Gadget` ci sò.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... altri campi
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... altri campi
//! }
//!
//! fn main() {
//!     // Crea un `Owner` cuntatu di riferenza.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Creà `Gadget` chì appartene à `gadget_owner`.
//!     // A Clonazione di u `Rc<Owner>` ci dà un novu puntatore per a listessa assignazione `Owner`, incrementendu u numeru di riferenza in u prucessu.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Scaricate a nostra variabile lucale `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Malgradu a caduta di `gadget_owner`, semu sempre capaci di stampà u nome di u `Owner` di u `Gadget`.
//!     // Questu hè perchè avemu abbandunatu solu un solu `Rc<Owner>`, micca u `Owner` chì punta.
//!     // Finu chì ci sò altri `Rc<Owner>` chì indicanu à a stessa attribuzione `Owner`, resterà in diretta.
//!     // A pruiezione di campu `gadget1.owner.name` funziona perchè `Rc<Owner>` dereca automaticamente e referenze à `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // À a fine di a funzione, `gadget1` è `gadget2` sò distrutti, è cun elli l'ultimi riferimenti contati à u nostru `Owner`.
//!     // Gadget Man hè oramai distruttu ancu.
//!     //
//! }
//! ```
//!
//! Se e nostre esigenze cambianu, è ci vole ancu à esse in gradu di traversà da `Owner` à `Gadget`, averemu prublemi.
//! Un puntatore [`Rc`] da `Owner` à `Gadget` introduce un ciclu.
//! Questu significa chì u so numeru di riferimentu ùn pò mai ghjunghje à 0, è l'assignazione ùn serà mai distrutta:
//! una fuga di memoria.Per circundà questu, pudemu aduprà puntatori [`Weak`].
//!
//! Rust rende in realtà un pocu difficiule di pruduce stu ciclu in primu locu.Per finisce cù dui valori chì puntanu l'uni à l'altri, unu di elli deve esse mutevule.
//! Questu hè difficiule perchè [`Rc`] impone a sicurezza di a memoria dendu solu riferimenti cumuni à u valore chì avvolge, è questi ùn permettenu micca a mutazione diretta.
//! Avemu bisognu à avvolge a parte di u valore chì vulemu mutà in un [`RefCell`], chì furnisce *mutabilità interiore*: un metudu per uttene mutabilità attraversu un riferimentu cumunu.
//! [`RefCell`] impone e regule di prestitu di Rust in runtime.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... altri campi
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... altri campi
//! }
//!
//! fn main() {
//!     // Crea un `Owner` cuntatu di riferenza.
//!     // Innota chì avemu messu u vector di u ``Proprietariu '' di`Gadget` in un `RefCell` in modu da pudè mutallu attraversu una riferenza cumuna.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Creà `Gadget` chì appartene à `gadget_owner`, cum'è nanzu.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Aghjunghjite u `Gadget` à u so `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` u prestitu dinamicu finisce quì.
//!     }
//!
//!     // Iterate nantu à i nostri `Gadget`, stampendu i so dettagli.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` hè un `Weak<Gadget>`.
//!         // Siccomu i puntatori `Weak` ùn ponu micca garantisce chì l'allocazione esista sempre, avemu bisognu di chjamà `upgrade`, chì restituisce un `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // In questu casu sapemu chì l'allocazione esiste sempre, allora simu semplicemente `unwrap` u `Option`.
//!         // In un prugramma più cumplicatu, pudete avè bisognu di manipulazione graziosa di errore per un risultatu `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // À a fine di a funzione, `gadget_owner`, `gadget1` è `gadget2` sò distrutti.
//!     // Ùn ci hè avà puntelli forti (`Rc`) per i gadgets, allora sò distrutti.
//!     // Questu mette à zero u conte di riferenza nantu à Gadget Man, allora hè ancu distruttu.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Questu hè repr(C) à future-prova contr'à una pussibile riorganizazione di campu, chì interferiscenu cù [into|from]_raw() altrimente sicuru di tippi interni trasmissibili.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Un puntatore di cuntu di riferimentu à un filu unicu.'Rc' significa 'Riferimentu
/// Counted'.
///
/// Vede u [module-level documentation](./index.html) per più dettagli.
///
/// I metudi inerenti di `Rc` sò tutte funzioni assuciate, chì significa chì duvete chjamalli cum'è per esempiu, [`Rc::get_mut(&mut value)`][get_mut] invece di `value.get_mut()`.
/// Questa evita i cunflitti cù i metudi di u tipu internu `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Questa insegurità hè ok perchè mentre questu Rc hè vivu ci hè garantitu chì u puntatore internu hè validu.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Custruisce un novu `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Ci hè un puntatore debule implicitu pussedutu da tutti i puntatori forti, chì assicura chì u destruttore debule ùn libere mai l'allocazione mentre u destructore forte hè in esecuzione, ancu se u puntatore debule hè conservatu in quellu forte.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Custruisce un novu `Rc<T>` aduprendu un debule riferimentu à sè stessu.
    /// Tentà d'aghjurnà u riferimentu debule prima chì sta funzione ritorna resultarà in un valore `None`.
    ///
    /// Tuttavia, a riferenza debule pò esse clonata liberamente è conservata per l'usu in un tempu dopu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... più campi
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Custruisce l'internu in u statu "uninitialized" cun una sola rifarenza debule.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Hè impurtante chì ùn abbandunemu micca a pruprietà di u puntatore debule, altrimenti a memoria pò esse liberata da u ritornu di `data_fn`.
        // Se vulissimu veramente passà a pruprietà, pudemu creà un puntatore debule addizionale per noi stessi, ma questu resulterebbe in aghjurnamenti addiziunali à u conte di riferimentu debule chì forse ùn sarebbe micca necessariu altrimenti.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // E referenze forti devenu pussede cullettivamente un riferimentu debule cumunu, allora ùn eseguite micca u distruttore per a nostra vechja riferenza debule.
        //
        mem::forget(weak);
        strong
    }

    /// Custruisce un novu `Rc` cù cuntenuti micca inizializati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inizializazione differita:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Custruisce un novu `Rc` cù cuntenuti non inizializati, cù a memoria chì hè piena di byte `0`.
    ///
    ///
    /// Vede [`MaybeUninit::zeroed`][zeroed] per esempi di usu currettu è incorrettu di stu metudu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Custruisce un novu `Rc<T>`, restituendu un errore se a distribuzione falla
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Ci hè un puntatore debule implicitu pussedutu da tutti i puntatori forti, chì assicura chì u destruttore debule ùn libere mai l'allocazione mentre u destructore forte hè in esecuzione, ancu se u puntatore debule hè conservatu in quellu forte.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Custruisce un novu `Rc` cù cuntenuti non inizializzati, restituendu un errore se l'allocazione fiasca
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inizializazione differita:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Custruisce un novu `Rc` cù cuntenuti non inizializzati, cù a memoria riempita di byte `0`, restituendu un errore se l'allocazione fiasca
    ///
    ///
    /// Vede [`MaybeUninit::zeroed`][zeroed] per esempi di usu currettu è incorrettu di stu metudu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Custruisce un novu `Pin<Rc<T>>`.
    /// Se `T` ùn implementa micca `Unpin`, allora `value` serà appiccicatu in memoria è incapace di esse spustatu.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Restituisce u valore internu, se u `Rc` hà esattamente una forte rifarenza.
    ///
    /// Inutili, un [`Err`] hè restituitu cù u listessu `Rc` chì hè statu passatu.
    ///
    ///
    /// Questu avarà successu ancu s'ellu ci sò riferenzi debuli pendenti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // cupià l'ughjettu cuntenutu

                // Indicate à i Debuli chì ùn ponu micca esse promossi decrementendu u numeru forte, è poi rimuovere u puntatore "strong weak" implicitu puru trattendu ancu a logica di goccia solu artigianendu una falsa Debula.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Custruisce una nova fetta cuntata di riferimentu cù cuntenuti micca inizializati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inizializazione differita:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Custruisce una nova fetta cuntata di riferimentu cù cuntenuti non inizializati, cù a memoria chì hè piena di byte `0`.
    ///
    ///
    /// Vede [`MaybeUninit::zeroed`][zeroed] per esempi di usu currettu è incorrettu di stu metudu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Converte in `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Cum'è cù [`MaybeUninit::assume_init`], tocca à u chjamante di garantisce chì u valore internu sia veramente in un statu inizializatu.
    ///
    /// Chjamà questu quandu u cuntenutu ùn hè ancu cumpletamente inizializatu provoca un cumpurtamentu indefinitu immediatu.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inizializazione differita:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Converte in `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Cum'è cù [`MaybeUninit::assume_init`], tocca à u chjamante di garantisce chì u valore internu sia veramente in un statu inizializatu.
    ///
    /// Chjamà questu quandu u cuntenutu ùn hè ancu cumpletamente inizializatu provoca un cumpurtamentu indefinitu immediatu.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inizializazione differita:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Consuma u `Rc`, restituendu u puntatore avvoltu.
    ///
    /// Per evità una perdita di memoria, u puntatore deve esse cunvertitu in un `Rc` cù [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Fornisce un puntatore grezzu à i dati.
    ///
    /// I conti ùn sò micca affettati in alcun modu è u `Rc` ùn hè micca cunsumatu.
    /// U puntatore hè validu finu à quandu ci sò conti forti in u `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SICUREZZA: Questu ùn pò passà per Deref::deref o Rc::inner perchè
        // questu hè necessariu per conservà a provenienza raw/mut tale chì per esempio
        // `get_mut` pò scrive attraversu u puntatore dopu chì u Rc hè recuperatu per `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Custruisce un `Rc<T>` da un puntatore grezzu.
    ///
    /// U puntatore grezzu deve esse statu precedentemente restituitu da una chjamata à [`Rc<U>::into_raw`][into_raw] induve `U` deve avè a stessa dimensione è allineamentu cum'è `T`.
    /// Questu hè trivialmente veru se `U` hè `T`.
    /// Innota chì se `U` ùn hè micca `T` ma hà a stessa dimensione è allineamentu, questu hè basicamente cum'è trasmutazione di referenze di diversi tipi.
    /// Vede [`mem::transmute`][transmute] per più infurmazione nantu à e restrizioni applicabili in questu casu.
    ///
    /// L'utilizatore di `from_raw` hà da assicurassi chì un valore specificu di `T` sia cascatu una sola volta.
    ///
    /// Sta funzione ùn hè micca sicura perchè l'usu impropriu pò purtà à a memoria in securità, ancu se u `Rc<T>` restituitu ùn hè mai accessu.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Cunvertite torna in un `Rc` per prevene a fuga.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ulteriori chjamate à `Rc::from_raw(x_ptr)` serianu micca sicure in memoria.
    /// }
    ///
    /// // A memoria hè stata liberata quandu `x` hè andatu fora di u scopu sopra, allora `x_ptr` hè avà pendente!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Inversa l'offset per truvà u RcBox originale.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Crea un novu puntatore [`Weak`] per questa attribuzione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Assicuratevi chì ùn creemu micca un Debbule pendente
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Ottiene u numeru di puntatori [`Weak`] per questa attribuzione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Ottiene u numeru di forti puntatori (`Rc`) per questa attribuzione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Ritorna `true` se ùn ci sò micca altri puntatori `Rc` o [`Weak`] à questa attribuzione.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Restituisce una riferenza mutevule in u `Rc` datu, se ùn ci sò micca altri puntatori `Rc` o [`Weak`] à a listessa assignazione.
    ///
    ///
    /// Restituisce [`None`] altrimente, perchè ùn hè micca sicuru di mutà un valore cumunu.
    ///
    /// Vede ancu [`make_mut`][make_mut], chì farà [`clone`][clone] u valore internu quandu ci sò altri puntatori.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Restituisce un riferimentu mutevule in u `Rc` datu, senza alcun cuntrollu.
    ///
    /// Vede ancu [`get_mut`], chì hè sicuru è face i cuntrolli adatti.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Ogni altru puntatore `Rc` o [`Weak`] per a stessa attribuzione ùn deve micca esse deriferenziata per a durata di u prestitu restituitu.
    ///
    /// Questu hè trivialmente u casu se ùn esistenu micca tali indicatori, per esempiu immediatamente dopu `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Semu attenti à *micca* creà una riferenza chì copre i campi "count", chì questu seria in cunflittu cù l'accessi à i conti di riferenza (es.
        // da `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Restituisce `true` se i dui `Rc` puntanu à a stessa attribuzione (in una vena simile à [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Face una riferenza mutevule in u `Rc` datu.
    ///
    /// Se ci sò altri puntatori `Rc` per a stessa attribuzione, allora `make_mut` darà [`clone`] u valore internu à una nova attribuzione per assicurà a pruprietà unica.
    /// Questu hè ancu chjamatu clone-on-write.
    ///
    /// Se ùn ci sò micca altri puntatori `Rc` per questa attribuzione, allora i puntatori [`Weak`] per questa attribuzione seranu disassociati.
    ///
    /// Vede ancu [`get_mut`], chì fallerà invece di clonà.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Ùn clonerà nunda
    /// let mut other_data = Rc::clone(&data);    // Ùn clonerà micca dati interni
    /// *Rc::make_mut(&mut data) += 1;        // Cloni dati interni
    /// *Rc::make_mut(&mut data) += 1;        // Ùn clonerà nunda
    /// *Rc::make_mut(&mut other_data) *= 2;  // Ùn clonerà nunda
    ///
    /// // Avà `data` è `other_data` puntanu à allocazioni sfarenti.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] i puntatori seranu disassociati:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Devi clonà i dati, ci sò altri Rcs.
            // Pre-attribuisce memoria per permette di scrive u valore clonatu direttamente.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Pudete solu arrubbà i dati, tuttu ciò chì ferma hè Debuli
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Elimina u ref forte-debule implicitu (ùn ci hè bisognu di fà una falsa Debula quì-sapemu chì altri Debuli ponu pulì per noi)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Questa insicurezza hè ok perchè avemu a garanzia chì u puntatore restituitu hè u *solu* puntatore chì serà mai restituitu à T.
        // U nostru numeru di riferenze hè garantitu per esse 1 à questu puntu, è avemu dumandatu chì u `Rc<T>` stessu sia `mut`, allora restituemu l'unica riferenza pussibile à l'attribuzione.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Pruvate à abbassà u `Rc<dyn Any>` à un tipu cuncretu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Assigna un `RcBox<T>` cun spaziu sufficiente per un valore internu pussibuli micca dimensionatu induve u valore hà a dispusizione furnita.
    ///
    /// A funzione `mem_to_rcbox` hè chjamata cù u puntatore di dati è deve restituisce un indicatore (potenzialmente grassu) per u `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Calculate u schema aduprendu u schema di valore datu.
        // Nanzu, u layout era calculatu annantu à l'espressione `&*(ptr as* const RcBox<T>)`, ma questu hà creatu un riferimentu disalliniatu (vede #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Assigna un `RcBox<T>` cun spaziu sufficiente per un valore internu pussibuli micca dimensionatu induve u valore hà a dispusizione furnita, restituendu un errore se l'assignazione fiasca.
    ///
    ///
    /// A funzione `mem_to_rcbox` hè chjamata cù u puntatore di dati è deve restituisce un indicatore (potenzialmente grassu) per u `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Calculate u schema aduprendu u schema di valore datu.
        // Nanzu, u layout era calculatu annantu à l'espressione `&*(ptr as* const RcBox<T>)`, ma questu hà creatu un riferimentu disalliniatu (vede #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Assignate per u schema.
        let ptr = allocate(layout)?;

        // Inizializà u RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Assigna un `RcBox<T>` cun spaziu sufficiente per un valore interiore micca dimensionatu
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Assignate per u `RcBox<T>` cù u valore datu.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copia u valore cum'è byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Libera l'allocazione senza abbandunà u so cuntenutu
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Assigna un `RcBox<[T]>` cù a lunghezza data.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Copia l'elementi da a fetta in Rc appena attribuitu <\[T\]>
    ///
    /// Unsafe perchè u chjamante deve o piglià a pruprietà o ligà `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Custruisce un `Rc<[T]>` da un iteratore cunnisciutu per esse di una certa dimensione.
    ///
    /// U cumpurtamentu ùn hè micca definitu se a taglia hè sbagliata.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic guardia mentre clone elementi T.
        // In casu di un panic, elementi chì sò stati scritti in u novu RcBox seranu abbandunati, dopu a memoria liberata.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Puntatore à u primu elementu
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tuttu chjaru.Dimenticate a guardia per ùn liberà u novu RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializazione trait aduprata per `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Gocce u `Rc`.
    ///
    /// Questu diminuirà u forte conte di riferenza.
    /// Se u numeru forte di riferenza righjunghji u zero allora l'unichi altri riferimenti (se esiste) sò [`Weak`], cusì avemu `drop` u valore internu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Ùn stampa nunda
    /// drop(foo2);   // Stampa "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // distrugge l'ughjettu cuntenutu
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // caccià u puntatore "strong weak" implicitu avà chì avemu distruttu u cuntenutu.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Face un clone di u puntatore `Rc`.
    ///
    /// Questu crea un altru puntatore per a stessa allocazione, aumentendu u forte conte di riferimentu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Crea un novu `Rc<T>`, cù u valore `Default` per `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack per permettà specializazione in `Eq` ancu se `Eq` hà un metudu.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Facemu sta specializazione quì, è micca cum'è una ottimisazione più generale nantu à `&T`, perchè altrimenti aghjunghjeria un costu per tutti i cuntrolli di uguaglianza nantu à i ref.
/// Assumemu chì `Rc` sò aduprati per immagazzinà grandi valori, chì sò lenti à clonà, ma ancu pesanti per verificà l'uguaglianza, pruvucendu stu costu à pagà più facilmente.
///
/// Hè ancu più prubabile d'avè dui cloni `Rc`, chì indicanu u listessu valore, cà dui `&T`s.
///
/// Ùn pudemu micca fà questu quandu `T: Eq` cum'è `PartialEq` pò esse deliberatamente irreflexivu.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Uguaglianza per dui `Rc`s.
    ///
    /// Dui `Rc` sò uguali se i so valori interni sò uguali, ancu s'elli sò memorizzati in una distribuzione diversa.
    ///
    /// Se `T` implementa ancu `Eq` (chì implica riflessività di uguaglianza), dui `Rc` chì indicanu a stessa attribuzione sò sempre uguali.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Iniqualità per dui `Rc`s.
    ///
    /// Dui `Rc` sò inuguali se i so valori interni sò inuguali.
    ///
    /// Se `T` implementa ancu `Eq` (chì implica riflessività di uguaglianza), dui `Rc` chì indicanu a stessa attribuzione ùn sò mai inuguali.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Paragone parziale per dui `Rc`s.
    ///
    /// I dui sò paragunati chjamendu `partial_cmp()` nantu à i so valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Paragunà menu cà dui `Rc`s.
    ///
    /// I dui sò paragunati chjamendu `<` nantu à i so valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Paragunà 'Meno o uguale à' per dui `Rc`.
    ///
    /// I dui sò paragunati chjamendu `<=` nantu à i so valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Cunfrontu più grande di quellu per dui `Rc`.
    ///
    /// I dui sò paragunati chjamendu `>` nantu à i so valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Un paragone "più grande o uguale à" per dui "Rc".
    ///
    /// I dui sò paragunati chjamendu `>=` nantu à i so valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Cunfrontu per dui `Rc`s.
    ///
    /// I dui sò paragunati chjamendu `cmp()` nantu à i so valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Assignate una fetta cuntata di riferenza è riempila clonendu l'articuli di "v".
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Assignate una fetta di stringa cuntata di riferenza è copiate `v` in questu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Assignate una fetta di stringa cuntata di riferenza è copiate `v` in questu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Move un oggettu in scatula à un novu, riferimentu cuntatu, allocazione.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Assignate una fetta cuntata di riferenza è move l'articuli di "v" in questu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Permettite à Vec di liberà a so memoria, ma micca di distrughje u so cuntenutu
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Piglia ogni elementu in u `Iterator` è u raccoglie in un `Rc<[T]>`.
    ///
    /// # Caratteristiche di prestazione
    ///
    /// ## U casu generale
    ///
    /// In u casu generale, a raccolta in `Rc<[T]>` hè fatta da a prima raccolta in un `Vec<T>`.Hè cusì, quandu scrivite u seguitu:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// questu si comporta cum'è se avemu scrittu:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // U primu gruppu di allocazioni accade quì.
    ///     .into(); // Una seconda assignazione per `Rc<[T]>` accade quì.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Questu assignerà quante volte chì ci hè necessariu per custruisce u `Vec<T>` è poi assignerà una volta per trasformà u `Vec<T>` in u `Rc<[T]>`.
    ///
    ///
    /// ## Iteratori di lunghezza cunnisciuta
    ///
    /// Quandu u vostru `Iterator` implementa `TrustedLen` è hè di una dimensione esatta, una sola attribuzione serà fatta per u `Rc<[T]>`.Per esempiu:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Una sola attribuzione accade quì.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specializazione trait aduprata per coglie in `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Hè u casu per un iteratore `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SICUREZZA: Avemu bisognu di assicurà chì l'iteratore abbia una lunghezza esatta è l'avemu.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Riturnate à l'implementazione normale.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` hè una versione di [`Rc`] chì cuntene un riferimentu micca propiu à l'attribuzione gestita.L'accessione hè accessibile chjamendu [`upgrade`] nantu à u puntatore `Weak`, chì restituisce una [`Opzione`]`<`[`Rc`] `<T>>`.
///
/// Siccomu un riferimentu `Weak` ùn conta micca per a pruprietà, ùn impedisce micca chì u valore almacenatu in l'allocazione sia abbandunatu, è `Weak` stessu ùn face alcuna garanzia nantu à u valore chì hè sempre presente.
/// Cusì pò restituisce [`None`] quandu [`aghjurnà`] d.
/// Nutate quantunque chì una riferenza `Weak`*impedisce* l'assignazione stessa (u magazinu di sustegnu) da esse deallocatu.
///
/// Un puntatore `Weak` hè utile per tene un riferimentu tempurale à l'attribuzione gestita da [`Rc`] senza impedisce u so valore internu di esse calatu.
/// Hè ancu adupratu per impedisce e referenze circolari trà i puntatori [`Rc`], postu chì e referenze reciproche di pruprietà ùn permetterianu mai di tramandà nè [`Rc`].
/// Per esempiu, un arburu puderia avè forti puntatori [`Rc`] da i nodi genitori à i zitelli, è puntelli `Weak` da i zitelli à i so genitori.
///
/// U modu tipicu per uttene un puntatore `Weak` hè di chjamà [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Questu hè un `NonNull` per permette ottimisazione di a dimensione di stu tipu in enumerazioni, ma ùn hè micca necessariamente un puntatore validu.
    //
    // `Weak::new` impone questu à `usize::MAX` in modo chì ùn abbia bisognu di assignà spaziu nantu à a mansa.
    // Ùn hè micca un valore chì un veru puntatore averà mai perchè RcBox hà un allineamentu almenu 2.
    // Questu hè pussibule solu quandu `T: Sized`;`T` senza dimensioni ùn pende mai.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Custruisce un novu `Weak<T>`, senza attribuisce alcuna memoria.
    /// Chjamà [`upgrade`] à u valore di ritornu dà sempre [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Tipu d'aiutu per permette l'accessu à i conti di riferenza senza fà alcuna asserzione nantu à u campu di dati.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Restituisce un puntatore grezzu à l'ughjettu `T` indicatu da questu `Weak<T>`.
    ///
    /// U puntatore hè validu solu s'ellu ci hè qualchì riferimentu forte.
    /// U puntatore pò esse pendente, micca alliniatu o ancu [`null`] altrimente.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Tramindui puntanu à u listessu ughjettu
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // U forte quì u mantene vivu, cusì pudemu sempre accede à l'ughjettu.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ma micca di più.
    /// // Pudemu fà weak.as_ptr(), ma accede à u puntatore cunduceria à un cumpurtamentu indefinitu.
    /// // assert_eq! ("bonghjornu", periculosu {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Se u puntatore hè pendente, rimandemu direttamente a sentinella.
            // Questu ùn pò micca esse un indirizzu di carica valida validu, chì a carica utile hè almenu alineata cum'è RcBox (usize).
            ptr as *const T
        } else {
            // SICUREZZA: se is_dangling ritorna falsu, allora u puntatore hè dereferencable.
            // A carica utile pò esse abbandunata à questu puntu, è duvemu mantene a provenienza, allora aduprate a manipulazione di u puntatore grezzu.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Consuma u `Weak<T>` è u trasforma in un puntatore crudu.
    ///
    /// Questu cunverte u puntatore debule in un puntatore grezzu, pur mantenendu sempre a pruprietà di un riferimentu debule (u conte debule ùn hè micca mudificatu da questa operazione).
    /// Pò esse trasformatu in `Weak<T>` cù [`from_raw`].
    ///
    /// E stesse restrizioni per accede à u target di u puntatore cum'è cù [`as_ptr`] valenu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Converte un puntatore grezzu creatu prima da [`into_raw`] torna in `Weak<T>`.
    ///
    /// Questu pò esse adupratu per uttene in modu sicuru una forte riferenza (chjamendu [`upgrade`] più tardi) o per deallocate u conte debule lascendu cascà u `Weak<T>`.
    ///
    /// Piglia a pruprietà di un riferimentu debule (eccettu i puntatori creati da [`new`], chì questi ùn pussedenu nunda; u metudu funziona sempre nantu à elli).
    ///
    /// # Safety
    ///
    /// U puntatore deve esse uriginatu da u [`into_raw`] è deve ancu pussede u so putenziale riferimentu debule.
    ///
    /// Hè permessu chì u conte forte sia 0 à u mumentu di chjamà questu.
    /// Tuttavia, questu s'impatrunisce di un debule riferimentu attualmente rappresentatu cum'è un puntatore grezzo (u conte debule ùn hè micca mudificatu da questa operazione) è dunque deve esse accoppiato cun una chjamata precedente à [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Decrementà l'ultimu conte debule.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Vede Weak::as_ptr per u cuntestu nantu à cumu si deriva u puntatore d'entrata.

        let ptr = if is_dangling(ptr as *mut T) {
            // Questu hè un Debbule pendente.
            ptr as *mut RcBox<T>
        } else {
            // Altrimenti, avemu a guaranzia chì u puntatore hè vinutu da un Debule nondangling.
            // SICUREZZA: data_offset hè sicuru da chjamà, postu chì ptr riferisce un veru T.
            let offset = unsafe { data_offset(ptr) };
            // Cusì, inveremu l'offset per uttene tuttu u RcBox.
            // SEGURITÀ: u puntatore hè natu da un Debule, dunque questu offset hè sicuru.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SICUREZZA: avemu avà recuperatu u puntatore uriginale Debule, cusì pudemu creà u Debule.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Tentativi di aghjurnà u puntatore `Weak` à un [`Rc`], ritardendu a caduta di u valore internu se riesce.
    ///
    ///
    /// Restituisce [`None`] se u valore internu hè statu dapoi abbandunatu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Distrugge tutti i punti forti.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Ottiene u numeru di forti puntatori (`Rc`) chì indicanu sta attribuzione.
    ///
    /// Se `self` hè statu creatu cù [`Weak::new`], questu restituverà 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Ottiene u numeru di puntatori `Weak` chì indicanu sta assignazione.
    ///
    /// Se ùn fermanu micca indicatori forti, questu restituverà zero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // sottrae u ptr debule implicitu
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Ritorna `None` quandu u puntatore hè pendente è ùn ci hè micca `RcBox` assignatu, (vale à dì, quandu stu `Weak` hè statu creatu da `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Semu attenti à *micca* creà una riferenza chì copre u campu "data", chì u campu pò esse mutatu simultaneamente (per esempiu, se l'ultimu `Rc` hè abbandunatu, u campu di dati serà abbandunatu in locu).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Restituisce `true` se i dui `Debuli` puntanu à a stessa attribuzione (simile à [`ptr::eq`]), o sì tramindui ùn puntanu micca à alcuna attribuzione (perchè sò stati creati cù `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Siccomu questu compara indicatori significa chì `Weak::new()` sarà uguale unu à l'altru, ancu s'elli ùn puntanu micca à alcuna attribuzione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Cumparendu `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Gocce u puntatore `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ùn stampa nunda
    /// drop(foo);        // Stampa "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // u numeru debule parte da 1, è anderà solu à zeru se tutti i punti forti sò spariti.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Face un clone di u puntatore `Weak` chì punta à a stessa attribuzione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Custruisce un novu `Weak<T>`, attribuisce memoria per `T` senza iniziallu.
    /// Chjamà [`upgrade`] à u valore di ritornu dà sempre [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Avemu verificatu_aghjuntu quì per trattà cù mem::forget in modu sicuru.In particulare
// sè mem::forget Rcs (o Debuli), u numeru di ref pò overflow, è poi pudete liberà l'allocazione mentre esistenu Rcs (o Debuli) eccezziunali.
//
// Abbortemu perchè questu hè un scenariu cusì degeneratu chì ùn ci importa micca di ciò chì accade-nisun veru prugramma ùn deve mai sperimentà questu.
//
// Questu duverebbe avè una trascurabilità trascurabile postu chì ùn avete micca bisognu di clonà questi assai in Rust grazia à a pruprietà è move-semantica.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Vulemu abortà in casu di overflow invece di calà u valore.
        // U numeru di riferenza ùn serà mai cero quandu si chjama questu;
        // tuttavia, inseremu quì un interruzzione per induce LLVM à un'ottimisazione altrimenti mancata.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Vulemu abortà in casu di overflow invece di calà u valore.
        // U numeru di riferenza ùn serà mai cero quandu si chjama questu;
        // tuttavia, inseremu quì un interruzzione per induce LLVM à un'ottimisazione altrimenti mancata.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Uttenite a compensazione in un `RcBox` per a carica utile dietro un puntatore.
///
/// # Safety
///
/// U puntatore deve puntà (è avè metadati validi per) un'istanza valida prima di T, ma u T hè permessu di esse abbandunatu.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Alignate u valore micca dimensionatu à a fine di u RcBox.
    // Perchè RcBox hè repr(C), serà sempre l'ultimu campu in memoria.
    // SICUREZZA: postu chì i soli tippi senza dimensioni pussibuli sò fette, oggetti trait,
    // è tippi esterni, u requisitu di sicurezza in ingressu hè attualmente abbastanza per soddisfà i requisiti di align_of_val_raw;questu hè un dettagliu di implementazione di a lingua chì ùn pò micca esse invucatu fora di std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}