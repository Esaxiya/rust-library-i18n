//! Una vista di dimensioni dinamica in una sequenza contigua, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! E fette sò una vista in un bloccu di memoria rapprisentatu cum'è un puntatore è una lunghezza.
//!
//! ```
//! // affettendu un Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // coercizione di una matrice in una fetta
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! E fette sò mutevuli o cumuni.
//! U tippu di fetta spartutu hè `&[T]`, mentre chì u tippu di fetta mutabile hè `&mut [T]`, induve `T` rappresenta u tippu d'elementu.
//! Per esempiu, pudete mutà u bloccu di memoria chì una fetta mutabile punta à:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Eccu alcune di e cose chì stu modulu cuntene:
//!
//! ## Structs
//!
//! Ci hè parechje strutture chì sò utili per e fette, cum'è [`Iter`], chì rapprisenta l'iterazione nantu à una fetta.
//!
//! ## Implementazioni Trait
//!
//! Ci hè parechje implementazioni di traits cumuni per fette.Alcuni esempi includenu:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], per fette chì u tippu d'elementu hè [`Eq`] o [`Ord`].
//! * [`Hash`] - per fette chì u tippu d'elementu hè [`Hash`].
//!
//! ## Iteration
//!
//! E fette implementanu `IntoIterator`.L'iteratore dà riferimenti à l'elementi slice.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! A fetta mutabile dà riferimenti mutevuli à l'elementi:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Questu iteratore dà riferimenti mutevuli à l'elementi di a fetta, dunque mentre u tippu d'elementu di a fetta hè `i32`, u tippu d'elementu di l'iteratore hè `&mut i32`.
//!
//!
//! * [`.iter`] è [`.iter_mut`] sò i metudi espliciti per restituisce l'iteratori predefiniti.
//! * Altri metodi chì restituiscenu l'iteratori sò [`.split`], [`.splitn`], [`.chunks`], [`.windows`] è ancu di più.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Parechji di l'usi in stu modulu sò aduprati solu in a cunfigurazione di prova.
// Hè più pulitu solu di spegne l'avvertimentu unused_imports cà di riparalli.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Metodi di estensione di fetta di basa
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) necessariu per l'implementazione di a macro `vec!` durante a prova NB, vedi u modulu `hack` in stu schedariu per più dettagli.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) necessariu per l'implementazione di `Vec::clone` durante a prova NB, vedi u modulu `hack` in questu fugliale per più dettagli.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Cù cfg(test) `impl [T]` ùn hè micca dispunibile, queste trè funzioni sò in realtà metudi chì sò in `impl [T]` ma micca in `core::slice::SliceExt`, avemu bisognu di furnisce queste funzioni per u test `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Ùn duvemu micca aghjunghje l'attributu in linea à questu postu chì questu hè adupratu in macro `vec!` principalmente è provoca una regressione perfetta.
    // Vede #71204 per discussione è risultati perf.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // l'articuli sò stati marcati inizializati in u ciclu sottu
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) hè necessariu per LLVM per rimuovere i controlli di limiti è hà megliu codegen cà zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // u vec hè statu attribuitu è inizializatu sopra à almenu sta lunghezza.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // attribuitu sopra cù a capacità di `s`, è inizializà à `s.len()` in ptr::copy_to_non_overlapping sottu.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Ordina a fetta.
    ///
    /// Questa sorte hè stabile (vale à dì, ùn riordina micca elementi uguali) è *O*(*n*\*log(* n*)) u peghju casu.
    ///
    /// Quandu hè applicabile, a scelta instabile hè preferita perchè hè generalmente più rapida di a classificazione stabile è ùn attribuisce micca memoria ausiliaria.
    /// Vede [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Implementazione attuale
    ///
    /// L'algoritmu attuale hè una sorta di fusione adattativa, iterativa ispirata da [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Hè cuncipitu per esse assai veloce in i casi induve a fetta hè guasgi urdinata, o custituita da duie o più sequenze urdinate cuncatenate una dopu l'altra.
    ///
    ///
    /// Inoltre, attribuisce un almacenamentu tempuraneu a mità di a dimensione di `self`, ma per e fette brevi hè usata invece una sorta d'inserzione senza attribuzione.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Ordina a fetta cù una funzione di comparatore.
    ///
    /// Questa sorte hè stabile (vale à dì, ùn riordina micca elementi uguali) è *O*(*n*\*log(* n*)) u peghju casu.
    ///
    /// A funzione di comparatore deve definisce un urdinamentu tutale per l'elementi in a fetta.Se l'ordine ùn hè micca tutale, l'ordine di l'elementi ùn hè micca specificatu.
    /// Un ordine hè un ordine tutale se hè (per tutti `a`, `b` è `c`):
    ///
    /// * tutale è antisimmetricu: esattamente unu di `a < b`, `a == b` o `a > b` hè veru, è
    /// * transitivu, `a < b` è `b < c` implica `a < c`.U listessu deve tene per `==` è `>`.
    ///
    /// Per esempiu, mentre [`f64`] ùn implementa micca [`Ord`] perchè `NaN != NaN`, pudemu aduprà `partial_cmp` cum'è a nostra funzione di sorte quandu sapemu chì a fetta ùn cuntene un `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Quandu hè applicabile, a scelta instabile hè preferita perchè hè generalmente più rapida di a classificazione stabile è ùn attribuisce micca memoria ausiliaria.
    /// Vede [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Implementazione attuale
    ///
    /// L'algoritmu attuale hè una sorta di fusione adattativa, iterativa ispirata da [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Hè cuncipitu per esse assai veloce in i casi induve a fetta hè guasgi urdinata, o custituita da duie o più sequenze urdinate cuncatenate una dopu l'altra.
    ///
    /// Inoltre, attribuisce un almacenamentu tempuraneu a mità di a dimensione di `self`, ma per e fette brevi hè usata invece una sorta d'inserzione senza attribuzione.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // tri inversu
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Ordina a fetta cù una funzione di estrazione chjave.
    ///
    /// Questa sorte hè stabile (vale à dì, ùn riordina micca elementi uguali) è *O*(*m*\* * n *\* log(*n*)) u peghju casu, induve a funzione chjave hè *O*(*m*).
    ///
    /// Per funzioni chjave caru (per esempiu
    /// funzioni chì ùn sò micca accessi simplici di pruprietà o operazioni di basa), [`sort_by_cached_key`](slice::sort_by_cached_key) hè prubabile di esse significativamente più veloce, perchè ùn ricumputa micca e chjave di l'elementu.
    ///
    ///
    /// Quandu hè applicabile, a scelta instabile hè preferita perchè hè generalmente più rapida di a classificazione stabile è ùn attribuisce micca memoria ausiliaria.
    /// Vede [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Implementazione attuale
    ///
    /// L'algoritmu attuale hè una sorta di fusione adattativa, iterativa ispirata da [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Hè cuncipitu per esse assai veloce in i casi induve a fetta hè guasgi urdinata, o custituita da duie o più sequenze urdinate cuncatenate una dopu l'altra.
    ///
    /// Inoltre, attribuisce un almacenamentu tempuraneu a mità di a dimensione di `self`, ma per e fette brevi hè usata invece una sorta d'inserzione senza attribuzione.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Ordina a fetta cù una funzione di estrazione chjave.
    ///
    /// Durante a selezzione, a funzione chjave hè chjamata solu una volta per elementu.
    ///
    /// Stu sorte hè stabile (vale à dì, ùn riordine micca elementi uguali) è *O*(*m*\* * n *+* n *\* log(*n*)) u peghju casu, induve a funzione chjave hè *O*(*m*) .
    ///
    /// Per e funzioni chjave semplici (per esempiu, funzioni chì sò accessi di pruprietà o operazioni di basa), [`sort_by_key`](slice::sort_by_key) hè prubabile di esse più veloce.
    ///
    /// # Implementazione attuale
    ///
    /// L'algoritmu attuale hè basatu annantu à [pattern-defeating quicksort][pdqsort] da Orson Peters, chì combina u casu mediu veloce di quicksort aleatoriu cù u peghju casu più veloce di heapsort, mentre uttene u tempu lineare nantu à fette cù certi mudelli.
    /// Utilizza qualchì randomizazione per evità casi degenerati, ma cun un seed fissu per furnisce sempre un comportamentu deterministicu.
    ///
    /// In u peghju casu, l'algoritmu assigna un almacenamentu temporaneu in un `Vec<(K, usize)>` a lunghezza di a fetta.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Macro aiutu per l'indexazione di u nostru vector da u tippu u più chjucu pussibule, per riduce l'allocazione.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // L'elementi di `indices` sò unichi, cume sò indicizzati, dunque ogni sorta serà stabile in quantu à a fetta originale.
                // Usemu `sort_unstable` quì perchè richiede menu allocazione di memoria.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Copia `self` in un novu `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Quì, `s` è `x` ponu esse mudificati indipindente.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Copia `self` in un novu `Vec` cù un allocatore.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Quì, `s` è `x` ponu esse mudificati indipindente.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, vedi u modulu `hack` in stu schedariu per più infurmazioni.
        hack::to_vec(self, alloc)
    }

    /// Converte `self` in un vector senza cloni nè attribuzione.
    ///
    /// U vector resultante pò esse cunvertitu in una scatula via `Vec<T>U metudu `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ùn pò più esse adupratu perchè hè statu cunvertitu in `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, vedi u modulu `hack` in stu schedariu per più infurmazioni.
        hack::into_vec(self)
    }

    /// Crea un vector ripetendu una fetta `n` volte.
    ///
    /// # Panics
    ///
    /// Sta funzione serà panic se a capacità sferisce.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic à u overflow:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Se `n` hè più grande di zero, pò esse divisu cum'è `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` hè u numeru raprisentatu da u bit '1' u più à manca di `n`, è `rem` hè a parte restante di `n`.
        //
        //

        // Aduprà `Vec` per accede à `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` a ripetizione hè fatta radduppendu i tempi XPX "expn".
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Se `m > 0`, ci sò resti bits finu à u '1' più à manca.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` hà una capacità di `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) a ripetizione hè fatta cupiendu e prime ripetizioni `rem` da `buf` stessu.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Questu ùn si sovrappone micca dapoi `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` uguale à `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Appiatta una fetta di `T` in un valore unicu `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Appiattite una fetta di `T` in un valore unicu `Self::Output`, ponendu un separatore datu trà ognunu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Appiattite una fetta di `T` in un valore unicu `Self::Output`, ponendu un separatore datu trà ognunu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Restituisce un vector chì cuntene una copia di sta fetta induve ogni byte hè mappatu à u so equivalente ASCII maiuscule.
    ///
    ///
    /// E lettere ASCII 'a' à 'z' sò mappate à 'A' à 'Z', ma e lettere non ASCII sò invariate.
    ///
    /// Per fà maiuscule u valore in locu, aduprate [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Restituisce un vector chì cuntene una copia di sta fetta induve ogni byte hè mappatu à u so equivalente ASCII minuscule.
    ///
    ///
    /// E lettere ASCII 'A' à 'Z' sò mappate à 'a' à 'z', ma e lettere non ASCII sò invariate.
    ///
    /// Per minuscule u valore in situ, utilizate [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Estensione traits per fette nantu à tipi specifici di dati
////////////////////////////////////////////////////////////////////////////////

/// Helper trait per [`[T]: : concat`](slice::concat).
///
/// Note: u paràmetru di tippu `Item` ùn hè micca adupratu in stu trait, ma permette à l'implets di esse più genericu.
/// Senza ella, avemu questu errore:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Hè perchè ci puderianu esiste tippi `V` cù più impli `Borrow<[_]>`, tali chì si applicanu più tippi `T`:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// U tippu resultante dopu a concatenazione
    type Output;

    /// Implementazione di [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait per [`[T]: : join`](fetta::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// U tippu resultante dopu a concatenazione
    type Output;

    /// Implementazione di [`[T]: : join`](fetta::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implementazioni standard trait per fette
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // lascià calà qualcosa in mira chì ùn serà micca soprascrittu
        target.truncate(self.len());

        // target.len <= self.len per via di u truncatu sopra, dunque e fette quì sò sempre in limiti.
        //
        let (init, tail) = self.split_at(target.len());

        // riutilizà i valori cuntenuti allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Inserisce `v[0]` in a sequenza pre-ordinata `v[1..]` in modu chì `v[..]` sanu sia ordenatu.
///
/// Questa hè a subrutina integrale di sorte d'inserzione.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Ci hè trè modi per implementà l'inserzione quì:
            //
            // 1. Scambià elementi cunfinanti finu à chì u primu ghjunghje à a so destinazione finale.
            //    Tuttavia, cusì copiamu i dati intornu à più di ciò chì hè necessariu.
            //    Se l'elementi sò grandi strutture (custosi da copià), stu metudu serà lentu.
            //
            // 2. Iterate finu à chì u locu ghjustu per u primu elementu hè truvatu.
            // Poi spostate l'elementi chì li succedenu per fassi spaziu è infine mette lu in u foru restante.
            // Questu hè un bonu metudu.
            //
            // 3. Copia u primu elementu in una variabile temporanea.Iterate finu à chì si trovi u locu ghjustu.
            // Mentre andemu longu, copiate ogni elementu attraversatu in u slot precedente.
            // Infine, cupiate i dati da a variàbile timpuraria in u foru restante.
            // Stu metudu hè assai bonu.
            // I benchmarks anu dimustratu prestazioni ligeramente megliu ch'è cù u metudu 2nd.
            //
            // Tutti i metudi sò stati benchmarked, è u 3rd hà mostratu i migliori risultati.Cusì avemu sceltu quellu.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // U statu intermediu di u prucessu d'inserzione hè sempre tracciatu da `hole`, chì serve dui scopi:
            // 1. Prutegge l'integrità di `v` da panics in `is_less`.
            // 2. Riempie u foru restante in `v` à a fine.
            //
            // Panic sicurezza:
            //
            // Se `is_less` panics in qualunque puntu durante u prucessu, `hole` serà abbandunatu è riempie u foru in `v` cù `tmp`, assicurendu cusì chì `v` tene sempre tutti l'ogetti chì deteneva esattamente una volta.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` hè cascatu è cusì copia `tmp` in u foru restante in `v`.
        }
    }

    // Quandu hè cascatu, copie da `src` in `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Unisce scorri non decrescenti `v[..mid]` è `v[mid..]` aduprendu `buf` cum'è almacenamentu tempuraneu, è guarda u risultatu in `v[..]`.
///
/// # Safety
///
/// E duie fette ùn devenu micca esse viote è `mid` deve esse in limiti.
/// U buffer `buf` deve esse abbastanza longu per tene una copia di a fetta più corta.
/// Inoltre, `T` ùn deve micca esse un tippu di dimensioni zero.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // U prucessu di unione copia prima a corsa più breve in `buf`.
    // Poi traccia a corsa nova copiata è a corsa più lunga in avanti (o indietro), paragunendu i so prossimi elementi micca cunsumati è copiando u menu (o più grande) in `v`.
    //
    // Appena a corsa più breve hè cunsumata cumpletamente, u prucessu hè fattu.Se a corsa più longa si cunsuma prima, allora duvemu copià tuttu ciò chì resta di a corsa più corta in u foru restante in `v`.
    //
    // U statu intermediu di u prucessu hè sempre tracciatu da `hole`, chì serve dui scopi:
    // 1. Prutegge l'integrità di `v` da panics in `is_less`.
    // 2. Riempie u foru restante in `v` se a corsa più longa si cunsuma prima.
    //
    // Panic sicurezza:
    //
    // Se `is_less` panics in qualunque puntu durante u prucessu, `hole` serà abbandunatu è riempie u foru in `v` cù a gamma micca cunsumata in `buf`, assicurendu cusì chì `v` detenga sempre ogni oggettu chì hà tenutu inizialmente esattamente una volta.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // A corsa à manca hè più corta.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Inizialmente, questi indicatori indicanu l'iniziu di e so matrici.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Cunsumate u latu minore.
            // Sì uguale, preferite a corsa à manca per mantene a stabilità.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // A corsa curretta hè più corta.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Inizialmente, questi indicatori puntanu oltre l'estremità di e so matrici.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Cunsumate u latu più grande.
            // Sì uguale, preferite a corsa curretta per mantene a stabilità.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Infine, `hole` hè cascatu.
    // Se a corsa più corta ùn hè stata cumpletamente cunsumata, tuttu ciò chì ne ferma avà serà cupiatu in u foru in `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Quandu hè cascatu, copia a gamma `start..end` in `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ùn hè micca un tipu di dimensione zero, allora hè bè di dividelu per a so dimensione.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Questa sorta di fusione prende alcune (ma micca tutte) idee da TimSort, chì hè descritta in dettaglio [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// L'algoritmu identifica sottusicenzi strettamente discendenti è non discendenti, chì sò chjamati corsi naturali.Ci hè una pila di corse in attesa ancu da esse unite.
/// Ogni corsa nova truvata hè spinta nantu à a pila, è dopu alcune coppie di corse adiacenti sò unite finu à chì sti dui invarianti sò soddisfatti:
///
/// 1. per ogni `i` in `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. per ogni `i` in `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// L'invarianti assicuranu chì u tempu di corsa tutale sia *O*(*n*\*log(* n*)) u peghju casu.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // E fette finu à sta lunghezza sò ordinate cù una sorta d'inserzione.
    const MAX_INSERTION: usize = 20;
    // E corse assai corte sò allargate aduprendu una sorta d'inserzione per attraversà almenu quanti elementi.
    const MIN_RUN: usize = 10;

    // L'urdinamentu ùn hà micca cumpurtamentu significativu nantu à tippi di dimensioni zero.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // I matrici corti sò urdinati in locu per sorte d'inserzione per evità allocazioni.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Assignate un buffer per aduprà cum'è memoria di scratch.Mantenemu a lunghezza 0 in modo da pudemu tene in ellu copie superficiali di u cuntenutu di `v` senza risicà i medici in esecuzione nantu à e copie se `is_less` panics.
    //
    // Quandu si fonde duie corse ordinate, stu buffer tene una copia di a corsa più corta, chì averà sempre lunghezza à u più `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Per identificà e corse naturali in `v`, a traversemu in daretu.
    // Chì puderia sembrà una decisione strana, ma cunsiderate u fattu chì si fonde più spessu vanu in a direzione opposta (forwards).
    // Sicondu benchmarks, a fusione in avanti hè ligeramente più rapida cà a fusione in avanti.
    // Per cunclude, identificà e corse attraversendu indietro migliora e prestazioni.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Truvate a prossima corsa naturale, è invertevi se hè strettamente discendente.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Inserite alcuni elementi in più in a corsa se hè troppu cortu.
        // A sorte d'inserzione hè più rapida cà a sorte di fusione in sequenze corte, dunque questu migliora significativamente e prestazioni.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Spinghje sta corsa nantu à a pila.
        runs.push(Run { start, len: end - start });
        end = start;

        // Unisce alcune coppie di corse adiacenti per soddisfà l'invarianti.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Infine, esattamente una corsa deve restà in a pila.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Esamina a pila di corse è identifica a prossima coppia di corse da unisce.
    // Più specificamente, se `Some(r)` hè restituitu, significa chì `runs[r]` è `runs[r + 1]` devenu esse uniti dopu.
    // Se l'algoritmu deve cuntinuà à custruisce una nova corsa invece, `None` hè restituitu.
    //
    // TimSort hè infame per e so implementazioni buggy, cum'è discrittu quì:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // L'essenza di a storia hè: duvemu rinfurzà l'invarianti nantu à e prime quattru corse di a pila.
    // Infurzalli nantu à i trè primi ùn hè micca abbastanza per assicurà chì l'invarianti tenenu sempre per *tutte* e corse in a pila.
    //
    // Sta funzione verifica currettamente l'invarianti per e prime quattru corse.
    // Inoltre, se u top run principia à l'indice 0, richiederà sempre un'operazione di unione finu à chì a pila sia completamente crollata, per compie a sorta.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}