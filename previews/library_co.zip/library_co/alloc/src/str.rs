//! Fette di stringa Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! U tippu `&str` hè unu di i dui tippi di stringe principali, l'altru essendu `String`.
//! A differenza di u so omologu `String`, u so cuntenutu hè pigliatu in prestitu.
//!
//! # Usu Basicu
//!
//! Una dichjarazione stringa di basa di tippu `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Quì avemu dichjaratu una stringa litterale, cunnisciuta ancu cum'è una fetta di stringa.
//! I literali di stringa anu una vita statica, chì significa chì a stringa `hello_world` hè garantita per esse valida per a durata di tuttu u prugramma.
//!
//! Pudemu esplicitamente specificà a vita di "hello_world" ancu:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Parechji di l'usi in stu modulu sò aduprati solu in a cunfigurazione di prova.
// Hè più pulitu solu di spegne l'avvertimentu unused_imports cà di riparalli.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` in `Concat<str>` ùn hè micca significativu quì.
/// Stu paràmetru tipu di u trait esiste solu per attivà un altru impl.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // i cicli cù taglie codificate duranu assai più veloce specializanu i casi cù piccule lunghezze di separatore
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // riserva arbitraria di dimensione non cero
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Implementazione di unione ottimizzata chì funziona sia per Vec<T>(T: Copia) è u vec internu di String Attualmente (2018-05-13) ci hè un bug cù inferenza di tippu è specializazione (vede u numeru #36262) Per questa ragione SliceConcat<T>ùn hè micca specializatu per T: Copy è SliceConcat<str>hè l'unicu utilizatore di sta funzione.
// Hè lasciatu in postu per u tempu quandu quellu hè fissu.
//
// i limiti per String-join sò S: Imprestà<str>è per Vec-join Borrow <[T]> [T] è str tram impl AsRef <[T]> per qualchì T
// => s.borrow().as_ref() è avemu sempre fette
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // a prima fetta hè a sola senza un separatore chì a precede
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // calcula a lunghezza totale esatta di u Vec aghjuntu se u calculu `len` trabocca, avemu panic averiamu finitu di memoria in ogni casu è u restu di a funzione richiede tuttu u Vec pre-assignatu per a sicurezza
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // preparate un buffer micca inizializatu
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // copia separatore è fette sopra senza limiti i cuntrolli generanu cicli cù offsets codificati per i picculi separatori pussibuli miglioramenti massivi (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Una implementazione strana di prestitu pò restituisce diverse fette per u calculu di a lunghezza è a copia vera.
        //
        // Assicuratevi chì ùn esponemu micca byte non inizializzati à u chjamante.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Metodi per fette di stringa.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Converte un `Box<str>` in un `Box<[u8]>` senza cupià o attribuisce.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Sostituisce tutte e partite di un mudellu cù un'altra stringa.
    ///
    /// `replace` crea un novu [`String`], è copia i dati da sta fetta di stringa in ellu.
    /// Mentre facia cusì, prova à truvà partite di un mudellu.
    /// S'ellu ne trova, li rimpiazza cù a fetta di stringa di sustituzione.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Quandu u mudellu ùn currisponde micca:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Sostituisce e prime N partite di un mudellu cù un'altra stringa.
    ///
    /// `replacen` crea un novu [`String`], è copia i dati da sta fetta di stringa in ellu.
    /// Mentre facia cusì, prova à truvà partite di un mudellu.
    /// S'ellu ne trova, li rimpiazza cù a fetta di stringa di sustituzione à u più `count` volte.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Quandu u mudellu ùn currisponde micca:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Spergu di riduce i tempi di riassegnazione
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Restituisce l'equivalente in minuscule di sta fetta di stringa, cum'è un novu [`String`].
    ///
    /// 'Lowercase' hè definitu secondu i termini di a Proprietà Core Derivata Unicode `Lowercase`.
    ///
    /// Siccomu certi caratteri ponu espansione in più caratteri quandu cambiendu u casu, sta funzione rende un [`String`] invece di mudificà u parametru in locu.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Un esempiu complicatu, cù sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // ma à a fine di una parolla, hè ς, micca σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Lingue senza casu ùn sò micca cambiate:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ mappa à σ, eccettu à a fine di una parolla induve mappa à ς.
                // Questa hè l'unica (contextual) cundizionale ma mappatura indipendente da a lingua in `SpecialCasing.txt`, cusì codificheghja dura piuttostu ch'è avè un mecanismu "condition" genericu.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // per a definizione di `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Restituisce l'equivalente maiusculu di sta fetta di stringa, cum'è un novu [`String`].
    ///
    /// 'Uppercase' hè definitu secondu i termini di a Proprietà Core Derivata Unicode `Uppercase`.
    ///
    /// Siccomu certi caratteri ponu espansione in più caratteri quandu cambiendu u casu, sta funzione rende un [`String`] invece di mudificà u parametru in locu.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// I script senza casu ùn sò micca cambiati:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Un caratteru pò diventà parechje:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Converte un [`Box<str>`] in un [`String`] senza cupià o attribuisce.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Crea un novu [`String`] ripetendu una stringa `n` volte.
    ///
    /// # Panics
    ///
    /// Sta funzione serà panic se a capacità sferisce.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// A panic à u overflow:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Restituisce una copia di sta stringa induve ogni caratteru hè mappatu à u so equivalente in maiuscule ASCII.
    ///
    ///
    /// E lettere ASCII 'a' à 'z' sò mappate à 'A' à 'Z', ma e lettere non ASCII sò invariate.
    ///
    /// Per fà maiuscule u valore in locu, aduprate [`make_ascii_uppercase`].
    ///
    /// Per caratteri ASCII maiuscule in più di caratteri non ASCII, aduprate [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() cunserva l'invariante UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Restituisce una copia di sta stringa induve ogni caratteru hè mappatu à u so equivalente in minuscule ASCII.
    ///
    ///
    /// E lettere ASCII 'A' à 'Z' sò mappate à 'a' à 'z', ma e lettere non ASCII sò invariate.
    ///
    /// Per minuscule u valore in situ, utilizate [`make_ascii_lowercase`].
    ///
    /// Per minuscule caratteri ASCII in più di caratteri non ASCII, aduprate [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() cunserva l'invariante UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Converte una fetta in scatula di byte in una fetta di stringa in scatula senza verificà chì a stringa cuntene UTF-8 valida.
///
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}