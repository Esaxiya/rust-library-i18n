//! Utilità per furmà è stampà `String`s.
//!
//! Stu modulu cuntene u supportu di runtime per l'estensione di sintassi [`format!`].
//! Questa macro hè implementata in u compilatore per emette chjamate à stu modulu per formattà l'argumenti in runtime in stringhe.
//!
//! # Usage
//!
//! A macro [`format!`] hè destinata à esse familiare à quelli chì venenu da e funzioni `printf`/`fprintf` di C o da a funzione `str.format` di Python.
//!
//! Alcuni esempi di l'estensione [`format!`] sò:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" cù zeros di punta
//! ```
//!
//! Da queste, pudete vede chì u primu argumentu hè una stringa di furmatu.Hè necessariu da u compilatore per questu esse una stringa litterale;ùn pò micca esse una variabile passata in (per fà verificà a validità).
//! U compilatore analiserà a stringa di furmatu è determinerà se a lista di l'argumenti furniti hè adatta per passà à sta stringa di furmatu.
//!
//! Per cunvertisce un valore unicu in una stringa, aduprate u metudu [`to_string`].Questu utilizerà u [`Display`] furmatu trait.
//!
//! ## Parametri di pusizione
//!
//! Ogni argumentu di furmatu hè permessu di specificà quale argumentu di valore face riferenza, è se omessu si presume "the next argument".
//! Per esempiu, a stringa di furmatu `{} {} {}` piglierà trè parametri, è saranu furmattati in u listessu ordine chì sò dati.
//! A stringa di furmatu `{2} {1} {0}`, in ogni modu, formattaria argumenti in ordine inversu.
//!
//! E cose ponu diventà un pocu complicate una volta chì cuminciate à intriccià i dui tippi di specificatori di pusizione.U specificatore "next argument" pò esse pensatu cum'è un iteratore sopra l'argumentu.
//! Ogni volta chì si vede un specificatore "next argument", l'iteratore avanza.Questu porta à un cumpurtamentu cusì:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! L'iteratore internu annantu à l'argumentu ùn hè micca statu avanzatu quandu u primu `{}` hè vistu, cusì stampa u primu argumentu.Dopu à ghjunghje à u secondu `{}`, l'iteratore hà avanzatu versu u secondu argumentu.
//! Essenzialmente, i parametri chì denominanu esplicitamente u so argumentu ùn influenzanu micca i parametri chì ùn denominanu micca un argumentu in termini di specificatori di pusizione.
//!
//! Una stringa di furmatu hè necessaria per aduprà tutti i so argumenti, altrimente hè un errore di compilazione.Pudete riferisce à u listessu argumentu più di una volta in a stringa di furmatu.
//!
//! ## Parametri chjamati
//!
//! Rust stessu ùn hà micca un equivalente Python-like di parametri chjamati à una funzione, ma a macro [`format!`] hè una estensione di sintassi chì li permette di sfruttà parametri chjamati.
//! I parametri chjamati sò elencati à a fine di a lista di l'argumenti è anu a sintassi:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Per esempiu, e seguenti espressioni [`format!`] usanu tutte l'argumentu chjamatu:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Ùn hè micca valevule per mette parametri di pusizione (quelli senza nomi) dopu à argumenti chì anu nomi.Cum'è cù parametri di pusizione, ùn hè micca validu per furnisce parametri chjamati chì ùn sò micca usati da a stringa di furmatu.
//!
//! # Parametri di furmatu
//!
//! Ogni argumentu chì hè furmattatu pò esse trasfurmatu da un numeru di parametri di furmatu (currispondente à `format_spec` in [the syntax](#syntax)). Questi parametri affettanu a rappresentazione stringa di ciò chì hè furmattatu.
//!
//! ## Width
//!
//! ```
//! // Tutti questi stampanu "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Questu hè un paràmetru per u "minimum width" chì u furmatu deve piglià.
//! Se a stringa di u valore ùn riempie micca quanti caratteri, allora u padding specificatu da fill/alignment serà adupratu per occupà u spaziu necessariu (vede quì sottu).
//!
//! U valore per a larghezza pò ancu esse furnitu cum'è [`usize`] in a lista di parametri aghjunghjendu un postfix `$`, indicendu chì u secondu argumentu hè un [`usize`] chì specifica a larghezza.
//!
//! Riferendu à un argumentu cù a sintassi di u dollaru ùn affetta micca u cuntatore "next argument", allora hè di solitu una bona idea di riferisce à argumenti per pusizione, o aduprà argumenti chjamati.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! U caratteru di riempimentu opzionale è l'allineamentu sò furniti normalmente in cunjunzione cù u parametru [`width`](#width).Deve esse definitu prima di `width`, subitu dopu à `:`.
//! Questu indica chì se u valore in furmatu hè più chjucu di `width` alcuni caratteri in più seranu stampati intornu.
//! U riempimentu vene in e varianti seguenti per diversi allineamenti:
//!
//! * `[fill]<` - l'argumentu hè allinatu à manca in colonne `width`
//! * `[fill]^` - l'argumentu hè centratu in centru in colonne `width`
//! * `[fill]>` - l'argumentu hè allinatu à destra in colonne `width`
//!
//! U [fill/alignment](#fillalignment) predefinitu per non numerichi hè un spaziu è allinatu à sinistra.U predefinitu per i formattatori numerichi hè ancu un caratteru spaziu ma cù allineamentu di diritta.
//! Se a bandiera `0` (vede sottu) hè specificata per numerica, allora u caratteru di riempimentu implicitu hè `0`.
//!
//! Nutate bè chì l'allinjamentu ùn pò micca esse messu in opera da certi tippi.In particulare, ùn hè generalmente implementatu per u `Debug` trait.
//! Un bonu modu per assicurà chì u padding sia applicatu hè di formattà u vostru input, poi pad sta stringa resultante per uttene u vostru output:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Salute Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Queste sò tutte bandiere chì alteranu u cumpurtamentu di u formattatore.
//!
//! * `+` - Questu hè destinatu à tippi numerichi è indica chì u segnu deve sempre esse stampatu.I segni pusitivi ùn sò mai stampati per difettu, è u segnu negativu hè stampatu solu per difettu per u `Signed` trait.
//! Questa bandiera indica chì u segnu currettu (`+` o `-`) deve sempre esse stampatu.
//! * `-` - Attualmente micca adupratu
//! * `#` - Questa bandiera indica chì a forma "alternate" di stampa deve esse aduprata.E forme alternative sò:
//!     * `#?` - bella-stampate u furmatu [`Debug`]
//!     * `#x` - precede l'argumentu cù un `0x`
//!     * `#X` - precede l'argumentu cù un `0x`
//!     * `#b` - precede l'argumentu cù un `0b`
//!     * `#o` - precede l'argumentu cù un `0o`
//! * `0` - Questu hè adupratu per indicà per i formati interi chì u padding à `width` deve esse fattu sia cù un caratteru `0`, sia cunnosce i segni.
//! Un furmatu cum'è `{:08}` darà `00000001` per u numeru sanu `1`, mentre u listessu furmatu darà `-0000001` per u numeru sanu `-1`.
//! Nutate bè chì a versione negativa hà unu menu zeru chè a versione pusitiva.
//!         Nutate bè chì i zeru di padding sò sempre piazzati dopu à u segnu (s'ellu ci hè) è davanti à e cifre.Quandu hè adupratu cù a bandiera `#`, si applica una regula simile: i zeri di padding sò inseriti dopu u prefissu ma davanti à e cifre.
//!         U prefissu hè inclusu in a larghezza tutale.
//!
//! ## Precision
//!
//! Per i tippi non numerichi, questu pò esse cunsideratu cum'è "maximum width".
//! Se a stringa resultante hè più longa di questa larghezza, allora hè truncata finu à quanti caratteri è quellu valore truncatu hè emessu cù `fill`, `alignment` è `width` adatti se questi parametri sò impostati.
//!
//! Per i tippi integrali, questu hè ignoratu.
//!
//! Per i tippi à virgula flottante, questu indica quante cifre dopu u puntu decimali devenu esse stampate.
//!
//! Ci hè trè modi pussibuli di specificà u `precision` desideratu:
//!
//! 1. Un numeru interu `.N`:
//!
//!    u numeru `N` stessu hè a precisione.
//!
//! 2. Un numeru interu o nome seguitatu da u segnu di dollaru `.N$`:
//!
//!    aduprate u furmatu *argumentu*`N` (chì deve esse un `usize`) cum'è precisione.
//!
//! 3. Un asteriscu `.*`:
//!
//!    `.*` significa chì questu `{...}` hè assuciatu cù *dui* input di furmatu piuttostu cà unu: u primu input tene a precisione `usize`, è u secondu detiene u valore da stampà.
//!    Innota chì in questu casu, se unu usa a stringa di furmatu `{<arg>:<spec>.*}`, allora a parte `<arg>` si riferisce à u valore* per stampà, è u `precision` deve vene in l'input precedente `<arg>`.
//!
//! Per esempiu, e chjamate seguenti stampanu tutte a stessa cosa `Hello x is 0.01000`:
//!
//! ```
//! // Bonghjornu {arg 0 ("x")} hè {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Bonghjornu {arg 1 ("x")} hè {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Bonghjornu {arg 0 ("x")} hè {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Bonghjornu {next arg ("x")} hè {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Bonghjornu {next arg ("x")} hè {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Bonghjornu {next arg ("x")} hè {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Mentre questi:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! stampate trè cose significativamente diverse:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! In certi linguaghji di prugrammazione, u cumpurtamentu di e funzioni di furmatu di e stringhe dipende da a regolazione locale di u sistema operativu.
//! E funzioni di furmatu furnite da a libreria standard di Rust ùn anu nisun cuncettu di locale è pruduceranu i listessi risultati in tutti i sistemi indipendentemente da a cunfigurazione di l'utente.
//!
//! Per esempiu, u codice seguente stamperà sempre `1.5` ancu se u locale di u sistema utilizza un separatore decimale altru ch'è un puntu.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! I caratteri letterali `{` è `}` ponu esse inclusi in una stringa precedenduli cù u listessu caratteru.Per esempiu, u caratteru `{` hè scappatu cù `{{` è u caratteru `}` hè scappatu cù `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Per riassume, quì pudete truvà a grammatica cumpleta di e stringhe di furmatu.
//! A sintassi per a lingua di furmatu aduprata hè tirata da altre lingue, dunque ùn deve micca esse troppu straniera.L'argumenti sò furmattuti cù sintassi Python-like, significendu chì l'argumenti sò circundati da `{}` invece di u C-like `%`.
//! A grammatica attuale per a sintassi di furmatu hè:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! In a grammatica sopra, `text` ùn pò cuntene alcunu caratteru `'{'` o `'}'`.
//!
//! # Formattazione di traits
//!
//! Quandu dumandate chì un argumentu sia furmattatu cù un tipu particulare, state in realtà dumandendu chì un argumentu attribuisca à un trait particulare.
//! Questu permette à parechji tippi attuali di esse formattati via `{:x}` (cum'è [`i8`] è [`isize`]).A mappatura attuale di tippi à traits hè:
//!
//! * *nunda* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] cù numeri interi esadecimali in minuscule
//! * `X?` ⇒ [`Debug`] cù numeri interi esadecimali maiuscoli
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Ciò chì significa hè chì ogni tippu d'argumentu chì implementa u [`fmt::Binary`][`Binary`] trait pò esse dopu furmatu cù `{:b}`.L'implementazioni sò furnite per questi traits per una serie di tippi primitivi da a biblioteca standard ancu.
//!
//! Se ùn hè specificatu alcun furmatu (cum'è in `{}` o `{:6}`), allora u furmatu trait adupratu hè u [`Display`] trait.
//!
//! Quandu implementate un furmatu trait per u vostru propiu tipu, duverete implementà un metudu di firma:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // u nostru tippu persunalizatu
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! U vostru tipu serà passatu cum'è `self` per riferimentu, è allora a funzione deve emette uscita in u flussu `f.buf`.Tocca à ogni furmatu di implementazione trait di rispettà currettamente i parametri di formattazione richiesti.
//! I valori di questi parametri seranu elencati in i campi di a struttura [`Formatter`].Per aiutà cun questu, a struttura [`Formatter`] furnisce ancu alcuni metudi d'aiutu.
//!
//! Inoltre, u valore di ritornu di sta funzione hè [`fmt::Result`] chì hè un alias di tipu di [`Risultatu`]`<(),`[`std: : fmt::Errore`] `>`.
//! L'implementazioni di furmatu devenu assicurà chì propaganu errori da u [`Formatter`] (per esempiu, quandu chjamanu [`write!`]).
//! Tuttavia, ùn devenu mai restituisce errori spuriously.
//! Questu hè, una implementazione di furmatu deve è pò restituisce un errore solu se u [`Formatter`] passatu torna un errore.
//! Hè perchè, à u cuntrariu di ciò chì a funzione di signatura puderia suggerisce, u furmatu di stringa hè un'operazione infallibile.
//! Sta funzione restituisce solu un risultatu perchè a scrittura à u flussu sottostante pò fiascà è deve furnisce un modu per propagà u fattu chì un errore hè accadutu in u backup di a pila.
//!
//! Un esempiu di implementazione di u furmatu traits s'assumiglia:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // U valore `f` implementa u `Write` trait, chì hè ciò chì scrive!macro aspetta.
//!         // Nutate bè chì stu furmatu ignora e varie bandiere furnite per furmattà e stringhe.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Differenti traits permettenu diverse forme di uscita di un tippu.
//! // U significatu di stu furmatu hè di stampà a magnitudine di un vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Rispettate e bandiere di furmatu aduprendu u metudu helper `pad_integral` nantu à l'ughjettu Formatter.
//!         // Vede a ducumentazione di u metudu per i dettagli, è a funzione `pad` pò esse usata per pad strings.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Queste duie formatting traits anu scopi distinti:
//!
//! - [`fmt::Display`][`Display`] l'implementazioni affirmanu chì u tipu pò esse fedelmente rapprisentatu cum'è una stringa UTF-8 in ogni momentu.Ùn hè **micca** previstu chì tutti i tippi implementanu u [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] l'implementazioni devenu esse implementate per **tutti i** tipi publichi.
//!   A produzzione raprisenterà tipicamente u statu internu u più fedelmente pussibule.
//!   U scopu di u [`Debug`] trait hè di facilità a debugging codice Rust.In a maiò parte di i casi, aduprà `#[derive(Debug)]` hè abbastanza è cunsigliatu.
//!
//! Alcuni esempi di u risultatu da i dui traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macro cunnessi
//!
//! Ci hè una quantità di macro cunnessi in a famiglia [`format!`].Quelli chì sò attualmente implementati sò:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Questu è [`writeln!`] sò duie macro chì sò aduprate per emette a stringa di furmatu à un flussu specificatu.Questu hè adupratu per prevene allocazioni intermedie di stringhe di furmatu è invece scrive direttamente l'output.
//! Sutta u cappucciu, sta funzione invoca in realtà a funzione [`write_fmt`] definita nantu à u [`std::io::Write`] trait.
//! Esempiu d'usu hè:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Questu è [`println!`] emettenu a so uscita à stdout.Simile à a macro [`write!`], l'ubbiettivu di queste macro hè di evità allocazioni intermedie quandu stampa stampa.Esempiu d'usu hè:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! E macro [`eprint!`] è [`eprintln!`] sò identiche à [`print!`] è [`println!`], rispettivamente, eccettu chì emettenu a so uscita à stderr.
//!
//! ### `format_args!`
//!
//! Questa hè una macro curiosa aduprata per passà in securità intornu à un oggettu opacu chì descrive a stringa di furmatu.Questu oggettu ùn richiede alcuna allocazione di cumuli per creà, è riferisce solu l'infurmazioni nantu à a pila.
//! Sutta u cappucciu, tutte e macro cunnesse sò implementate in termini di questu.
//! Prima, un esempiu di usu hè:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! U risultatu di a macro [`format_args!`] hè un valore di tippu [`fmt::Arguments`].
//! Questa struttura pò esse passata à e funzioni [`write`] è [`format`] in questu modulu per elaborà a stringa di furmatu.
//! U scopu di sta macro hè ancu di prevene ancu di più allocazioni intermedie quandu si tratta di formatting string.
//!
//! Per esempiu, una libreria di logging puderia aduprà a sintassi di furmatu standard, ma passerebbe internamente intornu à sta struttura finu à ch'ella sia stata determinata induve duveria andà l'output.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// A funzione `format` piglia una struttura [`Arguments`] è restituisce a stringa formattata resultante.
///
///
/// L'istanza [`Arguments`] pò esse creata cù a macro [`format_args!`].
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Per piacè nutate chì aduprà [`format!`] pò esse preferibile.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}