//! Una stringa cultivabile codificata UTF-8.
//!
//! Stu modulu cuntene u tippu [`String`], u [`ToString`] trait per cunvertisce in stringhe, è parechji tippi d'errore chì ponu resultà da travaglià cù [`String`] s.
//!
//!
//! # Examples
//!
//! Ci hè parechje manere di creà un novu [`String`] da una stringa litterale:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Pudete creà un novu [`String`] da un esistente cuncatenendu cun
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Se avete un vector di byte UTF-8 validi, pudete fà un [`String`] da ellu.Pudete fà l'inversu ancu.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Sapemu chì questi bytes sò validi, allora useremu `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Una stringa cultivabile codificata UTF-8.
///
/// U tippu `String` hè u tippu di stringa più cumunu chì hà a pruprietà annantu à u cuntenutu di a stringa.Hà una relazione stretta cù u so omologu pigliatu in prestitu, u primitivu [`str`].
///
/// # Examples
///
/// Pudete creà un `String` da [a literal string][`str`] cù [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Pudete aghjunghje un [`char`] à un `String` cù u metudu [`push`], è aghjunghje un [`&str`] cù u metudu [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Se avete un vector di UTF-8 byte, pudete creà un `String` da ellu cù u metudu [`from_utf8`]:
///
/// ```
/// // qualchi bytes, in un vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Sapemu chì questi bytes sò validi, allora useremu `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// I «String» sò sempre validi UTF-8.Questu hà alcune implicazioni, a prima di e quali hè chì se avete bisognu di una stringa chì ùn sia micca UTF-8, cunsiderate [`OsString`].Hè simile, ma senza a restrizione UTF-8.A seconda implicazione hè chì ùn pudete micca indexà in un `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// L'indexazione hè destinata à esse un'operazione à tempu custante, ma a codifica UTF-8 ùn ci permette micca di fà quessa.Inoltre, ùn hè micca chjaru chì tippu di cose l'indice deve restituisce: un byte, un puntu di codici, o un cluster di grafema.
/// I metudi [`bytes`] è [`chars`] restituiscenu iteratori sopra i primi dui, rispettivamente.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s implement [[Deref`]`<Target=str>`, è cusì ereditanu tutti i metudi di [` str`].Inoltre, questu significa chì pudete passà un `String` à una funzione chì piglia un [`&str`] aduprendu un amperu (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Questu creerà un [`&str`] da u `String` è u passerà. Sta cunversione hè assai economica, è dunque in generale, e funzioni accettanu [`&str`] s cum'è argumenti à menu chì ùn anu bisognu di un `String` per qualchì ragione specifica.
///
/// In certi casi Rust ùn hà micca abbastanza infurmazione per fà sta cunversione, cunnisciuta cum'è coercizione [`Deref`].In l'esempiu seguente una fetta di stringa [`&'a str`][`&str`] implementa u trait `TraitExample`, è a funzione `example_func` piglia tuttu ciò chì implementa u trait.
/// In questu casu Rust averia bisognu di fà duie cunversioni implicite, chì Rust ùn hà micca i mezi per fà.
/// Per questa ragione, l'esempiu seguente ùn cumpilarà micca.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Ci hè duie opzioni chì funzioneranu invece.U primu seria cambià a linea `example_func(&example_string);` in `example_func(example_string.as_str());`, aduprendu u metudu [`as_str()`] per estrarre esplicitamente a fetta di stringa chì cuntene a stringa.
/// U secondu modu cambia `example_func(&example_string);` in `example_func(&*example_string);`.
/// In questu casu stamu deriferenzendu un `String` à un [`str`][`&str`], poi riferendu u [`str`][`&str`] torna à [`&str`].
/// U secondu modu hè più idiomaticu, tuttavia tramindui travaglianu per fà a cunversione esplicitamente piuttostu chè di fidassi à a cunversione implicita.
///
/// # Representation
///
/// Un `String` hè cumpostu da trè cumpunenti: un puntatore à qualchi bytes, una lunghezza è una capacità.U puntatore punta à un buffer internu chì `String` usa per magazzinà i so dati.A lunghezza hè u numeru di byte attualmente memorizzati in u buffer, è a capacità hè a dimensione di u buffer in byte.
///
/// Cusì, a lunghezza serà sempre menu o uguale à a capacità.
///
/// Stu buffer hè sempre almacenatu in a mansa.
///
/// Pudete fighjà questi cù i metudi [`as_ptr`], [`len`] è [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Aghjurnate questu quandu vec_into_raw_parts hè stabilizatu.
/// // Impedisce di calà automaticamente i dati di a String
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // a storia hà diciannove byte
/// assert_eq!(19, len);
///
/// // Pudemu ricustruisce una String fora di ptr, len, è capacità.
/// // Tuttu questu hè periculosu perchè simu responsabili di assicurà chì i cumpunenti sò validi:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Se un `String` hà abbastanza capacità, l'aggiunta di elementi à questu ùn serà micca riassegnatu.Per esempiu, cunsiderate stu prugramma:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Questu pruduce u seguente:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// À u primu, ùn avemu micca memoria attribuita à tutti, ma cume aghjustemu à a stringa, aumenta a so capacità in modo adeguatu.Se invece usamu u metudu [`with_capacity`] per assignà a capacità curretta inizialmente:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Finemu cun una uscita diversa:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Quì, ùn ci hè bisognu di assignà più memoria in u ciclu.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Un valore d'errore pussibule quandu si cunverte un `String` da un byte UTF-8 vector.
///
/// Stu tipu hè u tipu d'errore per u metudu [`from_utf8`] in [`String`].
/// Hè cuncepitu in tale modu per evità cun attenzione riallocazioni: u metudu [`into_bytes`] restituirà u byte vector chì hè statu adupratu in u tentativu di cunversione.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// U tippu [`Utf8Error`] furnitu da [`std::str`] raprisenta un errore chì pò accade quandu si cunverte una fetta di [`u8`] s in un [`&str`].
/// In questu sensu, hè un analogu à `FromUtf8Error`, è pudete ottene unu da un `FromUtf8Error` attraversu u metudu [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// // qualchi bytes invalidi, in un vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Un valore d'errore pussibule quandu si cunverte un `String` da una fetta di byte UTF-16.
///
/// Stu tipu hè u tipu d'errore per u metudu [`from_utf16`] in [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Usu di basa:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Crea un novu `String` viotu.
    ///
    /// Datu chì u `String` hè viotu, questu ùn assignerà micca un buffer iniziale.Mentre chì significa chì questa operazione iniziale hè assai economica, pò causà allocazione eccessiva dopu quandu aghjunghjite dati.
    ///
    /// Se avete una idea di quantu dati tenerà l `String`, cunsiderate u metudu [`with_capacity`] per impedisce una riassegnazione eccessiva.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Crea un novu `String` vacante cù una capacità particulare.
    ///
    /// `String`s anu un buffer internu per mantene i so dati.
    /// A capacità hè a lunghezza di quellu buffer, è pò esse interrugata cù u metudu [`capacity`].
    /// Stu metudu crea un `String` vacante, ma unu cù un buffer iniziale chì pò cuntene `capacity` bytes.
    /// Questu hè utile quandu pudete aghjustà una mansa di dati à u `String`, riducendu u numeru di riassegnazioni chì deve fà.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Se a capacità data hè `0`, ùn serà micca attribuita, è questu metudu hè identicu à u metudu [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // A String ùn cuntene micca caratteri, ancu s'ellu hà capacità per più
    /// assert_eq!(s.len(), 0);
    ///
    /// // Quessi sò tutti fatti senza riallocazione ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ma questu pò fà riallocà a stringa
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cù cfg(test) u metudu `[T]::to_vec` inerente, chì hè necessariu per sta definizione di metudu, ùn hè micca dispunibule.
    // Postu chì ùn avemu micca bisognu di stu metudu per scopi di prova, l'aghju solu stub NB vede u modulu slice::hack in slice.rs per più infurmazione
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Converte un vector di byte in un `String`.
    ///
    /// Una stringa ([`String`]) hè fatta di bytes ([`u8`]), è un vector di bytes ([`Vec<u8>`]) hè fattu di bytes, cusì sta funzione cunverte trà i dui.
    /// Micca tutte e fette di byte sò valide `String`s, tuttavia: `String` richiede chì sia UTF-8 valida.
    /// `from_utf8()` verifica per assicurà chì i byte sò validi UTF-8, è poi face a cunversione.
    ///
    /// Se site sicuru chì a fetta byte hè UTF-8 valida, è ùn vulete micca incurru u soprappu di u cuntrollu di validità, ci hè una versione micca sicura di sta funzione, [`from_utf8_unchecked`], chì hà u stessu cumpurtamentu ma salta u cuntrollu.
    ///
    ///
    /// Stu metudu averà cura di ùn cupià micca u vector, per u nome di l'efficienza.
    ///
    /// Se avete bisognu di un [`&str`] invece di un `String`, cunsiderate [`str::from_utf8`].
    ///
    /// L'inversu di stu metudu hè [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Restituisce [`Err`] se a fetta ùn hè micca UTF-8 cù una descrizzione perchè i byte furniti ùn sò micca UTF-8.U vector chì avete spostatu hè ancu inclusu.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // qualchi bytes, in un vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Sapemu chì questi bytes sò validi, allora useremu `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bytes incorretti:
    ///
    /// ```
    /// // qualchi bytes invalidi, in un vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Vede i documenti per [`FromUtf8Error`] per più infurmazioni nantu à ciò chì pudete fà cun questu errore.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Converte una fetta di bytes in una stringa, cumprese caratteri invalidi.
    ///
    /// E corde sò fatte di bytes ([`u8`]), è una fetta di bytes ([`&[u8]`][byteslice]) hè fatta di bytes, cusì sta funzione cunverte trà i dui.Micca tutte e fette di byte sò stringhe valide, tuttavia: e stringhe sò necessarie per esse UTF-8 valide.
    /// Durante sta cunversione, `from_utf8_lossy()` rimpiazzerà qualsiasi sequenza UTF-8 invalida cù [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], chì pare cusì:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Sè site sicuru chì a fetta byte hè UTF-8 valida, è ùn vulete micca incorre in u soprapprezzu di a cunversione, ci hè una versione periculosa di sta funzione, [`from_utf8_unchecked`], chì hà u stessu cumpurtamentu ma salta i cuntrolli.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Questa funzione restituisce un [`Cow<'a, str>`].Se a nostra fetta byte hè invalida UTF-8, allora avemu bisognu di inserisce i caratteri di rimpiazzamentu, chì cambieranu a dimensione di a stringa, è dunque, necessitanu un `String`.
    /// Ma s'ellu hè digià validu UTF-8, ùn avemu micca bisognu di una nova attribuzione.
    /// Stu tipu di ritornu ci permette di trattà i dui casi.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // qualchi bytes, in un vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bytes incorretti:
    ///
    /// ```
    /// // qualchi bytes invalidi
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Decodificà un UTF-16-codificatu vector `v` in un `String`, restituendu [`Err`] se `v` cuntene dati invalidi.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Questu ùn hè micca fattu via collect: <Result<_, _>> () per ragioni di prestazione.
        // FIXME: a funzione pò esse simplificata di novu quandu #48994 hè chjusu.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Decodifica una fetta `v` codificata UTF-16 in un `String`, rimpiazzendu i dati invalidi cù [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// A differenza di [`from_utf8_lossy`] chì restituisce un [`Cow<'a, str>`], `from_utf16_lossy` restituisce un `String` postu chì a cunversione UTF-16 in UTF-8 richiede una allocazione di memoria.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Decompone un `String` in i so cumpunenti grezzi.
    ///
    /// Restituisce u puntatore grezzu à i dati sottostanti, a lunghezza di a stringa (in byte), è a capacità attribuita di i dati (in byte).
    /// Quessi sò i listessi argumenti in u listessu ordine chì l'argumenti per [`from_raw_parts`].
    ///
    /// Dopu avè chjamatu sta funzione, u chjamante hè rispunsevule per a memoria previamente gestita da u `String`.
    /// L'unicu modu per fà questu hè di cunvertisce u puntatore grezzu, a lunghezza è a capacità in un `String` cù a funzione [`from_raw_parts`], permettendu à u distruttore di fà a pulizia.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Crea un novu `String` da una lunghezza, capacità è puntatore.
    ///
    /// # Safety
    ///
    /// Questu hè assai periculosu, per via di u numeru d'invarianti chì ùn sò micca verificati:
    ///
    /// * A memoria in `buf` deve esse stata attribuita in precedenza da u listessu allocatore chì a biblioteca standard usa, cun un allineamentu richiestu di esattamente 1.
    /// * `length` deve esse menu o uguale à `capacity`.
    /// * `capacity` deve esse u valore currettu.
    /// * U primu `length` byte in `buf` deve esse validu UTF-8.
    ///
    /// A violazione di questi pò causà prublemi cum'è a corruzzione di e strutture di dati interni di l'allocatore.
    ///
    /// A pruprietà di `buf` hè effittivamenti trasferita à u `String` chì pò dopu riallocà, riallocà o cambià u cuntenutu di a memoria indicatu da u puntatore à vuluntà.
    /// Assicuratevi chì nunda di più utilizi u puntatore dopu avè chjamatu sta funzione.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Aghjurnate questu quandu vec_into_raw_parts hè stabilizatu.
    ///     // Impedisce di calà automaticamente i dati di a String
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Converte un vector di byte in un `String` senza verificà chì a stringa cuntene UTF-8 validu.
    ///
    /// Vede a versione sicura, [`from_utf8`], per più infurmazioni.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Sta funzione ùn hè micca sicura perchè ùn verifica micca chì i bytes passati per ella sò UTF-8 validi.
    /// Se questa restrizione hè violata, pò causà prublemi di sicurezza in memoria cù l'utilizatori future di u `String`, chì u restu di a biblioteca standard assume chì `String`s sò UTF-8 validi.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // qualchi bytes, in un vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Converte un `String` in un byte vector.
    ///
    /// Questu cunsuma u `String`, allora ùn avemu micca bisognu di cupià u so cuntenutu.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Estrae una fetta di stringa chì cuntene tuttu u `String`.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Converte un `String` in una fetta di stringa mutabile.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Aghjusta una fetta di stringa data à a fine di stu `String`.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Restituisce a capacità di sta String, in byte.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Assicura chì a capacità di sta "String" hè almenu `additional` byte più grande di a so lunghezza.
    ///
    /// A capacità pò esse aumentata di più di `additional` byte se sceglie, per impedisce riallocu frequenti.
    ///
    ///
    /// Se ùn vulete micca stu cumpurtamentu "at least", vedi u metudu [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics se a nova capacità suprana [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Questu pò micca veramente aumentà a capacità:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // avà hà una lunghezza di 2 è una capacità di 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Postu chì avemu dighjà una capacità 8 in più, chjamendu questu ...
    /// s.reserve(8);
    ///
    /// // ... ùn cresce micca.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Assicura chì a capacità di sta String sia `additional` byte più grande di a so lunghezza.
    ///
    /// Pensate à aduprà u metudu [`reserve`] à menu chì ùn sapiate assolutamente megliu cà l'allocatore.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics se a nova capacità suprana `usize`.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Questu pò micca veramente aumentà a capacità:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // avà hà una lunghezza di 2 è una capacità di 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Postu chì avemu dighjà una capacità 8 in più, chjamendu questu ...
    /// s.reserve_exact(8);
    ///
    /// // ... ùn cresce micca.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Prova à riservà capacità per almenu `additional` più elementi da inserisce in u `String` datu.
    /// A cullezzione pò riservà più spaziu per evità riallocazioni frequenti.
    /// Dopu avè chjamatu `reserve`, a capacità serà più grande o uguale à `self.len() + additional`.
    /// Ùn face nunda se a capacità hè dighjà sufficiente.
    ///
    /// # Errors
    ///
    /// Se a capacità suprana, o l'allocatore riporta un fallimentu, allora un errore hè restituitu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pre-riserva a memoria, surtendu sì ùn pudemu micca
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Avà sapemu chì questu ùn pò micca OOM in mezu à u nostru travagliu cumplessu
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Prova à riservà a capacità minima per esattamente `additional` più elementi da inserisce in u `String` datu.
    ///
    /// Dopu avè chjamatu `reserve_exact`, a capacità serà più grande o uguale à `self.len() + additional`.
    /// Ùn face nunda se a capacità hè dighjà sufficiente.
    ///
    /// Nutate bè chì l'allocatore pò dà à a cullezzione più spaziu di quantu dumanda.
    /// Dunque, a capacità ùn pò esse invucata per esse precisamente minima.
    /// Preferite `reserve` se si prevede inserzioni future.
    ///
    /// # Errors
    ///
    /// Se a capacità suprana, o l'allocatore riporta un fallimentu, allora un errore hè restituitu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pre-riserva a memoria, surtendu sì ùn pudemu micca
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Avà sapemu chì questu ùn pò micca OOM in mezu à u nostru travagliu cumplessu
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Riduce a capacità di stu `String` per abbinà a so lunghezza.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Riduce a capacità di stu `String` cun un limite inferiore.
    ///
    /// A capacità fermerà almenu quant'è a lunghezza è u valore furnitu.
    ///
    ///
    /// Se a capacità attuale hè menu di u limitu inferiore, questu hè un no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Aghjunghje u [`char`] datu à a fine di stu `String`.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Restituisce una fetta byte di u cuntenutu di sta `String`.
    ///
    /// L'inversu di stu metudu hè [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Accurta stu `String` à a lunghezza specificata.
    ///
    /// Se `new_len` hè più grande di a lunghezza attuale di a stringa, questu ùn hà micca effetti.
    ///
    ///
    /// Nutate bè chì stu metudu ùn hà alcun effettu nant'à a capacità assignata di a stringa
    ///
    /// # Panics
    ///
    /// Panics se `new_len` ùn si trova nantu à una fruntiera [`char`].
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Elimina l'ultimu caratteru da u buffer di stringa è u restituisce.
    ///
    /// Restituisce [`None`] se stu `String` hè viotu.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Elimina un [`char`] da questu `String` in una pusizione byte è u restituisce.
    ///
    /// Si tratta di un'operazione *O*(*n*), chì richiede di cupià ogni elementu in u buffer.
    ///
    /// # Panics
    ///
    /// Panics se `idx` hè più grande o uguale à a lunghezza di a "String", o s'ellu ùn si trova nantu à una fruntiera [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Elimina tutte e partite di u mudellu `pat` in u `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// E partite seranu rilevate è rimosse iterativamente, dunque in i casi in cui i mudelli si sovrapponganu, solu u primu mudellu serà eliminatu:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SICUREZZA: u principiu è a fine saranu nantu à i limiti di byte utf8 per
        // i documenti Searcher
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Conserva solu i caratteri specificati da u predicatu.
    ///
    /// In altre parolle, sguassate tutti i caratteri `c` in modu chì `f(c)` restituisce `false`.
    /// Stu metudu opera in situ, visitendu ogni caratteru esattamente una volta in l'ordine originale, è cunserva l'ordine di i caratteri ritenuti.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// L'ordine esattu pò esse utile per seguità u statu esternu, cum'è un indice.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Puntate idx à u prossimu char
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Inserisce un caratteru in questu `String` in una pusizione byte.
    ///
    /// Si tratta di un'operazione *O*(*n*) chì richiede di cupià ogni elementu in u buffer.
    ///
    /// # Panics
    ///
    /// Panics se `idx` hè più grande di a lunghezza di a "String", o s'ellu ùn si trova micca nantu à una fruntiera [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Inserisce una fetta di stringa in questu `String` in una pusizione byte.
    ///
    /// Si tratta di un'operazione *O*(*n*) chì richiede di cupià ogni elementu in u buffer.
    ///
    /// # Panics
    ///
    /// Panics se `idx` hè più grande di a lunghezza di a "String", o s'ellu ùn si trova micca nantu à una fruntiera [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Restituisce un riferimentu mutevule à u cuntenutu di stu `String`.
    ///
    /// # Safety
    ///
    /// Sta funzione ùn hè micca sicura perchè ùn verifica micca chì i bytes passati per ella sò UTF-8 validi.
    /// Se questa restrizione hè violata, pò causà prublemi di sicurezza in memoria cù l'utilizatori future di u `String`, chì u restu di a biblioteca standard assume chì `String`s sò UTF-8 validi.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Restituisce a lunghezza di questu `String`, in byte, micca [`char`] s o grafemi.
    /// In altre parolle, ùn pò micca esse ciò chì un umanu cunsidereghja a lunghezza di a stringa.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Ritorna `true` se questu `String` hà una lunghezza di zero, è `false` altrimenti.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Divide a stringa in duie à l'indice di byte datu.
    ///
    /// Restituisce un `String` appena attribuitu.
    /// `self` cuntene bytes `[0, at)`, è u `String` restituitu cuntene bytes `[at, len)`.
    /// `at` deve esse à u cunfini di un puntu di codice UTF-8.
    ///
    /// Nota chì a capacità di `self` ùn cambia.
    ///
    /// # Panics
    ///
    /// Panics se `at` ùn hè micca nantu à una fruntiera di u puntu di codice `UTF-8`, o s'ellu hè al di là di l'ultimu puntu di codice di a stringa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Truncate questu `String`, eliminendu tuttu u cuntenutu.
    ///
    /// Mentre questu significa chì u `String` avrà una lunghezza di zero, ùn tocca micca a so capacità.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Crea un iteratore di drenu chì elimina a gamma specificata in u `String` è dà u `chars` eliminatu.
    ///
    ///
    /// Note: A gamma di elementi hè eliminata ancu se l'iteratore ùn hè micca cunsumatu finu à a fine.
    ///
    /// # Panics
    ///
    /// Panics se u puntu di partenza o di fine ùn si trovanu micca nantu à una fruntiera [`char`], o se sò fora di i limiti.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Elimina a gamma finu à u β da a stringa
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Una gamma completa sblocca a stringa
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Sicurezza di memoria
        //
        // A versione String di Drain ùn hà micca i prublemi di sicurezza di memoria di a versione vector.
        // I dati sò solu piani bytes.
        // Perchè a rimozione di a gamma accade in Drop, se l'iteratore Drain hè filtratu, a rimozione ùn accadrà micca.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Pigliate dui prestiti simultanei.
        // A Corda &mut ùn serà accessu finu à chì l'iterazione sia finita, in Drop.
        let self_ptr = self as *mut _;
        // SICUREZZA: `slice::range` è `is_char_boundary` facenu i cuntrolli di limiti adatti.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Elimina u intervallu specificatu in a stringa, è a rimpiazza cù a stringa data.
    /// A stringa data ùn hà micca bisognu di esse a stessa lunghezza cum'è a gamma.
    ///
    /// # Panics
    ///
    /// Panics se u puntu di partenza o di fine ùn si trovanu micca nantu à una fruntiera [`char`], o se sò fora di i limiti.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Rimpiazzà a gamma finu à u β da a stringa
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Sicurezza di memoria
        //
        // Replace_range ùn hà micca i prublemi di sicurezza di memoria di un Splice vector.
        // di a versione vector.I dati sò solu piani bytes.

        // AVVERTENZA: L'inlinazione di sta variabile ùn seria micca solidu (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // AVVERTENZA: L'inlinazione di sta variabile ùn seria micca solidu (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Aduprà `range` di novu ùn seria micca solidu (#81138) Assumemu chì i limiti riportati da `range` restanu listessi, ma una implementazione contraria puderia cambià trà chjamate
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Converte questu `String` in una [`Box`]`<`[`str`] `>`.
    ///
    /// Questu abbandunà ogni capacità in eccessu.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Restituisce una fetta di [`u8`] s byte chì sò stati pruvati à cunvertisce in un `String`.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // qualchi bytes invalidi, in un vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Restituisce i byte chì sò stati pruvati à cunvertisce in un `String`.
    ///
    /// Stu metudu hè custruitu cù cura per evità l'assignazione.
    /// Cunsumerà l'errore, alluntanendu i bytes, in modu chì una copia di i bytes ùn abbia bisognu di esse fatta.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // qualchi bytes invalidi, in un vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Fetch un `Utf8Error` per uttene più dettagli nantu à u fallimentu di cunversione.
    ///
    /// U tippu [`Utf8Error`] furnitu da [`std::str`] raprisenta un errore chì pò accade quandu si cunverte una fetta di [`u8`] s in un [`&str`].
    /// In questu sensu, hè un analogu à `FromUtf8Error`.
    /// Vede a so documentazione per più dettagli nantu à aduprà.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // qualchi bytes invalidi, in un vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // u primu byte hè invalidu quì
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Perchè simu in iterazione annantu à `String`s, pudemu evità almenu una allocazione uttenendu a prima stringa da l'iteratore è appendendula à tutte e stringhe successive.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Perchè simu in iterazione nantu à CoWs, pudemu (potentially) evità almenu una attribuzione uttenendu u primu articulu è aghjustendu à tutti l'articuli successivi.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Un cunvenimentu impl chì delega à l'impl per `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Crea un `String` vacante.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Implementa l'operatore `+` per concatenà duie corde.
///
/// Questu cunsuma u `String` à manca è riutilizza u so buffer (crescendulu se necessariu).
/// Questu hè fattu per evità di attribuisce un novu `String` è di cupià u cuntenutu sanu sanu nantu à ogni operazione, ciò chì cunduceria à *O*(*n*^ 2) tempu di esecuzione quandu si custruisce una stringa *n*-byte per concatenazione ripetuta.
///
///
/// A stringa à manu dritta hè presa solu in prestu;u so cuntenutu hè cupiatu in u `String` restituitu.
///
/// # Examples
///
/// A cuncatenazione di duie `String`s piglia a prima per valore è impresta a seconda:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` hè spustatu è ùn pò più esse adupratu quì.
/// ```
///
/// Se vulete continuà à aduprà u primu `String`, pudete clonallu è appendelu à u clone invece:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` hè sempre validu quì.
/// ```
///
/// A concatenazione di e fette `&str` pò esse fatta cunvertendu a prima in un `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Implementa l'operatore `+=` per appendà à un `String`.
///
/// Questu hà u listessu comportamentu cum'è u metudu [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Un tipu alias per [`Infallible`].
///
/// Questu alias esiste per cumpatibilità retroattiva, è pò esse eventualmente obsoletu.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// Un trait per cunvertisce un valore in un `String`.
///
/// Questu trait hè automaticamente implementatu per qualsiasi tippu chì implementa u [`Display`] trait.
/// Per quessa, `ToString` ùn deve esse implementatu direttamente:
/// [`Display`] duverebbe esse implementatu invece, è uttenite l'implementazione `ToString` gratuitamente.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Converte u valore datu in un `String`.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// In questa implementazione, u metudu `to_string` panics se l'implementazione `Display` restituisce un errore.
/// Questu indica una implementazione `Display` incorrecta postu chì `fmt::Write for String` ùn restituisce mai un errore stessu.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Una guida cumuna hè di ùn mette in linea e funzioni generiche.
    // Tuttavia, rimuovere `#[inline]` da stu metudu provoca regressioni non trascurabili.
    // Vede <https://github.com/rust-lang/rust/pull/74852>, l'ultimu tentativu di pruvà à caccià lu.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Converte un `&mut str` in un `String`.
    ///
    /// U risultatu hè attribuitu nantu à a mansa.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test pulls in libstd, chì provoca errori quì
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Converte a fetta in scatula `str` data in un `String`.
    /// Hè nutevuli chì a fetta `str` hè di pruprietà.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Converte u `String` datu in una fetta in scatula `str` chì hè di pruprietà.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Converte una fetta di stringa in una variante Imprestata.
    /// Nisuna allocazione di cumuli hè eseguita, è a stringa ùn hè micca copiata.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Converte una String in una variante Owned.
    /// Nisuna allocazione di cumuli hè eseguita, è a stringa ùn hè micca copiata.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Converte una riferenza String in una variante Imprestata.
    /// Nisuna allocazione di cumuli hè eseguita, è a stringa ùn hè micca copiata.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Converte u `String` datu in un vector `Vec` chì cuntene valori di tipu `u8`.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Un iteratore drenante per `String`.
///
/// Sta struttura hè creata da u metudu [`drain`] in [`String`].
/// Vede a so ducumentazione per più.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Serà adupratu cum'è&'un mut String in u distruttore
    string: *mut String,
    /// Principiu di parte da caccià
    start: usize,
    /// Fine di a parte da caccià
    end: usize,
    /// Range rimanente attuale da caccià
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Aduprate Vec::drain.
            // "Reaffirm" i limiti verificanu per evità chì u codice panic sia inseritu di novu.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Restituisce a (sub) stringa restante di questu iteratore cum'è una fetta.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: Uncomment AsRef implica quì sottu quandu si stabilizza.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Scummentà quandu si stabilizza `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>per Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> per Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}