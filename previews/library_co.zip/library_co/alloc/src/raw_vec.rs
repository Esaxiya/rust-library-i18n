#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// U cuntenutu di a nova memoria ùn hè micca inizializatu.
    Uninitialized,
    /// A nova memoria hè garantita per esse messa à zero.
    Zeroed,
}

/// Una utilità di livellu bassu per attribuisce più ergonomicamente, riallocà, è disassignà un buffer di memoria nantu à a mansa senza avè da preoccupassi di tutti i casi d'angulu implicati.
///
/// Stu tipu hè eccellente per custruisce e vostre strutture di dati cum'è Vec è VecDeque.
/// In particulare:
///
/// * Produce `Unique::dangling()` nantu à tippi di dimensioni zero.
/// * Produce `Unique::dangling()` nantu à allocazioni di lunghezza zero.
/// * Evita di liberà `Unique::dangling()`.
/// * Cattura tutti i overflows in computazioni di capacità (li prumove à "capacity overflow" panics).
/// * Pruteghji contra i sistemi 32-bit attribuendu più di byte isize::MAX.
/// * E guardie da u traboccu di a vostra lunghezza.
/// * Chjama `handle_alloc_error` per allocazioni fallibili.
/// * Contene un `ptr::Unique` è dà dunque à l'utente tutti i benefici cunnessi.
/// * Utilizza l'eccessu restituitu da l'allocatore per aduprà a più grande capacità dispunibile.
///
/// Stu tippu ùn inspecciona in ogni casu a memoria chì gestisce.Quandu hè cascatu *libererà* a so memoria, ma *ùn* pruverà micca à calà u so cuntenutu.
/// Tocca à l'utilizatore di `RawVec` di gestisce e cose reali *salvate* in un `RawVec`.
///
/// Innota chì l'eccessu di un tippu di dimensioni zero hè sempre infinitu, cusì `capacity()` restituisce sempre `usize::MAX`.
/// Questu significa chì duvete esse attenti quandu si sparghje stu tipu cù un `Box<[T]>`, postu chì `capacity()` ùn darà micca a lunghezza.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Questu esiste perchè `#[unstable]` `const fn` ùn hà micca bisognu di cunformità à `min_const_fn` è cusì ùn ponu esse chjamati ancu in`min_const_fn`s.
    ///
    /// Se cambiate `RawVec<T>::new` o dipendenze, per piacè fate attenzione à ùn introduce nunda chì viulassi veramente `min_const_fn`.
    ///
    /// NOTE: Puderemu evità stu pirate è verificà a conformità cù qualchì attributu `#[rustc_force_min_const_fn]` chì richiede a conformità cù `min_const_fn` ma ùn permette micca necessariamente di chjamallu in `stable(...) const fn`/codice d'utilizatore chì ùn permette micca `foo` quandu `#[rustc_const_unstable(feature = "foo", issue = "01234")]` hè presente.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Crea u più grande `RawVec` pussibule (nantu à a mansa di u sistema) senza attribuisce.
    /// Se `T` hà una dimensione positiva, allora questu face un `RawVec` cù capacità `0`.
    /// Se `T` hè di dimensioni zero, allora face un `RawVec` cù capacità `usize::MAX`.
    /// Utile per l'implementazione di l'attribuzione ritardata.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Crea un `RawVec` (nantu à a mansa di sistema) cù esattamente i requisiti di capacità è di allineamentu per un `[T; capacity]`.
    /// Questu hè equivalente à chjamà `RawVec::new` quandu `capacity` hè `0` o `T` hè di dimensione zero.
    /// Innota chì se `T` hè di dimensione zero significa chì *ùn* uttene micca un `RawVec` cù a capacità richiesta.
    ///
    /// # Panics
    ///
    /// Panics se a capacità richiesta supera i `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Aborti nantu à OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Cum'è `with_capacity`, ma garantisce chì u buffer hè messu à zero.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Ristituisce un `RawVec` da un puntatore è capacità.
    ///
    /// # Safety
    ///
    /// U `ptr` deve esse attribuitu (nantu à a mansa di u sistema), è cù u `capacity` datu.
    /// U `capacity` ùn pò superà `isize::MAX` per tippi di dimensioni.(solu una preoccupazione per i sistemi 32-bit).
    /// ZST vectors pò avè una capacità finu à `usize::MAX`.
    /// Se u `ptr` è `capacity` venenu da un `RawVec`, allora questu hè garantitu.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs sò muti.Saltà à:
    // - 8 se a dimensione di l'elementu hè 1, perchè qualsiasi allocatori di cumuli hè probabile di arrotondà una richiesta di menu di 8 byte à almenu 8 byte.
    //
    // - 4 se l'elementi sò di dimensioni moderate (<=1 KiB).
    // - 1 altrimente, per evità di perde troppu spaziu per Vecs assai corti.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Cum'è `new`, ma parametrizzatu nantu à a scelta di l'allocatore per u `RawVec` restituitu.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` significa "unallocated".i tippi di dimensioni zero sò ignorati.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Cum'è `with_capacity`, ma parametrizzatu nantu à a scelta di l'allocatore per u `RawVec` restituitu.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Cum'è `with_capacity_zeroed`, ma parametrizzatu nantu à a scelta di l'allocatore per u `RawVec` restituitu.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Converte un `Box<[T]>` in un `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Converte tuttu u buffer in `Box<[MaybeUninit<T>]>` cù u `len` specificatu.
    ///
    /// Innota chì questu ricustituverà currettamente qualsiasi cambiamentu `cap` chì pò esse statu fattu.(Vede a descrizzione di u tippu per i dettagli.)
    ///
    /// # Safety
    ///
    /// * `len` deve esse più grande o uguale à a capacità più recente dumandata, è
    /// * `len` deve esse menu o uguale à `self.capacity()`.
    ///
    /// Nota, chì a capacità richiesta è `self.capacity()` puderebbenu differisce, cume un allocatore puderia globalmente situà è restituisce un bloccu di memoria più grande di quellu dumandatu.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanità-Verificate una metà di u requisitu di sicurezza (ùn pudemu micca verificà l'altra metà).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Evitemu `unwrap_or_else` quì perchè gonfia a quantità di LLVM IR generatu.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Ristituisce un `RawVec` da un puntatore, capacità è allocatore.
    ///
    /// # Safety
    ///
    /// U `ptr` deve esse attribuitu (via l'attribuatore datu `alloc`), è cù u `capacity` datu.
    /// U `capacity` ùn pò superà `isize::MAX` per tippi di dimensioni.
    /// (solu una preoccupazione per i sistemi 32-bit).
    /// ZST vectors pò avè una capacità finu à `usize::MAX`.
    /// Se `ptr` è `capacity` venenu da un `RawVec` creatu via `alloc`, allora questu hè garantitu.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Ottiene un puntatore grezzu finu à l'iniziu di l'attribuzione.
    /// Innota chì questu hè `Unique::dangling()` se `capacity == 0` o `T` hè di dimensione zero.
    /// In u primu casu, duvete esse attenti.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Ottiene a capacità di l'attribuzione.
    ///
    /// Questu serà sempre `usize::MAX` se `T` hè di dimensioni zero.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Restituisce un riferimentu cumunu à l'allocatore chì sustene stu `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Avemu un pezzu assignatu di memoria, cusì pudemu passà i cuntrolli di runtime per uttene u nostru layout attuale.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Assicura chì u buffer cuntene almenu spaziu abbastanza per tene elementi `len + additional`.
    /// S'ellu ùn hà micca dighjà abbastanza capacità, riassignerà abbastanza spaziu più un spaziu allentatu comodu per uttene u cumpurtamentu *O*(1) ammortizatu.
    ///
    /// Limiterà questu cumpurtamentu s'ellu si causerebbe innecessariamente à panic.
    ///
    /// Se `len` supera `self.capacity()`, questu pò mancà di attribuisce effettivamente u spaziu dumandatu.
    /// Questu ùn hè micca veramente periculosu, ma u codice periculosu *scrittu* chì si basa nantu à u cumpurtamentu di sta funzione pò rompe.
    ///
    /// Questu hè ideale per l'implementazione di una operazione di push-bulk cum'è `extend`.
    ///
    /// # Panics
    ///
    /// Panics se a nova capacità supera i `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborti nantu à OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // a riserva averia abbandunatu o panicu se u len superava `isize::MAX` dunque questu hè sicuru per fà senza cuntrollà avà.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// U listessu chè `reserve`, ma torna nantu à l'errori invece di piglià panicu o abbandunà.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Assicura chì u buffer cuntene almenu spaziu abbastanza per tene elementi `len + additional`.
    /// S'ellu ùn hè micca dighjà, riassegnerà a quantità minima pussibile di memoria necessaria.
    /// Generalmente questu serà esattamente a quantità di memoria necessaria, ma in principiu l'allocatore hè liberu di restituisce più di ciò chì avemu dumandatu.
    ///
    ///
    /// Se `len` supera `self.capacity()`, questu pò mancà di attribuisce effettivamente u spaziu dumandatu.
    /// Questu ùn hè micca veramente periculosu, ma u codice periculosu *scrittu* chì si basa nantu à u cumpurtamentu di sta funzione pò rompe.
    ///
    /// # Panics
    ///
    /// Panics se a nova capacità supera i `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborti nantu à OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// U listessu chè `reserve_exact`, ma torna nantu à l'errori invece di piglià panicu o abbandunà.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Riduce l'allocazione finu à a quantità specificata.
    /// Se a quantità data hè 0, in realtà si occupa cumpletamente.
    ///
    /// # Panics
    ///
    /// Panics se a quantità data hè *più grande* di a capacità attuale.
    ///
    /// # Aborts
    ///
    /// Aborti nantu à OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Ritorna se u buffer deve cresce per soddisfà a capacità extra necessaria.
    /// Principalmente adupratu per rende pussibule chjamate di riserva in linea senza `grow` in linea.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Stu metudu hè di solitu istantiatu parechje volte.Cusì vulemu chì sia u più chjucu pussibule, per migliurà i tempi di compilazione.
    // Ma vulemu ancu chì u più numeru di u so cuntenutu sia staticamente computabile pussibule, per fà u codice generatu corre più veloce.
    // Dunque, stu metudu hè scrittu attentamente per chì tuttu u codice chì dipende da `T` sia in ellu, mentre u più numeru di u codice chì ùn dipende micca da `T` quant'è pussibule hè in funzioni chì ùn sò micca generiche nantu à `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Questu hè assicuratu da i cuntesti chjamanti.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Postu chì tornemu una capacità di `usize::MAX` quandu `elem_size` hè
            // 0, ghjunghje quì significa necessariamente chì u `RawVec` hè eccessivu.
            return Err(CapacityOverflow);
        }

        // Nunda chì pudemu veramente fà per questi cuntrolli, purtroppu.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Questu garantisce una crescita esponenziale.
        // U radduppiannu ùn pò micca trabuccà perchè `cap <= isize::MAX` è u tippu di `cap` hè `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` hè micca genericu nantu à `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // I vinculi di stu metudu sò assai listessi à quelli di `grow_amortized`, ma stu metudu hè generalmente istanziatu menu spessu perciò hè menu criticu.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Dapoi u ritornu di una capacità di `usize::MAX` quandu a dimensione di u tippu hè
            // 0, ghjunghje quì significa necessariamente chì u `RawVec` hè eccessivu.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` hè micca genericu nantu à `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Sta funzione hè fora di `RawVec` per minimizà i tempi di compilazione.Vede u cummentariu sopra `RawVec::grow_amortized` per i dettagli.
// (U parametru `A` ùn hè micca significativu, perchè u numeru di tippi `A` diversi vistu in pratica hè assai più chjucu cà u numeru di tippi `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Verificate l'errore quì per minimizà a dimensione di `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // L'allocatore verifica a parità di allineamentu
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Libera a memoria di u `RawVec`*senza* pruvà di lascià cascà u so cuntenutu.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Funzione centrale per a gestione di l'errore di riserva.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Avemu bisognu di garantì i seguenti:
// * Ùn assignemu mai oggetti di dimensione byte `> isize::MAX`.
// * Ùn supranemu micca `usize::MAX` è in realtà assignemu troppu pocu.
//
// In 64-bit avemu solu bisognu di verificà u overflow, postu chì pruvà à attribuisce `> isize::MAX` bytes fallerà sicuramente.
// Nantu à 32-bit è 16-bit avemu bisognu di aghjunghje una guardia extra per questu in casu chì simu in corsa nantu à una piattaforma chì pò aduprà tutti i 4GB in u spaziu di l'utente, per esempiu, PAE o x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Una funzione centrale incaricata di segnalà i flussu di capacità.
// Questu assicurerà chì a generazione di codice in relazione cù questi panics hè minima postu chì ci hè solu un locu chì panics piuttostu chì un gruppu in tuttu u modulu.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}