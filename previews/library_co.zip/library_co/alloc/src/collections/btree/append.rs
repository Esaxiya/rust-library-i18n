use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Aggiunge tutte e coppie di valore-chiave da l'unione di dui iteratori ascendenti, incrementendu una variabile `length` lungo a strada.Quest'ultima facilita à u chjamante di evità una fuga quandu un gestore di gocce entra in panicu.
    ///
    /// Se i dui iteratori producenu a stessa chjave, stu metudu abbassa a coppia da l'iteratore di sinistra è aghjusta a coppia da l'iteratore di destra.
    ///
    /// Se vulete chì l'arburu finisce in un ordine strettamente ascendente, cum'è per un `BTreeMap`, entrambi l'iteratori devenu pruduce chiavi in ordine strettamente ascendente, ognuna più grande di tutte e chiavi di l'arburu, cumprese tutte e chiavi digià in l'arburu à l'entrata.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Preparamu a fusione `left` è `right` in una sequenza ordinata in tempu lineare.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Intantu, custruimu un arburu da a sequenza ordinata in tempu lineare.
        self.bulk_push(iter, length)
    }

    /// Spinge tutte e coppie di valore-chiave finu à a fine di l'arburu, incrementendu una variabile `length` lungo a strada.
    /// Quest'ultima facilita à u chjamante di evità una fuga quandu l'iteratore panica.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iterate per tutte e coppie di valore-chiave, spingenduli in nodi à u livellu ghjustu.
        for (key, value) in iter {
            // Pruvate di spinghje a coppia chjave-valore in u node di foglia attuale.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Ùn ferma più spaziu, cullate è spinghje.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Truvatu un nodu cù spaziu lasciatu, spinghje quì.
                                open_node = parent;
                                break;
                            } else {
                                // Andate di novu.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Simu in cima, creemu un novu node radice è spinghje ci.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Spinghje a coppia chjave-valore è u novu subarburu dirittu.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Falà torna à a più dritta foglia.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Incrementa a lunghezza di ogni iterazione, per assicurassi chì a carta abbassa l'elementi aghjunti ancu se avanza l'iteratore in panicu.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Un iteratore per a fusione di duie sequenze ordinate in una sola
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Se duie chjave sò uguali, restituisce u coppiu chjave-valore da a surghjente ghjusta.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}