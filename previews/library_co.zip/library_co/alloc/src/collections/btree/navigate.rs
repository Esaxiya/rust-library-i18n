use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Piglia temporaneamente un altru equivalente immutabile di a listessa gamma.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Truvate i spiculi di foglia distinti chì delimitanu un intervallu specificatu in un arburu.
    /// Ritorna o una coppia di manichi diversi in u listessu arburu o una coppia di opzioni vuote.
    ///
    /// # Safety
    ///
    /// A menu chì `BorrowType` hè `Immut`, ùn aduprate micca e maniche duplicate per visità u listessu KV duie volte.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Equivalente à `(root1.first_leaf_edge(), root2.last_leaf_edge())` ma più efficace.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Trova a coppia di bordi di foglia chì delimita una gamma specifica in un arburu.
    ///
    /// U risultatu hè significativu solu sì l'arburu hè urdinatu per chjave, cum'è l'arburu in un `BTreeMap` hè.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SICUREZZA: u nostru tippu di prestitu hè immutabile.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Trova a coppia di bordi di foglie chì delimitanu un arburu interu.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Sparte una riferenza unica in una coppia di bordi di foglie chì delimitanu un intervallu specificatu.
    /// U risultatu sò riferenze micca uniche chì permettenu a mutazione (some), chì deve esse aduprata cun cura.
    ///
    /// U risultatu hè significativu solu sì l'arburu hè urdinatu per chjave, cum'è l'arburu in un `BTreeMap` hè.
    ///
    ///
    /// # Safety
    /// Ùn aduprate micca e maniche duplicate per visità u listessu KV duie volte.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Sparte una riferenza unica in una coppia di bordi di foglie chì delimitanu tutta a gamma di l'arburu.
    /// I risultati sò referenze micca uniche chì permettenu a mutazione (solu di valori), dunque deve esse adupratu cun cura.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Duplichemu a ràdica NodeRef quì-ùn visiteremu mai u listessu KV duie volte, è ùn finisceremu mai cun riferenze di valore sovrapposte.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Sparte una riferenza unica in una coppia di bordi di foglie chì delimitanu tutta a gamma di l'arburu.
    /// I risultati sò riferenze micca uniche chì permettenu una mutazione massiccia distruttiva, dunque deve esse adupratu cù a massima cura.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Duplicemu a ràdica NodeRef quì-ùn averemu mai accessu à ella in un modu chì si sovrappone à e referenze ottenute da a radice.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Dà una manica edge foglia, restituisce [`Result::Ok`] cù una maniglia à u KV vicinu à u latu drittu, chì hè o in u stessu node foglia o in un node ancestrale.
    ///
    /// Se a foglia edge hè l'ultima in l'arburu, restituisce [`Result::Err`] cù u node radice.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Dà una foglia edge handle, restituisce [`Result::Ok`] cun una maniglia à u KV vicinu à u latu di u latu, chì hè o in u stessu node di foglia o in un node ancestrale.
    ///
    /// Se a foglia edge hè a prima in l'arburu, restituisce [`Result::Err`] cù u node radice.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Datu un manicu edge internu, restituisce [`Result::Ok`] cù un manicu à u KV vicinu à u latu drittu, chì hè o in u stessu node internu o in un node ancestrale.
    ///
    /// Se u edge internu hè l'ultimu in l'arburu, restituisce [`Result::Err`] cù u node radice.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Dà una foglia edge manighja in un arburu chì si more, torna a prossima foglia edge à u latu drittu, è u coppiu chjave-valore trà, chì hè o in u stessu node di foglia, in un node di antenatu, o inesistente.
    ///
    ///
    /// Stu metudu deallocate ancu qualsiasi node(s) chì ghjunghje à a fine di.
    /// Ciò implica chì s'ellu ùn esiste più coppia chjave-valore, tuttu u restu di l'arburu serà statu disassignatu è ùn ci hè più nunda da vultà.
    ///
    /// # Safety
    /// U edge datu ùn deve esse statu restituitu in precedenza da u contrapartu `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Dà una foglia edge manighjà in un arburu chì si more, ritorna a prossima foglia edge à u latu sinistro, è u coppiu chjave-valore in mezu, chì hè sia in u listessu nodu foglia, in un node ancestrale, o inesistente.
    ///
    ///
    /// Stu metudu deallocate ancu qualsiasi node(s) chì ghjunghje à a fine di.
    /// Ciò implica chì s'ellu ùn esiste più coppia chjave-valore, tuttu u restu di l'arburu serà statu disassignatu è ùn ci hè più nunda da vultà.
    ///
    /// # Safety
    /// U edge datu ùn deve esse statu restituitu in precedenza da u contrapartu `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Deallocates una pila di nodi da a foglia finu à a radice.
    /// Questu hè l'unicu modu per deallocate u restu di un arburu dopu chì `deallocating_next` è `deallocating_next_back` anu mordicatu da i dui lati di l'arburu, è anu colpitu u listessu edge.
    /// Cum'ellu hè destinatu solu à esse chjamatu quandu tutte e chjave è i valori sò stati restituiti, nisuna pulizia ùn hè fatta nant'à alcuna di e chjave o valori.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Move a foglia edge maniglia à a prossima foglia edge è restituisce riferimenti à a chjave è u valore in mezu.
    ///
    ///
    /// # Safety
    /// Deve esse un altru KV in a direzzione percorsa.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Move a foglia edge maniglia à a foglia precedente edge è restituisce riferimenti à a chjave è u valore trà.
    ///
    ///
    /// # Safety
    /// Deve esse un altru KV in a direzzione percorsa.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Move a foglia edge maniglia à a prossima foglia edge è restituisce riferimenti à a chjave è u valore in mezu.
    ///
    ///
    /// # Safety
    /// Deve esse un altru KV in a direzzione percorsa.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Fà questu ultimu hè più veloce, secondu benchmarks.
        kv.into_kv_valmut()
    }

    /// Move a foglia edge maniglia à a foglia precedente è restituisce riferimenti à a chjave è u valore trà.
    ///
    ///
    /// # Safety
    /// Deve esse un altru KV in a direzzione percorsa.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Fà questu ultimu hè più veloce, secondu benchmarks.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Move a foglia edge maniglia à a prossima foglia edge è restituisce a chjave è u valore trà, distribuendu ogni node lasciatu daretu lascendu u edge currispundente in u so node parente pendente.
    ///
    /// # Safety
    /// - Deve esse un altru KV in a direzzione percorsa.
    /// - Chì KV ùn era micca restituitu in precedenza da u contrapartu `next_back_unchecked` in alcuna copia di e maniglie chì sò aduprate per attraversà l'arburu.
    ///
    /// L'unicu modu sicuru per prucede cù a maniglia aggiornata hè di paragunallu, lasciallu, chjamà dinò stu metudu sottumessu à e so cundizioni di sicurità, o chjamà u so omologu `next_back_unchecked` sottumessu à e so cundizioni di sicurità.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Move a foglia edge maniglia à a foglia precedente edge è restituisce a chjave è u valore trà, distribuendu ogni node lasciatu daretu lascendu u edge currispundente in u so node parente pendente.
    ///
    /// # Safety
    /// - Deve esse un altru KV in a direzzione percorsa.
    /// - Questa foglia edge ùn hè micca stata previamente restituita da u contrapartu `next_unchecked` in alcuna copia di e maniglie chì sò aduprate per attraversà l'arburu.
    ///
    /// L'unicu modu sicuru per prucede cù a maniglia aggiornata hè di paragunallu, lasciallu, chjamà dinò stu metudu sottumessu à e so cundizioni di sicurità, o chjamà u so omologu `next_unchecked` sottumessu à e so cundizioni di sicurezza.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Ritorna a foglia più à manca edge in o sottu un node, in altre parolle, u edge chì avete bisognu prima per navigà in avanti (o l'ultimu quandu navigate indietro).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Ritorna a foglia più ghjustu à destra edge in o sottu un node, in altre parolle, u edge chì avete bisognu l'ultimu quandu navigate in avanti (o prima quandu navigate indietro).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Visite i nodi fugliali è i KV interni in ordine di chjavi ascendenti, è visita ancu i nodi interni in tuttu in un primu ordine di prufundità, vale à dì chì i nodi interni precedenu i so KV individuali è i so nodi figlioli.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Calcula u numeru di elementi in un (sub) arburu.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Ritorna a foglia edge più vicina à un KV per navigazione avanti.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Ritorna a foglia edge a più vicina à un KV per navigazione in ritornu.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}