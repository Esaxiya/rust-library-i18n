use core::marker::PhantomData;
use core::ptr::NonNull;

/// Mudeli un rimborsu di qualchì riferimentu unicu, quandu sapete chì u rimbursu è tutti i so discendenti (vale à dì, tutti i puntatori è e referenze derivate da ellu) ùn seranu più aduprati à un certu puntu, dopu à u quale vulete usà di novu a riferenza unica originale .
///
///
/// U verificatore di prestiti gestisce di solitu questu accatastamentu di prestiti per voi, ma alcuni flussi di cuntrollu chì realizanu questu accatastamentu sò troppu cumplicati per u compilatore da seguità.
/// Un `DormantMutRef` vi permette di verificà l'imprestate voi stessi, puru esprimendu a so natura accatastata, è incapsulendu u codice di puntatore grezzu necessariu per fà questu senza cumpurtamentu indefinitu.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Catturà un prestitu unicu, è subitu rimpruveratelu.
    /// Per u compilatore, a vita di a nova referenza hè a stessa di a vita di a referenza originale, ma voi promise per aduprà per un periodu più cortu.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SICUREZZA: tenemu u prestitu in tuttu 'a via `_marker`, è esponemu
        // solu sta riferenza, dunque hè unica.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Ritorna à u prestitu unicu inizialmente catturatu.
    ///
    /// # Safety
    ///
    /// U rimbursu deve esse finitu, vale à dì, a riferenza restituita da `new` è tutti i puntatori è e referenze derivate da ellu, ùn devenu più esse aduprate.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SICUREZZA: e nostre cundizioni di sicurità implicanu chì sta rifarenza sia torna unica.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;