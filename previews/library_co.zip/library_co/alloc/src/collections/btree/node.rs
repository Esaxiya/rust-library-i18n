// Questu hè un tentativu di una implementazione seguendu l'ideale
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Siccomu Rust ùn hà micca in realtà tippi dipendenti è ricursione polimorfica, ci femu cun assai sicurezza.
//

// Un scopu maiò di stu modulu hè di evità a cumplessità trattendu l'arburu cum'è un contenitore genericu (se di forma strana) è evitendu di trattà cù a maiò parte di l'invarianti B-Tree.
//
// Cusì, stu modulu ùn importa micca se l'entrate sò ordinate, chì nodi ponu esse sottu, o ancu ciò chì significa sottu.Tuttavia, ci basemu annantu à uni pochi d'invarianti:
//
// - L'arburi devenu avè uniforme depth/height.Questu significa chì ogni percorsu finu à una foglia da un determinatu node hà esattamente a stessa lunghezza.
// - Un nodu di lunghezza `n` hà e chjave `n`, i valori `n`, è i bordi `n + 1`.
//   Questu implica chì ancu un node vacante hà almenu un edge.
//   Per un node di foglia, "having an edge" significa solu chì pudemu identificà una pusizione in u node, postu chì i bordi di e foglie sò vioti è ùn necessitanu micca rappresentazione di dati.
// In un node internu, un edge identifica una pusizione è cuntene un puntatore à un node figliolu.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// A rapprisintazione sottostante di nodi foglia è parte di a rapprisintazione di nodi interni.
struct LeafNode<K, V> {
    /// Vulemu esse covarianti in `K` è `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// L'indice di questu nodu in a matrice `edges` di u node genitore.
    /// `*node.parent.edges[node.parent_idx]` duverebbe esse listessa cosa chì `node`.
    /// Questu hè garantitu solu per esse inizializatu quandu `parent` hè micca nulu.
    parent_idx: MaybeUninit<u16>,

    /// U numaru di chjave è valori di stu magazinu di node.
    len: u16,

    /// L'array chì memorizanu i dati veri di u node.
    /// Solu i primi elementi `len` di ogni array sò inizializzati è validi.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inizializza un novu `LeafNode` in situ.
    unsafe fn init(this: *mut Self) {
        // Cum'è una pulitica generale, lascemu campi micca inizializati se ponu esse, chì questu deve esse à tempu ligeramente più veloce è più faciule da seguità in Valgrind.
        //
        unsafe {
            // parent_idx, chjavi è vals sò tutti MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Crea un novu `LeafNode` in scatula.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// A rapprisintazione sottostante di nodi interni.Cum'è cù `LeafNode`, questi devenu esse piattati daretu à`BoxedNode` per impedisce di lascià cascà e chjave è i valori micca inizializati.
/// Ogni puntatore à un `InternalNode` pò esse direttamente castatu à un puntatore à a parte `LeafNode` sottostante di u node, permettendu à u codice di agisce nantu à a foglia è i nodi interni genericamente senza dighjà verificà à quale di i dui un puntatore punta.
///
/// Sta pruprietà hè attivata da l'usu di `repr(C)`.
///
#[repr(C)]
// gdb_providers.py usa stu nome di tipu per introspezione.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// L'indicatori per i zitelli di stu node.
    /// `len + 1` di questi sò cunsiderati inizializati è validi, eccettu chì vicinu à a fine, mentre chì l'arburu hè tenutu per imprestà tippu `Dying`, alcuni di sti indicatori sò pendenti.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Crea un novu `InternalNode` in scatula.
    ///
    /// # Safety
    /// Un invariante di nodi interni hè chì anu almenu un edge inizializatu è validu.
    /// Sta funzione ùn mette in opera un tale edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Avemu solu bisognu di inizializà i dati;i bordi sò ForsiUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Un puntatore gestitu, micca nullu à un nodu.Questu hè o un puntatore di pruprietà à `LeafNode<K, V>` o un puntatore di pruprietà à `InternalNode<K, V>`.
///
/// Tuttavia, `BoxedNode` ùn cuntene nisuna infurmazione nantu à quale di i dui tippi di nodi cuntene in realtà, è, in parte per via di sta mancanza di informazioni, ùn hè micca un tippu separatu è ùn hà micca distruttore.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// U node radice di un arburu pussedutu.
///
/// Innota chì questu ùn hà micca un distruttore, è deve esse pulitu manualmente.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Restituisce un novu arburu pussidutu, cù u so propiu node radice chì hè inizialmente viotu.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` ùn deve esse nulu.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Impresta mutualmente u node radice pussedutu.
    /// A differenza di `reborrow_mut`, questu hè sicuru perchè u valore di ritornu ùn pò micca esse adupratu per distrugge a radice, è ùn ci ponu esse altri riferimenti à l'arburu.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Imprestà un pocu mutabilmente u node radice pussedutu.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Transizione irreversibile à una riferenza chì permette a traversata è offre metudi distruttivi è pocu altru.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Aghjunghje un novu nodu internu cù un unicu edge chì punta à u node radice precedente, fate quellu novu nodu u node radice, è u restituisce.
    /// Questa aumenta l'altezza di 1 è hè u cuntrariu di `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, eccettu chì simu dimenticati chì simu interni avà:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Elimina u node radice internu, aduprendu u so primu figliolu cum'è u novu node radice.
    /// Cum'ellu hè destinatu solu à esse chjamatu quandu u node radice hà solu un zitellu, ùn hè fatta alcuna pulizia nant'à alcuna di e chjave, valori è altri zitelli.
    ///
    /// Quessu diminuite l'altitudine di 1 è hè u cuntrariu di `push_internal_level`.
    ///
    /// Richiede l'accessu esclusivu à l'ughjettu `Root` ma micca à u node radice;
    /// ùn invalidarà micca altri manichi o riferimenti à u node radice.
    ///
    /// Panics se ùn ci hè micca livellu internu, vale à dì, se u node radice hè una foglia.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SICUREZZA: avemu dichjaratu di esse interni.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SICUREZZA: avemu pigliatu in prestitu `self` solu è u so tippu di prestitu hè esclusivu.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SICUREZZA: u primu edge hè sempre inizializatu.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` hè sempre covariante in `K` è `V`, ancu quandu u `BorrowType` hè `Mut`.
// Questu hè tecnicamente sbagliatu, ma ùn pò risultà in alcuna sicurezza per l'usu internu di `NodeRef` perchè restemu cumpletamente genericu nantu à `K` è `V`.
//
// Tuttavia, ogni volta chì un tippu publicu avvolge `NodeRef`, assicuratevi chì abbia a varianza curretta.
//
/// Una riferenza à un nodu.
///
/// Stu tipu hà una serie di parametri chì controllanu cumu agisce:
/// - `BorrowType`: Un tippu fittiziu chì descrive u tippu di prestitu è porta una vita.
///    - Quandu hè `Immut<'a>`, u `NodeRef` agisce à pocu pressu cum'è `&'a Node`.
///    - Quandu hè `ValMut<'a>`, u `NodeRef` agisce à pocu pressu cum'è `&'a Node` in quantu à e chjave è a struttura di l'arburu, ma permette ancu parechje riferenze mutevuli à i valori in tuttu l'arburu per coesiste.
///    - Quandu hè `Mut<'a>`, u `NodeRef` agisce à pocu pressu cum'è `&'a mut Node`, ancu se i metudi d'inserimentu permettenu un puntatore mutevule à un valore per coesiste.
///    - Quandu hè `Owned`, u `NodeRef` agisce à pocu pressu cum'è `Box<Node>`, ma ùn hà micca un distruttore, è deve esse pulitu manualmente.
///    - Quandu hè `Dying`, u `NodeRef` agisce sempre à pocu pressu cum'è `Box<Node>`, ma hà metudi per distrugge l'arburu pocu à pocu, è i metudi urdinarii, ancu s'ellu ùn sò micca marcati cum'è periculosi per chjamà, ponu invucà UB se chjamati in modu incorrettu.
///
///   Siccomu qualsiasi `NodeRef` permette di navigà per l'arburu, `BorrowType` si applica in modu efficace à tuttu l'arburu, micca solu à u node stessu.
/// - `K` è `V`: Quessi sò i tippi di chjave è valori almacenati in i nodi.
/// - `Type`: Questu pò esse `Leaf`, `Internal`, o `LeafOrInternal`.
/// Quandu hè `Leaf`, u `NodeRef` punta à un node foglia, quandu questu hè `Internal` u `NodeRef` punta à un node internu, è quandu questu hè `LeafOrInternal` u `NodeRef` pò esse indicatu à ogni tipu di node.
///   `Type` hè chjamatu `NodeType` quandu s'utilice fora di `NodeRef`.
///
/// Sia `BorrowType` sia `NodeType` restringenu i metudi chì implementemu, per sfruttà a sicurezza di u tipu staticu.Ci sò limitazioni in u modu in cui pudemu applicà tali restrizioni:
/// - Per ogni parametru di tippu, pudemu definisce solu un metudu sia genericu sia per un tippu particulare.
/// Per esempiu, ùn pudemu micca definisce un metudu cum'è `into_kv` genericamente per tutti i `BorrowType`, o una volta per tutti i tippi chì portanu una vita, perchè vulemu chì restituisca referenze `&'a`.
///   Dunque, a definimu solu per u tippu `Immut<'a>` u menu putente.
/// - Ùn pudemu micca avè a coercizione implicita da dì `Mut<'a>` à `Immut<'a>`.
///   Dunque, duvemu chjamà esplicitamente `reborrow` nantu à un `NodeRef` più putente per ghjunghje à un metudu cum'è `into_kv`.
///
/// Tutti i metudi nantu à `NodeRef` chì restituiscenu un tipu di riferimentu, sia:
/// - Pigliate `self` per valore, è restituite a vita purtata da `BorrowType`.
///   A volte, per invucà un tale metudu, avemu bisognu di chjamà `reborrow_mut`.
/// - Pigliate `self` per riferimentu, è (implicitly) restituisce a vita di quella referenza, invece di a vita purtata da `BorrowType`.
/// In questu modu, u cuntrollore di prestitu garantisce chì u `NodeRef` rimane prestitu finchè a riferenza restituita hè aduprata.
///   I metudi chì sustenenu l'inserzione pieganu sta regula rientrendu un puntatore grezzu, vale à dì, una riferenza senza alcuna vita.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// U numaru di livelli chì u node è u livellu di foglie sò separati, una costante di u node chì ùn pò micca esse interamente descritta da `Type`, è chì u nodu stessu ùn conserva micca.
    /// Avemu solu bisognu di magazzinà l'altezza di u node radice, è derivà l'altezza di tutti l'altri nodi da ellu.
    /// Deve esse zeru se `Type` hè `Leaf` è diversu da zero se `Type` hè `Internal`.
    ///
    ///
    height: usize,
    /// U puntatore à a foglia o node internu.
    /// A definizione di `InternalNode` assicura chì u puntatore sia validu in ogni modu.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Scumpressate una riferenza di node chì hè stata imballata cum'è `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Espone i dati di un nodu internu.
    ///
    /// Restituisce un ptr crudu per evità d'invalidà altri riferimenti à stu nodu.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SICUREZZA: u tippu di node staticu hè `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Impresta l'accessu esclusivu à i dati di un nodu internu.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Trova a lunghezza di u node.Questu hè u numeru di chiavi o valori.
    /// U numaru di bordi hè `len() + 1`.
    /// Nutate bè chì, malgradu esse sicuru, chjamà sta funzione pò avè l'effettu secundariu d'invalidà e referenze mutevuli chì un codice periculosu hà creatu.
    ///
    pub fn len(&self) -> usize {
        // Crucialmente, accede solu à u campu `len` quì.
        // Se BorrowType hè marker::ValMut, ci ponu esse riferenzi mutevuli eccezziunali à valori chì ùn duvemu micca invalidà.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Restituisce u numeru di livelli chì u node è e foglie sò separati.
    /// Altezza zero significa chì u node hè una foglia stessa.
    /// Se figurate l'arburi cù a radice in cima, u numeru dice à quale elevazione apparisce u node.
    /// Se figurate arburi cù foglie in cima, u numeru dice quantu l'altezza si estende sopra u node.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Piglia temporaneamente un altru riferimentu immutabile à u listessu nodu.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Espone a parte foglia di qualsiasi foglia o node internu.
    ///
    /// Restituisce un ptr crudu per evità d'invalidà altri riferimenti à stu nodu.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // U node deve esse validu per almenu a parte LeafNode.
        // Questa ùn hè micca una riferenza in u tipu NodeRef perchè ùn sapemu micca s'ellu deve esse unicu o cumunu.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Trova u genitore di u node attuale.
    /// Restituisce `Ok(handle)` se u node attuale hà in realtà un genitore, induve `handle` punta à u edge di u genitore chì punta à u node attuale.
    ///
    /// Restituisce `Err(self)` se u node attuale ùn hà micca genitori, restituendu u `NodeRef` originale.
    ///
    /// U nome di u metudu suppone chì vi figurate l'arburi cù u node radice sopra.
    ///
    /// `edge.descend().ascend().unwrap()` è `node.ascend().unwrap().descend()` duverianu tramindui, dopu successu, ùn fà nunda.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Avemu bisognu di aduprà puntatori crudi per i nodi perchè, se BorrowType hè marker::ValMut, ci puderebbenu esse riferenzi mutevuli eccezziunali à valori chì ùn duvemu micca invalidà.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Nota chì `self` deve esse non vuoto.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Nota chì `self` deve esse non vuoto.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Espone a parte di a foglia di qualsiasi foglia o node internu in un arburu immutabile.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SICUREZZA: ùn ci ponu esse riferenze mutevuli in questu arburu pigliatu in prestitu cum'è `Immut`.
        unsafe { &*ptr }
    }

    /// Impresta una vista in e chjave guardate in u node.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Simile à `ascend`, riceve una riferenza à u node parente di un node, ma distribuisce ancu u nodu attuale in u prucessu.
    /// Questu hè periculosu perchè u node attuale serà sempre accessibile malgradu esse dislocatu.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Afferma senza sicurezza à u compilatore l'infurmazioni statiche chì stu node hè un `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Afferma senza sicurezza à u compilatore l'infurmazioni statiche chì stu node hè un `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Piglia temporaneamente un altru riferimentu mutevule à u listessu nodu.Attenti, chì stu metudu hè assai periculosu, doppiamente postu chì ùn pò micca apparì subitu periculosu.
    ///
    /// Perchè i puntatori mutevuli ponu vaghjà in ogni locu intornu à l'arburu, u puntatore restituitu pò esse facilmente utilizatu per fà u puntatore uriginale pendente, fora di i limiti, o invalidu secondu e regule di imprestà accatastate.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) cunsidereghja d'aghjunghje ancu un altru parametru di tippu à `NodeRef` chì limita l'usu di i metudi di navigazione nantu à i puntatori rimbursati, evitendu questu periculu.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Impresta l'accessu esclusivu à a parte foglia di qualsiasi foglia o node internu.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SICUREZZA: avemu un accessu esclusivu à tuttu u node.
        unsafe { &mut *ptr }
    }

    /// Offre accessu esclusivu à a parte foglia di qualsiasi foglia o node internu.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SICUREZZA: avemu un accessu esclusivu à tuttu u node.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Impresta l'accessu esclusivu à un elementu di l'area di almacenamentu chjave.
    ///
    /// # Safety
    /// `index` hè in limiti di 0..CAPACITÀ
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SICUREZZA: u chjamante ùn serà micca in gradu di chjamà altri metudi nantu à sè
        // finu à chì a riferenza chjave di slice sia abbandunata, chì avemu un accessu unicu per a vita di u prestitu.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Impresta l'accessu esclusivu à un elementu o una fetta di l'area di almacenamentu di valore di u node.
    ///
    /// # Safety
    /// `index` hè in limiti di 0..CAPACITÀ
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SICUREZZA: u chjamante ùn serà micca in gradu di chjamà altri metudi nantu à sè
        // finu à chì a riferenza di a fetta di valore sia abbandunata, cume avemu un accessu unicu per a vita di u prestitu.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Impresta l'accessu esclusivu à un elementu o una fetta di l'area di almacenamentu di u node per i cuntenuti edge.
    ///
    /// # Safety
    /// `index` hè in limiti di 0..CAPACITÀ + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SICUREZZA: u chjamante ùn serà micca in gradu di chjamà altri metudi nantu à sè
        // finu à chì a riferenza di a fetta edge sia abbandunata, chì avemu un accessu unicu per a vita di u prestitu.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - U node hà più di elementi inizializati `idx`.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Creemu solu una riferenza à l'elementu chì ci interessa, per evità l'aliasing cù riferimenti pendenti à altri elementi, in particulare, quelli riturnati à u chjamante in iterazioni precedenti.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Duvemu furzà à indicatori di matrici micca dimensionati per via di Rust issue #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Impresta l'accessu esclusivu à a lunghezza di u node.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Imposta u ligame di u nodu à u so parente edge, senza invalidà altre riferenze à u node.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Cancella u ligame di a radice cù u so parente edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Aghjunghje una coppia chjave-valore à a fine di u node.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Ogni articulu restituitu da `range` hè un indice edge validu per u node.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Aghjunghje una coppia valore-chiave, è un edge per andà à a destra di quella coppia, à a fine di u node.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Verifica se un node hè un node `Internal` o un node `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Una riferenza à una coppia specifica di valore-chiave o edge in un node.
/// U parametru `Node` deve esse un `NodeRef`, mentre chì `Type` pò esse `KV` (significendu un manicu nantu à una coppia valore-chiave) o `Edge` (significendu un manicu in un edge).
///
/// Innota chì ancu i nodi `Leaf` ponu avè manichi `Edge`.
/// Invece di rapprisintà un puntatore à un node zitellu, questi rapprisentanu i spazi induve i puntatori figlioli anderianu trà e coppie valore-chiave.
/// Per esempiu, in un nodu cù a lunghezza 2, ci serianu 3 lochi edge pussibili, unu à manca di u node, unu trà e duie coppie, è unu à a destra di u node.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Ùn avemu micca bisognu di a piena generalità di `#[derive(Clone)]`, chì a sola volta chì `Node` serà `Clone`able hè quandu hè una riferenza immutabile è dunque `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Recupera u node chì cuntene u edge o coppia chjave-valore chì sta maniglia punta.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Restituisce a pusizione di questu manicu in u node.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Crea un novu manicu per una coppia chjave-valore in `node`.
    /// Unsafe perchè u chjamante deve assicurà chì `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Puderia esse una implementazione publica di PartialEq, ma aduprata solu in stu modulu.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Piglia temporaneamente un'altra maniglia immutabile in u listessu locu.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Ùn pudemu micca aduprà Handle::new_kv o Handle::new_edge perchè ùn cunniscimu micca u nostru tippu
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Afferma senza sicurezza à u compilatore l'infurmazioni statiche chì u node di a maniglia hè un `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Piglia temporaneamente un'altra maniglia mutabile in u listessu locu.
    /// Attenti, chì questu metudu hè assai periculosu, doppiamente postu chì pò ùn sembra micca subitu periculosu.
    ///
    ///
    /// Per i dettagli, vedi `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Ùn pudemu micca aduprà Handle::new_kv o Handle::new_edge perchè ùn cunniscimu micca u nostru tippu
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Crea un novu manicu per un edge in `node`.
    /// Unsafe perchè u chjamante deve assicurà chì `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Datu un indice edge induve vulemu inserisce in un nodu pienu à capacità, calcula un indice KV sensibile di un puntu divisu è induve eseguisce l'inserzione.
///
/// L'obiettivu di u puntu split hè chì a so chjave è u valore finiscinu in un node parent;
/// i chjavi, i valori è i bordi à manca di u puntu divisu diventanu u zitellu di manca;
/// i chjavi, i valori è i bordi à a diritta di u puntu divisu diventanu u zitellu ghjustu.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // U numeru Rust #74834 prova à spiegà queste regule simmetriche.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inserisce una nova coppia chjave-valore trà e coppie chjave-valore à diritta è à manca di stu edge.
    /// Stu metudu assume chì ci hè abbastanza spaziu in u node per chì a nova coppia si adatta.
    ///
    /// U puntatore restituitu punta à u valore inseritu.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inserisce una nova coppia chjave-valore trà e coppie chjave-valore à diritta è à manca di stu edge.
    /// Stu metudu divide u node s'ellu ùn ci hè micca abbastanza stanza.
    ///
    /// U puntatore restituitu punta à u valore inseritu.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Risolve u puntatore parentale è l'indice in u node figliolu chì stu edge lega.
    /// Questu hè utile quandu l'ordine di i bordi hè statu cambiatu,
    fn correct_parent_link(self) {
        // Crea un backpointer senza invalidà altri riferimenti à u node.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Inserisce una nova coppia chjave-valore è un edge chì anderà à a diritta di quella nova coppia tra stu edge è a coppia chjave-valore à a destra di stu edge.
    /// Stu metudu assume chì ci hè abbastanza spaziu in u node per chì a nova coppia si adatta.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Inserisce una nova coppia chjave-valore è un edge chì anderà à a diritta di quella nova coppia tra stu edge è a coppia chjave-valore à a destra di stu edge.
    /// Stu metudu divide u node s'ellu ùn ci hè micca abbastanza stanza.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inserisce una nova coppia chjave-valore trà e coppie chjave-valore à diritta è à manca di stu edge.
    /// Stu metudu sparte u node s'ellu ùn ci hè abbastanza spaziu, è prova à inserisce a parte spartuta in u node parente recursivamente, finu à chì a radice hè ghjunta.
    ///
    ///
    /// Se u risultatu restituitu hè un `Fit`, u nodu di u so manicu pò esse stu node di edge o un antenatu.
    /// Se u risultatu restituitu hè un `Split`, u campu `left` serà u node radice.
    /// U puntatore restituitu punta à u valore inseritu.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Truvate u node indicatu da questu edge.
    ///
    /// U nome di u metudu suppone chì vi figurate l'arburi cù u node radice sopra.
    ///
    /// `edge.descend().ascend().unwrap()` è `node.ascend().unwrap().descend()` duverianu tramindui, dopu successu, ùn fà nunda.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Avemu bisognu di aduprà puntatori crudi per i nodi perchè, se BorrowType hè marker::ValMut, ci puderebbenu esse riferenzi mutevuli eccezziunali à valori chì ùn duvemu micca invalidà.
        // Ùn ci hè nisuna preoccupazione chì accede à u campu di l'altezza perchè quellu valore hè cupiatu.
        // Attenti chì, una volta chì u puntatore di u node hè dereferenziatu, accedemu à a matrice di i bordi cù una riferenza (Rust issue #73987) è invalidemu qualsiasi altra riferenza à o in l'internu di a matrice, duve esse intornu.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Ùn pudemu micca chjamà metudi chjave è valori separati, perchè chjamà u secondu invalida a riferenza restituita da u primu.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Rimpiazzà a chjave è u valore chì si riferisce à u manicu KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Aiuta l'implementazioni di `split` per un `NodeType` particulare, pigliendu cura di i dati fugliali.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Sparte u node sottostante in trè parti:
    ///
    /// - U node hè truncatu per cuntene solu e coppie valore-chiave à a manca di sta maniglia.
    /// - A chjave è u valore indicatu da questu manicu sò estratti.
    /// - Tutte e coppie chjave-valore à a diritta di questu manicu sò messe in un node appena attribuitu.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Elimina u coppiu chjave-valore indicatu da questu manicu è u restituisce, cù u edge chì a coppia chjave-valore hè cascata in.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Sparte u node sottostante in trè parti:
    ///
    /// - U node hè truncatu per cuntene solu i bordi è e coppie valore-chiave à a manca di questu manicu.
    /// - A chjave è u valore indicatu da questu manicu sò estratti.
    /// - Tutti i bordi è e coppie valore-chjave à a diritta di questu manicu sò messe in un node appena attribuitu.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Rappresenta una sessione per valutà è eseguisce un'operazione di bilanciu intornu à una coppia interna valore-chiave.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Sceglite un cuntestu di equilibriu chì implica u node cum'è un zitellu, cusì trà u KV immediatamente à manca o à diritta in u node parent.
    /// Restituisce un `Err` se ùn ci hè micca parente.
    /// Panics se u genitore hè viotu.
    ///
    /// Prefiere u latu sinistro, per esse ottimale se u nodu datu hè in qualchì modu pocu pienu, vale à dì solu quì chì hà menu elementi di u so fratellu sinistro è di u so fratellu sinistro, se esistenu.
    /// In questu casu, a fusione cù u fratellu di sinistra hè più rapida, postu chì avemu solu bisognu di spostà l'N elementi di u node, invece di spostalli à a destra è di spostà più di N elementi davanti.
    /// Arrubà da u fratellu di sinistra hè ancu tipicamente più veloce, postu chì avemu solu bisognu di spustà l'elementi N di u node à diritta, invece di spostà almenu N di l'elementi di u fratellu à manca.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Restituisce se a fusione hè pussibile, vale à dì, sì ci hè abbastanza spaziu in un nodu per cunghjuntà u KV centrale cù i dui nodi figlioli adiacenti.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Esegue una fusione è lascia una chjusura decide di cosa restituisce.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SICUREZZA: l'altezza di i nodi chì sò uniti hè una sottu à l'altitudine
                // di u node di questu edge, cusì sopra à zero, allora sò interni.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Unisce a coppia chjave-valore di u genitore è i dui nodi figlioli adiacenti in u node figliu di sinistra è restituisce u node parent riduttu.
    ///
    ///
    /// Panics a menu chì no `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Unisce a coppia chjave-valore di u genitore è i dui nodi figlioli adiacenti in u node zitellu sinistro è restituisce quellu nodu zitellu.
    ///
    ///
    /// Panics a menu chì no `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Unisce a coppia chjave-valore di u genitore è i dui nodi figlioli adiacenti in u node figliu di sinistra è restituisce a maniglia edge in quellu node figliu induve u zitellu tracciatu edge finì,
    ///
    ///
    /// Panics a menu chì no `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Elimina una coppia chjave-valore da u zitellu di sinistra è u mette in u magazzinu chjave-valore di u genitore, mentre spinge u vechju paru chiave-valore di u genitore in u zitellu ghjustu.
    ///
    /// Ritorna un manicu à u edge in u zitellu ghjustu chì currisponde à induve u edge originale specificatu da `track_right_edge_idx` hè finitu.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Elimina una coppia chjave-valore da u zitellu ghjustu è u mette in a memoria di chjave-valore di u genitore, mentre spinghje u vechju paru chjave-valore parente nantu à u zitellu di manca.
    ///
    /// Ritorna un manicu à u edge in u zitellu di manca specificatu da `track_left_edge_idx`, chì ùn si move micca.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Questu face a rubazione simile à `steal_left` ma ruba più elementi à tempu.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Assicuratevi chì pudemu arrubà in modu sicuru.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Move i dati di e foglie.
            {
                // Fate a piazza per l'elementi arrubati in u zitellu ghjustu.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Move elementi da u zitellu di manca à u dirittu.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Move u paru u più arrubatu à manca à u genitore.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Move a coppia chjave-valore di u genitore à u zitellu ghjustu.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Fate a piazza à i bordi arrubati.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Arrubate i bordi.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// U clone simmetricu di `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Assicuratevi chì pudemu arrubà in modu sicuru.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Move i dati di e foglie.
            {
                // Spustate u coppiu u più arrubatu à diritta à u genitore.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Move a coppia chjave-valore di u genitore à u zitellu di manca.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Move elementi da u zitellu ghjustu à u manca.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Riempite a lacuna induve sò stati elementi rubati.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Arrubate i bordi.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Riempite u spaziu induve eranu i bordi arrubati.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Elimina qualsiasi infurmazione statica affirmannu chì questu node hè un node `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Elimina ogni infurmazione statica affirmannu chì questu node hè un node `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Verifica se u node sottostante hè un node `Internal` o un node `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Move u suffissu dopu `self` da un node à l'altru.`right` deve esse viotu.
    /// U primu edge di `right` ferma senza cambià.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Risultatu di l'inserzione, quandu un node avia bisognu di espansione oltre a so capacità.
pub struct SplitResult<'a, K, V, NodeType> {
    // Nodu alteratu in l'arburu esistente cù elementi è bordi chì appartenenu à a sinistra di `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Alcune chjave è valore si separanu, da inserisce in altrò.
    pub kv: (K, V),
    // Proprietariu, unattached, novu node cù elementi è bordi chì appartenenu à a destra di `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Sì i riferimenti di nodi di stu tippu di prestitu permettenu di attraversà à altri nodi in l'arburu.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversale ùn hè micca necessariu, accade aduprendu u risultatu di `borrow_mut`.
        // Disattivendu a traversata, è creendu solu novi riferimenti à e radiche, sapemu chì ogni riferenza di u tippu `Owned` hè à un node radice.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Inserisce un valore in una fetta di elementi inizializati seguitatu da un elementu micca inizializatu.
///
/// # Safety
/// A fetta hà più di elementi `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Elimina è rende un valore da una fetta di tutti l'elementi inizializati, lascendu daretu un elementu ininiziale finitu.
///
///
/// # Safety
/// A fetta hà più di elementi `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Sposta l'elementi in una fetta pusizioni `distance` à manca.
///
/// # Safety
/// A fetta hà almenu elementi `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Sposta l'elementi in una fetta pusizioni `distance` à diritta.
///
/// # Safety
/// A fetta hà almenu elementi `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Sposta tutti i valori da una fetta d'elementi inizializati à una fetta d'elementi micca inizializati, lascendu daretu `src` cum'è tuttu micca inizializatu.
///
/// Funziona cum'è `dst.copy_from_slice(src)` ma ùn richiede micca `T` per esse `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;