use core::intrinsics;
use core::mem;
use core::ptr;

/// Questu rimpiazza u valore daretu à a riferenza unica `v` chjamendu a funzione pertinente.
///
///
/// Se un panic si trova in a chjusura `change`, tuttu u prucessu serà abbandunatu.
#[allow(dead_code)] // mantene cum'è illustrazione è per l'usu future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Questu rimpiazzà u valore daretu à a riferenza unica `v` chjamendu a funzione pertinente, è restituisce un risultatu ottenutu longu u caminu.
///
///
/// Se un panic si trova in a chjusura `change`, tuttu u prucessu serà abbandunatu.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}