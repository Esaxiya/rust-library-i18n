#![stable(feature = "rust1", since = "1.0.0")]

//! Puntatori di cuntezione di referenze sicuri di filu.
//!
//! Vede a documentazione [`Arc<T>`][Arc] per più dettagli.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Un limitu minimu per a quantità di referenze chì ponu esse fatte à un `Arc`.
///
/// Passà sopra à stu limitu annullerà u vostru prugramma (ancu se micca necessariamente) à e referenze _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ùn sustene micca e recinzioni di memoria.
// Per evità falsi rapporti pusitivi in l'implementazione Arc/Debule utilizate invece carichi atomichi per a sincronizazione.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Un puntatore di cuntezione di riferenza sicura di filu.'Arc' significa "Riferimentu atomicu cuntatu".
///
/// U tippu `Arc<T>` furnisce pruprietà cumuna di un valore di tippu `T`, attribuitu in a mansa.Invucà [`clone`][clone] nantu à `Arc` produce una nova istanza `Arc`, chì punta à a stessa attribuzione nantu à a mansa cum'è a fonte `Arc`, puru aumentendu un conte di riferenza.
/// Quandu l'ultimu puntatore `Arc` à una attribuzione data hè distruttu, u valore almacenatu in quella attribuzione (spessu chjamatu "inner value") hè ancu calatu.
///
/// E referenze cumune in Rust ùn permettenu micca a mutazione per difettu, è `Arc` ùn face micca eccezione: ùn pudete micca generalmente uttene una riferenza mutevule à qualcosa in un `Arc`.Sì avete bisognu di mutà attraversu un `Arc`, aduprate [`Mutex`][mutex], [`RwLock`][rwlock], o unu di i tippi [`Atomic`][atomic].
///
/// ## Filetta Sicurezza
///
/// A differenza di [`Rc<T>`], `Arc<T>` utilizza operazioni atomiche per u so numeru di riferenza.Questu significa chì hè filu sicuru.U svantaghju hè chì l'operazioni atomiche sò più costose di l'accessi di memoria ordinaria.Se ùn state micca spartendu allocazioni cuntate di riferimentu trà fili, pensate à aduprà [`Rc<T>`] per un sovrapposizione inferiore.
/// [`Rc<T>`] hè un predefinitu sicuru, perchè u compilatore catturà ogni tentativu di invià un [`Rc<T>`] trà fili.
/// Tuttavia, una biblioteca pò sceglie `Arc<T>` per dà à i consumatori di biblioteca più flessibilità.
///
/// `Arc<T>` implementerà [`Send`] è [`Sync`] sempre chì u `T` implementi [`Send`] è [`Sync`].
/// Perchè ùn pudete micca mette un tippu `T` senza filu in un `Arc<T>` per rende u filu sicuru?Questu pò esse un pocu contru-intuitivu à u primu: dopu tuttu, ùn hè micca u puntu di a sicurezza di u filu `Arc<T>`?A chjave hè questa: `Arc<T>` rende u filu sicuru per avè più pruprietà di i stessi dati, ma ùn aghjunghje micca a sicurezza di u filu à i so dati.
///
/// Cunsiderate `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] ùn hè micca [`Sync`], è se `Arc<T>` era sempre [`Send`], `Arc <` [`RefCell<T>"]">`seria ancu.
/// Ma allora averiamu un prublema:
/// [`RefCell<T>`] ùn hè micca filu sicuru;tene traccia di u numeru di prestiti aduprendu operazioni non atomiche.
///
/// À a fine, questu significa chì pudete bisognu di accoppiare `Arc<T>` cù una sorta di tippu [`std::sync`], di solitu [`Mutex<T>`][mutex].
///
/// ## Cicli di rumpitura cù `Weak`
///
/// U metudu [`downgrade`][downgrade] pò esse adupratu per creà un puntatore [`Weak`] chì ùn hè micca pruprietariu.Un puntatore [`Weak`] pò esse [`aghjurnamentu`][aghjurnamentu] d à un `Arc`, ma questu restituverà [`None`] se u valore almacenatu in l'allocazione hè digià statu abbandunatu.
/// In altre parole, i puntatori `Weak` ùn mantenenu micca u valore in l'internu di l'attribuzione;però,*facenu* mantenenu viva l'allocazione (u magazinu di sustegnu per u valore).
///
/// Un ciclu trà i puntatori `Arc` ùn serà mai dislocatu.
/// Per questa ragione, [`Weak`] hè adupratu per rompe i cicli.Per esempiu, un arburu puderia avè forti puntelli `Arc` da i nodi genitori à i zitelli, è puntelli [`Weak`] da i zitelli à i so genitori.
///
/// # Riferimenti di clonazione
///
/// A creazione di un novu riferimentu da un puntatore di riferimentu esistente hè fattu cù `Clone` trait implementatu per [`Arc<T>`][Arc] è [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // E duie sintassi sottu sò equivalenti.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, è foo sò tutti Archi chì indicanu a listessa situazione di memoria
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` dereferenze automaticamente à `T` (via [`Deref`][deref] trait), cusì pudete chjamà i metudi di "T" per un valore di tipu `Arc<T>`.Per evità i scontri di nomi cù i metudi di `T`, i metudi di `Arc<T>` stessu sò funzioni associate, chjamate aduprendu [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>L'implementazioni di traits cum'è `Clone` ponu ancu esse chjamate cù sintassi cumpletamente qualificata.
/// Alcune persone preferenu aduprà una sintassi cumpletamente qualificata, mentre chì altri preferenu aduprà una sintassi di metudu-chjamata.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sintassi di metudu-chjama
/// let arc2 = arc.clone();
/// // Sintassi cumpletamente qualificata
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ùn dereca micca automaticamente à `T`, perchè u valore internu pò esse digià statu abbandunatu.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Spartendu qualchì dati immutabili trà fili:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Innota chì **ùn** micca ** eseguite queste prove quì.
// I costruttori windows diventanu super disgraziati se un filu supera u filu principale è poi esce in u stessu tempu (qualcosa di blocchi) allora evitemu solu questu interamente ùn eseguendu micca questi test.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Spartendu un [`AtomicUsize`] mutabile:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Vede u [`rc` documentation][rc_examples] per più esempi di cunte di riferenza in generale.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` hè una versione di [`Arc`] chì cuntene un riferimentu micca propiu à l'attribuzione gestita.
/// L'accessione hè accessibile chjamendu [`upgrade`] nantu à u puntatore `Weak`, chì restituisce una [`Opzione`]`<`[`Arc`] `<T>>`.
///
/// Siccomu un riferimentu `Weak` ùn conta micca per a pruprietà, ùn impedisce micca chì u valore almacenatu in l'allocazione sia abbandunatu, è `Weak` stessu ùn face alcuna garanzia nantu à u valore chì hè sempre presente.
///
/// Cusì pò restituisce [`None`] quandu [`aghjurnà`] d.
/// Nutate quantunque chì una riferenza `Weak`*impedisce* l'assignazione stessa (u magazinu di sustegnu) da esse deallocatu.
///
/// Un puntatore `Weak` hè utile per tene un riferimentu tempurale à l'attribuzione gestita da [`Arc`] senza impedisce u so valore internu di esse calatu.
/// Hè ancu adupratu per impedisce e referenze circolari trà i puntatori [`Arc`], postu chì e referenze reciproche di pruprietà ùn permetterianu mai di tramandà nè [`Arc`].
/// Per esempiu, un arburu puderia avè forti puntatori [`Arc`] da i nodi genitori à i zitelli, è puntelli `Weak` da i zitelli à i so genitori.
///
/// U modu tipicu per uttene un puntatore `Weak` hè di chjamà [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Questu hè un `NonNull` per permette ottimisazione di a dimensione di stu tipu in enumerazioni, ma ùn hè micca necessariamente un puntatore validu.
    //
    // `Weak::new` impone questu à `usize::MAX` in modo chì ùn abbia bisognu di assignà spaziu nantu à a mansa.
    // Ùn hè micca un valore chì un veru puntatore averà mai perchè RcBox hà un allineamentu almenu 2.
    // Questu hè pussibule solu quandu `T: Sized`;`T` senza dimensioni ùn pende mai.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Questu hè repr(C) à future-prova contr'à una pussibile riorganizazione di campu, chì interferiscenu cù [into|from]_raw() altrimente sicuru di tippi interni trasmissibili.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // u valore usize::MAX agisce da sentinella per "locking" temporaneamente a capacità d'aghjurnà puntatori debuli o di calà quelli forti;questu hè adupratu per evità e corse in `make_mut` è `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Custruisce un novu `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Accuminciate u puntatore debule cunte 1 chì hè u puntatore debule tenutu da tutti i puntatori forti (kinda), vedi std/rc.rs per più infurmazione
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Custruisce un novu `Arc<T>` aduprendu un debule riferimentu à sè stessu.
    /// Tentà d'aghjurnà u riferimentu debule prima chì sta funzione ritorna resultarà in un valore `None`.
    /// Tuttavia, a riferenza debule pò esse clonata liberamente è conservata per l'usu in un tempu dopu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Custruisce l'internu in u statu "uninitialized" cun una sola rifarenza debule.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Hè impurtante chì ùn abbandunemu micca a pruprietà di u puntatore debule, altrimenti a memoria pò esse liberata da u ritornu di `data_fn`.
        // Se vulissimu veramente passà a pruprietà, pudemu creà un puntatore debule addizionale per noi stessi, ma questu resulterebbe in aghjurnamenti addiziunali à u conte di riferimentu debule chì forse ùn sarebbe micca necessariu altrimenti.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Ora pudemu inizializà currettamente u valore interiore è trasformà a nostra debule referenza in una forte riferenza.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // A scrittura di sopra à u campu di dati deve esse visibile à qualsiasi filu chì osserva un numeru forte diversu da zero.
            // Dunque ci vole almenu un ordine "Release" per sincronizà cù u `compare_exchange_weak` in `Weak::upgrade`.
            //
            // "Acquire" l'ordine ùn hè micca necessariu.
            // Quandu si cunsidereghja i cumpurtamenti pussibuli di `data_fn`, basta à guardà ciò chì puderia fà cun una riferenza à un `Weak` non aggiornabile:
            //
            // - Pò *clunà* l `Weak`, aumentendu u conte di riferimentu debule.
            // - Pò abbandunà quelli cloni, diminuendu u numeru di riferimentu debule (ma mai à zeru).
            //
            // Quessi effetti collaterali ùn ci anu micca impattu in alcun modu, è nisun altru effetti collaterale hè pussibile solu cù u codice sicuru.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // E referenze forti devenu pussede cullettivamente un riferimentu debule cumunu, allora ùn eseguite micca u distruttore per a nostra vechja riferenza debule.
        //
        mem::forget(weak);
        strong
    }

    /// Custruisce un novu `Arc` cù cuntenuti micca inizializati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inizializazione differita:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Custruisce un novu `Arc` cù cuntenuti non inizializati, cù a memoria chì hè piena di byte `0`.
    ///
    ///
    /// Vede [`MaybeUninit::zeroed`][zeroed] per esempi di usu currettu è incorrettu di stu metudu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Custruisce un novu `Pin<Arc<T>>`.
    /// Se `T` ùn implementa micca `Unpin`, allora `data` serà appiccicatu in memoria è incapace di esse spustatu.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Custruisce un novu `Arc<T>`, restituendu un errore se l'assignazione falla.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Accuminciate u puntatore debule cunte 1 chì hè u puntatore debule tenutu da tutti i puntatori forti (kinda), vedi std/rc.rs per più infurmazione
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Custruisce un novu `Arc` cù cuntenuti non inizializzati, restituendu un errore se l'assignazione falla.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inizializazione differita:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Custruisce un novu `Arc` cù cuntenuti micca inizializati, cù a memoria chì hè piena di byte `0`, restituendu un errore se l'assignazione falla.
    ///
    ///
    /// Vede [`MaybeUninit::zeroed`][zeroed] per esempi di usu currettu è incorrettu di stu metudu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Restituisce u valore internu, se u `Arc` hà esattamente una forte rifarenza.
    ///
    /// Inutili, un [`Err`] hè restituitu cù u listessu `Arc` chì hè statu passatu.
    ///
    ///
    /// Questu avarà successu ancu s'ellu ci sò riferenzi debuli pendenti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Fate un puntatore debule per pulì u riferimentu implicitu forte-debule
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Custruisce una nova fetta cunta atomicamente di riferenza cun contenuti non inizializzati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inizializazione differita:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Custruisce una nova fetta cunta di riferenza atomica cù cuntenuti non inizializati, cù a memoria chì hè piena di byte `0`.
    ///
    ///
    /// Vede [`MaybeUninit::zeroed`][zeroed] per esempi di usu currettu è incorrettu di stu metudu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Converte in `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Cum'è cù [`MaybeUninit::assume_init`], tocca à u chjamante di garantisce chì u valore internu sia veramente in un statu inizializatu.
    ///
    /// Chjamà questu quandu u cuntenutu ùn hè ancu cumpletamente inizializatu provoca un cumpurtamentu indefinitu immediatu.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inizializazione differita:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Converte in `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Cum'è cù [`MaybeUninit::assume_init`], tocca à u chjamante di garantisce chì u valore internu sia veramente in un statu inizializatu.
    ///
    /// Chjamà questu quandu u cuntenutu ùn hè ancu cumpletamente inizializatu provoca un cumpurtamentu indefinitu immediatu.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inizializazione differita:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Consuma u `Arc`, restituendu u puntatore avvoltu.
    ///
    /// Per evità una perdita di memoria, u puntatore deve esse cunvertitu in un `Arc` cù [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Fornisce un puntatore grezzu à i dati.
    ///
    /// I conti ùn sò micca affettati in alcun modu è u `Arc` ùn hè micca cunsumatu.
    /// U puntatore hè validu finu à quandu ci sò conti forti in u `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SICUREZZA: Questu ùn pò passà per Deref::deref o RcBoxPtr::inner perchè
        // questu hè necessariu per conservà a provenienza raw/mut tale chì per esempio
        // `get_mut` pò scrive attraversu u puntatore dopu chì u Rc hè recuperatu per `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Custruisce un `Arc<T>` da un puntatore grezzu.
    ///
    /// U puntatore grezzu deve esse statu precedentemente restituitu da una chjamata à [`Arc<U>::into_raw`][into_raw] induve `U` deve avè a stessa dimensione è allineamentu cum'è `T`.
    /// Questu hè trivialmente veru se `U` hè `T`.
    /// Innota chì se `U` ùn hè micca `T` ma hà a stessa dimensione è allineamentu, questu hè basicamente cum'è trasmutazione di referenze di diversi tipi.
    /// Vede [`mem::transmute`][transmute] per più infurmazione nantu à e restrizioni applicabili in questu casu.
    ///
    /// L'utilizatore di `from_raw` hà da assicurassi chì un valore specificu di `T` sia cascatu una sola volta.
    ///
    /// Sta funzione ùn hè micca sicura perchè l'usu impropriu pò purtà à a memoria in securità, ancu se u `Arc<T>` restituitu ùn hè mai accessu.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Cunvertite torna in un `Arc` per prevene a fuga.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ulteriori chjamate à `Arc::from_raw(x_ptr)` serianu micca sicure in memoria.
    /// }
    ///
    /// // A memoria hè stata liberata quandu `x` hè andatu fora di u scopu sopra, allora `x_ptr` hè avà pendente!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Inversa l'offset per truvà l'ArcInner originale.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Crea un novu puntatore [`Weak`] per questa attribuzione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Questu Relaxed hè OK perchè verificemu u valore in u CAS sottu.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // verificate se u contatore debule hè attualmente "locked";sè cusì, filate.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: stu codice ignora attualmente a pussibilità di overflow
            // in usize::MAX;in generale sia Rc sia Arc necessitanu esse adattati per trattà u overflow.
            //

            // A differenza di Clone(), avemu bisognu chì questu sia una Acquista di lettura per sincronizà cù a scrittura chì vene da `is_unique`, in modo chì l'eventi precedenti à quella scrittura accadenu prima di sta lettura.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Assicuratevi chì ùn creemu micca un Debbule pendente
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Ottiene u numeru di puntatori [`Weak`] per questa attribuzione.
    ///
    /// # Safety
    ///
    /// Stu metudu per ellu stessu hè sicuru, ma u so usu currettu richiede una cura extra.
    /// Un altru filu pò cambià u numeru debule in ogni mumentu, cumprese potenzialmente trà chjamà stu metudu è agisce nantu à u risultatu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Questa affirmazione hè deterministica perchè ùn avemu micca spartutu u `Arc` o `Weak` trà fili.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Se u conte debule hè attualmente bloccatu, u valore di u conte era 0 appena prima di piglià a serratura.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Ottiene u numeru di forti puntatori (`Arc`) per questa attribuzione.
    ///
    /// # Safety
    ///
    /// Stu metudu per ellu stessu hè sicuru, ma u so usu currettu richiede una cura extra.
    /// Un altru filu pò cambià u numeru forte in ogni mumentu, cumprese potenzialmente trà chjamà stu metudu è agisce nantu à u risultatu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Questa affirmazione hè determinista perchè ùn avemu micca spartutu u `Arc` trà fili.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Incrementa u numeru di riferimentu forte nantu à u `Arc<T>` assuciatu cù u puntatore furnitu da unu.
    ///
    /// # Safety
    ///
    /// U puntatore deve esse statu uttenutu per mezu di `Arc::into_raw`, è l'istanza `Arc` associata deve esse valida (vale à dì
    /// u conte forte deve esse almenu 1) per a durata di stu metudu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Questa affirmazione hè determinista perchè ùn avemu micca spartutu u `Arc` trà fili.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Ritenite l'Arc, ma ùn toccate micca u numeru di refcount imballendu in ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Avà aumentate u numeru di refcount, ma ùn lasciate mancu novu refcount
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Decrementa u numeru di riferimentu forte nantu à u `Arc<T>` assuciatu cù u puntatore furnitu da unu.
    ///
    /// # Safety
    ///
    /// U puntatore deve esse statu uttenutu per mezu di `Arc::into_raw`, è l'istanza `Arc` associata deve esse valida (vale à dì
    /// u conte forte deve esse almenu 1) quandu invoca stu metudu.
    /// Stu metudu pò esse adupratu per liberà u `Arc` finale è u almacenamentu di sustegnu, ma **ùn deve micca** esse chjamatu dopu chì u `Arc` finale sia statu liberatu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Queste asserzioni sò deterministe perchè ùn avemu micca spartutu u `Arc` trà fili.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Questa insegurità hè ok perchè mentre questu arcu hè vivu ci hè garantitu chì u puntatore internu hè validu.
        // Inoltre, sapemu chì a struttura `ArcInner` stessa hè `Sync` perchè i dati interni sò ancu `Sync`, allora andemu bè à imprestà un puntatore immutabile à questi cuntenuti.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Parte non inline di `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Distrugge i dati à questu mumentu, ancu se ùn pudemu micca liberà l'allocazione di a scatula stessa (ci ponu ancu esse cunsiglii deboli in giru).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Abbandunate u debule ref cullettivamente tenutu da tutte e referenze forti
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Restituisce `true` se i dui `Arc` puntanu à a stessa attribuzione (in una vena simile à [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Assigna un `ArcInner<T>` cun spaziu sufficiente per un valore internu pussibuli micca dimensionatu induve u valore hà a dispusizione furnita.
    ///
    /// A funzione `mem_to_arcinner` hè chjamata cù u puntatore di dati è deve restituisce un indicatore (potenzialmente grassu) per u `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Calculate u schema aduprendu u schema di valore datu.
        // Nanzu, u layout era calculatu annantu à l'espressione `&*(ptr as* const ArcInner<T>)`, ma questu hà creatu un riferimentu disalliniatu (vede #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Assigna un `ArcInner<T>` cun spaziu sufficiente per un valore internu pussibuli micca dimensionatu induve u valore hà a dispusizione furnita, restituendu un errore se l'assignazione fiasca.
    ///
    ///
    /// A funzione `mem_to_arcinner` hè chjamata cù u puntatore di dati è deve restituisce un indicatore (potenzialmente grassu) per u `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Calculate u schema aduprendu u schema di valore datu.
        // Nanzu, u layout era calculatu annantu à l'espressione `&*(ptr as* const ArcInner<T>)`, ma questu hà creatu un riferimentu disalliniatu (vede #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inizializà l'ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Assigna un `ArcInner<T>` cun spaziu sufficiente per un valore interiore micca dimensionatu.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Assignate per u `ArcInner<T>` cù u valore datu.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copia u valore cum'è byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Libera l'allocazione senza abbandunà u so cuntenutu
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Assigna un `ArcInner<[T]>` cù a lunghezza data.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Copia l'elementi da a fetta in Arc novu attribuitu <\[T\]>
    ///
    /// Unsafe perchè u chjamante deve o piglià a pruprietà o ligà `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Custruisce un `Arc<[T]>` da un iteratore cunnisciutu per esse di una certa dimensione.
    ///
    /// U cumpurtamentu ùn hè micca definitu se a taglia hè sbagliata.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic guardia mentre clone elementi T.
        // In casu di un panic, elementi chì sò stati scritti in u novu ArcInner seranu abbandunati, poi a memoria liberata.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Puntatore à u primu elementu
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tuttu chjaru.Dimenticate a guardia per ùn liberà u novu ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializazione trait aduprata per `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Face un clone di u puntatore `Arc`.
    ///
    /// Questu crea un altru puntatore per a stessa allocazione, aumentendu u forte conte di riferimentu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Usà un ordine rilassatu hè bè quì, chì a cunniscenza di a riferenza originale impedisce à altri fili di cancellà erroneamente l'ughjettu.
        //
        // Cum'è spiegatu in u [Boost documentation][1], Aumentà u cuntatore di riferenza pò sempre esse fattu cù memory_order_relaxed: I novi riferimenti à un ogettu ponu esse furmati solu da una riferenza esistente, è passà una riferenza esistente da un filu à l'altru deve dighjà furnisce ogni sincronizazione necessaria.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Tuttavia ci vole à guardà da refcounts massicci in casu chì qualcunu sia `mem: : forget`ing Arcs.
        // Se ùn femu micca questu u cuntu pò overflow è l'utilizatori aduprà-after free.
        // Saturemu racialmente à `isize::MAX` in a supposizione chì ùn ci sò ~2 miliardi di fili chì aumentanu u cuntu di riferimentu in una volta.
        //
        // Questu branch ùn serà mai presu in alcun prugramma realistu.
        //
        // Abbortemu perchè un tale prugramma hè incredibilmente degeneratu, è ùn importa micca di sustene lu.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Face una riferenza mutevule in u `Arc` datu.
    ///
    /// Se ci sò altri puntatori `Arc` o [`Weak`] per a stessa attribuzione, allora `make_mut` creerà una nova attribuzione è invocerà [`clone`][clone] nantu à u valore internu per assicurà a pruprietà unica.
    /// Questu hè ancu chjamatu clone-on-write.
    ///
    /// Innota chì questu differe di u cumpurtamentu di [`Rc::make_mut`] chì disassocia qualsiasi puntatore `Weak` restante.
    ///
    /// Vede ancu [`get_mut`][get_mut], chì fallerà invece di clonà.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Ùn clonerà nunda
    /// let mut other_data = Arc::clone(&data); // Ùn clonerà micca dati interni
    /// *Arc::make_mut(&mut data) += 1;         // Cloni dati interni
    /// *Arc::make_mut(&mut data) += 1;         // Ùn clonerà nunda
    /// *Arc::make_mut(&mut other_data) *= 2;   // Ùn clonerà nunda
    ///
    /// // Avà `data` è `other_data` puntanu à allocazioni sfarenti.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Nutate bè chì tenemu à tempu una forte rifarenza è una rifarenza debule.
        // Cusì, rilasciate solu a nostra forte rifarenza ùn daverà micca, da per ellu, a distribuzione di a memoria.
        //
        // Aduprate Acquistà per assicurà chì vedemu scrive in `weak` chì accadenu prima di scrive in liberazione (vale à dì, decrementi) in `strong`.
        // Siccomu tenemu un conte debule, ùn ci hè alcuna possibilità chì ArcInner stessu pò esse dislocatu.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Un altru puntatore forte esiste, allora duvemu clonà.
            // Pre-attribuisce memoria per permette di scrive u valore clonatu direttamente.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Rilassatu basta in quì sopra perchè hè in fondu una ottimisazione: simu sempre in corsa cù puntatori debuli chì sò cascati.
            // U peghju casu, finiscemu assignatu un novu Arcu inutilmente.
            //

            // Avemu cacciatu l'ultimu rif forte, ma ci sò rifuggi debbuli addiziunali chì restanu.
            // Trasferiremu u cuntenutu à un novu Arcu, è invalideremu l'altri riflessi debuli.
            //

            // Nutate bè chì ùn hè micca pussibule per a lettura di `weak` di pruduce usize::MAX (vale à dì, chjosu), postu chì u numeru debule pò esse chjosu solu da un filu cun una forte rifarenza.
            //
            //

            // Materializà u nostru puntatore debule implicitu, in modu da pudè pulisce l'ArcInner quant'è necessariu.
            //
            let _weak = Weak { ptr: this.ptr };

            // Pudete solu arrubbà i dati, tuttu ciò chì ferma hè Debuli
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Eramu a sola riferenza di tutti i dui;ritruvate u forte conte di ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Cum'è cù `get_mut()`, a securità hè ok perchè a nostra riferenza era o unica per cumincià, o hè diventata una dopu a clonazione di u cuntenutu.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Restituisce una riferenza mutevule in u `Arc` datu, se ùn ci sò micca altri puntatori `Arc` o [`Weak`] à a listessa assignazione.
    ///
    ///
    /// Restituisce [`None`] altrimente, perchè ùn hè micca sicuru di mutà un valore cumunu.
    ///
    /// Vede ancu [`make_mut`][make_mut], chì farà [`clone`][clone] u valore internu quandu ci sò altri puntatori.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Questa insicurezza hè ok perchè avemu a garanzia chì u puntatore restituitu hè u *solu* puntatore chì serà mai restituitu à T.
            // U nostru numeru di riferimenti hè garantitu per esse 1 à questu puntu, è avemu dumandatu chì l'Arc stessu sia `mut`, allora tornemu l'unica riferenza pussibile à i dati interni.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Restituisce un riferimentu mutevule in u `Arc` datu, senza alcun cuntrollu.
    ///
    /// Vede ancu [`get_mut`], chì hè sicuru è face i cuntrolli adatti.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Ogni altru puntatore `Arc` o [`Weak`] per a stessa attribuzione ùn deve micca esse deriferenziata per a durata di u prestitu restituitu.
    ///
    /// Questu hè trivialmente u casu se ùn esistenu micca tali indicatori, per esempiu immediatamente dopu `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Semu attenti à *micca* creà una riferenza chì copre i campi "count", chì questu alias cù accessu concurrente à i conti di riferenza (es.
        // da `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Determinate se questu hè u riferimentu unicu (cumpresi referenzi debuli) à i dati sottostanti.
    ///
    ///
    /// Innota chì questu richiede di bloccà u conte di ref debuli.
    fn is_unique(&mut self) -> bool {
        // bluccà u cuntadore di puntatore debule sè paremu esse u solu detentore di puntatore debule.
        //
        // L'etichetta acquista quì assicura una relazione accaduta prima cù qualsiasi scrittura in `strong` (in particulare in `Weak::upgrade`) prima di decrementi di u conte `weak` (via `Weak::drop`, chì utilizza a liberazione).
        // Se u ref debule aghjurnatu ùn hè mai statu abbandunatu, u CAS quì fiascherà dunque ùn ci importa micca di sincronizà.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Questu deve esse un `Acquire` per sincronizà cù u decrementu di u cuntatore `strong` in `drop`-u solu accessu chì accade quandu qualchissia, ma l'ultima referenza hè stata abbandunata.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // U scrittu di liberazione quì si sincronizza cù una lettura in `downgrade`, evitendu in modu efficace a lettura sopra `strong` da accadere dopu a scrittura.
            //
            //
            self.inner().weak.store(1, Release); // liberà a serratura
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Gocce u `Arc`.
    ///
    /// Questu diminuirà u forte conte di riferenza.
    /// Se u numeru forte di riferenza righjunghji u zero allora l'unichi altri riferimenti (se esiste) sò [`Weak`], cusì avemu `drop` u valore internu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Ùn stampa nunda
    /// drop(foo2);   // Stampa "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Perchè `fetch_sub` hè dighjà atomicu, ùn avemu micca bisognu di sincronizà cun altri fili, à menu chì no eliminemu l'ughjettu.
        // Sta stessa logica si applica à u `fetch_sub` sottu à u conte `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Questa recinzione hè necessaria per impedisce u riordenamentu di l'usu di i dati è l'eliminazione di i dati.
        // Perchè hè marcatu `Release`, a diminuzione di u numeru di riferimentu si sincronizza cù sta recinzione `Acquire`.
        // Ciò significa chì l'usu di i dati accade prima di diminuire u conte di riferenza, chì accade prima di sta recinzione, chì accade prima di a cancellazione di i dati.
        //
        // Cum'è spiegatu in u [Boost documentation][1],
        //
        // > Hè impurtante di rinfurzà ogni accessu pussibule à l'ughjettu in unu
        // > thread (per mezu di una riferenza esistente) per *accadere prima di* sguassà
        // > l'ughjettu in un filu diversu.Questu hè rializatu da un "release"
        // > operazione dopu avè abbandunatu un riferimentu (qualsiasi accessu à l'ughjettu
        // > attraversu questu riferimentu deve ovviamente accadutu prima), è un
        // > "acquire" operazione prima di sguassà l'ughjettu.
        //
        // In particulare, mentre u cuntenutu di un Arcu hè di solitu immutabile, hè pussibile avè scrive interiore à qualcosa cum'è un Mutex<T>.
        // Postu chì un Mutex ùn hè micca acquistatu quandu hè eliminatu, ùn pudemu micca contà nantu à a so logica di sincronizazione per fà scrive in u filu A visibile per un distruttore in esecuzione in u filu B.
        //
        //
        // Innota ancu chì a fence Acquire quì puderia esse probabilmente rimpiazzata cù una carica Acquire, chì puderia migliurà e prestazioni in situazioni altamente disputate.Vede [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Pruvate à abbassà u `Arc<dyn Any + Send + Sync>` à un tipu cuncretu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Custruisce un novu `Weak<T>`, senza attribuisce alcuna memoria.
    /// Chjamà [`upgrade`] à u valore di ritornu dà sempre [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Tipu d'aiutu per permette l'accessu à i conti di riferenza senza fà alcuna asserzione nantu à u campu di dati.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Restituisce un puntatore grezzu à l'ughjettu `T` indicatu da questu `Weak<T>`.
    ///
    /// U puntatore hè validu solu s'ellu ci hè qualchì riferimentu forte.
    /// U puntatore pò esse pendente, micca alliniatu o ancu [`null`] altrimente.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Tramindui puntanu à u listessu ughjettu
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // U forte quì u mantene vivu, cusì pudemu sempre accede à l'ughjettu.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ma micca di più.
    /// // Pudemu fà weak.as_ptr(), ma accede à u puntatore cunduceria à un cumpurtamentu indefinitu.
    /// // assert_eq! ("bonghjornu", periculosu {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Se u puntatore hè pendente, rimandemu direttamente a sentinella.
            // Questu ùn pò micca esse un indirizzu di carica valida validu, chì a carica utile hè almenu allineata cum'è ArcInner (usize).
            ptr as *const T
        } else {
            // SICUREZZA: se is_dangling ritorna falsu, allora u puntatore hè dereferencable.
            // A carica utile pò esse abbandunata à questu puntu, è duvemu mantene a provenienza, allora aduprate a manipulazione di u puntatore grezzu.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Consuma u `Weak<T>` è u trasforma in un puntatore crudu.
    ///
    /// Questu cunverte u puntatore debule in un puntatore grezzu, pur mantenendu sempre a pruprietà di un riferimentu debule (u conte debule ùn hè micca mudificatu da questa operazione).
    /// Pò esse trasformatu in `Weak<T>` cù [`from_raw`].
    ///
    /// E stesse restrizioni per accede à u target di u puntatore cum'è cù [`as_ptr`] valenu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Converte un puntatore grezzu creatu prima da [`into_raw`] torna in `Weak<T>`.
    ///
    /// Questu pò esse adupratu per uttene in modu sicuru una forte riferenza (chjamendu [`upgrade`] più tardi) o per deallocate u conte debule lascendu cascà u `Weak<T>`.
    ///
    /// Piglia a pruprietà di un riferimentu debule (eccettu i puntatori creati da [`new`], chì questi ùn pussedenu nunda; u metudu funziona sempre nantu à elli).
    ///
    /// # Safety
    ///
    /// U puntatore deve esse uriginatu da u [`into_raw`] è deve ancu pussede u so putenziale riferimentu debule.
    ///
    /// Hè permessu chì u conte forte sia 0 à u mumentu di chjamà questu.
    /// Tuttavia, questu s'impatrunisce di un debule riferimentu attualmente rappresentatu cum'è un puntatore grezzo (u conte debule ùn hè micca mudificatu da questa operazione) è dunque deve esse accoppiato cun una chjamata precedente à [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Decrementà l'ultimu conte debule.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Vede Weak::as_ptr per u cuntestu nantu à cumu si deriva u puntatore d'entrata.

        let ptr = if is_dangling(ptr as *mut T) {
            // Questu hè un Debbule pendente.
            ptr as *mut ArcInner<T>
        } else {
            // Altrimenti, avemu a guaranzia chì u puntatore hè vinutu da un Debule nondangling.
            // SICUREZZA: data_offset hè sicuru da chjamà, postu chì ptr riferisce un veru T.
            let offset = unsafe { data_offset(ptr) };
            // Cusì, inveremu l'offset per uttene tuttu u RcBox.
            // SEGURITÀ: u puntatore hè natu da un Debule, dunque questu offset hè sicuru.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SICUREZZA: avemu avà recuperatu u puntatore uriginale Debule, cusì pudemu creà u Debule.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Tentativi di aghjurnà u puntatore `Weak` à un [`Arc`], ritardendu a caduta di u valore internu se riesce.
    ///
    ///
    /// Restituisce [`None`] se u valore internu hè statu dapoi abbandunatu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Distrugge tutti i punti forti.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Usemu un ciclu CAS per incrementà u numeru forte invece di fetch_add chì sta funzione ùn deve mai piglià u numeru di riferenza da zero à unu.
        //
        //
        let inner = self.inner()?;

        // Carica rilassata perchè qualsiasi scrittura di 0 chì pudemu osservà lascia u campu in un statu permanentemente zero (dunque una lettura "stale" di 0 va bè), è qualsiasi altru valore hè cunfirmatu via u CAS sottu.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Vede i cumenti in `Arc::clone` per quessa chì facemu questu (per `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed va bè per u casu di fallimentu perchè ùn avemu micca aspettative nantu à u novu statu.
            // Acquistà hè necessariu per u casu di successu per sincronizà cù `Arc::new_cyclic`, quandu u valore internu pò esse inizializatu dopu chì e referenze `Weak` sò digià state create.
            // In quellu casu, aspettemu di osservà u valore cumpletamente inizializatu.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null verificatu sopra
                Err(old) => n = old,
            }
        }
    }

    /// Ottiene u numeru di forti puntatori (`Arc`) chì indicanu sta attribuzione.
    ///
    /// Se `self` hè statu creatu cù [`Weak::new`], questu restituverà 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Ottiene una approssimazione di u numeru di puntatori `Weak` chì puntanu à st'attribuzione.
    ///
    /// Se `self` hè statu creatu cù [`Weak::new`], o se ùn ci sò più punti forti, questu restituverà 0.
    ///
    /// # Accuracy
    ///
    /// A causa di i dettagli di l'implementazione, u valore restituitu pò esse disattivatu da 1 in ogni direzione quandu altri threads manipulanu qualsiasi `Arc`s o`Weak`s chì indicanu a stessa attribuzione.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Postu chì avemu osservatu chì ci era almenu un puntatore forte dopu avè lettu u conte debule, sapemu chì u riferimentu debule implicitu (prisente ogni volta chì qualchì riferimentu forte hè vivu) era sempre in giru quandu avemu osservatu u conte debule, è pudemu dunque sotturallu.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Ritorna `None` quandu u puntatore hè pendente è ùn ci hè micca `ArcInner` assignatu, (vale à dì, quandu stu `Weak` hè statu creatu da `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Semu attenti à *micca* creà una riferenza chì copre u campu "data", chì u campu pò esse mutatu simultaneamente (per esempiu, se l'ultimu `Arc` hè abbandunatu, u campu di dati serà abbandunatu in locu).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Restituisce `true` se i dui `Debuli` puntanu à a stessa attribuzione (simile à [`ptr::eq`]), o sì tramindui ùn puntanu micca à alcuna attribuzione (perchè sò stati creati cù `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Siccomu questu compara indicatori significa chì `Weak::new()` sarà uguale unu à l'altru, ancu s'elli ùn puntanu micca à alcuna attribuzione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Cumparendu `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Face un clone di u puntatore `Weak` chì punta à a stessa attribuzione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Vede i cumenti in Arc::clone() per quessa hè rilassatu.
        // Questu pò aduprà un fetch_add (ignurendu u bloccu) perchè u numeru debule hè chjosu solu induve ùn ci sò *altri* puntatori debuli in esistenza.
        //
        // (Cusì ùn pudemu micca esse in esecuzione stu codice in questu casu).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Vede i cumenti in Arc::clone() per quessa chì facemu questu (per mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Custruisce un novu `Weak<T>`, senza allocà memoria.
    /// Chjamà [`upgrade`] à u valore di ritornu dà sempre [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Gocce u puntatore `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ùn stampa nunda
    /// drop(foo);        // Stampa "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Se truvemu chì eramu l'ultimu puntatore debule, allora hè ora di trattà interamente i dati.Vede a discussione in Arc::drop() nantu à l'ordine di memoria
        //
        // Ùn hè micca necessariu di verificà u statu chjosu quì, perchè u numeru debule pò esse bluccatu solu s'ellu ci era precisamente un ref debule, vale à dì chì a goccia puderia solu successivamente girà ON nant'à u restu ref debule, chì pò accadere solu dopu à a liberazione di u serratura.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Facemu sta specializazione quì, è micca cum'è una ottimisazione più generale nantu à `&T`, perchè altrimenti aghjunghjeria un costu per tutti i cuntrolli di uguaglianza nantu à i ref.
/// Assumemu chì `Arc`s sò aduprati per immagazzinà grandi valori, chì sò lenti à clonà, ma ancu pesanti per verificà l'ugualità, facendu chì questu costu paghi più facilmente.
///
/// Hè ancu più prubabile d'avè dui cloni `Arc`, chì indicanu u listessu valore, cà dui `&T`s.
///
/// Ùn pudemu micca fà questu quandu `T: Eq` cum'è `PartialEq` pò esse deliberatamente irreflexivu.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Uguaglianza per dui `Arc`s.
    ///
    /// Dui `Arc`s sò uguali se i so valori interni sò uguali, ancu s'elli sò memorizzati in una distribuzione diversa.
    ///
    /// Se `T` implementa ancu `Eq` (chì implica riflessività di uguaglianza), dui `Arc` chì indicanu a stessa attribuzione sò sempre uguali.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Iniqualità per dui `Arc`s.
    ///
    /// Dui `Arc`s sò inuguali se i so valori interni sò inuguali.
    ///
    /// Se `T` implementa ancu `Eq` (chì implica riflessività di uguaglianza), dui `Arc` chì indicanu u listessu valore ùn sò mai inuguali.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Paragone parziale per dui `Arc`s.
    ///
    /// I dui sò paragunati chjamendu `partial_cmp()` nantu à i so valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Paragunà menu chè dui Arc.
    ///
    /// I dui sò paragunati chjamendu `<` nantu à i so valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Paragunà 'menu o uguale à' per dui `Arc`.
    ///
    /// I dui sò paragunati chjamendu `<=` nantu à i so valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Paragone più grande di quellu per dui `Arc`.
    ///
    /// I dui sò paragunati chjamendu `>` nantu à i so valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Paragone "Maggiore o uguale à" per dui "Arc".
    ///
    /// I dui sò paragunati chjamendu `>=` nantu à i so valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Cunfrontu per dui `Arc`s.
    ///
    /// I dui sò paragunati chjamendu `cmp()` nantu à i so valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Crea un novu `Arc<T>`, cù u valore `Default` per `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Assignate una fetta cuntata di riferenza è riempila clonendu l'articuli di "v".
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Assignate un `str` cuntatu di riferenza è copiate `v` in questu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Assignate un `str` cuntatu di riferenza è copiate `v` in questu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Move un ughjettu in scatula à una nova assignazione riferita.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Assignate una fetta cuntata di riferenza è move l'articuli di "v" in questu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Permettite à Vec di liberà a so memoria, ma micca di distrughje u so cuntenutu
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Piglia ogni elementu in u `Iterator` è u raccoglie in un `Arc<[T]>`.
    ///
    /// # Caratteristiche di prestazione
    ///
    /// ## U casu generale
    ///
    /// In u casu generale, a raccolta in `Arc<[T]>` hè fatta da a prima raccolta in un `Vec<T>`.Hè cusì, quandu scrivite u seguitu:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// questu si comporta cum'è se avemu scrittu:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // U primu gruppu di allocazioni accade quì.
    ///     .into(); // Una seconda assignazione per `Arc<[T]>` accade quì.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Questu assignerà quante volte chì ci hè necessariu per custruisce u `Vec<T>` è poi assignerà una volta per trasformà u `Vec<T>` in u `Arc<[T]>`.
    ///
    ///
    /// ## Iteratori di lunghezza cunnisciuta
    ///
    /// Quandu u vostru `Iterator` implementa `TrustedLen` è hè di una dimensione esatta, una sola attribuzione serà fatta per u `Arc<[T]>`.Per esempiu:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Una sola attribuzione accade quì.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specializazione trait aduprata per coglie in `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Hè u casu per un iteratore `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SICUREZZA: Avemu bisognu di assicurà chì l'iteratore abbia una lunghezza esatta è l'avemu.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Riturnate à l'implementazione normale.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Uttenite a compensazione in un `ArcInner` per a carica utile dietro un puntatore.
///
/// # Safety
///
/// U puntatore deve puntà (è avè metadati validi per) un'istanza valida prima di T, ma u T hè permessu di esse abbandunatu.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Alignate u valore micca dimensionatu à a fine di l'ArcInner.
    // Perchè RcBox hè repr(C), serà sempre l'ultimu campu in memoria.
    // SICUREZZA: postu chì i soli tippi senza dimensioni pussibuli sò fette, oggetti trait,
    // è tippi esterni, u requisitu di sicurezza in ingressu hè attualmente abbastanza per soddisfà i requisiti di align_of_val_raw;questu hè un dettagliu di implementazione di a lingua chì ùn pò micca esse invucatu fora di std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}