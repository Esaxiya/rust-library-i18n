use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Un'altra specializazione trait per Vec::from_iter necessaria per priorità manualmente e specializazioni sovrapposte vedi [`SpecFromIter`](super::SpecFromIter) per i dettagli.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Svolgite a prima iterazione, chì u vector hà da esse allargatu nantu à questa iterazione in ogni casu quandu l'iterabile ùn hè micca viotu, ma u ciclu in extend_desugared() ùn vedrà micca chì u vector sia pienu in e poche iterazioni successive di ciclu.
        //
        // Cusì avemu una migliore previsione branch.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // deve delegà à spec_extend() postu chì extend() stessu delega à spec_from per Vecs vioti
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // deve delegà à spec_extend() postu chì extend() stessu delega à spec_from per Vecs vioti
        //
        vector.spec_extend(iterator);
        vector
    }
}