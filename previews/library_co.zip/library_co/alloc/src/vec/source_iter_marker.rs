use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Marcatore di specializazione per a raccolta di una pipeline iteratore in un Vec mentre riutilizza l'allocazione sorgente, cioè
/// esecutendu u pipeline in locu.
///
/// U genitore SourceIter trait hè necessariu per a funzione di specializazione per accede à l'attribuzione chì deve esse riutilizzata.
/// Ma ùn basta micca chì a specializazione sia valida.
/// Vede limiti supplementari nantu à l'impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// U std-internu SourceIter/InPlaceIterable traits sò solu implementati da catene di Adattatore <Adapter<Adapter<IntoIter>>> (tutti di pruprietà di core/std).
// Limiti addiziunali nantu à l'implementazioni di l'adattatori (al di là di `impl<I: Trait> Trait for Adapter<I>`) dipendenu solu da altri traits digià marcati cum'è specializazione traits (Copia, TrustedRandomAccess, FusedIterator).
//
// I.e. u marcatore ùn dipende micca da a vita di i tipi furniti da l'utente.Muduleghja u foru Copia, chì dipende dapoi parechje altre specializazioni.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Esigenze addiziunali chì ùn ponu micca esse espresse via trait bounds.Ci appughjemu nantu à const eval invece:
        // a) senza ZSTs cume ùn ci sarebbe alcuna attribuzione per riutilizà è l'aritmetica di u puntatore seria panic b) dimensione currisponde à u requisitu di u cuntrattu Alloc c) allineamenti currispondenu cum'è richiestu da u contrattu Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // ritornu à implementazioni più generiche
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // aduprà try-fold dapoi
        // - vectorizeghja megliu per alcuni adattatori iteratori
        // - à u cuntrariu di a maiò parte di i metudi di iterazione interna, piglia solu un autore &mut
        // - ci lascia infilarà u puntatore di scrittura attraversu e so entrate è ritruvallu à a fine
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // l'iterazione hà riesciutu, ùn lasciate micca cascà
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // verificate se u cuntrattu SourceIter hè statu cunfirmatu avvisu: sì ùn eranu micca, ùn pudemu mancu ghjunghje finu à questu puntu
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // verificate u cuntrattu InPlaceIterable.Questu hè pussibile solu se l'iteratore hà avanzatu u puntatore surghjente.
        // Se usa un accessu micca verificatu via TrustedRandomAccess allora u puntatore surghjente fermerà in a so pusizione iniziale è ùn pudemu micca aduprà cum'è riferimentu
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // lascià calà i valori restanti à a coda di a surghjente ma impedisce a calata di l'assignazione stessa una volta IntoIter esce fora di portata se a caduta panics allora perdemu ancu qualsiasi elementu raccoltu in dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // u cuntrattu InPlaceIterable ùn pò micca esse verificatu precisamente quì postu chì try_fold hà un riferimentu esclusivu à u puntatore surghjente tuttu ciò chì pudemu fà hè verificà s'ellu hè sempre in portata
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}