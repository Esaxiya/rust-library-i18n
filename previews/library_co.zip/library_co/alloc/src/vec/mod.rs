//! Un tippu di matrice crescibile contiguu cù cuntenuti attribuiti in pile, scrittu `Vec<T>`.
//!
//! Vectors anu indexatu `O(1)`, push amortizatu `O(1)` (finu à a fine) è `O(1)` pop (da a fine).
//!
//!
//! Vectors assicura chì ùn assignanu mai più di byte `isize::MAX`.
//!
//! # Examples
//!
//! Pudete esplicitamente creà un [`Vec`] cù [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... o aduprendu a macro [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // dece zeru
//! ```
//!
//! Pudete valori [`push`] à a fine di un vector (chì cresce u vector cumu necessariu):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! I valori popping funzionanu in u listessu modu:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors supporta ancu l'indexazione (attraversu [`Index`] è [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Un tippu di matrice crescibile contigua, scrittu cum'è `Vec<T>` è pronunziatu 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// A macro [`vec!`] hè furnita per fà l'inizializazione più cunvene:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Pò dinò inizializà ogni elementu di un `Vec<T>` cun un valore datu.
/// Questu pò esse più efficiente ch'è eseguisce allocazione è inizializazione in passi separati, soprattuttu quandu si inizializza un vector di zeros:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // U seguitu hè equivalente, ma potenzialmente più lento:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Per più infurmazione, vedi [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Aduprate un `Vec<T>` cum'è una pila efficiente:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Stampe 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// U tippu `Vec` permette di accede à i valori per indice, perchè implementa u [`Index`] trait.Un esempiu serà più esplicitu:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // mostrarà '2'
/// ```
///
/// Tuttavia attenti: sè pruvate à accede à un indice chì ùn hè micca in u `Vec`, u vostru software serà panic!Ùn pudete micca fà questu:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Aduprate [`get`] è [`get_mut`] se vulete verificà se l'indice hè in `Vec`.
///
/// # Slicing
///
/// Un `Vec` pò esse mudificabile.D'altra parte, e fette sò oggetti di sola lettura.
/// Per uttene un [slice][prim@slice], aduprate [`&`].Esempiu:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... è basta!
/// // pudete ancu fà cusì:
/// let u: &[usize] = &v;
/// // o cusì:
/// let u: &[_] = &v;
/// ```
///
/// In Rust, hè più cumunu di passà fette cum'è argumenti piuttostu chè vectors quandu vulete solu furnisce accessu di lettura.U listessu vale per [`String`] è [`&str`].
///
/// # Capacità è riassegnazione
///
/// A capacità di un vector hè a quantità di spaziu attribuitu per qualsiasi elementi future chì seranu aghjuntu à u vector.Questu ùn hè micca cunfunditu cù a *lunghezza* di un vector, chì specifica u numeru di elementi reali in u vector.
/// Se a lunghezza di un vector supera a so capacità, a so capacità serà automaticamente aumentata, ma i so elementi duveranu esse riallocati.
///
/// Per esempiu, un vector cù capacità 10 è lunghezza 0 seria un vector vacante cù spaziu per 10 elementi in più.Spinghje 10 o menu elementi nantu à u vector ùn cambierà micca a so capacità o pruvucerà a riallocazione.
/// Tuttavia, se a lunghezza di u vector hè aumentata à 11, duverà riallocà, chì pò esse lenta.Per questa ragione, hè raccomandatu di aduprà [`Vec::with_capacity`] ogni volta chì hè pussibule per specificà quantu sarà grande u vector.
///
/// # Guarantees
///
/// A causa di a so natura incredibilmente fundamentale, `Vec` face assai garanzie nantu à u so design.Questu assicura chì sia u più bassu pussibule in u casu generale, è pò esse manipulatu currettamente in modi primitivi da un codice periculosu.Nota chì queste garanzie si riferiscenu à un `Vec<T>` senza qualificazione.
/// Se sò aghjunti parametri di tipu addiziunali (per esempiu, per supportà allocatori persunalizati), annullà i so predefiniti pò cambià u cumpurtamentu.
///
/// U più fundamentale, `Vec` hè è serà sempre un triplettu (puntatore, capacità, lunghezza).Mancu più, micca menu.L'ordine di sti campi hè cumpletamente micca specificatu, è duverete aduprà i metudi adatti per mudificà questi.
/// U puntatore ùn serà mai nullu, dunque stu tippu hè null-pointer-optimized.
///
/// Tuttavia, u puntatore ùn pò micca veramente puntà a memoria attribuita.
/// In particulare, se custruite un `Vec` cù capacità 0 via [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], o chjamendu [`shrink_to_fit`] nantu à un Vec vacante, ùn assignerà micca memoria.Similmente, se magazzini tippi di dimensioni zero in un `Vec`, ùn assignerà micca spaziu per elli.
/// *Nota chì in questu casu l `Vec` ùn pò micca segnalà un [`capacity`] di 0*.
/// `Vec` assignerà se è solu se [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// In generale, i dettagli di allocazione di `Vec` sò assai suttili-se avete intenzione di attribuisce a memoria aduprendu un `Vec` è di usalla per qualcosa d'altru (sia per passà à un codice periculosu, sia per custruisce a vostra propria collezione sustenuta da memoria), assicuratevi per deallocate sta memoria aduprendu `from_raw_parts` per recuperà u `Vec` è poi lasciallu.
///
/// Se un `Vec`*hà* attribuitu memoria, allora a memoria chì punta hè nantu à a mansa (cume definita da l'allocatore Rust hè configurata per aduprà per difettu), è u so puntatore punta à [`len`] inizializatu, elementi contigui in ordine (ciò chì vulete vede se l'avete coercita in una fetta), seguitata da [`capacità`]`,`[`len`] elementi logicamente non inizializzati, contigui.
///
///
/// Un vector chì cuntene l'elementi `'a'` è `'b'` cù capacità 4 pò esse visualizatu cum'è quì sottu.A parte superiore hè a struttura `Vec`, cuntene un puntatore à u capu di l'attribuzione in u cumunu, lunghezza è capacità.
/// A parte di fondu hè a distribuzione nantu à a mansa, un bloccu di memoria contigu.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** representa a memoria chì ùn hè micca inizializata, vede [`MaybeUninit`].
/// - Note: l'ABI ùn hè micca stabile è `Vec` ùn face nisuna garanzia nantu à a so dispusizione di memoria (cumpresu l'ordine di campi).
///
/// `Vec` ùn eseguirà mai un "small optimization" induve l'elementi sò veramente archiviati in u stack per duie ragioni:
///
/// * Faria più difficiule per un codice periculosu di manipulà currettamente un `Vec`.U cuntenutu di un `Vec` ùn averia micca un indirizzu stabile s'ellu fussi solu spostatu, è sarebbe più difficiule di determinà se un `Vec` avia effettivamente attribuitu memoria.
///
/// * Saria penalizatu u casu generale, incurrendu in un branch in più per ogni accessu.
///
/// `Vec` ùn si scurderà mai automaticamente, ancu sè cumpletamente viotu.Questu ùn assicura micca allocazioni o deallocations inutili.Sviutà un `Vec` è poi riempialu di novu in u listessu [`len`] ùn deve incurru micca chjamate à l'allocatore.Se vulete liberà memoria inutilizzata, utilizate [`shrink_to_fit`] o [`shrink_to`].
///
/// [`push`] è [`insert`] ùn (re) assignerà mai se a capacità riportata hè sufficiente.[`push`] è [`insert`]* ** (ri) assigneranu se [`len`]`==`[`capacità`].Hè cusì, a capacità riportata hè cumpletamente precisa, è pò esse invucata.Pò esse ancu adupratu per liberà manualmente a memoria attribuita da un `Vec` se vulete.
/// I metudi d'inserzione in massa *ponu* riallocà, ancu quandu ùn hè micca necessariu.
///
/// `Vec` ùn garantisce alcuna strategia di crescita particulare quandu si rialloca quandu hè pienu, nè quandu hè chjamatu [`reserve`].A strategia attuale hè di basa è pò rivelassi desiderabile aduprà un fattore di crescita micca costante.Qualunque sia a strategia aduprata garantirà naturalmente *O*(1) [`push`] ammortizatu.
///
/// `vec![x; n]`, `vec![a, b, c, d]`, è [`Vec::with_capacity(n)`][`Vec::with_capacity`], pruduceranu tutti un `Vec` cù esattamente a capacità richiesta.
/// Se [`len`]`==`[`capacità`], (cum'è u casu per a macro [`vec!`]), allora un `Vec<T>` pò esse cunvertitu da e per un [`Box<[T]>`][owned slice] senza riallocà o spustà l'elementi.
///
/// `Vec` ùn soprascriverà micca specificamente i dati chì ne sò rimossi, ma ancu ùn li preserveranu micca specificamente.A so memoria micca inizializata hè un spaziu di scratch chì pò aduprà quantunque vole.Generalmente farà solu ciò chì hè u più efficace o altrimenti faciule da mette in opera.Ùn fidatevi micca à i dati eliminati per esse cancellati per scopi di sicurezza.
/// Ancu se lasciate un `Vec`, u so buffer pò esse semplicemente riutilizatu da un altru `Vec`.
/// Ancu se zero a memoria di un `Vec` prima, ùn pò micca accade in realtà perchè l'ottimizzatore ùn considera micca questu un effetti collaterale chì deve esse cunservatu.
/// Ci hè un casu chì ùn romperemu micca, tuttavia: aduprà u codice `unsafe` per scrive à a capacità in eccessu, è allora aumentà a lunghezza per abbinà, hè sempre validu.
///
/// Attualmente, `Vec` ùn garantisce micca l'ordine in cui l'elementi sò cascati.
/// L'ordine hè cambiatu in u passatu è pò cambià di novu.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Metudi inerenti
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Custruisce un novu `Vec<T>` viotu.
    ///
    /// U vector ùn assignerà micca finu à chì l'elementi sò spinti annantu.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Custruisce un novu `Vec<T>` viotu cù a capacità specificata.
    ///
    /// U vector puderà tene esattamente elementi `capacity` senza riallocu.
    /// Se `capacity` hè 0, u vector ùn assignerà micca.
    ///
    /// Hè impurtante nutà chì ancu se u vector restituitu hà a *capacità* specificata, u vector averà una lunghezza zero *.
    ///
    /// Per una spiegazione di a differenza trà lunghezza è capacità, vedi *[Capacità è riallocazione]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // U vector ùn cuntene micca articuli, ancu s'ellu hà capacità per più
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Quessi sò tutti fatti senza riallocazione ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ma questu pò fà riallocà u vector
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Crea un `Vec<T>` direttamente da i cumpunenti grezzi di un altru vector.
    ///
    /// # Safety
    ///
    /// Questu hè assai periculosu, per via di u numeru d'invarianti chì ùn sò micca verificati:
    ///
    /// * `ptr` deve esse statu attribuitu in precedenza via [`String`]/`Vec<T>"(Almenu, hè assai probabile chì sia incorrettu se ùn era micca).
    /// * `T` deve avè a stessa dimensione è allineamentu cum'è ciò chì `ptr` hè statu attribuitu cù.
    ///   (`T` avendu un allinamentu menu strettu ùn hè micca sufficiente, l'allineamentu deve veramente esse uguale per soddisfà u requisitu [`dealloc`] chì a memoria deve esse attribuita è deallocata cù u listessu layout.)
    ///
    /// * `length` deve esse menu o uguale à `capacity`.
    /// * `capacity` deve esse a capacità chì u puntatore hè statu attribuitu cù.
    ///
    /// A violazione di questi pò causà prublemi cum'è a corruzzione di e strutture di dati interni di l'allocatore.Per esempiu hè **micca** sicuru di custruisce un `Vec<u8>` da un puntatore à un array C `char` cù lunghezza `size_t`.
    /// Ùn hè ancu micca sicuru di custruisce unu da un `Vec<u16>` è a so lunghezza, perchè l'allocatore si preoccupa di l'allinjamentu, è sti dui tippi anu allineamenti diversi.
    /// U buffer hè statu attribuitu cù l'allineamentu 2 (per `u16`), ma dopu trasformatu in un `Vec<u8>` serà distribuitu cù l'allineamentu 1.
    ///
    /// A pruprietà di `ptr` hè effittivamenti trasferita à u `Vec<T>` chì pò dopu riallocà, riallocà o cambià u cuntenutu di a memoria indicatu da u puntatore à vuluntà.
    /// Assicuratevi chì nunda di più utilizi u puntatore dopu avè chjamatu sta funzione.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Aghjurnate questu quandu vec_into_raw_parts hè stabilizatu.
    ///     // Impedite di fà corre u distruttore `v` allora simu in u cuntrollu cumpletu di l'assignazione.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tirate i vari pezzi impurtanti d'infurmazioni nantu à `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Scrivite a memoria cù 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Rimette tuttu in un Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Custruisce un novu `Vec<T, A>` viotu.
    ///
    /// U vector ùn assignerà micca finu à chì l'elementi sò spinti annantu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Custruisce un novu `Vec<T, A>` viotu cù a capacità specificata cù l'allocatore furnitu.
    ///
    /// U vector puderà tene esattamente elementi `capacity` senza riallocu.
    /// Se `capacity` hè 0, u vector ùn assignerà micca.
    ///
    /// Hè impurtante nutà chì ancu se u vector restituitu hà a *capacità* specificata, u vector averà una lunghezza zero *.
    ///
    /// Per una spiegazione di a differenza trà lunghezza è capacità, vedi *[Capacità è riallocazione]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // U vector ùn cuntene micca articuli, ancu s'ellu hà capacità per più
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Quessi sò tutti fatti senza riallocazione ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ma questu pò fà riallocà u vector
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Crea un `Vec<T, A>` direttamente da i cumpunenti grezzi di un altru vector.
    ///
    /// # Safety
    ///
    /// Questu hè assai periculosu, per via di u numeru d'invarianti chì ùn sò micca verificati:
    ///
    /// * `ptr` deve esse statu attribuitu in precedenza via [`String`]/`Vec<T>"(Almenu, hè assai probabile chì sia incorrettu se ùn era micca).
    /// * `T` deve avè a stessa dimensione è allineamentu cum'è ciò chì `ptr` hè statu attribuitu cù.
    ///   (`T` avendu un allinamentu menu strettu ùn hè micca sufficiente, l'allineamentu deve veramente esse uguale per soddisfà u requisitu [`dealloc`] chì a memoria deve esse attribuita è deallocata cù u listessu layout.)
    ///
    /// * `length` deve esse menu o uguale à `capacity`.
    /// * `capacity` deve esse a capacità chì u puntatore hè statu attribuitu cù.
    ///
    /// A violazione di questi pò causà prublemi cum'è a corruzzione di e strutture di dati interni di l'allocatore.Per esempiu hè **micca** sicuru di custruisce un `Vec<u8>` da un puntatore à un array C `char` cù lunghezza `size_t`.
    /// Ùn hè ancu micca sicuru di custruisce unu da un `Vec<u16>` è a so lunghezza, perchè l'allocatore si preoccupa di l'allinjamentu, è sti dui tippi anu allineamenti diversi.
    /// U buffer hè statu attribuitu cù l'allineamentu 2 (per `u16`), ma dopu trasformatu in un `Vec<u8>` serà distribuitu cù l'allineamentu 1.
    ///
    /// A pruprietà di `ptr` hè effittivamenti trasferita à u `Vec<T>` chì pò dopu riallocà, riallocà o cambià u cuntenutu di a memoria indicatu da u puntatore à vuluntà.
    /// Assicuratevi chì nunda di più utilizi u puntatore dopu avè chjamatu sta funzione.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Aghjurnate questu quandu vec_into_raw_parts hè stabilizatu.
    ///     // Impedite di fà corre u distruttore `v` allora simu in u cuntrollu cumpletu di l'assignazione.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tirate i vari pezzi impurtanti d'infurmazioni nantu à `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Scrivite a memoria cù 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Rimette tuttu in un Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Decompone un `Vec<T>` in i so cumpunenti grezzi.
    ///
    /// Restituisce u puntatore grezzu à i dati sottostanti, a lunghezza di u vector (in elementi), è a capacità attribuita di i dati (in elementi).
    /// Quessi sò i listessi argumenti in u listessu ordine chì l'argumenti per [`from_raw_parts`].
    ///
    /// Dopu avè chjamatu sta funzione, u chjamante hè rispunsevule per a memoria previamente gestita da u `Vec`.
    /// L'unicu modu per fà questu hè di cunvertisce u puntatore grezzu, a lunghezza è a capacità in un `Vec` cù a funzione [`from_raw_parts`], permettendu à u distruttore di fà a pulizia.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Pudemu avà fà cambiamenti à i cumpunenti, cume trasmutà u puntatore grezzu à un tippu cumpatibile.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Decompone un `Vec<T>` in i so cumpunenti grezzi.
    ///
    /// Restituisce u puntatore grezzu à i dati sottostanti, a lunghezza di u vector (in elementi), a capacità attribuita di i dati (in elementi), è l'allocatore.
    /// Quessi sò i listessi argumenti in u listessu ordine chì l'argumenti per [`from_raw_parts_in`].
    ///
    /// Dopu avè chjamatu sta funzione, u chjamante hè rispunsevule per a memoria previamente gestita da u `Vec`.
    /// L'unicu modu per fà questu hè di cunvertisce u puntatore grezzu, a lunghezza è a capacità in un `Vec` cù a funzione [`from_raw_parts_in`], permettendu à u distruttore di fà a pulizia.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Pudemu avà fà cambiamenti à i cumpunenti, cume trasmutà u puntatore grezzu à un tippu cumpatibile.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Restituisce u numeru di elementi chì u vector pò tene senza riallocu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Riserva capacità per almenu `additional` più elementi da inserisce in u `Vec<T>` datu.
    /// A cullezzione pò riservà più spaziu per evità riallocazioni frequenti.
    /// Dopu avè chjamatu `reserve`, a capacità serà più grande o uguale à `self.len() + additional`.
    /// Ùn face nunda se a capacità hè dighjà sufficiente.
    ///
    /// # Panics
    ///
    /// Panics se a nova capacità supera i `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Riserva a capacità minima per esattamente `additional` più elementi da inserisce in u `Vec<T>` datu.
    ///
    /// Dopu avè chjamatu `reserve_exact`, a capacità serà più grande o uguale à `self.len() + additional`.
    /// Ùn face nunda se a capacità hè dighjà sufficiente.
    ///
    /// Nutate bè chì l'allocatore pò dà à a cullezzione più spaziu di quantu dumanda.
    /// Dunque, a capacità ùn pò esse invucata per esse precisamente minima.
    /// Preferite `reserve` se si prevede inserzioni future.
    ///
    /// # Panics
    ///
    /// Panics se a nova capacità suprana `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Prova à riservà capacità per almenu `additional` più elementi da inserisce in u `Vec<T>` datu.
    /// A cullezzione pò riservà più spaziu per evità riallocazioni frequenti.
    /// Dopu avè chjamatu `try_reserve`, a capacità serà più grande o uguale à `self.len() + additional`.
    /// Ùn face nunda se a capacità hè dighjà sufficiente.
    ///
    /// # Errors
    ///
    /// Se a capacità suprana, o l'allocatore riporta un fallimentu, allora un errore hè restituitu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pre-riserva a memoria, surtendu sì ùn pudemu micca
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Avà sapemu chì questu ùn pò micca OOM in mezu à u nostru travagliu cumplessu
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // assai cumplicatu
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Prova à riservà a capacità minima per elementi esattamente `additional` da inserisce in u `Vec<T>` datu.
    /// Dopu avè chjamatu `try_reserve_exact`, a capacità serà più grande o uguale à `self.len() + additional` se ritorna `Ok(())`.
    ///
    /// Ùn face nunda se a capacità hè dighjà sufficiente.
    ///
    /// Nutate bè chì l'allocatore pò dà à a cullezzione più spaziu di quantu dumanda.
    /// Dunque, a capacità ùn pò esse invucata per esse precisamente minima.
    /// Preferite `reserve` se si prevede inserzioni future.
    ///
    /// # Errors
    ///
    /// Se a capacità suprana, o l'allocatore riporta un fallimentu, allora un errore hè restituitu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pre-riserva a memoria, surtendu sì ùn pudemu micca
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Avà sapemu chì questu ùn pò micca OOM in mezu à u nostru travagliu cumplessu
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // assai cumplicatu
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Riduce a capacità di u vector quant'è pussibule.
    ///
    /// Serà falatu u più vicinu pussibule à a lunghezza ma l'allocatore pò ancu informà u vector chì ci hè spaziu per uni pochi di più elementi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // A capacità ùn hè mai menu di a lunghezza, è ùn ci hè nunda da fà quandu sò uguali, cusì pudemu evità u casu panic in `RawVec::shrink_to_fit` chjamendulu solu cù una capacità più grande.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Riduce a capacità di u vector cun un limite inferiore.
    ///
    /// A capacità fermerà almenu quant'è a lunghezza è u valore furnitu.
    ///
    ///
    /// Se a capacità attuale hè menu di u limitu inferiore, questu hè un no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Converte u vector in [`Box<[T]>`][owned slice].
    ///
    /// Innota chì questu abbandunarà qualsiasi capacità in eccessu.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Ogni capacità in eccessu hè eliminata:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Accurta u vector, mantenendu i primi elementi `len` è lascendu cascà u restu.
    ///
    /// Se `len` hè più grande di a lunghezza attuale di u vector, questu ùn hà micca effetti.
    ///
    /// U metudu [`drain`] pò emulà `truncate`, ma face chì l'elementi in eccessu sianu restituiti invece di abbandunassi.
    ///
    ///
    /// Nutate bè chì stu metudu ùn hà alcun effettu nant'à a capacità assignata di u vector.
    ///
    /// # Examples
    ///
    /// Truncendu un vector à cinque elementi in dui elementi:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Nisun truncamentu si face quandu `len` hè più grande chì a lunghezza attuale di u vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Truncà quandu `len == 0` hè equivalente à chjamà u metudu [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Questu hè sicuru perchè:
        //
        // * a fetta passata à `drop_in_place` hè valida;u casu `len > self.len` evita di creà una fetta invalida, è
        // * u `len` di u vector hè diminuitu prima di chjamà `drop_in_place`, tale chì nisun valore serà abbandunatu duie volte in casu chì `drop_in_place` fussi à panic una volta (se panics duie volte, u prugramma interrompe).
        //
        //
        //
        unsafe {
            // Note: Hè intenzionale chì questu sia `>` è micca `>=`.
            //       U cambiamentu in `>=` hà implicazioni negative in e prestazioni in certi casi.
            //       Vede #78884 per più.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Estrae una fetta chì cuntene tuttu u vector.
    ///
    /// Equivalente à `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Estrae una fetta mutabile di tuttu u vector.
    ///
    /// Equivalente à `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Restituisce un puntatore grezzu à u buffer di vector.
    ///
    /// U chjamante deve assicurà chì u vector supera u puntatore chì sta funzione ritorna, altrimenti finirà per indicà a spazzatura.
    /// Mudificà u vector pò fà riallocà u so buffer, ciò chì renderebbe ancu qualsiasi indicatore per ellu invalidu.
    ///
    /// U chjamante deve ancu assicurà chì a memoria chì u puntatore (non-transitively) punta à ùn sia mai scritta (eccettu in un `UnsafeCell`) aduprendu questu puntatore o qualsiasi puntatore derivatu da ellu.
    /// Se avete bisognu di mutà u cuntenutu di a fetta, aduprate [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Avemu l'ombra di u metudu slice di u listessu nome per evità di passà per `deref`, chì crea una riferenza intermedia.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Restituisce un puntatore mutabile periculosu in u buffer di vector.
    ///
    /// U chjamante deve assicurà chì u vector supera u puntatore chì sta funzione ritorna, altrimenti finirà per indicà a spazzatura.
    ///
    /// Mudificà u vector pò fà riallocà u so buffer, ciò chì renderebbe ancu qualsiasi indicatore per ellu invalidu.
    ///
    /// # Examples
    ///
    /// ```
    /// // Assignate vector abbastanza grande per 4 elementi.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Inizializà l'elementi attraversu u puntatore grezzu scrive, poi definite a lunghezza.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Avemu l'ombra di u metudu slice di u listessu nome per evità di passà per `deref_mut`, chì crea una riferenza intermedia.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Restituisce una riferenza à l'allocatore sottostante.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Forza a lunghezza di u vector à `new_len`.
    ///
    /// Questa hè una operazione di livellu bassu chì mantene nisunu di l'invarianti normali di u tippu.
    /// Normalmente cambià a lunghezza di un vector hè fattu cù una di l'operazioni sicure invece, cum'è [`truncate`], [`resize`], [`extend`], o [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` deve esse menu o uguale à [`capacity()`].
    /// - L'elementi in `old_len..new_len` devenu esse inizializzati.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Stu metudu pò esse utile per situazioni in cui u vector serve cum'è un buffer per altri codici, in particulare per FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Questu hè solu un scheletru minimu per l'esempiu doc;
    /// # // ùn aduprate micca questu cume un puntu di partenza per una vera biblioteca.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Per i documenti di u metudu FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SICUREZZA: Quandu `deflateGetDictionary` restituisce `Z_OK`, detiene chì:
    ///     // 1. `dict_length` elementi sò stati inizializati.
    ///     // 2.
    ///     // `dict_length` <=a capacità (32_768) chì face `set_len` sicuru da chjamà.
    ///     unsafe {
    ///         // Fate a chjamata FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... è aghjurnà a lunghezza à ciò chì hè statu inizializatu.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Mentre l'esempiu seguente hè sonu, ci hè una perdita di memoria postu chì i vectors interni ùn sò micca stati liberati prima di a chjamata `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` hè viotu dunque ùn ci vole micca inizializà elementi.
    /// // 2. `0 <= capacity` tene sempre tuttu ciò chì `capacity` hè.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normalmente, quì, si userebbe [`clear`] invece per abbandunà currettamente u cuntenutu è cusì ùn perde micca memoria.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Elimina un elementu da u vector è u restituisce.
    ///
    /// L'elementu eliminatu hè rimpiazzatu da l'ultimu elementu di u vector.
    ///
    /// Questu ùn conserva micca l'ordine, ma hè O(1).
    ///
    /// # Panics
    ///
    /// Panics se `index` hè fora di i limiti.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Rimpiazzemu self [index] cù l'ultimu elementu.
            // Nutate bè chì sì u cuntrollu di i limiti sopra ci riesce deve esse un ultimu elementu (chì pò esse sè stessu [indice]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Inserisce un elementu in a pusizione `index` in u vector, trasfurmendu tutti l'elementi dopu à a diritta.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // spaziu per u novu elementu
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infallibile U spot per mette u novu valore
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Sposta tuttu per fà spaziu.
                // (Duplicendu l'elementu `index`th in dui posti consecutivi.)
                ptr::copy(p, p.offset(1), len - index);
                // Scrivila in, soprascrivendu a prima copia di l'elementu `index`th.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Elimina è rende l'elementu in a pusizione `index` in u vector, trasfurmendu tutti l'elementi dopu à a manca.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `index` hè fora di i limiti.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // u locu da quale pigliemu.
                let ptr = self.as_mut_ptr().add(index);
                // copiatelu, avendu in modu sicuru una copia di u valore nantu à a pila è in u vector in listessu tempu.
                //
                ret = ptr::read(ptr);

                // Sposta tuttu in ghjò per riempie quellu postu.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Conserva solu l'elementi specificati da u predicatu.
    ///
    /// In altre parolle, sguassate tutti l'elementi `e` tali chì `f(&e)` restituisce `false`.
    /// Stu metudu opera in situ, visitendu ogni elementu esattamente una volta in l'ordine originale, è cunserva l'ordine di l'elementi ritenuti.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Perchè l'elementi sò visitati esattamente una volta in l'ordine originale, u statu esternu pò esse adupratu per decide chì elementi mantene.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Evite a doppia goccia se a guardia di goccia ùn hè micca eseguita, postu chì pudemu fà qualchì foru durante u prucessu.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-len trattatu-> |^-accantu à verificà
        //                  | <-cnt eliminatu-> |
        //      | <-original_len-> |Mantenutu: Elementi chì u predicatu ritorna veru.
        //
        // Foru: slot di l'elementu spostatu o abbandunatu.
        // Unchecked: Elementi validi Unchecked.
        //
        // Questa guardia di goccia serà invucata quandu u predicatu o `drop` di l'elementu in panicu.
        // Sposta elementi incontrollati per copre fori è `set_len` à a lunghezza curretta.
        // In i casi quandu u predicatu è `drop` ùn anu mai panicu, serà ottimizatu fora.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SICUREZZA: L'elementi senza marcà di seguitu devenu esse validi postu chì ùn li toccemu mai.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SICUREZZA: Dopu à riempie fori, tutti l'articuli sò in memoria contigua.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SICUREZZA: L'elementu micca marcatu deve esse validu.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Avanzate prestu per evità a doppia goccia se `drop_in_place` hè in panicu.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SICUREZZA: Ùn toccemu mai più questu elementu dopu à a caduta.
                unsafe { ptr::drop_in_place(cur) };
                // Avemu digià avanzatu u cuntatore.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SICUREZZA: `deleted_cnt`> 0, allora u slot di u foru ùn deve micca sovrapposizione cù l'elementu attuale.
                // Adupremu copia per muvimentu, è ùn toccu mai più questu elementu.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Tutti l'articuli sò trattati.Questu pò esse ottimizatu per `set_len` da LLVM.
        drop(g);
    }

    /// Elimina tuttu, ma u primu di l'elementi consecutivi in u vector chì si risolvenu à a stessa chjave.
    ///
    ///
    /// Se u vector hè urdinatu, questu elimina tutti i duplicati.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Elimina tutti, eccettu u primu di l'elementi cunsecutivi in u vector chì soddisfanu una relazione d'ugualità data.
    ///
    /// A funzione `same_bucket` hè trasmessa referenze à dui elementi da u vector è deve determinà se l'elementi paragunanu uguali.
    /// L'elementi sò passati in ordine cuntrariu da u so ordine in a fetta, dunque se `same_bucket(a, b)` restituisce `true`, `a` hè eliminatu.
    ///
    ///
    /// Se u vector hè urdinatu, questu elimina tutti i duplicati.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Aghjusta un elementu à u fondu di una cullizzioni.
    ///
    /// # Panics
    ///
    /// Panics se a nova capacità supera i `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Questu serà panic o abbandunà se assigneremu> isize::MAX byte o se l'incrementu di lunghezza superava per tippi di dimensioni zero.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Elimina l'ultimu elementu da un vector è u restituisce, o [`None`] se hè viotu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Sposta tutti l'elementi di `other` in `Self`, lascendu `other` viotu.
    ///
    /// # Panics
    ///
    /// Panics se u numeru di elementi in u vector suprana un `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Aggiunge elementi à `Self` da un altru buffer.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Crea un iteratore di drenu chì elimina a gamma specificata in u vector è dà l'articuli rimossi.
    ///
    /// Quandu l'iteratore **hè** cacciatu, tutti l'elementi di a gamma sò eliminati da u vector, ancu se l'iteratore ùn hè micca statu cumpletamente cunsumatu.
    /// Se l'iteratore **ùn hè micca** cacciatu (cun [`mem::forget`] per esempiu), ùn hè micca specificatu quanti elementi sò rimossi.
    ///
    /// # Panics
    ///
    /// Panics se u puntu di partenza hè più grande chì u puntu finale o se u puntu finale hè più grande di a lunghezza di u vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Una gamma completa pulisce u vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Sicurezza di memoria
        //
        // Quandu u Drain hè creatu per a prima volta, accurtà a lunghezza di a fonte vector per assicurassi chì nisun elementu iniziale o spostatu ùn sia accessibile in tuttu se u distruttore di Drain ùn riesce mai à corre.
        //
        //
        // Drain farà ptr::read fora i valori da rimuovere.
        // Quandu hè finita, a coda restante di u vec hè copiata torna per copre u foru, è a lunghezza vector hè ripristinata à a nova lunghezza.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // impostate a lunghezza self.vec per cumincià, per esse sicura in casu chì Drain sia fughjitu
            self.set_len(start);
            // Aduprate u prestitu in IterMut per indicà u cumpurtamentu di prestitu di tuttu l'iteratore Drain (cum'è &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Cancella u vector, eliminendu tutti i valori.
    ///
    /// Nutate bè chì stu metudu ùn hà alcun effettu nant'à a capacità assignata di u vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Restituisce u numeru di elementi in u vector, chjamatu ancu u so 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Ritorna `true` se u vector ùn cuntene elementi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Divide a raccolta in dui à l'indice datu.
    ///
    /// Restituisce un vector appena attribuitu chì cuntene l'elementi in a gamma `[at, len)`.
    /// Dopu a chjamata, u vector originale serà lasciatu chì cuntene l'elementi `[0, at)` cù a so capacità precedente senza cambià.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // u novu vector pò ripiglià u buffer originale è evità a copia
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Unsafely `set_len` è cupiate l'articuli in `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Ridimensiona u `Vec` in locu per chì `len` sia uguale à `new_len`.
    ///
    /// Se `new_len` hè più grande chì `len`, u `Vec` hè allargatu da a differenza, cù ogni slot addizionale pienu di u risultatu di chjamà a chiusura `f`.
    ///
    /// I valori di ritornu da `f` finisceranu in u `Vec` in l'ordine ch'elli sò stati generati.
    ///
    /// Se `new_len` hè menu di `len`, u `Vec` hè simplicemente truncatu.
    ///
    /// Stu metudu usa una chjusura per creà novi valori à ogni spinta.Se preferite [`Clone`] un valore datu, aduprate [`Vec::resize`].
    /// Se vulete aduprà [`Default`] trait per generà valori, pudete passà [`Default::default`] cum'è secondu argumentu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Cunsuma è perde u `Vec`, restituendu un riferimentu mutevule à u cuntenutu, `&'a mut [T]`.
    /// Nutate bè chì u tippu `T` deve supravvivere à a vita scelta `'a`.
    /// Se u tippu hà solu riferimenti statichi, o nimu, allora questu pò esse sceltu per esse `'static`.
    ///
    /// Sta funzione hè simile à a funzione [`leak`][Box::leak] in [`Box`] eccettu chì ùn ci hè manera di ricuperà a memoria perduta.
    ///
    ///
    /// Sta funzione hè principalmente utile per i dati chì campanu per u restu di a vita di u prugramma.
    /// A caduta di u riferimentu restituitu causerà una perdita di memoria.
    ///
    /// # Examples
    ///
    /// Usu simplice:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Restituisce a capacità di riserva restante di u vector cum'è una fetta di `MaybeUninit<T>`.
    ///
    /// A fetta restituita pò esse aduprata per riempie u vector di dati (per esempio
    /// lighjendu da un fugliale) prima di marcà i dati cum'è inizializati cù u metudu [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Assignate vector abbastanza grande per 10 elementi.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Inserite i primi 3 elementi.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Marcate i primi 3 elementi di u vector cum'è inizializatu.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Stu metudu ùn hè micca implementatu in termini di `split_at_spare_mut`, per prevene l'invalidazione di i puntatori à u buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Ritorna u cuntenutu vector cum'è una fetta di `T`, cù a capacità di riserva restante di u vector cum'è una fetta di `MaybeUninit<T>`.
    ///
    /// A fetta di capacità di riserva restituita pò esse aduprata per riempie u vector di dati (per esempiu, leggendu da un fugliale) prima di marcà i dati cum'è inizializati cù u metudu [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Nutate bè chì si tratta di una API di livellu bassu, chì deve esse aduprata cun primura per scopi di ottimisazione.
    /// Se avete bisognu di appendà i dati à un `Vec` pudete aduprà [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] o [`resize_with`], secondu i vostri bisogni esatti.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Riservate spaziu supplementu abbastanza grande per 10 elementi.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Inserite i prossimi 4 elementi.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Marcate i 4 elementi di u vector cum'è inizializatu.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len hè ignoratu è cusì ùn hè mai cambiatu
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Sicurezza: cambià .2 restituitu (usu &mut) hè cunsideratu u listessu chè chjamà `.set_len(_)`.
    ///
    /// Stu metudu hè adupratu per avè un accessu unicu à tutte e parti vec in una volta in `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` hè garantitu per esse validu per l'elementi `len`
        // - `spare_ptr` indica un elementu passatu u buffer, dunque ùn si sovrappone micca cù `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Ridimensiona u `Vec` in locu per chì `len` sia uguale à `new_len`.
    ///
    /// Se `new_len` hè più grande chì `len`, u `Vec` hè allargatu da a differenza, cù ogni slot supplementu pienu di `value`.
    ///
    /// Se `new_len` hè menu di `len`, u `Vec` hè simplicemente truncatu.
    ///
    /// Stu metudu richiede `T` per implementà [`Clone`], per pudè clonà u valore passatu.
    /// Se avete bisognu di più flessibilità (o vulete contà nantu à [`Default`] invece di [`Clone`]), aduprate [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clona è aghjusta tutti l'elementi in una fetta à u `Vec`.
    ///
    /// Iterate nantu à a fetta `other`, clone ogni elementu, è dopu l'appende à questu `Vec`.
    /// U `other` vector hè attraversatu in ordine.
    ///
    /// Nutate bè chì sta funzione hè listessa à [`extend`] eccettu chì hè specializata per travaglià invece cù fette.
    ///
    /// Se è quandu Rust ottiene specializazione sta funzione sarà probabilmente obsoleta (ma sempre dispunibile).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Copia elementi da a gamma `src` à a fine di u vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` guarantisci chì a gamma data hè valida per l'indexazione di sè
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Stu codice generalizeghja `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Stende i valori vector da `n`, aduprendu u generatore datu.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Aduprate SetLenOnDrop per travaglià intornu à u bug induve u compilatore ùn pò micca rializà u magazinu per `ptr` à self.set_len() ùn aliasse micca.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Scrivi tutti l'elementi eccettu l'ultimu
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Aumenta a lunghezza in ogni passu in casu next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Pudemu scrive l'ultimu elementu direttamente senza clonà inutile
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len impostatu da guardia di portata
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Elimina elementi ripetuti consecutivi in u vector secondu l'implementazione [`PartialEq`] trait.
    ///
    ///
    /// Se u vector hè urdinatu, questu elimina tutti i duplicati.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Metudi è funzioni interni
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` deve esse un indice validu
    /// - `self.capacity() - self.len()` deve esse `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len hè aumentatu solu dopu l'inizializazione di elementi
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - caller guarantisci chì src hè un indice validu
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - L'elementu hè statu solu inizializatu cù `MaybeUninit::write`, allora hè bè d'incrementà a len
            // - len hè aumentatu dopu ogni elementu per prevene perdite (vede u numeru #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - U chjamante guarantisci chì `src` hè un indice validu
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - I dui indicatori sò creati da referenze di slice uniche (`&mut [_]`) dunque sò validi è ùn si sovrapponu.
            //
            // - L'elementi sò: Copia cusì hè bè di copialli, senza fà nunda cù i valori originali
            // - `count` hè uguale à a len di `source`, dunque a fonte hè valida per leghje `count`
            // - `.reserve(count)` guarantisci chì `spare.len() >= count` cusì riservatu hè validu per `count` scrive
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - L'elementi sò stati inizializzati da `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implementazioni cumuni di trait per Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cù cfg(test) u metudu `[T]::to_vec` inerente, chì hè necessariu per sta definizione di metudu, ùn hè micca dispunibule.
    // Utilizate invece a funzione `slice::to_vec` chì hè dispunibule solu cù cfg(test) NB vedi u modulu slice::hack in slice.rs per più infurmazione
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // lanciate tuttu ciò chì ùn serà micca soprascrittu
        self.truncate(other.len());

        // self.len <= other.len per via di u truncatu sopra, dunque e fette quì sò sempre in limiti.
        //
        let (init, tail) = other.split_at(self.len());

        // riutilizà i valori cuntenuti allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Crea un iteratore cunsumante, vale à dì unu chì move ogni valore fora di u vector (da u principiu à a fine).
    /// U vector ùn pò micca esse adupratu dopu à chjamà questu.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s hà tippu String, micca &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // metudu foglia à quale varie implementazioni SpecFrom/SpecExtend deleganu quandu ùn anu più ottimisazione da applicà
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Hè u casu per un iteratore generale.
        //
        // Sta funzione deve esse l'equivalente morale di:
        //
        //      per l'articulu in iteratore {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB ùn pò micca trabuccà postu chì averiamu avutu da assignà u spaziu di l'indirizzu
                self.set_len(len + 1);
            }
        }
    }

    /// Crea un iteratore di splicing chì sustituisce u intervallu specificatu in u vector cù l'iteratore `replace_with` datu è dà l'articuli rimossi.
    ///
    /// `replace_with` ùn hà micca bisognu di esse listessa lunghezza cum'è `range`.
    ///
    /// `range` hè eliminatu ancu se l'iteratore ùn hè micca cunsumatu finu à a fine.
    ///
    /// Ùn hè micca specificatu quanti elementi sò rimossi da u vector se u valore `Splice` hè filtratu.
    ///
    /// L'iteratore d'ingressu `replace_with` hè cunsumatu solu quandu u valore `Splice` hè abbandunatu.
    ///
    /// Questu hè ottimali se:
    ///
    /// * A coda (elementi in u vector dopu `range`) hè viota,
    /// * o `replace_with` rende menu elementi o uguali di a lunghezza di "range"
    /// * o u limitu inferiore di u so `size_hint()` hè esattu.
    ///
    /// Altrimenti, un vector temporaneu hè attribuitu è a coda hè sposta duie volte.
    ///
    /// # Panics
    ///
    /// Panics se u puntu di partenza hè più grande chì u puntu finale o se u puntu finale hè più grande di a lunghezza di u vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Crea un iteratore chì utilizza una chjusura per determinà se un elementu deve esse eliminatu.
    ///
    /// Se a chjusura torna vera, allora l'elementu hè eliminatu è cedutu.
    /// Se a chjusura torna falsa, l'elementu fermerà in u vector è ùn serà micca cedutu da l'iteratore.
    ///
    /// Aduprà stu metudu hè equivalente à u codice seguente:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // u vostru còdice quì
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Ma `drain_filter` hè più faciule da aduprà.
    /// `drain_filter` hè ancu più efficiente, perchè pò spostà in retroazione l'elementi di u array in massa.
    ///
    /// Notate chì `drain_filter` permette ancu di mutà ogni elementu in a chiusura di u filtru, indipendentemente da se sceglite di mantene o rimuovere.
    ///
    ///
    /// # Examples
    ///
    /// Spartendu una matrice in pari è probabilità, riutilizendu l'allocazione originale:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Pruteggevi contra noi chì si perdenu (amplificazione di fughe)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Allargate l'implementazione chì copia elementi fora di riferimenti prima di spinghje li nantu à u Vec.
///
/// Questa implementazione hè specializata per l'iteratori di slice, induve utilizza [`copy_from_slice`] per appendà tutta a fetta in una volta.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Implementa u paragone di vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Implementa l'ordine di vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // aduprate drop per [T] aduprate una fetta cruda per riferisce à l'elementi di u vector cum'è u tipu più debule necessariu;
            //
            // puderia evità e dumande di validità in certi casi
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec gestisce a deallocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Crea un `Vec<T>` vacante.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test pulls in libstd, chì provoca errori quì
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test pulls in libstd, chì provoca errori quì
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Ottiene u cuntenutu sanu sanu di u `Vec<T>` cum'è una matrice, se a so dimensione currisponde esattamente à quella di a matrice richiesta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Se a lunghezza ùn currisponde micca, l'entrata torna in `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Sè site bè cù solu avè un prefissu di u `Vec<T>`, pudete chjamà [`.truncate(N)`](Vec::truncate) prima.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SICUREZZA: `.set_len(0)` hè sempre sanu.
        unsafe { vec.set_len(0) };

        // SICUREZZA: Un puntatore di `Vec` hè sempre alliniatu currettamente, è
        // l'allinjamentu chì l'array hà bisognu hè listessu cù l'articuli.
        // Avemu verificatu prima chì avemu abbastanza elementi.
        // L'articuli ùn saranu micca duppiati quandu u `set_len` dice à u `Vec` di ùn lascià ancu elli.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}