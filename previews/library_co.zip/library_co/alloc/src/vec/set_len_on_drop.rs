// Impostate a lunghezza di u vec quandu u valore `SetLenOnDrop` esce da u scopu.
//
// L'idea hè: U campu di lunghezza in SetLenOnDrop hè una variabile lucale chì l'ottimisatore vedrà ùn aliasse micca cù alcun magazzinu attraversu u puntatore di dati di Vec.
// Questa hè una soluzione per l'analisi di alias #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}