use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specializazione trait aduprata per Vec::from_iter
///
/// ## U graficu di delegazione:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Un casu cumunu hè passà un vector in una funzione chì immediatamente torna à raccoglie in un vector.
        // Pudemu cortu circuitu questu se l'IntoIter ùn hè micca statu avanzatu affattu.
        // Quandu hè stata avanzata Pudemu ancu riutilizà a memoria è spustà i dati in fronte.
        // Ma femu solu quandu u Vec resultante ùn averia micca più capacità inutilizata di a creazione cù l'implementazione generica FromIterator.
        //
        // Questa limitazione ùn hè micca strettamente necessaria in quantu u comportamentu di attribuzione di Vec hè intenzionalmente micca specificatu.
        // Ma hè una scelta cunservatrice.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // deve delegà à spec_extend() postu chì extend() stessu delega à spec_from per Vecs vioti
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Questu utilizza `iterator.as_slice().to_vec()` postu chì spec_extend deve piglià più passi per ragiunà nantu à a capacità finale + lunghezza è cusì fà più travagliu.
// `to_vec()` attribuisce direttamente a quantità curretta è u riempie esattamente.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cù cfg(test) u metudu `[T]::to_vec` inerente, chì hè necessariu per sta definizione di metudu, ùn hè micca dispunibule.
    // Utilizate invece a funzione `slice::to_vec` chì hè dispunibule solu cù cfg(test) NB vedi u modulu slice::hack in slice.rs per più infurmazione
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}