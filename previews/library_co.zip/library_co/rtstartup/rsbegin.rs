// rsbegin.o è rsend.o sò i cusì chjamati "compiler runtime startup objects".
// Contenenu u codice necessariu per inizializà currettamente u runtime di u compilatore.
//
// Quandu una stampa eseguibile o dylib hè ligata, tutti i codici d'utilizatori è e bibliuteche sò "sandwiched" trà sti dui fugliali di ughjettu, cusì u codice o dati da rsbegin.o diventanu primi in e sezioni rispettivi di l'immagine, mentre chì u codice è i dati da rsend.o diventanu l'ultimi.
// Questu effettu pò esse adupratu per piazzà simboli à l'iniziu o à a fine di una sezione, è ancu per inserisce tutte e intestazioni o piè di pagina richiesti.
//
// Nutate bè chì u puntu d'ingressu di u modulu propiu si trova in l'ughjettu di avviu di runtime C (di solitu chjamatu `crtX.o`), chì invoca poi richiamate di inizializazione di altri cumpunenti di runtime (arregistrati via ancu un'altra sezzione d'imagine speciale).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Marca l'iniziu di u quadru di pila rilassate a sezione d'infurmazione
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Scratch space per a libreria interna di u svolgitore.
    // Questu hè definitu cum'è `struct object` in $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Rilassate e rutine di l'infurmazioni registration/deregistration.
    // Vede i documenti di libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // arregistrà si sviloppu l'infurmazioni à l'iniziu di u modulu
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // annullà a registrazione à l'arrestu
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Registrazione di routine init/uninit specifica MinGW
    pub mod mingw_init {
        // L'uggetti di startup di MinGW (crt0.o/dllcrt0.o) invuceranu costruttori globali in e sezioni .ctors è .dtors à l'iniziu è à a surtita.
        // In u casu di DLL, questu hè fattu quandu a DLL hè caricata è scaricata.
        //
        // U ligame sorte i sezzioni, chì assicura chì i nostri callbacks sò situati à a fine di a lista.
        // Siccomu i costruttori sò gestiti in ordine inversu, questu assicura chì i nostri callbacks sò i primi è l'ultimi eseguiti.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C callbacks d'inizializazione C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C callbacks di terminazione C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}