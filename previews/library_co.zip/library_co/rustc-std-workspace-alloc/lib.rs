#![feature(no_core)]
#![no_core]

// Vede rustc-std-workspace-core per quessa chì questu crate hè necessariu.

// Rinominate u crate per evità di cunflitti cù u modulu alloc in liballoc.
extern crate alloc as foo;

pub use foo::*;