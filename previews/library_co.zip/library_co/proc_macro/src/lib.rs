//! Una libreria di supportu per l'autori di macro quandu definisce novi macros.
//!
//! Questa libreria, furnita da a distribuzione standard, furnisce i tippi cunsumati in l'interfacce di definizioni macro definite in modu processuale cum'è macros funziunali `#[proc_macro]`, attributi macro `#[proc_macro_attribute]` è persunalizati derivanu attributi "#[proc_macro_derive]".
//!
//!
//! Vede [the book] per più.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Determina se proc_macro hè statu resu accessibile à u prugramma in esecuzione.
///
/// U proc_macro crate hè destinatu solu per l'usu in l'implementazione di macros procedurali.Tutte e funzioni in questu crate panic se invucatu da fora di una macro procedurale, cume da un script di custru o test di unità o binariu ordinariu Rust.
///
/// In cunsiderazione per e biblioteche Rust chì sò pensate per supportà casi d'usu macro è non macro, `proc_macro::is_available()` furnisce un modu senza panicu per rilevà se l'infrastruttura necessaria per aduprà l'API di proc_macro hè attualmente disponibile.
/// Restituisce veru se invucatu da l'internu di una macro procedurale, falsu se invucatu da qualsiasi altru binariu.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// U tippu principale furnitu da questu crate, chì rapprisenta un flussu astrattu di tokens, o, più specificamente, una sequenza di alberi token.
/// U tippu furnisce interfacce per iterà nantu à quessi arburi token è, à u cuntrariu, raccoglie un numeru di alberi token in un flussu.
///
///
/// Questu hè à tempu l'input è l'output di e definizioni `#[proc_macro]`, `#[proc_macro_attribute]` è `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Errore riturnatu da `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Restituisce un `TokenStream` vacante chì ùn cuntene micca arburi token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Verifica se stu `TokenStream` hè viotu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Tentativi di rompe a stringa in tokens è analizza quelli tokens in un flussu token.
/// Pò fiascà per parechje ragioni, per esempiu, se a stringa cuntene delimitatori sbilanciati o caratteri chì ùn esistenu micca in a lingua.
///
/// Tutti i tokens in u flussu analizatu uttenenu spazii `Span::call_site()`.
///
/// NOTE: alcuni errori ponu causà panics invece di restituisce `LexError`.Riservemu u dirittu di cambià questi errori in `LexError`s più tardi.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, u ponte furnisce solu `to_string`, implementa `fmt::Display` basatu annantu à questu (u reversu di a relazione abituale trà i dui).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Stampa u flussu token cum'è una stringa chì si suppone esse convertibile senza perdita in u stessu flussu token (spazi modulo), eccettu possibbilmente `TokenTree: : Group`s cù delimitatori `Delimiter::None` è letterali numerichi negativi.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Stampa token in una forma cunveniente per u debugging.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Crea un flussu token chì cuntene un unicu arburu token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Coglie un numeru di arburi token in un unicu flussu.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Una operazione "flattening" nantu à i flussi token, raccoglie l'arburi token da più flussi token in un unicu flussu.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Aduprate una implementazione ottimizzata if/when pussibule.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Dettagli di implementazione pubblica per u tippu `TokenStream`, cume l'iteratori.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Un iteratore nantu à `TokenTree` di`TokenStream`.
    /// L'iterazione hè "shallow", per esempiu, l'iteratore ùn ricorre micca in gruppi delimitati, è restituisce gruppi sani cum'è arburi token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` accetta tokens arbitrariu è si espande in un `TokenStream` chì descrive l'input.
/// Per esempiu, `quote!(a + b)` produrrà una spressione, chì, quandu hè valutata, custruisce `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting hè fattu cù `$`, è funziona pigliendu a sola identità successiva cum'è u termine micca citatu.
/// Per cita `$` stessu, aduprate `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Una regione di codice surghjente, cù l'infurmazioni di macro espansione.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Crea un novu `Diagnostic` cù u `message` datu à u span `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Una span chì si risolve in u situ di definizione macro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// A durata di l'invucazione di a macro procedurale attuale.
    /// L'identificatori creati cù questu spanu seranu risolti cum'è s'elli fussinu stati scritti direttamente in u locu di macro chiamata (igiene di u situ di chjamata) è altri codici in u situ di macro chiamata puderanu riferirli ancu.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Un span chì rapprisenta l'igiene `macro_rules`, è qualchì volta si risolve in u situ di macro definizione (variabili lucali, etichette, `$crate`) è à volte in u situ di macro chiamata (tuttu u restu).
    ///
    /// U situ di span hè presu da u situ di chjamata.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// U fugliale uriginale uriginale in quale sta span span
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// U `Span` per u tokens in a precedente espansione macro da a quale `self` hè stata generata, se esiste.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// U span per u codice fonte d'urigine da quale `self` hè statu generatu.
    /// Se questu `Span` ùn hè micca statu generatu da altre espansioni macro allora u valore di ritornu hè u listessu cum'è `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Ottiene u line/column iniziale in u fugliale surghjente per questa span.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Ottiene a fine line/column in u fugliale surghjente per questa span.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Crea un novu span chì abbraccia `self` è `other`.
    ///
    /// Ritorna `None` se `self` è `other` sò di fugliale differenti.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Crea un novu span cù a stessa infurmazione line/column cum'è `self` ma chì risolve i simboli cum'è s'ellu fussi in `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Crea un novu span cù u cumpurtamentu di risoluzione di u listessu nome cum'è `self` ma cù l'infurmazioni line/column di `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Si compara à i campi per vede s'elli sò uguali.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Restituisce u testu uriginale daretu à un span.
    /// Questu cunserva u còdice uriginale originale, cumprese spazi è cumenti.
    /// Ritorna solu un risultatu se u span currisponde à u veru còdice surghjente.
    ///
    /// Note: U risultatu osservabile di una macro si deve basà solu nantu à u tokens è micca nant'à stu testu fonte.
    ///
    /// U risultatu di sta funzione hè u megliu sforzu da aduprà solu per diagnostichi.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Stampa una span in una forma cunveniente per u debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Una coppia linea-colonna chì riprisenta l'iniziu o a fine di un `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// A linea 1-indiziata in u fugliale surghjente nantu à quale u span principia o finisce (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// A colonna 0-indiziata (in caratteri UTF-8) in u fugliale surghjente induve u span principia o finisce (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// U fugliale surghjente di un `Span` datu.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Ottiene u percorsu di stu fugliale fonte.
    ///
    /// ### Note
    /// Se u span di codice assuciatu à questu `SourceFile` hè statu generatu da una macro esterna, questa macro, questu ùn pò micca esse un percorsu propiu in u sistema di file.
    /// Aduprate [`is_real`] per verificà.
    ///
    /// Innota ancu chì ancu se `is_real` restituisce `true`, se `--remap-path-prefix` hè statu passatu nantu à a linea di cummanda, u percorsu cum'è datu pò micca esse veramente validu.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Restituisce `true` se stu schedariu surghjente hè un veru fugliale surghjente, è micca generatu da una espansione di una macro esterna.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Questu hè un pirate finu à chì i intervalli intercrate sò implementati è pudemu avè veri fugliali surghjenti per i spans generati in macros esterni.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Una sola token o una sequenza delimitata di l'arburi token (per esempiu, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Un flussu token circundatu da delimitatori di staffe.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Un identificatore.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Un caratteru di puntuazione unicu (`+`, `,`, `$`, ecc.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Un caratteru litterale (`'a'`), string (`"hello"`), numeru (`2.3`), ecc.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Restituisce u spanu di questu arburu, delegendu à u metudu `span` di u token cuntenutu o un flussu delimitatu.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Configura u spanu per *solu questu token*.
    ///
    /// Innota chì se questu token hè un `Group` allora stu metudu ùn configurerà micca u span di ognunu di i tokens interni, questu solu delegherà à u metudu `set_span` di ogni variante.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Stampa l'arburu token in una forma cunveniente per u debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ognunu di questi hà u nome in u tippu struct in u debug derivatu, allora ùn vi preoccupate micca di un stratu extra di indirezione
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, u ponte furnisce solu `to_string`, implementa `fmt::Display` basatu annantu à questu (u reversu di a relazione abituale trà i dui).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Stampa l'arburu token cum'è una stringa chì si suppone di esse convertibile senza perdita in u listessu albero token (spazi modulo), eccettu possibbilmente `TokenTree: : Group`s cù delimitatori `Delimiter::None` è letterali numerichi negativi.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Un flussu token delimitatu.
///
/// Un `Group` cuntene internamente un `TokenStream` chì hè circundatu da `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Descrive cume una sequenza di alberi token hè delimitata.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Un delimitatore implicitu, chì pò, per esempiu, apparisce intornu à tokens chì vene da un "macro variable" `$var`.
    /// Hè impurtante di priservà e priorità di l'operatore in casi cum'è `$var * 3` induve `$var` hè `1 + 2`.
    /// I delimitatori impliciti ùn puderanu micca sopravvivere à u ritornu di un flussu token attraversu una stringa.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Crea un novu `Group` cù u delimitatore datu è u flussu token.
    ///
    /// Questu costruttore stabilirà a span per stu gruppu à `Span::call_site()`.
    /// Per cambià a span pudete aduprà u metudu `set_span` sottu.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Restituisce u delimitatore di questu `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Restituisce u `TokenStream` di tokens chì sò delimitati in questu `Group`.
    ///
    /// Innota chì u flussu token restituitu ùn include micca u delimitatore restituitu sopra.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Restituisce u spanu per i delimitatori di stu flussu token, chì si estende per tuttu u `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Restituisce u span chì punta à u delimitatore d'apertura di stu gruppu.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Restituisce u span chì punta à u delimitatore di chiusura di stu gruppu.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Configura u spanu per i delimitatori di questu "Gruppu", ma micca u so tokens internu.
    ///
    /// Stu metudu **ùn** micca stabilitu a durata di tutti i tokens interni spannati da stu gruppu, ma piuttostu stabilisce solu a span di u delimitatore tokens à u livellu di u `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, u ponte furnisce solu `to_string`, implementa `fmt::Display` basatu annantu à questu (u reversu di a relazione abituale trà i dui).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Stampa u gruppu cum'è una stringa chì duveria esse convertibile senza perdita in u stessu gruppu (spazi modulo), eccettu possibbilmente `TokenTree: : Group`s cù delimitatori `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Un `Punct` hè un caratteru di puntuazione unicu cum'è `+`, `-` o `#`.
///
/// L'operatori multi-caratteri cum'è `+=` sò rapprisentati cum'è duie istanze di `Punct` cù diverse forme di `Spacing` restituite.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Ch'ella sia un `Punct` seguitatu immediatamente da un altru `Punct` o seguitatu da un altru token o un spaziu biancu.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// per esempiu, `+` hè `Alone` in `+ =`, `+ident` o `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// per esempiu, `+` hè `Joint` in `+=` o `'#`.
    /// Inoltre, una sola citazione `'` pò unisce cun identificatori per formà a vita `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Crea un novu `Punct` da u caratteru datu è u spaziu.
    /// L'argumentu `ch` deve esse un caratteru di puntuazione validu permessu da a lingua, altrimenti a funzione serà panic.
    ///
    /// U `Punct` restituitu averà u span predefinitu di `Span::call_site()` chì pò esse cunfiguratu in più cù u metudu `set_span` sottu.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Restituisce u valore di stu caratteru di puntuazione cum'è `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Restituisce a spaziatura di stu caratteru di puntuazione, indicendu s'ellu hè immediatamente seguitu da un altru `Punct` in u flussu token, cusì ponu esse cumminati potenzialmente in un operatore multi-caratteru (`Joint`), o hè seguitatu da qualchì altru token o spaziu biancu (`Alone`) cusì l'operatore hà certamente finita.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Restituisce u spanu per stu caratteru di puntuazione.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configurate u spanu per questu caratteru di puntuazione.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, u ponte furnisce solu `to_string`, implementa `fmt::Display` basatu annantu à questu (u reversu di a relazione abituale trà i dui).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Stampa u caratteru di puntuazione cum'è una stringa chì deve esse convertibile senza perdita in u stessu caratteru.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Un identificatore (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Crea un novu `Ident` cù u `string` datu è ancu u `span` specificatu.
    /// L'argumentu `string` deve esse un identificatore validu permessu da a lingua (cumprese parolle chjave, per esempiu `self` o `fn`).Inutili, a funzione serà panic.
    ///
    /// Nota chì `span`, attualmente in rustc, configura l'infurmazioni d'igiene per questu identificatore.
    ///
    /// À partesi di questu tempu `Span::call_site()` opta esplicitamente per l'igiene "call-site" chì significa chì l'identificatori creati cù questa span seranu risolti cum'è s'elli fussinu stati scritti direttamente in u locu di a macro chiamata, è altri codici in u situ di macro chiamata puderanu riferisce à elli dinò.
    ///
    ///
    /// I periodi successivi cum'è `Span::def_site()` permetteranu di opt-in à l'igiene "definition-site" chì significa chì l'identificatori creati cù questu spaziu seranu risolti in u locu di a definizione macro è l'altru codice in u situ di macro chiamata ùn puderanu micca riferisce à elli.
    ///
    /// A causa di l'importanza attuale di l'igiene stu costruttore, à u cuntrariu di l'altri tokens, richiede un `Span` per esse specificatu à a custruzzione.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Listessu chè `Ident::new`, ma crea un identificatore crudu (`r#ident`).
    /// L'argumentu `string` sia un identificatore validu permessu da a lingua (cumprese parolle chjave, per esempiu `fn`).
    /// Parolle chjave chì ponu esse aduprate in segmenti di percorsu (es
    /// `self`, "super") ùn sò micca supportati, è causeranu un panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Restituisce u spanu di questu `Ident`, cumprendi l'intera stringa restituita da [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configura a portata di stu `Ident`, cambendu possibilmente u so cuntestu igienicu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, u ponte furnisce solu `to_string`, implementa `fmt::Display` basatu annantu à questu (u reversu di a relazione abituale trà i dui).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Stampa l'identificatore cum'è una stringa chì deve esse convertibile senza perdita in u listessu identificatore.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Una stringa litterale (`"hello"`), stringa byte (`b"hello"`), caratteru (`'a'`), caratteru byte (`b'a'`), un numeru interu o numeru virgulatu cù o senza suffissu (`1 ', `1u8`, `2.3`, `2.3f32`).
///
/// I letterali booleani cum'è `true` è `false` ùn appartenenu micca quì, sò `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Crea un novu numeru interu suffissu cù u valore specificatu.
        ///
        /// Questa funzione creerà un numeru numericu cum'è `1u32` induve u valore interu specificatu hè a prima parte di u token è l'integrale hè ancu suffissu à a fine.
        /// I litturali creati da numeri negativi ùn ponu micca sopravvive à i viaghji intornu per `TokenStream` o stringhe è ponu esse spartuti in dui tokens (`-` è letterale pusitivu).
        ///
        ///
        /// I litturali creati per questu metudu anu u span `Span::call_site()` per difettu, chì pò esse cunfiguratu cù u metudu `set_span` sottu.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Crea un novu numeru interu micca suffissu cù u valore specificatu.
        ///
        /// Questa funzione creerà un numeru interu cum'è `1` induve u valore interu specificatu hè a prima parte di u token.
        /// Nisun suffissu hè specificatu annantu à stu token, vale à dì chì invucazioni cum'è `Literal::i8_unsuffixed(1)` sò equivalenti à `Literal::u32_unsuffixed(1)`.
        /// I litturali creati da numeri negativi ùn ponu micca sopravvive à rountrips attraversu `TokenStream` o stringhe è ponu esse spartuti in dui tokens (`-` è letterale pusitivu).
        ///
        ///
        /// I litturali creati per questu metudu anu u span `Span::call_site()` per difettu, chì pò esse cunfiguratu cù u metudu `set_span` sottu.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Crea un novu littérale in virgule flottante senza suffissi.
    ///
    /// Stu costruttore hè simile à quelli cum'è `Literal::i8_unsuffixed` induve u valore di u float hè emessu direttamente in u token ma nisun suffissu hè adupratu, allora pò esse inferitu per esse un `f64` più tardi in u compilatore.
    ///
    /// I litturali creati da numeri negativi ùn ponu micca sopravvive à rountrips attraversu `TokenStream` o stringhe è ponu esse spartuti in dui tokens (`-` è letterale pusitivu).
    ///
    /// # Panics
    ///
    /// Sta funzione richiede chì u float specificatu sia finitu, per esempiu s'ellu hè infinitu o NaN sta funzione serà panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Crea un novu literale in virgola flottante suffissata.
    ///
    /// Stu costruttore creerà un letterale cum'è `1.0f32` induve u valore specificatu hè a parte precedente di u token è `f32` hè u suffissu di u token.
    /// Questu token serà sempre inferitu per esse un `f32` in u compilatore.
    /// I litturali creati da numeri negativi ùn ponu micca sopravvive à rountrips attraversu `TokenStream` o stringhe è ponu esse spartuti in dui tokens (`-` è letterale pusitivu).
    ///
    ///
    /// # Panics
    ///
    /// Sta funzione richiede chì u float specificatu sia finitu, per esempiu s'ellu hè infinitu o NaN sta funzione serà panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Crea un novu littérale in virgule flottante senza suffissi.
    ///
    /// Stu costruttore hè simile à quelli cum'è `Literal::i8_unsuffixed` induve u valore di u float hè emessu direttamente in u token ma nisun suffissu hè adupratu, allora pò esse inferitu per esse un `f64` più tardi in u compilatore.
    ///
    /// I litturali creati da numeri negativi ùn ponu micca sopravvive à rountrips attraversu `TokenStream` o stringhe è ponu esse spartuti in dui tokens (`-` è letterale pusitivu).
    ///
    /// # Panics
    ///
    /// Sta funzione richiede chì u float specificatu sia finitu, per esempiu s'ellu hè infinitu o NaN sta funzione serà panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Crea un novu literale in virgola flottante suffissata.
    ///
    /// Stu costruttore creerà un letterale cum'è `1.0f64` induve u valore specificatu hè a parte precedente di u token è `f64` hè u suffissu di u token.
    /// Questu token serà sempre inferitu per esse un `f64` in u compilatore.
    /// I litturali creati da numeri negativi ùn ponu micca sopravvive à rountrips attraversu `TokenStream` o stringhe è ponu esse spartuti in dui tokens (`-` è letterale pusitivu).
    ///
    ///
    /// # Panics
    ///
    /// Sta funzione richiede chì u float specificatu sia finitu, per esempiu s'ellu hè infinitu o NaN sta funzione serà panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Caratteru literale.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte string litterale.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Restituisce u span chì abbraccia questu letterale.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configura u span assuciatu per questu literale.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Restituisce un `Span` chì hè un sottogruppu di `self.span()` chì cuntene solu i bytes surghjenti in u intervallu `range`.
    /// Restituisce `None` se u vulume-trimmed span hè fora di i limiti di `self`.
    ///
    // FIXME(SergioBenitez): verificate chì a gamma di byte principia è finisce à un limite UTF-8 di a surghjente.
    // altrimenti, hè prubabile chì un panic accadrà in altrò quandu u testu uriginale hè stampatu.
    // FIXME(SergioBenitez): ùn ci hè manera per l'utilizatore di sapè à chì `self.span()` mappa in realtà, dunque stu metudu attualmente pò esse chjamatu solu à a ceca.
    // Per esempiu, `to_string()` per u caratteru 'c' restituisce "'\u{63}'";ùn ci hè manera per l'utilizatore di sapè se u testu uriginale era 'c' o s'ellu era '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) qualcosa di simile à `Option::cloned`, ma per `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, u ponte furnisce solu `to_string`, implementa `fmt::Display` basatu annantu à questu (u reversu di a relazione abituale trà i dui).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Stampa u literale cum'è una stringa chì deve esse convertibile senza perdita in u listessu letterale (eccettu per un arrotondamentu pussibule per i letterali in virgola mobile).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Accessu tracciatu à e variabili di l'ambiente.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Recupera una variabile d'ambiente è aghjunghje per custruisce informazioni di dipendenza.
    /// U sistema di compilazione chì esegue u compilatore saperà chì a variabile hè stata accessu durante a compilazione, è serà capace di ripruduce a compilazione quandu u valore di quella variabile cambia.
    ///
    /// Oltre à a traccia di dipendenza sta funzione deve esse equivalente à `env::var` da a libreria standard, eccettu chì l'argumentu deve esse UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}