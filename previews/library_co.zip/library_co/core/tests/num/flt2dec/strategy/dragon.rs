use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri hè troppu lentu
fn exact_sanity_test() {
    // Questa prova finisce per esecutà ciò chì possu solu suppone chì sia qualchì casu angulare di a funzione di libreria `exp2`, definita in qualunque runtime C chì usemu.
    // In VS 2013 sta funzione apparentemente hà avutu un bug chì sta prova fiasca quandu hè ligata, ma cù VS 2015 u bug sembra risoltu postu chì u test funziona bè.
    //
    // U bug pare esse una differenza in u valore di ritornu di `exp2(-1057)`, induve in VS 2013 restituisce un doppiu cù u schema di bit 0x2 è in VS 2015 restituisce 0x20000.
    //
    //
    // Per avà solu ignora stu test interamente in MSVC cume hè testatu in altrò in ogni casu è ùn simu micca super interessati à pruvà l'implementazione exp2 di ogni piattaforma.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}