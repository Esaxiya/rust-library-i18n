use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Questa ùn hè micca una superficia stabile, ma aiuta à mantene `?` à bon pattu trà elli, ancu se LLVM ùn pò micca sempre prufittà di questu ora.
    //
    // (Purtroppu Risultatu è Opzione sò incoerenti, allora ControlFlow ùn pò micca currisponde à entrambi.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}