use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Mentre questa funzione hè aduprata in un locu è a so implementazione puderia esse inline, i tentativi precedenti di fà cusì rustc più lente:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Disposizione di un bloccu di memoria.
///
/// Un esempiu di `Layout` descrive un schema particulare di memoria.
/// Custruite un `Layout` cum'è input per dà à un allocatore.
///
/// Tutti i schemi anu una dimensione assuciata è un allinamentu di potenza di dui.
///
/// (Notate chì i layout ùn sò * ** necessarii per avè una dimensione diversa da zero, ancu se `GlobalAlloc` richiede chì tutte e richieste di memoria sianu diverse da zero.
/// Un chjamante deve o assicurà chì e cundizioni cum'è questu sò soddisfatte, aduprà allocatori specifici cun esigenze più libere, o aduprà l'interfaccia `Allocator` più indulgente.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // dimensione di u bloccu di memoria dumandatu, misurata in bytes.
    size_: usize,

    // alineamentu di u bloccu di memoria dumandatu, misuratu in bytes.
    // assicuremu chì questu sia sempre un putere di dui, perchè l'API cum'è `posix_memalign` ne richiedenu è hè una restrizione ragionevule da impone à i costruttori di Layout.
    //
    //
    // (Tuttavia, ùn avemu micca bisognu analogicu `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Custruisce un `Layout` da un determinatu `size` è `align`, o restituisce `LayoutError` se una di e cundizioni seguenti ùn hè micca soddisfatta:
    ///
    /// * `align` ùn deve esse nulu,
    ///
    /// * `align` deve esse una putenza di dui,
    ///
    /// * `size`, quandu hè arrotondatu à u multiplu più vicinu di `align`, ùn deve micca trabuccà (vale à dì, u valore arrotondatu deve esse inferiore o uguale a `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (putenza di dui implica allinamentu!=0.)

        // A dimensione arrotondata hè:
        //   size_rounded_up=(taglia + align, 1)&! (align, 1);
        //
        // Sapemu da sopra quellu align!=0.
        // Se aghjunghjendu (align, 1) ùn trabocca, allora l'arrotondamentu sarà bè.
        //
        // À u cuntrariu,&-masking with! (Align, 1) resterà solu i bit di bassu ordine.
        // Cusì se u overflow si verifica cù a somma, a&-mask ùn pò micca sottrae abbastanza per annullà quellu overflow.
        //
        //
        // Quì sopra implica chì verificà per u cumbugliu di summation hè à tempu necessariu è sufficiente.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SICUREZZA: e cundizioni per `from_size_align_unchecked` sò state
        // verificatu sopra.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Crea un schema, saltendu tutti i cuntrolli.
    ///
    /// # Safety
    ///
    /// Sta funzione ùn hè micca sicura perchè ùn verifica micca e precondizioni da [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SEGURITÀ: u chjamante deve assicurà chì `align` sia più grande chè zeru.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// A dimensione minima in bytes per un bloccu di memoria di questu layout.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// L'allineamentu minimu di byte per un bloccu di memoria di questu layout.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Custruisce un `Layout` adattu per tene un valore di tippu `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SICUREZZA: l'allinamentu hè garantitu da Rust per esse una putenza di dui è
        // u combo size + align hè garantitu per adattassi in u nostru spaziu di indirizzu.
        // Di conseguenza aduprate quì u costruttore senza marcatura per evità di inserisce codice chì panics se ùn hè micca ottimizatu abbastanza bè.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produce un layout chì descrive un registru chì puderia esse adupratu per attribuisce a struttura di supportu per `T` (chì puderia esse un trait o un altru tipu micca dimensionatu cum'è una fetta).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SICUREZZA: vede u fundamentu in `new` per quessa hè aduprendu a variante micca sicura
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produce un layout chì descrive un registru chì puderia esse adupratu per attribuisce a struttura di supportu per `T` (chì puderia esse un trait o un altru tipu micca dimensionatu cum'è una fetta).
    ///
    /// # Safety
    ///
    /// Questa funzione hè sicura da chjamà solu se e seguenti condizioni valenu:
    ///
    /// - Se `T` hè `Sized`, sta funzione hè sempre sicura di chjamà.
    /// - Se a coda senza dimensioni di `T` hè:
    ///     - un [slice], allora a lunghezza di a coda di fetta deve esse un interu intializatu, è a dimensione di u *valore interu*(lunghezza di coda dinamica + prefissu di dimensione statica) deve adattassi in `isize`.
    ///     - un [trait object], allora a parte vtable di u puntatore deve puntà à una vtable valida per u tippu `T` acquistata da una coersione di dimensione, è a dimensione di u *valore interu*(lunghezza di coda dinamica + prefissu di dimensione statica) deve adattassi in `isize`.
    ///
    ///     - un (unstable) [extern type], allora sta funzione hè sempre sicura da chjamà, ma pò panic o altrimente restituisce u valore sbagliatu, postu chì u layout di u tippu esternu ùn hè micca cunnisciutu.
    ///     Questu hè u listessu comportamentu cum'è [`Layout::for_value`] per una riferenza à una coda di tippu esternu.
    ///     - altrimenti, hè cunservativu micca permessu di chjamà sta funzione.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SICUREZZA: passemu longu i prerequisiti di ste funzioni à u chjamante
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SICUREZZA: vede u fundamentu in `new` per quessa hè aduprendu a variante micca sicura
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Crea un `NonNull` chì pende, ma ben alliniatu per questu Layout.
    ///
    /// Da nutà chì u valore di u puntatore pò raprisentà potenzialmente un puntatore validu, ciò chì significa chì questu ùn deve esse adupratu cum'è valore di sentinella "not yet initialized".
    /// Tipi chì pigghiamente allocanu devenu tracciare l'inizializazione per qualchì altru mezu.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SICUREZZA: align hè garantitu chì ùn sia micca zero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Crea un layout chì descrive u record chì pò tene un valore di u listessu layout cum'è `self`, ma chì hè ancu alliniatu à l'allineamentu `align` (misuratu in byte).
    ///
    ///
    /// Se `self` risponde digià à l'allineamentu prescrittu, allora ritorna `self`.
    ///
    /// Nutate bè chì stu metudu ùn aghjusta alcun imbottitura à a dimensione generale, indipendentemente da sì u layout riturnatu abbia un allineamentu diversu.
    /// In altre parolle, se `K` hà a taglia 16, `K.align_to(32)` hà *sempre* a taglia 16.
    ///
    /// Restituisce un errore se a cumminazione di `self.size()` è u `align` datu viola e cundizioni elencate in [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Restituisce a quantità di padding chì duvemu inserisce dopu `self` per assicurà chì l'indirizzu seguente soddisfatti `align` (misuratu in bytes).
    ///
    /// per esempiu, se `self.size()` hè 9, allora `self.padding_needed_for(4)` restituisce 3, perchè hè u numeru minimu di byte di padding necessariu per uttene un indirizzu 4-alliniatu (supponendu chì u bloccu di memoria currispundente principia à un indirizzu 4-aligned).
    ///
    ///
    /// U valore di ritornu di sta funzione ùn hà significatu se `align` ùn hè micca una putenza di dui.
    ///
    /// Innota chì l'utilità di u valore restituitu richiede chì `align` sia inferiore o uguale a l'allineamentu di l'indirizzu iniziale per tuttu u bloccu assignatu di memoria.Un modu per suddisfà sta limitazione hè di assicurà `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // U valore arrotondatu hè:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // è dopu restituemu a differenza di padding: `len_rounded_up - len`.
        //
        // Adupremu aritmetica modulare in tuttu:
        //
        // 1. align hè garantitu chì sia> 0, allora align, 1 hè sempre validu.
        //
        // 2.
        // `len + align - 1` pò overflow da massimu `align - 1`, cusì u&-mask cù `!(align - 1)` assicurerà chì in casu di overflow, `len_rounded_up` serà ellu stessu 0.
        //
        //    Cusì u padding restituitu, quandu aghjuntu à `len`, produce 0, chì soddisfa banalmente l'alineamentu `align`.
        //
        // (Benintesa, i tentativi di attribuisce blocchi di memoria chì a dimensione è u padding overflow in a maniera sopra deve causà l'allocatore à dà un errore quantunque.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Crea un schema arrotondendu a dimensione di stu schema finu à un multiplu di l'allineamentu di u schema.
    ///
    ///
    /// Questu hè equivalente à aghjunghje u risultatu di `padding_needed_for` à a dimensione attuale di u layout.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Questu ùn pò micca trabuccà.Citendu da l'invariante di Layout:
        // > `size`, quandu hè arrotondatu à u multiplu più vicinu di `align`,
        // > ùn deve micca overflow (vale à dì, u valore arrotondatu deve esse menu di
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Crea un schema chì descrive u record per l'istanze `n` di `self`, cù una quantità adatta di imbottitura trà ognuna per assicurà chì ogni istanza riceva a so dimensione è l'alineamentu richiesti.
    /// In successu, ritorna `(k, offs)` induve `k` hè u schema di u array è `offs` hè a distanza trà u principiu di ogni elementu in u array.
    ///
    /// In caso di overflow aritmeticu, restituisce `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Questu ùn pò micca trabuccà.Citendu da l'invariante di Layout:
        // > `size`, quandu hè arrotondatu à u multiplu più vicinu di `align`,
        // > ùn deve micca overflow (vale à dì, u valore arrotondatu deve esse menu di
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SICUREZZA: self.align hè dighjà cunnisciutu per esse validu è alloc_size hè statu
        // imbottitu dighjà.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Crea un schema chì descrive u registru per `self` seguitatu da `next`, cumprendu qualsiasi imbottitura necessaria per assicurà chì `next` sia allineata currettamente, ma *nisun imbottitura finale*.
    ///
    /// Per currisponde à u schema di rappresentanza C `repr(C)`, duvete chjamà `pad_to_align` dopu avè allargatu u schema cù tutti i campi.
    /// (Ùn ci hè manera di currisponde à u schema di rappresentanza Rust predefinitu `repr(Rust)`, as it is unspecified.)
    ///
    /// Nutate bè chì l'allineamentu di u layout resultante serà u massimu di quelli di `self` è `next`, per assicurà l'allineamentu di e duie parte.
    ///
    /// Restituisce `Ok((k, offset))`, induve `k` hè u schema di u record concatenatu è `offset` hè a situazione relativa, in byte, di l'iniziu di u `next` incrustatu in u registru concatenatu (supponendu chì u registru stessu cumencia à offset 0).
    ///
    ///
    /// In caso di overflow aritmeticu, restituisce `LayoutError`.
    ///
    /// # Examples
    ///
    /// Per calculà u schema di una struttura `#[repr(C)]` è l'offsets di i campi da i layout di i so campi:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Arricurdatevi di finalizà cù `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // pruvà chì funziona
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Crea un schema chì descrive u registru per l'istanze `n` di `self`, senza padding trà ogni istanza.
    ///
    /// Nutate bè chì, à u cuntrariu di `repeat`, `repeat_packed` ùn garantisce micca chì l'istanze ripetute di `self` saranu allineate currettamente, ancu se una istanza data di `self` sia allineata currettamente.
    /// In altre parolle, se u schema restituitu da `repeat_packed` hè adupratu per attribuisce un array, ùn hè micca garantitu chì tutti l'elementi in u array saranu allineati currettamente.
    ///
    /// In caso di overflow aritmeticu, restituisce `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Crea un schema chì descrive u record per `self` seguitatu da `next` senza alcuna imbottitura addizionale trà i dui.
    /// Postu chì nisun imbottitura ùn hè inserita, l'alineamentu di `next` hè irrilevante, è ùn hè micca incorporatu *affattu* in u layout resultante.
    ///
    ///
    /// In caso di overflow aritmeticu, restituisce `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Crea un schema chì descrive u record per un `[T; n]`.
    ///
    /// In caso di overflow aritmeticu, restituisce `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// I parametri dati à `Layout::from_size_align` o qualchì altru costruttore `Layout` ùn soddisfanu micca e so limitazioni documentate.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (avemu bisognu di questu per impl downstream di trait Error)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}