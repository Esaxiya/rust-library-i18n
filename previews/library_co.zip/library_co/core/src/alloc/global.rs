use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Un allocatore di memoria chì pò esse registratu cum'è predefinitu di a biblioteca standard per l'attributu `#[global_allocator]`.
///
/// Alcuni di i metudi richiedenu chì un bloccu di memoria sia *attualmente attribuitu* via un allocatore.Questu significa chì:
///
/// * l'indirizzu iniziale per quellu bloccu di memoria era precedentemente restituitu da una chjamata precedente à un metudu di attribuzione cum'è `alloc`, è
///
/// * u bloccu di memoria ùn hè statu successivamente dislocatu, induve i blocchi sò deallocati sia passendu à un metudu di deallocazione cum'è `dealloc` sia passendu à un metudu di riallocazione chì restituisce un puntatore micca nullu.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// U `GlobalAlloc` trait hè un `unsafe` trait per parechje ragioni, è l'implementatori devenu assicurà chì rispettanu questi cuntratti:
///
/// * Hè un cumpurtamentu indefinitu se l'allucatori globali si distenu.Questa restrizione pò esse levata in u future, ma attualmente un panic da una qualsiasi di queste funzioni pò purtà à a sicurezza in memoria.
///
/// * `Layout` e dumande è i calculi in generale devenu esse curretti.Chjamatori di stu trait sò permessi di cuntà nantu à i cuntratti definiti per ogni metudu, è l'implementatori devenu assicurà chì tali cuntratti restanu veri.
///
/// * Ùn pudete micca cunfidassi nantu à allocazioni chì accadenu in realtà, ancu s'ellu ci sò allocazioni di cumuli espliciti in a fonte.
/// L'ottimizatore pò rilevà allocazioni inutilizate chì pò eliminà interamente o passà à a pila è cusì ùn invoca mai l'allocatore.
/// L'ottimizatore pò ancu suppone chì l'assignazione sia infallibile, dunque u codice chì prima fallia per via di fiaschi di l'allocatore pò avà travaglià improvvisamente perchè l'ottimizzatore hà travagliatu intornu à a necessità di una attribuzione.
/// Più concretamente, l'esempiu di codice seguente ùn hè micca solidu, indipendentemente da se u vostru allocatore persunalizatu permette di cuntà quante allocazioni sò accadute.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Nutate bè chì l'ottimisazione mintuvate sopra ùn sò micca l'unica ottimisazione chì pò esse applicata.In generale ùn pudete micca contà nantu à l'assegnazioni di cumuli chì accadenu se ponu esse rimossi senza cambià u cumpurtamentu di u prugramma.
///   S'ellu accade o no allocazioni ùn face micca parte di u cumpurtamentu di u prugramma, ancu s'ellu puderia esse rilevatu via un allocatore chì traccia l'allocazioni stampendu o altrimenti avendu effetti collaterali.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Assignate memoria cum`ella hè discritta da u `layout` datu.
    ///
    /// Restituisce un puntatore in memoria appena attribuita, o null per indicà u fallimentu di allocazione.
    ///
    /// # Safety
    ///
    /// Sta funzione ùn hè micca sicura perchè pò esse un comportamentu indefinitu se u chjamante ùn assicura micca chì `layout` abbia una dimensione diversa da zero.
    ///
    /// (I sottutratuli di estensione ponu furnisce limiti più specifici nantu à u cumpurtamentu, per esempiu, guarantiscenu un indirizzu sentinella o un puntatore nullu in risposta à una dumanda d'attribuzione di dimensioni zero).
    ///
    /// U bloccu assignatu di memoria pò esse iniziatu o micca.
    ///
    /// # Errors
    ///
    /// U ritornu di un puntatore nullu indica chì sia a memoria hè esausta sia chì `layout` ùn risponde micca à e dimensioni di questu allocatore o e limitazioni di allineamentu.
    ///
    /// L'implementazioni sò incuraghjite à rinviallu nullu nantu à l'esaurimentu di a memoria piuttostu chì abbandunà, ma questu ùn hè micca un requisitu strettu.
    /// (Specificamente: hè *legale* per implementà stu trait in cima à una libreria d'attribuzione nativa sottostante chì interrompe l'esaurimentu di memoria.)
    ///
    /// I Clienti chì volenu abbandunà u calculu in risposta à un errore d'attribuzione sò incuraghjiti à chjamà a funzione [`handle_alloc_error`], piuttostu chè à invucà direttamente `panic!` o simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Deallocate u bloccu di memoria à u puntatore `ptr` datu cù u `layout` datu.
    ///
    /// # Safety
    ///
    /// Sta funzione ùn hè micca sicura perchè pò esse un cumpurtamentu indefinitu se u chjamante ùn assicura micca tutti i seguenti:
    ///
    ///
    /// * `ptr` deve denotà un bloccu di memoria attualmente attribuitu via questu allocatore,
    ///
    /// * `layout` deve esse u listessu schema chì hè statu adupratu per attribuisce quellu bloccu di memoria.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Si comporta cum'è `alloc`, ma assicura ancu chì u cuntenutu sia messu à zeru prima di esse restituitu.
    ///
    /// # Safety
    ///
    /// Sta funzione ùn hè micca sicura per i stessi motivi chì hè `alloc`.
    /// Tuttavia u bloccu assignatu di memoria hè garantitu per esse inizializatu.
    ///
    /// # Errors
    ///
    /// Riturnà un puntatore nullu indica chì sia a memoria hè esausta o chì `layout` ùn risponde micca à e dimensioni di l'allocatore o à i vincoli di allineamentu, cum'è in `alloc`.
    ///
    /// I Clienti chì volenu abbandunà u calculu in risposta à un errore d'attribuzione sò incuraghjiti à chjamà a funzione [`handle_alloc_error`], piuttostu chè à invucà direttamente `panic!` o simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SEGURITÀ: u cuntrattu di sicurezza per `alloc` deve esse rispettatu da u chjamante.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SICUREZZA: cum'è l'allocazione hà successu, a regione da `ptr`
            // di taglia `size` hè garantitu per esse validu per scrive.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Riduce o cresce un bloccu di memoria à u `new_size` datu.
    /// U bloccu hè descrittu da u puntatore `ptr` datu è `layout`.
    ///
    /// S'ellu restituisce un puntatore micca nullu, allora a pruprietà di u bloccu di memoria riferitu da `ptr` hè stata trasferita à questu allocatore.
    /// A memoria pò esse o ùn hè stata disassignata, è deve esse cunsiderata inutilizabile (a menu chì, naturalmente, sia stata trasferita torna à u chjamante per mezu di u valore di ritornu di stu metudu).
    /// U novu bloccu di memoria hè attribuitu cù `layout`, ma cù u `size` aggiornatu à `new_size`.
    /// Stu novu schema deve esse adupratu quandu si distribuisce u novu bloccu di memoria cù `dealloc`.
    /// A gamma `0..min(layout.size(), new_size) "di u novu bloccu di memoria hè garantita per avè i stessi valori cum'è u bloccu originale.
    ///
    /// Se stu metudu torna nulu, allora a pruprietà di u bloccu di memoria ùn hè micca stata trasferita à questu allocatore, è u cuntenutu di u bloccu di memoria ùn hè micca cambiatu.
    ///
    /// # Safety
    ///
    /// Sta funzione ùn hè micca sicura perchè pò esse un cumpurtamentu indefinitu se u chjamante ùn assicura micca tutti i seguenti:
    ///
    /// * `ptr` deve esse attualmente attribuitu via questu allocatore,
    ///
    /// * `layout` deve esse u listessu layout chì hè stata aduprata per attribuisce quellu bloccu di memoria,
    ///
    /// * `new_size` deve esse più grande chè zeru.
    ///
    /// * `new_size`, quandu hè arrotondatu à u multiplu più vicinu di `layout.align()`, ùn deve micca trabuccà (vale à dì, u valore arrotondatu deve esse menu di `usize::MAX`).
    ///
    /// (I sottutratuli di estensione ponu furnisce limiti più specifici nantu à u cumpurtamentu, per esempiu, guarantiscenu un indirizzu sentinella o un puntatore nullu in risposta à una dumanda d'attribuzione di dimensioni zero).
    ///
    /// # Errors
    ///
    /// Restituisce u valore nulu se u novu schema ùn risponde micca à e dimensioni è à i vincoli di allineamentu di l'allocatore, o se a riallocazione falla altrimenti.
    ///
    /// L'implementazioni sò incuragite à rinviallu nullu nantu à l'esaurimentu di a memoria piuttostu chè in panicu o abbandunà, ma questu ùn hè micca un requisitu strettu.
    /// (Specificamente: hè *legale* per implementà stu trait in cima à una libreria d'attribuzione nativa sottostante chì interrompe l'esaurimentu di memoria.)
    ///
    /// I Clienti chì volenu abbandunà u calculu in risposta à un errore di riallocazione sò incuragiti à chjamà a funzione [`handle_alloc_error`], piuttostu chè à invucà direttamente `panic!` o simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SICUREZZA: u chjamante deve assicurà chì u `new_size` ùn sia micca troppu.
        // `layout.align()` vene da un `Layout` è hè dunque garantitu per esse validu.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SEGURITÀ: u chjamante deve assicurà chì `new_layout` sia più grande chè zeru.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SICUREZZA: u bloccu assignatu prima ùn pò micca soprappone u bloccu novu attribuitu.
            // U cuntrattu di sicurezza per `dealloc` deve esse rispettatu da u chjamante.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}