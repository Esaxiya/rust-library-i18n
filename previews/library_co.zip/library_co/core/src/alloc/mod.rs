//! API di allocazione di memoria

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// L'errore `AllocError` indica un fiascu d'attribuzione chì pò esse dovutu à l'esaurimentu di e risorse o à qualcosa di male quandu si cumbinanu l'argumenti entrati dati cù questu allocatore.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (avemu bisognu di questu per impl downstream di trait Error)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Una messa in opera di `Allocator` pò assignà, cresce, riduce, è distribuisce blocchi arbitrarie di dati descritti via [`Layout`][].
///
/// `Allocator` hè designatu per esse implementatu nantu à ZST, riferimenti, o puntatori intelligenti perchè avè un allocatore cum'è `MyAlloc([u8; N])` ùn pò micca esse spostatu, senza aghjurnà i puntatori à a memoria attribuita.
///
/// A differenza di [`GlobalAlloc`][], allocazioni di dimensioni zero sò permesse in `Allocator`.
/// Se un allocatore sottostante ùn supporta micca questu (cum'è jemalloc) o restituisce un puntatore null (cum'è `libc::malloc`), questu deve esse pigliatu da l'implementazione.
///
/// ### Memoria attualmente attribuita
///
/// Alcuni di i metudi richiedenu chì un bloccu di memoria sia *attualmente attribuitu* via un allocatore.Questu significa chì:
///
/// * l'indirizzu iniziale per quellu bloccu di memoria hè statu prima restituitu da [`allocate`], [`grow`], o [`shrink`], è
///
/// * u bloccu di memoria ùn hè statu successivamente deallocatu, induve i blocchi sò o deallocati direttamente da esse passatu à [`deallocate`] o sò stati cambiati passendu à [`grow`] o [`shrink`] chì restituisce `Ok`.
///
/// Se `grow` o `shrink` anu restituitu `Err`, u puntatore passatu hè validu.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Adattazione di memoria
///
/// Alcuni di i metudi richiedenu chì un layout *si adatti* à un bloccu di memoria.
/// Ciò chì significa per un layout per "fit" un bloccu di memoria significa (o equivalente, per un bloccu di memoria per "fit" un layout) hè chì e condizioni seguenti devenu tene:
///
/// * U bloccu deve esse attribuitu cù u listessu allineamentu cum'è [`layout.align()`], è
///
/// * U [`layout.size()`] furnitu deve rientre in a gamma `min ..= max`, induve:
///   - `min` hè a dimensione di a dispusizione utilizata più recentemente per attribuisce u bloccu, è
///   - `max` hè l'ultima dimensione attuale restituita da [`allocate`], [`grow`], o [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * I blocchi di memoria restituiti da un allocatore devenu puntà à memoria valida è mantene a so validità finu à chì l'istanza è tutti i so cloni sò cascati,
///
/// * clonazione o muvimentu di l'allocatore ùn deve invalidà i blocchi di memoria restituiti da questu allocatore.Un allocatore clonatu deve comportassi cum'è u listessu allocatore, è
///
/// * qualsiasi puntatore à un bloccu di memoria chì hè [*currently allocated*] pò esse passatu à qualsiasi altru metudu di l'allocatore.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Tentativi di attribuisce un bloccu di memoria.
    ///
    /// À u successu, ritorna un [`NonNull<[u8]>`][NonNull] chì risponde à e dimensioni è e garanzie di allineamentu di `layout`.
    ///
    /// U bloccu restituitu pò avè una dimensione più grande di quellu specificatu da `layout.size()`, è pò avè u so cuntenutu iniziatu o micca.
    ///
    /// # Errors
    ///
    /// U ritornu di `Err` indica chì sia a memoria hè esausta, sia chì `layout` ùn risponde micca à e dimensioni di l'allocatore o à e limitazioni di allineamentu.
    ///
    /// L'implementazioni sò incuragite à restituisce `Err` per stanchezza di memoria piuttostu chè da piglià panicu o abbandunà, ma questu ùn hè micca un requisitu strettu.
    /// (Specificamente: hè *legale* per implementà stu trait in cima à una libreria d'attribuzione nativa sottostante chì interrompe l'esaurimentu di memoria.)
    ///
    /// I Clienti chì volenu abbandunà u calculu in risposta à un errore d'attribuzione sò incuraghjiti à chjamà a funzione [`handle_alloc_error`], piuttostu chè à invucà direttamente `panic!` o simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Si comporta cum'è `allocate`, ma assicura ancu chì a memoria restituita sia inizializata à zero.
    ///
    /// # Errors
    ///
    /// U ritornu di `Err` indica chì sia a memoria hè esausta, sia chì `layout` ùn risponde micca à e dimensioni di l'allocatore o à e limitazioni di allineamentu.
    ///
    /// L'implementazioni sò incuragite à restituisce `Err` per stanchezza di memoria piuttostu chè da piglià panicu o abbandunà, ma questu ùn hè micca un requisitu strettu.
    /// (Specificamente: hè *legale* per implementà stu trait in cima à una libreria d'attribuzione nativa sottostante chì interrompe l'esaurimentu di memoria.)
    ///
    /// I Clienti chì volenu abbandunà u calculu in risposta à un errore d'attribuzione sò incuraghjiti à chjamà a funzione [`handle_alloc_error`], piuttostu chè à invucà direttamente `panic!` o simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SICUREZZA: `alloc` restituisce un bloccu di memoria validu
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Deallocates a memoria riferita da `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` deve denotà un bloccu di memoria [*currently allocated*] via questu allocatore, è
    /// * `layout` deve [*fit*] quellu bloccu di memoria.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Tentativi di allargà u bloccu di memoria.
    ///
    /// Restituisce un novu [`NonNull<[u8]>`][NonNull] chì cuntene un puntatore è a dimensione vera di a memoria assignata.U puntatore hè adattatu per tene i dati descritti da `new_layout`.
    /// Per fà questu, l'allocatore pò allargà l'allocazione riferita da `ptr` per adattassi à u novu schema.
    ///
    /// Se questu restituisce `Ok`, allora a pruprietà di u bloccu di memoria riferitu da `ptr` hè stata trasferita à questu allocatore.
    /// A memoria pò esse o ùn hè stata liberata, è deve esse cunsiderata inutilizabile a menu chì sia stata trasferita torna à u chjamante per mezu di u valore di ritornu di stu metudu.
    ///
    /// Se stu metudu torna `Err`, allora a pruprietà di u bloccu di memoria ùn hè micca stata trasferita à questu allocatore, è u cuntenutu di u bloccu di memoria ùn hè micca cambiatu.
    ///
    /// # Safety
    ///
    /// * `ptr` deve denotà un bloccu di memoria [*currently allocated*] via questu allocatore.
    /// * `old_layout` [*fit*] deve esse quellu bloccu di memoria (L'argumentu `new_layout` ùn deve micca adattallu.).
    /// * `new_layout.size()` deve esse più grande o uguale à `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ritorna `Err` se u novu schema ùn risponde micca à a dimensione di l'allocatore è e restrizioni di allineamentu di l'allocatore, o se a crescita altrimenti fiasca.
    ///
    /// L'implementazioni sò incuragite à restituisce `Err` per stanchezza di memoria piuttostu chè da piglià panicu o abbandunà, ma questu ùn hè micca un requisitu strettu.
    /// (Specificamente: hè *legale* per implementà stu trait in cima à una libreria d'attribuzione nativa sottostante chì interrompe l'esaurimentu di memoria.)
    ///
    /// I Clienti chì volenu abbandunà u calculu in risposta à un errore d'attribuzione sò incuraghjiti à chjamà a funzione [`handle_alloc_error`], piuttostu chè à invucà direttamente `panic!` o simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SICUREZZA: perchè `new_layout.size()` deve esse più grande o uguale à
        // `old_layout.size()`, sia a vechja sia a nova assignazione di memoria sò valide per leghje è scrive per byte `old_layout.size()`.
        // Inoltre, perchè l'anziana allocazione ùn era ancu disassignata, ùn pò micca sovrappone `new_ptr`.
        // Cusì, a chjamata à `copy_nonoverlapping` hè sicura.
        // U cuntrattu di sicurezza per `dealloc` deve esse rispettatu da u chjamante.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Si comporta cum'è `grow`, ma assicura ancu chì i novi cuntenuti sò messi à zeru prima di esse restituiti.
    ///
    /// U bloccu di memoria cuntene i cuntenuti seguenti dopu una chjamata riesciuta à
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` sò cunservati da l'attribuzione originale.
    ///   * I Bytes `old_layout.size()..old_size` seranu cunservati o messi à zero, secondu l'implementazione di l'allocatore.
    ///   `old_size` si riferisce à a dimensione di u bloccu di memoria prima di a chjamata `grow_zeroed`, chì pò esse più grande di a dimensione chì era urigginariamente dumandata quandu hè stata attribuita.
    ///   * Byte `old_size..new_size` sò messi à zero.`new_size` si riferisce à a dimensione di u bloccu di memoria restituitu da a chjamata `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` deve denotà un bloccu di memoria [*currently allocated*] via questu allocatore.
    /// * `old_layout` [*fit*] deve esse quellu bloccu di memoria (L'argumentu `new_layout` ùn deve micca adattallu.).
    /// * `new_layout.size()` deve esse più grande o uguale à `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ritorna `Err` se u novu schema ùn risponde micca à a dimensione di l'allocatore è e restrizioni di allineamentu di l'allocatore, o se a crescita altrimenti fiasca.
    ///
    /// L'implementazioni sò incuragite à restituisce `Err` per stanchezza di memoria piuttostu chè da piglià panicu o abbandunà, ma questu ùn hè micca un requisitu strettu.
    /// (Specificamente: hè *legale* per implementà stu trait in cima à una libreria d'attribuzione nativa sottostante chì interrompe l'esaurimentu di memoria.)
    ///
    /// I Clienti chì volenu abbandunà u calculu in risposta à un errore d'attribuzione sò incuraghjiti à chjamà a funzione [`handle_alloc_error`], piuttostu chè à invucà direttamente `panic!` o simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SICUREZZA: perchè `new_layout.size()` deve esse più grande o uguale à
        // `old_layout.size()`, sia a vechja sia a nova assignazione di memoria sò valide per leghje è scrive per byte `old_layout.size()`.
        // Inoltre, perchè l'anziana allocazione ùn era ancu disassignata, ùn pò micca sovrappone `new_ptr`.
        // Cusì, a chjamata à `copy_nonoverlapping` hè sicura.
        // U cuntrattu di sicurezza per `dealloc` deve esse rispettatu da u chjamante.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Tentativi di riduce u bloccu di memoria.
    ///
    /// Restituisce un novu [`NonNull<[u8]>`][NonNull] chì cuntene un puntatore è a dimensione vera di a memoria assignata.U puntatore hè adattatu per tene i dati descritti da `new_layout`.
    /// Per fà questu, l'allocatore pò riduce l'allocazione riferita da `ptr` per adattassi à u novu layout.
    ///
    /// Se questu restituisce `Ok`, allora a pruprietà di u bloccu di memoria riferitu da `ptr` hè stata trasferita à questu allocatore.
    /// A memoria pò esse o ùn hè stata liberata, è deve esse cunsiderata inutilizabile a menu chì sia stata trasferita torna à u chjamante per mezu di u valore di ritornu di stu metudu.
    ///
    /// Se stu metudu torna `Err`, allora a pruprietà di u bloccu di memoria ùn hè micca stata trasferita à questu allocatore, è u cuntenutu di u bloccu di memoria ùn hè micca cambiatu.
    ///
    /// # Safety
    ///
    /// * `ptr` deve denotà un bloccu di memoria [*currently allocated*] via questu allocatore.
    /// * `old_layout` [*fit*] deve esse quellu bloccu di memoria (L'argumentu `new_layout` ùn deve micca adattallu.).
    /// * `new_layout.size()` deve esse più chjucu o uguale à `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ritorna `Err` se u novu schema ùn risponde micca à a dimensione di l'allocatore è e restrizioni di allineamentu di l'allocatore, o se a diminuzione altrimenti fiasca.
    ///
    /// L'implementazioni sò incuragite à restituisce `Err` per stanchezza di memoria piuttostu chè da piglià panicu o abbandunà, ma questu ùn hè micca un requisitu strettu.
    /// (Specificamente: hè *legale* per implementà stu trait in cima à una libreria d'attribuzione nativa sottostante chì interrompe l'esaurimentu di memoria.)
    ///
    /// I Clienti chì volenu abbandunà u calculu in risposta à un errore d'attribuzione sò incuraghjiti à chjamà a funzione [`handle_alloc_error`], piuttostu chè à invucà direttamente `panic!` o simile.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SICUREZZA: perchè `new_layout.size()` deve esse inferiore o uguale a
        // `old_layout.size()`, sia a vechja sia a nova assignazione di memoria sò valide per leghje è scrive per byte `new_layout.size()`.
        // Inoltre, perchè l'anziana allocazione ùn era ancu disassignata, ùn pò micca sovrappone `new_ptr`.
        // Cusì, a chjamata à `copy_nonoverlapping` hè sicura.
        // U cuntrattu di sicurezza per `dealloc` deve esse rispettatu da u chjamante.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Crea un adattatore "by reference" per questa istanza di `Allocator`.
    ///
    /// L'adattatore restituitu implementa ancu `Allocator` è simplificherà prestu questu.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SICUREZZA: u cuntrattu di sicurezza deve esse rispettatu da u chjamante
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SICUREZZA: u cuntrattu di sicurezza deve esse rispettatu da u chjamante
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SICUREZZA: u cuntrattu di sicurezza deve esse rispettatu da u chjamante
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SICUREZZA: u cuntrattu di sicurezza deve esse rispettatu da u chjamante
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}