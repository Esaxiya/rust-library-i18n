#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Un future representa un computazione asincrona.
///
/// Un future hè un valore chì forse ùn hà ancu finitu l'informatica.
/// Stu tipu di "asynchronous value" rende pussibule per un filu di cuntinuà à fà travagli utili mentre aspetta u valore per esse dispunibule.
///
///
/// # U metudu `poll`
///
/// U metudu core di future, `poll`,*prova* di risolve u future in un valore finale.
/// Stu metudu ùn blocca micca se u valore ùn hè micca prontu.
/// Invece, u compitu attuale hè previstu per esse svegliatu quandu hè pussibule di fà ulteriori prugressi da `poll 'di novu.
/// U `context` passatu à u metudu `poll` pò furnisce un [`Waker`], chì hè un manicu per svegliare u compitu attuale.
///
/// Quandu si usa un future, in generale ùn chjamate micca `poll` direttamente, ma invece `.await` u valore.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// U tippu di valore pruduttu à a fine.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Pruvate à risolve u future à un valore finale, registrendu u compitu attuale per u svegliu se u valore ùn hè ancu dispunibile.
    ///
    /// # Valore di ritornu
    ///
    /// Sta funzione ritorna:
    ///
    /// - [`Poll::Pending`] se u future ùn hè ancu prontu
    /// - [`Poll::Ready(val)`] cù u risultatu `val` di questu future se hè finitu cù successu.
    ///
    /// Una volta chì un future hè finitu, i clienti ùn devenu micca `poll` torna.
    ///
    /// Quandu un future ùn hè ancu prontu, `poll` restituisce `Poll::Pending` è guarda un clone di u [`Waker`] copiatu da u [`Context`] attuale.
    /// Questu [`Waker`] hè allora svegliatu una volta chì u future pò fà prugressi.
    /// Per esempiu, un future chì aspetta un socket per diventà leggibile chjamaria `.clone()` nantu à u [`Waker`] è u memorizava.
    /// Quandu un signale ghjunghje in altrò chì indica chì u socket hè leggibile, [`Waker::wake`] hè chjamatu è u compitu di u socket future hè svegliu.
    /// Una volta chì un compitu hè statu svegliatu, duverà pruvà à `poll` u future di novu, chì pò o ùn pò pruduce un valore finale.
    ///
    /// Innota chì nantu à parechje chjamate à `poll`, solu u [`Waker`] da u [`Context`] passatu à a più recente chjamata deve esse pianificatu per riceve un svegliu.
    ///
    /// # Caratteristiche di runtime
    ///
    /// Futures solu sò *inerti*;devenu esse *attivamente*`poll`ed per fà u prugressu, vale à dì chì ogni volta chì u compitu attuale hè svegliatu, deve attivamente ri-`pollà 'in attesa di futures chì hà sempre un interessu in.
    ///
    /// A funzione `poll` ùn hè micca chjamata ripetutamente in un ciclu strettu-invece, deve esse chjamata solu quandu u future indica chì hè pronta à fà prugressi (chjamendu `wake()`).
    /// Se site familiarizatu cù u `poll(2)` o `select(2)` syscalls in Unix vale nutà chì futures tipicamente ùn * ** soffre micca i listessi prublemi di "all wakeups must poll all events";sò più cum'è `epoll(4)`.
    ///
    /// Una implementazione di `poll` duverebbe sforzassi di vultà prestu, è ùn deve micca bluccà.U ritornu rapidamente impedisce inutile intasà i fili o cicli d'eventi.
    /// S'ellu hè cunnisciutu in anticipu chì una chjamata à `poll` pò finisce per piglià un pocu, u travagliu deve esse scaricatu in un pool di fili (o qualcosa di simile) per assicurà chì `poll` possa tornà rapidamente.
    ///
    /// # Panics
    ///
    /// Una volta chì un future hà compiu (restituitu `Ready` da `poll`), chjamà dinò u so metudu `poll` pò panic, bluccà per sempre, o causà altri tipi di prublemi;u `Future` trait ùn mette micca esigenze nantu à l'effetti di una tale chjamata.
    /// Tuttavia, cume u metudu `poll` ùn hè micca marcatu `unsafe`, e regule abituali di Rust valenu: e chjamate ùn devenu mai causà cumpurtamentu indefinitu (corruzzione di memoria, usu incorrettu di e funzioni `unsafe`, o simile), indipendentemente da u statu di future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}