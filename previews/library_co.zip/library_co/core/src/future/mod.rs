#![stable(feature = "futures_api", since = "1.36.0")]

//! Valori asincroni.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Stu tipu hè necessariu perchè:
///
/// a) I generatori ùn ponu micca implementà `for<'a, 'b> Generator<&'a mut Context<'b>>`, allora ci vole à passà un puntatore grezzu (vede <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) I puntatori grezzi è `NonNull` ùn sò micca `Send` o `Sync`, dunque ciò renderebbe ancu ogni singulu future non-Send/Sync, è ùn vulemu micca.
///
/// Simplifica ancu a calata HIR di `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Avvolge un generatore in un future.
///
/// Sta funzione rende un `GenFuture` sottu, ma a piatta in `impl Trait` per dà megliu messagi d'errore (`impl Future` piuttostu chè `GenFuture<[closure.....]>`).
///
// Questu hè `const` per evità errori extra dopu avè recuperatu da `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Ci appughjemu nantu à u fattu chì async/await futures sò immubiliari per creà prestiti autoreferenziali in u generatore sottostante.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SICUREZZA: Sicura perchè simu !Unpin + !Drop, è questu hè solu una pruiezione di campu.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Riprende u generatore, trasformendu u `&mut Context` in un puntatore grezzu `NonNull`.
            // L'abbassamentu `.await` lanciarà in modu sicuru ciò chì torna à un `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SICUREZZA: u chjamante deve garantisce chì `cx.0` hè un puntatore validu
    // chì risponde à tutti i requisiti per una riferenza mutabile.
    unsafe { &mut *cx.0.as_ptr().cast() }
}