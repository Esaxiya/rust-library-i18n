#![stable(feature = "core_hint", since = "1.27.0")]

//! Suggerimenti per u compilatore chì influenza cumu u codice deve esse emessu o ottimizatu.
//! I suggerimenti ponu esse tempu di compilazione o runtime.

use crate::intrinsics;

/// Informa u compilatore chì stu puntu di u codice ùn hè micca accessibile, permettendu ulteriori ottimizzazioni.
///
/// # Safety
///
/// Ghjunghje à sta funzione hè cumpletamente *cumpurtamentu indefinitu*(UB).In particulare, u compilatore assume chì tutte l'UB ùn devenu mai accade, è dunque eliminerà tutte e branche chì ghjunghjenu à una chjamata à `unreachable_unchecked()`.
///
/// Cum'è tutti i casi di UB, se sta supposizione si rivela sbagliata, cioè, a chjamata `unreachable_unchecked()` hè in realtà raggiungibile trà tutti i flussi di cuntrollu pussibili, u compilatore applica a strategia d'ottimisazione sbagliata, è pò ancu ancu corrompe un codice apparentemente micca legatu, causendu difficultà-prublemi di debug.
///
///
/// Aduprate sta funzione solu quandu puderete pruvà chì u codice ùn a chjamerà mai.
/// Altrimenti, pensate à aduprà a macro [`unreachable!`], chì ùn permette micca ottimisazioni, ma serà panic quandu eseguitu.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` hè sempre pusitivu (micca zeru), dunque `checked_div` ùn tornerà mai `None`.
/////
///     // Dunque, l'altru branch hè inaccessibile.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SICUREZZA: u cuntrattu di sicurezza per `intrinsics::unreachable` deve
    // esse cunfirmatu da u chjamante.
    unsafe { intrinsics::unreachable() }
}

/// Emette una struzzione di macchina per signalà à u processatore chì hè in esecuzione in un spin-loop occupatu-aspettatu ("spin lock").
///
/// Dopu avè ricevutu u segnale spin-loop u processatore pò ottimisà u so cumpurtamentu, per esempiu, risparmendu energia o cambiendu i fili hyper.
///
/// Sta funzione hè diversa da [`thread::yield_now`] chì cede direttamente à u pianificatore di u sistema, mentre chì `spin_loop` ùn interagisce micca cù u sistema operativu.
///
/// Un casu d'usu cumunu per `spin_loop` hè l'implementazione di filatura ottimista limitata in un loop CAS in primitivi di sincronizazione.
/// Per evità prublemi cum'è l'inversione di priorità, hè fortemente raccomandatu chì u spin loop sia terminatu dopu una quantità finita di iterazioni è una syscall di bloccu adatta sia fatta.
///
///
/// **Nota**: Nantu à e piattaforme chì ùn sustenenu micca di riceve suggerimenti spin-loop sta funzione ùn face nunda.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Un valore atomicu spartutu chì i fili aduprà per coordinar
/// let live = Arc::new(AtomicBool::new(false));
///
/// // In un filu di fondu avemu da definisce u valore
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Fate un travagliu, poi fate campà u valore
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Torna à u nostru filu attuale, aspettemu chì u valore sia impostatu
/// while !live.load(Ordering::Acquire) {
///     // U spin loop hè un suggerimentu à u CPU chì aspittemu, ma probabilmente micca per assai tempu
/////
///     hint::spin_loop();
/// }
///
/// // U valore hè avà stabilitu
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SICUREZZA: u `cfg` attr assicura chì eseguemu solu questu nantu à i target x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SICUREZZA: u `cfg` attr assicura chì eseguemu solu questu nantu à i target x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SICUREZZA: u `cfg` attr assicura chì eseguemu solu questu nantu à i target aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SICUREZZA: u `cfg` attr assicura chì eseguemu solu questu nantu à i bracci di mira
            // cù supportu per a funzione v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Una funzione d'identità chì *__ suggerisce __* à u compilatore per esse massimamente pessimista di ciò chì `black_box` puderia fà.
///
/// A diversità di [`std::convert::identity`], un compilatore Rust hè incuragitu à suppurtà chì `black_box` pò aduprà `dummy` in ogni modu validu pussibule chì u codice Rust hè permessu senza introduce un comportamentu indefinitu in u codice di chjamata.
///
/// Sta pruprietà rende `black_box` utile per scrive codice in u quale certe ottimisazione ùn sò micca desiderate, cum'è benchmarks.
///
/// Nota però, chì `black_box` hè solu (è pò esse solu) furnitu nantu à una basa "best-effort".A misura in cui pò bluccà l'ottimisazioni pò varià secondu a piattaforma è u backend di codice-gen adupratu.
/// I prugrammi ùn ponu micca contà nantu à `black_box` per a *currettezza* in alcun modu.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Avemu bisognu di "use" l'argumentu in un certu modu LLVM ùn pò micca introspettà, è nantu à obiettivi chì u sustenenu pudemu tipicamente sfruttà l'assemblea in linea per fà questu.
    // L'interpretazione di LLVM di l'assemblea in linea hè chì hè, bè, una scatula nera.
    // Questa ùn hè micca a più grande implementazione postu chì probabilmente deoptimizza più di ciò chì vulemu, ma hè finu finu abbastanza bè.
    //
    //

    #[cfg(not(miri))] // Questu hè solu un suggerimentu, dunque hè bè di saltà in Miri.
    // SICUREZZA: l'assemblea in linea hè un no-op.
    unsafe {
        // FIXME: Ùn pudemu micca aduprà `asm!` perchè ùn supporta micca MIPS è altre architetture.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}