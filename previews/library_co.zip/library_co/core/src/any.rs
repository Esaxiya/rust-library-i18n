//! Stu modulu implementa u `Any` trait, chì permette a scrittura dinamica di qualsiasi tippu `'static` attraversu a riflessione di runtime.
//!
//! `Any` ellu stessu pò esse adupratu per uttene un `TypeId`, è hà più caratteristiche quandu hè adupratu cum'è oggettu trait.
//! Cum'è `&dyn Any` (un ogettu trait in prestitu), hà i metudi `is` è `downcast_ref`, per pruvà se u valore cuntenutu hè di un tipu datu, è per uttene una riferenza à u valore internu cum'è tippu.
//! Cume `&mut dyn Any`, ci hè ancu u metudu `downcast_mut`, per uttene una riferenza mutevule à u valore internu.
//! `Box<dyn Any>` aghjusta u metudu `downcast`, chì prova à cunvertisce in un `Box<T>`.
//! Vede a documentazione [`Box`] per i dettagli cumpleti.
//!
//! Nutate bè chì `&dyn Any` hè limitatu à pruvà se un valore hè di un tippu cuncretu specificatu, è ùn pò micca esse adupratu per pruvà se un tippu mette in opera un trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Puntatori intelligenti è `dyn Any`
//!
//! Un cumpurtamentu da tene à mente quandu si usa `Any` cum'è un oggettu trait, in particulare cù tippi cum'è `Box<dyn Any>` o `Arc<dyn Any>`, hè chì chjamà solu `.type_id()` à u valore pruducerà u `TypeId` di u *contenitore*, micca l'oggettu sottostante trait.
//!
//! Questa pò esse evitata cunvertendu u puntatore intelligente in un `&dyn Any` invece, chì restituverà `TypeId` di l'ughjettu.
//! Per esempiu:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Avete più probabilità di vulè questu:
//! let actual_id = (&*boxed).type_id();
//! // ... chè questu:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Cunsiderate una situazione induve vulemu disconnettà un valore passatu à una funzione.
//! Cunnisciamu u valore chì travagliamu nantu à implementa Debug, ma ùn sapemu micca u so tippu cuncretu.Vulemu dà un trattamentu speciale à certi tippi: in questu casu stampà a lunghezza di i valori di String prima di u so valore.
//! Ùn sapemu micca u tippu cuncretu di u nostru valore in tempu di compilazione, allora avemu bisognu di aduprà a riflessione di runtime invece.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Funzione Logger per qualsiasi tippu chì implementa Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Pruvate à cunvertisce u nostru valore in un `String`.
//!     // Se riesce, vulemu pruduce a lunghezza di a String è u so valore.
//!     // Se no, hè un tippu diversu: basta stampallu senza ornamentu.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Sta funzione vole scurdà u so parametru prima di fà u travagliu cun ella.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... fà qualchì altru travagliu
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Ogni trait
///////////////////////////////////////////////////////////////////////////////

/// A trait per emulà a scrittura dinamica.
///
/// A maiò parte di i tipi implementanu `Any`.Tuttavia, qualsiasi tippu chì cuntene una riferenza micca "statica" ùn la face micca.
/// Vede u [module-level documentation][mod] per più dettagli.
///
/// [mod]: crate::any
// Stu trait ùn hè micca periculosu, ancu s'appughjemu nantu à e specificità di a so sola funzione `type_id` di impl in codice senza periculu (per esempiu, `downcast`).Normalmente, questu seria un prublema, ma perchè l'unica impl di `Any` hè una implementazione di manta, nisun altru codice pò implementà `Any`.
//
// Puderemu rende plausibilmente questu trait periculosu-ùn causaria micca rotture, postu chì cuntrullemu tutte l'implementazioni-ma sceglemu di ùn fà micca chì sia sia micca veramente necessariu è pudemu cunfondere l'utenti nantu à a distinzione di traits periculosi è metudi periculosi (vale à dì, `type_id` seria sempre sicuru di chjamà, ma vuleriamu probabilmente indicà cum'è tale in documentazione).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Ottiene u `TypeId` di `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Metodi di estensione per Ogni oggettu trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Assicuratevi chì u risultatu di, per esempiu, unisce un filu pò esse stampatu è dunque adupratu cù `unwrap`.
// Pò esse eventualmente micca più necessariu se u dispatch funziona cun upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Restituisce `true` se u tippu in scatula hè listessu chì `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Uttenite `TypeId` di u tippu cù chì sta funzione hè istanziata.
        let t = TypeId::of::<T>();

        // Uttenite `TypeId` di u tippu in l'oggettu trait (`self`).
        let concrete = self.type_id();

        // Paragunate entrambi i `TypeId` in parità.
        t == concrete
    }

    /// Restituisce qualchì riferimentu à u valore in scatula s'ellu hè di tipu `T`, o `None` se ùn hè micca.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SICUREZZA: ghjustu verificatu se puntemu u tippu currettu, è ci pudemu fidà
            // chì verificà a sicurità di a memoria perchè avemu implementatu Qualcosa per tutti i tippi;nisun altru impls ùn pò esiste cume si cuntrastanu cù u nostru impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Restituisce qualchì riferimentu mutevule à u valore in scatula s'ellu hè di tipu `T`, o `None` s'ellu ùn hè micca.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SICUREZZA: ghjustu verificatu se puntemu u tippu currettu, è ci pudemu fidà
            // chì verificà a sicurità di a memoria perchè avemu implementatu Qualcosa per tutti i tippi;nisun altru impls ùn pò esiste cume si cuntrastanu cù u nostru impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// In avanti à u metudu definitu nantu à u tipu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// In avanti à u metudu definitu nantu à u tipu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// In avanti à u metudu definitu nantu à u tipu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// In avanti à u metudu definitu nantu à u tipu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// In avanti à u metudu definitu nantu à u tipu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// In avanti à u metudu definitu nantu à u tipu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID è i so metudi
///////////////////////////////////////////////////////////////////////////////

/// Un `TypeId` riprisenta un identificatore univocu à livellu mundiale per un tippu.
///
/// Ogni `TypeId` hè un ogettu opacu chì ùn permette micca l'ispezione di ciò chì si trova in l'internu ma permette operazioni di basa cum'è clonazione, paragone, stampa è mostra.
///
///
/// Un `TypeId` hè attualmente dispunibule solu per i tippi chì attribuiscenu à `'static`, ma sta limitazione pò esse eliminata in u future.
///
/// Mentre `TypeId` implementa `Hash`, `PartialOrd` è `Ord`, vale nutà chì l'hash è l'ordine varieranu trà e versioni Rust.
/// Attenti à cunfidassi nantu à elli in u vostru còdice!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Restituisce u `TypeId` di u tippu cù chì sta funzione generica hè stata istanziata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Restituisce u nome di un tipu cum'è una fetta di stringa.
///
/// # Note
///
/// Questu hè destinatu à l'usu diagnosticu.
/// U cuntenutu esattu è u furmatu di a stringa restituita ùn sò micca specificati, fora di esse una descrizione di u megliu sforzu di u tippu.
/// Per esempiu, trà e corde chì `type_name::<Option<String>>()` puderia restituisce sò `"Option<String>"` è `"std::option::Option<std::string::String>"`.
///
///
/// A stringa restituita ùn deve esse cunsiderata cum'è un identificatore unicu di un tippu chì parechji tippi ponu mappà cù u listessu nome di tippu.
/// Similmente, ùn ci hè nisuna garanzia chì tutte e parte di un tippu apparsu in a stringa restituita: per esempiu, i specificatori di vita ùn sò attualmente inclusi.
/// Inoltre, l'output pò cambià trà e versioni di u compilatore.
///
/// L'implementazione attuale usa a stessa infrastruttura cum'è diagnosticu di compilatore è debuginfo, ma questu ùn hè micca garantitu.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Restituisce u nome di u tippu di u valore à punta cum'è una fetta di stringa.
/// Questu hè listessu chì `type_name::<T>()`, ma pò esse adupratu induve u tipu di una variabile ùn hè micca facilmente dispunibile.
///
/// # Note
///
/// Questu hè destinatu à l'usu diagnosticu.U cuntenutu esattu è u furmatu di a stringa ùn sò micca specificati, fora di esse una descrizione di u megliu sforzu di u tippu.
/// Per esempiu, `type_name_of_val::<Option<String>>(None)` puderia restituisce `"Option<String>"` o `"std::option::Option<std::string::String>"`, ma micca `"foobar"`.
///
/// Inoltre, l'output pò cambià trà e versioni di u compilatore.
///
/// Questa funzione ùn risolve micca l'oggetti trait, vale à dì chì `type_name_of_val(&7u32 as &dyn Debug)` pò restituisce `"dyn Debug"`, ma micca `"u32"`.
///
/// U nome di tippu ùn deve esse cunsideratu un identificatore unicu di un tippu;
/// parechji tippi ponu sparte u listessu nome di tippu.
///
/// L'implementazione attuale usa a stessa infrastruttura cum'è diagnosticu di compilatore è debuginfo, ma questu ùn hè micca garantitu.
///
/// # Examples
///
/// Stampa i tipi interi è float predefiniti.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}