//! Primitive traits è tippi chì rapprisentanu proprietà di basa di tippi.
//!
//! I tippi Rust ponu esse classificati in vari modi utili secondu e so proprietà intrinseche.
//! Queste classificazioni sò rappresentate cum'è traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tipi chì ponu esse trasferiti à traversu i limiti di u filu.
///
/// Questa trait hè automaticamente implementata quandu u compilatore determina chì hè adatta.
///
/// Un esempiu di un tippu chì ùn hè micca `Invia 'hè u puntatore [`rc::Rc`][`Rc`] chì conta u riferimentu.
/// Se dui fili cercanu di clonà [`Rc`] s chì puntanu à u listessu valore cuntatu di riferenza, puderianu pruvà à aghjurnà u cuntu di riferenza in listessu tempu, chì hè [undefined behavior][ub] perchè [`Rc`] ùn usa micca operazioni atomiche.
///
/// U so cuginu [`sync::Arc`][arc] usa operazioni atomiche (incurru qualchì soprappu) è cusì hè `Send`.
///
/// Vede [the Nomicon](../../nomicon/send-and-sync.html) per più infurmazioni.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tipi cù una dimensione custante cunnisciuta in tempu di compilazione.
///
/// Tutti i parametri di tippu anu un limite implicitu di `Sized`.A sintassi speciale `?Sized` pò esse usata per rimuovere questu legatu se ùn hè micca adatta.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//errore: Sized ùn hè micca implementatu per [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// L'unica eccezione hè u tippu `Self` implicitu di un trait.
/// Un trait ùn hà micca un `Sized` implicitu ligatu chì questu hè incompatibile cù [ughjettu trait] induve, per definizione, u trait hà bisognu di travaglià cù tutti l'implementatori pussibuli, è cusì puderia esse di qualsiasi dimensione.
///
///
/// Ancu se Rust vi permetterà di ligà `Sized` à un trait, ùn puderete micca aduprà per formà un oggettu trait dopu:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // lascià y: &dyn Bar= &Impl;//errore: u trait `Bar` ùn pò micca esse trasfurmatu in un ughjettu
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // per Default, per esempiu, chì richiede chì `[T]: !Default` sia valutabile
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tipi chì ponu esse "unsized" à un tippu di dimensioni dinamiche.
///
/// Per esempiu, u tipu di matrice di dimensioni `[i8; 2]` implementa `Unsize<[i8]>` è `Unsize<dyn fmt::Debug>`.
///
/// Tutte l'implementazioni di `Unsize` sò furnite automaticamente da u compilatore.
///
/// `Unsize` hè implementatu per:
///
/// - `[T; N]` hè `Unsize<[T]>`
/// - `T` hè `Unsize<dyn Trait>` quandu `T: Trait`
/// - `Foo<..., T, ...>` hè `Unsize<Foo<..., U, ...>>` se:
///   - `T: Unsize<U>`
///   - Foo hè una struct
///   - Solu l'ultimu campu di `Foo` hà un tipu chì implica `T`
///   - `T` ùn face micca parte di u tippu di altri campi
///   - `Bar<T>: Unsize<Bar<U>>`, se l'ultimu campu di `Foo` hà tippu `Bar<T>`
///
/// `Unsize` hè adupratu cù [`ops::CoerceUnsized`] per permette à i contenitori "user-defined" cum'è [`Rc`] di cuntene tippi di dimensioni dinamiche.
/// Vede u [DST coercion RFC][RFC982] è [the nomicon entry on coercion][nomicon-coerce] per più infurmazioni.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait Requisitu per e costanti aduprate in partite di schemi.
///
/// Ogni tippu chì derive `PartialEq` implementa automaticamente questu trait,*indipendentemente* da se i so parametri di tippu implementanu `Eq`.
///
/// Se un articulu `const` cuntene un tipu chì ùn implementa micca questu trait, allora quellu tippu sia (1.) ùn implementa micca `PartialEq` (chì significa chì a costante ùn furnisce micca quellu metudu di paragone, chì generazione di codice suppone hè dispunibile), o (2.) implementa *u so propiu* versione di `PartialEq` (chì supponemu chì ùn sia micca conforme à un paragone strutturale-parità).
///
///
/// In unu di i dui scenarii sopra, rifiutemu l'usu di una tale costante in un match match.
///
/// Vede ancu u [structural match RFC][RFC1445], è [issue 63438] chì hà motivatu a migrazione da u cuncepimentu basatu nantu à l'attributi à questu trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait Requisitu per e costanti aduprate in partite di schemi.
///
/// Ogni tipu chì deriva `Eq` implementa automaticamente questu trait,*indipendentemente* da se i so parametri di tippu implementanu `Eq`.
///
/// Questu hè un pirate per travaglià intornu à una limitazione in u nostru sistema di tippu.
///
/// # Background
///
/// Vulemu esigene chì i tipi di consts aduprati in partite di schemi anu l'attributu `#[derive(PartialEq, Eq)]`.
///
/// In un mondu più ideale, puderiamu verificà quellu esigenza solu verificendu chì u tippu datu implementi sia u `StructuralPartialEq` trait *sia* u `Eq` trait.
/// Tuttavia, pudete avè ADT chì *facenu*`derive(PartialEq, Eq)`, è esse un casu chì vulemu chì u compilatore accetta, eppuru u tippu di a costante ùn riesce micca à implementà `Eq`.
///
/// Vale à dì, un casu cusì:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (U prublema in u codice sopra hè chì `Wrap<fn(&())>` ùn implementa micca `PartialEq`, nè `Eq`, perchè `per <'a> fn(&'a _)` does not implement those traits.)
///
/// Dunque, ùn pudemu micca contà nantu à un cuntrollu ingenu per `StructuralPartialEq` è solu `Eq`.
///
/// Cum'è un pirate per travaglià intornu à questu, usamu dui traits separati iniettati da ciascuna di e duie derive (`#[derive(PartialEq)]` è `#[derive(Eq)]`) è verificemu chì entrambi sò presenti cum'è parte di u cuntrollu strutturale di partita.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Tipi chì i valori ponu esse duplicati semplicemente copendu bit.
///
/// Per impostazione predefinita, i ligami variabili anu "spostà a semantica".In altre parolle:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` s'hè trasferitu in `y`, è dunque ùn pò micca esse adupratu
///
/// // println! ("{: ?}", x);//errore: usu di u valore spustatu
/// ```
///
/// Tuttavia, se un tippu implementa `Copy`, hà invece 'copia di semantica':
///
/// ```
/// // Pudemu derivà una implementazione `Copy`.
/// // `Clone` hè ancu necessariu, perchè hè un supertrait di `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` hè una copia di `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Hè impurtante di nutà chì in questi dui esempi, l'unica differenza hè se site permessu di accede à `x` dopu l'assignazione.
/// Sottu à u cappucciu, sia una copia sia una mossa ponu fà copie di pezzi in memoria, ancu se questu hè qualchì volta ottimizatu.
///
/// ## Cumu possu implementà `Copy`?
///
/// Ci hè dui modi per implementà `Copy` nantu à u vostru tipu.U più simplice hè di aduprà `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Pudete ancu implementà `Copy` è `Clone` manualmente:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Ci hè una piccula differenza trà i dui: a strategia `derive` piazzerà ancu un `Copy` legatu à parametri di tippu, chì ùn hè micca sempre desideratu.
///
/// ## Chì ci hè a differenza trà `Copy` è `Clone`?
///
/// E copie accadenu implicitamente, per esempiu cum'è parte di un incaricu `y = x`.U cumpurtamentu di `Copy` ùn hè micca sovraccaricabile;hè sempre una copia simplici pocu sàviu.
///
/// A clonazione hè una azzione esplicita, `x.clone()`.L'implementazione di [`Clone`] pò furnisce qualsiasi cumpurtamentu specificu di tipu necessariu per duplicà i valori in modu sicuru.
/// Per esempiu, l'implementazione di [`Clone`] per [`String`] hà bisognu di cupià u buffer di stringa puntata in a mansa.
/// Una copia simplici à bit à bit di i valori [`String`] copierebbe solu u puntatore, purtendu à un doppiu liberu in a linea.
/// Per questa ragione, [`String`] hè [`Clone`] ma micca `Copy`.
///
/// [`Clone`] hè un supertrait di `Copy`, allora tuttu ciò chì hè `Copy` deve ancu implementà [`Clone`].
/// Se un tippu hè `Copy` allora a so implementazione [`Clone`] deve solu restituisce `*self` (vede l'esempiu di sopra).
///
/// ## Quandu u mo tippu pò esse `Copy`?
///
/// Un tippu pò implementà `Copy` se tutti i so cumpunenti implementanu `Copy`.Per esempiu, sta struttura pò esse `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Una struttura pò esse `Copy`, è [`i32`] hè `Copy`, dunque `Point` hè eligibile per esse `Copy`.
/// À u cuntrariu, cunsiderate
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// U struct `PointList` ùn pò micca implementà `Copy`, perchè [`Vec<T>`] ùn hè micca `Copy`.Se pruvemu à uttene una implementazione `Copy`, avemu un errore:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// E referenze cumune (`&T`) sò ancu `Copy`, dunque un tippu pò esse `Copy`, ancu quandu tene riferenze cumuni di tippi `T` chì ùn sò *micca*`Copy`.
/// Cunsiderate a struttura seguente, chì pò implementà `Copy`, perchè cuntene solu un *riferimentu cumunu* à u nostru tippu `PointList` chì ùn hè micca «Copia» da sopra:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Quandu *ùn pò* u mo tippu esse `Copy`?
///
/// Alcuni tippi ùn ponu micca esse copiati in modu sicuru.Per esempiu, cupià `&mut T` creerà una rifarenza mutevule alias.
/// Copià [`String`] duplica a responsabilità per a gestione di u buffer di [`String`], purtendu à un doppiu liberu.
///
/// Generalizendu l'ultimu casu, qualsiasi tippu chì implementa [`Drop`] ùn pò micca esse `Copy`, perchè gestisce qualchì risorsa oltre i so propri byte [`size_of::<T>`].
///
/// Se pruvate à implementà `Copy` nantu à una struttura o enum chì cuntene dati chì ùn sò micca "Copia", riceverete l'errore [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Quandu * u mo tippu deve esse `Copy`?
///
/// In generale, se u vostru tipu _can_ implementa `Copy`, deve.
/// Tenite à mente, però, chì l'implementazione di `Copy` face parte di l'API publica di u vostru tippu.
/// Se u tippu pò diventà micca "Copia" in u future, puderia esse prudente di omettere l'implementazione `Copy` avà, per evità un cambiamentu API rotante.
///
/// ## Implementatori addiziunali
///
/// In più di u [implementors listed below][impls], i tippi seguenti implementanu ancu `Copy`:
///
/// * Tipi d'elementi di funzione (ie, i tipi distinti definiti per ogni funzione)
/// * Tipi di puntatori di funzione (per esempiu, `fn() -> i32`)
/// * Tipi di matrici, per tutte e dimensioni, se u tipu d'articulu implementa ancu `Copy` (per esempiu, `[i32; 123456]`)
/// * Tipi di tupla, se ogni cumpunente implementa ancu `Copy` (per esempiu, `()`, `(i32, bool)`)
/// * Tipi di chjusura, se ùn catturanu micca valore da l'ambiente o se tutti questi valori catturati implementanu `Copy` stessi.
///   Nota chì e variabili catturate da riferenza cumuna implementanu sempre `Copy` (ancu se u riferente ùn), mentre e variabili catturate da riferenza mutevule ùn implementanu mai `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Questu permette di copià un tippu chì ùn implementa micca `Copy` per via di limiti di vita insoddisfatti (copià `A<'_>` quandu solu `A<'static>: Copy` è `A<'_>: Clone`).
// Avemu questu attributu quì per avà solu perchè ci sò abbastanza spezialità esistenti in `Copy` chì esistenu dighjà in a biblioteca standard, è ùn ci hè manera di avè stu comportamentu in modu sicuru in questu momentu.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Derive macro chì genera un impl di u trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tipi per i quali hè sicuru di sparte referenze trà filetti.
///
/// Questa trait hè automaticamente implementata quandu u compilatore determina chì hè adatta.
///
/// A definizione precisa hè: un tipu `T` hè [`Sync`] se è solu se `&T` hè [`Send`].
/// In altre parolle, se ùn ci hè micca pussibilità di [undefined behavior][ub] (cumprese e razze di dati) quandu passanu referenze `&T` trà filetti.
///
/// Cum'è omu si aspetterebbe, i tippi primitivi cum'è [`u8`] è [`f64`] sò tutti [`Sync`], è cusì sò simplici tippi aggregati chì li cuntenenu, cum'è tuple, structs è enums.
/// Più esempi di tippi [`Sync`] di basa includenu tippi "immutable" cum'è `&T`, è quelli cun mutabilità ereditata simplice, cum'è [`Box<T>`][box], [`Vec<T>`][vec] è a maiò parte di l'altri tippi di cullizzioni.
///
/// (I parametri generichi devenu esse [`Sync`] per chì u so contenitore sia [`Sync`].)
///
/// Una cunsequenza un pocu sorprendente di a definizione hè chì `&mut T` hè `Sync` (se `T` hè `Sync`) ancu se pare chì puderia furnisce una mutazione micca sincronizzata.
/// U truccu hè chì un riferimentu mutevule daretu à un riferimentu spartutu (vale à dì, `& &mut T`) diventa solu di lettura, cum'è s'ellu fussi un `& &T`.
/// Dunque ùn ci hè risicu di una corsa di dati.
///
/// Tipi chì ùn sò micca `Sync` sò quelli chì anu "interior mutability" in una forma micca sicura di filu, cum'è [`Cell`][cell] è [`RefCell`][refcell].
/// Sti tippi permettenu a mutazione di i so cuntenuti ancu attraversu un immutable, riferimentu cumunu.
/// Per esempiu u metudu `set` in [`Cell<T>`][cell] piglia `&self`, dunque richiede solu un riferimentu cumunu [`&Cell<T>`][cell].
/// U metudu ùn esegue micca sincronizazione, cusì [`Cell`][cell] ùn pò micca esse `Sync`.
///
/// Un altru esempiu di un tippu chì ùn hè micca `Sync` hè u puntatore [`Rc`][rc] chì conta u riferimentu.
/// Dà qualsiasi riferenza [`&Rc<T>`][rc], pudete clunà un novu [`Rc<T>`][rc], mudificendu i conti di riferenza in modu micca atomicu.
///
/// Per i casi quandu unu hà bisognu di mutabilità interiore sicura di fili, Rust furnisce [atomic data types], è ancu un bluccatu esplicitu via [`sync::Mutex`][mutex] è [`sync::RwLock`][rwlock].
/// Sti tippi assicuranu chì qualsiasi mutazione ùn possa micca causà razze di dati, dunque i tippi sò `Sync`.
/// In listessu modu, [`sync::Arc`][arc] furnisce un analogu di filu sicuru di [`Rc`][rc].
///
/// Ogni tippu cù mutabilità interiore deve ancu aduprà u involucru [`cell::UnsafeCell`][unsafecell] intornu à u value(s) chì pò esse mutatu per mezu di una riferenza cumuna.
/// Fallimentu à fà questu hè [undefined behavior][ub].
/// Per esempiu, [`transmute`][transmute]-ing da `&T` à `&mut T` hè invalidu.
///
/// Vede [the Nomicon][nomicon-send-and-sync] per più infurmazioni nantu à `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): una volta supportatu per aghjunghje note in `rustc_on_unimplemented` sbarcanu in beta, è hè statu allargatu per verificà se una chjusura hè in ogni locu in a catena di requisiti, allargalla cum'è (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Tipu di dimensioni zero usatu per marcà cose chì "act like" pussedenu un `T`.
///
/// Aghjunghjendu un campu `PhantomData<T>` à u vostru tippu dice à u compilatore chì u vostru tippu agisce cum'è se memorizessi un valore di tippu `T`, ancu s'ellu ùn hè micca veramente.
/// Questa informazione hè aduprata quandu si calculanu certe proprietà di sicurezza.
///
/// Per una spiegazione più approfondita di cumu aduprà `PhantomData<T>`, per piacè vede [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Una nota spaventosa 👻👻👻
///
/// Ancu tramindui anu nomi spaventosi, `PhantomData` è "tippi fantasma" sò parenti, ma micca identichi.Un parametru di tipu fantasma hè solu un parametru di tippu chì ùn hè mai adupratu.
/// In Rust, questu spessu face chì u compilatore si lagna, è a soluzione hè di aghjunghje un usu "dummy" per via di `PhantomData`.
///
/// # Examples
///
/// ## Parametri di vita inutilizati
///
/// Forse u casu d'usu più cumunu per `PhantomData` hè una struttura chì hà un parametru di vita inutilizatu, tipicamente cum'è parte di qualchì codice periculosu.
/// Per esempiu, eccu una struct `Slice` chì hà dui puntatori di tippu `*const T`, presumibilmente puntendu in un array in qualchì locu:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// L'intenzione hè chì i dati sottostanti sò validi solu per a vita `'a`, cusì `Slice` ùn deve micca supravvivere `'a`.
/// Tuttavia, sta intenzione ùn hè micca espressa in u codice, postu chì ùn ci sò micca usi di a vita `'a` è dunque ùn hè micca chjaru à chì dati si applica.
/// Pudemu correggerle dicendu à u compilatore di agisce *cum'è se* a struttura `Slice` cuntene un riferimentu `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Questu dinò richiede l'annotazione `T: 'a`, chì indica chì ogni riferenza in `T` hè valida per tutta a vita `'a`.
///
/// Quandu si inizializeghja un `Slice`, furnite solu u valore `PhantomData` per u campu `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Parametri di tippu inutilizatu
///
/// A volte accade chì avete parametri di tippu inutilizzati chì indicanu à chì tippu di dati una struct hè "tied", ancu se sti dati ùn si trovanu micca effettivamente in a struct stessa.
/// Eccu un esempiu induve questu nasce cù [FFI].
/// L'interfaccia straniera utilizza manichi di tipu `*mut ()` per riferisce à i valori Rust di diversi tipi.
/// Seguemu u tippu Rust aduprendu un parametru di tipu fantasma nantu à a struct `ExternalResource` chì avvolge una maniglia.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Proprietà è u cuntrollu di goccia
///
/// L'aggiunta di un campu di tippu `PhantomData<T>` indica chì u vostru tippu pussede dati di tippu `T`.A so volta implica chì quandu u vostru tipu hè abbandunatu, pò abbandunà una o più istanze di u tippu `T`.
/// Questu hà influenza annantu à l'analisi [drop check] di u compilatore Rust.
///
/// Se a vostra struttura ùn hà micca *pussessu* di i dati di u tippu `T`, hè megliu aduprà un tippu di riferimentu, cum'è `PhantomData<&'a T>` (ideally) o `PhantomData<*const T>` (se ùn si applica micca a vita), per ùn indicà micca a pruprietà.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// U compilatore-internu trait adupratu per indicà u tippu di discriminanti enum.
///
/// Questu trait hè automaticamente implementatu per ogni tippu è ùn aghjusta alcuna garanzia à [`mem::Discriminant`].
/// Hè **cumpurtamentu indefinitu** per trasmutà trà `DiscriminantKind::Discriminant` è `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// U tippu di discriminante, chì deve soddisfà u trait bounds richiestu da `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Cumpilatore-internu trait adupratu per determinà se un tippu cuntene alcunu `UnsafeCell` internamente, ma micca per mezu di una indiretta.
///
/// Questu affetta, per esempiu, se un `static` di quellu tippu hè piazzatu in memoria statica di sola lettura o in memoria statica scrivibile.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Tipi chì ponu esse spustati in modu sicuru dopu à esse appuntati.
///
/// Rust stessu ùn hà nisuna nuzione di tippi immubiliarii, è cunsidereghja chì e mosse (per esempiu, per mezu di assignazione o [`mem::replace`]) sò sempre sicure.
///
/// U tippu [`Pin`][Pin] hè adupratu invece per prevene movimenti attraversu u sistema di tippu.I Puntatori `P<T>` impannillati in u involucru [`Pin<P<T>>`][Pin] ùn ponu esse spustati fora.
/// Vede a documentazione [`pin` module] per più infurmazioni nantu à u pinning.
///
/// Implementà u `Unpin` trait per `T` alza e restrizioni di pinning off u tippu, chì permette allora di spostà `T` fora di [`Pin<P<T>>`][Pin] cù funzioni cum'è [`mem::replace`].
///
///
/// `Unpin` ùn hà nisuna cunsequenza per i dati micca appuntati.
/// In particulare, [`mem::replace`] move felice di dati `!Unpin` (funziona per qualsiasi `&mut T`, micca solu quandu `T: Unpin`).
/// Tuttavia, ùn pudete micca aduprà [`mem::replace`] nantu à i dati avvolti in un [`Pin<P<T>>`][Pin] perchè ùn pudete micca uttene u `&mut T` chì avete bisognu per quessa, è *hè* ciò chì face funzionà stu sistema.
///
/// Cusì, per esempiu, pò esse fattu solu nantu à tippi chì implementanu `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Avemu bisognu di una riferenza mutevule per chjamà `mem::replace`.
/// // Pudemu ottene una tale riferenza da (implicitly) invucendu `Pin::deref_mut`, ma questu hè pussibile solu perchè `String` implementa `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Questu trait hè automaticamente implementatu per quasi ogni tippu.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Un tipu marcatore chì ùn implementa micca `Unpin`.
///
/// Se un tipu cuntene un `PhantomPinned`, ùn implementerà micca `Unpin` per difettu.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementazioni di `Copy` per tippi primitivi.
///
/// Implementazioni chì ùn ponu micca esse descritte in Rust sò implementate in `traits::SelectionContext::copy_clone_conditions()` in `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// E referenze spartute ponu esse cupiate, ma e referenze mutevuli *ùn ponu*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}