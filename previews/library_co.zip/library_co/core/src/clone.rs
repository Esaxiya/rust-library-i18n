//! U `Clone` trait per tippi chì ùn ponu micca esse "implicitamente copiati".
//!
//! In Rust, certi tippi semplici sò "implicitly copyable" è quandu li assignate o li passanu cum'è argumenti, u destinatariu riceverà una copia, lascendu u valore originale in locu.
//! Sti tippi ùn necessitanu micca di allocazione per copià è ùn anu micca finalizatori (vale à dì, ùn cuntenenu micca scatule di pruprietà o implementanu [`Drop`]), dunque u compilatore li considera economici è sicuri da copià.
//!
//! Per altri tippi, e copie devenu esse esplicite, per cunvenzione implementendu u [`Clone`] trait è chjamendu u metudu [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Esempiu d'usu di basa:
//!
//! ```
//! let s = String::new(); // U tipu String implementa Clone
//! let copy = s.clone(); // cusì pudemu clonallu
//! ```
//!
//! Per implementà facilmente u Clone trait, pudete ancu aduprà `#[derive(Clone)]`.Esempiu:
//!
//! ```
//! #[derive(Clone)] // aghjustemu u Clone trait à Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // è avà a pudemu clunà!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Un trait cumunu per a capacità di duplicà esplicitamente un oggettu.
///
/// Diferente da [`Copy`] in quellu [`Copy`] hè implicitu è estremamente economicu, mentre chì `Clone` hè sempre esplicitu è pò o ùn pò micca esse caru.
/// Per rinfurzà queste caratteristiche, Rust ùn vi permette micca di reimplementà [`Copy`], ma pudete reimplementà `Clone` è eseguisce un codice arbitrariu.
///
/// Postu chì `Clone` hè più generale ch'è [`Copy`], pudete fà automaticamente qualcosa chì [`Copy`] sia `Clone` ancu.
///
/// ## Derivable
///
/// Questu trait pò esse adupratu cù `#[derive]` se tutti i campi sò `Clone`.L'implementazione `derive`d di [`Clone`] chjama [`clone`] in ogni campu.
///
/// [`clone`]: Clone::clone
///
/// Per una struttura generica, `#[derive]` implementa `Clone` condizionalmente aggiungendo `Clone` legato su parametri generici.
///
/// ```
/// // `derive` implementa Clone per Lettura<T>quandu T hè Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Cumu possu implementà `Clone`?
///
/// Tipi chì sò [`Copy`] duveranu avè una implementazione banale di `Clone`.Più formalmente:
/// se `T: Copy`, `x: T` è `y: &T`, allora `let x = y.clone();` hè equivalente à `let x = *y;`.
/// L'implementazioni manuali devenu esse attenti à difende st'invariante;in ogni modu, un codice periculosu ùn deve micca contà nantu à ellu per assicurà a sicurezza di a memoria.
///
/// Un esempiu hè una struttura generica tenendu un puntatore di funzione.In questu casu, l'implementazione di `Clone` ùn pò micca esse "derivata" d, ma pò esse implementata cum'è:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Implementatori addiziunali
///
/// In più di u [implementors listed below][impls], i tippi seguenti implementanu ancu `Clone`:
///
/// * Tipi d'elementi di funzione (ie, i tipi distinti definiti per ogni funzione)
/// * Tipi di puntatori di funzione (per esempiu, `fn() -> i32`)
/// * Tipi di matrici, per tutte e dimensioni, se u tipu d'articulu implementa ancu `Clone` (per esempiu, `[i32; 123456]`)
/// * Tipi di tupla, se ogni cumpunente implementa ancu `Clone` (per esempiu, `()`, `(i32, bool)`)
/// * Tipi di chjusura, se ùn catturanu micca valore da l'ambiente o se tutti questi valori catturati implementanu `Clone` stessi.
///   Nota chì e variabili catturate da riferenza cumuna implementanu sempre `Clone` (ancu se u riferente ùn), mentre e variabili catturate da riferenza mutevule ùn implementanu mai `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Restituisce una copia di u valore.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementa Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Esegue copia-assignazione da `source`.
    ///
    /// `a.clone_from(&b)` hè equivalente à `a = b.clone()` in funziunalità, ma pò esse annullatu per riutilizà e risorse di `a` per evità allocazioni inutili.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Derive macro chì genera un impl di u trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): queste strutt sò aduprate solu da#[derive] per affirmà chì ogni cumpunente di un tipu implementa Clone o Copia.
//
//
// Queste strutture ùn devenu mai cumparisce in u codice di l'utente.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementazioni di `Clone` per tippi primitivi.
///
/// Implementazioni chì ùn ponu micca esse descritte in Rust sò implementate in `traits::SelectionContext::copy_clone_conditions()` in `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// E referenze cumune ponu esse clonate, ma e referenze mutevuli *ùn ponu*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// E referenze cumune ponu esse clonate, ma e referenze mutevuli *ùn ponu*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}