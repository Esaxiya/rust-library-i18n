use crate::marker::Unsize;

/// Trait chì indica chì questu hè un puntatore o un involucru per unu, induve a dimensione pò esse eseguita nantu à u puntu.
///
/// Vede u [DST coercion RFC][dst-coerce] è [the nomicon entry on coercion][nomicon-coerce] per più infurmazioni.
///
/// Per i tippi di puntatori integrati, i puntatori à `T` coerceranu à i puntatori à `U` se `T: Unsize<U>` cunvertendu da un puntatore finu à un puntatore grassu.
///
/// Per i tippi persunalizati, a coercizione funziona quì coercendu `Foo<T>` à `Foo<U>` furnitu un impl di `CoerceUnsized<Foo<U>> for Foo<T>` esiste.
/// Un tali implice pò esse scrittu solu se `Foo<T>` hà solu un campu di dati non phantomdata chì implica `T`.
/// Se u tippu di quellu campu hè `Bar<T>`, una implementazione di `CoerceUnsized<Bar<U>> for Bar<T>` deve esiste.
/// A coercizione funzionerà coercendu u campu `Bar<T>` in `Bar<U>` è riempendu u restu di i campi da `Foo<T>` per creà un `Foo<U>`.
/// Questu ferà in modu efficace in un campu di puntatore è furzerà quellu.
///
/// Generalmente, per i puntatori intelligenti implementerete `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, cun un `?Sized` opzionale legatu à `T` stessu.
/// Per i tipi di involucri chì integranu direttamente `T` cum'è `Cell<T>` è `RefCell<T>`, pudete implementà direttamente `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Questu permetterà e coercizioni di tippi cum'è `Cell<Box<T>>` di travaglià.
///
/// [`Unsize`][unsize] hè adupratu per marcà tippi chì ponu esse coerciti à DSTs se daretu à i puntatori.Hè implementatu automaticamente da u compilatore.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Questu hè adupratu per a sicurezza di l'oggetti, per verificà chì u tippu di ricevitore di un metudu pò esse speditu.
///
/// Un esempiu di implementazione di u trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}