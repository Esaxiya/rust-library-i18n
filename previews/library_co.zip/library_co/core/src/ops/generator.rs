use crate::marker::Unpin;
use crate::pin::Pin;

/// U risultatu di una ripresa di u generatore.
///
/// Questa enum hè restituita da u metudu `Generator::resume` è indica i valori di ritornu pussibuli di un generatore.
/// Attualmente questu currisponde à un puntu di sospensione (`Yielded`) o à un puntu di terminazione (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// U generatore suspesu cù un valore.
    ///
    /// Stu statu indica chì un generatore hè statu suspesu, è currisponde tipicamente à una dichjarazione `yield`.
    /// U valore furnitu in sta variante currisponde à l'espressione passata à `yield` è permette à i generatori di furnisce un valore ogni volta chì rendenu.
    ///
    ///
    Yielded(Y),

    /// U generatore cumpletatu cù un valore di ritornu.
    ///
    /// Questu statu indica chì un generatore hà finitu l'esecuzione cù u valore furnitu.
    /// Una volta chì un generatore hà tornatu `Complete` hè cunsideratu un errore di prugrammatore per chjamà `resume` di novu.
    ///
    Complete(R),
}

/// U trait implementatu da tippi di generatori integrati.
///
/// I Generatori, chjamati ancu currutti, sò attualmente una caratteristica di lingua sperimentale in Rust.
/// Aggiunti in i generatori [RFC 2033] sò attualmente destinati à furnisce principalmente un blocu di custru per a sintassi async/await ma probabilmente si estenderà ancu à furnisce una definizione ergonomica per iteratori è altri primitivi.
///
///
/// A sintassi è a semantica per i generatori sò instabili è richiederanu un ulteriore RFC per a stabilizazione.A stu mumentu, però, a sintassi hè simile à a chjusura:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Più documentazione di generatori si pò truvà in u libru instabile.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// U tippu di valore chì dà stu generatore.
    ///
    /// Stu tipu assuciatu currisponde à l'espressione `yield` è i valori chì sò permessi di esse restituiti ogni volta chì un generatore cede.
    ///
    /// Per esempiu un iteratore-cum'è-generatore avaria probabilmente stu tippu cum'è `T`, u tippu essendu iteratu sopra.
    ///
    type Yield;

    /// U tippu di valore chì rende questu generatore.
    ///
    /// Questu currisponde à u tippu restituitu da un generatore sia cù una dichjarazione `return` sia implicitamente cum'è l'ultima espressione di un generatore letterale.
    /// Per esempiu futures aduprà questu cum'è `Result<T, E>` perchè rapprisenta un future cumpletu.
    ///
    ///
    type Return;

    /// Riprende l'esecuzione di stu generatore.
    ///
    /// Sta funzione ripiglierà l'esecuzione di u generatore o principierà l'esecuzione s'ellu ùn hè micca dighjà.
    /// Questa chjamata tornerà in l'ultimu puntu di sospensione di u generatore, riprendendu l'esecuzione da l'ultimu `yield`.
    /// U generatore continuerà à esecutà finu à chì cede o rende, à chì puntu sta funzione tornerà.
    ///
    /// # Valore di ritornu
    ///
    /// L'enumariu `GeneratorState` restituitu da sta funzione indica in chì statu si trova u generatore à u ritornu.
    /// Se a variante `Yielded` hè restituita allora u generatore hà righjuntu un puntu di sospensione è un valore hè statu cedutu.
    /// I generatori in questu statu sò dispunibuli per a ripresa in un puntu dopu.
    ///
    /// Se `Complete` hè restituitu allora u generatore hè finitu cumpletamente cù u valore furnitu.Ùn hè micca validu per u generatore per esse ripresu di novu.
    ///
    /// # Panics
    ///
    /// Questa funzione pò panic se hè chjamata dopu chì a variante `Complete` sia stata restituita prima.
    /// Mentre i literali generatori in a lingua sò garantiti à panic à a ripresa dopu `Complete`, questu ùn hè micca garantitu per tutte l'implementazioni di u `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}