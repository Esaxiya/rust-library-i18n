/// Adupratu per operazioni immutabili di deriferenziazione, cum'è `*v`.
///
/// Oltre à esse adupratu per operazioni di dereferenziazione esplicite cù l'operatore (unary) `*` in contesti immutabili, `Deref` hè ancu usatu implicitamente da u compilatore in parechje circustanze.
/// Stu mecanismu hè chjamatu ['`Deref` coercion'][more].
/// In cuntesti mutevuli, [`DerefMut`] hè adupratu.
///
/// L'implementazione di `Deref` per i puntatori intelligenti facilita l'accessu à i dati daretu à elli, hè per quessa chì implementanu `Deref`.
/// D'altra parte, e regule riguardanti `Deref` è [`DerefMut`] sò state cuncipite specificamente per accoglie puntatori intelligenti.
/// Per via di questu,**"Deref" deve esse implementatu solu per i puntatori intelligenti** per evità cunfusioni.
///
/// Per ragioni simili,**questu trait ùn deve mai fallisce**.Fallimentu durante a dereferenziazione pò esse estremamente confusu quandu `Deref` hè invucatu implicitamente.
///
/// # Più infurmazione nantu à a coercizione `Deref`
///
/// Se `T` implementa `Deref<Target = U>`, è `x` hè un valore di tipu `T`, allora:
///
/// * In cuntesti immutabili, `*x` (induve `T` ùn hè nè una riferenza nè un puntatore grezzu) hè equivalente à `* Deref::deref(&x)`.
/// * I valori di u tippu `&T` sò coerciti à i valori di u tippu `&U`
/// * `T` implementa implicitamente tutti i metudi (immutable) di u tippu `U`.
///
/// Per più infurmazioni, visitate [the chapter in *The Rust Programming Language*][book] è ancu e sezioni di riferimentu in [the dereference operator][ref-deref-op], [method resolution] è [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Una struct cun un campu unicu chì hè accessibile deriferenzendu a struct.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// U tippu resultante dopu a dereferenzazione.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Diferenze u valore.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Adupratu per operazioni di dereferenziazione mutevuli, cum'è in `*v = 1;`.
///
/// Oltre à esse adupratu per operazioni di dereferenziazione esplicite cù l'operatore (unary) `*` in contesti mutevuli, `DerefMut` hè ancu usatu implicitamente da u compilatore in parechje circustanze.
/// Stu mecanismu hè chjamatu ['`Deref` coercion'][more].
/// In contesti immutabili, [`Deref`] hè adupratu.
///
/// L'implementazione di `DerefMut` per i puntatori intelligenti face a mutazione di i dati daretu à elli cunvenienti, eccu perchè implementanu `DerefMut`.
/// D'altra parte, e regule riguardanti [`Deref`] è `DerefMut` sò state cuncipite specificamente per accoglie puntatori intelligenti.
/// Per via di questu,**"DerefMut" deve esse implementatu solu per i puntatori intelligenti** per evità cunfusioni.
///
/// Per ragioni simili,**questu trait ùn deve mai fallisce**.Fallimentu durante a dereferenziazione pò esse estremamente confusu quandu `DerefMut` hè invucatu implicitamente.
///
/// # Più infurmazione nantu à a coercizione `Deref`
///
/// Se `T` implementa `DerefMut<Target = U>`, è `x` hè un valore di tipu `T`, allora:
///
/// * In cuntesti mutevuli, `*x` (induve `T` ùn hè nè una riferenza nè un puntatore grezzu) hè equivalente à `* DerefMut::deref_mut(&mut x)`.
/// * I valori di u tippu `&mut T` sò coerciti à i valori di u tippu `&mut U`
/// * `T` implementa implicitamente tutti i metudi (mutable) di u tippu `U`.
///
/// Per più infurmazioni, visitate [the chapter in *The Rust Programming Language*][book] è ancu e sezioni di riferimentu in [the dereference operator][ref-deref-op], [method resolution] è [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Una struct cù un campu unicu chì si pò mudificà deriferenzendu a struct.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Mutualmente deriferisce u valore.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Indica chì una struttura pò esse usata cum'è ricettore di metudu, senza a funzione `arbitrary_self_types`.
///
/// Questu hè implementatu da tippi di puntatore stdlib cum'è `Box<T>`, `Rc<T>`, `&T` è `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}