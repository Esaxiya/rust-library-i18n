//! Operatori sovraccaricabili.
//!
//! L'implementazione di sti traits vi permette di sovraccaricà certi operatori.
//!
//! Alcuni di sti traits sò impurtati da u prelude, allora sò dispunibili in ogni prugramma Rust.Solu l'operatori sustinuti da traits ponu esse sovraccaricati.
//! Per esempiu, l'operatore d'addizione (`+`) pò esse sovraccaricatu attraversu u [`Add`] trait, ma postu chì l'operatore di assignazione (`=`) ùn hà micca appoghju trait, ùn ci hè manera di sovraccaricà a so semantica.
//! Inoltre, stu modulu ùn furnisce micca un mecanismu per creà novi operatori.
//! Se un sovraccaricu senza caratteri o operatori persunalizati sò richiesti, duvete guardà versu macros o plugins di compilatore per allargà a sintassi di Rust.
//!
//! L'implementazioni di l'operatore traits ùn devenu micca sorprendenti in i so rispettivi contesti, tenendu à mente i so significati abituali è [operator precedence].
//! Per esempiu, quandu si implementa [`Mul`], l'operazione duveria avè qualchì similitudine cù a multiplicazione (è sparte e pruprietà previste cum'è l'associatività).
//!
//! Innota chì l'operatori `&&` è `||` cortocircuitu, vale à dì, valutanu u so secondu operandu solu s'ellu cuntribuisce à u risultatu.Siccomu stu cumpurtamentu ùn hè micca applicabile da traits, `&&` è `||` ùn sò micca supportati cum'è operatori sovraccaricabili.
//!
//! Parechji di l'operatori piglianu i so operandi per valore.In contesti non generici chì implicanu tippi integrati, di solitu ùn hè micca un prublema.
//! Tuttavia, l'usu di questi operatori in codice genericu, richiede qualchì attenzione se i valori anu da esse riutilizzati invece di lascià l'operatori cunsumalli.Una opzione hè di aduprà occasionalmente [`clone`].
//! Un'altra opzione hè di fidà si à i tippi implicati chì furniscenu implementazioni supplementari di l'operatore per e referenze.
//! Per esempiu, per un tipu `T` definitu da l'utilizatore chì si suppone di sustene l'addizione, hè probabilmente una bona idea d'avè tramindui `T` è `&T` implementanu u traits [`Add<T>`][`Add`] è [`Add<&T>`][`Add`] in modu chì u codice genericu pò esse scrittu senza clonazione inutile.
//!
//!
//! # Examples
//!
//! Questu esempiu crea una struttura `Point` chì implementa [`Add`] è [`Sub`], è dopu dimostra di aghjunghje è sottrae dui `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Vede a documentazione per ogni trait per un esempiu di implementazione.
//!
//! U [`Fn`], [`FnMut`] è [`FnOnce`] traits sò implementati per tippi chì ponu esse invocati cum'è funzioni.Nota chì [`Fn`] piglia `&self`, [`FnMut`] piglia `&mut self` è [`FnOnce`] piglia `self`.
//! Quessi currispondenu à i trè tippi di metudi chì ponu esse invucati nantu à un'istanza: chjamata per riferenza, chjamata per mutabile-riferenza, è chjamata per valore.
//! L'usu più cumunu di questi traits hè di agisce cum'è limiti per funzioni di livellu più altu chì piglianu funzioni o chjusure cum'è argumenti.
//!
//! Pigliate un [`Fn`] cum'è parametru:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Pigliate un [`FnMut`] cum'è parametru:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Pigliate un [`FnOnce`] cum'è parametru:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` cunsuma e so variabili catturate, dunque ùn pò esse lanciata più d'una volta
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Tentà d'invucà `func()` torna à lancià un errore `use of moved value` per `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ùn pò più esse invucatu à questu puntu
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;