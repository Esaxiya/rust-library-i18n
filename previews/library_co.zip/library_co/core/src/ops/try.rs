/// Un trait per persunalizà u cumpurtamentu di l'operatore `?`.
///
/// Un tippu chì implementa `Try` hè quellu chì hà un modu canonicu per vedelu in termini di una dicotomia success/failure.
/// Questu trait permette sia di estrarre quelli valori di successu o fallimentu da un'istanza esistente sia di creà una nova istanza da un valore di successu o fallimentu.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// U tippu di questu valore quandu si vede cum'è successu.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// U tippu di questu valore quandu si vede cum'è fallitu.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Applica l'operatore "?".Un ritornu di `Ok(t)` significa chì l'esekuzione deve cuntinuà nurmalmente, è u risultatu di `?` hè u valore `t`.
    /// Un ritornu di `Err(e)` significa chì l'esekzione deve branch à u `catch` più chjusu, o vultà da a funzione.
    ///
    /// Se un risultu `Err(e)` hè restituitu, u valore `e` serà "wrapped" in u tippu di ritornu di l'ambitu chjusu (chì deve esse ellu stessu implementà `Try`).
    ///
    /// Specificamente, u valore `X::from_error(From::from(e))` hè restituitu, induve `X` hè u tippu di ritornu di a funzione acclusa.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Avvolge un valore d'errore per custruisce u risultatu compositu.
    /// Per esempiu, `Result::Err(x)` è `Result::from_error(x)` sò equivalenti.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Avvolge un valore OK per custruisce u risultatu cumpostu.
    /// Per esempiu, `Result::Ok(x)` è `Result::from_ok(x)` sò equivalenti.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}