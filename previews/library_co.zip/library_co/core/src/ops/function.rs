/// A versione di l'operatore di chjamata chì piglia un receptore immutabile.
///
/// L'istanze di `Fn` ponu esse chjamate ripetutamente senza statu mutante.
///
/// *Questu trait (`Fn`) ùn deve micca esse cunfusu cù [function pointers] (`fn`).*
///
/// `Fn` hè implementatu automaticamente da chjusi chì piglianu solu riferimenti immutabili à variabili catturate o ùn catturanu nunda, è ancu (safe) [function pointers] (cun alcune avvertenze, vedi a so documentazione per più dettagli).
///
/// Inoltre, per ogni tipu `F` chì implementa `Fn`, `&F` implementa `Fn`, ancu.
///
/// Siccome [`FnMut`] è [`FnOnce`] sò supertraits di `Fn`, qualsiasi istanza di `Fn` pò esse usata cum'è parametru induve si prevede un [`FnMut`] o [`FnOnce`].
///
/// Aduprate `Fn` cum'è ligatu quandu vulete accettà un parametru di tippu funziunale è avete bisognu di chjamallu ripetutamente è senza statu mutante (per esempiu, quandu u chjamate simultaneamente).
/// Se ùn avete micca bisognu di tali esigenze strette, aduprate [`FnMut`] o [`FnOnce`] cum'è limiti.
///
/// Vede u [chapter on closures in *The Rust Programming Language*][book] per alcuni più infurmazioni nantu à questu tema.
///
/// Da nutà dinò a sintassi speciale per `Fn` traits (es
/// `Fn(usize, bool) -> usize`).Quelli chì sò interessati à i dettagli tecnichi di questu ponu riferisce à [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Chjamendu una chjusura
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Utilizendu un parametru `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // cusì chì regex pò cuntà quellu `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Eseguisce l'operazione di chjamata.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// A versione di l'operatore di chjamata chì pigghia un receptore mutable.
///
/// L'istanze di `FnMut` ponu esse chjamate ripetutamente è ponu mutà di statu.
///
/// `FnMut` hè implementatu automaticamente da chjusi chì piglianu riferenze mutevuli à variabili catturate, è ancu tutti i tippi chì implementanu [`Fn`], per esempiu, (safe) [function pointers] (postu chì `FnMut` hè un supertrait di [`Fn`]).
/// Inoltre, per ogni tipu `F` chì implementa `FnMut`, `&mut F` implementa `FnMut`, ancu.
///
/// Postu chì [`FnOnce`] hè un supertrait di `FnMut`, qualsiasi istanza di `FnMut` pò esse aduprata induve si prevede un [`FnOnce`], è postu chì [`Fn`] hè un subtrettu di `FnMut`, qualsiasi istanza di [`Fn`] pò esse aduprata induve `FnMut` hè previstu.
///
/// Aduprate `FnMut` cum'è ligatu quandu vulete accettà un parametru di tipu simile à a funzione è avete bisognu di chjamallu ripetutamente, puru permettendu di mutà u statu.
/// Se ùn vulete micca chì u paràmetru mute u statu, utilizate [`Fn`] cum'è ligatu;sè ùn avete bisognu di chjamallu ripetutamente, aduprate [`FnOnce`].
///
/// Vede u [chapter on closures in *The Rust Programming Language*][book] per alcuni più infurmazioni nantu à questu tema.
///
/// Da nutà dinò a sintassi speciale per `Fn` traits (es
/// `Fn(usize, bool) -> usize`).Quelli chì sò interessati à i dettagli tecnichi di questu ponu riferisce à [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Chjamendu una chjusura mutualmente catturante
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Utilizendu un parametru `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // cusì chì regex pò cuntà quellu `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Eseguisce l'operazione di chjamata.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// A versione di l'operatore di chjamata chì piglia un ricevitore di valore.
///
/// L'istanze di `FnOnce` ponu esse chjamate, ma puderebbenu esse chjamabili più volte.Per via di questu, se l'unica cosa cunnisciuta nantu à un tipu hè chì implementa `FnOnce`, pò esse chjamatu solu una volta.
///
/// `FnOnce` hè messu in opera in autumàticu da e chjuse chì puderebbenu cunsumà variabili catturate, è ancu tutti i tippi chì implementanu [`FnMut`], per esempiu, (safe) [function pointers] (postu chì `FnOnce` hè un supertrait di [`FnMut`]).
///
///
/// Siccome [`Fn`] è [`FnMut`] sò sottotraiti di `FnOnce`, qualsiasi istanza di [`Fn`] o [`FnMut`] pò esse aduprata induve si prevede un `FnOnce`.
///
/// Aduprate `FnOnce` cum'è ligatu quandu vulete accettà un parametru di tipu simile à a funzione è avete bisognu solu di chjamallu una volta.
/// Se avete bisognu di chjamà u parametru ripetutamente, aduprate [`FnMut`] cum'è un ligatu;se ne avete ancu bisognu per ùn mutà u statu, aduprate [`Fn`].
///
/// Vede u [chapter on closures in *The Rust Programming Language*][book] per alcuni più infurmazioni nantu à questu tema.
///
/// Da nutà dinò a sintassi speciale per `Fn` traits (es
/// `Fn(usize, bool) -> usize`).Quelli chì sò interessati à i dettagli tecnichi di questu ponu riferisce à [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Utilizendu un parametru `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` cunsuma e so variabili catturate, dunque ùn pò esse lanciata più d'una volta.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Tentativu d'invucà `func()` torna à lancià un errore `use of moved value` per `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ùn pò più esse invucatu à questu puntu
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // cusì chì regex pò cuntà quellu `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// U tippu restituitu dopu l'operatore di chjamata hè adupratu.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Eseguisce l'operazione di chjamata.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}