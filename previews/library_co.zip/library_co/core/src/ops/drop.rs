/// Codice persunalizatu in u distruttore.
///
/// Quandu un valore ùn hè più necessariu, Rust eseguirà un "destructor" nantu à quellu valore.
/// U modu più cumunu chì un valore ùn hè più necessariu hè quandu esce fora di portata.I distruttori ponu ancu esse in altre circustanze, ma ci concentreremu nantu à a portata di l'esempii quì.
/// Per amparà nantu à alcuni di questi altri casi, per piacè vede a sezione [the reference] nantu à i distruttori.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Stu distruttore hè cumpostu di duie cumpunenti:
/// - Una chjamata à `Drop::drop` per quellu valore, se stu `Drop` trait speciale hè implementatu per u so tippu.
/// - U "drop glue" generatu automaticamente chì chjama ricursivamente i distruttori di tutti i campi di stu valore.
///
/// Cum'è Rust chjama automaticamente i distruttori di tutti i campi cuntenuti, ùn avete micca da implementà `Drop` in a maiò parte di i casi.
/// Ma ci sò certi casi induve hè utile, per esempiu per i tippi chì gestiscenu direttamente una risorsa.
/// Questa risorsa pò esse memoria, pò esse un descrittore di file, pò esse una presa di rete.
/// Una volta chì un valore di quellu tippu ùn serà più adupratu, deve "clean up" a so risorsa liberendu a memoria o chjudendu u fugliale o u socket.
/// Questu hè u travagliu di un distruttore, è dunque u travagliu di `Drop::drop`.
///
/// ## Examples
///
/// Per vede i distruttori in azzione, fighjemu u prugramma seguente:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust chjamerà prima `Drop::drop` per `_x` è dopu per `_x.one` è `_x.two`, vale à dì chì eseguendu questu stamperà
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Ancu se eliminemu l'implementazione di `Drop` per `HasTwoDrop`, i distruttori di i so campi sò sempre chjamati.
/// Questu resulterebbe
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Ùn pudete micca chjamà `Drop::drop` voi stessu
///
/// Perchè `Drop::drop` hè adupratu per pulì un valore, pò esse periculosu di aduprà stu valore dopu chì u metudu sia statu chjamatu.
/// Cum'è `Drop::drop` ùn piglia micca a pruprietà di u so input, Rust impedisce u sbagliu ùn vi permettenu micca di chjamà `Drop::drop` direttamente.
///
/// In altre parolle, se avete pruvatu à chjamà esplicitamente `Drop::drop` in l'esempiu di sopra, riceverete un errore di compilatore.
///
/// Se vulete chjamà esplicitamente u distruttore di un valore, [`mem::drop`] pò esse adupratu invece.
///
/// [`mem::drop`]: drop
///
/// ## Ordine di goccia
///
/// Quale hè unu di i nostri dui `HasDrop` prima?Per e strutture, hè u listessu ordine chì sò dichjarati: prima `one`, dopu `two`.
/// Se vulete pruvà questu stessu, pudete mudificà `HasDrop` sopra per cuntene alcuni dati, cum'è un numeru interu, è poi aduprallu in `println!` in `Drop`.
/// Stu cumpurtamentu hè guarantitu da a lingua.
///
/// A cuntrariu di e strutture, e variabili lucali sò calate in ordine inversu:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Questu serà stampatu
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Per piacè vede [the reference] per e regule complete.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` è `Drop` sò esclusivi
///
/// Ùn pudete micca implementà tramindui [`Copy`] è `Drop` nantu à u listessu tipu.Tipi chì sò `Copy` sò implicitamente duplicati da u compilatore, rendendu assai difficiule di prevede quandu, è quantu volte i distruttori saranu eseguiti.
///
/// Cusì, sti tipi ùn ponu micca avè distruttori.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Esegue u distruttore per stu tippu.
    ///
    /// Stu metudu hè chjamatu implicitamente quandu u valore esce da u scopu, è ùn pò micca esse chjamatu esplicitamente (questu hè l'errore di compilatore [E0040]).
    /// Tuttavia, a funzione [`mem::drop`] in u prelude pò esse aduprata per chjamà l'implementazione `Drop` di l'argumentu.
    ///
    /// Quandu stu metudu hè statu chjamatu, `self` ùn hè ancu statu disassignatu.
    /// Ciò accade solu dopu chì u metudu sia finitu.
    /// S'ellu ùn era micca u casu, `self` seria una riferenza pendente.
    ///
    /// # Panics
    ///
    /// Datu chì un [`panic!`] chjamerà `drop` mentre si rilassa, qualsiasi [`panic!`] in una implementazione `drop` probabilmente aborterà.
    ///
    /// Innota chì ancu se questu panics, u valore hè cunsideratu chì hè abbandunatu;
    /// ùn duvete micca fà chjamà `drop` di novu.
    /// Questu hè normalmente trattatu automaticamente da u compilatore, ma quandu si usa un codice periculosu, pò accade qualchì volta involuntariamente, in particulare quandu si usa [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}