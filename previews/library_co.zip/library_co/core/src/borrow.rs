//! Un modulu per travaglià cù dati in prestitu.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait per imprestà dati.
///
/// In Rust, hè cumunu di furnisce diverse riprisentazioni di un tippu per i diversi casi d'usu.
/// Per esempiu, u locu di almacenamentu è a gestione per un valore ponu esse specificamente scelti cume adatti per un usu particulare via tippi di puntatori cum'è [`Box<T>`] o [`Rc<T>`].
/// Al di là di questi involucri generici chì ponu esse aduprati cù qualsiasi tippu, alcuni tippi furniscenu facette opzionali chì furniscenu funzionalità potenzialmente costose.
/// Un esempiu per un tale tipu hè [`String`] chì aghjusta a capacità di allargà una stringa à u [`str`] di basa.
/// Questu richiede di mantene l'infurmazioni supplementari inutili per una stringa simplice, immutabile.
///
/// Questi tipi furniscenu l'accessu à i dati sottostanti per mezu di riferimenti à u tippu di questi dati.Si dice chì sò "imprestati cum'è" quellu tippu.
/// Per esempiu, un [`Box<T>`] pò esse pigliatu in prestu cum'è `T` mentre un [`String`] pò esse pigliatu in prestu cum'è `str`.
///
/// I tipi esprimenu chì ponu esse presi in prestitu cum'è qualchì tippu `T` implementendu `Borrow<T>`, dendu una riferenza à un `T` in u metudu [`borrow`] di trait.Un tippu hè liberu di imprestà cum'è parechji tippi diversi.
/// Se vole mutà in prestitu cum'è u tippu-permettendu a mudificazione di i dati sottostanti, pò ancu implementà [`BorrowMut<T>`].
///
/// Inoltre, quandu furnisce implementazioni per traits supplementari, deve esse cunsideratu se duverebbe comportassi identicu à quelli di u tippu sottostante in cunsequenza di agisce cum'è una rappresentazione di quellu tippu sottostante.
/// U codice genericu tipicamente usa `Borrow<T>` quandu si basa nantu à u cumpurtamentu identicu di queste implementazioni supplementari trait.
/// Queste traits appariranu probabilmente cum'è trait bounds supplementari.
///
/// In particulare `Eq`, `Ord` è `Hash` devenu esse equivalenti per i valori presi in prestitu è di pruprietà: `x.borrow() == y.borrow()` deve dà u listessu risultatu cum'è `x == y`.
///
/// Se u codice genericu hà solu bisognu di travaglià per tutti i tipi chì ponu furnisce una riferenza à u tippu cunnessu `T`, hè spessu megliu aduprà [`AsRef<T>`] chì più tippi ponu implementallu in modu sicuru.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Cum'è una raccolta di dati, [`HashMap<K, V>`] possede sia chiavi sia valori.Se i dati attuali di a chjave sò avvolti in un tipu di gestione di qualchì tipu, duverebbe, tuttavia, esse sempre pussibule di circà un valore aduprendu una riferenza à i dati di a chjave.
/// Per esempiu, se a chjave hè una stringa, allora hè probabilmente archiviata cù a mappa hash cum'è [`String`], mentre deve esse pussibule circà cù un [`&str`][`str`].
/// Cusì, `insert` hà bisognu di operà nantu à un `String` mentre `get` hà bisognu di pudè aduprà un `&str`.
///
/// Un pocu simplificatu, e parti pertinenti di `HashMap<K, V>` parenu cusì:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // campi omessi
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Tutta a mappa hash hè generica nantu à un tipu chjave `K`.Perchè queste chjave sò almacenate cù a mappa hash, stu tippu deve pussede i dati di a chjave.
/// Quandu si inserisce una coppia valore-chiave, a mappa hè data un tale `K` è hà bisognu di truvà u bucket di hash currettu è verificà se a chjave hè dighjà presente basatu annantu à quellu `K`.Richiede dunque `K: Hash + Eq`.
///
/// Tuttavia, quandu si cerca un valore in a carta, avè da furnisce una riferenza à un `K` cume a chjave da circà richiederebbe sempre di creà un valore tale.
/// Per e chjave di stringa, questu significava un valore `String` deve esse creatu solu per a ricerca di casi induve solu un `str` hè dispunibule.
///
/// Invece, u metudu `get` hè genericu annantu à u tippu di dati chjave sottostanti, chjamatu `Q` in a firma di u metudu sopra.Indica chì `K` prende in prestitu cum'è `Q` richiedendu quellu `K: Borrow<Q>`.
/// Richiedendu in più `Q: Hash + Eq`, segnala u requisitu chì `K` è `Q` anu implementazioni di `Hash` è `Eq` traits chì producenu risultati identici.
///
/// L'implementazione di `get` si basa in particulare in implementazioni identiche di `Hash` determinendu u bucket hash di a chjave chjamendu `Hash::hash` nantu à u valore `Q` ancu se hà inseritu a chjave basata annantu à u valore hash calculatu da u valore `K`.
///
///
/// Di conseguenza, a mappa hash si rompe se un `K` avvolgente un valore `Q` produce un hash diversu da `Q`.Per esempiu, immaginate chì avete un tippu chì avvolge una stringa ma confronta lettere ASCII ignorendu u so casu:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Perchè dui valori uguali necessitanu di pruduce u listessu valore hash, l'implementazione di `Hash` hà bisognu ancu di ignorà u casu ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Pudete `CaseInsensitiveString` implementà `Borrow<str>`?Certamente pò furnisce una riferenza à una fetta di stringa per mezu di a so stringa cuntenuta.
/// Ma perchè a so implementazione `Hash` differisce, si comporta in modu diversu da `str` è dunque ùn deve micca, in realtà, implementà `Borrow<str>`.
/// Se vole permettà à l'altri l'accessu à u `str` sottostante, pò fà ciò via `AsRef<str>` chì ùn porta micca esigenze in più.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Impresta immutabilmente da un valore di pruprietà.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait per mutualmente imprestà dati.
///
/// Cum'è cumpagnu di [`Borrow<T>`] questu trait permette à un tippu di piglià in prestitu cum'è tippu sottostante furnendu una riferenza mutabile.
/// Vede [`Borrow<T>`] per più infurmazione nantu à u prestitu cum'è un altru tipu.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Prende mutualmente da un valore di pruprietà.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}