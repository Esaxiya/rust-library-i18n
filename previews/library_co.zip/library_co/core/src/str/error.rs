//! Definisce u tippu d'errore utf8.

use crate::fmt;

/// Errori chì ponu accade quandu si prova à interpretà una sequenza di [`u8`] cum'è una stringa.
///
/// Cusì, a famiglia `from_utf8` di funzioni è metudi per tramindui [`String`] s è [`&str`] s facenu usu di st'errore, per esempiu.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// I metudi di stu tippu d'errore ponu esse aduprati per creà funzionalità simili à `String::from_utf8_lossy` senza attribuisce memoria memoria:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Restituisce l'indice in a stringa data finu à chì UTF-8 validu hè statu verificatu.
    ///
    /// Hè l'indice massimu tale chì `from_utf8(&input[..index])` restituverà `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// use std::str;
    ///
    /// // qualchi bytes invalidi, in un vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 restituisce un Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // u secondu byte hè invalidu quì
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Offre più informazioni nantu à u fallimentu:
    ///
    /// * `None`: a fine di l'input hè stata ghjunta inaspettatamente.
    ///   `self.valid_up_to()` hè da 1 à 3 byte da a fine di l'input.
    ///   Se un flussu di byte (cum'è un fugliale o un socket di rete) hè decodificatu incrementalmente, questu puderia esse un `char` validu chì a so sequenza di byte UTF-8 copre più pezzi.
    ///
    ///
    /// * `Some(len)`: hè statu scontru un byte inaspettatu.
    ///   A lunghezza furnita hè quella di a sequenza di byte invalida chì parte da l'indice datu da `valid_up_to()`.
    ///   A decodifica deve riprende dopu quella sequenza (dopu inseritu un [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) in casu di decodifica lossy.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Un errore vultatu quandu l'analisi di un `bool` cù [`from_str`] fiasca
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}