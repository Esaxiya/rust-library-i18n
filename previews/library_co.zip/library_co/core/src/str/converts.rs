//! Modi per creà un `str` da a fetta di bytes.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Converte una fetta di byte in una fetta di stringa.
///
/// Una fetta di stringa ([`&str`]) hè fatta di bytes ([`u8`]), è una fetta di byte ([`&[u8]`][byteslice]) hè fatta di bytes, cusì sta funzione cunverte trà i dui.
/// Micca tutte e fette di byte sò fette di stringa valide, tuttavia: [`&str`] richiede chì sia UTF-8 valida.
/// `from_utf8()` verifica per assicurà chì i byte sò validi UTF-8, è poi face a cunversione.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Se site sicuru chì a fetta byte hè UTF-8 valida, è ùn vulete micca incurru u soprappu di u cuntrollu di validità, ci hè una versione micca sicura di sta funzione, [`from_utf8_unchecked`], chì hà u stessu cumpurtamentu ma salta u cuntrollu.
///
///
/// Se avete bisognu di un `String` invece di un `&str`, cunsiderate [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Perchè pudete stack-allocate un `[u8; N]`, è pudete piglià un [`&[u8]`][byteslice] di questu, sta funzione hè un modu per avè una stringa allocata in stack.Ci hè un esempiu di questu in l'esempiu di sezione sottu.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Restituisce `Err` se a fetta ùn hè micca UTF-8 cù una descrizzione per quessa chì a fetta furnita ùn hè micca UTF-8.
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// use std::str;
///
/// // qualchi bytes, in un vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Sapemu chì questi bytes sò validi, allora basta aduprà `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Bytes incorretti:
///
/// ```
/// use std::str;
///
/// // qualchi bytes invalidi, in un vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Vede i documenti per [`Utf8Error`] per più dettagli nantu à i tipi di errori chì ponu esse restituiti.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // qualchi bytes, in un array assignatu in pila
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Sapemu chì questi bytes sò validi, allora basta aduprà `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SICUREZZA: Ghjustu hè stata a validazione.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Converte una fetta mutabile di byte in una fetta di stringa mutabile.
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" cum'è vector mutevule
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Cum'è sapemu chì questi bytes sò validi, pudemu aduprà `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Bytes incorretti:
///
/// ```
/// use std::str;
///
/// // Alcuni byte invalidi in un vector mutabile
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Vede i documenti per [`Utf8Error`] per più dettagli nantu à i tipi di errori chì ponu esse restituiti.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SICUREZZA: Ghjustu hè stata a validazione.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Converte una fetta di byte in una fetta di stringa senza verificà chì a stringa cuntene UTF-8 validu.
///
/// Vede a versione sicura, [`from_utf8`], per più infurmazione.
///
/// # Safety
///
/// Sta funzione ùn hè micca sicura perchè ùn verifica micca chì i bytes passati per ella sò UTF-8 validi.
/// Se questa restrizione hè violata, u comportamentu indefinitu risulta, cume u restu di Rust assume chì [`&str`] sò validi UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// use std::str;
///
/// // qualchi bytes, in un vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SICUREZZA: u chjamante deve garantisce chì i bytes `v` sò validi UTF-8.
    // Si basa ancu in `&str` è `&[u8]` avendu u listessu layout.
    unsafe { mem::transmute(v) }
}

/// Converte una fetta di bytes in una fetta di stringa senza verificà chì a stringa cuntene UTF-8 validu;versione mutevule.
///
///
/// Vede a versione immutabile, [`from_utf8_unchecked()`] per più infurmazione.
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SICUREZZA: u chjamante deve garantisce chì i bytes `v`
    // sò validi UTF-8, cusì u cast à `*mut str` hè sicuru.
    // Inoltre, a deriferenza di u puntatore hè sicura perchè quellu puntatore vene da una riferenza chì hè garantita per esse valida per scrive.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}