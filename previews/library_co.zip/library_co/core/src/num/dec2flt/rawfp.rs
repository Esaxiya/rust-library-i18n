//! Bit fiddling nantu à i flottanti IEEE 754 pusitivi.I numeri negativi ùn sò è ùn devenu micca esse trattati.
//! I numeri nurmali à virgola flottante anu una raprisentazione canonica cum'è (frac, exp) tale chì u valore hè 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) induve N hè u numeru di bit.
//!
//! I subnormali sò un pocu sfarenti è strani, ma si applica u listessu principiu.
//!
//! Quì, tuttavia, li ripresentemu cum'è (sig, k) cun f pusitivu, tale chì u valore sia f *
//! 2 <sup>e</sup> .Oltre à rende u "hidden bit" esplicitu, questu cambia l'esponente da u chjamatu cambiu di mantissa.
//!
//! Dittu altrimente, normalmente i floats sò scritti cum'è (1) ma quì sò scritti cum'è (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Chjamemu (1) a **rappresentazione frazionale** è (2) a **rappresentanza integrale**.
//!
//! Parechje funzioni in questu modulu trattanu solu numeri normali.E rutine dec2flt piglianu in modu cunservatore u percorsu lentu universale currettu (Algoritmu M) per numeri assai picculi è assai numerosi.
//! Quellu algoritmu hà bisognu solu di next_float() chì gestisce subnormali è zeru.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Un aiutu trait per evità di duplicà basicamente tuttu u codice di cunversione per `f32` è `f64`.
///
/// Vede u cummentariu doc di u modulu parente per quessa hè necessariu.
///
/// **Ùn deve mai** esse implementatu per altri tippi o esse adupratu fora di u modulu dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Tipu adupratu da `to_bits` è `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Esegue una trasmutazione grezza in un numeru interu.
    fn to_bits(self) -> Self::Bits;

    /// Esegue una trasmutazione grezza da un numeru interu.
    fn from_bits(v: Self::Bits) -> Self;

    /// Restituisce a categuria in quale stu numeru face parte.
    fn classify(self) -> FpCategory;

    /// Restituisce a mantissa, esponente è segnu cum'è numeri interi.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Decodifica u float.
    fn unpack(self) -> Unpacked;

    /// Cast da un picculu interu chì pò esse riprisentatu esattamente.
    /// Panic se u numeru interu ùn pò micca esse ripresentatu, l'altru codice in stu modulu assicura di ùn lascià mai chì accada.
    fn from_int(x: u64) -> Self;

    /// Ottiene u valore 10 <sup>e</sup> da una tavola pre-calculata.
    /// Panics per `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Ciò chì dice u nome.
    /// Hè più faciule per u codice duru ch'è di ghjuvannusi intrinseci è sperendu chì LLVM a piega constante.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Un ligame cunservatore nantu à e cifre decimali di input chì ùn ponu micca pruduce overflow o zero o
    /// subnormali.Probabilmente l'esponente decimale di u valore normale massimu, da quì u nome.
    const MAX_NORMAL_DIGITS: usize;

    /// Quandu a cifra decimale più significativa hà un valore postu più grande di questu, u numeru hè certamente arrotondatu à l'infinitu.
    ///
    const INF_CUTOFF: i64;

    /// Quandu a cifra decimale più significativa hà un valore postu menu di questu, u numeru hè certamente arrotondatu à zeru.
    ///
    const ZERO_CUTOFF: i64;

    /// U numaru di bits in l'esponente.
    const EXP_BITS: u8;

    /// U numeru di bit in u significatu,*cumpresu* u bit ammucciatu.
    const SIG_BITS: u8;

    /// U numeru di bit in u significatu,*escludendu* u bit ammucciatu.
    const EXPLICIT_SIG_BITS: u8;

    /// U massimu esponente legale in a rappresentazione frazzionale.
    const MAX_EXP: i16;

    /// L'esponente legale minimu in a rapprisintazione frazzionale, escludendu i subnormali.
    const MIN_EXP: i16;

    /// `MAX_EXP` per a rappresentazione integrale, vale à dì, cù u cambiamentu applicatu.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` codificatu (vale à dì, cù preghjudiziu offset)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` per a rappresentazione integrale, vale à dì, cù u cambiamentu applicatu.
    const MIN_EXP_INT: i16;

    /// U significatu massimu normalizatu in rapprisentazione integrale.
    const MAX_SIG: u64;

    /// U significatu minimu nurmalizatu in a raprisentazione integrale.
    const MIN_SIG: u64;
}

// Soprattuttu una soluzione per #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Restituisce a mantissa, esponente è segnu cum'è numeri interi.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Bias di espunente + shift di mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe hè incertu se `as` gira currettamente in tutte e piattaforme.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Restituisce a mantissa, esponente è segnu cum'è numeri interi.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Bias di espunente + shift di mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe hè incertu se `as` gira currettamente in tutte e piattaforme.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Converte un `Fp` à u tippu di galleggiante di macchina più vicinu.
/// Ùn tratta micca risultati subnormali.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f hè 64 bit, allora xe hà un cambiamentu di mantissa di 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Arrotonda u significatu 64-bit à i bit T::SIG_BITS cù a mità à uguale.
/// Ùn tratta micca u overflow di esponenti.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Ajuste u cambiamentu di mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inversu di `RawFloat::unpack()` per numeri nurmalizati.
/// Panics se u significatu o espunente ùn sò micca validi per numeri nurmalizzati.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Eliminà u bit ammucciatu
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Aghjustate l'esponente per u preghjudiziu di l'esponente è u mantisu shift
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Lascià un pocu di segnu à 0 ("+"), i nostri numeri sò tutti pusitivi
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Custruisce un subnormale.Una mantissa di 0 hè permessa è custruisce zero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // L'espunente codificatu hè 0, u bit di segnu hè 0, allora ci vole solu à reinterpretà i bit.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Approssimate un bignum cun Fp.Gira in 0.5 ULP cù a mità di paru.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Tagliemu tutti i bit prima di l'indice `start`, vale à dì, cambiamu effettivamente a destra di una quantità di `start`, allora questu hè ancu l'esponente chì avemu bisognu.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Round (half-to-even) secondu i pezzi truncati.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Trova u più grande numeru di virgule flottanti strettamente più chjucu di l'argumentu.
/// Ùn manighja micca e subnormali, zeru, o sottumessu di espunenti.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Truvate u più chjucu numaru di punti flottanti strettamente più grande di l'argumentu.
// Questa operazione hè saturata, vale à dì, next_float(inf) ==inf.
// A diversità di a maiò parte di u codice in questu modulu, sta funzione gestisce zero, subnormali è infiniti.
// Tuttavia, cum'è tutti l'altri codici quì, ùn tratta micca di NaN è numeri negativi.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Ciò pare troppu bellu per esse veru, ma funziona.
        // 0.0 hè cudificatu cum'è a parolla tuttu zero.Subnormali sò 0x000m ... m induve m hè a mantissa.
        // In particulare, u più chjucu subnormale hè 0x0 ... 01 è u più grande hè 0x000F ... F.
        // U più chjucu numaru nurmale hè 0x0010 ... 0, allora stu casu d'angulu funziona ancu.
        // Se l'incrementu supraneghja a mantissa, u bit di portu incrementa l'esponente cume vulemu, è i bit di mantissa diventanu zero.
        // A causa di a cunvenzione di u bit nascosta, ancu questu hè esattamente ciò chì vulemu!
        // Infine, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}