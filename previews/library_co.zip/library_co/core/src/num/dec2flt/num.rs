//! Funzioni di utilità per bignums chì ùn anu micca troppu sensu per trasformassi in metudi.

// FIXME U nome di questu modulu hè un pocu disgraziatu, postu chì altri moduli impurtanu ancu `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Pruvate se truncà tutti i bits menu significativi di `ones_place` introduce un errore parente menu, uguale o più grande di 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Se tutti i bit restanti sò zero, hè= 0.5 ULP, altrimenti> 0.5 S'ellu ùn ci hè più bit (half_bit==0), u sottu torna dinò Uguale.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Converte una stringa ASCII chì cuntene solu cifre decimali in un `u64`.
///
/// Ùn esegue micca verifiche per overflow o caratteri invalidi, allora se u chjamante ùn hè micca attentu, u risultatu hè falsu è pò panic (ancu s'ellu ùn serà micca `unsafe`).
/// Inoltre, e stringe viote sò trattate cum'è zero.
/// Sta funzione esiste perchè
///
/// 1. aduprà `FromStr` nantu à `&[u8]` richiede `from_utf8_unchecked`, chì hè male, è
/// 2. riunisce i risultati di `integral.parse()` è `fractional.parse()` hè più cumplicatu di tutta sta funzione.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Converte una stringa di cifre ASCII in un bignum.
///
/// Cum'è `from_str_unchecked`, sta funzione s'appoghja nantu à l'analizatore per eliminà micca e cifre.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Svolge un bignum in un interu 64 bit.Panics se u numeru hè troppu grande.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Estrae una gamma di bit.

/// L'indice 0 hè u pocu menu significativu è a gamma hè mezu aperta cum'è di solitu.
/// Panics se hè dumandatu di estrarre più bit chì si adattanu à u tippu di ritornu.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}