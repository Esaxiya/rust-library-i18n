//! I vari algoritmi da a carta.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Numeru di bit significanti in Fp
const P: u32 = 64;

// Simplemente guardemu a migliore apprussimazione per *tutti* i espunenti, cusì a variabile "h" è e cundizioni assuciate ponu esse omesse.
// Questu scambia a prestazione per un paio di kilobyte di spaziu.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// In a maiò parte di l'architetture, l'operazioni à puntu flottante anu una dimensione di bit esplicita, dunque a precisione di u calculu hè determinata per una basa per operazione.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// In x86, u x87 FPU hè adupratu per l'operazioni float se l'estensioni SSE/SSE2 ùn sò micca dispunibili.
// U x87 FPU opera cù 80 bit di precisione per difettu, ciò chì significa chì l'operazioni arrotonderanu à 80 bit causendu u doppiu arrotondamentu quandu i valori sò eventualmente rappresentati cum'è
//
// 32/64 valori float bit.Per superà questu, a parolla di cuntrollu FPU pò esse impostata in modu chì i computazioni sò eseguiti in a precisione desiderata.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Una struttura aduprata per priservà u valore originale di a parolla di cuntrollu FPU, da pudè esse ristabilita quandu a struttura hè cascata.
    ///
    ///
    /// U x87 FPU hè un registru di 16 bit chì i so campi sò i seguenti:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// A documentazione per tutti i campi hè dispunibule in u Manuale di u Sviluppatore di Software IA-32 Architectures (Volume 1).
    ///
    /// U solu campu chì hè pertinente per u codice chì seguita hè PC, Cuntrollu di precisione.
    /// Stu campu determina a precisione di l'operazioni effettuate da u FPU.
    /// Pò esse piazzatu à:
    ///  - 0b00, precisione unica cioè, 32-bit
    ///  - 0b10, doppia precisione ie, 64-bit
    ///  - 0b11, doppia precisione estesa cioè, 80-bit (statu predefinitu) U valore 0b01 hè riservatu è ùn deve micca esse adupratu.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SICUREZZA: l'istruzione `fldcw` hè stata verificata per esse capace di travaglià bè
        // qualsiasi `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Usemu a sintassi ATT per supportà LLVM 8 è LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Imposta u campu di precisione di u FPU à `T` è restituisce un `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Calculate u valore per u campu di Cuntrollu di Precisione chì hè adattu per `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bits
            8 => 0x0200, // 64 bits
            _ => 0x0300, // predefinitu, 80 bits
        };

        // Uttenite u valore originale di a parolla di cuntrollu per ristabilisce più tardi, quandu a struttura `FPUControlWord` hè cascata SICUREZZA: l'istruzione `fnstcw` hè stata verificata per pudè funzionà currettamente cù qualsiasi `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Usemu a sintassi ATT per supportà LLVM 8 è LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Pone a parolla di cuntrollu à a precisione desiderata.
        // Questu si ottiene mascherendu l'antica precisione (bit 8 è 9, 0x300) è rimpiazzendu lu cù a bandiera di precisione calculata sopra.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// U percorsu veloce di Bellerophon aduprendu numeri interi è flottanti di dimensioni macchina.
///
/// Questu hè estrattu in una funzione separata in modu chì pò esse pruvatu prima di custruisce un bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Paragunemu u valore esattu à MAX_SIG vicinu à a fine, questu hè solu un rifiutu rapidu è bonu (è libera ancu u restu di u codice da preoccupassi per u sferimentu).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // U percorsu rapidu dipende cruciale da chì l'aritmetica sia arrotondata à u numeru currettu di bit senza alcun arrotondamentu intermediu.
    // In x86 (senza SSE o SSE2) questu richiede di cambià a precisione di a pila x87 FPU in modo da circundà direttamente à bit 64/32.
    // A funzione `set_precision` s'occupa di impostà a precisione nantu à l'architetture chì richiedenu l'impostazione cambiendu u statu glubale (cum'è a parolla di cuntrollu di u x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // U casu e <0 ùn pò micca esse piegatu in l'altru branch.
    // E putenze negative risultanu in una parte frazzionale ripetuta in binariu, chì sò arrotondati, chì provoca errori veri (è à volte abbastanza significativi!) In u risultatu finale.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// L'algoritmu Bellerofonte hè un codice banale ghjustificatu da analisi numeriche non banali.
///
/// Arrotonda "f" à un float cun significatu di 64 bit è u multiplica per a migliore approssimazione di `10^e` (in u listessu furmatu di virgola flottante).Questu hè spessu abbastanza per uttene u risultatu currettu.
/// Tuttavia, quandu u risultatu hè vicinu à a mità di strada trà dui galleggianti (ordinary) adiacenti, l'errore di arrotondamentu cumpostu da a multiplicazione di duie approssimazioni significa chì u risultatu pò esse spente da pochi bit.
/// Quandu accade questu, l'algoritmu iterativu R risolve e cose.
///
/// U "close to halfway" ondulatu à a manu hè fattu precisu da l'analisi numerica in a carta.
/// In e parole di Clinger:
///
/// > Slop, espressu in unità di u pocu menu significativu, hè un ligame inclusivu per l'errore
/// > accumulatu durante u calculu in virgula flottante di l'apprussimazione à f * 10 ^ e.(Slop hè
/// > micca un ligame per u veru errore, ma limite a differenza trà l'approssimazione z è
/// > a migliore approssimazione pussibule chì utilizza p bit di significand.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // I casi abs(e) <log5(2^N) sò in fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // U slop hè abbastanza grande per fà a differenza quandu si arrotonda à n bit?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Un algoritmu iterativu chì migliora una apprussimazione in virgula flottante di `f * 10^e`.
///
/// Ogni iterazione ottiene una unità in l'ultimu locu più vicinu, chì naturalmente richiede assai tempu per cunverghjere se `z0` hè ancu leggermente spento.
/// Per furtuna, quandu hè adupratu cum'è riserva per Bellerophon, l'approssimazione iniziale hè disattivata da massimu una ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Truvate numeri interi pusitivi `x`, `y` tali chì `x / y` hè esattamente `(f *10^e) / (m* 2^k)`.
        // Questu evita solu di trattà cù i segni di `e` è `k`, eliminemu ancu a putenza di dui cumuni à `10^e` è `2^k` per rende i numeri più chjuchi.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Questu hè scrittu un pocu goffu perchè i nostri bignum ùn supportanu micca numeri negativi, allora usemu u valore assolutu + l'infurmazione di u segnu.
        // A multiplicazione cù m_digits ùn pò micca trabuccà.
        // Se `x` o `y` sò abbastanza grandi chì avemu bisognu di preoccupassi per u overflow, allora sò ancu abbastanza grandi chì `make_ratio` hà riduttu a frazione di un fattore di 2 ^ 64 o più.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Ùn avete più bisognu di x, salvate un clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Ancu bisognu di y, fate una copia.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Dati `x = f` è `y = m` induve `f` rapprisentanu numeri decimali in ingressu cum'è di solitu è `m` hè u significatu di una apprussimazione in virgule flottante, fate u rapportu `x / y` uguale à `(f *10^e) / (m* 2^k)`, forse riduttu da una putenza di dui entrambi in cumunu.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, eccettu chì riducemu a frazione di qualchì putenza di dui.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Quessa ùn pò micca trabuccà perchè richiede `e` pusitivi è `k` negativi, chì ponu accade solu per valori estremamente vicini à 1, chì significa chì `e` è `k` saranu relativamente chjucchi.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Nemmenu questu pò micca trabuccà, vede sopra.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), riducendu dinò per una putenza cumuna di dui.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Cuncettualmente, l'algoritmu M hè u modu più simplice per cunvertisce un decimali in un float.
///
/// Formemu un raportu chì hè uguale à `f * 10^e`, allora ghjittemu in putenze di dui finu à chì dà un significatu float validu.
/// L'esponente binariu `k` hè u numeru di volte chì avemu multiplicatu numeratore o denominatore per dui, vale à dì, in ogni momentu `f *10^e` hè uguale à `(u / v)* 2^k`.
/// Quandu avemu trovu significand, avemu solu bisognu à circundà ispezionendu u restu di a divisione, chì si face in funzioni d'aiutu più sottu.
///
///
/// Questu algoritmu hè super lentu, ancu cù l'ottimisazione descritta in `quick_start()`.
/// Tuttavia, hè u più sèmplice di l'algoritmi per adattà per risultati di overflow, underflow, è subnormali.
/// Questa implementazione ripiglia quandu Bellerophon è Algoritmu R sò sopraffatti.
/// Rilevà u sfruttamentu è u sversamentu hè faciule: u rapportu ùn hè ancu un significatu in a portata, eppuru u esponente minimum/maximum hè statu ghjuntu.
/// In casu di overflow, simu semplicemente restituiti l'infinitu.
///
/// A gestione di u sottufluu è di e subnormali hè più complicata.
/// Un grande prublema hè chì, cù u minimu esponente, u rapportu pò ancu esse troppu grande per un significand.
/// Vede underflow() per i dettagli.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME ottimisazione pussibule: generalizà big_to_fp in modu chì pudemu fà l'equivalente di fp_to_float(big_to_fp(u)) quì, solu senza u doppiu arrotondamentu.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Avemu da fermà à u minimu esponente, se aspettemu finu à `k < T::MIN_EXP_INT`, allora sariamu scesi da un fattore di dui.
            // Purtroppu questu significa chì duvemu spezializà numeri normali cù u minimu esponente.
            // FIXME trova una formulazione più elegante, ma esegue u test `tiny-pow10` per assicurassi chì sia veramente currettu!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Salta a maiò parte di e M iterazioni di l'Algoritmu verificendu a lunghezza di bit.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // A lunghezza di bit hè una stima di u logaritimu di basa dui, è log(u / v) = log(u), log(v).
    // A stima hè disattivata da massimu 1, ma sempre una sottovalutazione, dunque l'errore nantu à log(u) è log(v) sò di u listessu segnu è si cancellanu (se entrambi sò grandi).
    // Dunque l'errore per log(u / v) hè à u più unu ancu.
    // U rapportu di destinazione hè quellu induve u/v hè in un significand in-range.Cusì a nostra cundizione di terminazione hè log2(u / v) essendu u significante bit, plus/minus unu.
    // FIXME Fighjendu u secondu bit puderia migliurà a stima è evità alcune divisioni in più.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow o subnormale.Lascialu à a funzione principale.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Overflow.Lascialu à a funzione principale.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // U Ratio ùn hè micca un significatu in u intervallu è cun u esponente minimu, allora ci vole à arrotondà i pezzi in eccessu è adeguà l'esponente in cunsunenza.
    // U veru valore pare avà:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(rapprisentatu da rem)
    //
    // Dunque, quandu i bit arrotondati sò!= 0.5 ULP, decidenu l'arrotondamentu da solu.
    // Quandu sò uguali è u restu hè diversu da zero, u valore deve sempre esse arrotondatu.
    // Solu quandu i bit arrotondati sò 1/2 è u restu hè zero, avemu una situazione à mezu à uguale.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Ordinariu round-to-even, offuscatu da avè da circundà basatu annantu à u restu di una divisione.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}