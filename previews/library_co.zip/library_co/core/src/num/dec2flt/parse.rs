//! Validazione è decomposizione di una stringa decimale di a forma:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! In altre parolle, sintassi standard in virgule flottante, eccettu duie eccezioni: Nisun segnu, è nisuna gestione di "inf" è "NaN".Quessi sò gestiti da a funzione di driver (super::dec2flt).
//!
//! Benchì ricunnosce input validi sia relativamente faciule, stu modulu deve ancu rifiutà l'innumerevuli variazioni invalide, mai panic, è fà numerosi cuntrolli chì l'altri moduli s'appoghjanu à micca panic (o overflow) à turnu.
//!
//! Per peghju, tuttu ciò chì accade in una sola passata sopra l'input.
//! Dunque, fate attenzione quandu mudificate qualcosa, è verificate dinò cù l'altri moduli.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// E parti interessanti di una stringa decimale.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// L'esponente decimali, garantitu d'avè menu di 18 cifre decimali.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Verifica se a stringa d'ingressu hè un numeru in virgula flottante valida è sì, localizza a parte integrale, a parte frazzionale è l'esponente in questu.
/// Ùn manighja micca i segni.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Nisuna cifra prima di 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Avemu bisognu di almenu una sola cifra prima o dopu u puntu.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Spazzatura finale dopu parte frazzionale
            }
        }
        _ => Invalid, // Spazzatura finale dopu a stringa di prima cifra
    }
}

/// Sculpisce e cifre decimali finu à u primu caratteru micca cifru.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Estrazione di espunenti è verificazione di errore.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Spazzatura finale dopu espunente
    }
    if number.is_empty() {
        return Invalid; // Esponente viotu
    }
    // A stu puntu, avemu certamente una stringa di cifre valida.Pò esse troppu longu per mette in un `i64`, ma s'ellu hè cusì grande, l'input hè certamente zero o infinitu.
    // Postu chì ogni zeru in e cifre decimali aghjusta solu l'esponente da +/-1, à exp=10 ^ 18 l'input duveria esse 17 exabyte (!) di zeros per ottene ancu à distanza vicinu à esse finitu.
    //
    // Questu ùn hè micca esattamente un casu d'usu chì avemu bisognu à risponde.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}