//! Custanti specifiche à u tippu `f64` à doppia precisione in virgula flottante.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Numeri matematicamente significativi sò furniti in u sottumodulu `consts`.
//!
//! Per e costanti definite direttamente in stu modulu (distinte da quelle definite in u sottomodulu `consts`), u novu codice deve invece usà e costanti associate definite direttamente nantu à u tippu `f64`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// A radice o basa di a raprisentazione interna di `f64`.
/// Aduprate invece [`f64::RADIX`].
///
/// # Examples
///
/// ```rust
/// // modu deprecatu
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // manera intesa
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Numeru di cifre significative in basa 2.
/// Aduprate invece [`f64::MANTISSA_DIGITS`].
///
/// # Examples
///
/// ```rust
/// // modu deprecatu
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // manera intesa
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Numeru approssimativu di cifre significative in basa 10.
/// Aduprate invece [`f64::DIGITS`].
///
/// # Examples
///
/// ```rust
/// // modu deprecatu
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // manera intesa
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] valore per `f64`.
/// Aduprate invece [`f64::EPSILON`].
///
/// Questa hè a differenza trà `1.0` è u prossimu numeru rappresentabile più grande.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // modu deprecatu
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // manera intesa
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// Valore `f64` finitu u più chjucu.
/// Aduprate invece [`f64::MIN`].
///
/// # Examples
///
/// ```rust
/// // modu deprecatu
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // manera intesa
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// U più chjucu valore `f64` nurmale pusitivu.
/// Aduprate invece [`f64::MIN_POSITIVE`].
///
/// # Examples
///
/// ```rust
/// // modu deprecatu
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // manera intesa
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// U più grande valore finitu `f64`.
/// Aduprate invece [`f64::MAX`].
///
/// # Examples
///
/// ```rust
/// // modu deprecatu
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // manera intesa
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// Una più grande di a putenza nurmale minima pussibule di 2 esponente.
/// Aduprate invece [`f64::MIN_EXP`].
///
/// # Examples
///
/// ```rust
/// // modu deprecatu
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // manera intesa
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// Potenza massima pussibule di 2 esponente.
/// Aduprate invece [`f64::MAX_EXP`].
///
/// # Examples
///
/// ```rust
/// // modu deprecatu
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // manera intesa
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Potenza nurmale minima pussibule di 10 esponenti.
/// Aduprate invece [`f64::MIN_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // modu deprecatu
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // manera intesa
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Potenza massima massima di 10 esponenti.
/// Aduprate invece [`f64::MAX_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // modu deprecatu
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // manera intesa
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Micca un Numaru (NaN).
/// Aduprate invece [`f64::NAN`].
///
/// # Examples
///
/// ```rust
/// // modu deprecatu
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // manera intesa
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinitu (∞).
/// Aduprate invece [`f64::INFINITY`].
///
/// # Examples
///
/// ```rust
/// // modu deprecatu
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // manera intesa
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Infinità negativa (−∞).
/// Aduprate invece [`f64::NEG_INFINITY`].
///
/// # Examples
///
/// ```rust
/// // modu deprecatu
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // manera intesa
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Custanti matematiche di basa.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: rimpiazzà cù custanti matematiche da cmath.

    /// (π) constante d'Archimede
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// U circondu cumpletu (τ) custante
    ///
    /// Uguale à 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Numeru di Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// A radice o basa di a raprisentazione interna di `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Numeru di cifre significative in basa 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Numeru approssimativu di cifre significative in basa 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] valore per `f64`.
    ///
    /// Questa hè a differenza trà `1.0` è u prossimu numeru rappresentabile più grande.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Valore `f64` finitu u più chjucu.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// U più chjucu valore `f64` nurmale pusitivu.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// U più grande valore finitu `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// Una più grande di a putenza nurmale minima pussibule di 2 esponente.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// Potenza massima pussibule di 2 esponente.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Potenza nurmale minima pussibule di 10 esponenti.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Potenza massima massima di 10 esponenti.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Micca un Numaru (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinitu (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Infinità negativa (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Restituisce `true` se stu valore hè `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` hè publicamente indisponibile in libcore per via di preoccupazioni nantu à a portabilità, cusì sta implementazione hè per usu privatu internamente.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// Restituisce `true` se stu valore hè infinitu pusitivu o infinitu negativu, è `false` altrimente.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Restituisce `true` se stu numeru ùn hè nè infinitu nè `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Ùn ci hè bisognu di trattà NaN separatamente: se sè stessu hè NaN, u paragone ùn hè micca veru, esattamente cum'è desideratu.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Restituisce `true` se u numeru hè [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // I valori trà `0` è `min` sò Subnormali.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Restituisce `true` se u numeru ùn hè nè zero, infinitu, [subnormal] o `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // I valori trà `0` è `min` sò Subnormali.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Restituisce a categuria di virgule flottanti di u numeru.
    /// Sì una sola prupietà serà testata, hè generalmente più veloce d'utilizà u predicatu specificu invece.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Ritorna `true` se `self` hà un segnu pusitivu, cumpresu `+0.0`, `NaN` cun bit di segnu pusitivu è infinitu pusitivu.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Restituisce `true` se `self` hà un segnu negativu, cumpresu `-0.0`, `NaN` cù bit di segnu negativu è infinitu negativu.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Piglia a (inverse) reciproca di un numeru, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Converte i radiani in gradi.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // A divisione quì hè currettamente arrotondata in quantu à u veru valore di 180/π.
        // (Questu differe di f32, induve una costante deve esse aduprata per assicurà un risultatu currettamente arrotondatu.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Converte i gradi in radiani.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Restituisce u massimu di i dui numeri.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Se unu di l'argumenti hè NaN, allora l'altru argumentu hè restituitu.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Restituisce u minimu di i dui numeri.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Se unu di l'argumenti hè NaN, allora l'altru argumentu hè restituitu.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Arrotonda versu zeru è si converte à qualsiasi tippu interu primitivu, supponendu chì u valore sia finitu è si adatti à quellu tippu.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// U valore deve:
    ///
    /// * Micca esse `NaN`
    /// * Ùn sia micca infinitu
    /// * Esse rappresentabile in u tippu di ritornu `Int`, dopu avè truncatu a so parte frazionale
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Trasmutazione grezza à `u64`.
    ///
    /// Questu hè attualmente identicu à `transmute::<f64, u64>(self)` in tutte e piattaforme.
    ///
    /// Vede `from_bits` per qualchì discussione nantu à a portabilità di questa operazione (ùn ci hè guasi micca prublemi).
    ///
    /// Nutate bè chì sta funzione hè distinta da u casting `as`, chì prova à priservà u valore *numericu*, è micca u valore bitwise.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() ùn hè micca casting!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // SICUREZZA: `u64` hè un vechju tippu di dati simplici per pudè sempre trasmutallu
        unsafe { mem::transmute(self) }
    }

    /// Trasmutazione grezza da `u64`.
    ///
    /// Questu hè attualmente identicu à `transmute::<u64, f64>(v)` in tutte e piattaforme.
    /// Si scopre chì questu hè incredibilmente portatile, per duie ragioni:
    ///
    /// * I galleggianti è Ints anu u listessu endiannessu in tutte e piattaforme supportate.
    /// * IEEE-754 specifica assai precisamente u schema di bit di i floats.
    ///
    /// Tuttavia, ci hè una caveat: prima di a versione 2008 di IEEE-754, cumu interpretà u bit di segnalazione NaN ùn era micca specificatu.
    /// A maiò parte di e piattaforme (in particulare x86 è ARM) anu sceltu l'interpretazione chì hè stata finalmente standardizata in u 2008, ma alcune ùn l'anu fatta (in particulare MIPS).
    /// Di conseguenza, tutte e NaN di segnalazione nantu à MIPS sò NaN tranquille in x86, è viceversa.
    ///
    /// Invece di pruvà à priservà a piattaforma incrociata di segnalazione, sta implementazione favurisce a preservazione di i bit esatti.
    /// Ciò significa chì qualsiasi carica utile codificata in NaNs sarà preservata ancu se u risultatu di stu metudu hè inviatu nantu à a rete da una macchina x86 à una MIPS.
    ///
    ///
    /// Se i risultati di questu metudu sò manipulati solu da a stessa architettura chì li hà pruduttu, allora ùn ci hè micca preoccupazione di portabilità.
    ///
    /// Se l'input ùn hè micca NaN, allora ùn ci hè micca preoccupazione di portabilità.
    ///
    /// Se ùn vi interessa micca à a signaletica (assai prubabile), allora ùn ci hè micca preoccupazione di portabilità.
    ///
    /// Nutate bè chì sta funzione hè distinta da u casting `as`, chì prova à priservà u valore *numericu*, è micca u valore bitwise.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // SICUREZZA: `u64` hè un vechju tippu di dati simplici per pudè sempre trasmutallu
        // Si scopre chì i prublemi di sicurezza cù sNaN sò stati supranati!Hurra!
        unsafe { mem::transmute(v) }
    }

    /// Ritorna a rapprisintazione di memoria di stu numeru à puntu flottante cum'è una matrice di byte in ordine di byte big-endian (network).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Ritorna a rapprisintazione di memoria di stu numeru in virgule flottante cum'è una matrice di byte in ordine di byte pocu endianu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Ritorna a rapprisintazione di memoria di stu numeru di puntu flottante cum'è una matrice di byte in ordine di byte nativu.
    ///
    /// Cum'è l'endianità nativa di a piattaforma di destinazione hè aduprata, u codice portatile deve aduprà [`to_be_bytes`] o [`to_le_bytes`], secondu u casu, invece.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Ritorna a rapprisintazione di memoria di stu numeru di puntu flottante cum'è una matrice di byte in ordine di byte nativu.
    ///
    ///
    /// [`to_ne_bytes`] duverebbe esse preferitu sopra questu quandu hè pussibule.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // SICUREZZA: `f64` hè un vechju tippu di dati simplici per pudè sempre trasmutallu
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Crea un valore in virgola flottante da a so raprisentazione cum'è una matrice di byte in big endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Crea un valore in virgule flottante da a so raprisentazione cum'è una matrice di byte in pocu endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Crea un valore in virgule flottante da a so raprisentazione cum'è una matrice di byte in endian nativu.
    ///
    /// Cum'è l'endianità nativa di a piattaforma di destinazione hè aduprata, u codice portatile probabilmente vole aduprà [`from_be_bytes`] o [`from_le_bytes`], cum'è adattu invece.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Restituisce un ordine trà sè è altri valori.
    /// A differenza di u paragone parziale standard trà i numeri in virgula flottante, questu paragone produce sempre un ordine in cunfurmità cù u predicatu di l'Ordine Totale cum'è definitu in IEEE 754 (revisione 2008) standard in virgola flottante.
    /// I valori sò urdinati in l'ordine seguente:
    /// - NaN tranquillu negativu
    /// - Segnalazione negativa NaN
    /// - Infinità negativa
    /// - Numeri negativi
    /// - Numeri subnormali negativi
    /// - Cero negativu
    /// - Cero pusitivu
    /// - Numeri subnormali pusitivi
    /// - Numeri pusitivi
    /// - Infinitu pusitivu
    /// - Segnalazione positiva NaN
    /// - NaN tranquillu pusitivu
    ///
    /// Innota chì sta funzione ùn hè micca sempre d'accordu cù l'implementazioni [`PartialOrd`] è [`PartialEq`] di `f64`.In particulare, cunsideranu u cero negativu è pusitivu cum'è uguale, mentre `total_cmp` ùn face micca.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // In casu di negativi, lanciate tutti i bit eccettu u segnu per uttene un schema simile à i numeri interi di cumplementu di dui
        //
        // Perchè stu travagliu?I floati IEEE 754 consistenu di trè campi:
        // Bit di segnu, espunente è mantissa.L'inseme di i campi di esponente è di mantissa in generale anu a pruprietà chì u so ordine à bit hè uguale à a magnitudine numerica induve hè definita a magnitudine.
        // A magnitudine ùn hè nurmalmente definita nantu à i valori NaN, ma IEEE 754 totalOrder definisce i valori NaN ancu per seguità l'ordine bitwise.Questu porta à l'ordine spiegatu in u cummentariu di doc.
        // Tuttavia, a rapprisintazione di magnitudine hè a stessa per i numeri negativi è positivi-solu u bit di segnu hè diversu.
        // Per paragunà facilmente i galleggianti cum'è numeri interi firmati, avemu bisognu di girà l'espunente è i bit di mantissa in casu di numeri negativi.
        // Cunvertemu in modu efficace i numeri in forma "two's complement".
        //
        // Per fà u flipping, custruimu una maschera è XOR contru.
        // Calculemu senza ramificazioni una maschera "all-ones except for the sign bit" da valori negativi-firmati: u segnu spostante à destra-allarga u numeru interu, allora "fill" a maschera cun bit di segnu, è poi cunvertitemu in senza signu per spinghje un bit di più zero.
        //
        // Nantu à i valori pusitivi, a maschera hè tuttu zeru, allora hè un no-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Limità un valore à un certu intervallu à menu chì sia NaN.
    ///
    /// Ritorna `max` se `self` hè più grande chì `max`, è `min` se `self` hè menu di `min`.
    /// Altrimenti questu restituisce `self`.
    ///
    /// Innota chì sta funzione restituisce NaN se u valore iniziale era ancu NaN.
    ///
    /// # Panics
    ///
    /// Panics se `min > max`, `min` hè NaN, o `max` hè NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}