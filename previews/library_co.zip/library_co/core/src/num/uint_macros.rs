macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// U valore più chjucu chì pò esse rappresentatu da stu tipu interu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// U più grande valore chì pò esse rappresentatu da stu tipu interu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// A dimensione di stu tipu interu in bit.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Converte una fetta di stringa in una basa data in un numeru interu.
        ///
        /// A corda hè prevista per esse un segnu `+` opzionale seguitatu da cifre.
        ///
        /// U spaziu biancu di punta è di seguitu raprisenta un errore.
        /// I cifri sò un sottogruppu di questi caratteri, secondu `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Questa funzione panics se `radix` ùn hè micca in u intervallu da 2 à 36.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Restituisce u numeru di quelli in a rappresentazione binaria di `self`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Restituisce u numeru di zeru in a rappresentazione binaria di `self`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Restituisce u numeru di zeri principali in a rapprisintazione binaria di `self`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Restituisce u numeru di zeru finale in a rappresentazione binaria di `self`.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Restituisce u numeru di quelli principali in a rappresentazione binaria di `self`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Restituisce u numeru di quelli chì finiscinu in a rappresentazione binaria di `self`.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Sposta i bit à sinistra per una quantità specificata, `n`, avvolgendu i bit truncati à a fine di u numeru interu resultante.
        ///
        ///
        /// Per piacè nutate chì questu ùn hè micca a stessa operazione cum'è l'operatore di cambiamentu `<<`!
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Sposta i bit à a diritta per una quantità specificata, `n`, avvolgendu i bit truncati finu à u principiu di u numeru interu resultante.
        ///
        ///
        /// Per piacè nutate chì questu ùn hè micca a stessa operazione cum'è l'operatore di cambiamentu `>>`!
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Inverte l'ordine di byte di u numeru interu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lasciate m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Inverte l'ordine di bit in u numeru sanu.
        /// U bit menu significativu diventa u bit più significativu, u secondu bit menu significativu diventa u secondu bit u più significativu, ecc.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lasciate m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Converte un interu da big endian in endianness di u target.
        ///
        /// In big endian questu hè un no-op.
        /// In pocu endian i byte sò scambiati.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } altru {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Converte un interu da pocu endian à endianness di u target.
        ///
        /// In pocu endian questu hè un no-op.
        /// In big endian i byte sò scambiati.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } altru {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Converte `self` in big endian da l'endianness di u target.
        ///
        /// In big endian questu hè un no-op.
        /// In pocu endian i byte sò scambiati.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } altru { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // o micca esse?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Converte `self` in pocu endian da l'endianness di u target.
        ///
        /// In pocu endian questu hè un no-op.
        /// In big endian i byte sò scambiati.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } altru { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Aggiunta intera verificata.
        /// Calcula `self + rhs`, restituisce `None` in casu di overflow.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Aghjuntu interu micca marcatu.Calcula `self + rhs`, supponendu chì u overflow ùn si pò fà.
        /// Questu risultà in un comportamentu indefinitu quandu
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Sottrazione entera verificata.
        /// Calcula `self - rhs`, restituisce `None` in casu di overflow.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Sottrazione intera micca marcata.Calcula `self - rhs`, supponendu chì u overflow ùn si pò fà.
        /// Questu risultà in un comportamentu indefinitu quandu
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Multiplicazione intera verificata.
        /// Calcula `self * rhs`, restituisce `None` in casu di overflow.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Moltiplicazione intera micca marcata.Calcula `self * rhs`, supponendu chì u overflow ùn si pò fà.
        /// Questu risultà in un comportamentu indefinitu quandu
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Divisione intera verificata.
        /// Calcula `self / rhs`, restituisce `None` se `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SICUREZZA: div per zero hè statu verificatu sopra è i tippi senza firma ùn ne anu altru
                // modi di fallimentu per a divisione
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Divisione Euclidiana verificata.
        /// Calcula `self.div_euclid(rhs)`, restituisce `None` se `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Verificatu u restu interu.
        /// Calcula `self % rhs`, restituisce `None` se `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SICUREZZA: div per zero hè statu verificatu sopra è i tippi senza firma ùn ne anu altru
                // modi di fallimentu per a divisione
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Verificatu modulu euclidianu.
        /// Calcula `self.rem_euclid(rhs)`, restituisce `None` se `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Negazione verificata.Calcula `-self`, restituisce `None` a menu chì `self==
        /// 0`.
        ///
        /// Innota chì a negazione di qualsiasi numeru interu pusitivu sferrà.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Verificatu turnu à manca.
        /// Calcula `self << rhs`, restituisce `None` se `rhs` hè più grande o uguale à u numeru di bit in `self`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Verificatu shift right.
        /// Calcula `self >> rhs`, restituisce `None` se `rhs` hè più grande o uguale à u numeru di bit in `self`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Esponenziazione verificata.
        /// Calcula `self.pow(exp)`, restituisce `None` in casu di overflow.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // postu chì exp!=0, infine u exp deve esse 1.
            // Trattà cù u bit finale di l'esponente separatamente, postu chì quadrà a basa dopu ùn hè micca necessariu è pò causà un overflow inutile.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Aghjuntu sanu sanu.
        /// Calcula `self + rhs`, saturendu à i limiti numerichi invece di traboccà.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Sottrazione intera saturante.
        /// Calcula `self - rhs`, saturendu à i limiti numerichi invece di traboccà.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Multiplicazione intera saturante.
        /// Calcula `self * rhs`, saturendu à i limiti numerichi invece di traboccà.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Esponenziazione intera saturante.
        /// Calcula `self.pow(exp)`, saturendu à i limiti numerichi invece di traboccà.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Imballu (modular) aghjuntu.
        /// Calcula `self + rhs`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Avvolgimentu di sottrazione (modular).
        /// Calcula `self - rhs`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Imballaggio multiplicazione (modular).
        /// Calcula `self * rhs`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// Per piacè nutate chì questu esempiu hè spartutu trà tippi interi.
        /// Chì spiega perchè `u8` hè adupratu quì.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Avvolgimentu di a divisione (modular).Calcula `self / rhs`.
        /// A divisione avvolta nantu à i tippi non firmati hè solu una divisione normale.
        /// Ùn ci hè mancu manera chì l'embiu possa accadere
        /// Sta funzione esiste, affinchì tutte l'operazioni sianu contabilizate in l'operazioni d'embiu.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Avvolgimentu di a divisione euclidea.Calcula `self.div_euclid(rhs)`.
        /// A divisione avvolta nantu à i tippi non firmati hè solu una divisione normale.
        /// Ùn ci hè mancu manera chì l'embiu possa accadere
        /// Sta funzione esiste, affinchì tutte l'operazioni sianu contabilizate in l'operazioni d'embiu.
        /// Dapoi, per i numeri interi pusitivi, tutte e definizioni cumuni di divisione sò uguali, questu hè esattamente uguale à `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Imballaggio di u restu (modular).Calcula `self % rhs`.
        /// U calculu di u restu avvoltu nantu à tippi non firmati hè solu u calculu di u restu regulare.
        ///
        /// Ùn ci hè mancu manera chì l'embiu possa accadere
        /// Sta funzione esiste, affinchì tutte l'operazioni sianu contabilizate in l'operazioni d'embiu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Avvolgimentu modulu euclidianu.Calcula `self.rem_euclid(rhs)`.
        /// U calculu modulu imballatu nantu à tippi senza firma hè solu u calculu restante regulare.
        /// Ùn ci hè mancu manera chì l'embiu possa accadere
        /// Sta funzione esiste, affinchì tutte l'operazioni sianu contabilizate in l'operazioni d'embiu.
        /// Postu chì, per i numeri interi pusitivi, tutte e definizioni cumuni di divisione sò uguali, questu hè esattamente uguale à `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Imballu negazione (modular).
        /// Calcula `-self`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// Postu chì i tippi non firmati ùn anu micca equivalenti negativi tutte l'applicazioni di sta funzione s'involucraranu (eccettu per `-0`).
        /// Per i valori minori di u massimu di u tippu firmatu currispundente, u risultatu hè u listessu chè lancià u valore signatu currispundente.
        ///
        /// Ogni valore più grande hè equivalente à `MAX + 1 - (val - MAX - 1)` induve `MAX` hè u massimu di u tippu firmatu currispundente.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// Per piacè nutate chì questu esempiu hè spartutu trà tippi interi.
        /// Chì spiega perchè `i8` hè adupratu quì.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-free bitwise shift-left;
        /// rende `self << mask(rhs)`, induve `mask` elimina qualsiasi bit di altu ordine di `rhs` chì puderebbe fà chì u cambiamentu supere a larghezza di bit di u tippu.
        ///
        /// Innota chì questu hè *micca* u listessu cum'è un rotate-left;u RHS di un avvolgimentu shift-left hè limitatu à a gamma di u tippu, piuttostu chì i bit spostati fora di u LHS restituiti à l'altra estremità.
        /// I tippi interi primitivi implementanu tutti una funzione [`rotate_left`](Self::rotate_left), chì pò esse ciò chì vulete invece.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SICUREZZA: u mascheramentu da u bit di u tippu assicura chì ùn cambiemu micca
            // fora di i limiti
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-bitwise shift-right;
        /// rende `self >> mask(rhs)`, induve `mask` elimina tutti i pezzi di altu ordine di `rhs` chì puderebbenu fà chì u cambiamentu supere a larghezza di bit di u tippu.
        ///
        /// Innota chì questu hè *micca* u listessu cum'è un rotate-right;u RHS di un avvolgimentu shift-right hè limitatu à a gamma di u tippu, piuttostu chè i bit spostati fora di u LHS restituiti à l'altra estremità.
        /// I tippi interi primitivi implementanu tutti una funzione [`rotate_right`](Self::rotate_right), chì pò esse ciò chì vulete invece.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SICUREZZA: u mascheramentu da u bit di u tippu assicura chì ùn cambiemu micca
            // fora di i limiti
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Avvolgimentu di esponenziazione (modular).
        /// Calcula `self.pow(exp)`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // postu chì exp!=0, infine u exp deve esse 1.
            // Trattà cù u bit finale di l'esponente separatamente, postu chì quadrà a basa dopu ùn hè micca necessariu è pò causà un overflow inutile.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Calcula `self` + `rhs`
        ///
        /// Restituisce una tupla di l'aghjuntu cù un booleanu chì indica se un overflow aritmeticu si averebbe.
        /// Se un overflow si saria fattu allora u valore imballatu hè restituitu.
        ///
        /// # Examples
        ///
        /// Usu di basa
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Calcula `self`, `rhs`
        ///
        /// Restituisce una tupla di a sottrazione cù un booleanu chì indica se un overflow aritmeticu si averebbe.
        /// Se un overflow si saria fattu allora u valore imballatu hè restituitu.
        ///
        /// # Examples
        ///
        /// Usu di basa
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Calcula a multiplicazione di `self` è `rhs`.
        ///
        /// Restituisce una tupla di a multiplicazione cù un booleanu chì indica se un overflow aritmeticu si averebbe.
        /// Se un overflow si saria fattu allora u valore imballatu hè restituitu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// Per piacè nutate chì questu esempiu hè spartutu trà tippi interi.
        /// Chì spiega perchè `u32` hè adupratu quì.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Calcula u divisore quandu `self` hè divisu per `rhs`.
        ///
        /// Restituisce una tupla di u divisore cù un booleanu chì indica se un overflow aritmeticu si averebbe.
        /// Nutate bè chì per i numeri interi micca firmati ùn si face mai, allora u secondu valore hè sempre `false`.
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0.
        ///
        /// # Examples
        ///
        /// Usu di basa
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Calcula u quoziente di a divisione euclidea `self.div_euclid(rhs)`.
        ///
        /// Restituisce una tupla di u divisore cù un booleanu chì indica se un overflow aritmeticu si averebbe.
        /// Nutate bè chì per i numeri interi micca firmati ùn si face mai, allora u secondu valore hè sempre `false`.
        /// Postu chì, per i numeri interi pusitivi, tutte e definizioni cumuni di divisione sò uguali, questu hè esattamente uguale à `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0.
        ///
        /// # Examples
        ///
        /// Usu di basa
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Calcula u restu quandu `self` hè divisu per `rhs`.
        ///
        /// Restituisce una tupla di u restu dopu avè divisu cù un booleanu chì indica se un overflow aritmeticu si averebbe.
        /// Nutate bè chì per i numeri interi micca firmati ùn si face mai, allora u secondu valore hè sempre `false`.
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0.
        ///
        /// # Examples
        ///
        /// Usu di basa
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Calcula u restu `self.rem_euclid(rhs)` cum'è per divisione euclidea.
        ///
        /// Restituisce una tupla di u modulu dopu avè divisu cù un booleanu chì indica se un overflow aritmeticu si averebbe.
        /// Nutate bè chì per i numeri interi micca firmati ùn si face mai, allora u secondu valore hè sempre `false`.
        /// Postu chì, per i numeri interi pusitivi, tutte e definizioni cumuni di divisione sò uguali, questa operazione hè esattamente uguale à `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0.
        ///
        /// # Examples
        ///
        /// Usu di basa
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Nega sè in modu sferente.
        ///
        /// Restituisce `!self + 1` aduprendu operazioni di imballu per restituisce u valore chì rapprisenta a negazione di stu valore micca firmatu.
        /// Nutate bè chì per i valori pusitivi micca firmati si faci sempre un overflow, ma negà 0 ùn supera micca.
        ///
        /// # Examples
        ///
        /// Usu di basa
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Sposta da sè lasciatu da i bit `rhs`.
        ///
        /// Restituisce una tupla di a versione spustata di sè cù un booleanu chì indica se u valore di spostamentu era più grande o uguale à u numeru di bit.
        /// Se u valore di shift hè troppu grande, u valore hè mascheratu (N-1) induve N hè u numeru di bit, è questu valore hè allora utilizatu per eseguisce u shift.
        ///
        /// # Examples
        ///
        /// Usu di basa
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Sposta propiu à dirittu per `rhs` bits.
        ///
        /// Restituisce una tupla di a versione spustata di sè cù un booleanu chì indica se u valore di spostamentu era più grande o uguale à u numeru di bit.
        /// Se u valore di shift hè troppu grande, u valore hè mascheratu (N-1) induve N hè u numeru di bit, è questu valore hè allora utilizatu per eseguisce u shift.
        ///
        /// # Examples
        ///
        /// Usu di basa
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Rialza u so autore à a putenza di `exp`, aduprendu l'esponenziazione à u quadratu.
        ///
        /// Restituisce una tupla di l'esponenziazione cù un bool chì indica se un overflow hè accadutu.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, veru));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Scratch space per almacenà i risultati di overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // postu chì exp!=0, infine u exp deve esse 1.
            // Trattà cù u bit finale di l'esponente separatamente, postu chì quadrà a basa dopu ùn hè micca necessariu è pò causà un overflow inutile.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Rialza u so autore à a putenza di `exp`, aduprendu l'esponenziazione à u quadratu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // postu chì exp!=0, infine u exp deve esse 1.
            // Trattà cù u bit finale di l'esponente separatamente, postu chì quadrà a basa dopu ùn hè micca necessariu è pò causà un overflow inutile.
            //
            //
            acc * base
        }

        /// Esegue una divisione euclidea.
        ///
        /// Postu chì, per i numeri interi pusitivi, tutte e definizioni cumuni di divisione sò uguali, questu hè esattamente uguale à `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Calcula u restu minimu di `self (mod rhs)`.
        ///
        /// Postu chì, per i numeri interi pusitivi, tutte e definizioni cumuni di divisione sò uguali, questu hè esattamente uguale à `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Ritorna `true` se è solu se `self == 2^k` per qualchì `k`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Ritorna unu menu di a prossima putenza di dui.
        // (Per 8u8 a prossima putenza di dui hè 8u8 è per 6u8 hè 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Stu metudu ùn pò micca trabuccà, cum'è in i casi di overflow `next_power_of_two` finisce invece per restituisce u valore massimu di u tippu, è pò restituisce 0 per 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SICUREZZA: Perchè `p > 0`, ùn pò micca esse cumpostu interamente da zeros principali.
            // Ciò significa chì u cambiamentu hè sempre in limiti, è alcuni processori (cum'è intel pre-haswell) anu più efficaci ctlz intrinseci quandu l'argumentu hè diversu da zero.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Restituisce a putenza più chjuca di duie più grande o uguale à `self`.
        ///
        /// Quandu u valore di ritornu sferisce (vale à dì, `self > (1 << (N-1))` per u tippu `uN`), hè panics in modu di debug è u valore di ritornu hè impannillatu à 0 in modu di liberazione (l'unica situazione in quale metudu pò restituisce 0).
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Restituisce a putenza più chjuca di duie più grande o uguale à `n`.
        /// Se a prossima putenza di dui hè più grande chì u valore massimu di u tippu, `None` hè restituitu, altrimenti a putenza di dui hè impannillata in `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Restituisce a putenza più chjuca di duie più grande o uguale à `n`.
        /// Se a prossima potenza di dui hè più grande chì u valore massimu di u tippu, u valore di ritornu hè impacchitu à `0`.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Ritorna a raprisentazione di memoria di questu interu cum'è una matrice di byte in ordine di byte big-endian (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Ritorna a raprisentazione di memoria di questu interu cum'è una matrice di byte in ordine di byte pocu endianu.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Ritorna a rapprisintazione di memoria di questu interu cum'è una matrice di byte in ordine di byte nativu.
        ///
        /// Cum'è l'endianità nativa di a piattaforma di destinazione hè aduprata, u codice portatile deve aduprà [`to_be_bytes`] o [`to_le_bytes`], secondu u casu, invece.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, se cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } altru {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SICUREZZA: sonu custante perchè i numeri interi sò vechji tippi di dati semplici da pudè sempre
        // trasmutalli in matrici di bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SICUREZZA: i numeri interi sò antichi tippi di dati simplici per pudè sempre trasmutalli in
            // matrici di bytes
            unsafe { mem::transmute(self) }
        }

        /// Ritorna a rapprisintazione di memoria di questu interu cum'è una matrice di byte in ordine di byte nativu.
        ///
        ///
        /// [`to_ne_bytes`] duverebbe esse preferitu sopra questu quandu hè pussibule.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// lasciate bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, se cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } altru {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SICUREZZA: i numeri interi sò antichi tippi di dati simplici per pudè sempre trasmutalli in
            // matrici di bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Crea un valore interu endian nativu da a so raprisentazione cum'è una matrice di byte in big endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// aduprà std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=riposu;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Crea un valore interu endianu nativu da a so raprisentazione cum'è una matrice di byte in pocu endianu.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// aduprà std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=riposu;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Crea un valore interu endianu nativu da a so raprisentazione di memoria cum'è una matrice di byte in endianness nativa.
        ///
        /// Cum'è l'endianità nativa di a piattaforma di destinazione hè aduprata, u codice portatile probabilmente vole aduprà [`from_be_bytes`] o [`from_le_bytes`], cum'è adattu invece.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } altru {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// aduprà std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=riposu;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SICUREZZA: sonu custante perchè i numeri interi sò vechji tippi di dati semplici da pudè sempre
        // trasmutalli
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SICUREZZA: i numeri interi sò vechji tippi di dati semplici da pudè sempre trasmutalli
            unsafe { mem::transmute(bytes) }
        }

        /// U novu codice deve preferisce aduprà
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Restituisce u valore u più chjucu chì pò esse ripresentatu da stu tipu interu.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// U novu codice deve preferisce aduprà
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Restituisce u valore più grande chì pò esse rappresentatu da stu tipu interu.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}