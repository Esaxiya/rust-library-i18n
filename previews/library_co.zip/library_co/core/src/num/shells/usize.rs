//! Custanti per u tippu interu senza segnu di dimensioni punteru.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! U novu codice deve aduprà e costanti associate direttamente nantu à u tippu primitivu.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }