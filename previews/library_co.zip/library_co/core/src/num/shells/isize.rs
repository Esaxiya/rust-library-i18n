//! Custanti per u tippu interu signatu di dimensioni punteru.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! U novu codice deve aduprà e costanti associate direttamente nantu à u tippu primitivu.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }