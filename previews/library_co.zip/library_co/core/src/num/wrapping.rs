//! Definizione di `Wrapping<T>`.

use crate::fmt;
use crate::ops::{Add, AddAssign, BitAnd, BitAndAssign, BitOr, BitOrAssign};
use crate::ops::{BitXor, BitXorAssign, Div, DivAssign};
use crate::ops::{Mul, MulAssign, Neg, Not, Rem, RemAssign};
use crate::ops::{Shl, ShlAssign, Shr, ShrAssign, Sub, SubAssign};

/// Fornisce aritmetica avvolta intenzionalmente in `T`.
///
/// L'operazioni cum'è `+` nantu à i valori `u32` sò destinati à ùn mai micca sopra, è in alcune configurazioni di debug u overflow hè rilevatu è risultati in un panic.
/// Mentre a maiò parte di l'aritmetica rientra in questa categuria, qualchì codice aspetta esplicitamente è si basa nantu à l'aritmetica modulare (per esempiu, hashing).
///
/// L'aritmetica di avvolgimentu pò esse ottenuta sia cù metudi cum'è `wrapping_add`, sia cù u tippu `Wrapping<T>`, chì dice chì tutte l'operazioni aritmetiche standard nantu à u valore sottostante sò destinate à avè una semantica di avvolgimentu.
///
///
/// U valore sottostante pò esse recuperatu attraversu l'indice `.0` di a tupla `Wrapping`.
///
/// # Examples
///
/// ```
/// use std::num::Wrapping;
///
/// let zero = Wrapping(0u32);
/// let one = Wrapping(1u32);
///
/// assert_eq!(u32::MAX, (zero - one).0);
/// ```
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(PartialEq, Eq, PartialOrd, Ord, Clone, Copy, Default, Hash)]
#[repr(transparent)]
pub struct Wrapping<T>(#[stable(feature = "rust1", since = "1.0.0")] pub T);

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for Wrapping<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[stable(feature = "wrapping_display", since = "1.10.0")]
impl<T: fmt::Display> fmt::Display for Wrapping<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[stable(feature = "wrapping_fmt", since = "1.11.0")]
impl<T: fmt::Binary> fmt::Binary for Wrapping<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[stable(feature = "wrapping_fmt", since = "1.11.0")]
impl<T: fmt::Octal> fmt::Octal for Wrapping<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[stable(feature = "wrapping_fmt", since = "1.11.0")]
impl<T: fmt::LowerHex> fmt::LowerHex for Wrapping<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[stable(feature = "wrapping_fmt", since = "1.11.0")]
impl<T: fmt::UpperHex> fmt::UpperHex for Wrapping<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[allow(unused_macros)]
macro_rules! sh_impl_signed {
    ($t:ident, $f:ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Shl<$f> for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn shl(self, other: $f) -> Wrapping<$t> {
                if other < 0 {
                    Wrapping(self.0.wrapping_shr((-other & self::shift_max::$t as $f) as u32))
                } else {
                    Wrapping(self.0.wrapping_shl((other & self::shift_max::$t as $f) as u32))
                }
            }
        }
        forward_ref_binop! { impl Shl, shl for Wrapping<$t>, $f,
        #[stable(feature = "wrapping_ref_ops", since = "1.39.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl ShlAssign<$f> for Wrapping<$t> {
            #[inline]
            fn shl_assign(&mut self, other: $f) {
                *self = *self << other;
            }
        }
        forward_ref_op_assign! { impl ShlAssign, shl_assign for Wrapping<$t>, $f }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl Shr<$f> for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn shr(self, other: $f) -> Wrapping<$t> {
                if other < 0 {
                    Wrapping(self.0.wrapping_shl((-other & self::shift_max::$t as $f) as u32))
                } else {
                    Wrapping(self.0.wrapping_shr((other & self::shift_max::$t as $f) as u32))
                }
            }
        }
        forward_ref_binop! { impl Shr, shr for Wrapping<$t>, $f,
        #[stable(feature = "wrapping_ref_ops", since = "1.39.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl ShrAssign<$f> for Wrapping<$t> {
            #[inline]
            fn shr_assign(&mut self, other: $f) {
                *self = *self >> other;
            }
        }
        forward_ref_op_assign! { impl ShrAssign, shr_assign for Wrapping<$t>, $f }
    };
}

macro_rules! sh_impl_unsigned {
    ($t:ident, $f:ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Shl<$f> for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn shl(self, other: $f) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_shl((other & self::shift_max::$t as $f) as u32))
            }
        }
        forward_ref_binop! { impl Shl, shl for Wrapping<$t>, $f,
        #[stable(feature = "wrapping_ref_ops", since = "1.39.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl ShlAssign<$f> for Wrapping<$t> {
            #[inline]
            fn shl_assign(&mut self, other: $f) {
                *self = *self << other;
            }
        }
        forward_ref_op_assign! { impl ShlAssign, shl_assign for Wrapping<$t>, $f }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl Shr<$f> for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn shr(self, other: $f) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_shr((other & self::shift_max::$t as $f) as u32))
            }
        }
        forward_ref_binop! { impl Shr, shr for Wrapping<$t>, $f,
        #[stable(feature = "wrapping_ref_ops", since = "1.39.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl ShrAssign<$f> for Wrapping<$t> {
            #[inline]
            fn shr_assign(&mut self, other: $f) {
                *self = *self >> other;
            }
        }
        forward_ref_op_assign! { impl ShrAssign, shr_assign for Wrapping<$t>, $f }
    };
}

// FIXME (#23545): scummentate i resti impls
macro_rules! sh_impl_all {
    ($($t:ident)*) => ($(
        // sh_impl_unsigned!{ $t, u8 } sh_impl_unsigned!{ $t, u16 } sh_impl_unsigned!{ $t, u32 } sh_impl_unsigned!{ $t, u64 } sh_impl_unsigned! { $t, u128 }
        //
        //
        //
        //
        sh_impl_unsigned! { $t, usize }

        // sh_impl_signed!{ $t, i8 } sh_impl_signed!{ $t, i16 } sh_impl_signed!{ $t, i32 } sh_impl_signed!{ $t, i64 } sh_impl_signed!{ $t, i128 } sh_impl_signed! { $t, isize }
        //
        //
        //
        //
        //
    )*)
}

sh_impl_all! { u8 u16 u32 u64 u128 usize i8 i16 i32 i64 i128 isize }

// FIXME(30524): impl Op<T>per Imballaggio<T>, impl OpAssign<T>per Imballaggio<T>
macro_rules! wrapping_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Add for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn add(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_add(other.0))
            }
        }
        forward_ref_binop! { impl Add, add for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl AddAssign for Wrapping<$t> {
            #[inline]
            fn add_assign(&mut self, other: Wrapping<$t>) {
                *self = *self + other;
            }
        }
        forward_ref_op_assign! { impl AddAssign, add_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl Sub for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn sub(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_sub(other.0))
            }
        }
        forward_ref_binop! { impl Sub, sub for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl SubAssign for Wrapping<$t> {
            #[inline]
            fn sub_assign(&mut self, other: Wrapping<$t>) {
                *self = *self - other;
            }
        }
        forward_ref_op_assign! { impl SubAssign, sub_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl Mul for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn mul(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_mul(other.0))
            }
        }
        forward_ref_binop! { impl Mul, mul for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl MulAssign for Wrapping<$t> {
            #[inline]
            fn mul_assign(&mut self, other: Wrapping<$t>) {
                *self = *self * other;
            }
        }
        forward_ref_op_assign! { impl MulAssign, mul_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "wrapping_div", since = "1.3.0")]
        impl Div for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn div(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_div(other.0))
            }
        }
        forward_ref_binop! { impl Div, div for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl DivAssign for Wrapping<$t> {
            #[inline]
            fn div_assign(&mut self, other: Wrapping<$t>) {
                *self = *self / other;
            }
        }
        forward_ref_op_assign! { impl DivAssign, div_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "wrapping_impls", since = "1.7.0")]
        impl Rem for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn rem(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_rem(other.0))
            }
        }
        forward_ref_binop! { impl Rem, rem for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl RemAssign for Wrapping<$t> {
            #[inline]
            fn rem_assign(&mut self, other: Wrapping<$t>) {
                *self = *self % other;
            }
        }
        forward_ref_op_assign! { impl RemAssign, rem_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl Not for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn not(self) -> Wrapping<$t> {
                Wrapping(!self.0)
            }
        }
        forward_ref_unop! { impl Not, not for Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl BitXor for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn bitxor(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0 ^ other.0)
            }
        }
        forward_ref_binop! { impl BitXor, bitxor for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl BitXorAssign for Wrapping<$t> {
            #[inline]
            fn bitxor_assign(&mut self, other: Wrapping<$t>) {
                *self = *self ^ other;
            }
        }
        forward_ref_op_assign! { impl BitXorAssign, bitxor_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl BitOr for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn bitor(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0 | other.0)
            }
        }
        forward_ref_binop! { impl BitOr, bitor for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl BitOrAssign for Wrapping<$t> {
            #[inline]
            fn bitor_assign(&mut self, other: Wrapping<$t>) {
                *self = *self | other;
            }
        }
        forward_ref_op_assign! { impl BitOrAssign, bitor_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl BitAnd for Wrapping<$t> {
            type Output = Wrapping<$t>;

            #[inline]
            fn bitand(self, other: Wrapping<$t>) -> Wrapping<$t> {
                Wrapping(self.0 & other.0)
            }
        }
        forward_ref_binop! { impl BitAnd, bitand for Wrapping<$t>, Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl BitAndAssign for Wrapping<$t> {
            #[inline]
            fn bitand_assign(&mut self, other: Wrapping<$t>) {
                *self = *self & other;
            }
        }
        forward_ref_op_assign! { impl BitAndAssign, bitand_assign for Wrapping<$t>, Wrapping<$t> }

        #[stable(feature = "wrapping_neg", since = "1.10.0")]
        impl Neg for Wrapping<$t> {
            type Output = Self;
            #[inline]
            fn neg(self) -> Self {
                Wrapping(0) - self
            }
        }
        forward_ref_unop! { impl Neg, neg for Wrapping<$t>,
                #[stable(feature = "wrapping_ref", since = "1.14.0")] }

    )*)
}

wrapping_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

macro_rules! wrapping_int_impl {
    ($($t:ty)*) => ($(
        impl Wrapping<$t> {
            /// Restituisce u valore u più chjucu chì pò esse ripresentatu da stu tipu interu.
            ///
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            #[doc = concat!("assert_eq!(<Wrapping<", stringify!($t), ">>::MIN, Wrapping(", stringify!($t), "::MIN));")]
            /// ```
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const MIN: Self = Self(<$t>::MIN);

            /// Restituisce u valore più grande chì pò esse rappresentatu da stu tipu interu.
            ///
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            #[doc = concat!("assert_eq!(<Wrapping<", stringify!($t), ">>::MAX, Wrapping(", stringify!($t), "::MAX));")]
            /// ```
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const MAX: Self = Self(<$t>::MAX);

            /// Restituisce u numeru di quelli in a rappresentazione binaria di `self`.
            ///
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            #[doc = concat!("let n = Wrapping(0b01001100", stringify!($t), ");")]
            /// assert_eq!(n.count_ones(), 3);
            /// ```
            #[inline]
            #[doc(alias = "popcount")]
            #[doc(alias = "popcnt")]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn count_ones(self) -> u32 {
                self.0.count_ones()
            }

            /// Restituisce u numeru di zeru in a rappresentazione binaria di `self`.
            ///
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            #[doc = concat!("assert_eq!(Wrapping(!0", stringify!($t), ").count_zeros(), 0);")]
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn count_zeros(self) -> u32 {
                self.0.count_zeros()
            }

            /// Restituisce u numeru di zeru finale in a rappresentazione binaria di `self`.
            ///
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            #[doc = concat!("let n = Wrapping(0b0101000", stringify!($t), ");")]
            /// assert_eq!(n.trailing_zeros(), 3);
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn trailing_zeros(self) -> u32 {
                self.0.trailing_zeros()
            }

            /// Sposta i bit à sinistra per una quantità specificata, `n`, avvolgendu i bit truncati à a fine di u numeru interu resultante.
            ///
            ///
            /// Per piacè nutate chì questu ùn hè micca a stessa operazione cum'è l'operatore di cambiamentu `<<`!
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// use std::num::Wrapping;
            ///
            /// let n: Wrapping<i64> = Wrapping(0x0123456789ABCDEF);
            /// let m: Wrapping<i64> = Wrapping(-0x76543210FEDCBA99);
            ///
            /// assert_eq!(n.rotate_left(32), m);
            /// ```
            ///
            ///
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn rotate_left(self, n: u32) -> Self {
                Wrapping(self.0.rotate_left(n))
            }

            /// Sposta i bit à a diritta per una quantità specificata, `n`, avvolgendu i bit truncati finu à u principiu di u numeru interu resultante.
            ///
            ///
            /// Per piacè nutate chì questu ùn hè micca a stessa operazione cum'è l'operatore di cambiamentu `>>`!
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// use std::num::Wrapping;
            ///
            /// let n: Wrapping<i64> = Wrapping(0x0123456789ABCDEF);
            /// let m: Wrapping<i64> = Wrapping(-0xFEDCBA987654322);
            ///
            /// assert_eq!(n.rotate_right(4), m);
            /// ```
            ///
            ///
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn rotate_right(self, n: u32) -> Self {
                Wrapping(self.0.rotate_right(n))
            }

            /// Inverte l'ordine di byte di u numeru interu.
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// use std::num::Wrapping;
            ///
            /// let n: Wrapping<i16> = Wrapping(0b0000000_01010101);
            /// assert_eq!(n, Wrapping(85));
            ///
            /// let m = n.swap_bytes();
            ///
            /// assert_eq!(m, Wrapping(0b01010101_00000000));
            /// assert_eq!(m, Wrapping(21760));
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn swap_bytes(self) -> Self {
                Wrapping(self.0.swap_bytes())
            }

            /// Inverte u schema di bit di u numeru sanu.
            ///
            /// # Examples
            ///
            /// Per piacè nutate chì questu esempiu hè spartutu trà tippi interi.
            /// Chì spiega perchè `i16` hè adupratu quì.
            ///
            /// Usu di basa:
            ///
            /// ```
            /// use std::num::Wrapping;
            ///
            /// let n = Wrapping(0b0000000_01010101i16);
            /// assert_eq!(n, Wrapping(85));
            ///
            /// let m = n.reverse_bits();
            ///
            /// assert_eq!(m.0 as u16, 0b10101010_00000000);
            /// assert_eq!(m, Wrapping(-22016));
            /// ```
            #[stable(feature = "reverse_bits", since = "1.37.0")]
            #[rustc_const_stable(feature = "const_reverse_bits", since = "1.37.0")]
            #[inline]
            #[must_use]
            pub const fn reverse_bits(self) -> Self {
                Wrapping(self.0.reverse_bits())
            }

            /// Converte un interu da big endian in endianness di u target.
            ///
            ///
            /// In big endian questu hè un no-op.
            /// In pocu endian i byte sò scambiati.
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            #[doc = concat!("let n = Wrapping(0x1A", stringify!($t), ");")]
            /// se cfg! (target_endian= "big"){
            #[doc = concat!("    assert_eq!(<Wrapping<", stringify!($t), ">>::from_be(n), n)")]
            /// } altru {
            #[doc = concat!("    assert_eq!(<Wrapping<", stringify!($t), ">>::from_be(n), n.swap_bytes())")]
            /// }
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn from_be(x: Self) -> Self {
                Wrapping(<$t>::from_be(x.0))
            }

            /// Converte un interu da pocu endian à endianness di u target.
            ///
            ///
            /// In pocu endian questu hè un no-op.
            /// In big endian i byte sò scambiati.
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            #[doc = concat!("let n = Wrapping(0x1A", stringify!($t), ");")]
            /// se cfg! (target_endian= "little"){
            #[doc = concat!("    assert_eq!(<Wrapping<", stringify!($t), ">>::from_le(n), n)")]
            /// } altru {
            #[doc = concat!("    assert_eq!(<Wrapping<", stringify!($t), ">>::from_le(n), n.swap_bytes())")]
            /// }
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn from_le(x: Self) -> Self {
                Wrapping(<$t>::from_le(x.0))
            }

            /// Converte `self` in big endian da l'endianness di u target.
            ///
            ///
            /// In big endian questu hè un no-op.
            /// In pocu endian i byte sò scambiati.
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            #[doc = concat!("let n = Wrapping(0x1A", stringify!($t), ");")]
            /// se cfg! (target_endian= "big"){
            ///     assert_eq!(n.to_be(), n)
            /// } altru { assert_eq!(n.to_be(), n.swap_bytes()) }
            ///
            /// ```
            ///
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn to_be(self) -> Self {
                Wrapping(self.0.to_be())
            }

            /// Converte `self` in pocu endian da l'endianness di u target.
            ///
            ///
            /// In pocu endian questu hè un no-op.
            /// In big endian i byte sò scambiati.
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            #[doc = concat!("let n = Wrapping(0x1A", stringify!($t), ");")]
            /// se cfg! (target_endian= "little"){
            ///     assert_eq!(n.to_le(), n)
            /// } altru { assert_eq!(n.to_le(), n.swap_bytes()) }
            ///
            /// ```
            ///
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn to_le(self) -> Self {
                Wrapping(self.0.to_le())
            }

            /// Rialza u so autore à a putenza di `exp`, aduprendu l'esponenziazione à u quadratu.
            ///
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            #[doc = concat!("assert_eq!(Wrapping(3", stringify!($t), ").pow(4), Wrapping(81));")]
            /// ```
            ///
            /// Results that are too large are wrapped:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            ///
            /// assert_eq!(Wrapping(3i8).pow(5), Wrapping(-13));
            /// assert_eq!(Wrapping(3i8).pow(6), Wrapping(-39));
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub fn pow(self, exp: u32) -> Self {
                Wrapping(self.0.wrapping_pow(exp))
            }
        }
    )*)
}

wrapping_int_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

macro_rules! wrapping_int_impl_signed {
    ($($t:ty)*) => ($(
        impl Wrapping<$t> {
            /// Restituisce u numeru di zeri principali in a rapprisintazione binaria di `self`.
            ///
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            #[doc = concat!("let n = Wrapping(", stringify!($t), "::MAX) >> 2;")]
            /// assert_eq!(n.leading_zeros(), 3);
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn leading_zeros(self) -> u32 {
                self.0.leading_zeros()
            }

            /// Calcula u valore assolutu di `self`, avvolgendusi intornu à a fruntiera di u tippu.
            ///
            /// L'unicu casu induve un tale imballu pò accade hè quandu si piglia u valore assolutu di u valore minimu negativu per u tippu questu hè un valore pusitivu chì hè troppu grande per rapprisintà in u tippu.
            /// In tale casu, sta funzione rende `MIN` stessa.
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            ///
            ///
            ///
            #[doc = concat!("assert_eq!(Wrapping(100", stringify!($t), ").abs(), Wrapping(100));")]
            #[doc = concat!("assert_eq!(Wrapping(-100", stringify!($t), ").abs(), Wrapping(100));")]
            #[doc = concat!("assert_eq!(Wrapping(", stringify!($t), "::MIN).abs(), Wrapping(", stringify!($t), "::MIN));")]
            /// assert_eq!(Wrapping(-128i8).abs().0 as u8, 128u8);
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub fn abs(self) -> Wrapping<$t> {
                Wrapping(self.0.wrapping_abs())
            }

            /// Restituisce un numeru chì riprisenta u segnu di `self`.
            ///
            ///
            ///  - `0` se u numeru hè zeru
            ///  - `1` se u numeru hè pusitivu
            ///  - `-1` se u numeru hè negativu
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            #[doc = concat!("assert_eq!(Wrapping(10", stringify!($t), ").signum(), Wrapping(1));")]
            #[doc = concat!("assert_eq!(Wrapping(0", stringify!($t), ").signum(), Wrapping(0));")]
            #[doc = concat!("assert_eq!(Wrapping(-10", stringify!($t), ").signum(), Wrapping(-1));")]
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub fn signum(self) -> Wrapping<$t> {
                Wrapping(self.0.signum())
            }

            /// Restituisce `true` se `self` hè pusitivu è `false` se u numeru hè zeru o negativu.
            ///
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            ///
            #[doc = concat!("assert!(Wrapping(10", stringify!($t), ").is_positive());")]
            #[doc = concat!("assert!(!Wrapping(-10", stringify!($t), ").is_positive());")]
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn is_positive(self) -> bool {
                self.0.is_positive()
            }

            /// Restituisce `true` se `self` hè negativu è `false` se u numeru hè zeru o pusitivu.
            ///
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            ///
            #[doc = concat!("assert!(Wrapping(-10", stringify!($t), ").is_negative());")]
            #[doc = concat!("assert!(!Wrapping(10", stringify!($t), ").is_negative());")]
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn is_negative(self) -> bool {
                self.0.is_negative()
            }
        }
    )*)
}

wrapping_int_impl_signed! { isize i8 i16 i32 i64 i128 }

macro_rules! wrapping_int_impl_unsigned {
    ($($t:ty)*) => ($(
        impl Wrapping<$t> {
            /// Restituisce u numeru di zeri principali in a rapprisintazione binaria di `self`.
            ///
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            #[doc = concat!("let n = Wrapping(", stringify!($t), "::MAX) >> 2;")]
            /// assert_eq!(n.leading_zeros(), 2);
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub const fn leading_zeros(self) -> u32 {
                self.0.leading_zeros()
            }

            /// Ritorna `true` se è solu se `self == 2^k` per qualchì `k`.
            ///
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_int_impl)]
            /// aduprà std::num::Wrapping;
            #[doc = concat!("assert!(Wrapping(16", stringify!($t), ").is_power_of_two());")]
            #[doc = concat!("assert!(!Wrapping(10", stringify!($t), ").is_power_of_two());")]
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_int_impl", issue = "32463")]
            pub fn is_power_of_two(self) -> bool {
                self.0.is_power_of_two()
            }

            /// Restituisce a putenza più chjuca di duie più grande o uguale à `self`.
            ///
            /// Quandu u valore di ritornu sferisce (vale à dì, `self > (1 << (N-1))` per u tippu `uN`), sferisce à `2^N = 0`.
            ///
            ///
            /// # Examples
            ///
            /// Usu di basa:
            ///
            /// ```
            /// #![feature(wrapping_next_power_of_two)]
            /// aduprà std::num::Wrapping;
            ///
            #[doc = concat!("assert_eq!(Wrapping(2", stringify!($t), ").next_power_of_two(), Wrapping(2));")]
            #[doc = concat!("assert_eq!(Wrapping(3", stringify!($t), ").next_power_of_two(), Wrapping(4));")]
            #[doc = concat!("assert_eq!(Wrapping(200_u8).next_power_of_two(), Wrapping(0));")]
            /// ```
            #[inline]
            #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                       reason = "needs decision on wrapping behaviour")]
            pub fn next_power_of_two(self) -> Self {
                Wrapping(self.0.wrapping_next_power_of_two())
            }
        }
    )*)
}

wrapping_int_impl_unsigned! { usize u8 u16 u32 u64 u128 }

mod shift_max {
    #![allow(non_upper_case_globals)]

    #[cfg(target_pointer_width = "16")]
    mod platform {
        pub const usize: u32 = super::u16;
        pub const isize: u32 = super::i16;
    }

    #[cfg(target_pointer_width = "32")]
    mod platform {
        pub const usize: u32 = super::u32;
        pub const isize: u32 = super::i32;
    }

    #[cfg(target_pointer_width = "64")]
    mod platform {
        pub const usize: u32 = super::u64;
        pub const isize: u32 = super::i64;
    }

    pub const i8: u32 = (1 << 3) - 1;
    pub const i16: u32 = (1 << 4) - 1;
    pub const i32: u32 = (1 << 5) - 1;
    pub const i64: u32 = (1 << 6) - 1;
    pub const i128: u32 = (1 << 7) - 1;
    pub use self::platform::isize;

    pub const u8: u32 = i8;
    pub const u16: u32 = i16;
    pub const u32: u32 = i32;
    pub const u64: u32 = i64;
    pub const u128: u32 = i128;
    pub use self::platform::usize;
}