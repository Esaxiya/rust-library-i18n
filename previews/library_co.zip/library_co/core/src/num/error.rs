//! Tipi d'errore per a cunversione in tippi integrali.

use crate::convert::Infallible;
use crate::fmt;

/// U tippu d'errore hà tornatu quandu una cunversione di tippu integrale verificatu fiasca.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Incuntrà piuttostu chè coercì per assicurassi chì u codice cum'è `From<Infallible> for TryFromIntError` sopra continuerà à travaglià quandu `Infallible` diventa un alias di `!`.
        //
        //
        match never {}
    }
}

/// Un errore chì pò esse restituitu quandu analizza un numeru interu.
///
/// Stu errore hè adupratu cum'è tippu d'errore per e funzioni `from_str_radix()` nantu à i tippi interi primitivi, cum'è [`i8::from_str_radix`].
///
/// # Cause putenziali
///
/// Frà altre cause, `ParseIntError` pò esse lanciatu per via di un spaziu biancu di punta o di fine in a stringa per esempiu, quandu hè ottenutu da l'input standard.
///
/// Aduprà u metudu [`str::trim()`] assicura chì nisun spaziu biancu fermi prima di parsighjà.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum per archivà i vari tippi di errori chì ponu causà l'analisi di un interu per fallu.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// U valore chì hè analizatu hè viotu.
    ///
    /// Frà altre cause, sta variante serà custruita quandu si analizza una stringa viota.
    Empty,
    /// Cuntene un cifru invalidu in u so cuntestu.
    ///
    /// Frà altre cause, sta variante serà custruita quandu si analizza una stringa chì cuntene un caratteru micca ASCII.
    ///
    /// Questa variante hè ancu custruita quandu un `+` o `-` hè spiazzatu in una stringa sia da sola sia à mezu à un numeru.
    ///
    ///
    InvalidDigit,
    /// Integer hè troppu grande per almacenà in u tipu interu di destinazione.
    PosOverflow,
    /// Integer hè troppu chjucu per almacenà in u tipu interu di destinazione.
    NegOverflow,
    /// U valore era Zero
    ///
    /// Questa variante serà emessa quandu a stringa di analisi hà un valore zero, chì sarebbe illegale per i tippi diversi da zero.
    ///
    Zero,
}

impl ParseIntError {
    /// Emette a causa dettagliata di l'analisi di un interu fallendu.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}