/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// mentre questu hè assai documentatu, questu hè in principiu privatu chì hè resu publicu solu per pruvà.
// ùn ci esponi micca.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// Algoritmi di generazione di cifri.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// A dimensione minima di u buffer necessariu per u modu più cortu.
///
/// Hè un pocu micca banale per derivà, ma questu hè unu più u numeru massimu di cifre decimali significative da algoritmi di furmatu cù u risultatu u più cortu.
///
/// A formula esatta hè `ceil(# bits in mantissa * log_10 2 + 1)`.
pub const MAX_SIG_DIGITS: usize = 17;

/// Quandu `d` cuntene cifre decimali, aumentate l'ultima cifra è propagate u portu.
/// Restituisce una prossima cifra quandu face cambià a lunghezza.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] hè tuttu nove
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 gira à 1000..000 cun un espunente aumentatu
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // un buffer vacante arrotonda (un pocu stranu ma ragiunevule)
            Some(b'1')
        }
    }
}

/// Parti furmattate.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// Datu numeru di zeru cifre.
    Zero(usize),
    /// Un numeru litterale finu à 5 cifre.
    Num(u16),
    /// Una copia testuale di byte dati.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// Restituisce a lunghezza esatta di byte di una parte data.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// Scrive una parte in u buffer furnitu.
    /// Restituisce u numeru di byte scritti, o `None` se u buffer ùn hè micca abbastanza.
    /// (Pò ancu lascià byte parzialmente scritti in u buffer; ùn fidate micca à què.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// Risultatu furmatu chì cuntene una o più parti.
/// Questu pò esse scrittu in u buffer byte o cunvertitu in a stringa attribuita.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// Una fetta di byte chì riprisenta un segnu, sia `""`, `"-"` o `"+"`.
    pub sign: &'static str,
    /// Parti furmattate da esse rese dopu un segnu è padding zero opzionale.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// Restituisce a lunghezza esatta di byte di u risultatu furmatu cumbinatu.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// Scrive tutte e parti furmattate in u buffer furnitu.
    /// Restituisce u numeru di byte scritti, o `None` se u buffer ùn hè micca abbastanza.
    /// (Pò ancu lascià byte parzialmente scritti in u buffer; ùn fidate micca à què.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// Formati dati cifri decimali `0.<...buf...> * 10^exp` in a forma decimali cù almenu numeru datu di cifre frazziunali.
///
/// U risultatu hè almacenatu in a serie di parti furnite è una fetta di parti scritte hè restituita.
///
/// `frac_digits` pò esse menu di u numeru di numeri frazziunali effettivi in `buf`;
/// serà ignoratu è e cifre complete seranu stampate.Hè adupratu solu per stampà zeru addiziunali dopu e cifre rese.
/// Cusì `frac_digits` di 0 significa chì stamperà solu cifre date è nunda altru.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // s'ellu ci hè a restrizzione nantu à l'ultima cifra, `buf` hè presumutu da esse abbandunatu cù i zeru virtuale.
    // u numeru di zeru virtuale, `nzeroes`, uguale à `max(0, exp + frac_digits - buf.len())`, cusì chì a pusizione di l'ultima cifra `exp - buf.len() - nzeroes` ùn hè più cà `-frac_digits`:
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |zeroes |exp
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` hè calculatu individualmente per ogni casu per evità u overflow.
    //

    if exp <= 0 {
        // u puntu decimali hè prima di e cifre rese: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // SICUREZZA: avemu solu inizializatu l'elementi `..4`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // SICUREZZA: avemu solu inizializatu l'elementi `..3`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // u puntu decimali hè in i numeri resi: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // SICUREZZA: avemu solu inizializatu l'elementi `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // SICUREZZA: avemu solu inizializatu l'elementi `..3`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // u puntu decimali hè dopu à cifri resi: [1234][____0000] o [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // SICUREZZA: avemu solu inizializatu l'elementi `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // SICUREZZA: avemu solu inizializatu l'elementi `..2`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// Formata e cifre decimali date `0.<...buf...> * 10^exp` in a forma esponenziale cù almenu u numeru datu di cifre significative.
///
/// Quandu `upper` hè `true`, l'esponente serà prefissatu da `E`;altrimente hè `e`.
/// U risultatu hè almacenatu in a serie di parti furnite è una fetta di parti scritte hè restituita.
///
/// `min_digits` pò esse menu di u numeru di numeri significativi effettivi in `buf`;
/// serà ignoratu è e cifre complete seranu stampate.Hè adupratu solu per stampà zeru addiziunali dopu e cifre rese.
/// Cusì, `min_digits == 0` significa chì stamperà solu e cifre date è nunda di più.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // evità u sfruttamentu quandu exp hè i16::MIN
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // SICUREZZA: avemu solu inizializatu l'elementi `..n + 2`.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// Opzioni di furmatu di segnu.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// Stampa `-` solu per i valori negativi non nulli.
    Minus, // -inf -1 0 0 1 inf nan
    /// Stampa `-` solu per qualsiasi valore negativu (cumpresu u zeru negativu).
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// Stampa `-` per i valori negativi diversi da zero, o `+` altrimenti.
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// Stampa `-` per qualsiasi valore negativu (cumpresu u zeru negativu), o `+` altrimente.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// Restituisce a stringa di byte staticu chì currisponde à u segnu da formattà.
/// Pò esse sia `""`, `"+"` o `"-"`.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// Formata u numeru in virgola flottante datu in a forma decimale cù almenu numeru datu di cifre frazziunali.
/// U risultatu hè almacenatu in a serie di parti furnite mentre aduprendu u buffer di byte datu cum'è un graffiu.
/// `upper` hè attualmente inutilizatu ma lascia per a decisione future di cambià u casu di i valori non finiti, vale à dì, `inf` è `nan`.
///
/// A prima parte da esse resa hè sempre un `Part::Sign` (chì pò esse una stringa viota se nisun segnu hè resu).
///
/// `format_shortest` duverebbe esse a funzione di generazione di cifre sottostante.
/// Deve restituisce a parte di u buffer chì hà iniziatu.
/// Probabilmente vulete un `strategy::grisu::format_shortest` per questu.
///
/// `frac_digits` pò esse menu di u numeru di numeri frazziunali effettivi in `v`;
/// serà ignoratu è e cifre complete seranu stampate.Hè adupratu solu per stampà zeru addiziunali dopu e cifre rese.
/// Cusì `frac_digits` di 0 significa chì stamperà solu cifre date è nunda altru.
///
/// U buffer byte deve esse almenu `MAX_SIG_DIGITS` byte longu.
/// Ci deve esse almenu 4 parti dispunibili, per via di u peghju casu cum'è `[+][0.][0000][2][0000]` cù `frac_digits = 10`.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SICUREZZA: avemu solu inizializatu l'elementi `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SICUREZZA: avemu solu inizializatu l'elementi `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // SICUREZZA: avemu solu inizializatu l'elementi `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // SICUREZZA: avemu solu inizializatu l'elementi `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// Formata u numeru in virgulette datu in a forma decimali o in a forma esponenziale, secondu l'esponente resultante.
/// U risultatu hè almacenatu in a serie di parti furnite mentre aduprendu u buffer di byte datu cum'è un graffiu.
/// `upper` hè adupratu per determinà u casu di valori non finiti (`inf` è `nan`) o u casu di u prefissu esponente (`e` o `E`).
/// A prima parte da esse resa hè sempre un `Part::Sign` (chì pò esse una stringa viota se nisun segnu hè resu).
///
/// `format_shortest` duverebbe esse a funzione di generazione di cifre sottostante.
/// Deve restituisce a parte di u buffer chì hà iniziatu.
/// Probabilmente vulete un `strategy::grisu::format_shortest` per questu.
///
/// U `dec_bounds` hè una tupla `(lo, hi)` tale chì u numeru hè furmattatu cum'è decimali solu quandu `10^lo <= V < 10^hi`.
/// Innota chì questu hè u *apparente*`V` invece di u `v` attuale!Cusì qualsiasi espunente stampatu in a forma esponenziale ùn pò micca esse in questa gamma, evitendu ogni cunfusione.
///
///
/// U buffer byte deve esse almenu `MAX_SIG_DIGITS` byte longu.
/// Ci deve esse almenu 6 parti dispunibili, per via di u peghju casu cum'è `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SICUREZZA: avemu solu inizializatu l'elementi `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SICUREZZA: avemu solu inizializatu l'elementi `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // SICUREZZA: avemu solu inizializatu l'elementi `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// Restituisce una apprussimazione piuttostu grezza (limite superiore) per a dimensione massima di u buffer calculata da l'esponente decodificatu datu.
///
/// U limitu esattu hè:
///
/// - quandu `exp < 0`, a lunghezza massima hè `ceil(log_10 (5^-exp * (2^64 - 1)))`.
/// - quandu `exp >= 0`, a lunghezza massima hè `ceil(log_10 (2^exp * (2^64 - 1)))`.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` hè menu di `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)`, chì hè a so volta menu di `20 + (1 + exp* log_10 x)`.
/// Usemu i fatti chì `log_10 2 < 5/16` è `log_10 5 < 12/16`, chì hè abbastanza per i nostri scopi.
///
/// Perchè avemu bisognu di questu?E funzioni `format_exact` riempiranu l'interu buffer, à menu chì limitate da l'ultima restrizione di cifre, ma hè pussibule chì u numeru di cifre richieste sia ridiculamente grande (per esempiu, 30.000 cifre).
///
/// A grande maggioranza di u buffer sarà piena di zeru, allora ùn vulemu micca assignà tuttu u buffer in anticipu.
/// Di cunsiguenza, per qualsiasi argumenti dati,
/// 826 bytes di buffer devenu esse abbastanza per `f64`.Paragunate cù u numeru propiu per u peghju casu: 770 byte (quandu `exp = -1074`).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// Formati datu un numeru in virgula flottante in a forma esponenziale cun numeru esattamente datu di cifre significative.
/// U risultatu hè almacenatu in a serie di parti furnite mentre aduprendu u buffer di byte datu cum'è un graffiu.
/// `upper` hè adupratu per determinà u casu di u prefissu esponente (`e` o `E`).
/// A prima parte da esse resa hè sempre un `Part::Sign` (chì pò esse una stringa viota se nisun segnu hè resu).
///
/// `format_exact` duverebbe esse a funzione di generazione di cifre sottostante.
/// Deve restituisce a parte di u buffer chì hà iniziatu.
/// Probabilmente vulete un `strategy::grisu::format_exact` per questu.
///
/// U buffer byte deve esse almenu `ndigits` byte longu à menu chì `ndigits` sia cusì grande chì solu u numeru fissu di cifre serà mai scrittu.
/// (U puntu di punta per `f64` hè di circa 800, dunque 1000 bytes devenu esse abbastanza.) Ci duveria esse almenu 6 parti dispunibili, per via di u peghju casu cum'è `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SICUREZZA: avemu solu inizializatu l'elementi `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SICUREZZA: avemu solu inizializatu l'elementi `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // SICUREZZA: avemu solu inizializatu l'elementi `..3`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // SICUREZZA: avemu solu inizializatu l'elementi `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// Formati datu un numeru in virgula flottante in a forma decimali cun numeru esattamente datu di cifre frazziunali.
/// U risultatu hè almacenatu in a serie di parti furnite mentre aduprendu u buffer di byte datu cum'è un graffiu.
/// `upper` hè attualmente inutilizatu ma lascia per a decisione future di cambià u casu di i valori non finiti, vale à dì, `inf` è `nan`.
/// A prima parte da esse resa hè sempre un `Part::Sign` (chì pò esse una stringa viota se nisun segnu hè resu).
///
/// `format_exact` duverebbe esse a funzione di generazione di cifre sottostante.
/// Deve restituisce a parte di u buffer chì hà iniziatu.
/// Probabilmente vulete un `strategy::grisu::format_exact` per questu.
///
/// U buffer byte deve esse abbastanza per l'output a menu chì `frac_digits` sia cusì grande chì solu u numeru fissu di cifre serà mai scrittu.
/// (U puntu di punta per `f64` hè di circa 800, è 1000 bytes devenu esse abbastanza.) Ci deve esse almenu 4 parti dispunibili, per via di u peghju casu cum'è `[+][0.][0000][2][0000]` cù `frac_digits = 10`.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SICUREZZA: avemu solu inizializatu l'elementi `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SICUREZZA: avemu solu inizializatu l'elementi `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // SICUREZZA: avemu solu inizializatu l'elementi `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // SICUREZZA: avemu solu inizializatu l'elementi `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // *hè* pussibule chì `frac_digits` sia ridículamente grande.
            // `format_exact` finiscerà di rende e cifre assai prima in questu casu, perchè simu strettamente limitati da `maxlen`.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // a restrizione ùn pudia micca esse soddisfatta, allora questu deve esse resu cum'è zero, ùn importa `exp` era.
                // questu ùn include micca u casu chì a restrizione sia stata rispettata solu dopu l'arrotondamentu finale;hè un casu regulare cù `exp = limit + 1`.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // SICUREZZA: avemu solu inizializatu l'elementi `..2`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // SICUREZZA: avemu solu inizializatu l'elementi `..1`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}