//! Decodifica un valore in virgola mobile in parti individuali è intervalli di errore.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Valore finitu non firmatu decodificatu, tale chì:
///
/// - U valore originale hè uguale à `mant * 2^exp`.
///
/// - Ogni numeru da `(mant - minus)*2^exp` à `(mant + plus)* 2^exp` arrotonderà à u valore originale.
/// A gamma hè inclusiva solu quandu `inclusive` hè `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// A mantissa scalata.
    pub mant: u64,
    /// A gamma di errore inferiore.
    pub minus: u64,
    /// A gamma di errore superiore.
    pub plus: u64,
    /// L'esponente cumunu in basa 2.
    pub exp: i16,
    /// Hè vera quandu u intervallu di errore hè inclusivu.
    ///
    /// In IEEE 754, questu hè veru quandu a mantissa originale era uniforme.
    pub inclusive: bool,
}

/// Valore senza segnu decodificatu.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infiniti, pusitivi o negativi.
    Infinite,
    /// Zero, sia pusitivu sia negativu.
    Zero,
    /// Numeri finiti cù ulteriori campi decodificati.
    Finite(Decoded),
}

/// Un tippu in virgula flottante chì pò esse `decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// U valore minimu nurmale pusitivu.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Restituisce un segnu (veru quandu hè negativu) è u valore `FullDecoded` da un numeru in virgola flottante datu.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // vicini: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode cunserva sempre l'esponente, dunque a mantissa hè scalata per i subnormali.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // vicini: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // induve maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // vicini: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}