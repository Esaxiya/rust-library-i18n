//! Adattazione Rust di l'algoritmu Grisu3 descrittu in "Stampa di numeri in virgula flottante rapidamente è cun precisione cù numeri interi" [^ 1].
//! Utilizza circa 1 KB di tavula precomputata, è à u so tornu, hè assai veloce per a maiò parte di l'input.
//!
//! [^1]: Florian Loitsch.2010. Stampa rapidamente numeri in virgula flottante è
//!   accuratamente cù numeri interi.SIGPLAN Micca.45, 6 (ghjugnu 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// vede i cumenti in `format_shortest_opt` per u fundamentu.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Datu `x > 0`, restituisce `(k, 10^k)` tale chì `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// L'implementazione di modalità più corta per Grisu.
///
/// Ritorna `None` quandu restituveria una rapprisintazione inesatta altrimenti.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // avemu bisognu di almenu trè pezzi di precisione supplementaria

    // principià cù i valori nurmalizati cù l'esponente cumunu
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // truvà ogni `cached = 10^minusk` tale chì `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // postu chì `plus` hè nurmalizatu, questu significa `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // date e nostre scelte di `ALPHA` è `GAMMA`, questu mette `plus * cached` in `[4, 2^32)`.
    //
    // hè ovviamente desiderabile massimizà `GAMMA - ALPHA`, per ùn avè micca bisognu di assai putenzi in cache di 10, ma ci sò alcune considerazioni:
    //
    //
    // 1. vulemu tene `floor(plus * cached)` in `u32` postu chì hà bisognu di una divisione costosa.
    //    (questu ùn hè micca veramente evitabile, u restu hè necessariu per a stima di precisione.)
    // 2.
    // u restu di `floor(plus * cached)` si multiplica ripetutamente per 10, è ùn deve micca trabuccà.
    //
    // u primu dà `64 + GAMMA <= 32`, mentre chì u secondu dà `10 * 2^-ALPHA <= 2^64`;
    // -60 è -32 hè a gamma massima cù questa restrizione, è V8 li usa ancu.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // scala fps.questu dà l'errore massimu di 1 ulp (pruvatu da u Teorema 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-range reale di minus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // sopra `minus`, `v` è `plus` sò *quantificati* apprussimazioni (errore <1 ulp).
    // cum'è ùn sapemu micca chì l'errore hè pusitivu o negativu, adupremu duie apprussimazioni spaziate ugualmente è avemu l'errore massimu di 2 ulpi.
    //
    // u "unsafe region" hè un intervallu liberale chì inizialmente generemu.
    // u "safe region" hè un intervallu cunservatore chì accettemu solu.
    // cumminciamu cù a riprissioni curretta ind'u rughjonu periculosu, è pruvemu à truvà a ripruduzzione a più vicina à `v` chì si trova ancu in a regione sicura.
    // sè ùn pudemu micca, rinunziemu.
    //
    let plus1 = plus.f + 1;
    // lascia plus0 = plus.f, 1;//solu per spiegazione lasciate minus0 = minus.f + 1;//solu per spiegazione
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // espunente spartutu

    // divide `plus1` in parti integrali è frazziunali.
    // e parti integrali sò garantite per adattassi in u32, postu chì a putenza in cache garantisce `plus < 2^32` è `plus.f` normalizatu hè sempre menu di `2^64 - 2^4` per via di u requisitu di precisione.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // calcula u più grande `10^max_kappa` micca più di `plus1` (cusì `plus1 < 10^(max_kappa+1)`).
    // questu hè un limite superiore di `kappa` sottu.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorema 6.2: sì `k` hè u più grande interu st
    // `0 <= y mod 10^k <= y - x`,              allora `V = floor(y / 10^k) * 10^k` hè in `[x, y]` è una di e rapresentazione più corte (cù u numeru minimu di cifre significative) in quella gamma.
    //
    //
    // truvate a lunghezza di cifre `kappa` trà `(minus1, plus1)` secondu u Teorema 6.2.
    // U Teorema 6.2 pò esse aduttatu per escludisce `x` esigendu invece `y mod 10^k < y - x`.
    // (per esempiu, `x` =32000, `y` =32777; `kappa` =2 postu chì `y mod 10 ^ 3=777 <y, x=777`.) l'algoritmu si basa nantu à a fase di verificazione più tardi per escludiri `y`.
    //
    let delta1 = plus1 - minus1;
    // lasciemu delta1int=(delta1>> e) cum'è usize;//solu per spiegazione
    let delta1frac = delta1 & ((1 << e) - 1);

    // rende e parti integrali, cuntrollendu a precisione in ogni passu.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // cifre ancu da esse rese
    loop {
        // avemu sempre almenu una cifra da rende, cum'è invarianti `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (segue chì `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // divide `remainder` per `10^kappa`.tramindui sò scalati da `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; avemu trovu u `kappa` currettu.
            let ten_kappa = (ten_kappa as u64) << e; // scala 10 ^ kappa torna à l'esponente cumunu
            return round_and_weed(
                // SICUREZZA: avemu inizializatu quella memoria sopra.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // rompe u ciclu quandu avemu resu tutte e cifre integrali.
        // u numeru esattu di cifre hè `max_kappa + 1` cum'è `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // ristabilisce invarianti
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // rende parti frazziunali, mentre cuntrolla a precisione à ogni passu.
    // sta volta ci appughjemu nantu à multiplicazioni ripetute, chì a divisione perderà a precisione.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // a prossima cifra duveria esse significativa postu chì avemu pruvatu chì prima di sparghje invarianti, induve `m = max_kappa + 1` (#di cifre in a parte integrale):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ùn sferisce micca, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // divide `remainder` per `10^kappa`.
        // tramindui sò scalati da `2^e / 10^kappa`, cusì l'ultimu hè implicitu quì.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // divisore implicitu
            return round_and_weed(
                // SICUREZZA: avemu inizializatu quella memoria sopra.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // ristabilisce invarianti
        kappa -= 1;
        remainder = r;
    }

    // avemu generatu tutte e cifre significative di `plus1`, ma ùn sò micca sicuru se hè l'ottima.
    // per esempiu, se `minus1` hè 3.14153 ... è `plus1` hè 3.14158 ..., ci sò 5 diverse rapprisentazioni più corte da 3.14154 à 3.14158 ma avemu solu a più grande.
    // duvemu riduce successivamente l'ultima cifra è verificà s'ellu hè a riprima ottimale.
    // ci sò à u più 9 candidati (..1 à ..9), allora hè abbastanza veloce.(Fase "rounding")
    //
    // a funzione verifica se stu "optimal" repr hè in realtà in l'upp range, è ancu, hè pussibule chì u "second-to-optimal" repr pò esse in realtà ottimali per via di l'errore di arrotondamentu.
    // in i dui casi questu restituisce `None`.
    // (Fase "weeding")
    //
    // tutti l'argumenti quì sò scalati da u valore cumunu (ma implicitu) `k`, in modu chì:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (è dinò, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (è dinò, `threshold > plus1v` da invarianti precedenti)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // pruduce duie approssimazioni à `v` (in realtà `plus1 - v`) in ulps 1.5.
        // a raprisentazione resultante duveria esse a raprisentazione a più vicina à tramindui.
        //
        // quì `plus1 - v` hè adupratu postu chì i calculi sò fatti in rispettu à `plus1` per evità overflow/underflow (da quì i nomi apparentemente scambiati).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // diminuite l'ultima cifra è fermate à a rappresentazione più vicina à `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // travagliamu cù e cifre apprussimate `w(n)`, chì hè inizialmente uguale à `plus1 - plus1 % 10^kappa`.dopu avè eseguitu u ciclu di corpu `n` volte, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // avemu impostatu `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (cusì `restu= plus1w(0)`) per simplificà i cuntrolli.
            // nutate chì `plus1w(n)` cresce sempre.
            //
            // avemu trè cundizioni per finisce.ognunu di elli farà chì u ciclu ùn possa prucede, ma avemu tandu almenu una raprisentazione valida cunnisciuta per esse a più vicina à `v + 1 ulp` quantunque.
            // li denoteremu cum'è TC1 à TC3 per brevità.
            //
            // TC1: `w(n) <= v + 1 ulp`, vale à dì, questu hè l'ultimu repr chì pò esse u più vicinu.
            // questu hè equivalente à `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // cumbinatu cù TC2 (chì verifica se `w(n+1)` is valid), questu impedisce u pussibule overflow nantu à u calculu di `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, vale à dì, a prossima ripruduzzione ùn definisce micca arrotondate à `v`.
            // questu hè equivalente à `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // u latu sinistro pò trabuccà, ma sapemu `threshold > plus1v`, allora sì TC1 hè falsu, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` è pudemu pruvà in modu sicuru se `threshold - plus1w(n) < 10^kappa` invece.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, vale à dì, a prossima riprova hè
            // micca più vicinu à `v + 1 ulp` cà a riprova attuale.
            // datu `z(n) = plus1v_up - plus1w(n)`, questu diventa `abs(z(n)) <= abs(z(n+1))`.dinò assumendu chì TC1 hè falsu, avemu `z(n) > 0`.avemu dui casi da cunsiderà:
            //
            // - quandu `z(n+1) >= 0`: TC3 diventa `z(n) <= z(n+1)`.
            // cum'è `plus1w(n)` cresce, `z(n)` deve esse diminuente è questu hè chjaramente falsu.
            // - quandu `z(n+1) < 0`:
            //   - TC3a: a precondizione hè `plus1v_up < plus1w(n) + 10^kappa`.supponendu chì TC2 sia falsu, `threshold >= plus1w(n) + 10^kappa` dunque ùn pò micca trabuccà.
            //   - TC3b: TC3 diventa `z(n) <= -z(n+1)`, vale à dì, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   u TC1 negatu dà `plus1v_up > plus1w(n)`, perciò ùn pò micca trabuccà o sferisce quandu si combina cù TC3a.
            //
            // dunque, duvemu fermà quandu `TC1 || TC2 || (TC3a && TC3b)`.u seguitu hè uguale à u so inversu, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // a più corta riprova ùn pò finisce cù `0`
                plus1w += ten_kappa;
            }
        }

        // verificate se sta raprisentazione hè ancu a raprisentazione a più vicina à `v - 1 ulp`.
        //
        // questu hè simplicemente listessu per e condizioni di fine per `v + 1 ulp`, cù tuttu `plus1v_up` rimpiazzatu da `plus1v_down` invece.
        // analisi overflow tene ugualmente.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // avà avemu a raprisentazione a più vicina à `v` trà `plus1` è `minus1`.
        // questu hè troppu liberale, però, dunque rifiutemu qualsiasi `w(n)` micca trà `plus0` è `minus0`, vale à dì, `plus1 - plus1w(n) <= minus0` o `plus1 - plus1w(n) >= plus0`.
        // usamu i fatti chì `threshold = plus1 - minus1` è `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// L'implementazione di modalità più corta per Grisu cù Dragon fallback.
///
/// Questu deve esse adupratu per a maggior parte di i casi.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SICUREZZA: U verificatore di prestiti ùn hè micca abbastanza intelligente per lasciaci aduprà `buf`
    // in u secondu branch, allora lavemu a vita quì.
    // Ma solu riutilizemu `buf` se `format_shortest_opt` hà restituitu `None` allora hè bè.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// L'implementazione di modu esattu è fissu per Grisu.
///
/// Ritorna `None` quandu restituveria una rapprisintazione inesatta altrimenti.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // avemu bisognu di almenu trè pezzi di precisione supplementaria
    assert!(!buf.is_empty());

    // nurmalizà è scala `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // divide `v` in parti integrali è frazziunali.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // sia u vechju `v` sia u novu `v` (scalatu da `10^-k`) hà un errore di <1 ulp (Teorema 5.1).
    // cum'è ùn sapemu micca chì l'errore hè pusitivu o negativu, usamu duie apprussimazioni spaziate ugualmente è avemu l'errore massimu di 2 ulpi (listessu per u casu più cortu).
    //
    //
    // u scopu hè di truvà a seria esattamente arrotondata di cifre chì sò cumuni sia à `v - 1 ulp` sia à `v + 1 ulp`, in modu chì siamu cunfidenziali.
    // se questu ùn hè micca pussibule, ùn sapemu micca quale hè a produzzione curretta per `v`, allora rinunziamu è ricusemu.
    //
    // `err` hè definitu cum'è `1 ulp * 2^e` quì (listessu à l'ulp in `vfrac`), è u scaleremu ogni volta chì `v` sarà scalatu.
    //
    //
    //
    let mut err = 1;

    // calcula u più grande `10^max_kappa` micca più di `v` (cusì `v < 10^(max_kappa+1)`).
    // questu hè un limite superiore di `kappa` sottu.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // se travagliamu cù a limitazione di l'ultime cifre, ci vole à accurtà u buffer prima di a resa effettiva per evità u doppiu arrotondamentu.
    //
    // nutate chì ci vole à ingrandà dinò u buffer quandu si arrotonda!
    let len = if exp <= limit {
        // oops, ùn pudemu mancu pruduce *una* cifra.
        // questu hè pussibule quandu, dicemu, avemu qualcosa cum'è 9.5 è hè arrotondatu à 10.
        //
        // in principiu pudemu chjamà immediatamente `possibly_round` cun un buffer vacante, ma scalendu `max_ten_kappa << e` da 10 pò resultà in overflow.
        //
        // cusì simu stati sciatti quì è allargemu a gamma di errore di un fattore di 10.
        // questu aumenterà a falsa percentuale negativa, ma solu assai,*assai* leggermente;
        // ùn pò impurtanza nutevule solu quandu a mantissa hè più grande di 60 bit.
        //
        // SICUREZZA: `len=0`, allora l'obligazione di avè inizializatu sta memoria hè banale.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // rende parti integrali.
    // l'errore hè interamente frazzionale, allora ùn avemu micca bisognu di verificallu in sta parte.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // cifre ancu da esse rese
    loop {
        // avemu sempre almenu una cifra per rende invarianti:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (segue chì `remainder = vint % 10^(kappa+1)`)
        //
        //

        // divide `remainder` per `10^kappa`.tramindui sò scalati da `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // hè u buffer pienu?lanciate u passu rotundante cù u restu.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SICUREZZA: avemu inizializatu `len` parechji byte.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // rompe u ciclu quandu avemu resu tutte e cifre integrali.
        // u numeru esattu di cifre hè `max_kappa + 1` cum'è `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // ristabilisce invarianti
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // rende parti frazziunali.
    //
    // in principiu pudemu cuntinuà finu à l'ultimu cifru dispunibule è verificà a precisione.
    // purtroppu stemu travagliendu cù i numeri interi di dimensioni finite, allora avemu bisognu di qualchì criteriu per rilevà u overflow.
    // V8 usa `remainder > err`, chì diventa falsu quandu e prime cifre significative `i` di `v - 1 ulp` è `v` differenu.
    // tuttavia questu rifiuta troppu input altrimenti validi.
    //
    // postu chì a fase successiva hà una rilevazione curretta di overflow, usemu invece criteriu più strettu:
    // continuemu finu à chì `err` supera `10^kappa / 2`, cusì chì a gamma trà `v - 1 ulp` è `v + 1 ulp` cuntene definitivamente duie o più riprisentazioni arrotondate.
    //
    // hè listessa per i primi dui paraguni da `possibly_round`, per a riferenza.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invarianti, induve `m = max_kappa + 1` (#di cifre in a parte integrale):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ùn sferisce micca, `2^e * 10 < 2^64`
        err *= 10; // ùn sferisce micca, `err * 10 < 2^e * 5 < 2^64`

        // divide `remainder` per `10^kappa`.
        // tramindui sò scalati da `2^e / 10^kappa`, cusì l'ultimu hè implicitu quì.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // hè u buffer pienu?lanciate u passu rotundante cù u restu.
        if i == len {
            // SICUREZZA: avemu inizializatu `len` parechji byte.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // ristabilisce invarianti
        remainder = r;
    }

    // un ulteriore calculu hè inutile (`possibly_round` fiasca definitivamente), dunque rinunziemu.
    return None;

    // avemu generatu tutte e cifre richieste di `v`, chì devenu esse listesse à e cifre currispundenti di `v - 1 ulp`.
    // avà verificemu s'ellu ci hè una rapprisintazione unica spartuta da `v - 1 ulp` è `v + 1 ulp`;chistu pò esse uguale à e cifre generate, o à a versione arrotondata di quelle cifre.
    //
    // se a gamma cuntene parechje riprisentazioni di listessa lunghezza, ùn pudemu micca esse sicuri è duverebbe restituì `None` invece.
    //
    // tutti l'argumenti quì sò scalati da u valore cumunu (ma implicitu) `k`, in modu chì:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SICUREZZA: i primi bytes `len` di `buf` devenu esse inizializati.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (per a riferenza, a linea punteggiata indica u valore esattu per e pussibuli rapprisentazioni in un numeru datu di cifre.)
        //
        //
        // l'errore hè troppu grande chì ci sò almenu trè riprisentazione pussibule trà `v - 1 ulp` è `v + 1 ulp`.
        // ùn pudemu micca determinà quale hè curretta.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // in fattu, 1/2 ulp hè abbastanza per intruduce duie rapprisentazioni pussibuli.
        // (arricurdatevi chì avemu bisognu di una rapprisintazione unica sia per `v - 1 ulp` sia per `v + 1 ulp`.) questu ùn si supererà, cum'è `ulp < ten_kappa` da u primu verificatu.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // se `v + 1 ulp` hè più vicinu à a raprisentazione arrotondata (chì hè dighjà in `buf`), allora pudemu vultà in modu sicuru.
        // nutate chì `v - 1 ulp`*pò* esse menu di a raprisentazione attuale, ma cum'è `1 ulp < 10^kappa / 2`, sta cundizione hè abbastanza:
        // a distanza trà `v - 1 ulp` è a raprisentazione attuale ùn pò supere `10^kappa / 2`.
        //
        // a cundizione hè uguali à `remainder + ulp < 10^kappa / 2`.
        // postu chì questu pò facilmente trabucà, prima verificate se `remainder < 10^kappa / 2`.
        // avemu digià verificatu chì `ulp < 10^kappa / 2`, dunque, finu à chì `10^kappa` ùn hà micca sbulicatu dopu tuttu, u sicondu cuntrollu hè bè.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SICUREZZA: u nostru chjamante hà iniziatu quella memoria.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------restu------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // da l'altre mani, se `v - 1 ulp` hè più vicinu à a rapprisintazione arrotondata, duvemu arrotondà è tornà.
        // per a stessa ragione ùn avemu micca bisognu di verificà `v + 1 ulp`.
        //
        // a cundizione hè uguali à `remainder - ulp >= 10^kappa / 2`.
        // torna dinò verificemu prima se `remainder > ulp` (nutate chì questu ùn hè micca `remainder >= ulp`, chì `10^kappa` ùn hè mai cero).
        //
        // nutate ancu chì `remainder - ulp <= 10^kappa`, allora u secondu cuntrollu ùn trabocca micca.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SICUREZZA: u nostru chjamante deve avè inizializatu quella memoria.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // aghjunghje solu una cifra addiziunale quandu ci hè stata dumandata a precisione fissa.
                // duvemu dinò verificà chì, se u buffer originale era viotu, a cifra addiziunale pò esse aghjunta solu quandu `exp == limit` (casu edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SICUREZZA: noi è u nostru chjamante inizializamu quella memoria.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // altrimenti simu cundannati (vale à dì, certi valori trà `v - 1 ulp` è `v + 1 ulp` sò arrotondati in ghjò è altri sò arrotondati in su) è rinuncemu.
        //
        None
    }
}

/// L'implementazione di modu esattu è fissu per Grisu cù Dragon fallback.
///
/// Questu deve esse adupratu per a maggior parte di i casi.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SICUREZZA: U verificatore di prestiti ùn hè micca abbastanza intelligente per lasciaci aduprà `buf`
    // in u secondu branch, allora lavemu a vita quì.
    // Ma solu riutilizemu `buf` se `format_exact_opt` hà restituitu `None` allora hè bè.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}