macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// U valore più chjucu chì pò esse rappresentatu da stu tipu interu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// U più grande valore chì pò esse rappresentatu da stu tipu interu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// A dimensione di stu tipu interu in bit.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Converte una fetta di stringa in una basa data in un numeru interu.
        ///
        /// A stringa hè prevista per esse un segnu `+` o `-` opzionale seguitatu da cifre.
        /// U spaziu biancu di punta è di seguitu raprisenta un errore.
        /// I cifri sò un sottogruppu di questi caratteri, secondu `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Questa funzione panics se `radix` ùn hè micca in u intervallu da 2 à 36.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Restituisce u numeru di quelli in a rappresentazione binaria di `self`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Restituisce u numeru di zeru in a rappresentazione binaria di `self`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Restituisce u numeru di zeri principali in a rapprisintazione binaria di `self`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Restituisce u numeru di zeru finale in a rappresentazione binaria di `self`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Restituisce u numeru di quelli principali in a rappresentazione binaria di `self`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Restituisce u numeru di quelli chì finiscinu in a rappresentazione binaria di `self`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Sposta i bit à sinistra per una quantità specificata, `n`, avvolgendu i bit truncati à a fine di u numeru interu resultante.
        ///
        ///
        /// Per piacè nutate chì questu ùn hè micca a stessa operazione cum'è l'operatore di cambiamentu `<<`!
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Sposta i bit à a diritta per una quantità specificata, `n`, avvolgendu i bit truncati finu à u principiu di u numeru interu resultante.
        ///
        ///
        /// Per piacè nutate chì questu ùn hè micca a stessa operazione cum'è l'operatore di cambiamentu `>>`!
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Inverte l'ordine di byte di u numeru interu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lasciate m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Inverte l'ordine di bit in u numeru sanu.
        /// U bit menu significativu diventa u bit più significativu, u secondu bit menu significativu diventa u secondu bit u più significativu, ecc.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lasciate m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Converte un interu da big endian in endianness di u target.
        ///
        /// In big endian questu hè un no-op.In pocu endian i byte sò scambiati.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } altru {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Converte un interu da pocu endian à endianness di u target.
        ///
        /// In pocu endian questu hè un no-op.In big endian i byte sò scambiati.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } altru {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Converte `self` in big endian da l'endianness di u target.
        ///
        /// In big endian questu hè un no-op.In pocu endian i byte sò scambiati.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } altru { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // o micca esse?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Converte `self` in pocu endian da l'endianness di u target.
        ///
        /// In pocu endian questu hè un no-op.In big endian i byte sò scambiati.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } altru { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Aggiunta intera verificata.
        /// Calcula `self + rhs`, restituisce `None` in casu di overflow.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Aghjuntu interu micca marcatu.Calcula `self + rhs`, supponendu chì u overflow ùn si pò fà.
        /// Questu risultà in un comportamentu indefinitu quandu
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Sottrazione entera verificata.
        /// Calcula `self - rhs`, restituisce `None` in casu di overflow.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Sottrazione intera micca marcata.Calcula `self - rhs`, supponendu chì u overflow ùn si pò fà.
        /// Questu risultà in un comportamentu indefinitu quandu
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Multiplicazione intera verificata.
        /// Calcula `self * rhs`, restituisce `None` in casu di overflow.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Moltiplicazione intera micca marcata.Calcula `self * rhs`, supponendu chì u overflow ùn si pò fà.
        /// Questu risultà in un comportamentu indefinitu quandu
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Divisione intera verificata.
        /// Calcula `self / rhs`, restituisce `None` se `rhs == 0` o a divisione risultati in overflow.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SICUREZZA: div da zero è da INT_MIN sò stati verificati sopra
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Divisione Euclidiana verificata.
        /// Calcula `self.div_euclid(rhs)`, restituisce `None` se `rhs == 0` o a divisione risultati in overflow.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Verificatu u restu interu.
        /// Calcula `self % rhs`, restituisce `None` se `rhs == 0` o a divisione risultati in overflow.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SICUREZZA: div da zero è da INT_MIN sò stati verificati sopra
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Cuntrollatu restu euclidianu.
        /// Calcula `self.rem_euclid(rhs)`, restituisce `None` se `rhs == 0` o a divisione risultati in overflow.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Negazione verificata.
        /// Calcula `-self`, restituisce `None` se `self == MIN`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Verificatu turnu à manca.
        /// Calcula `self << rhs`, restituisce `None` se `rhs` hè più grande o uguale à u numeru di bit in `self`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Verificatu shift right.
        /// Calcula `self >> rhs`, restituisce `None` se `rhs` hè più grande o uguale à u numeru di bit in `self`.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Valore assolutu verificatu.
        /// Calcula `self.abs()`, restituisce `None` se `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Esponenziazione verificata.
        /// Calcula `self.pow(exp)`, restituisce `None` in casu di overflow.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // postu chì exp!=0, infine u exp deve esse 1.
            // Trattà cù u bit finale di l'esponente separatamente, postu chì quadrà a basa dopu ùn hè micca necessariu è pò causà un overflow inutile.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Aghjuntu sanu sanu.
        /// Calcula `self + rhs`, saturendu à i limiti numerichi invece di traboccà.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Sottrazione intera saturante.
        /// Calcula `self - rhs`, saturendu à i limiti numerichi invece di traboccà.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Negazione intera saturante.
        /// Calcula `-self`, restituisce `MAX` se `self == MIN` invece di traboccà.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Valore assolutu saturatu.
        /// Calcula `self.abs()`, restituisce `MAX` se `self == MIN` invece di traboccà.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Multiplicazione intera saturante.
        /// Calcula `self * rhs`, saturendu à i limiti numerichi invece di traboccà.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Esponenziazione intera saturante.
        /// Calcula `self.pow(exp)`, saturendu à i limiti numerichi invece di traboccà.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Imballu (modular) aghjuntu.
        /// Calcula `self + rhs`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Avvolgimentu di sottrazione (modular).
        /// Calcula `self - rhs`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Imballaggio multiplicazione (modular).
        /// Calcula `self * rhs`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Avvolgimentu di a divisione (modular).Calcula `self / rhs`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// L'unicu casu induve un tale imballu pò accade hè quandu si divide `MIN / -1` nantu à un tippu firmatu (induve `MIN` hè u valore minimu negativu per u tippu);questu hè equivalente à `-MIN`, un valore pusitivu chì hè troppu grande per riprisentà in u tippu.
        /// In tale casu, sta funzione rende `MIN` stessa.
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Avvolgimentu di a divisione euclidea.
        /// Calcula `self.div_euclid(rhs)`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// L'imballaggio si farà solu in `MIN / -1` nantu à un tippu firmatu (induve `MIN` hè u valore minimu negativu per u tippu).
        /// Questu hè equivalente à `-MIN`, un valore pusitivu chì hè troppu grande per rapprisintà in u tippu.
        /// In questu casu, stu metudu restituisce `MIN` stessu.
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Imballaggio di u restu (modular).Calcula `self % rhs`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// Tale avvolgimentu ùn accade mai in realtà matematicamente;L'artifatti di implementazione rendenu `x % y` invalidu per `MIN / -1` nantu à un tippu firmatu (induve `MIN` hè u valore minimu negativu).
        ///
        /// In tale casu, sta funzione rende `0`.
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Avvolgendu u restu euclidianu.Calcula `self.rem_euclid(rhs)`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// L'imballaggio si farà solu in `MIN % -1` nantu à un tippu firmatu (induve `MIN` hè u valore minimu negativu per u tippu).
        /// In questu casu, stu metudu restituisce 0.
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Involuzione di negazione (modular).Calcula `-self`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// L'unicu casu induve un tale imballu pò accade hè quandu unu nega `MIN` nantu à un tippu firmatu (induve `MIN` hè u valore minimu negativu per u tippu);questu hè un valore pusitivu chì hè troppu grande per rapprisintà in u tippu.
        /// In tale casu, sta funzione rende `MIN` stessa.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-free bitwise shift-left;rende `self << mask(rhs)`, induve `mask` elimina tutti i pezzi di altu ordine di `rhs` chì puderebbenu fà chì u cambiamentu supere a larghezza di bit di u tippu.
        ///
        /// Innota chì questu hè *micca* u listessu cum'è un rotate-left;u RHS di un avvolgimentu shift-left hè limitatu à a gamma di u tippu, piuttostu chì i bit spostati fora di u LHS restituiti à l'altra estremità.
        ///
        /// I tippi interi primitivi implementanu tutti una funzione [`rotate_left`](Self::rotate_left), chì pò esse ciò chì vulete invece.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SICUREZZA: u mascheramentu da u bit di u tippu assicura chì ùn cambiemu micca
            // fora di i limiti
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-bitwise shift-right;rende `self >> mask(rhs)`, induve `mask` elimina tutti i pezzi di altu ordine di `rhs` chì puderebbenu fà chì u cambiamentu supere a larghezza di bit di u tippu.
        ///
        /// Innota chì questu hè *micca* u listessu cum'è un rotate-right;u RHS di un avvolgimentu shift-right hè limitatu à a gamma di u tippu, piuttostu chè i bit spostati fora di u LHS restituiti à l'altra estremità.
        ///
        /// I tippi interi primitivi implementanu tutti una funzione [`rotate_right`](Self::rotate_right), chì pò esse ciò chì vulete invece.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SICUREZZA: u mascheramentu da u bit di u tippu assicura chì ùn cambiemu micca
            // fora di i limiti
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Imballu (modular) valore assolutu.Calcula `self.abs()`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// L'unicu casu induve tali imballu pò accade hè quandu si piglia u valore assolutu di u valore minimu negativu per u tippu;questu hè un valore pusitivu chì hè troppu grande per rapprisintà in u tippu.
        /// In tale casu, sta funzione rende `MIN` stessa.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Calcula u valore assolutu di `self` senza alcun involucru o panicu.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Avvolgimentu di esponenziazione (modular).
        /// Calcula `self.pow(exp)`, avvolgendusi intornu à u cunfini di u tippu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // postu chì exp!=0, infine u exp deve esse 1.
            // Trattà cù u bit finale di l'esponente separatamente, postu chì quadrà a basa dopu ùn hè micca necessariu è pò causà un overflow inutile.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Calcula `self` + `rhs`
        ///
        /// Restituisce una tupla di l'aghjuntu cù un booleanu chì indica se un overflow aritmeticu si averebbe.
        /// Se un overflow si saria fattu allora u valore imballatu hè restituitu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Calcula `self`, `rhs`
        ///
        /// Restituisce una tupla di a sottrazione cù un booleanu chì indica se un overflow aritmeticu si averebbe.
        /// Se un overflow si saria fattu allora u valore imballatu hè restituitu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Calcula a multiplicazione di `self` è `rhs`.
        ///
        /// Restituisce una tupla di a multiplicazione cù un booleanu chì indica se un overflow aritmeticu si averebbe.
        /// Se un overflow si saria fattu allora u valore imballatu hè restituitu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, veru));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Calcula u divisore quandu `self` hè divisu per `rhs`.
        ///
        /// Restituisce una tupla di u divisore cù un booleanu chì indica se un overflow aritmeticu si averebbe.
        /// Se un overflow accaderebbe allora u restituutu di sè.
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Calcula u quoziente di a divisione euclidea `self.div_euclid(rhs)`.
        ///
        /// Restituisce una tupla di u divisore cù un booleanu chì indica se un overflow aritmeticu si averebbe.
        /// Se un overflow accaderebbe allora `self` hè restituitu.
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Calcula u restu quandu `self` hè divisu per `rhs`.
        ///
        /// Restituisce una tupla di u restu dopu avè divisu cù un booleanu chì indica se un overflow aritmeticu si averebbe.
        /// Se un overflow accaderebbe allora 0 hè restituitu.
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Restu Euclidianu chì trabocca.Calcula `self.rem_euclid(rhs)`.
        ///
        /// Restituisce una tupla di u restu dopu avè divisu cù un booleanu chì indica se un overflow aritmeticu si averebbe.
        /// Se un overflow accaderebbe allora 0 hè restituitu.
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Negazione di sè, traboccante se questu hè uguale à u valore minimu.
        ///
        /// Restituisce una tupla di a versione negata di sè cun un booleanu chì indica se un overflow hè accadutu.
        /// Se `self` hè u valore minimu (per esempiu, `i32::MIN` per i valori di tippu `i32`), allora u valore minimu serà restituitu di novu è `true` serà restituitu per un overflow chì accade.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Sposta da sè lasciatu da i bit `rhs`.
        ///
        /// Restituisce una tupla di a versione spustata di sè cù un booleanu chì indica se u valore di spostamentu era più grande o uguale à u numeru di bit.
        /// Se u valore di shift hè troppu grande, u valore hè mascheratu (N-1) induve N hè u numeru di bit, è questu valore hè allora utilizatu per eseguisce u shift.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, veru));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Sposta propiu à dirittu per `rhs` bits.
        ///
        /// Restituisce una tupla di a versione spustata di sè cù un booleanu chì indica se u valore di spostamentu era più grande o uguale à u numeru di bit.
        /// Se u valore di shift hè troppu grande, u valore hè mascheratu (N-1) induve N hè u numeru di bit, è questu valore hè allora utilizatu per eseguisce u shift.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, veru));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Calcula u valore assolutu di `self`.
        ///
        /// Restituisce una tupla di a versione assoluta di sè cun un booleanu chì indica se un overflow hè accadutu.
        /// Sè sè hè u valore minimu
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// allora u valore minimu serà restituitu di novu è veru serà restituitu per un overflow chì accade.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Rialza u so autore à a putenza di `exp`, aduprendu l'esponenziazione à u quadratu.
        ///
        /// Restituisce una tupla di l'esponenziazione cù un bool chì indica se un overflow hè accadutu.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, veru));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Scratch space per almacenà i risultati di overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // postu chì exp!=0, infine u exp deve esse 1.
            // Trattà cù u bit finale di l'esponente separatamente, postu chì quadrà a basa dopu ùn hè micca necessariu è pò causà un overflow inutile.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Rialza u so autore à a putenza di `exp`, aduprendu l'esponenziazione à u quadratu.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // postu chì exp!=0, infine u exp deve esse 1.
            // Trattà cù u bit finale di l'esponente separatamente, postu chì quadrà a basa dopu ùn hè micca necessariu è pò causà un overflow inutile.
            //
            //
            acc * base
        }

        /// Calcula u quoziente di a divisione euclidea di `self` per `rhs`.
        ///
        /// Questu calcula u numeru interu `n` tale chì `self = n * rhs + self.rem_euclid(rhs)`, cù `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// In altre parolle, u risultatu hè `self / rhs` arrotondatu à u numeru sanu `n` tale chì `self >= n * rhs`.
        /// Se `self > 0`, questu hè uguale à u round versu zeru (u predefinitu in Rust);
        /// se `self < 0`, questu hè uguale à u giru versu l'infinitu +/-.
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0 o a divisione risultati in overflow.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// lascia b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Calcula u restu minimu innegativu di `self (mod rhs)`.
        ///
        /// Questu hè fattu cum'è se da l'algoritmu di divisione euclidea-datu `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` è `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Sta funzione serà panic se `rhs` hè 0 o a divisione risultati in overflow.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// lascia b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Calcula u valore assolutu di `self`.
        ///
        /// # Cumportamentu di overflow
        ///
        /// U valore assolutu di
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// ùn pò micca esse ripresentatu cum'è un
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// è pruvà à calculà lu pruvucarà un overflow.
        /// Questu significa chì u codice in modu di debug attivà un panic in questu casu è u codice ottimisatu tornerà
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// senza un panic.
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Innota chì u#[inline] sopra significa chì a semantica di overflow di a sottrazione dipende da u crate chì ci hè inline in.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Restituisce un numeru chì riprisenta u segnu di `self`.
        ///
        ///  - `0` se u numeru hè zeru
        ///  - `1` se u numeru hè pusitivu
        ///  - `-1` se u numeru hè negativu
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Restituisce `true` se `self` hè pusitivu è `false` se u numeru hè zeru o negativu.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Restituisce `true` se `self` hè negativu è `false` se u numeru hè zeru o pusitivu.
        ///
        ///
        /// # Examples
        ///
        /// Usu di basa:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Ritorna a raprisentazione di memoria di questu interu cum'è una matrice di byte in ordine di byte big-endian (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Ritorna a raprisentazione di memoria di questu interu cum'è una matrice di byte in ordine di byte pocu endianu.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Ritorna a rapprisintazione di memoria di questu interu cum'è una matrice di byte in ordine di byte nativu.
        ///
        /// Cum'è l'endianità nativa di a piattaforma di destinazione hè aduprata, u codice portatile deve aduprà [`to_be_bytes`] o [`to_le_bytes`], secondu u casu, invece.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, se cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } altru {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SICUREZZA: sonu custante perchè i numeri interi sò vechji tippi di dati semplici da pudè sempre
        // trasmutalli in matrici di bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SICUREZZA: i numeri interi sò antichi tippi di dati simplici per pudè sempre trasmutalli in
            // matrici di bytes
            unsafe { mem::transmute(self) }
        }

        /// Ritorna a rapprisintazione di memoria di questu interu cum'è una matrice di byte in ordine di byte nativu.
        ///
        ///
        /// [`to_ne_bytes`] duverebbe esse preferitu sopra questu quandu hè pussibule.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// lasciate bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, se cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } altru {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SICUREZZA: i numeri interi sò antichi tippi di dati simplici per pudè sempre trasmutalli in
            // matrici di bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Crea un valore interu da a so raprisentazione cum'è una matrice di byte in big endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// aduprà std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=riposu;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Crea un valore interu da a so raprisentazione cum'è una matrice di byte in pocu endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// aduprà std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=riposu;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Crea un valore interu da a so raprisentazione di memoria cum'è una matrice di byte in endianness nativa.
        ///
        /// Cum'è l'endianità nativa di a piattaforma di destinazione hè aduprata, u codice portatile probabilmente vole aduprà [`from_be_bytes`] o [`from_le_bytes`], cum'è adattu invece.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } altru {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// aduprà std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=riposu;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SICUREZZA: sonu custante perchè i numeri interi sò vechji tippi di dati semplici da pudè sempre
        // trasmutalli
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SICUREZZA: i numeri interi sò vechji tippi di dati semplici da pudè sempre trasmutalli
            unsafe { mem::transmute(bytes) }
        }

        /// U novu codice deve preferisce aduprà
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Restituisce u valore u più chjucu chì pò esse ripresentatu da stu tipu interu.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// U novu codice deve preferisce aduprà
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Restituisce u valore più grande chì pò esse rappresentatu da stu tipu interu.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}