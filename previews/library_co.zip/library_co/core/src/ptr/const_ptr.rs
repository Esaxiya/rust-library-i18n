use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Restituisce `true` se u puntatore hè nulu.
    ///
    /// Nutate bè chì i tippi senza dimensioni anu parechji puntatori nulli pussibuli, postu chì solu u puntatore di dati grezzi hè cunsideratu, micca a so lunghezza, vtable, ecc.
    /// Dunque, dui indicatori chì sò nulli ùn ponu ancu paragunassi uguali trà elli.
    ///
    /// ## Comportamentu durante a valutazione const
    ///
    /// Quandu sta funzione hè aduprata durante a valutazione const, pò restituisce `false` per i puntatori chì si rivelanu nulli in runtime.
    /// Specificamente, quandu un puntatore à qualchì memoria hè offset oltre i so limiti in tale manera chì u puntatore resultante sia nulu, a funzione restituverà sempre `false`.
    ///
    /// Ùn ci hè manera per CTFE di cunnosce a pusizione assuluta di quella memoria, dunque ùn pudemu micca sapè se u puntatore hè nulu o micca.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Paragunate cù un cast à un puntatore magru, cusì i puntatori di grassu tenenu solu in contu a so parte "data" per null-ness.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Lancia à un puntatore di un altru tippu.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Scumpone un puntatore (forse largu) in cumpunenti d'indirizzu è di metadati.
    ///
    /// U puntatore pò esse più tardi ricustruitu cù [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Restituisce `None` se u puntatore hè nulu, o altru restituisce un riferimentu cumunu à u valore imballatu in `Some`.Se u valore pò esse micca inizializatu, [`as_uninit_ref`] deve esse adupratu invece.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Quandu chjamate stu metudu, duvete assicurà chì *o* u puntatore hè NULL *o* tuttu ciò chì seguita hè veru:
    ///
    /// * U puntatore deve esse currettamente alliniatu.
    ///
    /// * Deve esse "dereferencable" in u sensu definitu in [the module documentation].
    ///
    /// * U puntatore deve puntà versu un esempiu inizializatu di `T`.
    ///
    /// * Duvete applicà e regule di aliasing di Rust, postu chì a vita restituita `'a` hè scelta arbitrariamente è ùn riflette micca necessariamente a vita effettiva di i dati.
    ///   In particulare, per a durata di sta vita, a memoria chì u puntatore punta ùn deve esse mutata (eccettu in `UnsafeCell`).
    ///
    /// Questu vale ancu se u risultatu di stu metudu hè inutilizatu!
    /// (A parte nantu à l'inizializazione ùn hè ancu cumpletamente decisa, ma finu à questu, l'unicu approcciu sicuru hè di assicurà ch'elli sianu veramente inizializati.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Versione Null-Unchecked
    ///
    /// Se site sicuru chì u puntatore ùn pò mai esse nullu è cercate un tipu di `as_ref_unchecked` chì restituisce u `&T` invece di `Option<&T>`, sapete chì pudete annullà u puntatore direttamente.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SICUREZZA: u chjamante deve garantisce chì `self` hè validu
        // per una riferenza s'ella ùn hè nulla.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Restituisce `None` se u puntatore hè nulu, o altrimente restituisce un riferimentu cumunu à u valore imballatu in `Some`.
    /// In cuntrastu à [`as_ref`], questu ùn hà micca bisognu chì u valore deve esse inizializatu.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Quandu chjamate stu metudu, duvete assicurà chì *o* u puntatore hè NULL *o* tuttu ciò chì seguita hè veru:
    ///
    /// * U puntatore deve esse currettamente alliniatu.
    ///
    /// * Deve esse "dereferencable" in u sensu definitu in [the module documentation].
    ///
    /// * Duvete applicà e regule di aliasing di Rust, postu chì a vita restituita `'a` hè scelta arbitrariamente è ùn riflette micca necessariamente a vita effettiva di i dati.
    ///
    ///   In particulare, per a durata di sta vita, a memoria chì u puntatore punta ùn deve esse mutata (eccettu in `UnsafeCell`).
    ///
    /// Questu vale ancu se u risultatu di stu metudu hè inutilizatu!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SICUREZZA: u chjamante deve garantisce chì `self` risponde à tutti i
        // esigenze per una riferenza.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Calcula l'offset da un puntatore.
    ///
    /// `count` hè in unità di T;per esempiu, un `count` di 3 rapprisenta un offset di puntatore di byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Se una di e cundizioni seguenti hè violata, u risultatu hè Comportamentu indefinitu:
    ///
    /// * Sia u puntatore iniziale sia u resultante devenu esse in limiti o un byte passatu a fine di u listessu oggettu assignatu.
    /// Innota chì in Rust, ogni variabile (stack-allocated) hè cunsiderata cum'è un oggettu assignatu separatu.
    ///
    /// * L'offset calculatu,**in bytes**, ùn pò micca trabuccà un `isize`.
    ///
    /// * L'offset essendu in limiti ùn pò micca contà nantu à "wrapping around" u spaziu di indirizzu.Hè cusì, a somma di precisione infinita,**in bytes** deve mette in un usu.
    ///
    /// U compilatore è a biblioteca standard cerca generalmente di assicurà chì l'assegnazioni ùn righjunghjinu mai una dimensione induve un offset hè un prublema.
    /// Per esempiu, `Vec` è `Box` assicuranu chì ùn assignanu mai più di byte `isize::MAX`, cusì `vec.as_ptr().add(vec.len())` hè sempre sicuru.
    ///
    /// A maiò parte di e piattaforme fundamentalmente ùn ponu mancu custruisce una tale attribuzione.
    /// Per esempiu, nisuna piattaforma 64-bit cunnisciuta pò mai serve una dumanda per 2 <sup>63</sup> byte per via di limitazioni di tavule di pagina o di spartera di u spaziu di indirizzu.
    /// Tuttavia, alcune piattaforme 32-bit è 16-bit ponu serve cun successu una dumanda per più di byte `isize::MAX` cù cose cum'è Estensione d'indirizzu fisicu.
    ///
    /// Cusì, a memoria acquistata direttamente da allocatori o da i fugliali di memoria *pò* esse troppu grande per trattà cù sta funzione.
    ///
    /// Pensate à aduprà [`wrapping_offset`] invece se queste limitazioni sò difficiule da suddisfà.
    /// L'unicu vantaghju di stu metudu hè chì permette ottimisazioni di cumpilatore più aggressivi.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Calcula l'offset da un puntatore aduprendu l'aritmetica di avvolgimentu.
    ///
    /// `count` hè in unità di T;per esempiu, un `count` di 3 rapprisenta un offset di puntatore di byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Questa operazione stessa hè sempre sicura, ma aduprà u puntatore resultante ùn hè micca.
    ///
    /// U puntatore resultante ferma attaccatu à u listessu oggettu assignatu chì `self` punta à.
    /// Pò esse *micca* adupratu per accede à un oggettu attribuitu diversu.Innota chì in Rust, ogni variabile (stack-allocated) hè cunsiderata cum'è un oggettu assignatu separatu.
    ///
    /// In altre parolle, `let z = x.wrapping_offset((y as isize) - (x as isize))`*ùn* face * `z` listessu chì `y` ancu sè supponemu chì `T` abbia una dimensione `1` è ùn ci sia micca un overflow: `z` hè sempre attaccatu à l'ughjettu `x` hè attaccatu à, è a deriferenza hè un Comportamentu indefinitu à menu chì `x` è Puntate `y` in u listessu ughjettu assignatu.
    ///
    /// Comparatu à [`offset`], stu metudu ritarda in fondu u requisitu di stà in u listessu oggettu attribuitu: [`offset`] hè un Comportamentu Indefinitu immediata quandu si francanu i limiti di l'ughjettu;`wrapping_offset` produce un puntatore ma porta sempre à Comportamentu indefinitu se un puntatore hè dereferenziatu quandu hè fora di i limiti di l'ughjettu à u quale hè attaccatu.
    /// [`offset`] pò esse ottimizatu megliu è hè dunque preferibile in codice sensibile à e prestazioni.
    ///
    /// U verificatu ritardatu cunsidereghja solu u valore di u puntatore chì hè statu dereferenziatu, micca i valori intermedii aduprati durante u calculu di u risultatu finale.
    /// Per esempiu, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` hè sempre uguale à `x`.In altre parolle, lascià l'ughjettu assignatu è poi rientrallu dopu hè permessu.
    ///
    /// Se avete bisognu di attraversà i limiti di l'ughjettu, fate u puntatore in un numeru interu è fate l'aritmetica quì.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // Iterate cù un puntatore grezzu in incrementi di dui elementi
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Stu ciclu stampa "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SICUREZZA: l'intrinsicu `arith_offset` ùn hà micca prerequisiti per esse chjamatu.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Calcula a distanza trà dui puntatori.U valore restituitu hè in unità di T: a distanza in byte hè divisa per `mem::size_of::<T>()`.
    ///
    /// Sta funzione hè l'inversa di [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Se una di e cundizioni seguenti hè violata, u risultatu hè Comportamentu indefinitu:
    ///
    /// * Sia u puntatore iniziale sia l'altru deve esse sia in limiti sia un byte passatu a fine di u listessu oggettu attribuitu.
    /// Innota chì in Rust, ogni variabile (stack-allocated) hè cunsiderata cum'è un oggettu assignatu separatu.
    ///
    /// * Entrambi i puntatori devenu esse *derivati da* un puntatore à u listessu oggettu.
    ///   (Vede quì sottu per un esempiu.)
    ///
    /// * A distanza trà i puntatori, in byte, deve esse un multiplu esattu di a dimensione di `T`.
    ///
    /// * A distanza trà i puntatori,**in bytes**, ùn pò micca trabuccà un `isize`.
    ///
    /// * A distanza essendu in limiti ùn pò micca contà nantu à "wrapping around" u spaziu di indirizzu.
    ///
    /// I tippi Rust ùn sò mai più grandi chì l'allocazioni `isize::MAX` è Rust ùn avvolgenu mai intornu à u spaziu di l'indirizzu, cusì dui puntatori in qualchì valore di qualsiasi tippu Rust `T` soddisfanu sempre l'ultime duie condizioni.
    ///
    /// A biblioteca standard assicura ancu generalmente chì l'assegnazioni ùn ghjunghjenu mai à una dimensione induve un offset hè un prublema.
    /// Per esempiu, `Vec` è `Box` assicuranu chì ùn assignanu mai più di byte `isize::MAX`, cusì `ptr_into_vec.offset_from(vec.as_ptr())` soddisfa sempre l'ultimi dui cundizioni.
    ///
    /// A maiò parte di e piattaforme in fondu ùn ponu mancu custruisce una assignazione cusì grande.
    /// Per esempiu, nisuna piattaforma 64-bit cunnisciuta pò mai serve una dumanda per 2 <sup>63</sup> byte per via di limitazioni di tavule di pagina o di spartera di u spaziu di indirizzu.
    /// Tuttavia, alcune piattaforme 32-bit è 16-bit ponu serve cun successu una dumanda per più di byte `isize::MAX` cù cose cum'è Estensione d'indirizzu fisicu.
    /// Cusì, a memoria acquistata direttamente da allocatori o da i fugliali di memoria *pò* esse troppu grande per trattà cù sta funzione.
    /// (Notate chì [`offset`] è [`add`] anu ancu una limitazione simile è dunque ùn ponu micca esse aduprate ancu in tali grandi allocazioni.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Sta funzione panics se `T` hè un Zero-Sized Type ("ZST").
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Usu incorrettu*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Fate ptr2_other un "alias" di ptr2, ma derivatu da ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Postu chì ptr2_other è ptr2 sò derivati da puntatori à ogetti sfarenti, u calculu di u so offset hè un cumpurtamentu indefinitu, ancu s'elli puntanu u listessu indirizzu!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Comportamentu indefinitu
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Restituisce sì dui indicatori sò garantiti per esse uguali.
    ///
    /// In runtime sta funzione si comporta cum'è `self == other`.
    /// Tuttavia, in certi cuntesti (per esempiu, valutazione in tempu di compilazione), ùn hè micca sempre pussibule di determinà l'uguaglianza di dui puntatori, dunque sta funzione pò restituisce spuriosamente `false` per i puntatori chì dopu si rivelanu effettivamente uguali.
    ///
    /// Ma quandu ritorna `true`, i puntatori sò garantiti per esse uguali.
    ///
    /// Sta funzione hè u spechju di [`guaranteed_ne`], ma micca u so inversu.Ci sò paragoni di puntatore per i quali e duie funzioni restituiscenu `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// U valore di ritornu pò cambià sicondu a versione di u compilatore è u codice periculosu ùn pò micca contà nantu à u risultatu di sta funzione per a solidità.
    /// Hè suggeritu di aduprà solu questa funzione per ottimisazione di prestazione induve i valori falsi di ritornu `false` da questa funzione ùn influenzanu micca u risultatu, ma solu e prestazioni.
    /// E cunsequenze di aduprà stu metudu per fà chì u runtime è u codice di compilazione si comportanu di manera diversa ùn sò micca state esplorate.
    /// Stu metudu ùn deve micca esse adupratu per introduce tali differenze, è ùn deve ancu esse stabilizatu prima di avè una migliore comprensione di sta questione.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Restituisce se dui indicatori sò garantiti per esse inuguali.
    ///
    /// In runtime sta funzione si comporta cum'è `self != other`.
    /// Tuttavia, in certi cuntesti (per esempiu, valutazione in tempu di compilazione), ùn hè micca sempre pussibule di determinà l'inegualità di dui puntatori, dunque sta funzione pò restituisce spuriosamente `false` per i puntatori chì dopu si rivelanu in realtà inuguali.
    ///
    /// Ma quandu ritorna `true`, i puntatori sò garantiti per esse inuguali.
    ///
    /// Sta funzione hè u spechju di [`guaranteed_eq`], ma micca u so inversu.Ci sò paragoni di puntatore per i quali e duie funzioni restituiscenu `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// U valore di ritornu pò cambià sicondu a versione di u compilatore è u codice periculosu ùn pò micca contà nantu à u risultatu di sta funzione per a solidità.
    /// Hè suggeritu di aduprà solu questa funzione per ottimisazione di prestazione induve i valori falsi di ritornu `false` da questa funzione ùn influenzanu micca u risultatu, ma solu e prestazioni.
    /// E cunsequenze di aduprà stu metudu per fà chì u runtime è u codice di compilazione si comportanu di manera diversa ùn sò micca state esplorate.
    /// Stu metudu ùn deve micca esse adupratu per introduce tali differenze, è ùn deve ancu esse stabilizatu prima di avè una migliore comprensione di sta questione.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Calcula l'offset da un puntatore (comodità per `.offset(count as isize)`).
    ///
    /// `count` hè in unità di T;per esempiu, un `count` di 3 rapprisenta un offset di puntatore di byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Se una di e cundizioni seguenti hè violata, u risultatu hè Comportamentu indefinitu:
    ///
    /// * Sia u puntatore iniziale sia u resultante devenu esse in limiti o un byte passatu a fine di u listessu oggettu assignatu.
    /// Innota chì in Rust, ogni variabile (stack-allocated) hè cunsiderata cum'è un oggettu assignatu separatu.
    ///
    /// * L'offset calculatu,**in bytes**, ùn pò micca trabuccà un `isize`.
    ///
    /// * L'offset essendu in limiti ùn pò micca contà nantu à "wrapping around" u spaziu di indirizzu.Hè cusì, a somma di precisione infinita deve adattassi à un `usize`.
    ///
    /// U compilatore è a biblioteca standard cerca generalmente di assicurà chì l'assegnazioni ùn righjunghjinu mai una dimensione induve un offset hè un prublema.
    /// Per esempiu, `Vec` è `Box` assicuranu chì ùn assignanu mai più di byte `isize::MAX`, cusì `vec.as_ptr().add(vec.len())` hè sempre sicuru.
    ///
    /// A maiò parte di e piattaforme fundamentalmente ùn ponu mancu custruisce una tale attribuzione.
    /// Per esempiu, nisuna piattaforma 64-bit cunnisciuta pò mai serve una dumanda per 2 <sup>63</sup> byte per via di limitazioni di tavule di pagina o di spartera di u spaziu di indirizzu.
    /// Tuttavia, alcune piattaforme 32-bit è 16-bit ponu serve cun successu una dumanda per più di byte `isize::MAX` cù cose cum'è Estensione d'indirizzu fisicu.
    ///
    /// Cusì, a memoria acquistata direttamente da allocatori o da i fugliali di memoria *pò* esse troppu grande per trattà cù sta funzione.
    ///
    /// Pensate à aduprà [`wrapping_add`] invece se queste limitazioni sò difficiule da suddisfà.
    /// L'unicu vantaghju di stu metudu hè chì permette ottimisazioni di cumpilatore più aggressivi.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Calcula l'offset da un puntatore (comodità per `.offset ((cunte cum'è isize).wrapping_neg())`).
    ///
    /// `count` hè in unità di T;per esempiu, un `count` di 3 rapprisenta un offset di puntatore di byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Se una di e cundizioni seguenti hè violata, u risultatu hè Comportamentu indefinitu:
    ///
    /// * Sia u puntatore iniziale sia u resultante devenu esse in limiti o un byte passatu a fine di u listessu oggettu assignatu.
    /// Innota chì in Rust, ogni variabile (stack-allocated) hè cunsiderata cum'è un oggettu assignatu separatu.
    ///
    /// * L'offset calculatu ùn pò supera `isize::MAX`**byte**.
    ///
    /// * L'offset essendu in limiti ùn pò micca contà nantu à "wrapping around" u spaziu di indirizzu.Hè cusì, a somma di precisione infinita deve adattassi à un usu.
    ///
    /// U compilatore è a biblioteca standard cerca generalmente di assicurà chì l'assegnazioni ùn righjunghjinu mai una dimensione induve un offset hè un prublema.
    /// Per esempiu, `Vec` è `Box` assicuranu chì ùn assignanu mai più di byte `isize::MAX`, cusì `vec.as_ptr().add(vec.len()).sub(vec.len())` hè sempre sicuru.
    ///
    /// A maiò parte di e piattaforme fundamentalmente ùn ponu mancu custruisce una tale attribuzione.
    /// Per esempiu, nisuna piattaforma 64-bit cunnisciuta pò mai serve una dumanda per 2 <sup>63</sup> byte per via di limitazioni di tavule di pagina o di spartera di u spaziu di indirizzu.
    /// Tuttavia, alcune piattaforme 32-bit è 16-bit ponu serve cun successu una dumanda per più di byte `isize::MAX` cù cose cum'è Estensione d'indirizzu fisicu.
    ///
    /// Cusì, a memoria acquistata direttamente da allocatori o da i fugliali di memoria *pò* esse troppu grande per trattà cù sta funzione.
    ///
    /// Pensate à aduprà [`wrapping_sub`] invece se queste limitazioni sò difficiule da suddisfà.
    /// L'unicu vantaghju di stu metudu hè chì permette ottimisazioni di cumpilatore più aggressivi.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Calcula l'offset da un puntatore aduprendu l'aritmetica di avvolgimentu.
    /// (comodità per `.wrapping_offset(count as isize)`)
    ///
    /// `count` hè in unità di T;per esempiu, un `count` di 3 rapprisenta un offset di puntatore di byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Questa operazione stessa hè sempre sicura, ma aduprà u puntatore resultante ùn hè micca.
    ///
    /// U puntatore resultante ferma attaccatu à u listessu oggettu assignatu chì `self` punta à.
    /// Pò esse *micca* adupratu per accede à un oggettu attribuitu diversu.Innota chì in Rust, ogni variabile (stack-allocated) hè cunsiderata cum'è un oggettu assignatu separatu.
    ///
    /// In altre parolle, `let z = x.wrapping_add((y as usize) - (x as usize))`*ùn* face * `z` listessu chì `y` ancu sè supponimu chì `T` abbia una dimensione `1` è ùn ci sia micca un overflow: `z` hè sempre attaccatu à l'ughjettu `x` hè attaccatu à, è a deriferenza hè Comportamentu indefinitu à menu chì `x` è Puntate `y` in u listessu ughjettu assignatu.
    ///
    /// Comparatu à [`add`], stu metudu ritarda in fondu u requisitu di stà in u listessu oggettu attribuitu: [`add`] hè un Comportamentu Indefinitu immediata quandu si francanu i limiti di l'ughjettu;`wrapping_add` produce un puntatore ma porta sempre à Comportamentu indefinitu se un puntatore hè dereferenziatu quandu hè fora di i limiti di l'ughjettu à u quale hè attaccatu.
    /// [`add`] pò esse ottimizatu megliu è hè dunque preferibile in codice sensibile à e prestazioni.
    ///
    /// U verificatu ritardatu cunsidereghja solu u valore di u puntatore chì hè statu dereferenziatu, micca i valori intermedii aduprati durante u calculu di u risultatu finale.
    /// Per esempiu, `x.wrapping_add(o).wrapping_sub(o)` hè sempre uguale à `x`.In altre parolle, lascià l'ughjettu assignatu è poi rientrallu dopu hè permessu.
    ///
    /// Se avete bisognu di attraversà i limiti di l'ughjettu, fate u puntatore in un numeru interu è fate l'aritmetica quì.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // Iterate cù un puntatore grezzu in incrementi di dui elementi
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Stu ciclu stampa "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Calcula l'offset da un puntatore aduprendu l'aritmetica di avvolgimentu.
    /// (comodità per `.wrapping_offset ((cuntate cum'è isize).wrapping_neg())`)
    ///
    /// `count` hè in unità di T;per esempiu, un `count` di 3 rapprisenta un offset di puntatore di byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Questa operazione stessa hè sempre sicura, ma aduprà u puntatore resultante ùn hè micca.
    ///
    /// U puntatore resultante ferma attaccatu à u listessu oggettu assignatu chì `self` punta à.
    /// Pò esse *micca* adupratu per accede à un oggettu attribuitu diversu.Innota chì in Rust, ogni variabile (stack-allocated) hè cunsiderata cum'è un oggettu assignatu separatu.
    ///
    /// In altre parolle, `let z = x.wrapping_sub((x as usize) - (y as usize))`*ùn* face * `z` listessu chì `y` ancu sè supponimu chì `T` abbia una dimensione `1` è ùn ci sia micca un overflow: `z` hè sempre attaccatu à l'ughjettu `x` hè attaccatu à, è a deriferenza hè Comportamentu indefinitu à menu chì `x` è Puntate `y` in u listessu ughjettu assignatu.
    ///
    /// Comparatu à [`sub`], stu metudu ritarda in fondu u requisitu di stà in u listessu oggettu attribuitu: [`sub`] hè un Comportamentu Indefinitu immediata quandu si francanu i limiti di l'ughjettu;`wrapping_sub` produce un puntatore ma porta sempre à Comportamentu indefinitu se un puntatore hè dereferenziatu quandu hè fora di i limiti di l'ughjettu à u quale hè attaccatu.
    /// [`sub`] pò esse ottimizatu megliu è hè dunque preferibile in codice sensibile à e prestazioni.
    ///
    /// U verificatu ritardatu cunsidereghja solu u valore di u puntatore chì hè statu dereferenziatu, micca i valori intermedii aduprati durante u calculu di u risultatu finale.
    /// Per esempiu, `x.wrapping_add(o).wrapping_sub(o)` hè sempre uguale à `x`.In altre parolle, lascià l'ughjettu assignatu è poi rientrallu dopu hè permessu.
    ///
    /// Se avete bisognu di attraversà i limiti di l'ughjettu, fate u puntatore in un numeru interu è fate l'aritmetica quì.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // Iterate cù un puntatore grezzu in incrementi di dui elementi (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Stu ciclu stampa "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Imposta u valore di u puntatore à `ptr`.
    ///
    /// In casu chì `self` sia un puntatore (fat) per un tippu micca dimensionatu, questa operazione hà da influenzà solu a parte di u puntatore, mentre chì per i puntatori (thin) à tippi di dimensioni, questu hà u listessu effettu cum'è una semplice assignazione.
    ///
    /// U puntatore resultante averà a provenienza di `val`, vale à dì, per un puntatore grassu, questa operazione hè semanticamente uguale à a creazione di un novu puntatore grassu cù u valore di u puntatore dati di `val` ma i metadati di `self`.
    ///
    ///
    /// # Examples
    ///
    /// Sta funzione hè primuramente utile per permette l'aritmetica di l'indicatore byte-sàviu nantu à indicatori potenzialmente grassi:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // stamperà "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SICUREZZA: In casu di un puntatore finu, questa operazione hè identica
        // à una missione simplice.
        // In casu di un indicatore di grassu, cù l'implementazione attuale di layout di indicatore di grassu, u primu campu di un tale indicatore hè sempre u puntatore di dati, chì hè altrettantu assignatu.
        //
        unsafe { *thin = val };
        self
    }

    /// Leghje u valore da `self` senza movelu.
    /// Questu lascia a memoria in `self` invariata.
    ///
    /// Vede [`ptr::read`] per prublemi di sicurità è esempi.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `read`.
        unsafe { read(self) }
    }

    /// Esegue una lettura volatile di u valore da `self` senza spostallu.Questu lascia a memoria in `self` invariata.
    ///
    /// L'operazioni volatili sò destinate à agisce nantu à a memoria I/O, è sò garantite per ùn esse elidite o riordinate da u compilatore in altre operazioni volatili.
    ///
    ///
    /// Vede [`ptr::read_volatile`] per prublemi di sicurità è esempi.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Leghje u valore da `self` senza movelu.
    /// Questu lascia a memoria in `self` invariata.
    ///
    /// A differenza di `read`, u puntatore pò esse micca alliniatu.
    ///
    /// Vede [`ptr::read_unaligned`] per prublemi di sicurità è esempi.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Copia `count * size_of<T>` byte da `self` à `dest`.
    /// A surghjente è a destinazione ponu sovrapposizione.
    ///
    /// NOTE: questu hà u listessu ordine * argumentu cum'è [`ptr::copy`].
    ///
    /// Vede [`ptr::copy`] per prublemi di sicurità è esempi.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Copia `count * size_of<T>` byte da `self` à `dest`.
    /// A surghjente è a destinazione pò *micca* sovrapposizione.
    ///
    /// NOTE: questu hà u listessu ordine * argumentu cum'è [`ptr::copy_nonoverlapping`].
    ///
    /// Vede [`ptr::copy_nonoverlapping`] per prublemi di sicurità è esempi.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Calcula l'offset chì deve esse applicatu à u puntatore per rende lu alliniatu à `align`.
    ///
    /// Se ùn hè micca pussibule di allineare u puntatore, l'implementazione restituisce `usize::MAX`.
    /// Hè permissibile per l'implementazione di *sempre* restituisce `usize::MAX`.
    /// Solu e prestazioni di u vostru algoritmu ponu dipende da ottene una compensazione utilizabile quì, micca a so currettezza.
    ///
    /// L'offset hè spressu in numeru di elementi `T`, è micca in bytes.U valore restituitu pò esse adupratu cù u metudu `wrapping_add`.
    ///
    /// Ùn ci hè nisuna garanzia chì a compensazione di u puntatore ùn si superi o và al di là di l'allocazione chì u puntatore punta in.
    ///
    /// Tocca à u chjamante per assicurà chì a compensazione restituita sia curretta in tutti i termini fora di l'allineamentu.
    ///
    /// # Panics
    ///
    /// A funzione panics se `align` ùn hè micca una putenza di dui.
    ///
    /// # Examples
    ///
    /// Accede à `u8` adiacente cum'è `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // mentre u puntatore pò esse alliniatu via `offset`, punterebbe fora di l'assignazione
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SICUREZZA: `align` hè statu verificatu per esse una putenza di 2 sopra
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Restituisce a lunghezza di una fetta cruda.
    ///
    /// U valore restituitu hè u numeru di **elementi**, micca u numeru di byte.
    ///
    /// Sta funzione hè sicura, ancu quandu a fetta cruda ùn pò esse ghjittata à una riferenza di fetta perchè u puntatore hè nulu o micca alliniatu.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SICUREZZA: hè sicuru perchè `*const [T]` è `FatPtr<T>` anu u listessu schema.
            // Solu `std` pò fà sta garanzia.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Restituisce un puntatore grezzu à u buffer di a fetta.
    ///
    /// Questu hè equivalente à casting `self` à `*const T`, ma più sicura per u tippu.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Restituisce un puntatore grezzu à un elementu o sottuclice, senza fà verificà i limiti.
    ///
    /// Chjamà stu metudu cun un indice fora di i limiti o quandu `self` ùn hè micca dereferencable hè *[cumpurtamentu indefinitu]* ancu se u puntatore resultante ùn hè micca usatu.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SICUREZZA: u chjamante assicura chì `self` sia dereferencable è `index` in-limiti.
        unsafe { index.get_unchecked(self) }
    }

    /// Restituisce `None` se u puntatore hè nulu, o altrimente restituisce una fetta spartuta à u valore imballatu in `Some`.
    /// In cuntrastu à [`as_ref`], questu ùn hà micca bisognu chì u valore deve esse inizializatu.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Quandu chjamate stu metudu, duvete assicurà chì *o* u puntatore hè NULL *o* tuttu ciò chì seguita hè veru:
    ///
    /// * U puntatore deve esse [valid] per leghje per `ptr.len() * mem::size_of::<T>()` parechji byte, è deve esse currettamente alliniatu.Questu significa in particulare:
    ///
    ///     * L'intera gamma di memoria di sta fetta deve esse cuntenuta in un unicu oggettu attribuitu!
    ///       E fette ùn ponu mai attraversà più oggetti attribuiti.
    ///
    ///     * U puntatore deve esse alliniatu ancu per fette di lunghezza zero.
    ///     Una di e ragioni per questu hè chì l'ottimisazioni di layout enum ponu basà nantu à riferimenti (cumprese fette di ogni lunghezza) chì sò allineati è micca nulli per distingue li da altri dati.
    ///
    ///     Pudete uttene un puntatore chì pò esse adupratu cum'è `data` per fette di lunghezza zero cù [`NonNull::dangling()`].
    ///
    /// * A dimensione totale `ptr.len() * mem::size_of::<T>()` di a fetta ùn deve esse più grande di `isize::MAX`.
    ///   Vede a documentazione di sicurezza di [`pointer::offset`].
    ///
    /// * Duvete applicà e regule di aliasing di Rust, postu chì a vita restituita `'a` hè scelta arbitrariamente è ùn riflette micca necessariamente a vita effettiva di i dati.
    ///   In particulare, per a durata di sta vita, a memoria chì u puntatore punta ùn deve esse mutata (eccettu in `UnsafeCell`).
    ///
    /// Questu vale ancu se u risultatu di stu metudu hè inutilizatu!
    ///
    /// Vede ancu [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Uguaglianza per i puntatori
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Cunfrontu per i puntatori
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}