use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ma non cero è covariante.
///
/// Questa hè spessu a cosa curretta da aduprà quandu custruisce strutture di dati aduprendu puntatori grezzi, ma hè infine più periculosa da aduprà per via di e so proprietà addiziunali.Se ùn site micca sicuru se duverete aduprà `NonNull<T>`, aduprate solu `*mut T`!
///
/// A differenza di `*mut T`, u puntatore deve esse sempre micca nullu, ancu sì u puntatore ùn hè mai dereferenziatu.Hè cusì chì e enumerie ponu aduprà stu valore proibitu cum'è discriminante-`Option<NonNull<T>>` hà a stessa dimensione cum'è `* mut T`.
/// Tuttavia u puntatore pò ancu pendà s'ellu ùn hè micca deriferenzatu.
///
/// A differenza di `*mut T`, `NonNull<T>` hè statu sceltu per esse covariante nantu à `T`.Questu rende pussibule aduprà `NonNull<T>` quandu custruisce tippi covarianti, ma introduce u risicu di insolvenza se adupratu in un tippu chì ùn deve micca esse in realtà covariante.
/// (A scelta opposta hè stata fatta per `*mut T` ancu se tecnicamente a mancanza di solitudine pò esse causata solu chjamendu funzioni periculose.)
///
/// A Covarianza hè curretta per a più astrazione sicura, cum'è `Box`, `Rc`, `Arc`, `Vec`, è `LinkedList`.Questu hè u casu perchè furniscenu una API pubblica chì segue e regule mutabili cumuni XOR di Rust.
///
/// Se u vostru tipu ùn pò micca esse sicuramente covariante, duvete assicurà chì cuntene qualchì campu addizionale per furnisce l'invarianza.Spessu questu campu serà un tippu [`PhantomData`] cum'è `PhantomData<Cell<T>>` o `PhantomData<&'a mut T>`.
///
/// Notate chì `NonNull<T>` hà un esempiu `From` per `&T`.Tuttavia, questu ùn cambia micca u fattu chì mutà per mezu di un (puntatore derivatu da a) riferimentu cumunu sia un comportamentu indefinitu à menu chì a mutazione accada in un [`UnsafeCell<T>`].U listessu vale per creà una riferenza mutevule da una riferenza cumuna.
///
/// Quandu si usa questu esempiu `From` senza un `UnsafeCell<T>`, hè a vostra responsabilità di assicurà chì `as_mut` ùn sia mai chjamatu, è `as_ptr` ùn sia mai usatu per mutazione.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` i puntatori ùn sò micca `Send` perchè i dati chì riferenu ponu esse aliased.
// NB, questu impl hè micca necessariu, ma duverebbe furnisce megliu messaghji d'errore.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` i puntatori ùn sò micca `Sync` perchè i dati chì riferenu ponu esse aliased.
// NB, questu impl hè micca necessariu, ma duverebbe furnisce megliu messaghji d'errore.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Crea un novu `NonNull` chì hè pendente, ma ben alliniatu.
    ///
    /// Questu hè utile per inizializà tippi chì allocanu pigmente, cum'è `Vec::new` face.
    ///
    /// Nutate bè chì u valore di u puntatore pò pudè raprisentà un puntatore validu à un `T`, ciò chì significa chì questu ùn deve esse adupratu cum'è valore di sentinella "not yet initialized".
    /// Tipi chì pigghiamente allocanu devenu tracciare l'inizializazione per qualchì altru mezu.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SICUREZZA: mem::align_of() rende un usu micca zero chì hè allora casted
        // à un * mut T.
        // Dunque, `ptr` ùn hè nullu è e cundizioni per chjamà new_unchecked() sò rispettate.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Restituisce un riferimentu cumunu à u valore.In cuntrastu à [`as_ref`], questu ùn hà micca bisognu chì u valore deve esse inizializatu.
    ///
    /// Per l'equivalente mutevule vede [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Quandu chjamate stu metudu, duvete assicurà chì tuttu ciò chì seguita sia veru:
    ///
    /// * U puntatore deve esse currettamente alliniatu.
    ///
    /// * Deve esse "dereferencable" in u sensu definitu in [the module documentation].
    ///
    /// * Duvete applicà e regule di aliasing di Rust, postu chì a vita restituita `'a` hè scelta arbitrariamente è ùn riflette micca necessariamente a vita effettiva di i dati.
    ///
    ///   In particulare, per a durata di sta vita, a memoria chì u puntatore punta ùn deve esse mutata (eccettu in `UnsafeCell`).
    ///
    /// Questu vale ancu se u risultatu di stu metudu hè inutilizatu!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SICUREZZA: u chjamante deve garantisce chì `self` risponde à tutti i
        // esigenze per una riferenza.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Restituisce un riferimentu unicu à u valore.In cuntrastu à [`as_mut`], questu ùn hà micca bisognu chì u valore deve esse inizializatu.
    ///
    /// Per a contrapartita cumuna vede [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Quandu chjamate stu metudu, duvete assicurà chì tuttu ciò chì seguita sia veru:
    ///
    /// * U puntatore deve esse currettamente alliniatu.
    ///
    /// * Deve esse "dereferencable" in u sensu definitu in [the module documentation].
    ///
    /// * Duvete applicà e regule di aliasing di Rust, postu chì a vita restituita `'a` hè scelta arbitrariamente è ùn riflette micca necessariamente a vita effettiva di i dati.
    ///
    ///   In particulare, per a durata di sta vita, a memoria chì u puntatore punta ùn deve esse accessu (lettu o scrittu) attraversu alcun altru puntatore.
    ///
    /// Questu vale ancu se u risultatu di stu metudu hè inutilizatu!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SICUREZZA: u chjamante deve garantisce chì `self` risponde à tutti i
        // esigenze per una riferenza.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Crea un novu `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` deve esse micca nullu.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SICUREZZA: u chjamante deve garantisce chì `ptr` hè micca nulu.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Crea un novu `NonNull` se `ptr` hè micca nullu.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SICUREZZA: U puntatore hè dighjà verificatu è ùn hè micca nullu
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Eseguisce a stessa funzionalità cum'è [`std::ptr::from_raw_parts`], eccettu chì un puntatore `NonNull` hè restituitu, à u cuntrariu di un puntatore `*const` grezzu.
    ///
    ///
    /// Vede a documentazione di [`std::ptr::from_raw_parts`] per più dettagli.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SICUREZZA: U risultatu di `ptr::from::raw_parts_mut` hè micca nullu perchè `data_address` hè.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Scumpone un puntatore (forse largu) in cumpunenti d'indirizzu è di metadati.
    ///
    /// U puntatore pò esse più tardi ricustruitu cù [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Acquista u puntatore `*mut` sottostante.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Restituisce un riferimentu cumunu à u valore.Se u valore pò esse micca inizializatu, [`as_uninit_ref`] deve esse adupratu invece.
    ///
    /// Per l'equivalente mutevule vede [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Quandu chjamate stu metudu, duvete assicurà chì tuttu ciò chì seguita sia veru:
    ///
    /// * U puntatore deve esse currettamente alliniatu.
    ///
    /// * Deve esse "dereferencable" in u sensu definitu in [the module documentation].
    ///
    /// * U puntatore deve puntà versu un esempiu inizializatu di `T`.
    ///
    /// * Duvete applicà e regule di aliasing di Rust, postu chì a vita restituita `'a` hè scelta arbitrariamente è ùn riflette micca necessariamente a vita effettiva di i dati.
    ///
    ///   In particulare, per a durata di sta vita, a memoria chì u puntatore punta ùn deve esse mutata (eccettu in `UnsafeCell`).
    ///
    /// Questu vale ancu se u risultatu di stu metudu hè inutilizatu!
    /// (A parte nantu à l'inizializazione ùn hè ancu cumpletamente decisa, ma finu à questu, l'unicu approcciu sicuru hè di assicurà ch'elli sianu veramente inizializati.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SICUREZZA: u chjamante deve garantisce chì `self` risponde à tutti i
        // esigenze per una riferenza.
        unsafe { &*self.as_ptr() }
    }

    /// Restituisce un riferimentu unicu à u valore.Se u valore pò esse micca inizializatu, [`as_uninit_mut`] deve esse adupratu invece.
    ///
    /// Per a contrapartita cumuna vede [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Quandu chjamate stu metudu, duvete assicurà chì tuttu ciò chì seguita sia veru:
    ///
    /// * U puntatore deve esse currettamente alliniatu.
    ///
    /// * Deve esse "dereferencable" in u sensu definitu in [the module documentation].
    ///
    /// * U puntatore deve puntà versu un esempiu inizializatu di `T`.
    ///
    /// * Duvete applicà e regule di aliasing di Rust, postu chì a vita restituita `'a` hè scelta arbitrariamente è ùn riflette micca necessariamente a vita effettiva di i dati.
    ///
    ///   In particulare, per a durata di sta vita, a memoria chì u puntatore punta ùn deve esse accessu (lettu o scrittu) attraversu alcun altru puntatore.
    ///
    /// Questu vale ancu se u risultatu di stu metudu hè inutilizatu!
    /// (A parte nantu à l'inizializazione ùn hè ancu cumpletamente decisa, ma finu à questu, l'unicu approcciu sicuru hè di assicurà ch'elli sianu veramente inizializati.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SICUREZZA: u chjamante deve garantisce chì `self` risponde à tutti i
        // esigenze per una riferenza mutabile.
        unsafe { &mut *self.as_ptr() }
    }

    /// Lancia à un puntatore di un altru tippu.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SICUREZZA: `self` hè un puntatore `NonNull` chì hè necessariamente micca nullu
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Crea una fetta cruda non nulla da un puntatore finu è da una lunghezza.
    ///
    /// L'argumentu `len` hè u numeru di **elementi**, micca u numeru di byte.
    ///
    /// Sta funzione hè sicura, ma a deriferenza di u valore di ritornu ùn hè micca sicura.
    /// Vede a documentazione di [`slice::from_raw_parts`] per i requisiti di sicurezza di fette.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // creà un puntatore di fetta quandu si principia cù un puntatore à u primu elementu
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Nutate bè chì st'esempiu dimostra artificialmente un usu di stu metudu, ma `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SICUREZZA: `data` hè un puntatore `NonNull` chì hè necessariamente micca nullu
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Restituisce a lunghezza di una fetta cruda non nulla.
    ///
    /// U valore restituitu hè u numeru di **elementi**, micca u numeru di byte.
    ///
    /// Sta funzione hè sicura, ancu quandu a fetta bruta non nulla ùn pò micca esse deriferenziata à una fetta perchè u puntatore ùn hà micca un indirizzu validu.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Restituisce un puntatore chì ùn hè micca nullu in u buffer di a slice.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SICUREZZA: Sapemu chì `self` hè micca nulu.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Restituisce un puntatore grezzu à u buffer di a fetta.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Restituisce un riferimentu cumunu à una fetta di valori forse micca inizializati.In cuntrastu à [`as_ref`], questu ùn hà micca bisognu chì u valore deve esse inizializatu.
    ///
    /// Per l'equivalente mutevule vede [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Quandu chjamate stu metudu, duvete assicurà chì tuttu ciò chì seguita sia veru:
    ///
    /// * U puntatore deve esse [valid] per leghje per `ptr.len() * mem::size_of::<T>()` parechji byte, è deve esse currettamente alliniatu.Questu significa in particulare:
    ///
    ///     * L'intera gamma di memoria di sta fetta deve esse cuntenuta in un unicu oggettu attribuitu!
    ///       E fette ùn ponu mai attraversà più oggetti attribuiti.
    ///
    ///     * U puntatore deve esse alliniatu ancu per fette di lunghezza zero.
    ///     Una di e ragioni per questu hè chì l'ottimisazioni di layout enum ponu basà nantu à riferimenti (cumprese fette di ogni lunghezza) chì sò allineati è micca nulli per distingue li da altri dati.
    ///
    ///     Pudete uttene un puntatore chì pò esse adupratu cum'è `data` per fette di lunghezza zero cù [`NonNull::dangling()`].
    ///
    /// * A dimensione totale `ptr.len() * mem::size_of::<T>()` di a fetta ùn deve esse più grande di `isize::MAX`.
    ///   Vede a documentazione di sicurezza di [`pointer::offset`].
    ///
    /// * Duvete applicà e regule di aliasing di Rust, postu chì a vita restituita `'a` hè scelta arbitrariamente è ùn riflette micca necessariamente a vita effettiva di i dati.
    ///   In particulare, per a durata di sta vita, a memoria chì u puntatore punta ùn deve esse mutata (eccettu in `UnsafeCell`).
    ///
    /// Questu vale ancu se u risultatu di stu metudu hè inutilizatu!
    ///
    /// Vede ancu [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Restituisce un riferimentu unicu à una fetta di valori forse micca inizializati.In cuntrastu à [`as_mut`], questu ùn hà micca bisognu chì u valore deve esse inizializatu.
    ///
    /// Per a contrapartita cumuna vede [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Quandu chjamate stu metudu, duvete assicurà chì tuttu ciò chì seguita sia veru:
    ///
    /// * U puntatore deve esse [valid] per leghje è scrive per `ptr.len() * mem::size_of::<T>()` parechji byte, è deve esse currettamente alliniatu.Questu significa in particulare:
    ///
    ///     * L'intera gamma di memoria di sta fetta deve esse cuntenuta in un unicu oggettu attribuitu!
    ///       E fette ùn ponu mai attraversà più oggetti attribuiti.
    ///
    ///     * U puntatore deve esse alliniatu ancu per fette di lunghezza zero.
    ///     Una di e ragioni per questu hè chì l'ottimisazioni di layout enum ponu basà nantu à riferimenti (cumprese fette di ogni lunghezza) chì sò allineati è micca nulli per distingue li da altri dati.
    ///
    ///     Pudete uttene un puntatore chì pò esse adupratu cum'è `data` per fette di lunghezza zero cù [`NonNull::dangling()`].
    ///
    /// * A dimensione totale `ptr.len() * mem::size_of::<T>()` di a fetta ùn deve esse più grande di `isize::MAX`.
    ///   Vede a documentazione di sicurezza di [`pointer::offset`].
    ///
    /// * Duvete applicà e regule di aliasing di Rust, postu chì a vita restituita `'a` hè scelta arbitrariamente è ùn riflette micca necessariamente a vita effettiva di i dati.
    ///   In particulare, per a durata di sta vita, a memoria chì u puntatore punta ùn deve esse accessu (lettu o scrittu) attraversu alcun altru puntatore.
    ///
    /// Questu vale ancu se u risultatu di stu metudu hè inutilizatu!
    ///
    /// Vede ancu [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Questu hè sicuru postu chì `memory` hè validu per leghje è scrive per `memory.len()` parechji byte.
    /// // Nutate bè chì chjamà `memory.as_mut()` ùn hè micca permessu quì postu chì u cuntenutu pò esse micca iniziatu.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Restituisce un puntatore grezzu à un elementu o sottuclice, senza fà verificà i limiti.
    ///
    /// Chjamà stu metudu cun un indice fora di i limiti o quandu `self` ùn hè micca dereferencable hè *[cumpurtamentu indefinitu]* ancu se u puntatore resultante ùn hè micca usatu.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SICUREZZA: u chjamante assicura chì `self` sia dereferencable è `index` in-limiti.
        // Di cunsiguenza, u puntatore resultante ùn pò esse NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SICUREZZA: Un puntatore Unicu ùn pò esse nullu, dunque e cundizioni per
        // new_unchecked() sò rispettati.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SICUREZZA: Una riferenza mutevule ùn pò esse nulla.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SICUREZZA: Una riferenza ùn pò esse nulla, allora e cundizioni per
        // new_unchecked() sò rispettati.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}