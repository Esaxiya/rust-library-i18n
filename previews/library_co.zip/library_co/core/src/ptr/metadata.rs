#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Fornisce u tippu di metadati di puntatore di qualsiasi tippu puntatu.
///
/// # Metadati di u puntatore
///
/// Tipi di puntatori crudi è tippi di riferenza in Rust ponu esse pensati cum'è fatti di duie parti:
/// un puntatore di dati chì cuntene l'indirizzu di memoria di u valore, è alcuni metadati.
///
/// Per i tippi di dimensione statica (chì implementanu u `Sized` traits) è ancu per i tippi `extern`, i puntatori sò ditti "fini": i metadati sò di dimensione zero è u so tippu hè `()`.
///
///
/// I puntatori à [dynamically-sized types][dst] si dicenu chì sò "largu" o "grassu", anu metadati di dimensione diversa da zero:
///
/// * Per e strutture chì l'ultimu campu hè un DST, i metadati sò i metadati per l'ultimu campu
/// * Per u tippu `str`, i metadati sò a lunghezza in byte cum'è `usize`
/// * Per i tipi di fette cum'è `[T]`, i metadati sò a lunghezza in l'articuli cum'è `usize`
/// * Per l'ogetti trait cum'è `dyn SomeTrait`, i metadati sò [`DynMetadata<Self>`][DynMetadata] (per esempiu `DynMetadata<dyn SomeTrait>`)
///
/// In u future, a lingua Rust pò guadagnà novi tippi di tippi chì anu metadati di puntatori diversi.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # U `Pointee` trait
///
/// U puntu di stu trait hè u so tippu assuciatu `Metadata`, chì hè `()` o `usize` o `DynMetadata<_>` cum'è discrittu sopra.
/// Hè automaticamente implementatu per ogni tippu.
/// Pò esse presuntu per esse implementatu in un cuntestu genericu, ancu senza un ligame currispundente.
///
/// # Usage
///
/// I puntatori grezzi ponu esse decomposti in l'indirizzu di dati è cumpunenti di metadati cù u so metudu [`to_raw_parts`].
///
/// In alternativa, metadati solu ponu esse estratti cù a funzione [`metadata`].
/// Un riferimentu pò esse passatu à [`metadata`] è implicitamente coercitu.
///
/// Un puntatore (possibly-wide) pò esse rimessu inseme da u so indirizzu è metadati cù [`from_raw_parts`] o [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// U tippu per metadati in indicatori è riferimenti à `Self`.
    #[lang = "metadata_type"]
    // NOTE: Mantene trait bounds in `static_assert_expected_bounds_for_metadata`
    //
    // in `library/core/src/ptr/metadata.rs` in sincronia cù quelli quì:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// I puntatori à i tippi chì implementanu stu alias trait sò "magri".
///
/// Ciò include tipichi statichi-Dimensione è tippi `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: ùn stabilizzate micca questu prima chì l'alias trait sò stabili in a lingua?
pub trait Thin = Pointee<Metadata = ()>;

/// Estrae u cumpunente di metadati di un puntatore.
///
/// I valori di u tippu `*mut T`, `&T`, o `&mut T` ponu esse trasmessi direttamente à sta funzione mentre implicitamente coercenu à `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SICUREZZA: L'accessu à u valore da l'unione `PtrRepr` hè sicuru postu chì * const T
    // è PtrComponents<T>avè i stessi schemi di memoria.
    // Solu std pò fà sta garanzia.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Forma un puntatore grezzu (possibly-wide) da un indirizzu di dati è metadati.
///
/// Sta funzione hè sicura ma u puntatore restituitu ùn hè micca necessariamente sicuru per a deriferenza.
/// Per e fette, vedi a documentazione di [`slice::from_raw_parts`] per i requisiti di sicurezza.
/// Per l'uggetti trait, i metadati devenu vene da un puntatore à u listessu tippu eraziatu sottostante.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SICUREZZA: L'accessu à u valore da l'unione `PtrRepr` hè sicuru postu chì * const T
    // è PtrComponents<T>avè i stessi schemi di memoria.
    // Solu std pò fà sta garanzia.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Eseguisce a stessa funzionalità cum'è [`from_raw_parts`], eccettu chì un puntatore `*mut` grezzu hè restituitu, à u cuntrariu di un puntatore `* const` grezzo.
///
///
/// Vede a documentazione di [`from_raw_parts`] per più dettagli.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SICUREZZA: L'accessu à u valore da l'unione `PtrRepr` hè sicuru postu chì * const T
    // è PtrComponents<T>avè i stessi schemi di memoria.
    // Solu std pò fà sta garanzia.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Manuale impl necessaria per evità `T: Copy` ligatu.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Manuale impl necessaria per evità `T: Clone` ligatu.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// I metadati per un tippu d'oggettu `Dyn = dyn SomeTrait` trait.
///
/// Hè un puntatore à una vtable (tavula di chjamata virtuale) chì raprisenta tutte l'infurmazioni necessarie per manipulà u tippu di cuncretu almacenatu in un oggettu trait.
/// A vtable in particulare cuntene:
///
/// * taglia di tippu
/// * tipu allinjamentu
/// * un puntatore à l'implicazione `drop_in_place` di u tippu (pò esse un no-op per plain-old-data)
/// * indicatori per tutti i metudi per l'implementazione di u tippu di u trait
///
/// Innota chì i primi trè sò speciali perchè sò necessarii per attribuisce, lasciare è deallocate qualsiasi oggettu trait.
///
/// Hè pussibule chjamà sta struct cun un paràmetru di tipu chì ùn hè micca un oggettu `dyn` trait (per esempiu `DynMetadata<u64>`) ma micca per ottene un valore significativu di quella struct.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// U prefissu cumunu di tutte e vtables.Hè seguitu da indicatori di funzione per i metudi trait.
///
/// Dettaglio d'implementazione privata di `DynMetadata::size_of` etc.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Restituisce a dimensione di u tippu assuciatu à sta vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Restituisce l'alineamentu di u tipu assuciatu à sta vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Restituisce a dimensione è l'allineamentu cum'è `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SICUREZZA: u compilatore hà emessu sta tavula per un tippu Rust concretu chì
        // hè cunnisciutu per avè una dispusizione valida.Listessu fundamentu cum'è in `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Manuale impls necessariu per evità i limiti `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}