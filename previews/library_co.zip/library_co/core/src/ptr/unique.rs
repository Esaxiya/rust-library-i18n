use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Un involucru intornu à un `*mut T` crudu non nullu chì indica chì u pussessore di questu involucru pussede u referente.
/// Utile per custruisce astrazioni cum'è `Box<T>`, `Vec<T>`, `String` è `HashMap<K, V>`.
///
/// A differenza di `*mut T`, `Unique<T>` si comporta "as if" era un esempiu di `T`.
/// Implementa `Send`/`Sync` se `T` hè `Send`/`Sync`.
/// Implica ancu u tipu di forte aliasing garantisce un esempiu di `T` pò aspettà:
/// u riferente di u puntatore ùn deve esse mudificatu senza una strada unica per u so propiu Unique.
///
/// Se ùn site micca sicuru se hè currettu aduprà `Unique` per i vostri scopi, pensate à aduprà `NonNull`, chì hà una semantica più debule.
///
///
/// A differenza di `*mut T`, u puntatore deve esse sempre micca nullu, ancu sì u puntatore ùn hè mai dereferenziatu.
/// Hè cusì chì e enumerie ponu aduprà stu valore pruibitu cum'è discriminante-`Option<Unique<T>>` hà a stessa dimensione cum'è `Unique<T>`.
/// Tuttavia u puntatore pò ancu pendà s'ellu ùn hè micca deriferenzatu.
///
/// A diversità di `*mut T`, `Unique<T>` hè covariante nantu à `T`.
/// Questu deve sempre esse currettu per ogni tippu chì sustene i requisiti di aliasing di Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: stu marcatore ùn hà nisuna cunsequenza per a varianza, ma hè necessariu
    // per dropck per capisce chì logicamente possedemu un `T`.
    //
    // Per i dettagli, vedi:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` i puntatori sò `Send` se `T` hè `Send` perchè i dati ch'elli riferiscenu ùn sò micca alializati.
/// Innota chì questu invariante aliasing ùn hè micca infurzatu da u sistema di tipu;l'astrazione aduprendu u `Unique` deve infurzarla.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` i puntatori sò `Sync` se `T` hè `Sync` perchè i dati ch'elli riferiscenu ùn sò micca alializati.
/// Innota chì questu invariante aliasing ùn hè micca infurzatu da u sistema di tipu;l'astrazione aduprendu u `Unique` deve infurzarla.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Crea un novu `Unique` chì hè pendente, ma ben alliniatu.
    ///
    /// Questu hè utile per inizializà tippi chì allocanu pigmente, cum'è `Vec::new` face.
    ///
    /// Nutate bè chì u valore di u puntatore pò pudè raprisentà un puntatore validu à un `T`, ciò chì significa chì questu ùn deve esse adupratu cum'è valore di sentinella "not yet initialized".
    /// Tipi chì pigghiamente allocanu devenu tracciare l'inizializazione per qualchì altru mezu.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SICUREZZA: mem::align_of() restituisce un puntatore validu, micca nullu.U
        // e cundizioni per chjamà new_unchecked() sò cusì rispettate.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Crea un novu `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` deve esse micca nullu.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SICUREZZA: u chjamante deve garantisce chì `ptr` hè micca nulu.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Crea un novu `Unique` se `ptr` hè micca nullu.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SICUREZZA: U puntatore hè dighjà verificatu è ùn hè nullu.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Acquista u puntatore `*mut` sottostante.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Diferenze u cuntenutu.
    ///
    /// A vita resultante hè ligata à sè stessu cusì si comporta "as if" era in realtà un esempiu di T chì si prende in prestitu.
    /// Se una vita (unbound) più lunga hè necessaria, aduprate `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SICUREZZA: u chjamante deve garantisce chì `self` risponde à tutti i
        // esigenze per una riferenza.
        unsafe { &*self.as_ptr() }
    }

    /// Diferenzie mutualmente u cuntenutu.
    ///
    /// A vita resultante hè ligata à sè stessu cusì si comporta "as if" era in realtà un esempiu di T chì si prende in prestitu.
    /// Se una vita (unbound) più lunga hè necessaria, aduprate `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SICUREZZA: u chjamante deve garantisce chì `self` risponde à tutti i
        // esigenze per una riferenza mutabile.
        unsafe { &mut *self.as_ptr() }
    }

    /// Lancia à un puntatore di un altru tippu.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SICUREZZA: Unique::new_unchecked() crea un novu unicu è bisogni
        // u puntatore datu per ùn esse nullu.
        // Postu chì passemu da sè cum'è puntatore, ùn pò esse nullu.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SICUREZZA: Una riferenza mutevule ùn pò esse nulla
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}