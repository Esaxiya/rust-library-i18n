//! Gestite manualmente a memoria per mezu di indicatori crudi.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Parechje funzioni in stu modulu piglianu indicatori grezzi cum'è argumenti è leghjenu o li scrivenu.Per chì questu sia sicuru, questi indicatori devenu esse *validi*.
//! S'ellu sia validu un puntatore dipende da l'operazione per a quale hè adupratu (leghje o scrive), è da a misura di a memoria chì si accede (vale à dì, quanti byte sò read/written).
//! A maiò parte di e funzioni adupranu `*mut T` è `* const T` per accede solu à un valore unicu, in quale casu a ducumentazione omette a dimensione è implicitamente assume chì sia `size_of::<T>()` byte.
//!
//! E regule precise per a validità ùn sò ancu determinate.E garanzie furnite à stu puntu sò assai minime:
//!
//! * Un puntatore [null] hè *mai* validu, mancu per l'accessi di [size zero][zst].
//! * Per chì un puntatore sia validu, hè necessariu, ma micca sempre sufficiente, chì u puntatore sia *dereferenceable*: l'intervallu di memoria di a dimensione data partendu da u puntatore deve esse tutti in i limiti di un unicu oggettu attribuitu.
//!
//! Innota chì in Rust, ogni variabile (stack-allocated) hè cunsiderata cum'è un oggettu assignatu separatu.
//! * Ancu per l'operazioni di [size zero][zst], u puntatore ùn deve micca puntà versu a memoria deallocata, vale à dì, a deallocazione rende i puntatori invalidi ancu per operazioni di dimensioni zero.
//! Tuttavia, lancià qualsiasi numeru interu *littérale* null à un puntatore hè valevule per accessi di dimensioni zero, ancu sì qualchì memoria accade à esiste à quell'indirizzu è sia deallocata.
//! Questu currisponde à scrive u vostru propiu allocatore: attribuisce oggetti di dimensioni zero ùn hè micca assai difficiule.
//! U modu canonicu per uttene un puntatore chì hè validu per accessi di dimensioni zero hè [`NonNull::dangling`].
//! * Tutti l'accessi realizati da e funzioni in stu modulu sò *non atomichi* in u sensu di [atomic operations] adupratu per sincronizà trà filetti.
//! Ciò significa chì hè un comportamentu indefinitu di fà dui accessi simultanei à u listessu locu da fili diversi, à menu chì i dui accessi leghjinu solu da memoria.
//! Notate chì questu include esplicitamente [`read_volatile`] è [`write_volatile`]: L'accessi volatili ùn ponu micca esse aduprati per a sincronizazione inter-thread.
//! * U risultatu di lancià una riferenza à un puntatore hè validu finu à quandu l'ughjettu sottostante hè vivu è nisuna riferenza (solu puntatori grezzi) hè aduprata per accede à a stessa memoria.
//!
//! Questi assiomi, cù l'usu attentu di [`offset`] per l'aritmetica di i puntatori, sò abbastanza per implementà currettamente parechje cose utili in codice periculosu.
//! Garantie più forti seranu furnite eventualmente, cume e regule [aliasing] sò state determinate.
//! Per più infurmazione, vedi u [book] è ancu a sezzione in a riferenza dedicata à [undefined behavior][ub].
//!
//! ## Alignment
//!
//! I puntatori grezzi validi cum'è definiti sopra ùn sò micca necessariamente allineati currettamente (induve l'allinamentu "proper" hè definitu da u tippu di punta, cioè, `*const T` deve esse alliniatu à `mem::align_of::<T>()`).
//! Tuttavia, a maiò parte di e funzioni richiedenu chì i so argumenti sianu allineati currettamente, è dichjareranu esplicitamente questu requisitu in a so documentazione.
//! Eccezzioni nutevuli à questu sò [`read_unaligned`] è [`write_unaligned`].
//!
//! Quandu una funzione richiede un allineamentu currettu, a face ancu se l'accessu hà una dimensione 0, vale à dì, ancu se a memoria ùn hè micca toccata in realtà.Pensate à aduprà [`NonNull::dangling`] in questi casi.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Esegue u distruttore (se ci hè) di u valore appuntatu.
///
/// Questu hè semanticamente equivalente à chjamà [`ptr::read`] è scartà u risultatu, ma hà i seguenti vantaghji:
///
/// * Hè *richiestu* di aduprà `drop_in_place` per abbandunà tippi micca dimensionati cum'è oggetti trait, perchè ùn ponu micca esse letti nantu à a pila è cascati normalmente.
///
/// * Hè più simpaticu per l'ottimisatore di fà questu nantu à [`ptr::read`] quandu si lascia a memoria assignata manualmente (per esempiu, in l'implementazioni di `Box`/`Rc`/`Vec`), chì u compilatore ùn hà micca bisognu di dimustrà chì hè bonu per eludir a copia.
///
///
/// * Pò esse adupratu per abbandunà i dati [pinned] quandu `T` ùn hè micca `repr(packed)` (i dati appuntati ùn devenu micca esse sposti prima ch'ella sia cascata).
///
/// I valori non allineati ùn ponu micca esse abbandunati in u locu, devenu esse copiati in un locu alliniatu prima aduprendu [`ptr::read_unaligned`].Per e strutture imballate, sta mossa hè fatta automaticamente da u compilatore.
/// Questu significa chì i campi di structs imballate ùn sò micca abbandunati in u locu.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * `to_drop` deve esse [valid] per leghje è scrive.
///
/// * `to_drop` deve esse currettamente alliniatu.
///
/// * U valore `to_drop` punti à deve esse validu per abbandunà, chì pò significà chì deve sustene invarianti supplementari, questu hè dipende da u tippu.
///
/// Inoltre, se `T` ùn hè micca [`Copy`], aduprà u valore appuntatu dopu à chjamà `drop_in_place` pò causà cumpurtamentu indefinitu.Nutate bè chì `*to_drop = foo` conta cum'è usu perchè pruvucarà à calà dinò u valore.
/// [`write()`] pò esse adupratu per rimpiazzà i dati senza pruvucallu à esse abbandunati.
///
/// Innota chì ancu se `T` hà una dimensione `0`, u puntatore deve esse micca NULL è allinatu currettamente.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Eliminà manualmente l'ultimu elementu da un vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Uttenite un puntatore grezzu à l'ultimu elementu in `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Accurtate `v` per impedisce chì l'ultimu elementu sia abbandunatu.
///     // Facemu quellu primu, per prevene prublemi se u `drop_in_place` sottu panics.
///     v.set_len(1);
///     // Senza una chjamata `drop_in_place`, l'ultimu articulu ùn seria mai abbandunatu, è a memoria chì gestisce serà filtrata.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Assicuratevi chì l'ultimu articulu hè statu abbandunatu.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Notate chì u compilatore esegue questa copia automaticamente quandu lasciate e strutture imballate, cioè, di solitu ùn avete micca da preoccupassi di tali prublemi à menu chì ùn chjamate `drop_in_place` manualmente.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // U codice quì ùn importa micca, questu hè rimpiazzatu da a vera colla à goccia da u compilatore.
    //

    // SICUREZZA: vede u cummentariu sopra
    unsafe { drop_in_place(to_drop) }
}

/// Crea un puntatore grezzu nulu.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Crea un puntatore grezzu mutabile null.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Manuale impl necessaria per evità `T: Clone` ligatu.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Manuale impl necessaria per evità `T: Copy` ligatu.
impl<T> Copy for FatPtr<T> {}

/// Forma una fetta cruda da un puntatore è una lunghezza.
///
/// L'argumentu `len` hè u numeru di **elementi**, micca u numeru di byte.
///
/// Sta funzione hè sicura, ma aduprendu in realtà u valore di ritornu ùn hè micca sicura.
/// Vede a documentazione di [`slice::from_raw_parts`] per i requisiti di sicurezza di fette.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // creà un puntatore di fetta quandu si principia cù un puntatore à u primu elementu
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SICUREZZA: Accede à u valore da l'unione `Repr` hè sicuru postu chì * const [T]
        //
        // è FatPtr anu i stessi schemi di memoria.Solu std pò fà sta garanzia.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Eseguisce a stessa funzionalità cum'è [`slice_from_raw_parts`], eccettu chì una fetta mutabile grezza hè restituita, à u cuntrariu di una fetta immutabile grezza.
///
///
/// Vede a documentazione di [`slice_from_raw_parts`] per più dettagli.
///
/// Sta funzione hè sicura, ma aduprendu in realtà u valore di ritornu ùn hè micca sicura.
/// Vede a documentazione di [`slice::from_raw_parts_mut`] per i requisiti di sicurezza di fette.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // assigna un valore à un indice in a fetta
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SICUREZZA: Accede à u valore da l'unione `Repr` hè sicuru postu chì * mut [T]
        // è FatPtr anu i stessi schemi di memoria
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Scambia i valori in dui lochi mutevuli di u listessu tippu, senza deinizializà nemmenu.
///
/// Ma per e duie eccezioni seguenti, sta funzione hè semanticamente equivalente à [`mem::swap`]:
///
///
/// * Funziona nantu à indicatori grezzi invece di riferimenti.
/// Quandu e referenze sò dispunibili, [`mem::swap`] deve esse preferitu.
///
/// * I dui valori puntati ponu sovrapposti.
/// Se i valori si sovrapponenu, allora serà usata a regione di memoria sovrapposta da `x`.
/// Questu hè dimustratu in u secondu esempiu sottu.
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * Sia `x` sia `y` devenu esse [valid] per leghje è scrive.
///
/// * Sia `x` sia `y` devenu esse allineati currettamente.
///
/// Innota chì ancu se `T` hà una dimensione `0`, i puntatori ùn devenu micca NULL è allineati currettamente.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Scambià duie regioni chì ùn si sovrapponenu:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // questu hè `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // questu hè `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Scambià duie regioni sovrapposte:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // questu hè `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // questu hè `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // L'indici `1..3` di a fetta si sovrapponenu trà `x` è `y`.
///     // I risultati ragiunevuli seranu per elli `[2, 3]`, perchè l'indici `0..3` sò `[1, 2, 3]` (currispondenu `y` prima di `swap`);o per esse `[0, 1]` per chì l'indici `1..4` sianu `[0, 1, 2]` (currispondenu à `x` prima di `swap`).
/////
///     // Questa implementazione hè definita per fà l'ultima scelta.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Dacci un pocu di spaziu per travaglià.
    // Ùn avemu micca da preoccupassi di e gocce: `MaybeUninit` ùn face nunda quandu hè cascatu.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Eseguite u swap SIGURTÀ: u chjamante deve garantisce chì `x` è `y` sò validi per scrive è currettamente allineati.
    // `tmp` ùn pò micca esse sovrapposti nè `x` nè `y` perchè `tmp` era ghjustu attribuitu nantu à a pila cum'è un oggettu assignatu separatu.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` è `y` pò sovrapposizione
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Scambia byte `count * size_of::<T>()` trà e duie regioni di memoria chì cumincianu à `x` è `y`.
/// E duie regioni ùn devenu *micca* sovrapposizione.
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * Sia `x` sia `y` devenu esse [valid] per leghje è scrive di `cuntà *
///   size_of: :<T>() `bytes.
///
/// * Sia `x` sia `y` devenu esse allineati currettamente.
///
/// * A regione di memoria chì principia à `x` cù una dimensione di `count *
///   size_of: :<T>() `Byte ùn devenu * ** sovrapposizione cù a regione di memoria chì principia da `y` cù a stessa dimensione.
///
/// Innota chì ancu se a dimensione copiata in modu efficace (`count * size_of: :<T>()`) hè `0`, i puntatori ùn devenu micca NULL è currettamente allineati.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SICUREZZA: u chjamante deve garantisce chì `x` è `y` sò
    // validu per scrive è currettamente allinatu.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Per i tippi più chjucu cà l'ottimisazione di u bloccu quì sottu, basta à scambià direttamente per evità di pessimizà u codegen.
    //
    if mem::size_of::<T>() < 32 {
        // SICUREZZA: u chjamante deve garantisce chì `x` è `y` sò validi
        // per scrive, currettamente allineati, è senza sovrapposizione.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // L'approcciu quì hè di aduprà simd per scambià x&y in modu efficiente.
    // A prova rivela chì scambià 32 byte o 64 byte à a volta hè u più efficace per i processori Intel Haswell E.
    // LLVM hè più capace d'ottimizà se demu à una struct un #[repr(simd)], ancu se ùn usemu micca in realtà sta struct direttamente.
    //
    //
    // FIXME repr(simd) rottu nantu à emscripten è redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Ciclu attraversu x&y, copiendu li `Block` à a volta L'ottimisatore deve sbulicà cumpletamente u ciclu per a maiò parte di i tippi NB
    // Ùn pudemu micca aduprà un ciclu for cum'è u `range` impl chjama `mem::swap` recursivamente
    //
    let mut i = 0;
    while i + block_size <= len {
        // Crià qualchì memoria micca inizializata cum'è spaziu di scratch A dichjarazione di `t` quì evita di allineare a pila quandu stu ciclu hè inutilizatu
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SICUREZZA: Cum'è `i < len`, è cum'è u chjamante deve garantisce chì `x` è `y` sò validi
        // per i byte `len`, `x + i` è `y + i` devenu esse indirizzi validi, chì rispetti u cuntrattu di sicurezza per `add`.
        //
        // Inoltre, u chjamante deve garantisce chì `x` è `y` sò validi per scrive, currettamente allineati, è micca sovrapposti, chì rispetta u cuntrattu di sicurezza per `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Scambià un bloccu di byte di x&y, aduprendu t cum'è buffer tempuraneu Questu deve esse ottimizatu in operazioni SIMD efficienti induve sò dispunibili
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Scambià qualsiasi byte restante
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SICUREZZA: vede u cummentariu di sicurezza precedente.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Sposta `src` in u `dst` appuntutu, restituendu u valore `dst` precedente.
///
/// Nè u valore hè cascatu.
///
/// Sta funzione hè semanticamente equivalente à [`mem::replace`] eccettu chì opera nantu à indicatori grezzi invece di riferimenti.
/// Quandu e referenze sò dispunibili, [`mem::replace`] deve esse preferitu.
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * `dst` deve esse [valid] per leghje è scrive.
///
/// * `dst` deve esse currettamente alliniatu.
///
/// * `dst` deve indicà un valore currettamente inizializatu di tippu `T`.
///
/// Innota chì ancu se `T` hà una dimensione `0`, u puntatore deve esse micca NULL è allinatu currettamente.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` averia u listessu effettu senza avè bisognu di u bloccu periculosu.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SICUREZZA: u chjamante deve garantisce chì `dst` hè validu per esse
    // ghjittatu à un riferimentu mutevule (validu per scrive, alliniatu, inizializatu), è ùn pò micca soprappone `src` postu chì `dst` deve puntà à un ughjettu distinatu attribuitu.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ùn pò micca soprappone
    }
    src
}

/// Leghje u valore da `src` senza movelu.Questu lascia a memoria in `src` invariata.
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * `src` deve esse [valid] per leghje.
///
/// * `src` deve esse currettamente alliniatu.Aduprate [`read_unaligned`] se questu ùn hè micca u casu.
///
/// * `src` deve indicà un valore currettamente inizializatu di tippu `T`.
///
/// Innota chì ancu se `T` hà una dimensione `0`, u puntatore deve esse micca NULL è allinatu currettamente.
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implementà manualmente [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Crea una copia bitwise di u valore in `a` in `tmp`.
///         let tmp = ptr::read(a);
///
///         // Esce da stu puntu (sia da u ritornu esplicitu sia da a chjamata à una funzione chì panics) pruvucaria à calà u valore in `tmp` mentre u listessu valore hè sempre riferitu da `a`.
///         // Questa puderia attivà un comportamentu indefinitu se `T` ùn hè micca `Copy`.
/////
/////
///
///         // Crea una copia bitwise di u valore in `b` in `a`.
///         // Questu hè sicuru perchè e referenze mutevuli ùn ponu micca alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Cum'è sopra, esce da quì puderia attivà un comportamentu indefinitu perchè u listessu valore hè riferitu da `a` è `b`.
/////
///
///         // Move `tmp` in `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` hè statu spustatu (`write` piglia a pruprietà di u so secondu argumentu), cusì nunda ùn hè cascatu implicitamente quì.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Proprietà di u Valore Ritorna
///
/// `read` crea una copia bitwise di `T`, indipendentemente da se `T` hè [`Copy`].
/// Se `T` ùn hè micca [`Copy`], aduprendu sia u valore restituitu sia u valore in `*src` pò viulà a sicurezza di a memoria.
/// Nota chì assignà à `*src` conta cum'è usu perchè pruvarà à calà u valore in `* src`.
///
/// [`write()`] pò esse adupratu per rimpiazzà i dati senza pruvucallu à esse abbandunati.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` avà punta à a stessa memoria sottostante cum'è `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Assignà à `s2` face chì u so valore originale sia abbandunatu.
///     // Al di là di stu puntu, `s` ùn deve più esse adupratu, postu chì a memoria sottostante hè stata liberata.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Assignà à `s` faria falà dinò u vechju valore, resultendu in un cumpurtamentu indefinitu.
/////
///     // s= String::from("bar");//ERRORE
///
///     // `ptr::write` pò esse adupratu per rimpiazzà un valore senza abbandunallu.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SICUREZZA: u chjamante deve garantisce chì `src` hè validu per leghje.
    // `src` ùn pò micca soprappone `tmp` perchè `tmp` hè statu ghjustu attribuitu nantu à a pila cum'è un oggettu assignatu separatu.
    //
    //
    // Inoltre, postu chì avemu ghjustu scrittu un valore validu in `tmp`, hè garantitu per esse inizializatu currettamente.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Leghje u valore da `src` senza movelu.Questu lascia a memoria in `src` invariata.
///
/// A diversità di [`read`], `read_unaligned` funziona cù puntatori micca allineati.
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * `src` deve esse [valid] per leghje.
///
/// * `src` deve indicà un valore currettamente inizializatu di tippu `T`.
///
/// Cum'è [`read`], `read_unaligned` crea una copia bitwise di `T`, indipendentemente da se `T` hè [`Copy`].
/// Se `T` ùn hè micca [`Copy`], aduprendu sia u valore restituitu sia u valore in `*src` pò [violate memory safety][read-ownership].
///
/// Innota chì ancu se `T` hà una dimensione `0`, u puntatore deve esse micca NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Su `packed` structs
///
/// Hè attualmente impussibile di creà puntatori grezzi à campi non allineati di una struttura imballata.
///
/// Tentà di creà un puntatore grezzu in un campu `unaligned` struct cù una espressione cum'è `&packed.unaligned as *const FieldType` crea un riferimentu intermediu senza allineamentu prima di cunvertisce quellu in un puntatore grezzo.
///
/// Chì sta riferenza sia tempuraria è ghjittata subitu ùn hè micca impurtante perchè u compilatore aspetta sempre chì e referenze sianu allineate currettamente.
/// Di conseguenza, aduprà `&packed.unaligned as *const FieldType` provoca un comportamentu* indefinitu * immediatu in u vostru prugramma.
///
/// Un esempiu di ciò chì ùn deve micca fà è cumu si tratta di `read_unaligned` hè:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Quì circhemu di piglià l'indirizzu di un interu 32-bit chì ùn hè micca alliniatu.
///     let unaligned =
///         // Una riferenza temporanea senza allineamentu hè creata quì chì dà risultati in un comportamentu indefinitu indipendentemente da se a riferenza hè usata o micca.
/////
///         &packed.unaligned
///         // U casting à un puntatore crudu ùn aiuta micca;l'errore hè digià accadutu.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// L'accessu à i campi non allineati direttamente cù per esempiu `packed.unaligned` hè sicuru quantunque.
///
///
///
///
///
///
// FIXME: Mette à ghjornu documenti basatu annantu à u risultatu di RFC #2582 è amichi.
/// # Examples
///
/// Leghjite un valore di usize da un buffer byte:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SICUREZZA: u chjamante deve garantisce chì `src` hè validu per leghje.
    // `src` ùn pò micca soprappone `tmp` perchè `tmp` hè statu ghjustu attribuitu nantu à a pila cum'è un oggettu assignatu separatu.
    //
    //
    // Inoltre, postu chì avemu ghjustu scrittu un valore validu in `tmp`, hè garantitu per esse inizializatu currettamente.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Sovrascrive un locu di memoria cù u valore datu senza leghje o lascià cascà u vechju valore.
///
/// `write` ùn lascia cascà u cuntenutu di `dst`.
/// Questu hè sicuru, ma puderia sfuglà allocazioni o risorse, perciò si deve fà casu à ùn rimpiazzà un ogettu chì duverebbe esse abbandunatu.
///
///
/// Inoltre, ùn lascia micca `src`.Semanticamente, `src` hè trasferitu in u locu indicatu da `dst`.
///
/// Questu hè appruvatu per inizializà a memoria non inizializzata, o rimpiazzà memoria chì hè stata prima [`read`] da.
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * `dst` deve esse [valid] per scrive.
///
/// * `dst` deve esse currettamente alliniatu.Aduprate [`write_unaligned`] se questu ùn hè micca u casu.
///
/// Innota chì ancu se `T` hà una dimensione `0`, u puntatore deve esse micca NULL è allinatu currettamente.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implementà manualmente [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Crea una copia bitwise di u valore in `a` in `tmp`.
///         let tmp = ptr::read(a);
///
///         // Esce da stu puntu (sia da u ritornu esplicitu sia da a chjamata à una funzione chì panics) pruvucaria à calà u valore in `tmp` mentre u listessu valore hè sempre riferitu da `a`.
///         // Questa puderia attivà un comportamentu indefinitu se `T` ùn hè micca `Copy`.
/////
/////
///
///         // Crea una copia bitwise di u valore in `b` in `a`.
///         // Questu hè sicuru perchè e referenze mutevuli ùn ponu micca alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Cum'è sopra, esce da quì puderia attivà un comportamentu indefinitu perchè u listessu valore hè riferitu da `a` è `b`.
/////
///
///         // Move `tmp` in `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` hè statu spustatu (`write` piglia a pruprietà di u so secondu argumentu), cusì nunda ùn hè cascatu implicitamente quì.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Chjamemu l'intrinsicu direttamente per evità chjamate à funzioni in u codice generatu cum'è `intrinsics::copy_nonoverlapping` hè una funzione di involucru.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SICUREZZA: u chjamante deve garantisce chì `dst` hè validu per scrive.
    // `dst` ùn pò micca soprappone `src` perchè u chjamante hà accessu mutevule à `dst` mentre `src` hè di pruprietà di sta funzione.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Sovrascrive un locu di memoria cù u valore datu senza leghje o lascià cascà u vechju valore.
///
/// A differenza di [`write()`], u puntatore pò esse micca alliniatu.
///
/// `write_unaligned` ùn lascia cascà u cuntenutu di `dst`.Questu hè sicuru, ma puderia sfuglà allocazioni o risorse, perciò si deve fà casu à ùn rimpiazzà un ogettu chì duverebbe esse abbandunatu.
///
/// Inoltre, ùn lascia micca `src`.Semanticamente, `src` hè trasferitu in u locu indicatu da `dst`.
///
/// Questu hè appruvatu per inizializà a memoria non inizializata, o rimpiazzà a memoria chì hè stata letta in precedenza cù [`read_unaligned`].
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * `dst` deve esse [valid] per scrive.
///
/// Innota chì ancu se `T` hà una dimensione `0`, u puntatore deve esse micca NULL.
///
/// [valid]: self#safety
///
/// ## Su `packed` structs
///
/// Hè attualmente impussibile di creà puntatori grezzi à campi non allineati di una struttura imballata.
///
/// Tentà di creà un puntatore grezzu in un campu `unaligned` struct cù una espressione cum'è `&packed.unaligned as *const FieldType` crea un riferimentu intermediu senza allineamentu prima di cunvertisce quellu in un puntatore grezzo.
///
/// Chì sta riferenza sia tempuraria è ghjittata subitu ùn hè micca impurtante perchè u compilatore aspetta sempre chì e referenze sianu allineate currettamente.
/// Di conseguenza, aduprà `&packed.unaligned as *const FieldType` provoca un comportamentu* indefinitu * immediatu in u vostru prugramma.
///
/// Un esempiu di ciò chì ùn deve micca fà è cumu si tratta di `write_unaligned` hè:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Quì circhemu di piglià l'indirizzu di un interu 32-bit chì ùn hè micca alliniatu.
///     let unaligned =
///         // Una riferenza temporanea senza allineamentu hè creata quì chì dà risultati in un comportamentu indefinitu indipendentemente da se a riferenza hè usata o micca.
/////
///         &mut packed.unaligned
///         // U casting à un puntatore crudu ùn aiuta micca;l'errore hè digià accadutu.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// L'accessu à i campi non allineati direttamente cù per esempiu `packed.unaligned` hè sicuru quantunque.
///
///
///
///
///
///
///
///
///
// FIXME: Mette à ghjornu documenti basatu annantu à u risultatu di RFC #2582 è amichi.
/// # Examples
///
/// Scrivite un valore di usize in un buffer byte:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SICUREZZA: u chjamante deve garantisce chì `dst` hè validu per scrive.
    // `dst` ùn pò micca soprappone `src` perchè u chjamante hà accessu mutevule à `dst` mentre `src` hè di pruprietà di sta funzione.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Chjamemu l'intrinsicu direttamente per evità chjamate à funzione in u codice generatu.
        intrinsics::forget(src);
    }
}

/// Esegue una lettura volatile di u valore da `src` senza spostallu.Questu lascia a memoria in `src` invariata.
///
/// L'operazioni volatili sò destinate à agisce nantu à a memoria I/O, è sò garantite per ùn esse elidite o riordinate da u compilatore in altre operazioni volatili.
///
/// # Notes
///
/// Rust ùn hà micca attualmente un mudellu di memoria rigurosamente è formalmente definitu, cusì a semantica precisa di ciò chì "volatile" significa quì hè sughjettu à cambià cù u tempu.
/// Dittu chistu, a semantica finiscerà guasi sempre abbastanza simile à [C11's definition of volatile][c11].
///
/// U compilatore ùn deve micca cambià l'ordine relativu o u numeru di operazioni di memoria volatile.
/// Tuttavia, l'operazioni di memoria volatile in tippi di dimensioni zero (per esempiu, se un tippu di dimensioni zero hè passatu à `read_volatile`) sò noops è ponu esse ignorate.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * `src` deve esse [valid] per leghje.
///
/// * `src` deve esse currettamente alliniatu.
///
/// * `src` deve indicà un valore currettamente inizializatu di tippu `T`.
///
/// Cum'è [`read`], `read_volatile` crea una copia bitwise di `T`, indipendentemente da se `T` hè [`Copy`].
/// Se `T` ùn hè micca [`Copy`], aduprendu sia u valore restituitu sia u valore in `*src` pò [violate memory safety][read-ownership].
/// Tuttavia, u almacenamentu di tippi non-[`Copia`] in memoria volatile hè guasi sicuramente incorrettu.
///
/// Innota chì ancu se `T` hà una dimensione `0`, u puntatore deve esse micca NULL è allinatu currettamente.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Cum'è in C, sì una operazione hè volatile ùn hà alcuna influenza nant'à e dumande chì implicanu accessu simultaneu da più fili.L'accessi volatili si comportanu esattamente cum'è l'accessi non atomici in stu sensu.
///
/// In particulare, una corsa trà un `read_volatile` è qualsiasi operazione di scrittura in u listessu locu hè un cumpurtamentu indefinitu.
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Micca in panicu per mantene l'impattu di i codegen più chjucu.
        abort();
    }
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Esegue una scrittura volatile di un locu di memoria cù u valore datu senza leghje o abbandunà u vechju valore.
///
/// L'operazioni volatili sò destinate à agisce nantu à a memoria I/O, è sò garantite per ùn esse elidite o riordinate da u compilatore in altre operazioni volatili.
///
/// `write_volatile` ùn lascia cascà u cuntenutu di `dst`.Questu hè sicuru, ma puderia sfuglà allocazioni o risorse, perciò si deve fà casu à ùn rimpiazzà un ogettu chì duverebbe esse abbandunatu.
///
/// Inoltre, ùn lascia micca `src`.Semanticamente, `src` hè trasferitu in u locu indicatu da `dst`.
///
/// # Notes
///
/// Rust ùn hà micca attualmente un mudellu di memoria rigurosamente è formalmente definitu, cusì a semantica precisa di ciò chì "volatile" significa quì hè sughjettu à cambià cù u tempu.
/// Dittu chistu, a semantica finiscerà guasi sempre abbastanza simile à [C11's definition of volatile][c11].
///
/// U compilatore ùn deve micca cambià l'ordine relativu o u numeru di operazioni di memoria volatile.
/// Tuttavia, l'operazioni di memoria volatile in tippi di dimensioni zero (per esempiu, se un tippu di dimensioni zero hè passatu à `write_volatile`) sò noops è ponu esse ignorate.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * `dst` deve esse [valid] per scrive.
///
/// * `dst` deve esse currettamente alliniatu.
///
/// Innota chì ancu se `T` hà una dimensione `0`, u puntatore deve esse micca NULL è allinatu currettamente.
///
/// [valid]: self#safety
///
/// Cum'è in C, sì una operazione hè volatile ùn hà alcuna influenza nant'à e dumande chì implicanu accessu simultaneu da più fili.L'accessi volatili si comportanu esattamente cum'è l'accessi non atomici in stu sensu.
///
/// In particulare, una corsa trà un `write_volatile` è qualsiasi altra operazione (lettura o scrittura) in u stessu locu hè un cumpurtamentu indefinitu.
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Micca in panicu per mantene l'impattu di i codegen più chjucu.
        abort();
    }
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Alignate u puntatore `p`.
///
/// Calculate offset (in termini d'elementi di striscia `stride`) chì deve esse applicatu à u puntatore `p` in modu chì u puntatore `p` sia alliniatu à `a`.
///
/// Note: Questa implementazione hè stata accuratamente adattata per micca panic.Hè UB per questu à panic.
/// L'unicu cambiamentu veru chì si pò fà quì hè u cambiamentu di `INV_TABLE_MOD_16` è e costanti assuciate.
///
/// Se mai dicideremu di rende pussibule chjamà l'intrinsicu cù `a` chì ùn hè micca una putenza di dui, serà probabilmente più prudente solu di cambià in una implementazione ingenua piuttostu chè di pruvà à adattà questu per accoglie quellu cambiamentu.
///
///
/// Tutte e dumande andate à@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): L'usu direttu di questi intrinsici migliora codegen significativamente à opt-level <=
    // 1, induve e versioni di metudu di queste operazioni ùn sò micca inline.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Calculate inversu modulare multiplicativu di `x` modulu `m`.
    ///
    /// Questa implementazione hè adattata per `align_offset` è hà e seguenti precondizioni:
    ///
    /// * `m` hè una putenza di dui;
    /// * `x < m`; (se `x ≥ m`, passate invece in `x % m`)
    ///
    /// L'implementazione di sta funzione ùn deve micca panic.Sempre.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Table inversa modulare multiplicativa modulu 2⁴=16.
        ///
        /// Nota, chì sta tavula ùn cuntene valori induve l'inversu ùn esiste micca (vale à dì, per `0⁻¹ mod 16`, `2⁻¹ mod 16`, ecc.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulu per u quale hè destinatu u `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SEGURITÀ: `m` hè necessariu per esse una putenza di dui, dunque diversa da zero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Iteremu "up" cù a formula seguente:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // finu à 2²ⁿ ≥ m.Dopu pudemu riduce à u nostru `m` desideratu pigliendu u risultatu `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Nota, chì adupremu intenzionalmente operazioni di imballu quì-a formula originale utilizza per esempiu, sottrazione `mod n`.
                // Hè propiu bè di fà li `mod usize::MAX` invece, perchè pigliemu u risultatu `mod n` à a fine quantunque.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SEGURITÀ: `a` hè una putenza di dui, dunque diversa da zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` u casu pò esse calculatu più simplicemente per mezu di `-p (mod a)`, ma cusì impedisce a capacità di LLVM di selezziunà struzzioni cum'è `lea`.Invece calculemu
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // chì distribuisce l'operazioni intornu à u portante, ma pessimizendu `and` abbastanza per LLVM per esse capace di aduprà e varie ottimizzazioni chì cunnosce.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Digià alliniatu.Iè!
        return 0;
    } else if stride == 0 {
        // Se u puntatore ùn hè micca alliniatu, è l'elementu hè di dimensione zero, allora nisuna quantità d'elementi mai allinearà u puntatore.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SICUREZZA: a hè putenza di dui dunque nulla.stride==0 casu hè trattatu sopra.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SICUREZZA: gcdpow hà un limite superiore chì hè al massimu u numeru di bit in un usu.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SICUREZZA: u gcd hè sempre più grande o uguale à 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Questu branch risolve per l'equazione di congruenza lineare seguente:
        //
        // ` p + so = 0 mod a `
        //
        // `p` eccu u valore di u puntatore, `s`, stride di `T`, `o` offset in `T`s, è `a`, l'allinjamentu dumandatu.
        //
        // Cù `g = gcd(a, s)`, è a cundizione sopra affermendu chì `p` hè ancu divisibile per `g`, pudemu denotà `a' = a/g`, `s' = s/g`, `p' = p/g`, allora questu diventa equivalente à:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // U primu termini hè "the relative alignment of `p` to `a`" (divisu da u `g`), u sicondu termini hè "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (divisu dinò per `g`).
        //
        // A divisione per `g` hè necessaria per fà l'inversu ben furmatu se `a` è `s` ùn sò micca coprimi.
        //
        // Inoltre, u risultatu pruduttu da sta soluzione ùn hè micca "minimal", dunque hè necessariu piglià u risultatu `o mod lcm(s, a)`.Pudemu rimpiazzà `lcm(s, a)` cù solu un `a'`.
        //
        //
        //
        //
        //

        // SICUREZZA: `gcdpow` hà un limite superiore micca più grande di u numeru di 0-bit in fine in `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SICUREZZA: `a2` hè diversu da zero.Sposta `a` da `gcdpow` ùn pò micca spustà alcunu di i pezzi stabiliti
        // in `a` (di i quali ne hà esattamente unu).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SICUREZZA: `gcdpow` hà un limite superiore micca più grande di u numeru di 0-bit in fine in `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SICUREZZA: `gcdpow` hà un limite superiore micca più grande di u numeru di 0-bit in fine
        // `a`.
        // Inoltre, a suttrazione ùn pò micca trabuccà, perchè `a2 = a >> gcdpow` serà sempre strettamente superiore à `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SICUREZZA: `a2` hè una putenza di dui, cum'è pruvata sopra.`s2` hè strettamente menu di `a2`
        // perchè `(s % a) >> gcdpow` hè strettamente menu di `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Ùn si pò micca allineare à tutti.
    usize::MAX
}

/// Confronta l'indicatori crudi per l'uguaglianza.
///
/// Hè u listessu cum'è cù l'operatore `==`, ma menu genericu:
/// l'argumenti devenu esse `*const T` puntatori grezzi, micca qualcosa chì implementi `PartialEq`.
///
/// Questu pò esse adupratu per paragunà e referenze `&T` (chì coercenu à `*const T` implicitamente) da u so indirizzu invece di paragunà i valori chì indicanu (chì hè ciò chì l'implementazione `PartialEq for &T` faci).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// E fette sò ancu paragunate per a so lunghezza (indicatori di grassu):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits sò ancu paragunati da a so implementazione:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // I puntatori anu indirizzi uguali.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // L'uggetti anu indirizzi uguali, ma `Trait` hà diverse implementazioni.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // A cunversione di a riferenza à un `*const u8` si compara per indirizzu.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash un puntatore crudu.
///
/// Questu pò esse adupratu per hash una riferenza `&T` (chì coercisce à `*const T` implicitamente) da u so indirizzu piuttostu da u valore chì punta (chì hè ciò chì face l'implementazione `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls per i puntatori di funzione
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: U cast intermediu cum'è usu hè necessariu per AVR
                // cusì chì u spaziu di indirizzu di u puntatore di a funzione surghjente hè cunservatu in u puntatore di funzione finale.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: U cast intermediu cum'è usu hè necessariu per AVR
                // cusì chì u spaziu di indirizzu di u puntatore di a funzione surghjente hè cunservatu in u puntatore di funzione finale.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Nisuna funzione variadica cù 0 parametri
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Crea un puntatore crudu `const` in un locu, senza creà una riferenza intermedia.
///
/// A creazione di una riferenza cù `&`/`&mut` hè permessa solu sì u puntatore hè alliniatu currettamente è punta à i dati inizializati.
/// Per i casi induve questi requisiti ùn valenu micca, i puntatori grezzi devenu esse usati invece.
/// Tuttavia, `&expr as *const _` crea una riferenza prima di lancialla in un puntatore grezzu, è quella riferenza hè sottumessa à e stesse regule cum'è tutte l'altre referenze.
///
/// Questa macro pò creà un puntatore grezzu *senza* creà prima una riferenza.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` creerebbe un riferimentu micca alliniatu, è cusì seria Comportamentu indefinitu!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Crea un puntatore crudu `mut` in un locu, senza creà una riferenza intermedia.
///
/// A creazione di una riferenza cù `&`/`&mut` hè permessa solu sì u puntatore hè alliniatu currettamente è punta à i dati inizializati.
/// Per i casi induve questi requisiti ùn valenu micca, i puntatori grezzi devenu esse usati invece.
/// Tuttavia, `&mut expr as *mut _` crea una riferenza prima di lancialla in un puntatore grezzu, è quella riferenza hè sottumessa à e stesse regule cum'è tutte l'altre referenze.
///
/// Questa macro pò creà un puntatore grezzu *senza* creà prima una riferenza.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` creerebbe un riferimentu micca alliniatu, è cusì seria Comportamentu indefinitu!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` forze chì copianu u campu invece di creà una riferenza.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}