use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Un involucru per inibisce u compilatore da chjamà automaticamente u distruttore di "T".
/// Questu involucru hè 0-cost.
///
/// `ManuallyDrop<T>` hè sottumessu à e stesse ottimisazione di layout cum'è `T`.
/// Di conseguenza, ùn hà *nisun effettu* nantu à l'ipotesi chì u compilatore face nantu à u so cuntenutu.
/// Per esempiu, inizializà un `ManuallyDrop<&mut T>` cù [`mem::zeroed`] hè un cumpurtamentu indefinitu.
/// Se avete bisognu di gestisce dati micca inizializati, utilizate invece [`MaybeUninit<T>`].
///
/// Innota chì accede à u valore in un `ManuallyDrop<T>` hè sicuru.
/// Ciò significa chì un `ManuallyDrop<T>` chì u so cuntenutu hè statu abbandunatu ùn deve esse espostu per mezu di una API pubblica sicura.
/// Currispundendu, `ManuallyDrop::drop` hè periculosu.
///
/// # `ManuallyDrop` è mandà ordine.
///
/// Rust hà un [drop order] ben definitu di valori.
/// Per assicurassi chì i campi o i lucali sianu abbandunati in un ordine specificu, riordine e dichjarazioni in modu chì l'ordine di goccia implicitu sia quellu currettu.
///
/// Hè pussibule aduprà `ManuallyDrop` per cuntrullà l'ordine di goccia, ma questu richiede un codice periculosu è hè difficiule da fà currettamente in presenza di svolgimentu.
///
///
/// Per esempiu, sè vulete assicurà chì un campu specificu sia abbandunatu dopu à l'altri, fate d'ellu l'ultimu campu di una struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` serà abbandunatu dopu `children`.
///     // Rust garantisce chì i campi sò abbandunati in l'ordine di dichjarazione.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Avvolge un valore da abbandunà manualmente.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Pudete ancu operà in modu sicuru in u valore
    /// assert_eq!(*x, "Hello");
    /// // Ma `Drop` ùn serà micca gestitu quì
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Estrae u valore da u contenitore `ManuallyDrop`.
    ///
    /// Questu permette chì u valore sia abbandunatu di novu.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Questu cadi u `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Piglia u valore da u contenitore `ManuallyDrop<T>`.
    ///
    /// Stu metudu hè principalmente destinatu à spustà i valori in goccia.
    /// Invece di aduprà [`ManuallyDrop::drop`] per abbandunà manualmente u valore, pudete aduprà stu metudu per piglià u valore è aduprà quantunque desideratu.
    ///
    /// Ogni volta chì hè pussibule, hè preferibile aduprà [`into_inner`][`ManuallyDrop::into_inner`] invece, chì impedisce di duplicà u cuntenutu di u `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Sta funzione sposta semanticamente u valore cuntenutu senza impedisce un ulteriore utilizzu, lascendu u statu di stu cuntainer immutatu.
    /// Hè a vostra responsabilità di assicurà chì questu `ManuallyDrop` ùn sia micca adupratu di novu.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SICUREZZA: lighjemu da una riferenza, chì hè garantita
        // esse validu per leghje.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Gocce manualmente u valore cuntenutu.Questu hè esattamente equivalente à chjamà [`ptr::drop_in_place`] cun un puntatore à u valore cuntenutu.
    /// Cume tale, a menu chì u valore contenutu sia una struttura imballata, u distruttore sarà chjamatu in locu senza spostà u valore, è pò esse adupratu per calà sicuramente i dati [pinned].
    ///
    /// Se avete a pruprietà di u valore, pudete aduprà [`ManuallyDrop::into_inner`] invece.
    ///
    /// # Safety
    ///
    /// Questa funzione gestisce u distruttore di u valore contenutu.
    /// Oltre à i cambiamenti fatti da u distruttore stessu, a memoria hè lasciata invariata, è per ciò chì tocca à u compilatore tene sempre un mudellu di bit chì hè validu per u tippu `T`.
    ///
    ///
    /// Tuttavia, stu valore "zombie" ùn deve esse espostu à un codice sicuru, è sta funzione ùn deve esse chjamata più di una volta.
    /// Aduprà un valore dopu chì hè statu abbandunatu, o abbandunà un valore parechje volte, pò causà Comportamentu Indefinitu (secondu ciò chì face `drop`).
    /// Questu hè normalmente impeditu da u sistema di tippu, ma l'utilizatori di `ManuallyDrop` devenu rispettà quelle garanzie senza l'assistenza di u compilatore.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SICUREZZA: stamu abbandunendu u valore indicatu da una riferenza mutevule
        // chì hè garantitu per esse validu per scrive.
        // Tocca à u chjamante per assicurassi chì `slot` ùn sia micca cascatu di novu.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}