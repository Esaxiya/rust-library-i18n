//! Funzioni di basa per trattà a memoria.
//!
//! Stu modulu cuntene funzioni per dumandà a dimensione è l'allinjamentu di i tippi, inizializendu è manipulendu a memoria.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Piglia a pruprietà è "forgets" circa u valore **senza esecutà u so distruttore**.
///
/// Ogni risorsa chì u valore gestisce, cume a memoria di cumuli o una maniglia di file, fermerà per sempre in un statu inaccessibile.Tuttavia, ùn garantisce micca chì l'indicatori di sta memoria resteranu validi.
///
/// * Se vulete filtrà memoria, vedi [`Box::leak`].
/// * Se vulete ottene un puntatore grezzu à a memoria, vedi [`Box::into_raw`].
/// * Se vulete dispunì di un valore currettamente, eseguendu u so distruttore, vedi [`mem::drop`].
///
/// # Safety
///
/// `forget` ùn hè micca marcatu cum'è `unsafe`, perchè e garanzie di sicurezza di Rust ùn includenu micca una garanzia chì i distruttori funzioneranu sempre.
/// Per esempiu, un prugramma pò creà un ciclu di riferimentu aduprendu [`Rc`][rc], o chjamà [`process::exit`][exit] per esce senza esecutà distruttori.
/// Cusì, permettendu `mem::forget` da un codice sicuru ùn cambia micca fundamentalmente e garanzie di sicurezza di Rust.
///
/// Dittu chistu, perde risorse cum'è memoria o oggetti I/O hè di solitu indesiderabile.
/// A necessità vene in certi casi d'usu specializati per FFI o codice periculosu, ma ancu allora, [`ManuallyDrop`] hè tipicamente preferitu.
///
/// Perchè scurdà un valore hè permessu, qualsiasi codice `unsafe` chì scrivite deve permettà sta pussibilità.Ùn pudete micca restituisce un valore è aspettate chì u chjamante eseguirà necessariamente u distruttore di u valore.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// L'utilizazione sicura canonica di `mem::forget` hè di circundà un distruttore di valore messu in opera da u `Drop` trait.Per esempiu, questu fugerà un `File`, ie
/// ricuperà u spaziu pigliatu da a variabile ma ùn chjude mai a risorsa di u sistema sottostante:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Questu hè utile quandu a pruprietà di a risorsa sottostante hè stata precedentemente trasferita in codice fora di Rust, per esempiu trasmettendu u descrittore di file grezzu in codice C.
///
/// # Relazione cù `ManuallyDrop`
///
/// Mentre `mem::forget` pò ancu esse adupratu per trasferisce *memoria* di pruprietà, fà cusì hè propensu à l'errore.
/// [`ManuallyDrop`] duveria esse adupratu invece.Cunsiderate, per esempiu, stu codice:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Custruisce un `String` cù u cuntenutu di `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // perdite `v` perchè a so memoria hè avà gestita da `s`
/// mem::forget(v);  // ERRORE, v hè invalidu è ùn deve esse passatu à una funzione
/// assert_eq!(s, "Az");
/// // `s` hè implicitamente abbandunatu è a so memoria hè dislocata.
/// ```
///
/// Ci hè dui prublemi cù l'esempiu di sopra:
///
/// * S'ellu si aghjunghjia più codice trà a custruzzione di `String` è l'invucazione di `mem::forget()`, un panic in ellu causerebbe un doppiu liberu perchè a stessa memoria hè trattata da `v` è `s`.
/// * Dopu avè chjamatu `v.as_mut_ptr()` è trasmessu a pruprietà di i dati à `s`, u valore `v` hè invalidu.
/// Ancu quandu un valore hè ghjustu spustatu in `mem::forget` (chì ùn l'ispettarà micca), certi tippi anu esigenze strette nantu à i so valori chì li rendenu invalidi quandu pendenu o ùn sò più pusseduti.
/// Aduprà valori invalidi in qualunque modu, cumprendu u passaghju o u ritornu da e funzioni, custituisce un cumpurtamentu indefinitu è pò rompe l'ipotesi fatte da u compilatore.
///
/// Passà à `ManuallyDrop` evita entrambi i prublemi:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Prima di smuntà `v` in i so pezzi grezzi, assicuratevi chì ùn sia micca cascatu!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Avà smuntate `v`.Queste operazioni ùn ponu micca panic, allora ùn ci pò esse una fuga.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Infine, custruisce un `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` hè implicitamente abbandunatu è a so memoria hè dislocata.
/// ```
///
/// `ManuallyDrop` impedisce in modu robustu u doppiu-liberu perchè disattivemu u distruttore `v` prima di fà nunda.
/// `mem::forget()` ùn la permette micca perchè cunsuma u so argumentu, ubligendu à chjamalla solu dopu avè estrattu tuttu ciò chì avemu bisognu da `v`.
/// Ancu se un panic hè statu introduttu trà a custruzzione di `ManuallyDrop` è a custruzzione di a stringa (chì ùn pò micca accade in u codice cum'è mostratu), resulterebbe in una fuga è micca una doppia libera.
/// In altre parolle, `ManuallyDrop` sbaglia da u latu di fughje invece di sbaglià da u latu di (doppia).
///
/// Inoltre, `ManuallyDrop` ci impedisce d'avè à "touch" `v` dopu u trasferimentu di a pruprietà à `s`-l'ultimu passu di interagisce cù `v` per disperse di ellu senza esecutà u so distruttore hè interamente evitatu.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Cum'è [`forget`], ma accetta ancu valori micca dimensionati.
///
/// Questa funzione hè solu una spina destinata à esse rimossa quandu a funzione `unsized_locals` si stabilizza.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Restituisce a dimensione di un tippu in bytes.
///
/// Più specificamente, questu hè u offset in byte trà elementi successivi in una matrice cù quellu tippu d'elemento cumprendu u padding di allineamentu.
///
/// Cusì, per qualsiasi tippu `T` è lunghezza `n`, `[T; n]` hà una dimensione di `n * size_of::<T>()`.
///
/// In generale, a dimensione di un tipu ùn hè micca stabile in tutte e compilazioni, ma tipi specifici cum'è primitivi sò.
///
/// A tavula seguente dà a dimensione per i primitivi.
///
/// Type |size_of: :\<Type>()
/// ---- | ---------------
/// () Œ œ0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Inoltre, `usize` è `isize` anu a listessa dimensione.
///
/// I tippi `*const T`, `&T`, `Box<T>`, `Option<&T>` è `Option<Box<T>>` anu tutti a stessa dimensione.
/// Se `T` hè Dimensione, tutti questi tipi anu a stessa dimensione cum'è `usize`.
///
/// A mutabilità di un puntatore ùn cambia micca a so dimensione.Cusì, `&T` è `&mut T` anu a listessa dimensione.
/// In listessu modu per `*const T` è `* mut T`.
///
/// # Dimensione di l'articuli `#[repr(C)]`
///
/// A rapprisintazione `C` per l'articuli hà un layout definitu.
/// Cù questu layout, a dimensione di l'articuli hè ancu stabile finchè tutti i campi anu una dimensione stabile.
///
/// ## Dimensione di Structs
///
/// Per `structs`, a dimensione hè determinata da l'algoritmu seguente.
///
/// Per ogni campu in a struttura ordinata per ordine di dichjarazione:
///
/// 1. Aghjunghjite a dimensione di u campu.
/// 2. Arrotonda a dimensione attuale à u multiplicu più vicinu di u prossimu campu [alignment].
///
/// Infine, arrotonda a dimensione di a struttura à u multiplu più vicinu di u so [alignment].
/// L'allineamentu di a struttura hè di solitu u più grande allineamentu di tutti i so campi;questu pò esse cambiatu cù l'usu di `repr(align(N))`.
///
/// A differenza di `C`, e strutture di dimensioni zero ùn sò micca arrotondate à una dimensione di un byte.
///
/// ## Dimensione di Enumi
///
/// L'enumeri chì ùn portanu micca dati altru chì u discriminante anu a stessa dimensione cum'è C enum in a piattaforma per a quale sò compilati.
///
/// ## Dimensione di l'Unioni
///
/// A dimensione di un sindicatu hè a dimensione di u so campu più grande.
///
/// A differenza di `C`, i sindicati di dimensione zero ùn sò micca arrotondati à una dimensione di un byte.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Alcuni primitivi
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Alcune matrici
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Uguaglianza di a dimensione di u puntatore
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Aduprendu `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // A dimensione di u primu campu hè 1, allora aghjunghje 1 à a dimensione.A dimensione hè 1.
/// // L'allineamentu di u secondu campu hè 2, allora aghjunghje 1 à a taglia per imbottitura.A dimensione hè 2.
/// // A dimensione di u secondu campu hè 2, allora aghjunghje 2 à a dimensione.A dimensione hè 4.
/// // L'alineamentu di u terzu campu hè 1, allora aghjunghje 0 à a taglia per imbottitura.A dimensione hè 4.
/// // A dimensione di u terzu campu hè 1, allora aghjunghje 1 à a dimensione.A dimensione hè 5.
/// // Infine, l'allineamentu di a struttura hè 2 (perchè l'alineamentu più grande trà i so campi hè 2), allora aghjunghjite 1 à a dimensione per u padding.
/// // A dimensione hè 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Strutture di tupla seguenu e stesse regule.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Nutate bè chì a riurdinazione di i campi pò calà a taglia.
/// // Pudemu eliminà i dui bytes di padding mettendu `third` prima di `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // A dimensione di l'Unione hè a dimensione di u campu più grande.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Restituisce a dimensione di u valore puntatu in byte.
///
/// Questu hè di solitu u listessu cum'è `size_of::<T>()`.
/// Tuttavia, quandu `T`*ùn hà* alcuna dimensione staticamente cunnisciuta, per esempiu, una fetta [`[T]`][slice] o un [trait object], allora `size_of_val` pò esse adupratu per uttene a dimensione dinamicamente cunnisciuta.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SICUREZZA: `val` hè una riferenza, dunque hè un puntatore grezzu validu
    unsafe { intrinsics::size_of_val(val) }
}

/// Restituisce a dimensione di u valore puntatu in byte.
///
/// Questu hè di solitu u listessu cum'è `size_of::<T>()`.Tuttavia, quandu `T`*ùn hà* alcuna dimensione staticamente cunnisciuta, per esempiu, una fetta [`[T]`][slice] o un [trait object], allora `size_of_val_raw` pò esse adupratu per uttene a dimensione dinamicamente cunnisciuta.
///
/// # Safety
///
/// Questa funzione hè sicura da chjamà solu se e seguenti condizioni valenu:
///
/// - Se `T` hè `Sized`, sta funzione hè sempre sicura di chjamà.
/// - Se a coda senza dimensioni di `T` hè:
///     - un [slice], allora a lunghezza di a coda di fetta deve esse un interu inizializatu, è a dimensione di u *valore interu*(lunghezza di coda dinamica + prefissu di dimensione statica) deve adattassi in `isize`.
///     - un [trait object], allora a parte vtable di u puntatore deve puntà à una vtable valida acquistata da una coercizione di dimensione, è a dimensione di u *valore interu*(lunghezza di coda dinamica + prefissu di dimensione statica) deve adattassi in `isize`.
///
///     - un (unstable) [extern type], allora sta funzione hè sempre sicura da chjamà, ma pò panic o altrimente restituisce u valore sbagliatu, postu chì u layout di u tippu esternu ùn hè micca cunnisciutu.
///     Questu hè u listessu comportamentu cum'è [`size_of_val`] per una riferenza à un tippu cù una coda di tippu esternu.
///     - altrimenti, hè cunservativu micca permessu di chjamà sta funzione.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SICUREZZA: u chjamante deve furnisce un puntatore grezzu validu
    unsafe { intrinsics::size_of_val(val) }
}

/// Restituisce u [ABI]-allineamentu minimu necessariu di un tippu.
///
/// Ogni riferenza à un valore di u tippu `T` deve esse un multiplu di questu numeru.
///
/// Questu hè l'allineamentu adupratu per i campi struct.Pò esse più chjucu cà l'allinjamentu preferitu.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Restituisce u [ABI]-allineamentu minimu necessariu di u tippu di u valore chì `val` punta.
///
/// Ogni riferenza à un valore di u tippu `T` deve esse un multiplu di questu numeru.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SICUREZZA: val hè una riferenza, dunque hè un puntatore grezzu validu
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Restituisce u [ABI]-allineamentu minimu necessariu di un tippu.
///
/// Ogni riferenza à un valore di u tippu `T` deve esse un multiplu di questu numeru.
///
/// Questu hè l'allineamentu adupratu per i campi struct.Pò esse più chjucu cà l'allinjamentu preferitu.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Restituisce u [ABI]-allineamentu minimu necessariu di u tippu di u valore chì `val` punta.
///
/// Ogni riferenza à un valore di u tippu `T` deve esse un multiplu di questu numeru.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SICUREZZA: val hè una riferenza, dunque hè un puntatore grezzu validu
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Restituisce u [ABI]-allineamentu minimu necessariu di u tippu di u valore chì `val` punta.
///
/// Ogni riferenza à un valore di u tippu `T` deve esse un multiplu di questu numeru.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Questa funzione hè sicura da chjamà solu se e seguenti condizioni valenu:
///
/// - Se `T` hè `Sized`, sta funzione hè sempre sicura di chjamà.
/// - Se a coda senza dimensioni di `T` hè:
///     - un [slice], allora a lunghezza di a coda di fetta deve esse un interu inizializatu, è a dimensione di u *valore interu*(lunghezza di coda dinamica + prefissu di dimensione statica) deve adattassi in `isize`.
///     - un [trait object], allora a parte vtable di u puntatore deve puntà à una vtable valida acquistata da una coercizione di dimensione, è a dimensione di u *valore interu*(lunghezza di coda dinamica + prefissu di dimensione statica) deve adattassi in `isize`.
///
///     - un (unstable) [extern type], allora sta funzione hè sempre sicura da chjamà, ma pò panic o altrimente restituisce u valore sbagliatu, postu chì u layout di u tippu esternu ùn hè micca cunnisciutu.
///     Questu hè u listessu comportamentu cum'è [`align_of_val`] per una riferenza à un tippu cù una coda di tippu esternu.
///     - altrimenti, hè cunservativu micca permessu di chjamà sta funzione.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SICUREZZA: u chjamante deve furnisce un puntatore grezzu validu
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Restituisce `true` se vale i valori di tipu `T`.
///
/// Questu hè puramente un suggerimentu di ottimisazione, è pò esse implementatu cun prudenza:
/// pò restituisce `true` per tippi chì ùn anu micca daveru esse abbandunati.
/// Cume sempre u ritornu `true` seria una implementazione valida di sta funzione.Tuttavia, se sta funzione rende effettivamente `false`, allora pudete esse sicuru chì a caduta di `T` ùn hà micca effetti collaterali.
///
/// Implementazioni di livellu bassu di cose cum'è e cullezzione, chì anu bisognu di abbandunà manualmente i so dati, devenu aduprà sta funzione per evità di pruvà inutilmente di abbandunà tuttu u so cuntenutu quandu sò distrutti.
///
/// Questu puderia micca fà una differenza in e versioni di liberazione (induve un loop chì ùn hà micca effetti collaterali hè facilmente rilevatu è eliminatu), ma hè spessu una grande vittoria per e costruzioni di debug.
///
/// Nota chì [`drop_in_place`] esegue dighjà stu cuntrollu, allora se u vostru caricu di travagliu pò esse riduttu à un pocu numeru di chiamate [`drop_in_place`], aduprà questu ùn hè micca necessariu.
/// In particulare nutate chì pudete [`drop_in_place`] una fetta, è chì farà una sola verifica need_drop per tutti i valori.
///
/// Tipi cum'è Vec dunque solu `drop_in_place(&mut self[..])` senza aduprà `needs_drop` esplicitamente.
/// Tipi cum'è [`HashMap`], invece, devenu abbandunà i valori unu à a volta è devenu aduprà sta API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Eccu un esempiu di cume una raccolta puderia fà usu di `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // falà i dati
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Restituisce u valore di u tippu `T` rappresentatu da u mudellu di byte all-zero.
///
/// Questu significa chì, per esempiu, u byte di padding in `(u8, u16)` ùn hè micca necessariamente messu à zero.
///
/// Ùn ci hè garanzia chì un mudellu di byte all-zero riprisenta un valore validu di qualchì tippu `T`.
/// Per esempiu, u mudellu di byte all-zero ùn hè micca un valore validu per i tippi di riferimentu (`&T`, `&mut T`) è i puntatori di funzioni.
/// Aduprà `zeroed` nantu à tali tippi provoca [undefined behavior][ub] immediata perchè [the Rust compiler assumes][inv] chì ci hè sempre un valore validu in una variabile chì si considera inizializata.
///
///
/// Questu hà u listessu effettu cum'è [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Hè utile per FFI à volte, ma deve generalmente esse evitatu.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Utilizazione curretta di sta funzione: inizializazione di un numeru interu cù zeru.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Usu incorrettu* di sta funzione: inizializazione di una rifarenza cù zeru.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Cumportamentu indefinitu!
/// let _y: fn() = unsafe { mem::zeroed() }; // È dinò!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SICUREZZA: u chjamante deve garantisce chì un valore tuttu zero hè validu per `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Ignora i cuntrolli normali di inizializazione di memoria di Rust fingendu di pruduce un valore di tippu `T`, senza fà nunda.
///
/// **Sta funzione hè obsoleta.** Aduprate invece [`MaybeUninit<T>`].
///
/// A ragione di a deprecazione hè chì a funzione in fondu ùn pò micca esse usata currettamente: hà u listessu effettu cum'è [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Cum'è [`assume_init` documentation][assume_init] spiega, [the Rust compiler assumes][inv] chì i valori sò inizializzati currettamente.
/// Di cunsiguenza, chjamà per esempiu
/// `mem::uninitialized::<bool>()` provoca un cumpurtamentu indefinitu immediatu per u ritornu di un `bool` chì ùn hè micca sicuramente nè `true` nè `false`.
/// Peggiu, memoria veramente non inizializzata cum'è ciò chì si restituisce quì hè speciale in quantu u compilatore sà chì ùn hà micca un valore fissu.
/// Questu face un comportamentu indefinitu di avè dati micca inizializati in una variabile ancu se quella variabile hà un tipu interu.
/// (Notate chì e regule intornu à i numeri interi micca inizializati ùn sò ancu finalizate, ma finu à esse, hè consigliabile evitàle.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SICUREZZA: u chjamante deve garantisce chì un valore unitariu sia validu per `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Scambia i valori in dui lochi mutevuli, senza deinizializà nè unu.
///
/// * Se vulete scambià cù un valore predefinitu o fittiziu, vedi [`take`].
/// * Se vulete scambià cù un valore passatu, restituendu u vechju valore, vedi [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SICUREZZA: i puntatori crudi sò stati creati da referenze mutevule sicure chì soddisfanu tutte e
    // limitazioni annantu à `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Sostituisce `dest` cù u valore predefinitu di `T`, restituendu u valore `dest` precedente.
///
/// * Se vulete rimpiazzà i valori di duie variabili, vedi [`swap`].
/// * Se vulete rimpiazzà cù un valore passatu invece di u valore predefinitu, vedi [`replace`].
///
/// # Examples
///
/// Un esempiu simplice:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` permette di piglià a pruprietà di un campu struct rimpiazzendulu cun un valore "empty".
/// Senza `take` pudete scuntrà in prublemi cum'è questi:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Innota chì `T` ùn implementa micca necessariamente [`Clone`], dunque ùn pò mancu clonà è resettà `self.buf`.
/// Ma `take` pò esse adupratu per disassocià u valore originale di `self.buf` da `self`, permettendu ch'ellu sia restituitu:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Sposta `src` in u `dest` riferitu, restituendu u valore `dest` precedente.
///
/// Nè u valore hè cascatu.
///
/// * Se vulete rimpiazzà i valori di duie variabili, vedi [`swap`].
/// * Se vulete rimpiazzà cù un valore predefinitu, vedi [`take`].
///
/// # Examples
///
/// Un esempiu simplice:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` permette a cunsumazione di un campu struct rimpiazzendulu cù un altru valore.
/// Senza `replace` pudete scuntrà in prublemi cum'è questi:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Innota chì `T` ùn implementa micca necessariamente [`Clone`], allora ùn pudemu mancu clonà `self.buf[i]` per evità u muvimentu.
/// Ma `replace` pò esse adupratu per disassocià u valore originale in quellu indice da `self`, permettendu ch'ellu sia restituitu:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SICUREZZA: Avemu lettu da `dest` ma scrivemu direttamente `src` in questu dopu,
    // tale chì u vechju valore ùn hè micca duplicatu.
    // Nunda ùn hè cascatu è nunda quì pò panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Dispone di un valore.
///
/// Questu face chjamendu l'implementazione di l'argumentu di [`Drop`][drop].
///
/// Questu ùn face nunda per i tippi chì implementanu `Copy`, per esempiu
/// integers.
/// Tali valori sò cupiati è _then_ spustatu in a funzione, cusì u valore persiste dopu à sta chjamata di funzione.
///
///
/// Sta funzione ùn hè micca magia;hè literale definitu cum'è
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Perchè `_x` hè trasferitu in a funzione, hè automaticamente abbandunatu prima chì a funzione ritorna.
///
/// [drop]: Drop
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // abbandunà esplicitamente u vector
/// ```
///
/// Dapoi [`RefCell`] impone e regule di prestitu in runtime, `drop` pò liberà un prestitu [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // rinuncià à l'imprestà mutevule in questu slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Numeri interi è altri tippi chì implementanu [`Copy`] ùn sò micca influenzati da `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // una copia di `x` hè sposta è lasciata
/// drop(y); // una copia di `y` hè sposta è lasciata
///
/// println!("x: {}, y: {}", x, y.0); // sempre dispunibule
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpreta `src` cum'è tippu `&U`, è dopu leghje `src` senza move u valore cuntenutu.
///
/// Questa funzione assumerà in modu sicuru chì u puntatore `src` hè validu per [`size_of::<U>`][size_of] bytes trasmutendu `&T` à `&U` è dopu lighjendu u `&U` (eccettu chì questu hè fattu in un modu chì hè currettu ancu quandu `&U` rende esigenze di allineamentu più strette di `&T`).
/// Crearà ancu in modu sicuru una copia di u valore cuntenutu invece di spustassi fora di `src`.
///
/// Ùn hè micca un errore di compilazione se `T` è `U` anu dimensioni diverse, ma hè assai incuragitu à invucà solu sta funzione induve `T` è `U` anu a stessa dimensione.Sta funzione attiva [undefined behavior][ub] se `U` hè più grande di `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Copia i dati da 'foo_array' è trattatelu cum'è 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Mudificà i dati copiati
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // U cuntenutu di 'foo_array' ùn duveria micca esse cambiatu
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Se U hà un requisitu d'alineamentu più altu, src pò esse micca alliniatu adeguatamente.
    if align_of::<U>() > align_of::<T>() {
        // SICUREZZA: `src` hè una riferenza chì hè garantita per esse valida per leghje.
        // U chjamante deve garantisce chì a trasmutazione vera sia sicura.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SICUREZZA: `src` hè una riferenza chì hè garantita per esse valida per leghje.
        // Avemu ghjustu verificatu chì `src as *const U` sia statu alliniatu currettamente.
        // U chjamante deve garantisce chì a trasmutazione vera sia sicura.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Tipu opacu chì rapprisenta u discriminante di un enum.
///
/// Vede a funzione [`discriminant`] in questu modulu per più infurmazione.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Queste implementazioni trait ùn ponu micca esse derivate perchè ùn vulemu micca limiti per T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Restituisce un valore identificendu unicamente a variante enum in `v`.
///
/// Se `T` ùn hè micca un enum, chjamà sta funzione ùn resulterà micca in cumpurtamentu indefinitu, ma u valore di ritornu ùn hè micca specificatu.
///
///
/// # Stability
///
/// U discriminante di una variante enum pò cambià se a definizione enum cambia.
/// Un discriminante di qualchì variante ùn cambierà trà e compilazioni cù u listessu compilatore.
///
/// # Examples
///
/// Questu pò esse adupratu per paragunà enumi chì portanu dati, ignorendu i dati reali:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Restituisce u numeru di varianti in u tippu enum `T`.
///
/// Se `T` ùn hè micca un enum, chjamà sta funzione ùn resulterà micca in cumpurtamentu indefinitu, ma u valore di ritornu ùn hè micca specificatu.
/// Altrettantu, se `T` hè un enum cù più varianti cà `usize::MAX` u valore di ritornu ùn hè micca specificatu.
/// E varianti disabitate saranu contate.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}