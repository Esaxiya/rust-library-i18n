use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Un tippu di involucru per custruisce istanze non inizializate di `T`.
///
/// # Invariante d'inizializazione
///
/// U compilatore, in generale, assume chì una variabile hè inizializata currettamente secondu i requisiti di u tippu di a variabile.Per esempiu, una variabile di tipu di riferimentu deve esse allineata è non NULL.
/// Questu hè un invariante chì deve *sempre* esse accoltu, ancu in codice periculosu.
/// Di conseguenza, l'inizializazione zero di una variabile di tippu di riferenza provoca [undefined behavior][ub] istantanea, ùn importa micca sì quella riferenza sia abituata per accede à a memoria:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // cumpurtamentu indefinitu!⚠️
/// // U codice equivalente cù `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // cumpurtamentu indefinitu!⚠️
/// ```
///
/// Questu hè sfruttatu da u compilatore per varie ottimizazioni, cume l'elezzione di i cuntrolli di runtime è l'ottimizazione di u layout `enum`.
///
/// Similmente, a memoria interamente micca inizializata pò avè qualchì cuntenutu, mentre un `bool` deve sempre esse `true` o `false`.Dunque, a creazione di un `bool` non inizializatu hè un comportamentu indefinitu:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // cumpurtamentu indefinitu!⚠️
/// // U codice equivalente cù `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // cumpurtamentu indefinitu!⚠️
/// ```
///
/// Inoltre, a memoria uninitializzata hè speciale in quantu ùn hà micca un valore fissu ("fixed" chì significa "it won't change without being written to").Leghje u listessu byte non inizializatu parechje volte pò dà risultati diversi.
/// Questu face un comportamentu indefinitu di avè dati micca inizializati in una variabile ancu se quella variabile hà un tippu interu, chì altrimenti pò tene qualsiasi mudellu di bit *fissu*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // cumpurtamentu indefinitu!⚠️
/// // U codice equivalente cù `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // cumpurtamentu indefinitu!⚠️
/// ```
/// (Notate chì e regule intornu à i numeri interi micca inizializati ùn sò ancu finalizate, ma finu à esse, hè consigliabile evitàle.)
///
/// In più di questu, ricordate chì a maiò parte di i tipi anu invarianti supplementari al di là di solu esse cunsiderati inizializati à u livellu di tippu.
/// Per esempiu, un "1" inizializatu [`Vec<T>`] hè cunsideratu inizializatu (sottu l'implementazione attuale; questu ùn custituisce micca una garanzia stabile) perchè l'unicu requisitu chì u compilatore ne cunnosce hè chì u puntatore di dati ùn deve esse nulu.
/// A creazione di un tale `Vec<T>` ùn provoca micca un comportamentu *immediatu* indefinitu, ma pruvucarà un cumpurtamentu indefinitu cù a maiò parte di l'operazioni sicure (cumpresu a cascata).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` serve per attivà un codice periculosu per trattà di dati micca inizializati.
/// Hè un signale à u compilatore chì indica chì i dati quì ponu *micca* esse inizializzati:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Crea un riferimentu esplicitamente micca inizializatu.
/// // U compilatore sà chì i dati in un `MaybeUninit<T>` ponu esse invalidi, è dunque questu ùn hè micca UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Piazzà à un valore validu.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Estrae i dati inizializati-questu hè permessu solu *dopu* inizializà currettamente `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// U compilatore sà tandu di ùn fà alcuna supposizione o ottimisazione sbagliate nantu à stu codice.
///
/// Pudete pensà à `MaybeUninit<T>` cum'è un pocu cum'è `Option<T>` ma senza alcun tracciamentu in esecuzione è senza alcunu cuntrolli di sicurezza.
///
/// ## out-pointers
///
/// Pudete aduprà `MaybeUninit<T>` per implementà "out-pointers": invece di restituisce dati da una funzione, passatelu un puntatore à qualchì memoria (uninitialized) per mette u risultatu in.
/// Questu pò esse utile quandu hè impurtante per u chjamante di cuntrullà cumu si alloca a memoria in cui u risultatu hè conservatu, è vulete evità movimenti inutili.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ùn lascia micca cascà u vechju cuntenutu, ciò chì hè impurtante.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Avà sapemu chì `v` hè inizializatu!Questu hè ancu sicuru chì u vector hè cacciatu currettamente.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inizializazione di un array elementu per elementu
///
/// `MaybeUninit<T>` pò esse adupratu per inizializà una grande matrice elementu per elementu:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Creà un array micca inizializatu di `MaybeUninit`.
///     // U `assume_init` hè sicuru perchè u tippu chì dichjaremu d'avè inizializatu quì hè una mansa di `MaybeUninit`s, chì ùn necessitanu micca inizializazione.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Trascendere un `MaybeUninit` ùn face nunda.
///     // Cusì l'usu di l'assignazione di puntatore grezzu invece di `ptr::write` ùn face micca fà cascà u vechju valore micca inizializatu.
/////
///     // Inoltre s'ellu ci hè un panic durante stu ciclu, avemu una perdita di memoria, ma ùn ci hè micca prublema di sicurezza in memoria.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Tuttu hè inizializatu.
///     // Trasmutate l'array à u tipu inizializatu.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Pudete ancu travaglià cù matrici parzialmente inizializati, chì si puderianu truvà in strutture di dati di livellu bassu.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Creà un array micca inizializatu di `MaybeUninit`.
/// // U `assume_init` hè sicuru perchè u tippu chì dichjaremu d'avè inizializatu quì hè una mansa di `MaybeUninit`s, chì ùn necessitanu micca inizializazione.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Cuntate u numeru di elementi chì avemu assignatu.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Per ogni articulu in u array, lasciate se l'avemu assignatu.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inizializazione di una struttura campu per campu
///
/// Pudete aduprà `MaybeUninit<T>`, è a macro [`std::ptr::addr_of_mut`], per inizializà e strutture campu per campu:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inizializazione di u campu `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inizializazione di u campu `list` Se ci hè un panic quì, allora u `String` in u campu `name` perde.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Tutti i campi sò inizializati, cusì chjamemu `assume_init` per uttene un Foo inizializatu.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` hè garantitu per avè a stessa dimensione, allineamentu è ABI cum'è `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Tuttavia arricurdatevi chì un tippu *chì cuntene* un `MaybeUninit<T>` ùn hè micca necessariamente u listessu schema;Rust ùn garantisce micca in generale chì i campi di un `Foo<T>` anu u listessu ordine cum'è un `Foo<U>` ancu se `T` è `U` anu a stessa dimensione è allineamentu.
///
/// Inoltre perchè qualsiasi valore di bit hè validu per un `MaybeUninit<T>` u compilatore ùn pò micca applicà ottimisazioni non-zero/niche-filling, pudendu risultà in una dimensione più grande:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Se `T` hè FFI-safe, allora cusì hè `MaybeUninit<T>`.
///
/// Mentre `MaybeUninit` hè `#[repr(transparent)]` (indicendu chì garantisce a stessa dimensione, allineamentu è ABI cum'è `T`), questu ùn *cambia* alcuna di e caveat precedenti.
/// `Option<T>` è `Option<MaybeUninit<T>>` pò avè sempre dimensioni diverse, è i tippi chì cuntenenu un campu di tippu `T` ponu esse disposti (è dimensionati) in modu diversu chè se quellu campu fussi `MaybeUninit<T>`.
/// `MaybeUninit` hè un tipu di sindicatu, è `#[repr(transparent)]` nantu à i sindicati hè instabile (vede [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Cù u tempu, e garanzie esatte di `#[repr(transparent)]` nantu à i sindicati ponu evoluzione, è `MaybeUninit` pò rimanere `#[repr(transparent)]` o micca.
/// Dice questu, `MaybeUninit<T>`*sempre* garantirà chì hà a stessa dimensione, allineamentu è ABI cum'è `T`;hè solu chì u modu `MaybeUninit` mette in opera quella garanzia pò evoluzione.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Articulu Lang per pudè avvolgelu altri tippi.Questu hè utile per i generatori.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ùn chjamemu `T::clone()`, ùn pudemu micca sapè se simu inizializzati abbastanza per quessa.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Crea un novu `MaybeUninit<T>` inizializatu cù u valore datu.
    /// Hè sicuru di chjamà [`assume_init`] nantu à u valore di ritornu di sta funzione.
    ///
    /// Innota chì calà un `MaybeUninit<T>` ùn chjamerà mai u codice di goccia di `T`.
    /// Hè a vostra responsabilità di assicurà chì `T` sia cascatu s'ellu hè statu inizializatu.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Crea un novu `MaybeUninit<T>` in un statu micca inizializatu.
    ///
    /// Innota chì calà un `MaybeUninit<T>` ùn chjamerà mai u codice di goccia di `T`.
    /// Hè a vostra responsabilità di assicurà chì `T` sia cascatu s'ellu hè statu inizializatu.
    ///
    /// Vede u [type-level documentation][MaybeUninit] per alcuni esempi.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Crea un novu array di elementi `MaybeUninit<T>`, in un statu micca inizializatu.
    ///
    /// Note: in una versione future Rust stu metudu pò diventà micca necessariu quandu a sintassi letterale di array permette [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// L'esempiu quì sottu puderia allora aduprà `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Restituisce una fetta (forse più chjuca) di dati chì hè stata in realtà letta
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SICUREZZA: Un `[MaybeUninit<_>; LEN]` micca inizializatu hè validu.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Crea un novu `MaybeUninit<T>` in un statu micca inizializatu, cù a memoria chì hè piena di byte `0`.Dipende da `T` sì chì dighjà faci una inizializazione curretta.
    ///
    /// Per esempiu, `MaybeUninit<usize>::zeroed()` hè inizializatu, ma `MaybeUninit<&'static i32>::zeroed()` ùn hè micca perchè e referenze ùn devenu esse nule.
    ///
    /// Innota chì calà un `MaybeUninit<T>` ùn chjamerà mai u codice di goccia di `T`.
    /// Hè a vostra responsabilità di assicurà chì `T` sia cascatu s'ellu hè statu inizializatu.
    ///
    /// # Example
    ///
    /// Usu currettu di sta funzione: inizializazione di una struct à zeru, induve tutti i campi di a struct ponu tene u bit-pattern 0 cum'è un valore validu.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Usu incorrettu* di sta funzione: chjamà `x.zeroed().assume_init()` quandu `0` ùn hè micca un mudellu di bit validu per u tippu:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Dentru una coppia, creemu un `NotZero` chì ùn hà micca un discriminante validu.
    /// // Questu hè un cumpurtamentu indefinitu.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SICUREZZA: `u.as_mut_ptr()` punta à a memoria assignata.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Imposta u valore di u `MaybeUninit<T>`.
    /// Questu rimpiazzà qualsiasi valore precedente senza abbandunallu, allora fate attenzione à ùn aduprà micca duie volte, a menu chì ùn vulete saltà in esecuzione u distruttore.
    ///
    /// Per a vostra cunvenzione, questu torna ancu una riferenza mutabile à u cuntenutu (avà inizializatu in modu sicuru) di `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SICUREZZA: Avemu ghjustu inizializatu stu valore.
        unsafe { self.assume_init_mut() }
    }

    /// Ottiene un puntatore per u valore contenutu.
    /// Leghje da stu puntatore o trasfurmallu in una riferenza hè un cumpurtamentu indefinitu à menu chì u `MaybeUninit<T>` sia inizializatu.
    /// Scrivendu in memoria chì questu puntatore (non-transitively) punta hè un cumpurtamentu indefinitu (eccettu in un `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Utilizazione curretta di stu metudu:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Crea una riferenza in u `MaybeUninit<T>`.Questu va bè perchè l'avemu inizializatu.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Ughjettu incorrettu* di stu metudu:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Avemu creatu una riferenza à un vector non inizializatu!Questu hè un cumpurtamentu indefinitu.⚠️
    /// ```
    ///
    /// (Notate chì e regule intornu à e referenze à i dati micca inizializati ùn sò ancu finalizate, ma finu à esse, hè consigliabile evitàle.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` è `ManuallyDrop` sò tramindui `repr(transparent)` cusì pudemu lancià u puntatore.
        self as *const _ as *const T
    }

    /// Ottiene un puntatore mutabile al valore contenuto.
    /// Leghje da stu puntatore o trasfurmallu in una riferenza hè un cumpurtamentu indefinitu à menu chì u `MaybeUninit<T>` sia inizializatu.
    ///
    /// # Examples
    ///
    /// Utilizazione curretta di stu metudu:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Crea una riferenza in u `MaybeUninit<Vec<u32>>`.
    /// // Questu va bè perchè l'avemu inizializatu.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Ughjettu incorrettu* di stu metudu:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Avemu creatu una riferenza à un vector non inizializatu!Questu hè un cumpurtamentu indefinitu.⚠️
    /// ```
    ///
    /// (Notate chì e regule intornu à e referenze à i dati micca inizializati ùn sò ancu finalizate, ma finu à esse, hè consigliabile evitàle.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` è `ManuallyDrop` sò tramindui `repr(transparent)` cusì pudemu lancià u puntatore.
        self as *mut _ as *mut T
    }

    /// Estrae u valore da u contenitore `MaybeUninit<T>`.Questu hè un ottimu modu per assicurà chì i dati saranu abbandunati, perchè u `T` resultante hè sottumessu à u solitu trattamentu di gocce.
    ///
    /// # Safety
    ///
    /// Tocca à u chjamante di garantisce chì u `MaybeUninit<T>` sia veramente in un statu inizializatu.Chjamà questu quandu u cuntenutu ùn hè ancu cumpletamente inizializatu provoca un cumpurtamentu indefinitu immediatu.
    /// U [type-level documentation][inv] cuntene più infurmazioni nantu à st'invariante di inizializazione.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// In più di questu, ricordate chì a maiò parte di i tipi anu invarianti supplementari al di là di solu esse cunsiderati inizializati à u livellu di tippu.
    /// Per esempiu, un "1" inizializatu [`Vec<T>`] hè cunsideratu inizializatu (sottu l'implementazione attuale; questu ùn custituisce micca una garanzia stabile) perchè l'unicu requisitu chì u compilatore ne cunnosce hè chì u puntatore di dati ùn deve esse nulu.
    ///
    /// A creazione di un tale `Vec<T>` ùn provoca micca un comportamentu *immediatu* indefinitu, ma pruvucarà un cumpurtamentu indefinitu cù a maiò parte di l'operazioni sicure (cumpresu a cascata).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Utilizazione curretta di stu metudu:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Ughjettu incorrettu* di stu metudu:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ùn era ancu statu inizializatu, allora st'ultima linea hà causatu cumpurtamentu indefinitu.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SEGURITÀ: u chjamante deve garantisce chì `self` sia inizializatu.
        // Questu significa ancu chì `self` deve esse una variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Leghje u valore da u contenitore `MaybeUninit<T>`.U `T` resultante hè sottumessu à u solitu trattamentu di gocce.
    ///
    /// Ogni volta chì hè pussibule, hè preferibile aduprà [`assume_init`] invece, chì impedisce di duplicà u cuntenutu di u `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Tocca à u chjamante di garantisce chì u `MaybeUninit<T>` sia veramente in un statu inizializatu.Chjamà questu quandu u cuntenutu ùn hè ancu cumpletamente inizializatu provoca un comportamentu indefinitu.
    /// U [type-level documentation][inv] cuntene più infurmazioni nantu à st'invariante di inizializazione.
    ///
    /// Inoltre, questu lascia una copia di i stessi dati in u `MaybeUninit<T>`.
    /// Quandu si utilizanu più copie di i dati (chjamendu `assume_init_read` più volte, o chjamendu prima `assume_init_read` è dopu [`assume_init`]), hè a vostra responsabilità di assicurà chì i dati possinu esse duppiati.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Utilizazione curretta di stu metudu:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` hè `Copy`, allora pudemu leghje parechje volte.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplicà un valore `None` va bè, allora pudemu leghje parechje volte.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Ughjettu incorrettu* di stu metudu:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Avemu creatu avà duie copie di u listessu vector, purtendu à un double️ doppiu libaru quandu tramindui sò cascati!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SEGURITÀ: u chjamante deve garantisce chì `self` sia inizializatu.
        // A lettura da `self.as_ptr()` hè sicura postu chì `self` deve esse inizializatu.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Gocce u valore cuntenutu in locu.
    ///
    /// Se avete a pruprietà di u `MaybeUninit`, pudete aduprà [`assume_init`] invece.
    ///
    /// # Safety
    ///
    /// Tocca à u chjamante di garantisce chì u `MaybeUninit<T>` sia veramente in un statu inizializatu.Chjamà questu quandu u cuntenutu ùn hè ancu cumpletamente inizializatu provoca un comportamentu indefinitu.
    ///
    /// In più di quessa, tutti l'invarianti addiziunali di u tippu `T` devenu esse suddisfatti, postu chì l'implementazione `Drop` di `T` (o di i so membri) pò contà nantu à questu.
    /// Per esempiu, un "1" inizializatu [`Vec<T>`] hè cunsideratu inizializatu (sottu l'implementazione attuale; questu ùn custituisce micca una garanzia stabile) perchè l'unicu requisitu chì u compilatore ne cunnosce hè chì u puntatore di dati ùn deve esse nulu.
    ///
    /// A caduta di un tale `Vec<T>` causerà cumportamentu indefinitu.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SEGURITÀ: u chjamante deve garantisce chì `self` sia inizializatu è
        // soddisfa tutti l'invarianti di `T`.
        // Lascià u valore in locu hè sicuru se hè u casu.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Ottiene una riferenza cumuna à u valore contenutu.
    ///
    /// Questu pò esse utile quandu vulemu accede à un `MaybeUninit` chì hè statu inizializatu ma ùn hà micca a pruprietà di u `MaybeUninit` (impedendu l'usu di `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Chjamà questu quandu u cuntenutu ùn hè ancu cumpletamente inizializatu provoca un comportamentu indefinitu: tocca à u chjamante di garantisce chì u `MaybeUninit<T>` sia veramente in un statu inizializatu.
    ///
    ///
    /// # Examples
    ///
    /// ### Utilizazione curretta di stu metudu:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialize `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Avà chì u nostru `MaybeUninit<_>` hè cunnisciutu per esse inizializatu, hè bè di creà una riferenza cumuna à questu:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SICUREZZA: `x` hè statu inizializatu.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Usi *incorretti* di stu metudu:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Avemu creatu una riferenza à un vector non inizializatu!Questu hè un cumpurtamentu indefinitu.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inizializà u `MaybeUninit` cù `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Riferimentu à un `Cell<bool>` non inizializatu: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SEGURITÀ: u chjamante deve garantisce chì `self` sia inizializatu.
        // Questu significa ancu chì `self` deve esse una variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Ottiene una riferenza (unique) mutabile à u valore contenutu.
    ///
    /// Questu pò esse utile quandu vulemu accede à un `MaybeUninit` chì hè statu inizializatu ma ùn hà micca a pruprietà di u `MaybeUninit` (impedendu l'usu di `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Chjamà questu quandu u cuntenutu ùn hè ancu cumpletamente inizializatu provoca un comportamentu indefinitu: tocca à u chjamante di garantisce chì u `MaybeUninit<T>` sia veramente in un statu inizializatu.
    /// Per esempiu, `.assume_init_mut()` ùn pò micca esse adupratu per inizializà un `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Utilizazione curretta di stu metudu:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inizializza *tutti* i byte di u buffer di ingressu.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initialize `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Avà sapemu chì `buf` hè statu inizializatu, cusì pudemu `.assume_init()` lu.
    /// // Tuttavia, aduprà `.assume_init()` pò scatenà un `memcpy` di i 2048 byte.
    /// // Per affirmà chì u nostru buffer hè statu inizializatu senza copià, aghjurnemu u `&mut MaybeUninit<[u8; 2048]>` à un `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SICUREZZA: `buf` hè statu inizializatu.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Ora pudemu aduprà `buf` cum'è una fetta normale:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Usi *incorretti* di stu metudu:
    ///
    /// Ùn pudete micca aduprà `.assume_init_mut()` per inizializà un valore:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Avemu creatu un riferimentu (mutable) à un `bool` micca inizializatu!
    ///     // Questu hè un cumpurtamentu indefinitu.⚠️
    /// }
    /// ```
    ///
    /// Per esempiu, ùn pudete micca [`Read`] in un buffer non inizializatu:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) riferenza à a memoria micca inizializata!
    ///                             // Questu hè un cumpurtamentu indefinitu.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Nè pudete aduprà l'accessu direttu à u campu per fà inizializazione graduale campu per campu:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) riferenza à a memoria micca inizializata!
    ///                  // Questu hè un cumpurtamentu indefinitu.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) riferenza à a memoria micca inizializata!
    ///                  // Questu hè un cumpurtamentu indefinitu.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Attualmente ci basemu nantu à chì quessi quì sopra sò sbagliati, vale à dì, avemu referenze à dati micca inizializati (per esempiu, in `libcore/fmt/float.rs`).
    // Duvemu piglià una decisione finale nantu à e regule prima di stabilizazione.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SEGURITÀ: u chjamante deve garantisce chì `self` sia inizializatu.
        // Questu significa ancu chì `self` deve esse una variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Estrae i valori da una serie di contenitori `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Tocca à u chjamante di guarantisce chì tutti l'elementi di u array sò in un statu inizializatu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SICUREZZA: Avà sicuru mentre avemu inizializatu tutti l'elementi
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * U chjamante garantisce chì tutti l'elementi di u array sò inizializzati
        // * `MaybeUninit<T>` è T sò garantiti per avè u listessu layout
        // * Forse Unint ùn cala micca, allora ùn ci hè micca doppiu liberu È cusì a cunversione hè sicura
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Assumendu chì tutti l'elementi sò inizializzati, uttene una fetta per elli.
    ///
    /// # Safety
    ///
    /// Tocca à u chjamante di guarantisce chì l'elementi `MaybeUninit<T>` sò veramente in un statu inizializatu.
    ///
    /// Chjamà questu quandu u cuntenutu ùn hè ancu cumpletamente inizializatu provoca un comportamentu indefinitu.
    ///
    /// Vede [`assume_init_ref`] per più dettagli è esempi.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SICUREZZA: u colpu di slice à un `*const [T]` hè sicuru postu chì u chjamante a garantisce
        // `slice` hè inizializatu, è "ForseUninit" hè garantitu d'avè u listessu layout cum'è `T`.
        // U puntatore uttenutu hè validu postu chì si riferisce à a memoria di `slice` chì hè una riferenza è cusì garantita per esse valida per e letture.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Assumendu chì tutti l'elementi sò inizializzati, uttene una fetta mutabile per elli.
    ///
    /// # Safety
    ///
    /// Tocca à u chjamante di guarantisce chì l'elementi `MaybeUninit<T>` sò veramente in un statu inizializatu.
    ///
    /// Chjamà questu quandu u cuntenutu ùn hè ancu cumpletamente inizializatu provoca un comportamentu indefinitu.
    ///
    /// Vede [`assume_init_mut`] per più dettagli è esempi.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SICUREZZA: simile à e note di sicurezza per `slice_get_ref`, ma avemu un
        // riferenza mutevule chì hè ancu garantitu per esse validu per scrive.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Ottiene un puntatore per u primu elementu di a matrice.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Ottiene un puntatore mutabile per il primo elemento del array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Copia l'elementi da `src` à `this`, restituendu una riferenza mutevule à u cuntenutu avà inizializatu di `this`.
    ///
    /// Se `T` ùn implementa micca `Copy`, utilizate [`write_slice_cloned`]
    ///
    /// Questu hè simile à [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Sta funzione serà panic se e duie fette anu lunghezze diverse.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SICUREZZA: avemu ghjustu cupiatu tutti l'elementi di len in a capacità di riserva
    /// // i primi elementi src.len() di u vec sò validi avà.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SICUREZZA: &[T] è&[MaybeUninit<T>] anu u listessu schema
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SICUREZZA: Elementi validi sò stati appena cupiati in `this` dunque hè inizializatu
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clona l'elementi da `src` à `this`, restituendu una riferenza mutevule à u cuntenutu avà inizializatu di `this`.
    /// Ogni elementu dighjà inizializatu ùn serà micca abbandunatu.
    ///
    /// Se `T` implementa `Copy`, utilizate [`write_slice`]
    ///
    /// Questu hè simile à [`slice::clone_from_slice`] ma ùn abbandunà elementi esistenti.
    ///
    /// # Panics
    ///
    /// Questa funzione serà panic se e duie fette anu lunghezze diverse, o se l'implementazione di `Clone` panics.
    ///
    /// Se ci hè un panic, l'elementi dighjà clonati seranu abbandunati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SICUREZZA: avemu ghjustu clonatu tutti l'elementi di len in a capacità di riserva
    /// // i primi elementi src.len() di u vec sò validi avà.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // à u cuntrariu di copy_from_slice questu ùn chjama micca clone_from_slice nantu à a fetta hè perchè `MaybeUninit<T: Clone>` ùn implementa micca Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SICUREZZA: sta fetta cruda cuntene solu oggetti inizializati
                // hè per quessa, hè permessu di fallu falà.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Avemu bisognu di esplicitamente taglià li à a stessa lunghezza
        // per verificà i limiti per esse eliditi, è l'ottimisatore genererà memcpy per casi simplici (per esempiu T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // A guardia hè necessaria b/c panic pò accade durante un clone
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SICUREZZA: Elementi validi sò stati scritti in `this` dunque hè inizializatu
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}