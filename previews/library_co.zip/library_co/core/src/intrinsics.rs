//! Cumpilatore intrinsicu.
//!
//! E definizioni currispundenti sò in `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! L'implementazioni currispundenti currispondenti sò in `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsicu
//!
//! Note: ogni cambiamentu in a custanza di l'intrinsicu deve esse discuttu cù a squadra linguistica.
//! Ciò include cambiamenti in a stabilità di a constanza.
//!
//! Per fà un intrinsicu utilizabile in tempu di compilazione, ci vole à cupià l'implementazione da <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> à `compiler/rustc_mir/src/interpret/intrinsics.rs` è aghjunghje un `#[rustc_const_unstable(feature = "foo", issue = "01234")]` à l'intrinsicu.
//!
//!
//! Se un intrinsicu deve esse adupratu da un `const fn` cun un attributu `rustc_const_stable`, l'attributu di l'intrinsicu deve esse `rustc_const_stable`, puru.
//! Un tali cambiamentu ùn deve esse fattu senza cunsultazione T-lang, perchè furnisce una caratteristica in a lingua chì ùn pò micca esse riplicata in u codice d'utilizatore senza u supportu di u compilatore.
//!
//! # Volatiles
//!
//! L'intrinsicu volatile furnisce operazioni destinate à agisce nantu à a memoria I/O, chì sò garantite per ùn esse riordenate da u compilatore in altri intrinsichi volatili.Vede a documentazione LLVM nantu à [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! L'intrinsicu atomicu furnisce operazioni atomichi cumuni nantu à e parolle di macchina, cù parechje ordinazioni di memoria pussibili.Ubbidiscenu à a stessa semantica cum'è C++ 11.Vede a documentazione LLVM nantu à [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Un aghjurnamentu rapidu nantu à l'ordine di memoria:
//!
//! * Acquistà, una barriera per acquistà una serratura.E letture è scrive successive si facenu dopu à a barriera.
//! * Release, una barriera per liberà una serratura.E letture e scritture precedenti si facenu prima di a barriera.
//! * Operazioni sequenzialmente consistenti, sequenzialmente consistenti sò garantite per accadere in ordine.Questu hè u modu standard per travaglià cù tippi atomici è hè equivalente à `volatile` di Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Queste impurtazioni sò aduprate per simplificà i ligami intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SICUREZZA: vede `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, questi intrinsichi piglianu indicatori grezzi perchè mutanu a memoria aliased, chì ùn hè micca valida nè per `&` nè per `&mut`.
    //

    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange` passendu [`Ordering::SeqCst`] cum'è i parametri `success` è `failure`.
    ///
    /// Per esempiu, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange` passendu [`Ordering::Acquire`] cum'è i parametri `success` è `failure`.
    ///
    /// Per esempiu, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange` passendu [`Ordering::Release`] cum'è `success` è [`Ordering::Relaxed`] cum'è parametri `failure`.
    /// Per esempiu, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange` passendu [`Ordering::AcqRel`] cum'è `success` è [`Ordering::Acquire`] cum'è parametri `failure`.
    /// Per esempiu, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange` passendu [`Ordering::Relaxed`] cum'è i parametri `success` è `failure`.
    ///
    /// Per esempiu, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange` passendu [`Ordering::SeqCst`] cum'è `success` è [`Ordering::Relaxed`] cum'è parametri `failure`.
    /// Per esempiu, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange` passendu [`Ordering::SeqCst`] cum'è `success` è [`Ordering::Acquire`] cum'è parametri `failure`.
    /// Per esempiu, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange` passendu [`Ordering::Acquire`] cum'è `success` è [`Ordering::Relaxed`] cum'è parametri `failure`.
    /// Per esempiu, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange` passendu [`Ordering::AcqRel`] cum'è `success` è [`Ordering::Relaxed`] cum'è parametri `failure`.
    /// Per esempiu, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange_weak` passendu [`Ordering::SeqCst`] cum'è i parametri `success` è `failure`.
    ///
    /// Per esempiu, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange_weak` passendu [`Ordering::Acquire`] cum'è i parametri `success` è `failure`.
    ///
    /// Per esempiu, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange_weak` passendu [`Ordering::Release`] cum'è `success` è [`Ordering::Relaxed`] cum'è parametri `failure`.
    /// Per esempiu, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange_weak` passendu [`Ordering::AcqRel`] cum'è `success` è [`Ordering::Acquire`] cum'è parametri `failure`.
    /// Per esempiu, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange_weak` passendu [`Ordering::Relaxed`] cum'è i parametri `success` è `failure`.
    ///
    /// Per esempiu, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange_weak` passendu [`Ordering::SeqCst`] cum'è `success` è [`Ordering::Relaxed`] cum'è parametri `failure`.
    /// Per esempiu, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange_weak` passendu [`Ordering::SeqCst`] cum'è `success` è [`Ordering::Acquire`] cum'è parametri `failure`.
    /// Per esempiu, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange_weak` passendu [`Ordering::Acquire`] cum'è `success` è [`Ordering::Relaxed`] cum'è parametri `failure`.
    /// Per esempiu, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se u valore attuale hè u listessu chè u valore `old`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `compare_exchange_weak` passendu [`Ordering::AcqRel`] cum'è `success` è [`Ordering::Relaxed`] cum'è parametri `failure`.
    /// Per esempiu, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Carica u valore attuale di u puntatore.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `load` passendu [`Ordering::SeqCst`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Carica u valore attuale di u puntatore.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `load` passendu [`Ordering::Acquire`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Carica u valore attuale di u puntatore.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `load` passendu [`Ordering::Relaxed`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Memorizza u valore in u locu di memoria specificatu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `store` passendu [`Ordering::SeqCst`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Memorizza u valore in u locu di memoria specificatu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `store` passendu [`Ordering::Release`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Memorizza u valore in u locu di memoria specificatu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `store` passendu [`Ordering::Relaxed`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Memorizza u valore in u locu di memoria specificatu, restituendu u vechju valore.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `swap` passendu [`Ordering::SeqCst`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Memorizza u valore in u locu di memoria specificatu, restituendu u vechju valore.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `swap` passendu [`Ordering::Acquire`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Memorizza u valore in u locu di memoria specificatu, restituendu u vechju valore.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `swap` passendu [`Ordering::Release`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Memorizza u valore in u locu di memoria specificatu, restituendu u vechju valore.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `swap` passendu [`Ordering::AcqRel`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Memorizza u valore in u locu di memoria specificatu, restituendu u vechju valore.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `swap` passendu [`Ordering::Relaxed`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Aghjunghje à u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_add` passendu [`Ordering::SeqCst`] cum'è `order`.
    /// Per esempiu, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aghjunghje à u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_add` passendu [`Ordering::Acquire`] cum'è `order`.
    /// Per esempiu, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aghjunghje à u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_add` passendu [`Ordering::Release`] cum'è `order`.
    /// Per esempiu, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aghjunghje à u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_add` passendu [`Ordering::AcqRel`] cum'è `order`.
    /// Per esempiu, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aghjunghje à u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_add` passendu [`Ordering::Relaxed`] cum'è `order`.
    /// Per esempiu, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Sottraete u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_sub` passendu [`Ordering::SeqCst`] cum'è `order`.
    /// Per esempiu, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sottraete u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_sub` passendu [`Ordering::Acquire`] cum'è `order`.
    /// Per esempiu, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sottraete u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_sub` passendu [`Ordering::Release`] cum'è `order`.
    /// Per esempiu, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sottraete u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_sub` passendu [`Ordering::AcqRel`] cum'è `order`.
    /// Per esempiu, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sottraete u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_sub` passendu [`Ordering::Relaxed`] cum'è `order`.
    /// Per esempiu, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise è cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_and` passendu [`Ordering::SeqCst`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise è cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_and` passendu [`Ordering::Acquire`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise è cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_and` passendu [`Ordering::Release`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise è cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_and` passendu [`Ordering::AcqRel`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise è cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_and` passendu [`Ordering::Relaxed`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à u tippu [`AtomicBool`] via u metudu `fetch_nand` passendu [`Ordering::SeqCst`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à u tippu [`AtomicBool`] via u metudu `fetch_nand` passendu [`Ordering::Acquire`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à u tippu [`AtomicBool`] via u metudu `fetch_nand` passendu [`Ordering::Release`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à u tippu [`AtomicBool`] via u metudu `fetch_nand` passendu [`Ordering::AcqRel`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à u tippu [`AtomicBool`] via u metudu `fetch_nand` passendu [`Ordering::Relaxed`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise o cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_or` passendu [`Ordering::SeqCst`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_or` passendu [`Ordering::Acquire`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_or` passendu [`Ordering::Release`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_or` passendu [`Ordering::AcqRel`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_or` passendu [`Ordering::Relaxed`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_xor` passendu [`Ordering::SeqCst`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_xor` passendu [`Ordering::Acquire`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_xor` passendu [`Ordering::Release`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_xor` passendu [`Ordering::AcqRel`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor cù u valore attuale, restituendu u valore precedente.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi [`atomic`] via u metudu `fetch_xor` passendu [`Ordering::Relaxed`] cum'è `order`.
    /// Per esempiu, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Massimu cù u valore attuale aduprendu un paragone firmatu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tipi interi firmati [`atomic`] via u metudu `fetch_max` passendu [`Ordering::SeqCst`] cum'è `order`.
    /// Per esempiu, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu cù u valore attuale aduprendu un paragone firmatu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tipi interi firmati [`atomic`] via u metudu `fetch_max` passendu [`Ordering::Acquire`] cum'è `order`.
    /// Per esempiu, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu cù u valore attuale aduprendu un paragone firmatu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tipi interi firmati [`atomic`] via u metudu `fetch_max` passendu [`Ordering::Release`] cum'è `order`.
    /// Per esempiu, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu cù u valore attuale aduprendu un paragone firmatu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tipi interi firmati [`atomic`] via u metudu `fetch_max` passendu [`Ordering::AcqRel`] cum'è `order`.
    /// Per esempiu, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu cù u valore attuale.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tipi interi firmati [`atomic`] via u metudu `fetch_max` passendu [`Ordering::Relaxed`] cum'è `order`.
    /// Per esempiu, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimu cù u valore attuale aduprendu un paragone firmatu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tipi interi firmati [`atomic`] via u metudu `fetch_min` passendu [`Ordering::SeqCst`] cum'è `order`.
    /// Per esempiu, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu cù u valore attuale aduprendu un paragone firmatu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tipi interi firmati [`atomic`] via u metudu `fetch_min` passendu [`Ordering::Acquire`] cum'è `order`.
    /// Per esempiu, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu cù u valore attuale aduprendu un paragone firmatu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tipi interi firmati [`atomic`] via u metudu `fetch_min` passendu [`Ordering::Release`] cum'è `order`.
    /// Per esempiu, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu cù u valore attuale aduprendu un paragone firmatu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tipi interi firmati [`atomic`] via u metudu `fetch_min` passendu [`Ordering::AcqRel`] cum'è `order`.
    /// Per esempiu, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu cù u valore attuale aduprendu un paragone firmatu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tipi interi firmati [`atomic`] via u metudu `fetch_min` passendu [`Ordering::Relaxed`] cum'è `order`.
    /// Per esempiu, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimu cù u valore attuale aduprendu un paragone senza firma.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tipi interi senza signu [`atomic`] via u metudu `fetch_min` passendu [`Ordering::SeqCst`] cum'è `order`.
    /// Per esempiu, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu cù u valore attuale aduprendu un paragone senza firma.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi interi senza segnu [`atomic`] via u metudu `fetch_min` passendu [`Ordering::Acquire`] cum'è `order`.
    /// Per esempiu, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu cù u valore attuale aduprendu un paragone senza firma.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi interi senza segnu [`atomic`] via u metudu `fetch_min` passendu [`Ordering::Release`] cum'è `order`.
    /// Per esempiu, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu cù u valore attuale aduprendu un paragone senza firma.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tipi interi senza segnu [`atomic`] via u metudu `fetch_min` passendu [`Ordering::AcqRel`] cum'è `order`.
    /// Per esempiu, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu cù u valore attuale aduprendu un paragone senza firma.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi interi senza segnu [`atomic`] via u metudu `fetch_min` passendu [`Ordering::Relaxed`] cum'è `order`.
    /// Per esempiu, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Massimu cù u valore attuale aduprendu un paragone senza firma.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi interi senza segnu [`atomic`] via u metudu `fetch_max` passendu [`Ordering::SeqCst`] cum'è `order`.
    /// Per esempiu, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu cù u valore attuale aduprendu un paragone senza firma.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi interi senza segnu [`atomic`] via u metudu `fetch_max` passendu [`Ordering::Acquire`] cum'è `order`.
    /// Per esempiu, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu cù u valore attuale aduprendu un paragone senza firma.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi interi senza segnu [`atomic`] via u metudu `fetch_max` passendu [`Ordering::Release`] cum'è `order`.
    /// Per esempiu, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu cù u valore attuale aduprendu un paragone senza firma.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi interi senza segnu [`atomic`] via u metudu `fetch_max` passendu [`Ordering::AcqRel`] cum'è `order`.
    /// Per esempiu, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu cù u valore attuale aduprendu un paragone senza firma.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule nantu à i tippi interi senza segnu [`atomic`] via u metudu `fetch_max` passendu [`Ordering::Relaxed`] cum'è `order`.
    /// Per esempiu, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// L'intrinsicu `prefetch` hè un suggerimentu à u generatore di codice per inserisce una struzzione di prefetch s'ellu hè supportatu;altrimenti, hè un no-op.
    /// I Prefetches ùn anu micca effetti nant'à u cumpurtamentu di u prugramma ma ponu cambià e so caratteristiche di prestazione.
    ///
    /// L'argumentu `locality` deve esse un numeru interu costante è hè un specificatore di località temporale chì va da (0), senza località, à (3), estremamente lucale tene in cache.
    ///
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// L'intrinsicu `prefetch` hè un suggerimentu à u generatore di codice per inserisce una struzzione di prefetch s'ellu hè supportatu;altrimenti, hè un no-op.
    /// I Prefetches ùn anu micca effetti nant'à u cumpurtamentu di u prugramma ma ponu cambià e so caratteristiche di prestazione.
    ///
    /// L'argumentu `locality` deve esse un numeru interu costante è hè un specificatore di località temporale chì va da (0), senza località, à (3), estremamente lucale tene in cache.
    ///
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// L'intrinsicu `prefetch` hè un suggerimentu à u generatore di codice per inserisce una struzzione di prefetch s'ellu hè supportatu;altrimenti, hè un no-op.
    /// I Prefetches ùn anu micca effetti nant'à u cumpurtamentu di u prugramma ma ponu cambià e so caratteristiche di prestazione.
    ///
    /// L'argumentu `locality` deve esse un numeru interu costante è hè un specificatore di località temporale chì va da (0), senza località, à (3), estremamente lucale tene in cache.
    ///
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// L'intrinsicu `prefetch` hè un suggerimentu à u generatore di codice per inserisce una struzzione di prefetch s'ellu hè supportatu;altrimenti, hè un no-op.
    /// I Prefetches ùn anu micca effetti nant'à u cumpurtamentu di u prugramma ma ponu cambià e so caratteristiche di prestazione.
    ///
    /// L'argumentu `locality` deve esse un numeru interu costante è hè un specificatore di località temporale chì va da (0), senza località, à (3), estremamente lucale tene in cache.
    ///
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Una scherma atomica.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule in [`atomic::fence`] passendu [`Ordering::SeqCst`] cum'è `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Una scherma atomica.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule in [`atomic::fence`] passendu [`Ordering::Acquire`] cum'è `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Una scherma atomica.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule in [`atomic::fence`] passendu [`Ordering::Release`] cum'è `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Una scherma atomica.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule in [`atomic::fence`] passendu [`Ordering::AcqRel`] cum'è `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Una barriera di memoria solu cumpilatore.
    ///
    /// L'accessi di memoria ùn seranu mai riordinati in questa barriera da u compilatore, ma nisuna istruzzioni serà emessa per questu.
    /// Questu hè appruvatu per l'operazioni nantu à u stessu filu chì pò esse prevenutu, cum'è quandu interagisce cù gestori di segnale.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule in [`atomic::compiler_fence`] passendu [`Ordering::SeqCst`] cum'è `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Una barriera di memoria solu cumpilatore.
    ///
    /// L'accessi di memoria ùn seranu mai riordinati in questa barriera da u compilatore, ma nisuna istruzzioni serà emessa per questu.
    /// Questu hè appruvatu per l'operazioni nantu à u stessu filu chì pò esse prevenutu, cum'è quandu interagisce cù gestori di segnale.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule in [`atomic::compiler_fence`] passendu [`Ordering::Acquire`] cum'è `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Una barriera di memoria solu cumpilatore.
    ///
    /// L'accessi di memoria ùn seranu mai riordinati in questa barriera da u compilatore, ma nisuna istruzzioni serà emessa per questu.
    /// Questu hè appruvatu per l'operazioni nantu à u stessu filu chì pò esse prevenutu, cum'è quandu interagisce cù gestori di segnale.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule in [`atomic::compiler_fence`] passendu [`Ordering::Release`] cum'è `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Una barriera di memoria solu cumpilatore.
    ///
    /// L'accessi di memoria ùn seranu mai riordinati in questa barriera da u compilatore, ma nisuna istruzzioni serà emessa per questu.
    /// Questu hè appruvatu per l'operazioni nantu à u stessu filu chì pò esse prevenutu, cum'è quandu interagisce cù gestori di segnale.
    ///
    /// A versione stabilizzata di questu intrinsicu hè dispunibule in [`atomic::compiler_fence`] passendu [`Ordering::AcqRel`] cum'è `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magia intrinseca chì deriva u so significatu da attributi attaccati à a funzione.
    ///
    /// Per esempiu, u flussu di dati utilizza questu per iniettà asserzioni statiche in modo chì `rustc_peek(potentially_uninitialized)` veramente duveria verificà chì u flussu di dati hà infatti calculatu chì ùn hè micca inizializatu in questu puntu in u flussu di cuntrollu.
    ///
    ///
    /// Questu intrinsicu ùn deve esse adupratu fora di u compilatore.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Annulla l'esecuzione di u prucessu.
    ///
    /// Una versione più userale è stabile di questa operazione hè [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informa l'ottimizatore chì stu puntu di u codice ùn hè micca accessibile, permettendu ulteriori ottimizzazioni.
    ///
    /// NB, questu hè assai diversu da a macro `unreachable!()`: A differenza di a macro, chì panics quandu hè eseguita, hè un *comportamentu indefinitu* per ghjunghje à u codice marcatu cù sta funzione.
    ///
    ///
    /// A versione stabilizzata di questu intrinsicu hè [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informa l'ottimizatore chì una cundizione hè sempre vera.
    /// Se a cundizione hè falsa, u cumpurtamentu ùn hè micca definitu.
    ///
    /// Nisun codice hè generatu per questu intrinsicu, ma l'ottimisatore pruverà à priservallu (è a so situazione) trà passaggi, chì pò interferisce cù l'ottimizazione di u codice circundante è riduce e prestazioni.
    /// Ùn deve micca esse adupratu se l'invariante pò esse scupertu da l'ottimisatore da per ellu, o s'ellu ùn permette alcuna ottimisazione significativa.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Cunsiglii à u compilatore chì a cundizione branch hè prubabile di esse vera.
    /// Restituisce u valore passatu.
    ///
    /// Ogni usu altru ch'è cun dichjarazioni `if` ùn averà probabilmente micca un effettu.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Suggerimenti à u compilatore chì a cundizione branch hè prubabile di esse falsa.
    /// Restituisce u valore passatu.
    ///
    /// Ogni usu altru ch'è cun dichjarazioni `if` ùn averà probabilmente micca un effettu.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Esegue una trappula di puntu di interruzzione, per l'ispezione da un debugger.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    pub fn breakpoint();

    /// A dimensione di un tipu in bytes.
    ///
    /// Più specificamente, questu hè u offset in bytes trà elementi successivi di u listessu tippu, cumprendu u padding di allineamentu.
    ///
    ///
    /// A versione stabilizzata di questu intrinsicu hè [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// L'allineamentu minimu di un tippu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// L'allineamentu preferitu di un tippu.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// A dimensione di u valore riferitu in bytes.
    ///
    /// A versione stabilizzata di questu intrinsicu hè [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// L'allineamentu richiestu di u valore riferitu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Ottiene una fetta di stringa statica chì cuntene u nome di un tippu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Ottiene un identificatore chì hè glubale unicu per u tippu specificatu.
    /// Questa funzione restituverà u listessu valore per un tippu indipendentemente da quale crate sia invocatu.
    ///
    ///
    /// A versione stabilizzata di questu intrinsicu hè [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Una guardia per funzioni periculose chì ùn ponu mai esse eseguite se `T` hè disabitatu:
    /// Questu serà staticamente o panic, o ùn fà nunda.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Una guardia per e funzioni periculose chì ùn ponu mai esse eseguite se `T` ùn permette micca l'inizializazione zero: Questu serà staticamente o panic, o ùn farà nunda.
    ///
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    pub fn assert_zero_valid<T>();

    /// Una guardia per e funzioni periculose chì ùn ponu micca mai esse eseguite se `T` hà schemi di bit invalidi: Questu serà staticamente o panic, o ùn farà nunda.
    ///
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    pub fn assert_uninit_valid<T>();

    /// Ottiene una riferenza à un `Location` staticu chì indica induve hè stata chjamata.
    ///
    /// Pensate à aduprà [`core::panic::Location::caller`](crate::panic::Location::caller) invece.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Sposta un valore fora di u scopu senza eseguisce colla à goccia.
    ///
    /// Questu esiste solu per [`mem::forget_unsized`];nurmale `forget` usa `ManuallyDrop` invece.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterpreta i bit di un valore di un tipu cum'è un altru tipu.
    ///
    /// I dui tippi devenu avè a stessa taglia.
    /// Nè l'uriginale, nè u risultatu, pò esse un [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` hè semanticamente equivalente à una mossa bitwise di un tipu in l'altru.Copia i bit da u valore surghjente in u valore di destinazione, poi si scorda di l'uriginale.
    /// Hè equivalente à C's `memcpy` sottu u cappucciu, cum'è `transmute_copy`.
    ///
    /// Perchè `transmute` hè un'operazione di valore, l'alineamentu di i *valori trasmutati stessi* ùn hè micca un prublema.
    /// Cum'è cù qualsiasi altra funzione, u compilatore hà digià assicuratu chì `T` è `U` sò allineati currettamente.
    /// Tuttavia, quandu si trasmutanu valori chì *puntanu in altrò*(cume puntatori, riferimenti, scatule ...), u chjamante hà da assicurà l'alineazione curretta di i valori puntati.
    ///
    /// `transmute` hè **incredibilmente** periculosu.Ci hè un vastu numeru di modi per causà [undefined behavior][ub] cù questa funzione.`transmute` deve esse l'ultimu risorse assolutu.
    ///
    /// U [nomicon](../../nomicon/transmutes.html) hà una documentazione supplementaria.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Ci hè parechje cose chì `transmute` hè veramente utile.
    ///
    /// Trasfurmà un puntatore in un puntatore di funzione.Questu hè *micca* portabile per e macchine induve i puntatori di funzione è i puntatori di dati anu dimensioni diverse.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Prolungà una vita, o accurtà una vita invariante.Questu hè avanzatu, Rust assai periculosu!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ùn disperate: parechji usi di `transmute` ponu esse uttenuti per altri mezi.
    /// Quì sottu sò applicazioni cumuni di `transmute` chì ponu esse rimpiazzati cù constructi più sicuri.
    ///
    /// Trasfurmendu bytes(`&[u8]`) crudu in `u32`, `f64`, ecc .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // aduprà invece `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // o utilizate `u32::from_le_bytes` o `u32::from_be_bytes` per specificà l'endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Trasfurmà un puntatore in un `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Aduprate un cast `as` invece
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Trasfurmà un `*mut T` in un `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Aduprate invece un rimbursu
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Trasfurmà un `&mut T` in un `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Avà, mette inseme `as` è rinfriscante, nutate chì a catena di `as` `as` ùn hè micca transitiva
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Trasfurmà un `&str` in un `&[u8]`:
    ///
    /// ```
    /// // questu ùn hè micca un bonu modu per fà questu.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Pudete aduprà `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Oppure, basta aduprà una stringa di byte, se avete u cuntrollu nantu à a stringa letterale
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Trasfurmà un `Vec<&T>` in un `Vec<Option<&T>>`.
    ///
    /// Per trasmutà u tippu interiore di u cuntenutu di un contenitore, duvete assicurà di ùn viulà alcunu di l'invarianti di u cuntenitore.
    /// Per `Vec`, questu significa chì sia a dimensione *sia l'alineamentu* di i tippi interni devenu currisponde.
    /// Altri contenitori puderebbenu appughjassi nantu à a dimensione di u tippu, l'allineamentu, o ancu u `TypeId`, in quale casu a trasmissione ùn sarebbe pussibile affattu senza viulà l'invarianti di i contenitori.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clone u vector cume li riutilizzeremu più tardi
    /// let v_clone = v_orig.clone();
    ///
    /// // Aduprà a transmutazione: questu si basa nantu à u schema di dati micca specificatu di `Vec`, chì hè una gattiva idea è puderia causà Comportamentu indefinitu.
    /////
    /// // Tuttavia, ùn hè micca copia.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Questu hè u modu suggeritu, sicuru.
    /// // Copia tutta a vector, però, in un novu array.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Questu hè u modu propiu senza copia, periculosu di "transmuting" un `Vec`, senza basà si nantu à u schema di dati.
    /// // Invece di chjamà letteralmente `transmute`, eseguemu un puntatore, ma in termini di cunversione di u tippu internu originale (`&i32`) in u novu (`Option<&i32>`), questu hà tutte e stesse avvertenze.
    /////
    /// // Oltre à l'infurmazioni furnite sopra, cunsultate ancu a documentazione [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Aghjurnate questu quandu vec_into_raw_parts hè stabilizatu.
    ///     // Assicuratevi chì u vector originale ùn sia micca cadutu.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementazione di `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Ci hè parechje manere di fà questu, è ci sò parechje prublemi cù u modu (transmute) seguente.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // prima: transmute ùn hè micca tipu sicuru;tuttu ciò chì verifica hè chì T è
    ///         // U sò di listessa taglia.
    ///         // Siconda, ghjustu quì, avete duie referenze mutevule chì puntanu à a stessa memoria.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Questu si sbarazza di i prublemi di sicurità di tipu;`&mut *` vi* solu *vi darà un `&mut T` da un `&mut T` o `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // tuttavia, avete sempre duie referenze mutevule chì puntanu à a stessa memoria.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Hè cusì chì a biblioteca standard face.
    /// // Questu hè u megliu metudu, se avete bisognu di fà qualcosa cusì
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Questu ora hà trè riferenzi mutevuli chì apuntanu à a stessa memoria.`slice`, u valore ret.0, è u valore ret.1.
    ///         // `slice` ùn hè mai adupratu dopu `let ptr = ...`, è cusì si pò trattà cum'è "dead", è dunque, avete solu duie fette veri mutevuli.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Mentre questu rende a stabile intrinseca stabile, avemu qualchì codice persunalizatu in const fn
    // verifiche chì impediscenu u so usu in `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Ritorna `true` se u tipu propiu datu cum'è `T` richiede colla per goccia;restituisce `false` se u tipu propiu furnitu per `T` implementa `Copy`.
    ///
    ///
    /// Se u tippu attuale ùn richiede nè colla per goccia nè implementa `Copy`, allora u valore di ritornu di sta funzione ùn hè micca specificatu.
    ///
    /// A versione stabilizzata di questu intrinsicu hè [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Calcula l'offset da un puntatore.
    ///
    /// Questu hè implementatu cum'è intrinsicu per evità di cunvertisce da e per un numeru interu, postu chì a cunversione ghjittaria infurmazioni di aliasing.
    ///
    /// # Safety
    ///
    /// Sia u puntatore iniziale sia u resultante devenu esse in limiti o un byte passatu a fine di un oggettu assignatu.
    /// Se unu di i puntatori hè fora di i limiti o si verifica un overflow aritmeticu allora qualsiasi ulteriore usu di u valore restituitu darà un comportamentu indefinitu.
    ///
    ///
    /// A versione stabilizzata di questu intrinsicu hè [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Calcula l'offset da un puntatore, potenzialmente avvolgente.
    ///
    /// Questu hè implementatu cum'è intrinsicu per evità di cunvertisce da e per un interu, postu chì a cunversione inibisce certe ottimizzazioni.
    ///
    /// # Safety
    ///
    /// A diversità di l'intrinsicu `offset`, questu intrinsicu ùn restringe micca u puntatore resultante per puntà o un byte passatu a fine di un oggettu attribuitu, è si avvolge cù aritmetica di complementu di dui.
    /// U valore resultante ùn hè micca necessariamente validu per esse adupratu per accede veramente à a memoria.
    ///
    /// A versione stabilizzata di questu intrinsicu hè [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Equivalente à l'intrinsicu `llvm.memcpy.p0i8.0i8.*` adattu, cù una dimensione di `count`*`size_of::<T>()` è un allineamentu di
    ///
    /// `min_align_of::<T>()`
    ///
    /// U parametru volatile hè impostatu à `true`, perciò ùn serà micca ottimizatu fora à menu chì a dimensione sia uguale à zero.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equivalente à l'intrinsicu `llvm.memmove.p0i8.0i8.*` appropritatu, cù una dimensione di `count* size_of::<T>()` è un allineamentu di
    ///
    /// `min_align_of::<T>()`
    ///
    /// U parametru volatile hè impostatu à `true`, perciò ùn serà micca ottimizatu fora à menu chì a dimensione sia uguale à zero.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equivalente à l'intrinsicu `llvm.memset.p0i8.*` adattu, cù una dimensione di `count* size_of::<T>()` è un allineamentu di `min_align_of::<T>()`.
    ///
    ///
    /// U parametru volatile hè impostatu à `true`, perciò ùn serà micca ottimizatu fora à menu chì a dimensione sia uguale à zero.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Esegue una carica volatile da u puntatore `src`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Esegue un magazinu volatile per u puntatore `dst`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Esegue una carica volatile da u puntatore `src` U puntatore ùn hè micca necessariu esse alliniatu.
    ///
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Esegue un magazinu volatile per u puntatore `dst`.
    /// U puntatore ùn hè micca necessariu per esse alliniatu.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Restituisce a radice quadrata di un `f32`
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Restituisce a radice quadrata di un `f64`
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Rialza un `f32` à una potenza intera.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Rialza un `f64` à una potenza intera.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Restituisce u sinus di un `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Restituisce u sinus di un `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Restituisce u cosinu di un `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Restituisce u cosinu di un `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Rialza un `f32` à una putenza `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Rialza un `f64` à una putenza `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Restituisce l'esponenziale di un `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Restituisce l'esponenziale di un `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Ritorna 2 elevatu à a putenza di un `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Ritorna 2 elevatu à a putenza di un `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Restituisce u logaritmu naturale di un `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Restituisce u logaritmu naturale di un `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Restituisce u logaritmu di basa 10 di un `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Restituisce u logaritmu di basa 10 di un `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Restituisce u logaritmu di basa 2 di un `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Restituisce u logaritmu di basa 2 di un `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Restituisce `a * b + c` per i valori `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Restituisce `a * b + c` per i valori `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Restituisce u valore assolutu di un `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Restituisce u valore assolutu di un `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Restituisce u minimu di dui valori `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Restituisce u minimu di dui valori `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Restituisce u massimu di dui valori `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Restituisce u massimu di dui valori `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Copia u segnu da `y` à `x` per i valori `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Copia u segnu da `y` à `x` per i valori `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Restituisce u più grande interu menu o uguale à un `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Restituisce u più grande interu menu o uguale à un `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Restituisce u più chjucu interu più grande o uguale à un `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Restituisce u più chjucu interu più grande o uguale à un `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Restituisce a parte intera di un `f32`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Restituisce a parte intera di un `f64`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Restituisce u numeru interu più vicinu à un `f32`.
    /// Pò alzà un'eccezione in virgula flottante inesatta se l'argumentu ùn hè micca un numeru interu.
    pub fn rintf32(x: f32) -> f32;
    /// Restituisce u numeru interu più vicinu à un `f64`.
    /// Pò alzà un'eccezione in virgula flottante inesatta se l'argumentu ùn hè micca un numeru interu.
    pub fn rintf64(x: f64) -> f64;

    /// Restituisce u numeru interu più vicinu à un `f32`.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Restituisce u numeru interu più vicinu à un `f64`.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Restituisce u numeru interu più vicinu à un `f32`.Circonda casi à mità di distanza da zero.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Restituisce u numeru interu più vicinu à un `f64`.Circonda casi à mità di distanza da zero.
    ///
    /// A versione stabilizzata di questu intrinsicu hè
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Aghjunzione Float chì permette ottimisazioni basate nantu à e regule algebraiche.
    /// Pò suppone chì l'input sò finiti.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Sottrazione float chì permette ottimisazioni basate nantu à e regule algebraiche.
    /// Pò suppone chì l'input sò finiti.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Moltiplicazione float chì permette ottimisazioni basate nantu à e regule algebraiche.
    /// Pò suppone chì l'input sò finiti.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Divisione Float chì permette ottimisazioni basate nantu à e regule algebraiche.
    /// Pò suppone chì l'input sò finiti.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Float restu chì permette ottimisazioni basati nantu à e regule algebraiche.
    /// Pò suppone chì l'input sò finiti.
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Cunvertite cù fptoui/fptosi di LLVM, chì pò restituisce undef per valori fora di portata
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilizatu cum'è [`f32::to_int_unchecked`] è [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Restituisce u numeru di bits impostati in un tipu interu `T`
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `count_ones`.
    /// Per esempiu,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Restituisce u numeru di bit unset principali (zeroes) in un tipu interu `T`.
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `leading_zeros`.
    /// Per esempiu,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Un `x` cun valore `0` restituverà a larghezza di bit di `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Cum'è `ctlz`, ma extra-periculosu perchè rende `undef` quandu hè datu un `x` cun valore `0`.
    ///
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Restituisce u numeru di bit unset finiti (zeroes) in un tipu interu `T`.
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `trailing_zeros`.
    /// Per esempiu,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Un `x` cun valore `0` restituverà a larghezza di bit di `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Cum'è `cttz`, ma extra-periculosu perchè rende `undef` quandu hè datu un `x` cun valore `0`.
    ///
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Inverte i bytes in un tipu interu `T`.
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `swap_bytes`.
    /// Per esempiu,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Inverte i bit in un tipu interu `T`.
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `reverse_bits`.
    /// Per esempiu,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Esegue l'aghjuntu interu verificatu.
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `overflowing_add`.
    /// Per esempiu,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Esegue a sottrazione intera verificata
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `overflowing_sub`.
    /// Per esempiu,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Esegue a multiplicazione intera verificata
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `overflowing_mul`.
    /// Per esempiu,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Esegue una divisione esatta, risultendu in un comportamentu indefinitu induve `x % y != 0` o `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Esegue una divisione senza cuntrollu, risultendu in un comportamentu indefinitu induve `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Involucri sicuri per questu intrinsicu sò dispunibili nantu à i primitivi interi via u metudu `checked_div`.
    /// Per esempiu,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Restituisce u restu di una divisione senza verificazione, risultendu in un comportamentu indefinitu quandu `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Involucri sicuri per questu intrinsicu sò dispunibili nantu à i primitivi interi via u metudu `checked_rem`.
    /// Per esempiu,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Esegue un spostamentu à sinistra senza cuntrollu, risultendu in un comportamentu indefinitu quandu `y < 0` o `y >= N`, induve N hè a larghezza di T in bit.
    ///
    ///
    /// Involucri sicuri per questu intrinsicu sò dispunibili nantu à i primitivi interi via u metudu `checked_shl`.
    /// Per esempiu,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Esegue un spostamentu di diritta senza cuntrollu, risultendu in un comportamentu indefinitu quandu `y < 0` o `y >= N`, induve N hè a larghezza di T in bit.
    ///
    ///
    /// Involucri sicuri per questu intrinsicu sò dispunibili nantu à i primitivi interi via u metudu `checked_shr`.
    /// Per esempiu,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Restituisce u risultatu di un aghjuntu micca verificatu, resultendu in un comportamentu indefinitu quandu `x + y > T::MAX` o `x + y < T::MIN`.
    ///
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Restituisce u risultatu di una sottrazione micca verificata, risultendu in un comportamentu indefinitu quandu `x - y > T::MAX` o `x - y < T::MIN`.
    ///
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Restituisce u risultatu di una multiplicazione senza cuntrolli, risultendu in un comportamentu indefinitu quandu `x *y > T::MAX` o `x* y < T::MIN`.
    ///
    ///
    /// Questu intrinsicu ùn hà micca una contrapartita stabile.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Eseguisce a rotazione à sinistra.
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `rotate_left`.
    /// Per esempiu,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Eseguisce a rotazione à diritta.
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `rotate_right`.
    /// Per esempiu,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Ritorna (a + b) mod 2 <sup>N</sup>, induve N hè a larghezza di T in bit.
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `wrapping_add`.
    /// Per esempiu,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Ritorna (a, b) mod 2 <sup>N</sup>, induve N hè a larghezza di T in bit.
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `wrapping_sub`.
    /// Per esempiu,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Ritorna (a * b) mod 2 <sup>N</sup>, induve N hè a larghezza di T in bit.
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `wrapping_mul`.
    /// Per esempiu,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Calcula `a + b`, saturendu à limiti numerichi.
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `saturating_add`.
    /// Per esempiu,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Calcula `a - b`, saturendu à limiti numerichi.
    ///
    /// E versioni stabilizate di questu intrinsicu sò dispunibili nantu à i primitivi numeri interi via u metudu `saturating_sub`.
    /// Per esempiu,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Restituisce u valore di u discriminante per a variante in 'v';
    /// se `T` ùn hà micca discriminante, restituisce `0`.
    ///
    /// A versione stabilizzata di questu intrinsicu hè [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Restituisce u numeru di varianti di u tipu `T` cast à un `usize`;
    /// se `T` ùn hà micca varianti, restituisce `0`.E varianti disabitate saranu contate.
    ///
    /// A versione stabilizabile di questu intrinsicu hè [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// A custruzzione "try catch" di Rust chì invoca a funzione puntatore `try_fn` cù u puntatore di dati `data`.
    ///
    /// U terzu argumentu hè una funzione chjamata se un panic accade.
    /// Sta funzione piglia u puntatore di dati è un puntatore à l'ughjettu eccezziunale specificu di destinazione chì hè statu pigliatu.
    ///
    /// Per più infurmazione vedi a fonte di u compilatore è l'implementazione di cattura di std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emette un magazinu `!nontemporal` secondu LLVM (vede i so documenti).
    /// Probabilmente ùn diventerà mai stabile.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Vede a documentazione di `<*const T>::offset_from` per i dettagli.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Vede a documentazione di `<*const T>::guaranteed_eq` per i dettagli.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Vede a documentazione di `<*const T>::guaranteed_ne` per i dettagli.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Allocate à u tempu di compilazione.Ùn deve micca esse chjamatu in runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Alcune funzioni sò definite quì perchè sò state accidentalmente rese dispunibili in questu modulu in stabile.
// Vede <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` rientra ancu in questa categuria, ma ùn pò micca esse imballatu per via di u verificatu chì `T` è `U` anu a stessa dimensione.)
//

/// Verifica se `ptr` hè currettamente allinatu cù rispettu à `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Copia `count *size_of::<T>()` byte da `src` à `dst`.A surghjente è a destinazione ùn devenu* micca * si sovrappone.
///
/// Per e regioni di memoria chì puderebbenu sovrapposizione, aduprate invece [`copy`].
///
/// `copy_nonoverlapping` hè semanticamente equivalente à C's [`memcpy`], ma cù l'ordine di l'argumentu scambiatu.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * `src` deve esse [valid] per leghje di byte `count * size_of::<T>()`.
///
/// * `dst` deve esse [valid] per scrive di byte `count * size_of::<T>()`.
///
/// * Sia `src` sia `dst` devenu esse allineati currettamente.
///
/// * A regione di memoria chì principia à `src` cù una dimensione di `count *
///   size_of: :<T>() `Byte ùn devenu * ** sovrapposizione cù a regione di memoria chì principia da `dst` cù a stessa dimensione.
///
/// Cum'è [`read`], `copy_nonoverlapping` crea una copia bitwise di `T`, indipendentemente da se `T` hè [`Copy`].
/// Se `T` ùn hè micca [`Copy`], aduprendu *tramindui* i valori in a regione chì principianu da `*src` è a regione chì principia da `* dst` pò [violate memory safety][read-ownership].
///
///
/// Innota chì ancu se a dimensione copiata in modu efficace (`count * size_of: :<T>()`) hè `0`, i puntatori ùn devenu micca NULL è currettamente allineati.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Implementà manualmente [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Sposta tutti l'elementi di `src` in `dst`, lascendu `src` viotu.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Assicuratevi chì `dst` abbia abbastanza capacità per tene tuttu `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // A chjama à cumpensà hè sempre sicura perchè `Vec` ùn assignerà mai più di byte `isize::MAX`.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` senza abbandunà u so cuntenutu.
///         // Facemu questu prima, per evità prublemi in casu qualcosa più in panics.
///         src.set_len(0);
///
///         // E duie regioni ùn ponu micca sovrapposizione perchè e referenze mutevuli ùn anu micca alias, è dui vectors diversi ùn ponu micca pussede a stessa memoria.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Notificate `dst` chì avà cuntene u cuntenutu di `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Eseguite questi cuntrolli solu in tempu di esecuzione
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Micca in panicu per mantene l'impattu di i codegen più chjucu.
        abort();
    }*/

    // SICUREZZA: u cuntrattu di sicurezza per `copy_nonoverlapping` deve esse
    // cunfirmatu da u chjamante.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Copia `count * size_of::<T>()` byte da `src` à `dst`.A surghjente è a destinazione ponu sovrapposizione.
///
/// Se a surghjente è a destinazione *ùn* si * superposeranu, [`copy_nonoverlapping`] pò esse adupratu invece.
///
/// `copy` hè semanticamente equivalente à C's [`memmove`], ma cù l'ordine di l'argumentu scambiatu.
/// A copia si face cum'è se i bytes fussinu cupiati da `src` à un array tempurale è dopu cupiatu da u array à `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * `src` deve esse [valid] per leghje di byte `count * size_of::<T>()`.
///
/// * `dst` deve esse [valid] per scrive di byte `count * size_of::<T>()`.
///
/// * Sia `src` sia `dst` devenu esse allineati currettamente.
///
/// Cum'è [`read`], `copy` crea una copia bitwise di `T`, indipendentemente da se `T` hè [`Copy`].
/// Se `T` ùn hè micca [`Copy`], aduprendu i dui valori in a regione chì principia da `*src` è a regione chì principia da `* dst` pò [violate memory safety][read-ownership].
///
///
/// Innota chì ancu se a dimensione copiata in modu efficace (`count * size_of: :<T>()`) hè `0`, i puntatori ùn devenu micca NULL è currettamente allineati.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Creà efficacemente un Rust vector da un buffer periculosu:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` deve esse currettamente alliniatu per u so tippu è diversu da zero.
/// /// * `ptr` deve esse validu per e letture di `elts` elementi contigui di tippu `T`.
/// /// * Quelli elementi ùn devenu micca esse aduprati dopu à chjamà sta funzione à menu chì `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SICUREZZA: A nostra precondizione assicura chì a fonte sia allineata è valida,
///     // è `Vec::with_capacity` assicura chì avemu un spaziu utilizzabile per scrive li.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SICUREZZA: L'avemu creata cun questa capacità assai prima,
///     // è u `copy` precedente hà inizializatu questi elementi.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Eseguite questi cuntrolli solu in tempu di esecuzione
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Micca in panicu per mantene l'impattu di i codegen più chjucu.
        abort();
    }*/

    // SEGURITÀ: u cuntrattu di sicurezza per `copy` deve esse rispettatu da u chjamante.
    unsafe { copy(src, dst, count) }
}

/// Piazzà `count * size_of::<T>()` byte di memoria da `dst` à `val`.
///
/// `write_bytes` hè simile à C's [`memset`], ma mette `count * size_of::<T>()` byte à `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * `dst` deve esse [valid] per scrive di byte `count * size_of::<T>()`.
///
/// * `dst` deve esse currettamente alliniatu.
///
/// Inoltre, u chjamante deve assicurà chì scrive `count * size_of::<T>()` byte in a regione data di memoria risulti in un valore validu di `T`.
/// Utilizà una regione di memoria scritta cum'è `T` chì cuntene un valore invalidu di `T` hè un cumpurtamentu indefinitu.
///
/// Innota chì ancu se a dimensione copiata in modu efficace (`count * size_of: :<T>()`) hè `0`, u puntatore deve esse micca NULL è allinatu currettamente.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Crià un valore invalidu:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Perde u valore detenutu in precedenza soprascrivendu u `Box<T>` cù un puntatore null.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // A stu mumentu, aduprà o abbandunà `v` risultati in un cumpurtamentu indefinitu.
/// // drop(v); // ERROR
///
/// // Ancu fughjendu `v` "uses", è dunque hè un cumpurtamentu indefinitu.
/// // mem::forget(v); // ERROR
///
/// // In fattu, `v` ùn hè micca validu secondu l'invarianti di layout di tippu di basa, dunque *qualsiasi operazione* chì tocca hè un comportamentu indefinitu.
/////
/// // lascia v2 =v;//ERRORE
///
/// unsafe {
///     // Mettemu invece un valore validu
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Avà a scatula hè bella
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SEGURITÀ: u cuntrattu di sicurezza per `write_bytes` deve esse rispettatu da u chjamante.
    unsafe { write_bytes(dst, val, count) }
}