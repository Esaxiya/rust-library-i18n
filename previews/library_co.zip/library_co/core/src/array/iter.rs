//! Definisce l'iteratore `IntoIter` pussedutu per matrici.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Un iteratore [array] per valore.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Questu hè u array chì stemu iterendu sopra.
    ///
    /// Elementi cù l'indice `i` induve `alive.start <= i < alive.end` ùn sò ancu stati ceduti è sò entrate di matrice valide.
    /// Elementi cù indici `i < alive.start` o `i >= alive.end` sò stati dighjà ceduti è ùn devenu più esse accessu!Quelli elementi morti puderebbenu ancu esse in un statu cumpletamente micca inizializatu!
    ///
    ///
    /// Cusì l'invarianti sò:
    /// - `data[alive]` hè vivu (vale à dì cuntene elementi validi)
    /// - `data[..alive.start]` è `data[alive.end..]` sò morti (vale à dì chì l'elementi eranu dighjà letti è ùn devenu più esse toccati!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// L'elementi in `data` chì ùn sò ancu stati ceduti.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Crea un novu iteratore annantu à u `array` datu.
    ///
    /// *Nota*: stu metudu pò esse deprecatu in u future, dopu [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // U tippu di `value` hè un `i32` quì, invece di `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SICUREZZA: A transmutazione quì hè veramente sicura.I documenti di `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` hè garantitu per avè a stessa dimensione è allineamentu
        // > cum'è `T`.
        //
        // I documenti mostranu ancu un trasmutu da un array di `MaybeUninit<T>` à un array di `T`.
        //
        //
        // Cù questu, questa inizializazione soddisfa l'invarianti.

        // FIXME(LukasKalbertodt): aduprate veramente `mem::transmute` quì, una volta chì funziona cun const generici:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Finu à quì, pudemu aduprà `mem::transmute_copy` per creà una copia bitwise cum'è un tippu diversu, poi scurdamu `array` in modu chì ùn sia micca abbandunatu.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Restituisce una fetta immutabile di tutti l'elementi chì ùn sò ancu stati ceduti.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SICUREZZA: Sapemu chì tutti l'elementi in `alive` sò inizializati currettamente.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Restituisce una fetta mutabile di tutti l'elementi chì ùn sò ancu stati ceduti.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SICUREZZA: Sapemu chì tutti l'elementi in `alive` sò inizializati currettamente.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Uttenite u prossimu indice da u fronte.
        //
        // Aumentà `alive.start` da 1 mantene l'invariante in quantu à `alive`.
        // Tuttavia, à causa di stu cambiamentu, per un cortu tempu, a zona viva ùn hè più `data[alive]`, ma `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Leghjite l'elementu da u array.
            // SICUREZZA: `idx` hè un indice in l'anziana regione "alive" di u
            // array.A lettura di questu elementu significa chì `data[idx]` hè cunsideratu cum'è mortu avà (vale à dì micca toccu).
            // Cum'è `idx` era l'iniziu di a zona viva, a zona viva hè avà `data[alive]` di novu, ripristinendu tutti l'invarianti.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Uttenite u prossimu indice da u ritornu.
        //
        // A diminuzione di `alive.end` da 1 mantene l'invariante in quantu à `alive`.
        // Tuttavia, à causa di stu cambiamentu, per un cortu tempu, a zona viva ùn hè più `data[alive]`, ma `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Leghjite l'elementu da u array.
            // SICUREZZA: `idx` hè un indice in l'anziana regione "alive" di u
            // array.A lettura di questu elementu significa chì `data[idx]` hè cunsideratu cum'è mortu avà (vale à dì micca toccu).
            // Cum'è `idx` era a fine di a zona viva, a zona viva hè avà `data[alive]` di novu, ripristinendu tutti l'invarianti.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SICUREZZA: Questu hè sicuru: `as_mut_slice` restituisce esattamente a sub-fetta
        // d'elementi chì ùn sò ancu stati spustati è chì fermanu da lascià cascà.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Ùn serà mai sottumessu per via di l'invariante `vivo.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// L'iteratore riporta veramente a lunghezza curretta.
// U numeru di elementi "alive" (chì saranu sempre ceduti) hè a lunghezza di a gamma `alive`.
// Questa gamma hè diminuita in lunghezza in `next` o `next_back`.
// Hè sempre decrementatu da 1 in questi metudi, ma solu se `Some(_)` hè restituitu.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Nota, ùn avemu micca veramente bisognu di currisponde esattamente a stessa gamma viva, allora pudemu solu clonà in offset 0 indipendentemente da induve `self` sia.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clonà tutti l'elementi vivi.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Scrivite un clone in a nova matrice, allora aghjurnate a so gamma viva.
            // Se clonate panics, lasciaremu currettamente l'elementi precedenti.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Stampa solu l'elementi chì ùn eranu ancu ceduti: ùn pudemu più accede à l'elementi ceduti.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}