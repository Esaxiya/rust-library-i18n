use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Una interfaccia per trattà cù iteratori asincroni.
///
/// Questu hè u flussu principale trait.
/// Per sapè di più nantu à u cuncettu di flussi in generale, per piacè vede u [module-level documentation].
/// In particulare, pudete vulete sapè cumu [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// U tippu d'articuli ceduti da u flussu.
    type Item;

    /// Pruvate à tirà fora u prossimu valore di stu flussu, registrendu u compitu attuale per u svegliu se u valore ùn hè ancu dispunibile, è restituisce `None` se u flussu hè esauritu.
    ///
    /// # Valore di ritornu
    ///
    /// Ci hè parechji valori di ritornu pussibuli, ognunu indicendu un statu di flussu distintu:
    ///
    /// - `Poll::Pending` significa chì u prossimu valore di stu flussu ùn hè ancu prontu.L'implementazioni assicureranu chì l'attività currente serà notificata quandu u prossimu valore pò esse prontu.
    ///
    /// - `Poll::Ready(Some(val))` significa chì u flussu hà pruduttu un valore, `val`, è pò pruduce ulteriori valori per e successive chiamate `poll_next`.
    ///
    /// - `Poll::Ready(None)` significa chì u flussu hè finitu, è `poll_next` ùn deve micca esse invucatu di novu.
    ///
    /// # Panics
    ///
    /// Una volta chì un flussu hè finitu (`Ready(None)` from `poll_next`) restituitu, chjamà di novu u so metudu `poll_next` pò panic, bluccà per sempre, o causà altri tipi di prublemi; u `Stream` trait ùn pone micca esigenze nantu à l'effetti di una tale chjamata.
    ///
    /// Tuttavia, cume u metudu `poll_next` ùn hè micca marcatu `unsafe`, valenu e regule abituali di Rust: e chjamate ùn devenu mai causà cumpurtamentu indefinitu (corruzzione di memoria, usu incorrettu di e funzioni `unsafe`, o simile), indipendentemente da u statu di u flussu.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Restituisce i limiti nantu à a lunghezza restante di u flussu.
    ///
    /// Specificamente, `size_hint()` restituisce una tupla induve u primu elementu hè u limite inferiore, è u secondu elementu hè u limite superiore.
    ///
    /// A seconda metà di a tupla restituita hè una [`Opzione`]`<`[`usize`] `>`.
    /// Un [`None`] quì significa chì o ùn ci hè micca un limite superiore cunnisciutu, o u limitu superiore hè più grande di [`usize`].
    ///
    /// # Note di implementazione
    ///
    /// Ùn hè micca infurzatu chì una messa in opera di u flussu produci u numeru dichjaratu d'elementi.Un flussu buggy pò pruduce menu di u limitu inferiore o più di u limitu superiore di l'elementi.
    ///
    /// `size_hint()` hè principalmente destinatu à esse adupratu per ottimizazioni cume riservà spaziu per l'elementi di u flussu, ma ùn deve micca esse fidatu per esempiu, omettendu i controlli di limiti in codice periculosu.
    /// Una messa in opera sbagliata di `size_hint()` ùn deve micca cunduce à viulazioni di sicurità di memoria
    ///
    /// Dice questu, l'implementazione duveria furnisce una stima curretta, perchè altrimente seria una violazione di u protocolu trait.
    ///
    /// L'implementazione predefinita restituisce `(0,` [Nessuna`]`)` chì hè currettu per qualsiasi flussu.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}