//! Iterazione asincrona cumpunibile.
//!
//! Se futures sò valori asincroni, allora i flussi sò iteratori asincroni.
//! Se vi truvate cun una raccolta asincrona di qualchì tipu, è avete bisognu di fà una operazione nantu à l'elementi di detta raccolta, scapperai rapidamente in 'streams'.
//! I flussi sò assai usati in u codice Rust idiomaticu asincronu, dunque vale a pena di cunnosce li.
//!
//! Prima di spiegà ne di più, parlemu cumu hè strutturatu stu modulu:
//!
//! # Organization
//!
//! Stu modulu hè largamente organizatu per tippu:
//!
//! * [Traits] sò a parte principale: questi traits definiscenu chì tippu di flussi esistenu è ciò chì pudete fà cun elli.I metudi di sti traits valenu a pena di mette qualchì tempu di studiu in più.
//! * E funzioni furniscenu alcuni modi utili per creà alcuni flussi di basa.
//! * Strutture sò spessu i tippi di ritornu di i vari metodi in traits di stu modulu.Di solitu vulerete fighjà u metudu chì crea u `struct`, piuttostu chè u `struct` stessu.
//! Per più dettu nantu à u perchè, vedi '[Implementing Stream](#Implementing-stream)'.
//!
//! [Traits]: #traits
//!
//! Eccu!Scavemu in flussi.
//!
//! # Stream
//!
//! U core è l'anima di stu modulu hè u [`Stream`] trait.U core di [`Stream`] s'assumiglia à questu:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! A differenza di `Iterator`, `Stream` face una distinzione trà u metudu [`poll_next`] chì hè adupratu quandu si implementa un `Stream`, è un metudu (to-be-implemented) `next` chì hè adupratu quandu si cunsuma un flussu.
//!
//! I consumatori di `Stream` anu solu bisognu di cunsiderà `next`, chì quandu hè chjamatu, restituisce un future chì dà `Option<Stream::Item>`.
//!
//! U future restituitu da `next` darà `Some(Item)` fintantu chì ci sò elementi, è una volta chì sò stati esausti, darà `None` per indicà chì l'iterazione hè finita.
//! Se aspettemu qualcosa asincrona da risolve, u future aspetterà finu à chì u flussu sia prontu à cede di novu.
//!
//! I flussi individuali ponu sceglie di ripiglià l'iterazione, è cusì chjamà `next` di novu pò o ùn pò eventualmente cede `Some(Item)` di novu à un certu puntu.
//!
//! A definizione cumpleta di [`Stream`] include ancu altri metudi, ma sò metodi predefiniti, custruiti sopra [`poll_next`], è cusì li uttenite gratuitamente.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implementazione di u Flussu
//!
//! A creazione di un flussu propiu implica dui passi: creà un `struct` per tene u statu di u flussu, è poi implementà [`Stream`] per quellu `struct`.
//!
//! Facemu un flussu chjamatu `Counter` chì conta da `1` à `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Prima, a struct:
//!
//! /// Un flussu chì conta da unu à cinque
//! struct Counter {
//!     count: usize,
//! }
//!
//! // vulemu chì u nostru conte cominci da unu, allora aghjustemu un metudu new() per aiutà.
//! // Questu ùn hè micca strettamente necessariu, ma hè cunveniente.
//! // Innota chì cuminciamu `count` à zero, vedemu perchè in l'implementazione `poll_next()`'s quì sottu.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Dopu, implementemu `Stream` per u nostru `Counter`:
//!
//! impl Stream for Counter {
//!     // cunteremu cun usize
//!     type Item = usize;
//!
//!     // poll_next() hè l'unicu metudu necessariu
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Incrementa u nostru conte.Hè per quessa chì avemu principiatu à zeru.
//!         self.count += 1;
//!
//!         // Verificate se avemu finitu di cuntà o micca.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! I flussi sò *pigri*.Questu significa chì solu creà un flussu ùn _do_ assai.Nunda accade veramente finu à chjamà `next`.
//! Questa hè qualchì volta una fonte di cunfusione quandu crea un flussu solu per i so effetti collaterali.
//! U compilatore ci avverterà di stu tipu di cumpurtamentu:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;