#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Un `RawWaker` permette à l'implementatore di un esecutore di travagliu di creà un [`Waker`] chì furnisce cumpurtamentu di svegliu persunalizatu.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Si compone di un puntatore di dati è di un [virtual function pointer table (vtable)][vtable] chì persunalizeghja u cumpurtamentu di u `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Un puntatore di dati, chì pò esse adupratu per archivà dati arbitrarii cum'è richiestu da l'esecutore.
    /// Questu pò esse per esempiu
    /// un puntatore cancellatu di tippu à un `Arc` chì hè assuciatu à u compitu.
    /// U valore di stu campu hè passatu à tutte e funzioni chì facenu parte di a vtable cum'è primu parametru.
    ///
    data: *const (),
    /// Tabella di puntatore di funzione virtuale chì persunalizeghja u cumpurtamentu di stu waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Crea un novu `RawWaker` da u puntatore `data` furnitu è `vtable`.
    ///
    /// U puntatore `data` pò esse adupratu per archivà dati arbitrarii cum'è richiestu da l'esecutore.Questu pò esse per esempiu
    /// un puntatore cancellatu di tippu à un `Arc` chì hè assuciatu à u compitu.
    /// U valore di questu puntatore serà passatu à tutte e funzioni chì facenu parte di u `vtable` cum'è primu parametru.
    ///
    /// U `vtable` persunalizeghja u cumpurtamentu di un `Waker` chì hè creatu da un `RawWaker`.
    /// Per ogni operazione nantu à u `Waker`, a funzione assuciata in u `vtable` di u `RawWaker` sottostante serà chjamata.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Una tabella di puntatore di funzione virtuale (vtable) chì specifica u cumpurtamentu di un [`RawWaker`].
///
/// U puntatore passatu à tutte e funzioni à l'internu di a vtable hè u puntatore `data` da l'ughjettu [`RawWaker`] accintu.
///
/// E funzioni in questa struttura sò destinate solu à esse chjamate nantu à u puntatore `data` di un oggettu [`RawWaker`] custruitu currettamente da l'internu di l'implementazione [`RawWaker`].
/// Chjamà una di e funzioni cuntenute aduprendu qualsiasi altru puntatore `data` causerà cumpurtamentu indefinitu.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Questa funzione serà chjamata quandu u [`RawWaker`] hè clonatu, per esempiu quandu u [`Waker`] in u quale hè almacenatu u [`RawWaker`] hè clonatu.
    ///
    /// L'implementazione di sta funzione deve cunservà tutte e risorse chì sò necessarie per questa istanza addizionale di un [`RawWaker`] è compitu assuciatu.
    /// Chjamà `wake` nantu à u [`RawWaker`] resultante duveria resultà in un svegliu di u listessu compitu chì sarebbe statu svegliatu da l [`RawWaker`] originale.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Questa funzione serà chjamata quandu `wake` hè chjamatu nantu à u [`Waker`].
    /// Deve svegliare u compitu assuciatu à questu [`RawWaker`].
    ///
    /// L'implementazione di sta funzione deve esse sicura di liberà tutte e risorse chì sò assuciate cù questa istanza di un [`RawWaker`] è compitu assuciatu.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Questa funzione serà chjamata quandu `wake_by_ref` hè chjamatu nantu à u [`Waker`].
    /// Deve svegliare u compitu assuciatu à questu [`RawWaker`].
    ///
    /// Sta funzione hè simile à `wake`, ma ùn deve micca cunsumà u puntatore di dati furnitu.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Sta funzione hè chjamata quandu un [`RawWaker`] hè cascatu.
    ///
    /// L'implementazione di sta funzione deve esse sicura di liberà tutte e risorse chì sò assuciate cù questa istanza di un [`RawWaker`] è compitu assuciatu.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Crea un novu `RawWakerVTable` da e funzioni `clone`, `wake`, `wake_by_ref` è `drop` furnite.
    ///
    /// # `clone`
    ///
    /// Questa funzione serà chjamata quandu u [`RawWaker`] hè clonatu, per esempiu quandu u [`Waker`] in u quale hè almacenatu u [`RawWaker`] hè clonatu.
    ///
    /// L'implementazione di sta funzione deve cunservà tutte e risorse chì sò necessarie per questa istanza addizionale di un [`RawWaker`] è compitu assuciatu.
    /// Chjamà `wake` nantu à u [`RawWaker`] resultante duveria resultà in un svegliu di u listessu compitu chì sarebbe statu svegliatu da l [`RawWaker`] originale.
    ///
    /// # `wake`
    ///
    /// Questa funzione serà chjamata quandu `wake` hè chjamatu nantu à u [`Waker`].
    /// Deve svegliare u compitu assuciatu à questu [`RawWaker`].
    ///
    /// L'implementazione di sta funzione deve esse sicura di liberà tutte e risorse chì sò assuciate cù questa istanza di un [`RawWaker`] è compitu assuciatu.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Questa funzione serà chjamata quandu `wake_by_ref` hè chjamatu nantu à u [`Waker`].
    /// Deve svegliare u compitu assuciatu à questu [`RawWaker`].
    ///
    /// Sta funzione hè simile à `wake`, ma ùn deve micca cunsumà u puntatore di dati furnitu.
    ///
    /// # `drop`
    ///
    /// Sta funzione hè chjamata quandu un [`RawWaker`] hè cascatu.
    ///
    /// L'implementazione di sta funzione deve esse sicura di liberà tutte e risorse chì sò assuciate cù questa istanza di un [`RawWaker`] è compitu assuciatu.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// U `Context` di un compitu asincrunu.
///
/// Attualmente, `Context` serve solu per furnisce l'accessu à un `&Waker` chì pò esse adupratu per svegliare u compitu attuale.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Assicuratevi chì a prova future contr'à i cambiamenti di varianza furzendu a vita à esse invariante (a vita di a posizione di l'argumentu hè contravarianta mentre a vita di a posizione di ritornu sò covarianti).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Crea un novu `Context` da un `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Restituisce una riferenza à u `Waker` per u compitu attuale.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Un `Waker` hè un manicu per svegliare un compitu notificendu à u so esecutore chì hè prontu à esse gestitu.
///
/// Questa maniglia incapsula un'istanza [`RawWaker`], chì definisce u cumpurtamentu di svegliu specificu di l'esecutore.
///
///
/// Implementa [`Clone`], [`Send`] è [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Svegliu u compitu assuciatu à questu `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // A chjama di svegliu attuale hè delegata per mezu di una funzione di funzione virtuale à l'implementazione chì hè definita da l'esecutore.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Ùn chjamate micca `drop`-u waker serà cunsumatu da `wake`.
        crate::mem::forget(self);

        // SICUREZZA: Questu hè sicuru perchè `Waker::from_raw` hè l'unicu modu
        // per inizializà `wake` è `data` chì richiede à l'utilizatore di ricunnosce chì u cuntrattu di `RawWaker` hè rispettatu.
        //
        unsafe { (wake)(data) };
    }

    /// Svegliu u compitu assuciatu à questu `Waker` senza cunsumà u `Waker`.
    ///
    /// Questu hè simili à `wake`, ma pò esse ligeramente menu efficiente in u casu induve un `Waker` pussibule hè dispunibule.
    /// Stu metudu deve esse preferitu à chjamà `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // A chjama di svegliu attuale hè delegata per mezu di una funzione di funzione virtuale à l'implementazione chì hè definita da l'esecutore.
        //

        // SICUREZZA: vede `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Ritorna `true` se questu `Waker` è un altru `Waker` anu svegliu u listessu compitu.
    ///
    /// Sta funzione funziona nantu à u megliu sforzu, è pò rientre falsa ancu quandu i `Waker` sveglieranu u listessu compitu.
    /// Tuttavia, se sta funzione rende `true`, hè garantitu chì i `Waker` sveglieranu u listessu compitu.
    ///
    /// Sta funzione hè aduprata principalmente per scopu di ottimisazione.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Crea un novu `Waker` da [`RawWaker`].
    ///
    /// U comportamentu di u `Waker` restituitu ùn hè micca definitu se u cuntrattu definitu in a documentazione di [`RawWaker`] è [`RawWakerVTable`] ùn hè micca cunfirmatu.
    ///
    /// Dunque stu metudu hè periculosu.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SICUREZZA: Questu hè sicuru perchè `Waker::from_raw` hè l'unicu modu
            // per inizializà `clone` è `data` chì richiede à l'utilizatore di ricunnosce chì u cuntrattu di [`RawWaker`] hè rispettatu.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SICUREZZA: Questu hè sicuru perchè `Waker::from_raw` hè l'unicu modu
        // per inizializà `drop` è `data` chì richiede à l'utilizatore di ricunnosce chì u cuntrattu di `RawWaker` hè rispettatu.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}