//! Tipi atomichi
//!
//! I tippi atomichi furniscenu una cumunicazione primitiva in memoria cumuna trà fili, è sò i blocchi di custruzzione di altri tippi concurrenti.
//!
//! Stu modulu definisce versioni atomiche di un numeru selezziunatu di tippi primitivi, cumpresu [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], etc.
//! Tipi atomichi prisentanu operazioni chì, quand'elli sò aduprati currettamente, sincronizanu l'aggiornamenti trà i fili.
//!
//! Ogni metudu piglia un [`Ordering`] chì riprisenta a forza di a barriera di memoria per questa operazione.Queste cumandamenti sò i stessi cum'è u [C++20 atomic orderings][1].Per più infurmazione vedi u [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! E variabili atomiche sò sicure da sparte trà fili (implementanu [`Sync`]) ma ùn furniscenu micca elli stessi u meccanisimu per sparte è seguitate u [threading model](../../../std/thread/index.html#the-threading-model) di Rust.
//!
//! U modu più cumunu per sparte una variabile atomica hè di mette la in un [`Arc`][arc] (un puntatore spartutu cuntegnu di riferenza atomica).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! I tippi atomici ponu esse conservati in variabili statiche, inizializate aduprendu l'iniziali costanti cum'è [`AtomicBool::new`].A statica atomica hè spessu usata per l'inizializazione glubale pigra.
//!
//! # Portability
//!
//! Tutti i tippi atomichi in questu modulu sò garantiti per esse [lock-free] se sò dispunibili.Questu significa chì ùn acquistanu micca internamente un mutex globale.Tipi atomichi è operazioni ùn sò micca garantiti per esse senza aspittà.
//! Ciò significa chì operazioni cum'è `fetch_or` ponu esse implementate cù un loop di paragunà è scambià.
//!
//! L'operazioni atomiche ponu esse implementate à u livellu di struzzioni cù atomichi di dimensioni più grandi.Per esempiu alcune piattaforme adupranu istruzioni atomiche à 4 byte per implementà `AtomicI8`.
//! Innota chì sta emulazione ùn deve micca avè un impattu nantu à a currettezza di u codice, hè solu qualcosa da cunnosce.
//!
//! I tippi atomichi in questu modulu ponu micca esse dispunibili in tutte e piattaforme.I tippi atomichi quì sò tutti dispunibuli largamente, tuttavia, è ponu generalmente esse affidati à l'esistenti.Alcune eccezioni notevuli sò:
//!
//! * PowerPC e piattaforme MIPS cù puntatori 32-bit ùn anu micca tippi `AtomicU64` o `AtomicI64`.
//! * ARM piattaforme cum'è `armv5te` chì ùn sò micca per Linux furniscenu solu operazioni `load` è `store`, è ùn supportanu micca l'operazioni Compare è Swap (CAS), cum'è `swap`, `fetch_add`, ecc.
//! Inoltre in Linux, queste operazioni CAS sò implementate via [operating system support], chì pò vene cun una penalità di prestazione.
//! * ARM i destinazioni cù `thumbv6m` furniscenu solu operazioni `load` è `store`, è ùn supportanu micca l'operazioni Comparare è Scambià (CAS), cum'è `swap`, `fetch_add`, ecc.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Nota chì e piattaforme future ponu esse aghjunte chì ùn anu ancu un supportu per alcune operazioni atomiche.U codice portabilmente massimu vulerà esse attentu à chì tippi atomichi sò aduprati.
//! `AtomicUsize` è `AtomicIsize` sò generalmente i più purtatili, ma ancu allora ùn sò micca dispunibili in ogni locu.
//! Per riferimentu, a libreria `std` richiede atomichi di dimensione di puntatore, ancu se `core` ùn ne.
//!
//! Attualmente duverete aduprà `#[cfg(target_arch)]` principalmente per compilà cundiziunale in codice cù atomichi.Ci hè un `#[cfg(target_has_atomic)]` instabile ancu chì pò esse stabilizatu in u future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Un spinlock simplice:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Aspittate per l'altru filu per liberà a serratura
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Mantene un conte globale di fili in diretta:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Un tippu booleanu chì pò esse spartutu in modu sicuru trà filetti.
///
/// Stu tipu hà a stessa rappresentanza in memoria cum'è un [`bool`].
///
/// **Nota**: Stu tipu hè dispunibule solu nantu à e piattaforme chì supportanu carichi atomichi è magazzini di `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Crea un `AtomicBool` inizializatu à `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send hè implicitamente implementatu per AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Un tippu di puntatore crudu chì pò esse spartutu in modu sicuru trà fili.
///
/// Stu tipu hà a stessa rappresentanza in memoria cum'è un `*mut T`.
///
/// **Nota**: Stu tipu hè dispunibule solu nantu à e piattaforme chì supportanu carichi atomichi è magazzini di puntatori.
/// A so dimensione dipende da a dimensione di u puntatore di destinazione.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Crea un `AtomicPtr<T>` nulu.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Ordinazioni di memoria atomica
///
/// L'ordine di memoria specificanu u modu in cui l'operazioni atomiche sincronizanu a memoria.
/// In u so [`Ordering::Relaxed`] u più debule, solu a memoria toccata direttamente da l'operazione hè sincronizata.
/// D'altra parte, una coppia di carichi di magazzinu di operazioni [`Ordering::SeqCst`] sincronizza l'altra memoria pur mantenendu in più un ordine tutale di tali operazioni in tutti i fili.
///
///
/// L'ordine di memoria di Rust sò [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Per saperne di più vede u [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Nisun vinculu d'ordine, solu operazioni atomiche.
    ///
    /// Currisponde à [`memory_order_relaxed`] in C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Quandu accumpagnatu cù un magazinu, tutte l'operazioni precedenti sò urdinate prima di qualsiasi carica di questu valore cun [`Acquire`] (o più forte) cumandendu.
    ///
    /// In particulare, tutte e scritture precedenti diventanu visibili per tutti i fili chì eseguiscenu una carica [`Acquire`] (o più forte) di questu valore.
    ///
    /// Nutate bè chì aduprà sta cumanda per un'operazione chì unisce carichi è magazzini porta à un'operazione di carica [`Relaxed`]!
    ///
    /// Questu urdinamentu hè applicabile solu per l'operazioni chì ponu fà un magazinu.
    ///
    /// Currisponde à [`memory_order_release`] in C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Quandu accumpagnatu cù una carica, se u valore caricatu hè statu scrittu da una operazione di magazinu cù l'ordine [`Release`] (o più forte), allora tutte l'operazioni successive diventanu urdinate dopu quellu magazinu.
    /// In particulare, tutti i carichi successivi vedenu dati scritti davanti à u magazinu.
    ///
    /// Notate chì aduprà sta cumanda per un'operazione chì combina carichi è magazzini porta à un'operazione di magazzinu [`Relaxed`]!
    ///
    /// Questu urdinamentu hè applicabile solu per l'operazioni chì ponu eseguisce una carica.
    ///
    /// Currisponde à [`memory_order_acquire`] in C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Hà l'effetti di [`Acquire`] è [`Release`] inseme:
    /// Per carichi utilizza l'ordine [`Acquire`].Per i magazini utilizza l'ordine [`Release`].
    ///
    /// Notate chì in u casu di `compare_and_swap`, hè pussibule chì l'operazione finisca per ùn eseguisce alcun magazinu è dunque hà solu l'ordine [`Acquire`].
    ///
    /// Tuttavia, `AcqRel` ùn eseguirà mai l'accessi [`Relaxed`].
    ///
    /// Questu ordine hè applicabile solu per l'operazioni chì combinanu sia carichi sia magazzini.
    ///
    /// Currisponde à [`memory_order_acq_rel`] in C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Cum'è [`Acquire`]/[`Release`]/[`AcqRel`](per operazioni di carica, magazzini è carichi cù magazzini, rispettivamente) cù a garanzia addizionale chì tutti i fili vedenu tutte l'operazioni cunsistenti sequenzialmente in u listessu ordine .
    ///
    ///
    /// Currisponde à [`memory_order_seq_cst`] in C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Un [`AtomicBool`] inizializatu à `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Crea un novu `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Restituisce un riferimentu mutevule à u [`bool`] sottostante.
    ///
    /// Questu hè sicuru perchè a riferenza mutevule garantisce chì nisun altru thread accede simultaneamente à i dati atomici.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SICUREZZA: a riferenza mutevule garantisce una pruprietà unica.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Uttenite l'accessu atomicu à un `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SICUREZZA: a riferenza mutevule garantisce una pruprietà unica, è
        // l'allineamentu di `bool` è `Self` hè 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Cunsuma u atomicu è restituisce u valore cuntenutu.
    ///
    /// Questu hè sicuru perchè passà `self` per valore garantisce chì nisun altru thread accede simultaneamente à i dati atomici.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Carica un valore da u bool.
    ///
    /// `load` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.
    /// I valori pussibuli sò [`SeqCst`], [`Acquire`] è [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` hè [`Release`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SICUREZZA: ogni corsa di dati hè impedita da l'intrinsicu atomicu è da a materia prima
        // u puntatore passatu hè validu perchè l'avemu ottenutu da una riferenza.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Memorizza un valore in u bool.
    ///
    /// `store` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.
    /// I valori pussibuli sò [`SeqCst`], [`Release`] è [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` hè [`Acquire`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SICUREZZA: ogni corsa di dati hè impedita da l'intrinsicu atomicu è da a materia prima
        // u puntatore passatu hè validu perchè l'avemu ottenutu da una riferenza.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Memorizza un valore in u bool, restituendu u valore precedente.
    ///
    /// `swap` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
    /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
    ///
    ///
    /// **Note:** Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche nantu à `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Memorizza un valore in u [`bool`] se u valore attuale hè u listessu chè u valore `current`.
    ///
    /// U valore di ritornu hè sempre u valore precedente.S'ellu hè uguale à `current`, allora u valore hè statu aggiornatu.
    ///
    /// `compare_and_swap` piglia ancu un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.
    /// Notate chì ancu quandu si utilizza [`AcqRel`], l'operazione puderia fiascà è dunque solu eseguisce una carica `Acquire`, ma ùn avè micca semantica `Release`.
    /// Aduprà [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`] se accade, è aduprà [`Release`] rende a parte di carica [`Relaxed`].
    ///
    /// **Note:** Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche nantu à `u8`.
    ///
    /// # Migrà à `compare_exchange` è `compare_exchange_weak`
    ///
    /// `compare_and_swap` hè equivalente à `compare_exchange` cù a seguente mappatura per l'ordine di memoria:
    ///
    /// Originale |Successu |Fallimentu
    /// -------- | ------- | -------
    /// Relaxed |Relaxed |Relaxed Acquire |Acquire |Acquistà Release |Release |Relaxed AcqRel |AcqRel |Acquistà SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` hè permessu di fallu spuriously ancu quandu u paragone riesce, chì permette à u compilatore di generà un codice di assemblea megliu quandu u paragone è u swap sò aduprati in un loop.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Memorizza un valore in u [`bool`] se u valore attuale hè u listessu chè u valore `current`.
    ///
    /// U valore di ritornu hè un risultatu chì indica se u novu valore hè statu scrittu è chì cuntene u valore precedente.
    /// In successu, questu valore hè garantitu per esse uguale à `current`.
    ///
    /// `compare_exchange` piglia dui argumenti [`Ordering`] per discrive l'ordine di memoria di questa operazione.
    /// `success` descrive l'ordine richiestu per l'operazione di lettura-mudificazione-scrittura chì si face se u paragone cù `current` riesce.
    /// `failure` descrive l'ordine richiestu per l'operazione di carica chì si faci quandu u paragone fiasca.
    /// Aduprà [`Acquire`] cum'è ordine di successu face u magazinu parte di questa operazione [`Relaxed`], è aduprà [`Release`] face u caricu di successu [`Relaxed`].
    ///
    /// L'ordine di fallimentu pò esse solu [`SeqCst`], [`Acquire`] o [`Relaxed`] è deve esse equivalente o più debule di l'ordine di successu.
    ///
    /// **Note:** Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche nantu à `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Memorizza un valore in u [`bool`] se u valore attuale hè u listessu chè u valore `current`.
    ///
    /// A differenza di [`AtomicBool::compare_exchange`], sta funzione hè permessa di fiascà spuriosamente ancu quandu u paragone riesce, ciò chì pò traduce in un codice più efficiente in alcune piattaforme.
    ///
    /// U valore di ritornu hè un risultatu chì indica se u novu valore hè statu scrittu è chì cuntene u valore precedente.
    ///
    /// `compare_exchange_weak` piglia dui argumenti [`Ordering`] per discrive l'ordine di memoria di questa operazione.
    /// `success` descrive l'ordine richiestu per l'operazione di lettura-mudificazione-scrittura chì si face se u paragone cù `current` riesce.
    /// `failure` descrive l'ordine richiestu per l'operazione di carica chì si faci quandu u paragone fiasca.
    /// Aduprà [`Acquire`] cum'è ordine di successu face u magazinu parte di questa operazione [`Relaxed`], è aduprà [`Release`] face u caricu di successu [`Relaxed`].
    /// L'ordine di fallimentu pò esse solu [`SeqCst`], [`Acquire`] o [`Relaxed`] è deve esse equivalente o più debule di l'ordine di successu.
    ///
    /// **Note:** Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche nantu à `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// "and" logicu cù un valore booleanu.
    ///
    /// Esegue un'operazione logica "and" nantu à u valore attuale è l'argumentu `val`, è mette u novu valore à u risultatu.
    ///
    /// Restituisce u valore precedente.
    ///
    /// `fetch_and` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
    /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
    ///
    ///
    /// **Note:** Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche nantu à `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// "nand" logicu cù un valore booleanu.
    ///
    /// Esegue un'operazione logica "nand" nantu à u valore attuale è l'argumentu `val`, è mette u novu valore à u risultatu.
    ///
    /// Restituisce u valore precedente.
    ///
    /// `fetch_nand` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
    /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
    ///
    ///
    /// **Note:** Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche nantu à `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Ùn pudemu micca aduprà atomic_nand quì perchè pò risultà in un bool cun un valore invalidu.
        // Questu accade perchè l'operazione atomica hè fatta cù un interu à 8 bit internamente, chì stabilisce i 7 bit superiori.
        //
        // Cusì usemu solu fetch_xor o scambià invece.
        if val {
            // ! (x&true)== !x Avemu da inverà u bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Duvemu impostà u bool à veru.
            //
            self.swap(true, order)
        }
    }

    /// "or" logicu cù un valore booleanu.
    ///
    /// Esegue un'operazione logica "or" nantu à u valore attuale è l'argumentu `val`, è mette u novu valore à u risultatu.
    ///
    /// Restituisce u valore precedente.
    ///
    /// `fetch_or` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
    /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
    ///
    ///
    /// **Note:** Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche nantu à `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// "xor" logicu cù un valore booleanu.
    ///
    /// Esegue un'operazione logica "xor" nantu à u valore attuale è l'argumentu `val`, è mette u novu valore à u risultatu.
    ///
    /// Restituisce u valore precedente.
    ///
    /// `fetch_xor` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
    /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
    ///
    ///
    /// **Note:** Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche nantu à `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Restituisce un puntatore mutevule à u [`bool`] sottostante.
    ///
    /// Fà letture è scrive non atomiche nantu à u numeru interu resultante pò esse una corsa di dati.
    /// Stu metudu hè soprattuttu utile per FFI, induve a firma di funzione pò aduprà `*mut bool` invece di `&AtomicBool`.
    ///
    /// Riturnà un puntatore `*mut` da una riferenza cumuna à questu atomicu hè sicuru perchè i tippi atomichi travaglianu cù mutabilità interiore.
    /// Tutte e modifiche di un atomicu cambianu u valore per mezu di una riferenza spartuta, è ponu fà lu in modu sicuru cù u tempu chì usanu operazioni atomiche.
    /// Ogni usu di u puntatore grezzu restituitu richiede un bloccu `unsafe` è deve sempre rispettà a stessa restrizione: l'operazioni annantu à ellu devenu esse atomiche.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Fetches u valore, è applica una funzione chì restituisce un novu valore opzionale.Restituisce un `Result` di `Ok(previous_value)` se a funzione restituisce `Some(_)`, altrimenti `Err(previous_value)`.
    ///
    /// Note: Questa pò chjamà a funzione parechje volte se u valore hè statu cambiatu da altri fili in u frattempu, basta chì a funzione restituisce `Some(_)`, ma a funzione serà stata applicata una sola volta à u valore almacenatu.
    ///
    ///
    /// `fetch_update` piglia dui argumenti [`Ordering`] per discrive l'ordine di memoria di questa operazione.
    /// U primu descrive l'ordine richiestu per quandu l'operazione finalmente riesce mentre u secondu descrive l'ordine richiestu per i carichi.
    /// Queste currispondenu à l'ordine di successu è di fallimentu di [`AtomicBool::compare_exchange`] rispettivamente.
    ///
    /// Aduprà [`Acquire`] cum'è ordine di successu face u magazinu parte di questa operazione [`Relaxed`], è aduprà [`Release`] face u carcu finale successu [`Relaxed`].
    /// L'ordine di carica (failed) pò esse solu [`SeqCst`], [`Acquire`] o [`Relaxed`] è deve esse equivalente o più debule di l'ordine di successu.
    ///
    /// **Note:** Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche nantu à `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Crea un novu `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Restituisce un riferimentu mudificabile à u puntatore sottostante.
    ///
    /// Questu hè sicuru perchè a riferenza mutevule garantisce chì nisun altru thread accede simultaneamente à i dati atomici.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Uttenite l'accessu atomicu à un puntatore.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - a riferenza mutevule garantisce una pruprietà unica.
        //  - l'alineamentu di `*mut T` è `Self` hè u listessu in tutte e piattaforme supportate da rust, cum'è verificatu sopra.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Cunsuma u atomicu è restituisce u valore cuntenutu.
    ///
    /// Questu hè sicuru perchè passà `self` per valore garantisce chì nisun altru thread accede simultaneamente à i dati atomici.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Carica un valore da u puntatore.
    ///
    /// `load` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.
    /// I valori pussibuli sò [`SeqCst`], [`Acquire`] è [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` hè [`Release`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Memorizza un valore in u puntatore.
    ///
    /// `store` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.
    /// I valori pussibuli sò [`SeqCst`], [`Release`] è [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` hè [`Acquire`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Memorizza un valore in u puntatore, restituendu u valore precedente.
    ///
    /// `swap` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
    /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
    ///
    ///
    /// **Note:** Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche nantu à i puntatori.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Memorizza un valore in u puntatore se u valore attuale hè u listessu chè u valore `current`.
    ///
    /// U valore di ritornu hè sempre u valore precedente.S'ellu hè uguale à `current`, allora u valore hè statu aggiornatu.
    ///
    /// `compare_and_swap` piglia ancu un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.
    /// Notate chì ancu quandu si utilizza [`AcqRel`], l'operazione puderia fiascà è dunque solu eseguisce una carica `Acquire`, ma ùn avè micca semantica `Release`.
    /// Aduprà [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`] se accade, è aduprà [`Release`] rende a parte di carica [`Relaxed`].
    ///
    /// **Note:** Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche nantu à i puntatori.
    ///
    /// # Migrà à `compare_exchange` è `compare_exchange_weak`
    ///
    /// `compare_and_swap` hè equivalente à `compare_exchange` cù a seguente mappatura per l'ordine di memoria:
    ///
    /// Originale |Successu |Fallimentu
    /// -------- | ------- | -------
    /// Relaxed |Relaxed |Relaxed Acquire |Acquire |Acquistà Release |Release |Relaxed AcqRel |AcqRel |Acquistà SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` hè permessu di fallu spuriously ancu quandu u paragone riesce, chì permette à u compilatore di generà un codice di assemblea megliu quandu u paragone è u swap sò aduprati in un loop.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Memorizza un valore in u puntatore se u valore attuale hè u listessu chè u valore `current`.
    ///
    /// U valore di ritornu hè un risultatu chì indica se u novu valore hè statu scrittu è chì cuntene u valore precedente.
    /// In successu, questu valore hè garantitu per esse uguale à `current`.
    ///
    /// `compare_exchange` piglia dui argumenti [`Ordering`] per discrive l'ordine di memoria di questa operazione.
    /// `success` descrive l'ordine richiestu per l'operazione di lettura-mudificazione-scrittura chì si face se u paragone cù `current` riesce.
    /// `failure` descrive l'ordine richiestu per l'operazione di carica chì si faci quandu u paragone fiasca.
    /// Aduprà [`Acquire`] cum'è ordine di successu face u magazinu parte di questa operazione [`Relaxed`], è aduprà [`Release`] face u caricu di successu [`Relaxed`].
    ///
    /// L'ordine di fallimentu pò esse solu [`SeqCst`], [`Acquire`] o [`Relaxed`] è deve esse equivalente o più debule di l'ordine di successu.
    ///
    /// **Note:** Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche nantu à i puntatori.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Memorizza un valore in u puntatore se u valore attuale hè u listessu chè u valore `current`.
    ///
    /// A differenza di [`AtomicPtr::compare_exchange`], sta funzione hè permessa di fiascà spuriosamente ancu quandu u paragone riesce, ciò chì pò traduce in un codice più efficiente in alcune piattaforme.
    ///
    /// U valore di ritornu hè un risultatu chì indica se u novu valore hè statu scrittu è chì cuntene u valore precedente.
    ///
    /// `compare_exchange_weak` piglia dui argumenti [`Ordering`] per discrive l'ordine di memoria di questa operazione.
    /// `success` descrive l'ordine richiestu per l'operazione di lettura-mudificazione-scrittura chì si face se u paragone cù `current` riesce.
    /// `failure` descrive l'ordine richiestu per l'operazione di carica chì si faci quandu u paragone fiasca.
    /// Aduprà [`Acquire`] cum'è ordine di successu face u magazinu parte di questa operazione [`Relaxed`], è aduprà [`Release`] face u caricu di successu [`Relaxed`].
    /// L'ordine di fallimentu pò esse solu [`SeqCst`], [`Acquire`] o [`Relaxed`] è deve esse equivalente o più debule di l'ordine di successu.
    ///
    /// **Note:** Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche nantu à i puntatori.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SICUREZZA: Questu intrinsicu ùn hè micca sicuru perchè opera nantu à un puntatore crudu
        // ma sapemu sicuramente chì u puntatore hè validu (l'avemu solu ottenutu da un `UnsafeCell` chì avemu da riferimentu) è l'operazione atomica stessa ci permette di mutà in modu sicuru u cuntenutu `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Fetches u valore, è applica una funzione chì restituisce un novu valore opzionale.Restituisce un `Result` di `Ok(previous_value)` se a funzione restituisce `Some(_)`, altrimenti `Err(previous_value)`.
    ///
    /// Note: Questa pò chjamà a funzione parechje volte se u valore hè statu cambiatu da altri fili in u frattempu, basta chì a funzione restituisce `Some(_)`, ma a funzione serà stata applicata una sola volta à u valore almacenatu.
    ///
    ///
    /// `fetch_update` piglia dui argumenti [`Ordering`] per discrive l'ordine di memoria di questa operazione.
    /// U primu descrive l'ordine richiestu per quandu l'operazione finalmente riesce mentre u secondu descrive l'ordine richiestu per i carichi.
    /// Queste currispondenu à l'ordine di successu è di fallimentu di [`AtomicPtr::compare_exchange`] rispettivamente.
    ///
    /// Aduprà [`Acquire`] cum'è ordine di successu face u magazinu parte di questa operazione [`Relaxed`], è aduprà [`Release`] face u carcu finale successu [`Relaxed`].
    /// L'ordine di carica (failed) pò esse solu [`SeqCst`], [`Acquire`] o [`Relaxed`] è deve esse equivalente o più debule di l'ordine di successu.
    ///
    /// **Note:** Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche nantu à i puntatori.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Converte un `bool` in un `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Questa macro finisce per esse inutilizzata in alcune architetture.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Un tippu interu chì pò esse spartutu in modu sicuru trà filetti.
        ///
        /// Stu tipu hà a stessa rapprisintazione in memoria cum'è u tippu interu sottostante, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Per sapè di più nantu à e sferenze trà i tippi atomichi è i tippi non atomichi è ancu nantu à l'infurmazioni nantu à a purtabilità di stu tippu, per piacè vede u [module-level documentation].
        ///
        ///
        /// **Note:** Stu tipu hè dispunibule solu nantu à e piattaforme chì supportanu carichi atomichi è magazzini di [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Un interu atomicu inizializatu à `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Send hè implicitamente implementatu.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Crea un novu interu atomicu.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Restituisce un riferimentu mutevule à u numeru interu sottostante.
            ///
            /// Questu hè sicuru perchè a riferenza mutevule garantisce chì nisun altru thread accede simultaneamente à i dati atomici.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// let mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - a riferenza mutevule garantisce una pruprietà unica.
                //  - l'alineamentu di `$int_type` è `Self` hè listessu, cum'è prumessu da $cfg_align è verificatu sopra.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Cunsuma u atomicu è restituisce u valore cuntenutu.
            ///
            /// Questu hè sicuru perchè passà `self` per valore garantisce chì nisun altru thread accede simultaneamente à i dati atomici.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Carica un valore da u numeru interu atomicu.
            ///
            /// `load` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.
            /// I valori pussibuli sò [`SeqCst`], [`Acquire`] è [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics se `order` hè [`Release`] o [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Memorizza un valore in u numeru interu atomicu.
            ///
            /// `store` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.
            ///  I valori pussibuli sò [`SeqCst`], [`Release`] è [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics se `order` hè [`Acquire`] o [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Memorizza un valore in u numeru atomicu, restituendu u valore precedente.
            ///
            /// `swap` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
            /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
            ///
            ///
            /// **Nota**: Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche sopra
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Memorizza un valore in u numeru interu atomicu se u valore attuale hè uguale à u valore `current`.
            ///
            /// U valore di ritornu hè sempre u valore precedente.S'ellu hè uguale à `current`, allora u valore hè statu aggiornatu.
            ///
            /// `compare_and_swap` piglia ancu un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.
            /// Notate chì ancu quandu si utilizza [`AcqRel`], l'operazione puderia fiascà è dunque solu eseguisce una carica `Acquire`, ma ùn avè micca semantica `Release`.
            ///
            /// Aduprà [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`] se accade, è aduprà [`Release`] rende a parte di carica [`Relaxed`].
            ///
            /// **Nota**: Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche sopra
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migrà à `compare_exchange` è `compare_exchange_weak`
            ///
            /// `compare_and_swap` hè equivalente à `compare_exchange` cù a seguente mappatura per l'ordine di memoria:
            ///
            /// Originale |Successu |Fallimentu
            /// -------- | ------- | -------
            /// Relaxed |Relaxed |Relaxed Acquire |Acquire |Acquistà Release |Release |Relaxed AcqRel |AcqRel |Acquistà SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` hè permessu di fallu spuriously ancu quandu u paragone riesce, chì permette à u compilatore di generà un codice di assemblea megliu quandu u paragone è u swap sò aduprati in un loop.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Memorizza un valore in u numeru interu atomicu se u valore attuale hè uguale à u valore `current`.
            ///
            /// U valore di ritornu hè un risultatu chì indica se u novu valore hè statu scrittu è chì cuntene u valore precedente.
            /// In successu, questu valore hè garantitu per esse uguale à `current`.
            ///
            /// `compare_exchange` piglia dui argumenti [`Ordering`] per discrive l'ordine di memoria di questa operazione.
            /// `success` descrive l'ordine richiestu per l'operazione di lettura-mudificazione-scrittura chì si face se u paragone cù `current` riesce.
            /// `failure` descrive l'ordine richiestu per l'operazione di carica chì si faci quandu u paragone fiasca.
            /// Aduprà [`Acquire`] cum'è ordine di successu face u magazinu parte di questa operazione [`Relaxed`], è aduprà [`Release`] face u caricu di successu [`Relaxed`].
            ///
            /// L'ordine di fallimentu pò esse solu [`SeqCst`], [`Acquire`] o [`Relaxed`] è deve esse equivalente o più debule di l'ordine di successu.
            ///
            /// **Nota**: Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche sopra
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Memorizza un valore in u numeru interu atomicu se u valore attuale hè uguale à u valore `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// sta funzione hè permessa di fiascà spuriosamente ancu quandu u paragone riesce, ciò chì pò traduce in un codice più efficace in certe piattaforme.
            /// U valore di ritornu hè un risultatu chì indica se u novu valore hè statu scrittu è chì cuntene u valore precedente.
            ///
            /// `compare_exchange_weak` piglia dui argumenti [`Ordering`] per discrive l'ordine di memoria di questa operazione.
            /// `success` descrive l'ordine richiestu per l'operazione di lettura-mudificazione-scrittura chì si face se u paragone cù `current` riesce.
            /// `failure` descrive l'ordine richiestu per l'operazione di carica chì si faci quandu u paragone fiasca.
            /// Aduprà [`Acquire`] cum'è ordine di successu face u magazinu parte di questa operazione [`Relaxed`], è aduprà [`Release`] face u caricu di successu [`Relaxed`].
            ///
            /// L'ordine di fallimentu pò esse solu [`SeqCst`], [`Acquire`] o [`Relaxed`] è deve esse equivalente o più debule di l'ordine di successu.
            ///
            /// **Nota**: Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche sopra
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// let mut old= val.load(Ordering::Relaxed);
            /// loop {let new=vechju * 2;
            ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Aghjunghje à u valore attuale, restituendu u valore precedente.
            ///
            /// Questa operazione avvolge u overflow.
            ///
            /// `fetch_add` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
            /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
            ///
            ///
            /// **Nota**: Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche sopra
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Sottrae u valore attuale, restituendu u valore precedente.
            ///
            /// Questa operazione avvolge u overflow.
            ///
            /// `fetch_sub` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
            /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
            ///
            ///
            /// **Nota**: Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche sopra
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" cù u valore attuale.
            ///
            /// Esegue un'operazione bitwise "and" nantu à u valore attuale è l'argumentu `val`, è mette u novu valore à u risultatu.
            ///
            /// Restituisce u valore precedente.
            ///
            /// `fetch_and` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
            /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
            ///
            ///
            /// **Nota**: Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche sopra
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" cù u valore attuale.
            ///
            /// Esegue un'operazione bitwise "nand" nantu à u valore attuale è l'argumentu `val`, è mette u novu valore à u risultatu.
            ///
            /// Restituisce u valore precedente.
            ///
            /// `fetch_nand` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
            /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
            ///
            ///
            /// **Nota**: Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche sopra
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" cù u valore attuale.
            ///
            /// Esegue un'operazione bitwise "or" nantu à u valore attuale è l'argumentu `val`, è mette u novu valore à u risultatu.
            ///
            /// Restituisce u valore precedente.
            ///
            /// `fetch_or` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
            /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
            ///
            ///
            /// **Nota**: Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche sopra
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" cù u valore attuale.
            ///
            /// Esegue un'operazione bitwise "xor" nantu à u valore attuale è l'argumentu `val`, è mette u novu valore à u risultatu.
            ///
            /// Restituisce u valore precedente.
            ///
            /// `fetch_xor` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
            /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
            ///
            ///
            /// **Nota**: Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche sopra
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Fetches u valore, è applica una funzione chì restituisce un novu valore opzionale.Restituisce un `Result` di `Ok(previous_value)` se a funzione restituisce `Some(_)`, altrimenti `Err(previous_value)`.
            ///
            /// Note: Questa pò chjamà a funzione parechje volte se u valore hè statu cambiatu da altri fili in u frattempu, basta chì a funzione restituisce `Some(_)`, ma a funzione serà stata applicata una sola volta à u valore almacenatu.
            ///
            ///
            /// `fetch_update` piglia dui argumenti [`Ordering`] per discrive l'ordine di memoria di questa operazione.
            /// U primu descrive l'ordine richiestu per quandu l'operazione finalmente riesce mentre u secondu descrive l'ordine richiestu per i carichi.Queste currispondenu à l'ordine di successu è fallimentu di
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Aduprà [`Acquire`] cum'è ordine di successu face u magazinu parte di questa operazione [`Relaxed`], è aduprà [`Release`] face u carcu finale successu [`Relaxed`].
            /// L'ordine di carica (failed) pò esse solu [`SeqCst`], [`Acquire`] o [`Relaxed`] è deve esse equivalente o più debule di l'ordine di successu.
            ///
            /// **Nota**: Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche sopra
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Ordine: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Ordine: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Massimu cù u valore attuale.
            ///
            /// Trova u massimu di u valore attuale è l'argumentu `val`, è mette u novu valore à u risultatu.
            ///
            /// Restituisce u valore precedente.
            ///
            /// `fetch_max` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
            /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
            ///
            ///
            /// **Nota**: Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche sopra
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// lascia barra=42;
            /// lascia max_foo=foo.fetch_max (barra, Ordering::SeqCst).max(bar);
            /// affirmà! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimu cù u valore attuale.
            ///
            /// Trova u minimu di u valore attuale è l'argumentu `val`, è mette u novu valore à u risultatu.
            ///
            /// Restituisce u valore precedente.
            ///
            /// `fetch_min` piglia un argumentu [`Ordering`] chì descrive l'ordine di memoria di questa operazione.Tutti i modi di ordine sò pussibuli.
            /// Innota chì l'usu [`Acquire`] face u magazinu parte di questa operazione [`Relaxed`], è l'usu [`Release`] face a parte di carica [`Relaxed`].
            ///
            ///
            /// **Nota**: Stu metudu hè dispunibule solu nantu à e piattaforme chì supportanu l'operazioni atomiche sopra
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// lascia barra=12;
            /// lascia min_foo=foo.fetch_min (barra, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: e razze di dati sò impedite da l'intrinsicu atomicu.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Restituisce un puntatore mutabile all'intero sottostante.
            ///
            /// Fà letture è scrive non atomiche nantu à u numeru interu resultante pò esse una corsa di dati.
            /// Stu metudu hè principalmente utile per FFI, induve a firma di funzione pò aduprà
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Riturnà un puntatore `*mut` da una riferenza cumuna à questu atomicu hè sicuru perchè i tippi atomichi travaglianu cù mutabilità interiore.
            /// Tutte e modifiche di un atomicu cambianu u valore per mezu di una riferenza spartuta, è ponu fà lu in modu sicuru cù u tempu chì usanu operazioni atomiche.
            /// Ogni usu di u puntatore grezzu restituitu richiede un bloccu `unsafe` è deve sempre rispettà a stessa restrizione: l'operazioni annantu à ellu devenu esse atomiche.
            ///
            ///
            /// # Examples
            ///
            /// "" ignora (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SICUREZZA: Sicura finu à chì `my_atomic_op` hè atomicu.
            /// periculosu {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Restituisce u valore precedente (cum'è __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Restituisce u valore precedente (cum'è __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// restituisce u valore massimu (paragone firmatu)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// restituisce u valore min (paragone firmatu)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// restituisce u valore massimu (paragone senza firma)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// restituisce u valore min (paragone senza firma)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Una scherma atomica.
///
/// Sicondu l'ordine specificatu, una recinzione impedisce à u compilatore è a CPU di riordinà certi tipi di operazioni di memoria intornu.
/// Ciò crea sincronizazioni-cù relazioni trà questu è operazioni atomiche o recinzioni in altri fili.
///
/// Una fence 'A' chì hà (almenu) [`Release`] chì ordina a semantica, si sincronizza cù una fence 'B' cù (almenu) [`Acquire`] semantica, se è solu se esistenu operazioni X è Y, tramindui chì operanu nantu à un oggettu atomicu 'M' tale chì A hè sequenziata prima X, Y hè sincronizatu prima chì B è Y osserva u cambiamentu in M.
/// Questu furnisce una dipendenza accaduta prima di A è B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// L'operazioni atomiche cù a semantica [`Release`] o [`Acquire`] ponu ancu sincronizà cù una rete.
///
/// Una recinzione chì hà urdinatu [`SeqCst`], in più di avè sia semantica [`Acquire`] è [`Release`], participa à l'ordine di prugramma glubale di l'altre operazioni è/o recinzioni [`SeqCst`].
///
/// Accetta cumandamenti [`Acquire`], [`Release`], [`AcqRel`] è [`SeqCst`].
///
/// # Panics
///
/// Panics se `order` hè [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Una primitiva esclusione mutuale basata nantu à spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Aspittate finu à chì u vechju valore hè `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Questa fence si sincronizza-cù u magazinu in `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SEGURITÀ: aduprà una rete atomica hè sicuru.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Un recintu di memoria di compilatore.
///
/// `compiler_fence` ùn emette alcun codice di macchina, ma limita i generi di memoria chì riordine u compilatore hè permessu di fà.Specificamente, sicondu a semantica [`Ordering`] data, u compilatore pò esse privatu di muvimentu di letture o scritture prima o dopu a chjamata à l'altra parte di a chjamata à `compiler_fence`.Nutate bè chì **ùn** impedisce micca à u *hardware* di fà tale riordine.
///
/// Questu ùn hè micca un prublema in un cuntestu di esecuzione à filu unicu, ma quandu altri fili ponu mudificà a memoria in listessu tempu, sò necessarie primitive di sincronizazione più forti cume [`fence`].
///
/// U riordine impeditu da e diverse semantiche d'ordine sò:
///
///  - cù [`SeqCst`], ùn hè permessu nisun riordenamentu di leghje è scrive in questu puntu.
///  - cù [`Release`], e letture è e scritture precedenti ùn ponu esse spostate passate e scritture successive.
///  - cù [`Acquire`], e letture è scrive successive ùn ponu micca esse spostate davanti à e letture precedenti.
///  - cù [`AcqRel`], entrambe e regule sopra sò applicate.
///
/// `compiler_fence` hè generalmente utile solu per impedisce un filu di corse *cun ellu stessu*.Vale à dì, se un filu datu esegue un pezzu di codice, è poi hè interrotto, è cumencia à esecutà u codice in altrò (mentre hè sempre in u stessu filu, è cuncettualmente sempre in u stessu core).In i prugrammi tradiziunali, questu pò accade solu quandu un gestore di segnale hè registratu.
/// In più codici di livellu bassu, tali situazioni ponu ancu nasce quandu si maneghjanu l'interruzzioni, quandu si implementanu fili verdi cù preempzione, ecc.
/// I lettori curiosi sò incuragiti à leghje a discussione di u kernel Linux di [memory barriers].
///
/// # Panics
///
/// Panics se `order` hè [`Relaxed`].
///
/// # Examples
///
/// Senza `compiler_fence`, u `assert_eq!` in u codice seguente ùn hè * ** garantitu per successu, malgradu tuttu ciò chì accade in un unicu filu.
/// Per vede perchè, ricordate chì u compilatore hè liberu di scambià i negozii per `IMPORTANT_VARIABLE` è `IS_READ` postu chì sò tramindui `Ordering::Relaxed`.S'ellu si faci, è u gestore di u signale hè invucatu subitu dopu chì `IS_READY` sia aggiornatu, allora u gestore di u segnale vedrà `IS_READY=1`, ma `IMPORTANT_VARIABLE=0`.
/// Aduprà un `compiler_fence` rimedi sta situazione.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // impedisce chì scritti precedenti sianu sposti al di là di stu puntu
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SEGURITÀ: aduprà una rete atomica hè sicuru.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Signala u processatore chì si trova in un spin-loop occupatu-aspettatu ("spin lock").
///
/// Sta funzione hè deprecata in favore di [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}