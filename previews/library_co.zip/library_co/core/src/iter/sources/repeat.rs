use crate::iter::{FusedIterator, TrustedLen};

/// Crea un novu iteratore chì ripete senza fine un elementu unicu.
///
/// A funzione `repeat()` ripete un valore unicu ripetutamente.
///
/// L'iteratori infiniti cum'è `repeat()` sò spessu usati cù adattatori cum'è [`Iterator::take()`], per rende li finiti.
///
/// Se l'elementu tipu di l'iteratore chì avete bisognu ùn implementa micca `Clone`, o se ùn vulete micca mantene l'elementu ripetutu in memoria, pudete invece aduprà a funzione [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// use std::iter;
///
/// // u numeru quattru 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // iè, sempre quattru
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Andà finitu cù [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // quellu ultimu esempiu era troppu quattru.Avemu solu quattru quattru.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... è avà avemu finitu
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Un iteratore chì ripete un elementu senza fine.
///
/// Questu `struct` hè creatu da a funzione [`repeat()`].Vede a so ducumentazione per più.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}