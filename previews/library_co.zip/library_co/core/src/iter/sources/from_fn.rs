use crate::fmt;

/// Crea un novu iteratore induve ogni iterazione chjama a chiusura furnita `F: FnMut() -> Option<T>`.
///
/// Questu permette di creà un iteratore persunalizatu cù qualsiasi cumpurtamentu senza aduprà a sintassi più dettagliata di creà un tippu dedicatu è di implementà u [`Iterator`] trait per questu.
///
/// Innota chì l'iteratore `FromFn` ùn face micca supposizioni nantu à u cumpurtamentu di a chiusura, è dunque cun prudenza ùn implementa micca [`FusedIterator`], o annulla [`Iterator::size_hint()`] da u so `(0, None)` predefinitu.
///
///
/// A chjusura pò aduprà catture è u so ambiente per tracciare u statu à traversu l'iterazioni.A seconda di cume si usa l'iteratore, questu pò richiede di specificà a parola chiave [`move`] nantu à a chiusura.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Implantemu torna l'iteratore di contatore da [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Incrementa u nostru conte.Hè per quessa chì avemu principiatu à zeru.
///     count += 1;
///
///     // Verificate se avemu finitu di cuntà o micca.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Un iteratore induve ogni iterazione chjama a chiusura furnita `F: FnMut() -> Option<T>`.
///
/// Questu `struct` hè creatu da a funzione [`iter::from_fn()`].
/// Vede a so ducumentazione per più.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}