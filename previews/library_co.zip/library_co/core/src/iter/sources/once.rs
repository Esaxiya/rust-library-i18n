use crate::iter::{FusedIterator, TrustedLen};

/// Crea un iteratore chì dà un elementu esattamente una volta.
///
/// Questu hè comunmente adupratu per adattà un valore unicu in un [`chain()`] di altri tippi d'iterazione.
/// Forse avete un iteratore chì copre quasi tuttu, ma avete bisognu di un casu speciale in più.
/// Forse avete una funzione chì funziona nantu à l'iteratori, ma avete solu bisognu di trattà un valore.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// use std::iter;
///
/// // unu hè u numeru u più solitariu
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // solu unu, hè tuttu ciò chì avemu
/// assert_eq!(None, one.next());
/// ```
///
/// Incatenà inseme cù un altru iteratore.
/// Diciamu chì vulemu iterà annantu à ogni fugliale di u repertoriu `.foo`, ma ancu un schedariu di cunfigurazione,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // avemu bisognu di cunvertisce da un iteratore di DirEntry-s in un iteratore di PathBufs, allora usemu a mappa
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // avà, u nostru iteratore solu per u nostru schedariu di cunfigurazione
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // incatenà i dui iteratori inseme in un grande iteratore
/// let files = dirs.chain(config);
///
/// // questu ci darà tutti i fugliali in .foo è .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Un iteratore chì dà un elementu esattamente una volta.
///
/// Questu `struct` hè creatu da a funzione [`once()`].Vede a so ducumentazione per più.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}