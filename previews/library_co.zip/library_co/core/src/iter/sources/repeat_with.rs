use crate::iter::{FusedIterator, TrustedLen};

/// Crea un novu iteratore chì ripete elementi di u tippu `A` senza fine applicendu a chiusura furnita, u ripetitore, `F: FnMut() -> A`.
///
/// A funzione `repeat_with()` chjama u ripetitore ripetutamente.
///
/// L'iteratori infiniti cum'è `repeat_with()` sò spessu usati cù adattatori cum'è [`Iterator::take()`], per rende li finiti.
///
/// Se u tippu d'elementu di l'iteratore chì avete bisognu implementa [`Clone`], è hè bè di mantene l'elementu surghjente in memoria, duvete invece aduprà a funzione [`repeat()`].
///
///
/// Un iteratore pruduttu da `repeat_with()` ùn hè micca un [`DoubleEndedIterator`].
/// Se avete bisognu di `repeat_with()` per restituisce un [`DoubleEndedIterator`], per piacè aprite un prublema GitHub spieghendu u vostru casu d'usu.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// use std::iter;
///
/// // supponemu chì avemu qualchì valore di un tipu chì ùn hè micca `Clone` o chì ùn volenu micca avè in memoria solu perchè hè caru:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // un valore particulare per sempre:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Usendu a mutazione è andendu finitu:
///
/// ```rust
/// use std::iter;
///
/// // Da u zeroth à a terza putenza di dui:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... è avà avemu finitu
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Un iteratore chì ripete elementi di tippu `A` senza fine applicendu a chjusura furnita `F: FnMut() -> A`.
///
///
/// Questu `struct` hè creatu da a funzione [`repeat_with()`].
/// Vede a so ducumentazione per più.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}