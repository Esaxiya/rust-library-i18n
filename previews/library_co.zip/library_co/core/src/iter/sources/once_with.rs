use crate::iter::{FusedIterator, TrustedLen};

/// Crea un iteratore chì genera pigmente un valore esattamente una volta invucendu a chiusura furnita.
///
/// Questu hè comunmente adupratu per adattà un generatore di valore unicu in un [`chain()`] di altri tippi d'iterazione.
/// Forse avete un iteratore chì copre quasi tuttu, ma avete bisognu di un casu speciale in più.
/// Forse avete una funzione chì funziona nantu à l'iteratori, ma avete solu bisognu di trattà un valore.
///
/// A cuntrariu di [`once()`], sta funzione genererà pigmente u valore à dumanda.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// use std::iter;
///
/// // unu hè u numeru u più solitariu
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // solu unu, hè tuttu ciò chì avemu
/// assert_eq!(None, one.next());
/// ```
///
/// Incatenà inseme cù un altru iteratore.
/// Diciamu chì vulemu iterà annantu à ogni fugliale di u repertoriu `.foo`, ma ancu un schedariu di cunfigurazione,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // avemu bisognu di cunvertisce da un iteratore di DirEntry-s in un iteratore di PathBufs, allora usemu a mappa
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // avà, u nostru iteratore solu per u nostru schedariu di cunfigurazione
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // incatenà i dui iteratori inseme in un grande iteratore
/// let files = dirs.chain(config);
///
/// // questu ci darà tutti i fugliali in .foo è .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Un iteratore chì dà un elementu unicu di tipu `A` applicendu a chjusura furnita `F: FnOnce() -> A`.
///
///
/// Questu `struct` hè creatu da a funzione [`once_with()`].
/// Vede a so ducumentazione per più.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}