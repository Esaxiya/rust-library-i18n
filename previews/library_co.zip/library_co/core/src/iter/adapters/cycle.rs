use crate::{iter::FusedIterator, ops::Try};

/// Un iteratore chì si ripete senza fine.
///
/// Questu `struct` hè creatu da u metudu [`cycle`] in [`Iterator`].
/// Vede a so ducumentazione per più.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // l'iteratore di cicli hè vuotu o infinitu
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // iterate cumpletamente l'iteratore attuale.
        // questu hè necessariu perchè `self.iter` pò esse viotu ancu quandu `self.orig` ùn hè micca
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // compie un ciclu cumpletu, tenendu traccia di sì l'iteratore ciclatu hè vuotu o micca.
        // avemu bisognu di vultà prestu in casu d'un iteratore vacante per prevene un loop infinitu
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // Nisun override `fold`, perchè `fold` ùn hà micca assai sensu per `Cycle`, è ùn pudemu micca fà nunda di megliu cà u predefinitu.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}