use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Questu trait furnisce accessu transitivu à a fonte-stage in un pipeline di interatore-adattatore in e condizioni chì
/// * a fonte d'iteratore `S` stessa implementa `SourceIter<Source = S>`
/// * ci hè una implementazione di delegazione di questu trait per ogni adattatore in a pipeline trà a fonte è u consumatore di pipeline.
///
/// Quandu a surghjente hè una struttura iteratrice pruprietaria (comunemente chjamata `IntoIter`) allora questu pò esse utile per specializà implementazioni [`FromIterator`] o recuperà l'elementi restanti dopu chì un iteratore sia statu parzialmente esauritu.
///
///
/// Nota chì l'implementazioni ùn anu micca necessariamente da furnisce l'accessu à a fonte più interna di un pipeline.Un adattatore intermediu statale puderia valutà cun impazienza una parte di u pipeline è espone u so almacenamentu internu cum'è fonte.
///
/// U trait hè periculosu perchè l'implementatori devenu rispettà proprietà di sicurezza addiziunali.
/// Vede [`as_inner`] per i dettagli.
///
/// # Examples
///
/// Recuperà una fonte parzialmente cunsumata:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Una tappa surghjente in una pipeline di iteratore.
    type Source: Iterator;

    /// Recuperate a fonte di un pipeline iteratore.
    ///
    /// # Safety
    ///
    /// L'implementazioni di devenu restituisce u listessu riferimentu mutevule per a so vita, a menu chì ùn sianu rimpiazzati da un chjamante.
    /// I chjamanti ponu rimpiazzà solu u riferimentu quandu fermanu l'iterazione è lasciate u pipeline di l'iteratore dopu avè estrattu a fonte.
    ///
    /// Ciò significa chì l'adattatori di iteratore ponu fidà si chì a fonte ùn cambiessi durante l'iterazione ma ùn ponu micca fidà si in e so implementazioni Drop.
    ///
    /// Implementà stu metudu significa chì l'adattatori rinuncianu à l'accessu solu privatu à a so surghjente è ponu solu s'appoghja nantu à e garanzie fatte secondu i tippi di ricettori di metudi.
    /// A mancanza di accessu ristrettu richiede ancu chì l'adattatori devenu rispettà l'API publica di a fonte ancu quandu anu accessu à i so interni.
    ///
    /// I chjamanti à a so volta devenu aspettà chì a fonte sia in qualunque statu chì sia coerente cù a so API pubblica postu chì l'adattatori chì si trovanu trà ella è a fonte anu u listessu accessu.
    /// In particulare un adattatore pò avè cunsumatu più elementi di quellu strettamente necessariu.
    ///
    /// L'obiettivu generale di questi requisiti hè di lascià u consumatore di un pipeline aduprà
    /// * tuttu ciò chì ferma in a surghjente dopu chì l'iterazione hà cessatu
    /// * a memoria chì hè diventata inutilizzata avanzendu un iteratore cunsumante
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Un adattatore iteratore chì produce output finchè l'iteratore sottostante produce valori `Result::Ok`.
///
///
/// Se si trova un errore, l'iteratore si ferma è l'errore hè conservatu.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Trasfurmate l'iteratore datu cum'è se cede un `T` invece di un `Result<T, _>`.
/// Ogni errore fermerà l'iteratore interiore è u risultatu generale serà un errore.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}