//! Iterazione esterna cumpunibile.
//!
//! Se vi truvate cun una raccolta di qualchì tipu, è avete bisognu di fà una operazione nantu à l'elementi di detta raccolta, scapperai rapidamente in 'iterators'.
//! L'iteratori sò assai usati in u codice idiomaticu Rust, dunque vale a pena di cunnosce cun elli.
//!
//! Prima di spiegà ne di più, parlemu cumu hè strutturatu stu modulu:
//!
//! # Organization
//!
//! Stu modulu hè largamente organizatu per tippu:
//!
//! * [Traits] sò a parte principale: questi traits definiscenu chì tippu d'iteratori esistenu è ciò chì pudete fà cun elli.I metudi di sti traits valenu a pena di mette qualchì tempu di studiu in più.
//! * [Functions] furnite alcuni modi utili per creà alcuni iteratori di basa.
//! * [Structs] sò spessu i tippi di ritornu di i varii metudi nantu à u modulu traits.Di solitu vulerete fighjà u metudu chì crea u `struct`, piuttostu chè u `struct` stessu.
//! Per sapenne di più nantu à perchè, vedi '[Implementing Iterator](#Implementing-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Eccu!Scavemu in iteratori.
//!
//! # Iterator
//!
//! U core è l'anima di stu modulu hè u [`Iterator`] trait.U core di [`Iterator`] s'assumiglia à questu:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Un iteratore hà un metudu, [`next`], chì quandu hè chjamatu, restituisce una [`Opzione`]`<Item>`.
//! [`next`] restituverà [`Some(Item)`] fintantu chì ci sò elementi, è una volta chì sò stati tutti stanchi, tornerà `None` per indicà chì l'iterazione hè finita.
//! Iteratori individuali ponu sceglie di ripiglià l'iterazione, è cusì chjamà [`next`] di novu pò o ùn puderà eventualmente ripiglià torna [`Some(Item)`] à qualchì puntu (per esempiu, vede [`TryIter`]).
//!
//!
//! A definizione cumpleta di [`Iterator`] include ancu altri metudi, ma sò metodi predefiniti, custruiti sopra [`next`], è cusì li uttenite gratuitamente.
//!
//! L'iteratori sò ancu cumpunibili, è hè cumunu di incatenalli per fà forme più cumplesse di trasfurmazioni.Vede a sezione [Adapters](#adapters) sottu per più dettagli.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # E trè forme di iterazione
//!
//! Ci hè trè metudi cumuni chì ponu creà iteratori da una cullizzioni:
//!
//! * `iter()`, chì itera annantu à `&T`.
//! * `iter_mut()`, chì itera annantu à `&mut T`.
//! * `into_iter()`, chì itera annantu à `T`.
//!
//! Diverse cose in a libreria standard ponu implementà una o più di e trè, induve hè appruvata.
//!
//! # Implementazione di l'iteratore
//!
//! A creazione di un iteratore di u vostru propiu implica duie tappe: creà un `struct` per tene u statu di l'iteratore, è poi implementà [`Iterator`] per quellu `struct`.
//! Eccu perchè ci sò tanti `struct` in stu modulu: ci n'hè unu per ogni iteratore è adattatore d'iteratore.
//!
//! Facemu un iteratore chjamatu `Counter` chì conta da `1` à `5`:
//!
//! ```
//! // Prima, a struct:
//!
//! /// Un iteratore chì conta da unu à cinque
//! struct Counter {
//!     count: usize,
//! }
//!
//! // vulemu chì u nostru conte cominci da unu, allora aghjustemu un metudu new() per aiutà.
//! // Questu ùn hè micca strettamente necessariu, ma hè cunveniente.
//! // Innota chì cuminciamu `count` à zero, vedemu perchè in l'implementazione `next()`'s quì sottu.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Dopu, implementemu `Iterator` per u nostru `Counter`:
//!
//! impl Iterator for Counter {
//!     // cunteremu cun usize
//!     type Item = usize;
//!
//!     // next() hè l'unicu metudu necessariu
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Incrementa u nostru conte.Hè per quessa chì avemu principiatu à zeru.
//!         self.count += 1;
//!
//!         // Verificate se avemu finitu di cuntà o micca.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // È avà a pudemu aduprà!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Chjamà [`next`] in questu modu si ripete.Rust hà una custruzzione chì pò chjamà [`next`] nantu à u vostru iteratore, finu à chì ghjunghje à `None`.Andemu nantu à quellu prossimu.
//!
//! Innota ancu chì `Iterator` furnisce una implementazione predefinita di metudi cum'è `nth` è `fold` chì chjamanu `next` internamente.
//! Tuttavia, hè ancu pussibule di scrive una implementazione persunalizata di metudi cum'è `nth` è `fold` se un iteratore li pò calculà più efficacemente senza chjamà `next`.
//!
//! # `for` cicli è `IntoIterator`
//!
//! A sintassi di ciclu `for` di Rust hè in realtà zuccheru per l'iteratori.Eccu un esempiu di basa di `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Questu stamperà i numeri da unu à cinque, ognunu nantu à a so linea.Ma rimarcherete qualcosa quì: ùn avemu mai chjamatu nunda nant'à u nostru vector per pruduce un iteratore.Chì dà?
//!
//! Ci hè un trait in a biblioteca standard per cunvertisce qualcosa in un iteratore: [`IntoIterator`].
//! Questu trait hà un metudu, [`into_iter`], chì converte a cosa chì implementa [`IntoIterator`] in un iteratore.
//! Fighjemu dinò quellu ciclu `for`, è ciò chì u compilatore a cunverte in:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-zuccheru questu in:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Prima, chjamemu `into_iter()` nantu à u valore.Dopu, truvemu nantu à l'iteratore chì ritorna, chjamendu [`next`] ripetutamente finu à vedemu un `None`.
//! À questu puntu, avemu `break` fora di u ciclu, è avemu finitu l'iterazione.
//!
//! Ci hè un pezzu più suttu quì: a biblioteca standard cuntene una interessante implementazione di [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! In altre parolle, tutti [`Iterator`] implementanu [`IntoIterator`], da solu tornendu elli stessi.Questu significa duie cose:
//!
//! 1. Se state scrivendu un [`Iterator`], pudete aduprà cun un loop `for`.
//! 2. Se create una raccolta, implementà [`IntoIterator`] per quessa permetterà a vostra raccolta da aduprà cù u ciclu `for`.
//!
//! # Iterazione per riferimentu
//!
//! Postu chì [`into_iter()`] piglia `self` per valore, aduprendu un ciclu `for` per iterà nantu à una cullezzione cunsuma quella cullezzione.Spessu, pudete vulete iterà nantu à una raccolta senza cunsumalla.
//! Parechje cullezzione offre metudi chì furniscenu iteratori nantu à e referenze, cunvenziunale chjamate `iter()` è `iter_mut()` rispettivamente:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` hè sempre pruprietariu di sta funzione.
//! ```
//!
//! Se un tipu di cullezzione `C` furnisce `iter()`, generalmente implementa ancu `IntoIterator` per `&C`, cù una implementazione chì chjama solu `iter()`.
//! In listessu modu, una raccolta `C` chì furnisce `iter_mut()` implementa generalmente `IntoIterator` per `&mut C` delegendu à `iter_mut()`.Questu permette una stenografia cunveniente:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // listessu cum'è `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // listessu cum'è `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Mentre chì assai cullizzioni offrenu `iter()`, micca tutti offrenu `iter_mut()`.
//! Per esempiu, mutà e chjave di un [`HashSet<T>`] o [`HashMap<K, V>`] puderia mette a cullezzione in un statu inconsistente se u hash di chjave cambia, dunque queste cullezzione offrenu solu `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funzioni chì piglianu un [`Iterator`] è restituiscenu un altru [`Iterator`] sò spessu chjamati 'adattatori iteratori', chì sò una forma di 'adattatore
//! pattern'.
//!
//! L'adattatori iteratori cumuni includenu [`map`], [`take`] è [`filter`].
//! Per più, vedi a so ducumentazione.
//!
//! Se un adattatore d'iteratore panics, l'iteratore sarà in un statu micca specificatu (ma sicura in memoria).
//! Stu statu ùn hè ancu garantitu di stà uguale in e versioni di Rust, allora duvete evità di fidàvvi à i valori esatti restituiti da un iteratore in panicu.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratori (è l'iteratore [adapters](#adapters)) sò *pigri*. Questu significa chì solu creà un iteratore ùn face micca _do_ assai. Nunda accade veramente finu à chjamà [`next`].
//! Questa hè à volte una fonte di cunfusione quandu si crea un iteratore solu per i so effetti collaterali.
//! Per esempiu, u metudu [`map`] chjama una chjusura per ogni elementu chì itera sopra:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Questu ùn stamperà alcun valore, postu chì avemu creatu solu un iteratore, piuttostu chè aduprà.U compilatore ci avverterà di stu tipu di cumpurtamentu:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! U modu idiomaticu per scrive un [`map`] per i so effetti collaterali hè di aduprà un ciclu `for` o chjamà u metudu [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Un altru modu cumunu per valutà un iteratore hè di aduprà u metudu [`collect`] per pruduce una nova raccolta.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratori ùn anu micca da esse finiti.Per esempiu, un intervallu apertu hè un iteratore infinitu:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Hè cumunu di aduprà l'adattatore d'iteratore [`take`] per trasformà un iteratore infinitu in unu finitu:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Questu stamperà i numeri da `0` à `4`, ognunu nantu à a so linea.
//!
//! Tenite à mente chì i metudi nantu à iteratori infiniti, ancu quelli per i quali un risultatu pò esse determinatu matematicamente in tempu finitu, ùn ponu finisce.
//! Specificamente, i metudi cum'è [`min`], chì in u casu generale richiedenu di attraversà ogni elementu in l'iteratore, sò prubabilmente micca di vultà cù successu per qualsiasi iteratori infiniti.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh innò!Un loop infinitu!
//! // `ones.min()` provoca un loop infinitu, allora ùn ghjunghjeremu micca à stu puntu!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;