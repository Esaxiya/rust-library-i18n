use crate::ops::{ControlFlow, Try};

/// Un iteratore capace di cede elementi da e duie estremità.
///
/// Qualcosa chì mette in opera `DoubleEndedIterator` hà una capacità in più di qualcosa chì mette in opera [`Iterator`]: a capacità di piglià ancu `Item` da u daretu, è ancu da u fronte.
///
///
/// Hè impurtante nutà chì tramindui avanti è indietru travaglianu nantu à a listessa gamma, è ùn attraversanu micca: l'iterazione hè finita quandu si scontranu à mezu.
///
/// In un modu simile à u protocolu [`Iterator`], una volta chì un `DoubleEndedIterator` restituisce [`None`] da un [`next_back()`], chjamallu torna pò o ùn pò mai più restituisce [`Some`] di novu.
/// [`next()`] è [`next_back()`] sò scambiabili per questu scopu.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Elimina è rende un elementu da a fine di l'iteratore.
    ///
    /// Ritorna `None` quandu ùn ci sò più elementi.
    ///
    /// I documenti [trait-level] cuntenenu più dettagli.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// L'elementi resi da i metudi di `DoubleEndedIterator` ponu differisce da quelli resi da i metudi di [`Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Avanza l'iteratore da u retro da elementi `n`.
    ///
    /// `advance_back_by` hè a versione inversa di [`advance_by`].Stu metudu salterà cù entusiasmu l'elementi `n` partendu da u fondu chjamendu [`next_back`] finu à `n` volte finu à chì [`None`] hè scontru.
    ///
    /// `advance_back_by(n)` restituverà [`Ok(())`] se l'iteratore avanza cù successu da elementi `n`, o [`Err(k)`] se [`None`] hè scontru, induve `k` hè u numeru d'elementi da cui l'iteratore hè avanzatu prima di mancà l'elementi (ie
    /// a lunghezza di l'iteratore).
    /// Innota chì `k` hè sempre menu di `n`.
    ///
    /// Chjamà `advance_back_by(0)` ùn cunsuma micca elementi è torna sempre [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // solu `&3` hè statu saltatu
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Restituisce l'elimentu `n`th da a fine di l'iteratore.
    ///
    /// Questa hè essenzialmente a versione inversa di [`Iterator::nth()`].
    /// Ancu se cum'è a maiò parte di l'operazioni d'indexazione, u conte principia da zero, cusì `nth_back(0)` restituisce u primu valore da a fine, `nth_back(1)` u secondu, ecc.
    ///
    ///
    /// Nota chì tutti l'elementi trà a fine è l'elementu restituitu seranu cunsumati, cumpresu l'elementu restituitu.
    /// Ciò significa ancu chì chjamà `nth_back(0)` più volte nantu à u listessu iteratore restituirà elementi diversi.
    ///
    /// `nth_back()` restituverà [`None`] se `n` hè più grande o uguale à a lunghezza di l'iteratore.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Chjamà `nth_back()` parechje volte ùn riavvia micca l'iteratore:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Ritorna `None` se ci sò menu elementi `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Questa hè a versione inversa di [`Iterator::try_fold()`]: piglia elementi chì partenu da u fondu di l'iteratore.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Perchè hè cortocircuitatu, l'elementi restanti sò sempre dispunibuli attraversu l'iteratore.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Un metudu iteratore chì riduce l'elementi di l'iteratore à un unicu valore finale, partendu da u ritornu.
    ///
    /// Questa hè a versione inversa di [`Iterator::fold()`]: piglia elementi chì partenu da u fondu di l'iteratore.
    ///
    /// `rfold()` piglia dui argumenti: un valore iniziale, è una chjusura cù dui argumenti: un 'accumulator', è un elementu.
    /// A chiusura restituisce u valore chì l'accumulatore deve avè per a prossima iterazione.
    ///
    /// U valore iniziale hè u valore chì l'accumulatore averà nantu à a prima chjamata.
    ///
    /// Dopu avè applicatu sta chjusura à ogni elementu di l'iteratore, `rfold()` restituisce l'accumulatore.
    ///
    /// Questa operazione hè qualchì volta chjamata 'reduce' o 'inject'.
    ///
    /// U piegamentu hè utile ogni volta chì avete una raccolta di qualcosa, è vulete pruduce un valore unicu da ellu.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a somma di tutti l'elementi di a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Questu esempiu custruisce una stringa, cuminciendu cù un valore iniziale è continuendu cù ogni elementu da u retro finu à u fronte:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Cerca un elementu di un iteratore da u fondu chì soddisfa un predicatu.
    ///
    /// `rfind()` piglia una chjusura chì rende `true` o `false`.
    /// Applica questa chjusura à ogni elementu di l'iteratore, à partesi da a fine, è se unu di elli restituisce `true`, allora `rfind()` restituisce [`Some(element)`].
    /// Se tutti tornanu `false`, torna [`None`].
    ///
    /// `rfind()` hè in cortocircuitu;in altre parolle, fermerà a trasfurmazione appena a chjusura ritorna `true`.
    ///
    /// Perchè `rfind()` piglia una riferenza, è parechji iteratori iteranu nantu à e referenze, questu porta à una situazione possibbilmente cunfusa induve l'argumentu hè una doppia riferenza.
    ///
    /// Pudete vede questu effettu in l'esempii sottu, cù `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Fermendu à u primu `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // pudemu sempre aduprà `iter`, chì ci sò più elementi.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}