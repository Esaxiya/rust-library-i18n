/// Un iteratore chì continua sempre à dà `None` quandu hè esauritu.
///
/// Chjamate dopu nantu à un iteratore fusionu chì hà restituitu `None` una volta hè garantitu per restituisce [`None`] di novu.
/// Questu trait duveria esse messu in opera da tutti l'iteratori chì si comportanu cusì perchè permette di ottimizà [`Iterator::fuse()`].
///
///
/// Note: In generale, ùn pudete micca aduprà `FusedIterator` in limiti generichi se avete bisognu di un iteratore fusionu.
/// Invece, duvete chjamà solu [`Iterator::fuse()`] nantu à l'iteratore.
/// Se l'iteratore hè digià fusionu, u involucru [`Fuse`] addizionale serà un no-op senza penalità di prestazione.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Un iteratore chì riporta una lunghezza precisa cù size_hint.
///
/// L'iteratore riporta un suggerimentu di dimensione induve hè o esattu (u limitu inferiore hè uguale à u limite superiore), o u limite superiore hè [`None`].
///
/// U limite superiore deve esse solu [`None`] se a lunghezza effettiva di l'iteratore hè più grande di [`usize::MAX`].
/// In questu casu, u limite inferiore deve esse [`usize::MAX`], risultendu in un [`Iterator::size_hint()`] di `(usize::MAX, None)`.
///
/// L'iteratore deve pruduce esattamente u numeru di elementi chì hà segnalatu o divergenu prima di ghjunghje à a fine.
///
/// # Safety
///
/// Stu trait deve esse messu in opera solu quandu u cuntrattu hè cunfirmatu.
/// I cunsumatori di stu trait devenu ispezionà u limite superiore [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Un iteratore chì quandu cede un articulu averà presu almenu un elementu da u so [`SourceIter`] sottostante.
///
/// Chjamà qualsiasi metudu chì avanza l'iteratore, per esempiu
/// [`next()`] o [`try_fold()`], garantisce chì per ogni passu almenu un valore di a fonte sottostante di l'iteratore hè statu spostatu fora è u risultatu di a catena di l'iteratore puderia esse inseritu in u so postu, supponendu chì e restrizioni strutturali di a fonte permettenu una tale inserzione.
///
/// In altre parolle questu trait indica chì un pipeline iteratore pò esse raccoltu in u locu.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}