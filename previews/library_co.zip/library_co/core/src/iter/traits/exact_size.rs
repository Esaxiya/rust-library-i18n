/// Un iteratore chì cunnosce a so lunghezza esatta.
///
/// Parechji [`Iteratori`] ùn sanu micca quante volte anu da iterà, ma alcuni a facenu.
/// Se un iteratore sà quante volte pò iterà, furnisce accessu à quella infurmazione pò esse utile.
/// Per esempiu, sè vulete iterà in daretu, un bon principiu hè di sapè induve hè a fine.
///
/// Quandu implementate un `ExactSizeIterator`, duvete ancu implementà [`Iterator`].
/// Quandu si face cusì, l'implementazione di [`Iterator::size_hint`]*deve* restituisce a dimensione esatta di l'iteratore.
///
/// U metudu [`len`] hà una implementazione predefinita, dunque di solitu ùn duverete micca implementallu.
/// Tuttavia, pudete esse capace di furnisce una implementazione più performante di quella predefinita, cusì annullà in questu casu hè sensu.
///
///
/// Innota chì questu trait hè un trait sicuru è cum'è tale *micca* è *ùn pò micca* garantisce chì a lunghezza restituita sia curretta.
/// Questu significa chì u codice `unsafe`**ùn deve micca** cunfidassi à a currettezza di [`Iterator::size_hint`].
/// U instabile è periculosu [`TrustedLen`](super::marker::TrustedLen) trait dà sta garanzia addizionale.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// // un intervallu finitu sà esattamente quante volte itererà
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// In u [module-level docs], avemu implementatu un [`Iterator`], `Counter`.
/// Implementemu `ExactSizeIterator` per ellu dinò:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Pudemu calculà facilmente u numeru restante di iterazioni.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // È avà a pudemu aduprà!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Restituisce a lunghezza esatta di l'iteratore.
    ///
    /// L'implementazione assicura chì l'iteratore tornerà esattamente `len()` più volte un valore [`Some(T)`], prima di restituisce [`None`].
    ///
    /// Stu metudu hà una implementazione predefinita, dunque di solitu ùn si deve micca implementà direttamente.
    /// Tuttavia, se pudete furnisce una implementazione più efficiente, pudete fà.
    /// Vede i documenti [trait-level] per un esempiu.
    ///
    /// Questa funzione hà e stesse garanzie di sicurezza cum'è a funzione [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // un intervallu finitu sà esattamente quante volte itererà
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Questa affirmazione hè troppu difensiva, ma verifica l'invariante
        // guarantitu da u trait.
        // Se stu trait era rust-internu, pudemu aduprà debug_assert !;assert_eq!verificerà ancu tutte l'implementazioni di l'utente Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Restituisce `true` se l'iteratore hè vacante.
    ///
    /// Stu metudu hà una implementazione predefinita aduprendu [`ExactSizeIterator::len()`], allora ùn avete micca bisognu di implementallu da voi stessu.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}