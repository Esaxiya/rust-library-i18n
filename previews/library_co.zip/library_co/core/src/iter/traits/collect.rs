/// Cunversione da un [`Iterator`].
///
/// Implementendu `FromIterator` per un tippu, definite cume serà creatu da un iteratore.
/// Questu hè cumunu per i tippi chì descrivenu una raccolta di qualche tipu.
///
/// [`FromIterator::from_iter()`] hè raramente chjamatu esplicitamente, è hè invece adupratu per mezu di u metudu [`Iterator::collect()`].
///
/// Vede a documentazione [`Iterator::collect()`]'s per più esempi.
///
/// Vede ancu: [`IntoIterator`].
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Aduprà [`Iterator::collect()`] per aduprà implicitamente `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implementazione di `FromIterator` per u vostru tipu:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Una raccolta di campioni, hè solu un involucru sopra Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Demu un pocu di metudi per pudè creà unu è aghjunghje cose.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // è implementeremu FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Ora pudemu fà un novu iteratore ...
/// let iter = (0..5).into_iter();
///
/// // ... è fà ne una MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // raccoglie opere dinò!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Crea un valore da un iteratore.
    ///
    /// Vede u [module-level documentation] per più.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Cunversione in un [`Iterator`].
///
/// Mettendu in opera `IntoIterator` per un tippu, definisci cume serà convertitu in un iteratore.
/// Questu hè cumunu per i tippi chì descrivenu una raccolta di qualche tipu.
///
/// Un benefiziu di l'implementazione di `IntoIterator` hè chì u vostru tipu serà [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Vede ancu: [`FromIterator`].
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementazione di `IntoIterator` per u vostru tipu:
///
/// ```
/// // Una raccolta di campioni, hè solu un involucru sopra Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Demu un pocu di metudi per pudè creà unu è aghjunghje cose.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // è implementeremu IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Avà pudemu fà una nova cullizzioni ...
/// let mut c = MyCollection::new();
///
/// // ... aghjunghje qualchì roba à questu ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... è poi trasformallu in un Iteratore:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Hè cumunu di aduprà `IntoIterator` cum'è trait bound.Questu permette à u tippu di raccolta di input di cambià, puru chì sia sempre un iteratore.
/// Limiti addiziunali ponu esse specificati limitendu nantu à
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// U tippu di l'elementi in iterazione.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// In chì tippu d'iteratore stemu trasformendu questu?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Crea un iteratore da un valore.
    ///
    /// Vede u [module-level documentation] per più.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Stende una cullizzioni cù u cuntenutu di un iteratore.
///
/// L'iteratori producenu una seria di valori, è e cullezzione ponu ancu esse pensate cum'è una seria di valori.
/// U `Extend` trait colma questu spaziu, chì vi permette di allargà una raccolta includendu u cuntenutu di quellu iteratore.
/// Quandu si stende una cullezzione cù una chjave dighjà esistente, quella entrata hè aggiornata o, in casu di raccolte chì permettenu più entrate cù chiavi uguali, quella entrata hè inserita.
///
///
/// # Examples
///
/// Usu di basa:
///
/// ```
/// // Pudete allargà una String cù qualchi caratteri:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementazione di `Extend`:
///
/// ```
/// // Una raccolta di campioni, hè solu un involucru sopra Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Demu un pocu di metudi per pudè creà unu è aghjunghje cose.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // postu chì MyCollection hà una lista di i32s, implementemu Extend per i32
/// impl Extend<i32> for MyCollection {
///
///     // Questu hè un pocu più simplice cù a firma di tippu cuncretu: pudemu chjamà estende nantu à tuttu ciò chì pò esse trasformatu in un Iteratore chì ci dà i32s.
///     // Perchè avemu bisognu di i32s per mette in MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // L'implementazione hè assai semplice: passà per l'iteratore, è add() ogni elementu per noi stessi.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // allargemu a nostra racolta cù altri trè numeri
/// c.extend(vec![1, 2, 3]);
///
/// // avemu aghjustatu questi elementi à a fine
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Estende una raccolta cù u cuntenutu di un iteratore.
    ///
    /// Cum'è questu hè l'unicu metudu necessariu per questu trait, i documenti [trait-level] cuntenenu più dettagli.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // Pudete allargà una String cù qualchi caratteri:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Estende una raccolta cun esattamente un elementu.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Riserva capacità in una raccolta per u numeru datu di elementi supplementari.
    ///
    /// L'implementazione predefinita ùn face nunda.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}