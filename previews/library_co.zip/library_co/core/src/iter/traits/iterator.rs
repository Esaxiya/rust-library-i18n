// ignore-tidy-filelength Stu schedariu hè custituitu guasgi solu da a definizione di `Iterator`.
// Ùn pudemu micca sparte quellu in più fugliali.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Una interfaccia per trattà cù iteratori.
///
/// Questu hè u principale iteratore trait.
/// Per sapè di più nantu à u cuncettu di iteratori in generale, per piacè vede u [module-level documentation].
/// In particulare, pudete vulete sapè cumu [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// U tippu di l'elementi in iterazione.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Avanza l'iteratore è restituisce u prossimu valore.
    ///
    /// Restituisce [`None`] quandu l'iterazione hè finita.
    /// L'implementazioni individuali di l'iteratore ponu sceglie di ripiglià l'iterazione, è cusì chjamà `next()` di novu pò o ùn puderà eventualmente ripiglià torna [`Some(Item)`] à un certu puntu.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Una chjamata à next() restituisce u prossimu valore ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... è dopu None una volta finita.
    /// assert_eq!(None, iter.next());
    ///
    /// // Più chjamate ponu restituisce `None` o micca.Eccu, anu sempre.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Restituisce i limiti di a lunghezza restante di l'iteratore.
    ///
    /// Specificamente, `size_hint()` restituisce una tupla induve u primu elementu hè u limite inferiore, è u secondu elementu hè u limite superiore.
    ///
    /// A seconda metà di a tupla restituita hè una [`Opzione`]`<`[`usize`] `>`.
    /// Un [`None`] quì significa chì o ùn ci hè micca un limite superiore cunnisciutu, o u limitu superiore hè più grande di [`usize`].
    ///
    /// # Note di implementazione
    ///
    /// Ùn hè micca infurzatu chì un'implementazione iteratrice produci u numeru dichjaratu d'elementi.Un iteratore buggy pò pruduce menu di u limitu inferiore o più di u limitu superiore di l'elementi.
    ///
    /// `size_hint()` hè principalmente destinatu à esse adupratu per ottimizazioni cume riservà spaziu per l'elementi di l'iteratore, ma ùn deve micca esse fidatu per esempiu, omettendu i controlli di limiti in codice periculosu.
    /// Una messa in opera sbagliata di `size_hint()` ùn deve micca cunduce à viulazioni di sicurità di memoria
    ///
    /// Dice questu, l'implementazione duveria furnisce una stima curretta, perchè altrimente seria una violazione di u protocolu trait.
    ///
    /// L'implementazione predefinita restituisce `(0,` [Nessuna`]`)` chì hè currettu per qualsiasi iteratore.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Un esempiu più cumplessu:
    ///
    /// ```
    /// // I numeri pari da zero à dece.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Puderemu iterà da zero à dece volte.
    /// // Sapendu chì sò cinque esattamente ùn saria micca pussibule senza eseguisce filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Aghjustemu cinque numeri in più cù chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // avà i dui limiti sò aumentati di cinque
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Ritorna `None` per un limite superiore:
    ///
    /// ```
    /// // un iteratore infinitu ùn hà micca limite superiore è u limite inferiore massimu pussibule
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Cunsuma l'iteratore, cuntendu u numeru di iterazioni è u restituisce.
    ///
    /// Stu metudu chjamerà [`next`] ripetutamente finu à chì [`None`] hè scontru, restituendu u numeru di volte chì hà vistu [`Some`].
    /// Nota chì [`next`] deve esse chjamatu almenu una volta ancu se l'iteratore ùn hà micca elementi.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Cumportamentu Overflow
    ///
    /// U metudu ùn guarda micca da u overflow, cusì cuntà elementi di un iteratore cù più di elementi [`usize::MAX`] produce u risultatu sbagliatu o panics.
    ///
    /// Se l'affirmazioni di debug sò attivate, un panic hè garantitu.
    ///
    /// # Panics
    ///
    /// Sta funzione puderia panic se l'iteratore hà più di elementi [`usize::MAX`].
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Cunsuma l'iteratore, restituendu l'ultimu elementu.
    ///
    /// Stu metudu valuterà l'iteratore finu à chì restituisce [`None`].
    /// Mentre faci cusì, tene traccia di l'elementu attuale.
    /// Dopu chì [`None`] hè restituitu, `last()` restituverà l'ultimu elementu chì hà vistu.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Avanza l'iteratore da elementi `n`.
    ///
    /// Stu metudu salterà cun fervore elementi `n` chjamendu [`next`] finu à `n` volte finu à chì [`None`] hè scontru.
    ///
    /// `advance_by(n)` restituverà [`Ok(())`][Ok] se l'iteratore avanza cù successu da elementi `n`, o [`Err(k)`][Err] se [`None`] hè scontru, induve `k` hè u numeru d'elementi da cui l'iteratore hè avanzatu prima di mancà l'elementi (ie
    /// a lunghezza di l'iteratore).
    /// Innota chì `k` hè sempre menu di `n`.
    ///
    /// Chjamà `advance_by(0)` ùn cunsuma micca elementi è torna sempre [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // solu `&4` hè statu saltatu
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Restituisce l'elementu `n` di l'iteratore.
    ///
    /// Cum'è a maiò parte di l'operazioni d'indexazione, u numeru parte da zero, cusì `nth(0)` restituisce u primu valore, `nth(1)` u secondu, ecc.
    ///
    /// Innota chì tutti l'elementi precedenti, cum'è l'elementu restituitu, seranu cunsumati da l'iteratore.
    /// Ciò significa chì l'elementi precedenti saranu scartati, è ancu chì chjamà `nth(0)` più volte nantu à u listessu iteratore restituirà elementi diversi.
    ///
    ///
    /// `nth()` restituverà [`None`] se `n` hè più grande o uguale à a lunghezza di l'iteratore.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Chjamà `nth()` parechje volte ùn riavvia micca l'iteratore:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Ritorna `None` se ci sò menu elementi `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Crea un iteratore partendu da u listessu puntu, ma passendu da a quantità data à ogni iterazione.
    ///
    /// Nota 1: U primu elementu di l'iteratore serà sempre restituitu, indipendentemente da u passu datu.
    ///
    /// Nota 2: U tempu induve l'elementi ignorati sò tirati ùn hè micca fissatu.
    /// `StepBy` si comporta cum'è a sequenza `next(), nth(step-1), nth(step-1),…`, ma hè ancu liberu di comportassi cum'è a sequenza
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Quale modu hè adupratu pò cambià per alcuni iteratori per ragioni di prestazione.
    /// U secondu modu avancherà l'iteratore prima è pò cunsumà più elementi.
    ///
    /// `advance_n_and_return_first` hè l'equivalente di:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// U metudu serà panic se u passu datu hè `0`.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Piglia dui iteratori è crea un novu iteratore sopra tramindui in sequenza.
    ///
    /// `chain()` restituverà un novu iteratore chì prima itererà sopra i valori di u primu iteratore è dopu sopra i valori di u secondu iteratore.
    ///
    /// In altre parolle, lea dui iteratori inseme, in una catena.🔗
    ///
    /// [`once`] hè comunemente adupratu per adattà un valore unicu in una catena di altri tippi d'iterazione.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Siccomu l'argumentu per `chain()` usa [`IntoIterator`], pudemu passà tuttu ciò chì pò esse cunvertitu in un [`Iterator`], micca solu in un [`Iterator`] stessu.
    /// Per esempiu, e fette (`&[T]`) implementanu [`IntoIterator`], è cusì ponu esse passate à `chain()` direttamente:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Se travagliate cù Windows API, pudete desiderà cunvertisce [`OsStr`] in `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips up' dui iteratori in un unicu iteratore di coppie.
    ///
    /// `zip()` restituisce un novu iteratore chì itererà nantu à dui altri iteratori, restituendu una tupla induve u primu elementu vene da u primu iteratore, è u secondu elementu vene da u secondu iteratore.
    ///
    ///
    /// In altre parolle, chjappà dui iteratori inseme, in una sola.
    ///
    /// Se unu di l'iteratori restituisce [`None`], [`next`] da l'iteratore zipped restituverà [`None`].
    /// Se u primu iteratore ritorna [`None`], `zip` farà un cortocircuitu è `next` ùn serà micca chjamatu nantu à u secondu iteratore.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Siccomu l'argumentu per `zip()` usa [`IntoIterator`], pudemu passà tuttu ciò chì pò esse cunvertitu in un [`Iterator`], micca solu in un [`Iterator`] stessu.
    /// Per esempiu, e fette (`&[T]`) implementanu [`IntoIterator`], è cusì ponu esse passate à `zip()` direttamente:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` hè spessu usatu per zip un iteratore infinitu à unu finitu.
    /// Questu funziona perchè l'iteratore finitu ritorna eventualmente [`None`], finendu u zipper.Zipper cun `(0..)` pò assomiglia assai à [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Crea un novu iteratore chì mette una copia di `separator` trà elementi adiacenti di l'iteratore originale.
    ///
    /// In casu `separator` ùn implementa micca [`Clone`] o deve esse calculatu ogni volta, aduprate [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // U primu elementu da `a`.
    /// assert_eq!(a.next(), Some(&100)); // U separatore.
    /// assert_eq!(a.next(), Some(&1));   // U prossimu elementu da `a`.
    /// assert_eq!(a.next(), Some(&100)); // U separatore.
    /// assert_eq!(a.next(), Some(&2));   // L'ultimu elementu da `a`.
    /// assert_eq!(a.next(), None);       // L'iteratore hè finitu.
    /// ```
    ///
    /// `intersperse` pò esse assai utile per unisce l'articuli di un iteratore cù un elementu cumunu:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Crea un novu iteratore chì mette un articulu generatu da `separator` trà elementi adiacenti di l'iteratore originale.
    ///
    /// A chjusura serà chjamata esattamente una volta ogni volta chì un articulu hè piazzatu trà dui elementi adiacenti da l'iteratore sottostante;
    /// specificamente, a chjusura ùn hè micca chjamata se l'iteratore sottostante produce menu di dui elementi è dopu l'ultimu articulu hè cedutu.
    ///
    ///
    /// Se l'articulu di l'iteratore implementa [`Clone`], pò esse più faciule da aduprà [`intersperse`].
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // U primu elementu da `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // U separatore.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // U prossimu elementu da `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // U separatore.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // L'ultimu elementu da da `v`.
    /// assert_eq!(it.next(), None);               // L'iteratore hè finitu.
    /// ```
    ///
    /// `intersperse_with` pò esse adupratu in situazioni induve u separatore deve esse calculatu:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // A chjusura impresta mutabilmente u so cuntestu per generà un articulu.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Piglia una chjusura è crea un iteratore chì chjama quella chjusura per ogni elementu.
    ///
    /// `map()` trasforma un iteratore in un altru, per mezu di u so argumentu:
    /// qualcosa chì implementa [`FnMut`].Produce un novu iteratore chì chjama sta chjusura per ogni elementu di l'iteratore originale.
    ///
    /// Se site bravu à pensà in tippi, pudete pensà à `map()` cusì:
    /// Se avete un iteratore chì vi dà elementi di qualchì tippu `A`, è vulete un iteratore di qualchì altru tippu `B`, pudete aduprà `map()`, passendu una chjusura chì piglia un `A` è restituisce un `B`.
    ///
    ///
    /// `map()` hè cuncettualmente simile à un loop [`for`].Tuttavia, cum'è `map()` hè pigru, hè megliu adupratu quandu site dighjà travagliendu cù altri iteratori.
    /// Se fate una sorta di looping per un effettu collaterale, hè cunsideratu più idiomaticu per aduprà [`for`] cà `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Se fate una sorta di effetti collaterali, preferite [`for`] à `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ùn fà micca què:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ùn mancu eseguirà, chì hè pigru.Rust vi avverrà di questu.
    ///
    /// // Invece, aduprate per:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Chjama una chjusura per ogni elementu di un iteratore.
    ///
    /// Questu hè equivalente à aduprà un loop [`for`] nantu à l'iteratore, ancu se `break` è `continue` ùn sò micca pussibili da una chjusura.
    /// Hè generalmente più idiomaticu di aduprà un ciclu `for`, ma `for_each` pò esse più leghjibile quandu si tratta l'elementi à a fine di e catene più lunghe d'iteratori.
    ///
    /// In certi casi `for_each` pò ancu esse più veloce di un loop, perchè utilizarà iterazione interna nantu à adattatori cum'è `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Per un esempiu cusì chjucu, un ciclu `for` pò esse più pulitu, ma `for_each` pò esse preferibile per tene un stile funzionale cù iteratori più lunghi:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Crea un iteratore chì utilizza una chiusura per determinà se un elementu deve esse cedutu.
    ///
    /// Datu un elementu a chjusura deve restituisce `true` o `false`.L'iteratore restituitu darà solu l'elementi per i quali a chjusura torna vera.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Perchè a chjusura passata à `filter()` piglia una riferenza, è parechji iteratori iteranu nantu à e referenze, questu porta à una situazione forse confusa, induve u tippu di chjusura hè un doppiu riferimentu:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // bisognu di dui * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hè cumunu di utilizà invece a distrutturazione nantu à l'argumentu per sparisce unu:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // tramindui&è *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// o dui:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dui &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// di sti strati.
    ///
    /// Innota chì `iter.filter(f).next()` hè equivalente à `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Crea un iteratore chì filtra è carte.
    ///
    /// L'iteratore restituitu dà solu u `valore` per u quale a chjusura furnita restituisce `Some(value)`.
    ///
    /// `filter_map` pò esse adupratu per fà e catene di [`filter`] è [`map`] più concise.
    /// L'esempiu sottu mostra cumu un `map().filter().map()` pò esse accurtatu à una sola chjamata à `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Eccu u listessu esempiu, ma cù [`filter`] è [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Crea un iteratore chì dà u conte di iterazione attuale è u prossimu valore.
    ///
    /// L'iteratore hà restituitu produce coppie `(i, val)`, induve `i` hè l'indice attuale di iterazione è `val` hè u valore restituitu da l'iteratore.
    ///
    ///
    /// `enumerate()` mantene u so contu cum'è [`usize`].
    /// Se vulete cuntà per un numeru interu di dimensioni diverse, a funzione [`zip`] furnisce funzionalità simile.
    ///
    /// # Cumportamentu Overflow
    ///
    /// U metudu ùn guarda micca da u overflow, dunque enumerendu più di elementi [`usize::MAX`] produce u risultatu sbagliatu o panics.
    /// Se l'affirmazioni di debug sò attivate, un panic hè garantitu.
    ///
    /// # Panics
    ///
    /// L'iteratore restituitu puderia panic se l'indice da restituisce inunderà un [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Crea un iteratore chì pò aduprà [`peek`] per guardà l'elementu prossimu di l'iteratore senza cunsumallu.
    ///
    /// Aggiunge un metudu [`peek`] à un iteratore.Vede a so ducumentazione per più infurmazione.
    ///
    /// Da nutà chì l'iteratore sottostante hè sempre avanzatu quandu [`peek`] hè chjamatu per a prima volta: Per recuperà l'elementu prossimu, [`next`] hè chjamatu nantu à l'iteratore sottostante, da quì ogni effetti collaterali (ie
    ///
    /// qualsiasi cosa altru ch'è piglià u prossimu valore) di u metudu [`next`] accadrà.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ci lascia vede in u future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // pudemu peek() parechje volte, l'iteratore ùn avanzerà micca
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // dopu l'iteratore hè finitu, cusì hè peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Crea un iteratore chì [`saltà]] elementi basati annantu à un predicatu.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` piglia una chjusura cum'è argumentu.Chjamerà sta chjusura annantu à ogni elementu di l'iteratore, è ignurarà l'elementi finu à chì rende `false`.
    ///
    /// Dopu chì `false` hè restituitu, u travagliu `skip_while()`'s hè finitu, è u restu di l'elementi sò ceduti.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Perchè a chjusura passata à `skip_while()` piglia una riferenza, è parechji iteratori iteranu nantu à e referenze, questu porta à una situazione forse confusa, induve u tippu di l'argumentu di chjusura hè un doppiu riferimentu:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // bisognu di dui * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Arrestà dopu à un `false` iniziale:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // mentre questu seria falsu, postu chì avemu digià avutu un falsu, skip_while() ùn hè più adupratu
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Crea un iteratore chì dà elementi basati annantu à un predicatu.
    ///
    /// `take_while()` piglia una chjusura cum'è argumentu.Chjamerà sta chjusura per ogni elementu di l'iteratore, è darà elementi mentre restituisce `true`.
    ///
    /// Dopu chì `false` hè restituitu, u travagliu `take_while()`'s hè finitu, è u restu di l'elementi sò ignorati.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Perchè a chjusura passata à `take_while()` piglia una riferenza, è parechji iteratori iteranu nantu à e referenze, questu porta à una situazione forse confusa, induve u tippu di chjusura hè un doppiu riferimentu:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // bisognu di dui * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Arrestà dopu à un `false` iniziale:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Avemu più elementi chì sò menu di zeru, ma postu chì avemu digià avutu un falsu, take_while() ùn hè più adupratu
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Perchè `take_while()` hà bisognu di guardà u valore per vede s'ellu deve esse inclusu o micca, cunsumendu iteratori vedenu chì hè eliminatu:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// U `3` ùn ci hè più, perchè hè statu cunsumatu per vede se l'iterazione si deve piantà, ma ùn hè micca stata rimessa in l'iteratore.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Crea un iteratore chì tramindui rende elementi basati annantu à un predicatu è e carte.
    ///
    /// `map_while()` piglia una chjusura cum'è argumentu.
    /// Chjamerà sta chjusura per ogni elementu di l'iteratore, è darà elementi mentre restituisce [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Eccu u listessu esempiu, ma cù [`take_while`] è [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Arrestà dopu à un [`None`] iniziale:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Avemu più elementi chì puderebbenu adattassi à u32 (4, 5), ma `map_while` hà restituitu `None` per `-3` (cume `predicate` hà tornatu `None`) è `collect` si ferma à u primu `None` scontru.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Perchè `map_while()` hà bisognu di guardà u valore per vede s'ellu deve esse inclusu o micca, cunsumendu iteratori vedenu chì hè eliminatu:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// U `-3` ùn ci hè più, perchè hè statu cunsumatu per vede se l'iterazione si deve piantà, ma ùn hè micca stata rimessa in l'iteratore.
    ///
    /// Innota chì à u cuntrariu di [`take_while`] questu iteratore hè **micca** fusu.
    /// Ùn hè ancu specificatu ciò chì torna questu iteratore dopu u primu [`None`] hè restituitu.
    /// Se avete bisognu di iteratore fusionatu, aduprate [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Crea un iteratore chì salta i primi elementi `n`.
    ///
    /// Dopu sò stati cunsumati, u restu di l'elementi sò ceduti.
    /// Invece di annullà stu metudu direttamente, invece annullà u metudu `nth`.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Crea un iteratore chì dà i so primi elementi `n`.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` hè spessu usatu cù un iteratore infinitu, per rende lu finitu:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Se menu di l'elementi `n` sò dispunibili, `take` si limiterà à a dimensione di l'iteratore sottostante:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Un adattatore iteratore simile à [`fold`] chì tene u statu internu è produce un novu iteratore.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` piglia dui argumenti: un valore iniziale chì sementa u statu internu, è una chjusura cù dui argumenti, u primu hè un riferimentu mutevule à u statu internu è u secondu un elementu iteratore.
    ///
    /// A chjusura pò assignà à u statu internu per sparte u statu trà iterazioni.
    ///
    /// In iterazione, a chiusura serà applicata à ogni elementu di l'iteratore è u valore di ritornu da a chiusura, un [`Option`], hè cedutu da l'iteratore.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // ogni iterazione, multiplichemu u statu per l'elementu
    ///     *state = *state * x;
    ///
    ///     // allora, daremu a negazione di u statu
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Crea un iteratore chì funziona cum'è mappa, ma appiattisce a struttura annidata.
    ///
    /// L'adattatore [`map`] hè assai utile, ma solu quandu l'argumentu di chjusura produce valori.
    /// S'ellu produce invece un iteratore, ci hè un stratu di indirezzione in più.
    /// `flat_map()` eliminerà stu stratu supplementu da solu.
    ///
    /// Pudete pensà à `flat_map(f)` cum'è l'equivalente semanticu di [`map`] ping, è dopu [`appiattì`] ing cum'è in `map(f).flatten()`.
    ///
    /// Un altru modu di pensà à `flat_map()`: a chjusura di [`map`] rende un elementu per ogni elementu, è a chjusura `flat_map()`'s restituisce un iteratore per ogni elementu.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() torna un iteratore
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Crea un iteratore chì appiattisce a struttura annidata.
    ///
    /// Questu hè utile quandu avete un iteratore di iteratori o un iteratore di cose chì ponu esse trasformate in iteratori è vulete eliminà un livellu di indirezione.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mappatura è dopu appiattimentu:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() torna un iteratore
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Pudete ancu riscrive questu in termini di [`flat_map()`], chì hè preferibile in questu casu postu chì trasmette l'intenzione più chjaramente:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() torna un iteratore
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// L'appiattimentu elimina solu un livellu di nidificazione à a volta:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Quì vedemu chì `flatten()` ùn esegue micca un "deep" appiattitu.
    /// Invece, solu un livellu di nesting hè eliminatu.Questu hè, se `flatten()` un array tridimensionale, u risultatu serà bidimensionale è micca unidimensionale.
    /// Per uttene una struttura unidimensionale, avete da novu `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Crea un iteratore chì finisce dopu u primu [`None`].
    ///
    /// Dopu chì un iteratore rende [`None`], e chjamate future ponu o ùn anu micca daveru [`Some(T)`] di novu.
    /// `fuse()` adatta un iteratore, assicurendu chì dopu un [`None`] hè datu, tornerà sempre [`None`] per sempre.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // un iteratore chì alterna trà Alcuni è Nimu
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // s'ellu hè paru, Some(i32), altru Nimu
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // pudemu vede u nostru iteratore andendu avanti è avanti
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // però, una volta chì u fusionemu ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // tornerà sempre `None` dopu a prima volta.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Face qualcosa cù ogni elementu di un iteratore, passendu u valore.
    ///
    /// Quandu aduprate iteratori, spessu catene parechji di elli.
    /// Mentre travagliate nantu à tale codice, pudete vulete verificà ciò chì accade in varie parti in pipeline.Per fà quessa, inserisci una chjamata à `inspect()`.
    ///
    /// Hè più cumunu per `inspect()` esse adupratu cum'è strumentu di debugging ch'è esiste in u vostru còdice finale, ma l'applicazioni ponu truvà utile in certe situazioni quandu l'errori anu da esse registrati prima di esse scartati.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // sta sequenza iteratrice hè cumplessa.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // aghjustemu qualchì chjamata inspect() per investigà ciò chì accade
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Questu stamperà:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Errori di logging prima di scartalli:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Questu stamperà:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Impresta un iteratore, invece di cunsumallu.
    ///
    /// Questu hè utile per permettà l'applicazione di adattatori iteratori mantenendu sempre a pruprietà di l'iteratore originale.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // se pruvemu à aduprà iter di novu, ùn funzionerà micca.
    /// // A seguente linea dà "errore: usu di u valore spustatu: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // pruvemu dinò
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // invece, aghjustemu in un .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // avà hè bè:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Trasforma un iteratore in una raccolta.
    ///
    /// `collect()` pò piglià qualcosa iterabile, è trasformallu in una raccolta pertinente.
    /// Questu hè unu di i metudi più putenti in a biblioteca standard, adupratu in una varietà di contesti.
    ///
    /// U mudellu più basicu in quale `collect()` hè adupratu hè di trasfurmà una cullizzioni in un'altra.
    /// Pigliate una cullizzioni, chjamate [`iter`] nantu à questu, fate unepoche di trasfurmazioni, è dopu `collect()` à a fine.
    ///
    /// `collect()` pò ancu creà casi di tippi chì ùn sò micca cullezzione tipiche.
    /// Per esempiu, un [`String`] pò esse custruitu da [`char`] s, è un iteratore di articuli [`Result<T, E>`][`Result`] pò esse raccoltu in `Result<Collection<T>, E>`.
    ///
    /// Vede l'esempii sottu per più.
    ///
    /// Perchè `collect()` hè cusì generale, pò causà prublemi cù l'inferenza di tippu.
    /// Cusì, `collect()` hè una di e poche volte chì vedrete a sintassi affettuosamente cunnisciuta cum'è 'turbofish': `::<>`.
    /// Questu aiuta à l'algoritmu di inferenza capisce specificamente in quale raccolta pruvate à raccoglie.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Innota chì avemu bisognu di u `: Vec<i32>` à manca.Questu hè perchè pudemu cullà in, per esempiu, un [`VecDeque<T>`] invece:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Aduprà u 'turbofish' invece di annotà `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Perchè `collect()` si preoccupa solu di ciò chì state raccogliendu, pudete ancu aduprà un suggerimentu di tipu parziale, `_`, cù u turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Aduprà `collect()` per fà un [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Se avete una lista di [`Risultatu<T, E>`][`Risultatu`] s, pudete aduprà `collect()` per vede se unu di elli hà fiascatu:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ci dà u primu errore
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ci dà a lista di e risposte
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Cunsuma un iteratore, creendu duie cullezzioni da ellu.
    ///
    /// U predicatu passatu à `partition()` pò restituisce `true`, o `false`.
    /// `partition()` restituisce una coppia, tutti l'elementi per i quali hà restituitu `true`, è tutti l'elementi per i quali hà restituitu `false`.
    ///
    ///
    /// Vede ancu [`is_partitioned()`] è [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Riordina l'elementi di questu iteratore *in locu* secondu u predicatu datu, tale chì tutti quelli chì restituiscenu `true` precedenu tutti quelli chì restituiscenu `false`.
    ///
    /// Restituisce u numeru di elementi `true` truvati.
    ///
    /// L'ordine relative di l'articuli partizionati ùn hè micca mantenutu.
    ///
    /// Vede ancu [`is_partitioned()`] è [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Spartimentu in locu trà pari è probabilità
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: duvemu inchietacci per u numeru di traboccu?L'unicu modu per avè più di
        // `usize::MAX` referenze mutevuli hè cù ZST, chì ùn sò micca utili per spartà ...

        // Queste funzioni di chiusura "factory" esistenu per evità a genericità in `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Truvate ripetutamente u primu `false` è scambiate cù l'ultimu `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Verifica se l'elementi di questu iteratore sò partizionati secondu u predicatu datu, tale chì tutti quelli chì restituiscenu `true` precedenu tutti quelli chì restituiscenu `false`.
    ///
    ///
    /// Vede ancu [`partition()`] è [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // O tutti l'articuli testanu `true`, o a prima clausula si ferma à `false` è verificemu chì ùn ci sia più articuli `true` dopu.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Un metudu iteratore chì applica una funzione finchè ritorna cù successu, producendu un solu valore finale.
    ///
    /// `try_fold()` piglia dui argumenti: un valore iniziale, è una chjusura cù dui argumenti: un 'accumulator', è un elementu.
    /// A chjusura sia torna cù successu, cù u valore chì l'accumulatore duverebbe avè per a prossima iterazione, o torna u fallimentu, cù un valore d'errore chì si propaga torna à u chjamante (short-circuiting) immediatamente.
    ///
    ///
    /// U valore iniziale hè u valore chì l'accumulatore averà nantu à a prima chjamata.Se l'applicazione di a chjusura hè riesciuta contr'à ogni elementu di l'iteratore, `try_fold()` restituisce l'accumulatore finale cum'è successu.
    ///
    /// U piegamentu hè utile ogni volta chì avete una raccolta di qualcosa, è vulete pruduce un valore unicu da ellu.
    ///
    /// # Nota à Implementatori
    ///
    /// Parechji di l'altri metudi (forward) anu implementazioni predefinite in termini di questu, allora pruvate à implementà questu esplicitamente se pò fà qualcosa di megliu cà l'implementazione predefinita di u ciclu `for`.
    ///
    /// In particulare, pruvate à avè sta chjamata `try_fold()` nantu à e parti internhe da chì questu iteratore hè cumpostu.
    /// Se sò necessarie più chiamate, l'operatore `?` pò esse pratice per incatenà u valore di l'accumulatore, ma attenti à qualsiasi invarianti chì devenu esse accolti prima di quelli primi ritorni.
    /// Questu hè un metudu `&mut self`, dunque l'iterazione deve esse ripresentibile dopu avè colpitu un errore quì.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a summa verificata di tutti l'elementi di u array
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Questa somma suprana quandu si aghjunghje l'elementu 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Perchè hè cortocircuitatu, l'elementi restanti sò sempre dispunibuli attraversu l'iteratore.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Un metudu iteratore chì applica una funzione fallibile à ogni articulu in l'iteratore, fermendu à u primu errore è restituendu quellu errore.
    ///
    ///
    /// Questu pò ancu esse pensatu cum'è a forma fallibile di [`for_each()`] o cum'è a versione senza statu di [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Hè cortocircuitatu, cusì l'articuli restanti sò sempre in l'iteratore:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Piega ogni elementu in un accumulatore applicendu un'operazione, restituendu u risultatu finale.
    ///
    /// `fold()` piglia dui argumenti: un valore iniziale, è una chjusura cù dui argumenti: un 'accumulator', è un elementu.
    /// A chiusura restituisce u valore chì l'accumulatore deve avè per a prossima iterazione.
    ///
    /// U valore iniziale hè u valore chì l'accumulatore averà nantu à a prima chjamata.
    ///
    /// Dopu avè applicatu sta chjusura à ogni elementu di l'iteratore, `fold()` restituisce l'accumulatore.
    ///
    /// Questa operazione hè qualchì volta chjamata 'reduce' o 'inject'.
    ///
    /// U piegamentu hè utile ogni volta chì avete una raccolta di qualcosa, è vulete pruduce un valore unicu da ellu.
    ///
    /// Note: `fold()`, è metudi simili chì traversanu l'iteratore sanu, ùn ponu finisce per iteratori infiniti, ancu in traits per i quali un risultatu hè determinabile in tempu finitu.
    ///
    /// Note: [`reduce()`] pò esse adupratu per aduprà u primu elementu cum'è valore iniziale, se u tippu di accumulatore è u tippu di articulu hè u listessu.
    ///
    /// # Nota à Implementatori
    ///
    /// Parechji di l'altri metudi (forward) anu implementazioni predefinite in termini di questu, allora pruvate à implementà questu esplicitamente se pò fà qualcosa di megliu cà l'implementazione predefinita di u ciclu `for`.
    ///
    ///
    /// In particulare, pruvate à avè sta chjamata `fold()` nantu à e parti internhe da chì questu iteratore hè cumpostu.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a somma di tutti l'elementi di a matrice
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Caminemu per ogni passu di l'iterazione quì:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// È cusì, u nostru risultatu finale, `6`.
    ///
    /// Hè cumunu per e persone chì ùn anu micca adupratu assai iteratori per aduprà un ciclu `for` cun una lista di cose per custruisce un risultatu.Quelli ponu esse trasformati in `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // per ciclu:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // sò listessi
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Riduce l'elementi à unu solu, applicendu ripetutamente un'operazione riduttrice.
    ///
    /// Se l'iteratore hè vacante, restituisce [`None`];altrimenti, restituisce u risultatu di a riduzzione.
    ///
    /// Per l'iteratori cun almenu un elementu, questu hè uguale à [`fold()`] cù u primu elementu di l'iteratore cum'è u valore iniziale, pieghendu ogni elementu successivu in questu.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Truvate u valore massimu:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Pruvede sì ogni elementu di l'iteratore currisponde à un predicatu.
    ///
    /// `all()` piglia una chjusura chì rende `true` o `false`.Applica questa chjusura à ogni elementu di l'iteratore, è se tutti restituiscenu `true`, allora cusì face `all()`.
    /// Se qualchissia torna `false`, restituisce `false`.
    ///
    /// `all()` hè in cortocircuitu;in altre parolle, smetterà di trasfurmà appena si trova un `false`, postu chì ùn importa ciò chì succede altru, u risultatu serà ancu `false`.
    ///
    ///
    /// Un iteratore viotu torna `true`.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Fermendu à u primu `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // pudemu sempre aduprà `iter`, chì ci sò più elementi.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Prove se qualchì elementu di l'iteratore currisponde à un predicatu.
    ///
    /// `any()` piglia una chjusura chì rende `true` o `false`.Applica questa chjusura à ogni elementu di l'iteratore, è se qualcunu di elli restituisce `true`, allora ancu `any()`.
    /// Se tutti tornanu `false`, torna `false`.
    ///
    /// `any()` hè in cortocircuitu;in altre parolle, smetterà di trasfurmà appena si trova un `true`, postu chì ùn importa ciò chì succede altru, u risultatu serà ancu `true`.
    ///
    ///
    /// Un iteratore viotu torna `false`.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Fermendu à u primu `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // pudemu sempre aduprà `iter`, chì ci sò più elementi.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Ricerca per un elementu di un iteratore chì soddisfa un predicatu.
    ///
    /// `find()` piglia una chjusura chì rende `true` o `false`.
    /// Applica questa chjusura à ogni elementu di l'iteratore, è se qualcunu di elli restituisce `true`, allora `find()` restituisce [`Some(element)`].
    /// Se tutti tornanu `false`, torna [`None`].
    ///
    /// `find()` hè in cortocircuitu;in altre parolle, fermerà a trasfurmazione appena a chjusura ritorna `true`.
    ///
    /// Perchè `find()` piglia una riferenza, è parechji iteratori iteranu nantu à e referenze, questu porta à una situazione possibbilmente cunfusa induve l'argumentu hè una doppia riferenza.
    ///
    /// Pudete vede questu effettu in l'esempii sottu, cù `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Fermendu à u primu `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // pudemu sempre aduprà `iter`, chì ci sò più elementi.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Innota chì `iter.find(f)` hè equivalente à `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Applica a funzione à l'elementi di l'iteratore è restituisce u primu resultatu senza nisunu.
    ///
    ///
    /// `iter.find_map(f)` hè equivalente à `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Applica a funzione à l'elementi di l'iteratore è restituisce u primu risultatu veru o u primu errore.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Ricerche per un elementu in un iteratore, restituendu u so indice.
    ///
    /// `position()` piglia una chjusura chì rende `true` o `false`.
    /// Applica questa chjusura à ogni elementu di l'iteratore, è se unu di elli restituisce `true`, allora `position()` restituisce [`Some(index)`].
    /// Se tutti tornanu `false`, torna [`None`].
    ///
    /// `position()` hè in cortocircuitu;in altre parolle, fermerà a trasfurmazione appena trova un `true`.
    ///
    /// # Cumportamentu Overflow
    ///
    /// U metudu ùn guarda micca da u overflow, allora s'ellu ci hè più di [`usize::MAX`] elementi chì ùn currispondenu micca, produce u risultatu sbagliatu o panics.
    ///
    /// Se l'affirmazioni di debug sò attivate, un panic hè garantitu.
    ///
    /// # Panics
    ///
    /// Sta funzione puderia panic se l'iteratore hà più di `usize::MAX` elementi chì ùn currispondenu micca.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Fermendu à u primu `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // pudemu sempre aduprà `iter`, chì ci sò più elementi.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // L'indice restituitu dipende da u statu di l'iteratore
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Ricerche per un elementu in un iteratore da a diritta, restituendu u so indice.
    ///
    /// `rposition()` piglia una chjusura chì rende `true` o `false`.
    /// Applica questa chjusura à ogni elementu di l'iteratore, partendu da a fine, è se unu di elli restituisce `true`, allora `rposition()` restituisce [`Some(index)`].
    ///
    /// Se tutti tornanu `false`, torna [`None`].
    ///
    /// `rposition()` hè in cortocircuitu;in altre parolle, fermerà a trasfurmazione appena trova un `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Fermendu à u primu `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // pudemu sempre aduprà `iter`, chì ci sò più elementi.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Ùn ci hè bisognu di un cuntrollu di overflow quì, perchè `ExactSizeIterator` implica chì u numeru di elementi si adatta à un `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Restituisce l'elementu massimu di un iteratore.
    ///
    /// Se parechji elementi sò ugualmente massimi, l'ultimu elementu hè restituitu.
    /// Se l'iteratore hè viotu, [`None`] hè restituitu.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Restituisce l'elementu minimu di un iteratore.
    ///
    /// Se parechji elementi sò ugualmente minimi, u primu elementu hè restituitu.
    /// Se l'iteratore hè viotu, [`None`] hè restituitu.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Restituisce l'elementu chì dà u valore massimu da a funzione specificata.
    ///
    ///
    /// Se parechji elementi sò ugualmente massimi, l'ultimu elementu hè restituitu.
    /// Se l'iteratore hè viotu, [`None`] hè restituitu.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Restituisce l'elementu chì dà u valore massimu rispettu à a funzione di paragone specificata.
    ///
    ///
    /// Se parechji elementi sò ugualmente massimi, l'ultimu elementu hè restituitu.
    /// Se l'iteratore hè viotu, [`None`] hè restituitu.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Restituisce l'elementu chì dà u valore minimu da a funzione specificata.
    ///
    ///
    /// Se parechji elementi sò ugualmente minimi, u primu elementu hè restituitu.
    /// Se l'iteratore hè viotu, [`None`] hè restituitu.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Restituisce l'elementu chì dà u valore minimu rispettu à a funzione di paragone specificata.
    ///
    ///
    /// Se parechji elementi sò ugualmente minimi, u primu elementu hè restituitu.
    /// Se l'iteratore hè viotu, [`None`] hè restituitu.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Inverte a direzzione di un iteratore.
    ///
    /// Di solitu, l'iteratori iteranu da manca à diritta.
    /// Dopu aduprà `rev()`, un iteratore invece itererà da diritta à manca.
    ///
    /// Questu hè pussibile solu sì l'iteratore hà una fine, allora `rev()` funziona solu nantu à [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Converte un iteratore di coppie in una coppia di contenitori.
    ///
    /// `unzip()` cunsuma un interu iteratore di coppie, producendu duie raccolte: una da l'elementi di sinistra di e coppie, è una da l'elementi ghjusti.
    ///
    ///
    /// Sta funzione hè, in qualchì sensu, u cuntrariu di [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Crea un iteratore chì copia tutti i so elementi.
    ///
    /// Questu hè utile quandu avete un iteratore sopra `&T`, ma avete bisognu di un iteratore sopra `T`.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // copiatu hè listessu chì .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Crea un iteratore chì [`clone`] s tutti i so elementi.
    ///
    /// Questu hè utile quandu avete un iteratore sopra `&T`, ma avete bisognu di un iteratore sopra `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // clonatu hè listessu chì .map(|&x| x), per numeri interi
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Ripete un iteratore senza fine.
    ///
    /// Invece di piantà à [`None`], l'iteratore ripartirà invece, da u principiu.Dopu avè ripetitu l'iterazione, ricumincierà à u principiu.È dinò.
    /// È dinò.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Riassume l'elementi di un iteratore.
    ///
    /// Piglia ogni elementu, li aghjunghje inseme, è restituisce u risultatu.
    ///
    /// Un iteratore vacante restituisce u valore zero di u tippu.
    ///
    /// # Panics
    ///
    /// Quandu chjamate `sum()` è un tippu interu primitivu hè restituitu, stu metudu serà panic se u computazione overflows è debug assertions sò attivati.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Itera annantu à tuttu l'iteratore, multiplicendu tutti l'elementi
    ///
    /// Un iteratore vacante restituisce u valore unicu di u tippu.
    ///
    /// # Panics
    ///
    /// Quandu si chjama `product()` è un tippu interu primitivu hè restituitu, u metudu serà panic se u computing overflows è debug assertions sò attivati.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) confronta l'elementi di stu [`Iterator`] cù quelli di l'altru.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) confronta l'elementi di stu [`Iterator`] cù quelli di l'altru in quantu à a funzione di paragone specificata.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) confronta l'elementi di stu [`Iterator`] cù quelli di l'altru.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) confronta l'elementi di stu [`Iterator`] cù quelli di l'altru in quantu à a funzione di paragone specificata.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Determina se l'elementi di stu [`Iterator`] sò uguali à quelli di l'altru.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Determina se l'elementi di stu [`Iterator`] sò uguali à quelli di un altru in quantu à a funzione d'ugualità specificata.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Determina se l'elementi di stu [`Iterator`] sò inuguali à quelli di l'altru.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Determina se l'elementi di questu [`Iterator`] sò [lexicographically](Ord#lexicographical-comparison) menu di quelli di l'altru.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Determina se l'elementi di stu [`Iterator`] sò [lexicographically](Ord#lexicographical-comparison) menu o uguali à quelli di l'altru.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Determina se l'elementi di stu [`Iterator`] sò [lexicographically](Ord#lexicographical-comparison) più grande di quelli di l'altru.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Determina se l'elementi di stu [`Iterator`] sò [lexicographically](Ord#lexicographical-comparison) più grande o uguale à quelli di un altru.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Verifica se l'elementi di questu iteratore sò ordinati.
    ///
    /// Questu hè, per ogni elementu `a` è u so elementu seguente `b`, `a <= b` deve tene.Se l'iteratore rende esattamente zero o un elementu, `true` hè restituitu.
    ///
    /// Innota chì sì `Self::Item` hè solu `PartialOrd`, ma micca `Ord`, a definizione sopra implica chì sta funzione restituisce `false` se dui elementi consecutivi ùn sò micca paragunabili.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Verifica se l'elementi di questu iteratore sò classificati aduprendu a funzione di comparatore data.
    ///
    /// Invece di aduprà `PartialOrd::partial_cmp`, sta funzione usa a funzione `compare` data per determinà l'ordine di dui elementi.
    /// In più di questu, hè equivalente à [`is_sorted`];vede a so ducumentazione per più infurmazione.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Verifica se l'elementi di questu iteratore sò urdinati cù a funzione di estrazione di chjave data.
    ///
    /// Invece di paragunà l'elementi di l'iteratore direttamente, sta funzione paraguneghja e chjave di l'elementi, cumu determinatu da `f`.
    /// In più di questu, hè equivalente à [`is_sorted`];vede a so ducumentazione per più infurmazione.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Vede [TrustedRandomAccess]
    // U nome insolitu hè di evità collisioni di nomi in a risoluzione di u metudu vede #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}