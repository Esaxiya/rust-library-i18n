// ignore-tidy-filelength

//! Gestione di e fette è manipulazione.
//!
//! Per più dettagli vedi [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Implementazione pura rust memchr, presa da rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Sta funzione hè publica solu perchè ùn ci hè altru modu per testà unità heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Restituisce u numeru di elementi in a fetta.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SICUREZZA: sonu custante perchè trasmutemu u campu di lunghezza cum'è usu (chì deve esse)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SICUREZZA: hè sicuru perchè `&[T]` è `FatPtr<T>` anu u listessu schema.
            // Solu `std` pò fà sta garanzia.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Rimpiazzà cù `crate::ptr::metadata(self)` quandu hè custante.
            // A sta scrittura questu causa un errore "Const-stable functions can only call other const-stable functions".
            //

            // SICUREZZA: L'accessu à u valore da l'unione `PtrRepr` hè sicuru postu chì * const T
            // è PtrComponents<T>avè i stessi schemi di memoria.
            // Solu std pò fà sta garanzia.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Restituisce `true` se a fetta hà una lunghezza di 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Restituisce u primu elementu di a fetta, o `None` se hè viotu.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Restituisce un puntatore mutevule à u primu elementu di a fetta, o `None` se hè viotu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Restituisce u primu è tuttu u restu di l'elementi di a fetta, o `None` se hè viotu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Restituisce u primu è tuttu u restu di l'elementi di a fetta, o `None` se hè viotu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Restituisce l'ultimu è tuttu u restu di l'elementi di a fetta, o `None` se hè viotu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Restituisce l'ultimu è tuttu u restu di l'elementi di a fetta, o `None` se hè viotu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Restituisce l'ultimu elementu di a fetta, o `None` se hè viotu.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Restituisce un puntatore mudificabile à l'ultimu elementu in a fetta.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Restituisce una riferenza à un elementu o sottuslice secondu u tippu d'indice.
    ///
    /// - S'ellu hè datu una pusizione, restituisce un riferimentu à l'elementu in quella pusizione o `None` se fora di i limiti.
    ///
    /// - Se hè datu un intervallu, restituisce a sottuslice currispondente à quellu intervallu, o `None` se fora di i limiti.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Restituisce un riferimentu mutevule à un elementu o sottuclice secondu u tippu d'indice (vede [`get`]) o `None` se l'indice hè fora di limiti.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Restituisce un riferimentu à un elementu o sottuclice, senza fà verificà i limiti.
    ///
    /// Per una alternativa sicura vedi [`get`].
    ///
    /// # Safety
    ///
    /// Chjamà stu metudu cù un indice fora di i limiti hè *[cumpurtamentu indefinitu]* ancu se a riferenza resultante ùn hè micca usata.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SEGURITÀ: u chjamante deve rispettà a maiò parte di i requisiti di sicurezza per `get_unchecked`;
        // a fetta hè dereferencable perchè `self` hè un riferimentu sicuru.
        // U puntatore restituitu hè sicuru perchè l'implimenti di `SliceIndex` devenu garantì chì hè.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Restituisce un riferimentu mutevule à un elementu o sottuslice, senza fà verificà i limiti.
    ///
    /// Per una alternativa sicura vedi [`get_mut`].
    ///
    /// # Safety
    ///
    /// Chjamà stu metudu cù un indice fora di i limiti hè *[cumpurtamentu indefinitu]* ancu se a riferenza resultante ùn hè micca usata.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SEGURITÀ: u chjamante deve rispettà i requisiti di sicurezza per `get_unchecked_mut`;
        // a fetta hè dereferencable perchè `self` hè un riferimentu sicuru.
        // U puntatore restituitu hè sicuru perchè l'implimenti di `SliceIndex` devenu garantì chì hè.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Restituisce un puntatore grezzu à u buffer di a fetta.
    ///
    /// U chjamante deve assicurà chì a fetta supera u puntatore chì sta funzione ritorna, altrimenti finirà per indicà a spazzatura.
    ///
    /// U chjamante deve ancu assicurà chì a memoria chì u puntatore (non-transitively) punta à ùn sia mai scritta (eccettu in un `UnsafeCell`) aduprendu questu puntatore o qualsiasi puntatore derivatu da ellu.
    /// Se avete bisognu di mutà u cuntenutu di a fetta, aduprate [`as_mut_ptr`].
    ///
    /// Mudificà u cuntaineru riferitu da sta fetta pò fà riallocà u so buffer, ciò chì renderebbe ancu qualsiasi indicatore per ellu invalidu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Restituisce un puntatore mutabile periculosu in u buffer di a fetta.
    ///
    /// U chjamante deve assicurà chì a fetta supera u puntatore chì sta funzione ritorna, altrimenti finirà per indicà a spazzatura.
    ///
    /// Mudificà u cuntaineru riferitu da sta fetta pò fà riallocà u so buffer, ciò chì renderebbe ancu qualsiasi indicatore per ellu invalidu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Restituisce i dui puntatori grezzi attraversendu a fetta.
    ///
    /// A gamma restituita hè mezu aperta, ciò chì significa chì u puntatore finale punta *un passatu* l'ultimu elementu di a fetta.
    /// In questu modu, una fetta viota hè rappresentata da dui puntatori uguali, è a differenza trà i dui puntatori rappresenta a dimensione di a fetta.
    ///
    /// Vede [`as_ptr`] per avvertenze nantu à l'usu di questi indicatori.U puntatore finale richiede una prudenza in più, perchè ùn punta micca à un elementu validu in a fetta.
    ///
    /// Sta funzione hè utile per interagisce cù interfacce straniere chì usanu dui puntatori per riferisce à una serie di elementi in memoria, cume hè cumunu in C++ .
    ///
    ///
    /// Pò ancu esse utile per verificà se un puntatore à un elementu si riferisce à un elementu di sta fetta:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SICUREZZA: U `add` quì hè sicuru, perchè:
        //
        //   - Entrambi i puntatori facenu parte di u listessu oggettu, cume u puntu direttu passatu l'oggettu conta ancu.
        //
        //   - A dimensione di a fetta ùn hè mai più grande di byte isize::MAX, cum'è nutatu quì:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Ùn ci hè micca involucrazione intornu, cum'è e fette ùn avvolenu micca a fine di u spaziu di indirizzu.
        //
        // Vede a documentazione di pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Restituisce i dui puntatori mutevi periculosi chì abbraccianu a fetta.
    ///
    /// A gamma restituita hè mezu aperta, ciò chì significa chì u puntatore finale punta *un passatu* l'ultimu elementu di a fetta.
    /// In questu modu, una fetta viota hè rappresentata da dui puntatori uguali, è a differenza trà i dui puntatori rappresenta a dimensione di a fetta.
    ///
    /// Vede [`as_mut_ptr`] per avvertenze nantu à l'usu di questi indicatori.
    /// U puntatore finale richiede una prudenza in più, perchè ùn punta micca à un elementu validu in a fetta.
    ///
    /// Sta funzione hè utile per interagisce cù interfacce straniere chì usanu dui puntatori per riferisce à una serie di elementi in memoria, cume hè cumunu in C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SICUREZZA: Vede as_ptr_range() sopra per quessa `add` quì hè sicuru.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Scambia dui elementi in a fetta.
    ///
    /// # Arguments
    ///
    /// * a, L'indice di u primu elementu
    /// * b, L'indice di u secondu elementu
    ///
    /// # Panics
    ///
    /// Panics se `a` o `b` sò fora di i limiti.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Ùn pudemu micca piglià dui prestiti mutevuli da un vector, allora invece usate puntatori grezzi.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SICUREZZA: `pa` è `pb` sò stati creati da referenze mutevule sicure è riferite
        // à elementi in a fetta è dunque sò garantiti per esse validi è allineati.
        // Nota chì accede à l'elementi daretu à `a` è `b` hè verificatu è serà panic quandu fora di i limiti.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Inverte l'ordine di l'elementi in a fetta, in postu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Per tippi assai chjuchi, tuttu l'individuu leghje in u percorsu nurmale funziona male.
        // Pudemu fà megliu, datu load/store senza allinamentu efficiente, caricendu un pezzu più grande è inverendu un registru.
        //

        // Idealmente LLVM faria questu per noi, cume sà megliu di noi se e letture non allineate sò efficienti (postu chì cambia trà e diverse versioni ARM, per esempiu) è quale seria a migliore dimensione di pezzu.
        // Sfurtunatamente, à partire da LLVM 4.0 (2017-05) si sviloppa solu u ciclu, allora ci vole à fà questu noi stessi.
        // (Ipotesi: l'inversu hè fastidiosu perchè i lati ponu esse allineati diversamente-sarà, quandu a lunghezza hè strana-dunque ùn ci hè manera di emette pre-è postludii per aduprà SIMD cumpletamente allineati à mezu).
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Aduprate u llvm.bswap intrinsicu per riversà u8s in un usu
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SICUREZZA: Ci hè parechje cose da verificà quì:
                //
                // - Innota chì `chunk` hè o 4 o 8 per via di a verificazione cfg sopra.Cusì `chunk - 1` hè pusitivu.
                // - L'indexazione cù l'indice `i` hè bella cum'è a verificazione di ciclu garantisce
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - L'indexazione cù l'indice `ln - i - chunk = ln - (i + chunk)` hè bella:
                //   - `i + chunk > 0` hè trivialmente veru.
                //   - U cuntrollu di ciclu garantisce:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, cusì a sottrazione ùn sottumette micca.
                // - E chjamate `read_unaligned` è `write_unaligned` vanu bè:
                //   - `pa` punti à l'indici `i` induve `i < ln / 2 - (chunk - 1)` (vede sopra) è `pb` punti à l'indici `ln - i - chunk`, cusì tramindui sò almenu `chunk` assai byte da a fine di `self`.
                //
                //   - Ogni memoria inizializata hè valida `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Aduprate rotate-by-16 per riversà u16s in un u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SICUREZZA: Un u32 senza allineamentu pò esse lettu da `i` se `i + 1 < ln`
                // (è ovviamente `i < ln`), perchè ogni elementu hè 2 byte è stemu leggendu 4.
                //
                // `i + chunk - 1 < ln / 2` # mentre cundizione
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Siccomu hè menu di a lunghezza divisa per 2, allora deve esse in limiti.
                //
                // Ciò significa ancu chì a condizione `0 < i + chunk <= ln` hè sempre rispettata, assicurendu chì u puntatore `pb` pò esse adupratu in modu sicuru.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SICUREZZA: `i` hè inferiore à a mità di a lunghezza di a fetta cusì
            // accede à `i` è `ln - i - 1` hè sicuru (`i` cumencia à 0 è ùn anderà più luntanu da `ln / 2 - 1`).
            // I puntatori resultanti `pa` è `pb` sò dunque validi è allineati, è ponu esse letti è scritti à.
            //
            //
            unsafe {
                // Scambià periculosu per evità i limiti verificate in scambiu sicuru.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Restituisce un iteratore sopra a fetta.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Restituisce un iteratore chì permette di mudificà ogni valore.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Restituisce un iteratore per tutte e windows cunfinanti di lunghezza `size`.
    /// U windows si sovrappone.
    /// Se a fetta hè più corta cà `size`, l'iteratore ùn restituisce micca valori.
    ///
    /// # Panics
    ///
    /// Panics se `size` hè 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se a fetta hè più corta cà `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Restituisce un iteratore nantu à l'elementi `chunk_size` di a fetta à a volta, partendu da u principiu di a fetta.
    ///
    /// I pezzi sò fette è ùn si sovrapponu.Se `chunk_size` ùn divide micca a lunghezza di a fetta, allora l'ultimu pezzu ùn averà micca lunghezza `chunk_size`.
    ///
    /// Vede [`chunks_exact`] per una variante di questu iteratore chì restituisce pezzi di elementi sempre esattamente `chunk_size`, è [`rchunks`] per u listessu iteratore ma partendu da a fine di a fetta.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` hè 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Restituisce un iteratore nantu à l'elementi `chunk_size` di a fetta à a volta, partendu da u principiu di a fetta.
    ///
    /// I pezzi sò fette mutevuli, è ùn si sovrapponu.Se `chunk_size` ùn divide micca a lunghezza di a fetta, allora l'ultimu pezzu ùn averà micca lunghezza `chunk_size`.
    ///
    /// Vede [`chunks_exact_mut`] per una variante di questu iteratore chì restituisce pezzi di elementi sempre esattamente `chunk_size`, è [`rchunks_mut`] per u listessu iteratore ma partendu da a fine di a fetta.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` hè 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Restituisce un iteratore nantu à l'elementi `chunk_size` di a fetta à a volta, partendu da u principiu di a fetta.
    ///
    /// I pezzi sò fette è ùn si sovrapponu.
    /// Se `chunk_size` ùn divide micca a lunghezza di a fetta, allora l'ultimi elementi `chunk_size-1` saranu omessi è ponu esse recuperati da a funzione `remainder` di l'iteratore.
    ///
    ///
    /// A causa di ogni pezzu chì hà esattamente elementi `chunk_size`, u compilatore pò spessu ottimizà u codice resultante megliu cà in u casu di [`chunks`].
    ///
    /// Vede [`chunks`] per una variante di questu iteratore chì restituisce ancu u restu cum'è un pezzu più chjucu, è [`rchunks_exact`] per u listessu iteratore ma à partesi da a fine di a fetta.
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` hè 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Restituisce un iteratore nantu à l'elementi `chunk_size` di a fetta à a volta, partendu da u principiu di a fetta.
    ///
    /// I pezzi sò fette mutevuli, è ùn si sovrapponu.
    /// Se `chunk_size` ùn divide micca a lunghezza di a fetta, allora l'ultimi elementi `chunk_size-1` saranu omessi è ponu esse recuperati da a funzione `into_remainder` di l'iteratore.
    ///
    ///
    /// A causa di ogni pezzu chì hà esattamente elementi `chunk_size`, u compilatore pò spessu ottimizà u codice resultante megliu cà in u casu di [`chunks_mut`].
    ///
    /// Vede [`chunks_mut`] per una variante di questu iteratore chì restituisce ancu u restu cum'è un pezzu più chjucu, è [`rchunks_exact_mut`] per u listessu iteratore ma à partesi da a fine di a fetta.
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` hè 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Sparte a fetta in una fetta di matrici d'elementi `N`, supponendu chì ùn ci sia più restu.
    ///
    ///
    /// # Safety
    ///
    /// Questu pò esse chjamatu solu quandu
    /// - A fetta si divide esattamente in pezzi N-elementu (alias `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SICUREZZA: I pezzi di 1 elementu ùn anu mai restu
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SICUREZZA: A lunghezza di a fetta (6) hè un multiplu di 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Queste seranu sane:
    /// // lasciemu pezzi: &[[_;5]]= slice.as_chunks_unchecked()//A lunghezza di a fetta ùn hè micca un multiplu di 5 lasciate pezzi:&[[_;0]]= slice.as_chunks_unchecked()//Chunks di lunghezza zero ùn sò mai permessi
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SICUREZZA: A nostra precondizione hè esattamente ciò chì hè necessariu per chjamà cusì
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SICUREZZA: Avemu lanciatu una fetta di elementi `new_len * N` in
        // una fetta di `new_len` assai elementi `N` pezzi.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Divide a fetta in una fetta di matrici d'elementi `N`, à partesi da u principiu di a fetta, è una fetta restante cù lunghezza strettamente inferiore à `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` hè 0. Questa verificazione sarà probabilmente cambiata in un errore di tempu di compilazione prima chì stu metudu sia stabilizatu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SICUREZZA: Avemu digià in panicu per cero, è assicuratu da a custruzzione
        // chì a lunghezza di a sottuslice hè multipla di N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Sparte a fetta in una fetta di matrici di l'elementu `N`, cuminciendu à a fine di a fetta, è una fetta restante cù lunghezza strettamente menu di `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` hè 0. Questa verificazione sarà probabilmente cambiata in un errore di tempu di compilazione prima chì stu metudu sia stabilizatu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SICUREZZA: Avemu digià in panicu per cero, è assicuratu da a custruzzione
        // chì a lunghezza di a sottuslice hè multipla di N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Restituisce un iteratore nantu à l'elementi `N` di a fetta à a volta, partendu da u principiu di a fetta.
    ///
    /// I pezzi sò riferimenti di matriculazione è ùn si sovrapponu.
    /// Se `N` ùn divide micca a lunghezza di a fetta, allora l'ultimi elementi `N-1` saranu omessi è ponu esse recuperati da a funzione `remainder` di l'iteratore.
    ///
    ///
    /// Stu metudu hè l'equivalente genericu const di [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics se `N` hè 0. Questa verificazione sarà probabilmente cambiata in un errore di tempu di compilazione prima chì stu metudu sia stabilizatu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Sparte a fetta in una fetta di matrici d'elementi `N`, supponendu chì ùn ci sia più restu.
    ///
    ///
    /// # Safety
    ///
    /// Questu pò esse chjamatu solu quandu
    /// - A fetta si divide esattamente in pezzi N-elementu (alias `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SICUREZZA: I pezzi di 1 elementu ùn anu mai restu
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SICUREZZA: A lunghezza di a fetta (6) hè un multiplu di 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Queste seranu sane:
    /// // lasciemu pezzi: &[[_;5]]= slice.as_chunks_unchecked_mut()//A lunghezza di a fetta ùn hè micca un multiplu di 5 lasciate pezzi:&[[_;0]]= slice.as_chunks_unchecked_mut()//Chunks di lunghezza zero ùn sò mai permessi
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SICUREZZA: A nostra precondizione hè esattamente ciò chì hè necessariu per chjamà cusì
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SICUREZZA: Avemu lanciatu una fetta di elementi `new_len * N` in
        // una fetta di `new_len` assai elementi `N` pezzi.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Divide a fetta in una fetta di matrici d'elementi `N`, à partesi da u principiu di a fetta, è una fetta restante cù lunghezza strettamente inferiore à `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` hè 0. Questa verificazione sarà probabilmente cambiata in un errore di tempu di compilazione prima chì stu metudu sia stabilizatu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SICUREZZA: Avemu digià in panicu per cero, è assicuratu da a custruzzione
        // chì a lunghezza di a sottuslice hè multipla di N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Sparte a fetta in una fetta di matrici di l'elementu `N`, cuminciendu à a fine di a fetta, è una fetta restante cù lunghezza strettamente menu di `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` hè 0. Questa verificazione sarà probabilmente cambiata in un errore di tempu di compilazione prima chì stu metudu sia stabilizatu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SICUREZZA: Avemu digià in panicu per cero, è assicuratu da a custruzzione
        // chì a lunghezza di a sottuslice hè multipla di N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Restituisce un iteratore nantu à l'elementi `N` di a fetta à a volta, partendu da u principiu di a fetta.
    ///
    /// I chunks sò riferenzi mutevuli di array è ùn si sovrapponu.
    /// Se `N` ùn divide micca a lunghezza di a fetta, allora l'ultimi elementi `N-1` saranu omessi è ponu esse recuperati da a funzione `into_remainder` di l'iteratore.
    ///
    ///
    /// Stu metudu hè l'equivalente genericu const di [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics se `N` hè 0. Questa verificazione sarà probabilmente cambiata in un errore di tempu di compilazione prima chì stu metudu sia stabilizatu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Restituisce un iteratore sovrappostu windows di `N` elementi di una fetta, partendu da u principiu di a fetta.
    ///
    ///
    /// Questu hè l'equivalente genericu const di [`windows`].
    ///
    /// Se `N` hè più grande di a dimensione di a fetta, ùn restituverà micca windows.
    ///
    /// # Panics
    ///
    /// Panics se `N` hè 0.
    /// Questa verificazione sarà probabilmente cambiata in un errore di tempu di compilazione prima chì stu metudu sia stabilizatu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Restituisce un iteratore nantu à l'elementi `chunk_size` di a fetta à a volta, partendu da a fine di a fetta.
    ///
    /// I pezzi sò fette è ùn si sovrapponu.Se `chunk_size` ùn divide micca a lunghezza di a fetta, allora l'ultimu pezzu ùn averà micca lunghezza `chunk_size`.
    ///
    /// Vede [`rchunks_exact`] per una variante di questu iteratore chì restituisce pezzi di elementi sempre esattamente `chunk_size`, è [`chunks`] per u listessu iteratore ma partendu da u principiu di a fetta.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` hè 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Restituisce un iteratore nantu à l'elementi `chunk_size` di a fetta à a volta, partendu da a fine di a fetta.
    ///
    /// I pezzi sò fette mutevuli, è ùn si sovrapponu.Se `chunk_size` ùn divide micca a lunghezza di a fetta, allora l'ultimu pezzu ùn averà micca lunghezza `chunk_size`.
    ///
    /// Vede [`rchunks_exact_mut`] per una variante di questu iteratore chì restituisce pezzi di elementi sempre esattamente `chunk_size`, è [`chunks_mut`] per u listessu iteratore ma partendu da u principiu di a fetta.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` hè 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Restituisce un iteratore nantu à l'elementi `chunk_size` di a fetta à a volta, partendu da a fine di a fetta.
    ///
    /// I pezzi sò fette è ùn si sovrapponu.
    /// Se `chunk_size` ùn divide micca a lunghezza di a fetta, allora l'ultimi elementi `chunk_size-1` saranu omessi è ponu esse recuperati da a funzione `remainder` di l'iteratore.
    ///
    /// A causa di ogni pezzu chì hà esattamente elementi `chunk_size`, u compilatore pò spessu ottimizà u codice resultante megliu cà in u casu di [`chunks`].
    ///
    /// Vede [`rchunks`] per una variante di questu iteratore chì restituisce ancu u restu cum'è un pezzu più chjucu, è [`chunks_exact`] per u listessu iteratore ma cuminciendu à u principiu di a fetta.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` hè 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Restituisce un iteratore nantu à l'elementi `chunk_size` di a fetta à a volta, partendu da a fine di a fetta.
    ///
    /// I pezzi sò fette mutevuli, è ùn si sovrapponu.
    /// Se `chunk_size` ùn divide micca a lunghezza di a fetta, allora l'ultimi elementi `chunk_size-1` saranu omessi è ponu esse recuperati da a funzione `into_remainder` di l'iteratore.
    ///
    /// A causa di ogni pezzu chì hà esattamente elementi `chunk_size`, u compilatore pò spessu ottimizà u codice resultante megliu cà in u casu di [`chunks_mut`].
    ///
    /// Vede [`rchunks_mut`] per una variante di questu iteratore chì restituisce ancu u restu cum'è un pezzu più chjucu, è [`chunks_exact_mut`] per u listessu iteratore ma cuminciendu à u principiu di a fetta.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` hè 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Restituisce un iteratore sopra a fetta pruducendu corse non sovrapposte di elementi aduprendu u predicatu per separalli.
    ///
    /// U predicatu hè chjamatu nantu à dui elementi chì si seguitanu, significa chì u predicatu hè chjamatu in `slice[0]` è `slice[1]` poi in `slice[1]` è `slice[2]` ecc.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stu metudu pò esse adupratu per estrarre i sottuclici ordinati:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Restituisce un iteratore sopra a fetta chì produce run mutabili non sovrapposti di elementi chì utilizanu u predicatu per separalli.
    ///
    /// U predicatu hè chjamatu nantu à dui elementi chì si seguitanu, significa chì u predicatu hè chjamatu in `slice[0]` è `slice[1]` poi in `slice[1]` è `slice[2]` ecc.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stu metudu pò esse adupratu per estrarre i sottuclici ordinati:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Divide una fetta in duie in un indice.
    ///
    /// U primu cuntene tutti l'indici da `[0, mid)` (esclusu l'indice `mid` stessu) è u secondu cuntene tutti l'indici da `[mid, len)` (esclusu l'indice `len` stessu).
    ///
    ///
    /// # Panics
    ///
    /// Panics se `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SICUREZZA: `[ptr; mid]` è `[mid; len]` sò in `self`, chì
        // risponde à i requisiti di `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Divide una fetta mutabile in dui in un indice.
    ///
    /// U primu cuntene tutti l'indici da `[0, mid)` (esclusu l'indice `mid` stessu) è u secondu cuntene tutti l'indici da `[mid, len)` (esclusu l'indice `len` stessu).
    ///
    ///
    /// # Panics
    ///
    /// Panics se `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SICUREZZA: `[ptr; mid]` è `[mid; len]` sò in `self`, chì
        // risponde à i requisiti di `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Divide una fetta in duie in un indice, senza fà verificà i limiti.
    ///
    /// U primu cuntene tutti l'indici da `[0, mid)` (esclusu l'indice `mid` stessu) è u secondu cuntene tutti l'indici da `[mid, len)` (esclusu l'indice `len` stessu).
    ///
    ///
    /// Per una alternativa sicura vedi [`split_at`].
    ///
    /// # Safety
    ///
    /// Chjamà stu metudu cù un indice fora di i limiti hè *[cumpurtamentu indefinitu]* ancu se a riferenza resultante ùn hè micca usata.U chjamante hà da assicurà chì `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SICUREZZA: Chjamante hà da verificà chì `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Divide una fetta mutabile in dui in un indice, senza fà verificà i limiti.
    ///
    /// U primu cuntene tutti l'indici da `[0, mid)` (esclusu l'indice `mid` stessu) è u secondu cuntene tutti l'indici da `[mid, len)` (esclusu l'indice `len` stessu).
    ///
    ///
    /// Per una alternativa sicura vedi [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Chjamà stu metudu cù un indice fora di i limiti hè *[cumpurtamentu indefinitu]* ancu se a riferenza resultante ùn hè micca usata.U chjamante hà da assicurà chì `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SICUREZZA: Chjamante hà da verificà chì `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` è `[mid; len]` ùn si superponenu micca, dunque vultà una rifarenza mutevule hè bè.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Restituisce un iteratore sopra sottuclisi separati da elementi chì currispondenu à `pred`.
    /// L'elementu abbinatu ùn hè micca cuntenutu in i sottuclici.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se u primu elementu hè assuciatu, una fetta viota serà u primu elementu restituitu da l'iteratore.
    /// Similmente, se l'ultimu elementu in a fetta hè assuciatu, una fetta viota serà l'ultimu elementu restituitu da l'iteratore:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se dui elementi accurdati sò direttamente adiacenti, una fetta viota serà presente trà d'elli:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Restituisce un iteratore sopra sottuclisi mutevuli separati da elementi chì currispondenu à `pred`.
    /// L'elementu abbinatu ùn hè micca cuntenutu in i sottuclici.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Restituisce un iteratore sopra sottuclisi separati da elementi chì currispondenu à `pred`.
    /// L'elementu accumpagnatu hè cuntenutu à a fine di a sottuslice precedente cum'è terminatore.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se l'ultimu elementu di a fetta hè assuciatu, quellu elementu serà cunsideratu u terminatore di a fetta precedente.
    ///
    /// Questa fetta serà l'ultimu articulu restituitu da l'iteratore.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Restituisce un iteratore sopra sottuclisi mutevuli separati da elementi chì currispondenu à `pred`.
    /// L'elementu accumpagnatu hè cuntenutu in a sottuslice precedente cum'è terminatore.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Restituisce un iteratore sopra sottuclisi separati da elementi chì currispondenu à `pred`, cuminciendu à a fine di a fetta è travagliendu in daretu.
    /// L'elementu abbinatu ùn hè micca cuntenutu in i sottuclici.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Cum'è cù `split()`, se u primu o l'ultimu elementu hè assuciatu, una fetta viota serà u primu (o l'ultimu) elementu riturnatu da l'iteratore.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Restituisce un iteratore sopra sottuclisi mutevuli siparati da elementi chì currispondenu à `pred`, cuminciendu à a fine di a fetta è travagliendu in daretu.
    /// L'elementu abbinatu ùn hè micca cuntenutu in i sottuclici.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Restituisce un iteratore sopra sottuclisi separati da elementi chì currispondenu à `pred`, limitatu à u ritornu à u più articuli `n`.
    /// L'elementu abbinatu ùn hè micca cuntenutu in i sottuclici.
    ///
    /// L'ultimu elementu restituitu, s'ellu ci hè, cuntene u restu di a fetta.
    ///
    /// # Examples
    ///
    /// Stampa a fetta divisa una volta per numeri divisibili per 3 (vale à dì, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Restituisce un iteratore sopra sottuclisi separati da elementi chì currispondenu à `pred`, limitatu à u ritornu à u più articuli `n`.
    /// L'elementu abbinatu ùn hè micca cuntenutu in i sottuclici.
    ///
    /// L'ultimu elementu restituitu, s'ellu ci hè, cuntene u restu di a fetta.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Restituisce un iteratore sopra sottuclisi separati da elementi chì currispondenu à `pred` limitatu à u ritornu à u più articuli `n`.
    /// Questu principia à a fine di a fetta è travaglia in daretu.
    /// L'elementu abbinatu ùn hè micca cuntenutu in i sottuclici.
    ///
    /// L'ultimu elementu restituitu, s'ellu ci hè, cuntene u restu di a fetta.
    ///
    /// # Examples
    ///
    /// Stampa a fetta divisa una volta, à partesi da a fine, da numeri divisibili per 3 (vale à dì, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Restituisce un iteratore sopra sottuclisi separati da elementi chì currispondenu à `pred` limitatu à u ritornu à u più articuli `n`.
    /// Questu principia à a fine di a fetta è travaglia in daretu.
    /// L'elementu abbinatu ùn hè micca cuntenutu in i sottuclici.
    ///
    /// L'ultimu elementu restituitu, s'ellu ci hè, cuntene u restu di a fetta.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Restituisce `true` se a fetta cuntene un elementu cù u valore datu.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Se ùn avete micca un `&T`, ma solu un `&U` tale chì `T: Borrow<U>` (es
    /// `String: Imprestà<str>`), pudete aduprà `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // fetta di `String`
    /// assert!(v.iter().any(|e| e == "hello")); // cerca cù `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Restituisce `true` se `needle` hè un prefissu di a fetta.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Ritorna sempre `true` se `needle` hè una fetta viota:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Restituisce `true` se `needle` hè un suffissu di a fetta.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Ritorna sempre `true` se `needle` hè una fetta viota:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Restituisce un sottuclice cù u prefissu eliminatu.
    ///
    /// Se a fetta cumencia cù `prefix`, restituisce a sottuslice dopu u prefissu, impannillata in `Some`.
    /// Se `prefix` hè viotu, restituisce solu a fetta originale.
    ///
    /// Se a fetta ùn principia cù `prefix`, restituisce `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Sta funzione averà bisognu di riscrittura se è quandu SlicePattern diventa più sofisticatu.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Restituisce un sottuclice cù u suffissu eliminatu.
    ///
    /// Se a fetta finisce cù `suffix`, restituisce a sottuslice prima di u suffissu, impannillata in `Some`.
    /// Se `suffix` hè viotu, restituisce solu a fetta originale.
    ///
    /// Se a fetta ùn finisce micca cù `suffix`, restituisce `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Sta funzione averà bisognu di riscrittura se è quandu SlicePattern diventa più sofisticatu.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// U binariu cerca sta fetta sorte per un elementu datu.
    ///
    /// Se u valore si trova allora [`Result::Ok`] hè restituitu, cuntenendu l'indice di l'elementu chì currisponde.
    /// Se ci sò parechje partite, allora una di e partite puderia esse restituita.
    /// Se u valore ùn hè micca truvatu allora [`Result::Err`] hè restituitu, cuntenendu l'indice induve un elementu currispundente puderia esse inseritu mantenendu l'ordine ordinatu.
    ///
    ///
    /// Vede ancu [`binary_search_by`], [`binary_search_by_key`] è [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Cerca una seria di quattru elementi.
    /// U primu si trova, cù una pusizione unicamente determinata;u sicondu è u terzu ùn si trovanu;u quartu puderia currisponde à qualsiasi pusizione in `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Se vulete inserisce un articulu in un vector ordinatu, mantenendu l'ordine di sorte:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// U binariu cerca sta fetta sorte cù una funzione di comparatore.
    ///
    /// A funzione di comparatore deve implementà un ordine cuncordante cù l'ordine di sorte di a fetta sottostante, restituendu un codice d'ordine chì indica se u so argumentu hè `Less`, `Equal` o `Greater` u target desideratu.
    ///
    ///
    /// Se u valore si trova allora [`Result::Ok`] hè restituitu, cuntenendu l'indice di l'elementu chì currisponde.Se ci sò parechje partite, allora una di e partite puderia esse restituita.
    /// Se u valore ùn hè micca truvatu allora [`Result::Err`] hè restituitu, cuntenendu l'indice induve un elementu currispundente puderia esse inseritu mantenendu l'ordine ordinatu.
    ///
    /// Vede ancu [`binary_search`], [`binary_search_by_key`] è [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Cerca una seria di quattru elementi.U primu si trova, cù una pusizione unicamente determinata;u sicondu è u terzu ùn si trovanu;u quartu puderia currisponde à qualsiasi pusizione in `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SICUREZZA: a chjama hè resa sicura da i seguenti invarianti:
            // - `mid >= 0`
            // - `mid < size`: `mid` hè limitatu da `[left; right)` ligatu.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // A ragione per a quale usamu u flussu di cuntrollu if/else piuttostu ch'è u match hè perchè u match riorganizza l'operazioni di paragone, chì hè perfettu sensibile.
            //
            // Questu hè x86 asm per u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// U binariu cerca sta fetta ordinata cù una funzione di estrazione chjave.
    ///
    /// Assumemu chì a fetta hè urdinata per a chjave, per esempiu cù [`sort_by_key`] cù a stessa funzione di estrazione di chjave.
    ///
    /// Se u valore si trova allora [`Result::Ok`] hè restituitu, cuntenendu l'indice di l'elementu chì currisponde.
    /// Se ci sò parechje partite, allora una di e partite puderia esse restituita.
    /// Se u valore ùn hè micca truvatu allora [`Result::Err`] hè restituitu, cuntenendu l'indice induve un elementu currispundente puderia esse inseritu mantenendu l'ordine ordinatu.
    ///
    ///
    /// Vede ancu [`binary_search`], [`binary_search_by`] è [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Cerca una seria di quattru elementi in una fetta di coppie ordinate per i so secondi elementi.
    /// U primu si trova, cù una pusizione unicamente determinata;u sicondu è u terzu ùn si trovanu;u quartu puderia currisponde à qualsiasi pusizione in `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links hè permessu cum'è `slice::sort_by_key` hè in crate `alloc`, è per quessa ùn esiste ancu quandu custruisce `core`.
    //
    // ligami per crate downstream: #74481.Siccomu i primitivi sò documentati solu in libstd (#73423), questu ùn porta mai à ligami rotte in pratica.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Ordina a fetta, ma ùn pò micca priservà l'ordine di elementi uguali.
    ///
    /// Questa sorte hè instabile (vale à dì, pò riurdinà elementi uguali), in locu (vale à dì, ùn attribuisce micca), è *O*(*n*\*log(* n*)) u peghju casu.
    ///
    /// # Implementazione attuale
    ///
    /// L'algoritmu attuale hè basatu annantu à [pattern-defeating quicksort][pdqsort] da Orson Peters, chì combina u casu mediu veloce di quicksort aleatoriu cù u peghju casu più veloce di heapsort, mentre uttene u tempu lineare nantu à fette cù certi mudelli.
    /// Utilizza qualchì randomizazione per evità casi degenerati, ma cun un seed fissu per furnisce sempre un comportamentu deterministicu.
    ///
    /// Hè tipicamente più veloce di una classificazione stabile, eccettu in uni pochi di casi speciali, per esempiu, quandu a fetta si compone di parechje sequenze ordinate concatenate.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Ordina a fetta cù una funzione di comparatore, ma ùn pò micca priservà l'ordine di elementi uguali.
    ///
    /// Questa sorte hè instabile (vale à dì, pò riurdinà elementi uguali), in locu (vale à dì, ùn attribuisce micca), è *O*(*n*\*log(* n*)) u peghju casu.
    ///
    /// A funzione di comparatore deve definisce un urdinamentu tutale per l'elementi in a fetta.Se l'ordine ùn hè micca tutale, l'ordine di l'elementi ùn hè micca specificatu.Un ordine hè un ordine tutale se hè (per tutti `a`, `b` è `c`):
    ///
    /// * tutale è antisimmetricu: esattamente unu di `a < b`, `a == b` o `a > b` hè veru, è
    /// * transitivu, `a < b` è `b < c` implica `a < c`.U listessu deve tene per `==` è `>`.
    ///
    /// Per esempiu, mentre [`f64`] ùn implementa micca [`Ord`] perchè `NaN != NaN`, pudemu aduprà `partial_cmp` cum'è a nostra funzione di sorte quandu sapemu chì a fetta ùn cuntene un `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Implementazione attuale
    ///
    /// L'algoritmu attuale hè basatu annantu à [pattern-defeating quicksort][pdqsort] da Orson Peters, chì combina u casu mediu veloce di quicksort aleatoriu cù u peghju casu più veloce di heapsort, mentre uttene u tempu lineare nantu à fette cù certi mudelli.
    /// Utilizza qualchì randomizazione per evità casi degenerati, ma cun un seed fissu per furnisce sempre un comportamentu deterministicu.
    ///
    /// Hè tipicamente più veloce di una classificazione stabile, eccettu in uni pochi di casi speciali, per esempiu, quandu a fetta si compone di parechje sequenze ordinate concatenate.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // tri inversu
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Ordina a fetta cù una funzione di estrazione chjave, ma ùn pò micca priservà l'ordine di elementi uguali.
    ///
    /// Questa sorte hè instabile (vale à dì, pò riurdinà elementi uguali), in locu (vale à dì, ùn attribuisce micca), è *O*(m\* * n *\* log(*n*)) u peghju casu, induve a funzione chjave hè *O*(*m*).
    ///
    /// # Implementazione attuale
    ///
    /// L'algoritmu attuale hè basatu annantu à [pattern-defeating quicksort][pdqsort] da Orson Peters, chì combina u casu mediu veloce di quicksort aleatoriu cù u peghju casu più veloce di heapsort, mentre uttene u tempu lineare nantu à fette cù certi mudelli.
    /// Utilizza qualchì randomizazione per evità casi degenerati, ma cun un seed fissu per furnisce sempre un comportamentu deterministicu.
    ///
    /// A causa di a so strategia di chjamata chjave, [`sort_unstable_by_key`](#method.sort_unstable_by_key) hè prubabile di esse più lento ch'è [`sort_by_cached_key`](#method.sort_by_cached_key) in casi induve a funzione chjave hè cara.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Riordine a fetta in modu chì l'elementu in `index` sia in a so pusizione finale ordinata.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Riordine a fetta cù una funzione di comparatore tale chì l'elementu in `index` sia in a so pusizione finale ordinata.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Reurdinate a fetta cù una funzione di estrazione chjave tale chì l'elementu in `index` sia in a so pusizione finale ordinata.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Riordine a fetta in modu chì l'elementu in `index` sia in a so pusizione finale ordinata.
    ///
    /// Questa riurdinazione hà a pruprietà addizionale chì qualsiasi valore in a pusizione `i < index` serà menu o uguale à qualsiasi valore in una pusizione `j > index`.
    /// Inoltre, questu riordenamentu hè instabile (ie
    /// ogni numeru d'elementi uguali pò finisce in pusizione `index`), in locu (vale à dì
    /// ùn attribuisce micca), è *O*(*n*) u peghju casu.
    /// Sta funzione hè ancu/cunnisciuta cum'è "kth element" in altre librerie.
    /// Ritorna una tripletta di i valori seguenti: tutti l'elementi menu di quellu à l'indice datu, u valore à l'indice datu, è tutti l'elementi più grande di quellu à l'indice datu.
    ///
    ///
    /// # Implementazione attuale
    ///
    /// L'algoritmu attuale hè basatu annantu à a parte quickselect di u listessu algoritmu quicksort utilizatu per [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics quandu `index >= len()`, vale à dì sempre panics nantu à fette viote.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Truvate a mediana
    /// v.select_nth_unstable(2);
    ///
    /// // Semu solu garantiti chì a fetta serà unu di i seguenti, basatu nantu à a manera di sorte per l'indice specificatu.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Riordine a fetta cù una funzione di comparatore tale chì l'elementu in `index` sia in a so pusizione finale ordinata.
    ///
    /// Questa riurdinazione hà a pruprietà supplementaria chì qualsiasi valore in a pusizione `i < index` serà menu o uguale à qualsiasi valore in una pusizione `j > index` cù a funzione di comparatore.
    /// Inoltre, questu riordenamentu hè instabile (vale à dì ogni numeru d'elementi uguali pò finisce in pusizione `index`), in locu (vale à dì ùn attribuisce micca), è *O*(*n*) u peghju casu.
    /// Sta funzione hè cunnisciuta ancu cum'è "kth element" in altre librerie.
    /// Ritorna una tripletta di i valori seguenti: tutti l'elementi menu di quellu à l'indice datu, u valore à l'indice datu, è tutti l'elementi più grande di quellu à l'indice datu, aduprendu a funzione di comparatore furnita.
    ///
    ///
    /// # Implementazione attuale
    ///
    /// L'algoritmu attuale hè basatu annantu à a parte quickselect di u listessu algoritmu quicksort utilizatu per [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics quandu `index >= len()`, vale à dì sempre panics nantu à fette viote.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Truvate a mediana cum'è se a fetta fussi urdinata in ordine decrescente.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Semu solu garantiti chì a fetta serà unu di i seguenti, basatu nantu à a manera di sorte per l'indice specificatu.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reurdinate a fetta cù una funzione di estrazione chjave tale chì l'elementu in `index` sia in a so pusizione finale ordinata.
    ///
    /// Questa riurdinazione hà a pruprietà supplementaria chì qualsiasi valore in a pusizione `i < index` serà menu o uguale à qualsiasi valore in una pusizione `j > index` cù a funzione di estrazione chjave.
    /// Inoltre, questu riordenamentu hè instabile (vale à dì ogni numeru d'elementi uguali pò finisce in pusizione `index`), in locu (vale à dì ùn attribuisce micca), è *O*(*n*) u peghju casu.
    /// Sta funzione hè cunnisciuta ancu cum'è "kth element" in altre librerie.
    /// Ritorna una tripletta di i valori seguenti: tutti l'elementi menu di quellu à l'indice datu, u valore à l'indice datu, è tutti l'elementi più grande di quellu à l'indice datu, aduprendu a funzione di estrazione chjave furnita.
    ///
    ///
    /// # Implementazione attuale
    ///
    /// L'algoritmu attuale hè basatu annantu à a parte quickselect di u listessu algoritmu quicksort utilizatu per [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics quandu `index >= len()`, vale à dì sempre panics nantu à fette viote.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Ritorna a mediana cum'è se a matrice fussi urdinata secondu u valore assolutu.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Semu solu garantiti chì a fetta serà unu di i seguenti, basatu nantu à a manera di sorte per l'indice specificatu.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Sposta tutti l'elementi ripetuti consecutivi à a fine di a fetta secondu l'implementazione [`PartialEq`] trait.
    ///
    ///
    /// Restituisce duie fette.U primu ùn cuntene elementi ripetuti consecutivi.
    /// U secondu cuntene tutti i duplicati in nisun ordine specificatu.
    ///
    /// Se a fetta hè urdinata, a prima fetta restituita ùn cuntene micca duplicati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Sposta tuttu eccettu u primu di l'elementi cunsecutivi à a fine di a fetta chì soddisfa una data rilazioni d'ugualità.
    ///
    /// Restituisce duie fette.U primu ùn cuntene elementi ripetuti consecutivi.
    /// U secondu cuntene tutti i duplicati in nisun ordine specificatu.
    ///
    /// A funzione `same_bucket` hè trasmessa referenze à dui elementi da a fetta è deve determinà se l'elementi paragunanu uguali.
    /// L'elementi sò passati in ordine cuntrariu da u so ordine in a fetta, allora se `same_bucket(a, b)` restituisce `true`, `a` hè spostatu à a fine di a fetta.
    ///
    ///
    /// Se a fetta hè urdinata, a prima fetta restituita ùn cuntene micca duplicati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Ancu se avemu un riferimentu mutevule à `self`, ùn pudemu micca fà cambiamenti * arbitrarie.E chjamate `same_bucket` puderebbenu panic, allora duvemu assicurà chì a fetta sia sempre valida.
        //
        // U modu chì trattemu questu hè aduprendu swap;iteremu annantu à tutti l'elementi, scambendu mentre andemu in modu chì à a fine l'elementi chì vulemu mantene sò in fronte, è quelli chì vulemu rifiutà sò in u fondu.
        // Pudemu dopu sparte a fetta.
        // Questa operazione hè sempre `O(n)`.
        //
        // Esempiu: Partemu in questu statu, induve `r` rapprisenta "dopu
        // leghje "è `w` riprisenta" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Comparendu self[r] contr'à sè stessu [w-1], questu ùn hè micca un duplicatu, cusì scambiamu self[r] è self[w] (nisun effettu cum'è r==w) è poi aumentemu sia r che w, lascianoci cun:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Comparendu self[r] contr'à sè stessu [w-1], questu valore hè un duplicatu, allora aumentemu `r` ma lasciemu tuttu u restu immutatu:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Comparendu self[r] contr'à sè stessu [w-1], questu ùn hè micca un duplicatu, cusì scambiate self[r] è self[w] è avanzate r è w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Micca un duplicatu, ripetite:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplicate, advance r. End di fetta.Split à w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SICUREZZA: a cundizione `while` garantisce `next_read` è `next_write`
        // sò menu di `len`, cusì sò in `self`.
        // `prev_ptr_write` punta à un elementu prima di `ptr_write`, ma `next_write` parte da 1, allora `prev_ptr_write` ùn hè mai menu di 0 è si trova in a fetta.
        // Questu risponde à i requisiti per a dereferenzazione `ptr_read`, `prev_ptr_write` è `ptr_write`, è per aduprà `ptr.add(next_read)`, `ptr.add(next_write - 1)` è `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` hè ancu incrementatu à u massimu una volta per ciclu à u più significatu chì nisun elementu hè saltatu quandu pò esse necessariu scambià.
        //
        // `ptr_read` è `prev_ptr_write` ùn puntanu mai à u listessu elementu.Questu hè necessariu per `&mut *ptr_read`, `&mut* prev_ptr_write` per esse sicuru.
        // A spiegazione hè simplicemente chì `next_read >= next_write` hè sempre vera, cusì `next_read > next_write - 1` hè ancu.
        //
        //
        //
        //
        //
        unsafe {
            // Evite cuntrolli di limiti usendu puntatori crudi.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Sposta tuttu eccettu u primu di l'elementi cunsecutivi à a fine di a fetta chì si risolve à a stessa chjave.
    ///
    ///
    /// Restituisce duie fette.U primu ùn cuntene elementi ripetuti consecutivi.
    /// U secondu cuntene tutti i duplicati in nisun ordine specificatu.
    ///
    /// Se a fetta hè urdinata, a prima fetta restituita ùn cuntene micca duplicati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Gira a fetta in locu tale chì i primi elementi `mid` di a fetta si spostinu finu à a fine mentre l'ultimi elementi `self.len() - mid` si movenu in fronte.
    /// Dopu avè chjamatu `rotate_left`, l'elementu precedente à l'indice `mid` diventerà u primu elementu in a fetta.
    ///
    /// # Panics
    ///
    /// Questa funzione serà panic se `mid` hè più grande di a lunghezza di a fetta.Innota chì `mid == self.len()` face _not_ panic è hè una rotazione senza opzione.
    ///
    /// # Complexity
    ///
    /// Piglia lineale (in tempu `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Rotazione di una subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SICUREZZA: A gamma `[p.add(mid) - mid, p.add(mid) + k)` hè trivialmente
        // valevule per a lettura è a scrittura, cum'è richiestu da `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Gira a fetta in locu tale chì i primi elementi `self.len() - k` di a fetta si spostinu finu à a fine mentre l'ultimi elementi `k` si movenu in fronte.
    /// Dopu avè chjamatu `rotate_right`, l'elementu precedente à l'indice `self.len() - k` diventerà u primu elementu in a fetta.
    ///
    /// # Panics
    ///
    /// Questa funzione serà panic se `k` hè più grande di a lunghezza di a fetta.Innota chì `k == self.len()` face _not_ panic è hè una rotazione senza opzione.
    ///
    /// # Complexity
    ///
    /// Piglia lineale (in tempu `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Gira una sottuclice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SICUREZZA: A gamma `[p.add(mid) - mid, p.add(mid) + k)` hè trivialmente
        // valevule per a lettura è a scrittura, cum'è richiestu da `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Cumpiglia `self` cù elementi clonendu `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Riempie `self` cù elementi restituiti chjamendu una chjusura ripetutamente.
    ///
    /// Stu metudu usa una chjusura per creà novi valori.Se preferite [`Clone`] un valore datu, aduprate [`fill`].
    /// Se vulete aduprà [`Default`] trait per generà valori, pudete passà [`Default::default`] cum'è argumentu.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Copia l'elementi da `src` in `self`.
    ///
    /// A lunghezza di `src` deve esse uguale à `self`.
    ///
    /// Se `T` implementa `Copy`, pò esse più performante aduprà [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Sta funzione serà panic se e duie fette anu lunghezze diverse.
    ///
    /// # Examples
    ///
    /// Clonazione di dui elementi da una fetta in un'altra:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Perchè e fette anu da esse di listessa lunghezza, tagliamu a fetta surghjente da quattru elementi à dui.
    /// // Serà panic se ùn femu micca questu.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust impone chì ci pò esse solu una riferenza mutevule senza riferenze immutabili à un pezzu particulare di dati in un scopu particulare.
    /// Per via di questu, pruvate d'utilizà `clone_from_slice` nantu à una sola fetta resultarà in un fallimentu di compilazione:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Per travaglià intornu à questu, pudemu aduprà [`split_at_mut`] per creà duie sottucette distinti da una fetta:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Copia tutti l'elementi da `src` in `self`, aduprendu un memcpy.
    ///
    /// A lunghezza di `src` deve esse uguale à `self`.
    ///
    /// Se `T` ùn implementa micca `Copy`, utilizate [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Sta funzione serà panic se e duie fette anu lunghezze diverse.
    ///
    /// # Examples
    ///
    /// Copia di dui elementi da una fetta in un'altra:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Perchè e fette anu da esse di listessa lunghezza, tagliamu a fetta surghjente da quattru elementi à dui.
    /// // Serà panic se ùn femu micca questu.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust impone chì ci pò esse solu una riferenza mutevule senza riferenze immutabili à un pezzu particulare di dati in un scopu particulare.
    /// Per via di questu, pruvate d'utilizà `copy_from_slice` nantu à una sola fetta resultarà in un fallimentu di compilazione:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Per travaglià intornu à questu, pudemu aduprà [`split_at_mut`] per creà duie sottucette distinti da una fetta:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // U percorsu di u codice panic hè statu messu in una funzione fredda per ùn gonfà u situ di chjamata.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SICUREZZA: `self` hè valevule per elementi `self.len()` per definizione, è `src` era
        // verificatu per avè a stessa lunghezza.
        // E fette ùn ponu micca sovrapposizione perchè e referenze mutevuli sò esclusivi.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Copia elementi da una parte di a fetta à un'altra parte d'ella stessa, aduprendu un memmove.
    ///
    /// `src` hè a gamma in `self` da copià da.
    /// `dest` hè l'indice iniziale di l'intervalu in `self` da cupià, chì avarà a listessa lunghezza cum'è `src`.
    /// E duie gamme ponu sovrapposizione.
    /// L'estremità di e duie gamme devenu esse menu o uguali à `self.len()`.
    ///
    /// # Panics
    ///
    /// Sta funzione serà panic se una di e varieghja supera a fine di a fetta, o se a fine di `src` hè prima di l'iniziu.
    ///
    ///
    /// # Examples
    ///
    /// Copia di quattru byte in una fetta:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SICUREZZA: e cundizioni per `ptr::copy` sò state tutte verificate sopra,
        // cum'è quelli per `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Scambia tutti l'elementi in `self` cù quelli in `other`.
    ///
    /// A lunghezza di `other` deve esse uguale à `self`.
    ///
    /// # Panics
    ///
    /// Sta funzione serà panic se e duie fette anu lunghezze diverse.
    ///
    /// # Example
    ///
    /// Scambià dui elementi in fette:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust impone chì ci pò esse solu un riferimentu mutevule à un pezzu particulare di dati in un scopu particulare.
    ///
    /// Per via di questu, pruvate d'utilizà `swap_with_slice` nantu à una sola fetta resultarà in un fallimentu di compilazione:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Per travaglià intornu à questu, pudemu aduprà [`split_at_mut`] per creà duie sottucette mutevuli distinti da una fetta:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SICUREZZA: `self` hè valevule per elementi `self.len()` per definizione, è `src` era
        // verificatu per avè a stessa lunghezza.
        // E fette ùn ponu micca sovrapposizione perchè e referenze mutevuli sò esclusivi.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funzione per calculà e lunghezze di a fetta media è finita per `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Ciò chì avemu da fà per `rest` hè di capisce chì multiplu di `U` pudemu mette in un numeru più bassu di`T`.
        //
        // E quante `T` avemu bisognu per ognunu di questi "multiple".
        //
        // Cunsiderate per esempiu T=u8 U=u16.Dopu pudemu mette 1 U in 2 Ts.Semplici.
        // Avà, cunsiderate per esempiu un casu induve size_of: :<T>=16, taglia_di::<U>=24.</u>
        // Pudemu mette 2 Us in postu di ogni 3 Ts in a fetta `rest`.
        // Un pocu più cumplicatu.
        //
        // Formula per calculà questu hè:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Allargatu è simplificatu:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Per furtuna postu chì tuttu què hè valutatu custantamente ... e prestazioni quì ùn importanu micca!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // algutitimu iterativu di stein Duvemu ancu fà stu `const fn` (è vultà à l'algoritmu ricorsivu se ne femu) perchè basassi nantu à llvm per custattà tuttu què hè ... bè, mi face scomudu.
            //
            //

            // SICUREZZA: `a` è `b` sò verificati per esse valori diversi da zero.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // caccià tutti i fattori di 2 da b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SICUREZZA: `b` hè verificatu per esse nulu.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Armati cun sta cunniscenza, pudemu truvà quanti `U` pudemu mette!
        let us_len = self.len() / ts * us;
        // E quante `T` saranu in a fetta di fine!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Trasmutate a fetta à una fetta di un altru tippu, assicurendu l'alignamentu di i tippi hè mantenutu.
    ///
    /// Stu metudu divide a fetta in trè fette distinte: prefissu, fetta media currettamente allineata di un novu tippu, è a fetta di suffissu.
    /// U metudu pò fà chì a fetta media sia a lunghezza più grande pussibule per un determinatu tippu è fetta d'entrata, ma solu e prestazioni di u vostru algoritmu devenu dipende da quessa, micca da a so currettezza.
    ///
    /// Hè permissibile per tutti i dati in entrata da esse restituiti cum'è prefissu o fetta di suffissu.
    ///
    /// Stu metudu ùn hà alcun scopu quandu l'elementu d'ingressu `T` o l'elementu di uscita `U` sò di dimensione zero è restituiranu a fetta originale senza sparte nunda.
    ///
    /// # Safety
    ///
    /// Stu metudu hè essenzialmente un `transmute` in quantu à l'elementi in a fetta media rientrata, dunque tutte e solite avvertenze pertinenti à `transmute::<T, U>` valenu ancu quì.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Nota chì a maiò parte di sta funzione serà costantemente valutata,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // manighjà ZST in particulare, chì hè-ùn li manighjà mancu.
            return (self, &[], &[]);
        }

        // Prima, truvate à chì puntu ci dividemu trà a prima è a seconda fetta.
        // Facile cù ptr.align_offset.
        let ptr = self.as_ptr();
        // SICUREZZA: Vede u metudu `align_to_mut` per u cummentariu di sicurezza detallatu.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SICUREZZA: avà `rest` hè definitivamente alliniatu, allora `from_raw_parts` sottu hè bè,
            // postu chì u chjamante garante chì pudemu trasmutà `T` in `U` in modu sicuru.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Trasmutate a fetta à una fetta di un altru tippu, assicurendu l'alignamentu di i tippi hè mantenutu.
    ///
    /// Stu metudu divide a fetta in trè fette distinte: prefissu, fetta media currettamente allineata di un novu tippu, è a fetta di suffissu.
    /// U metudu pò fà chì a fetta media sia a lunghezza più grande pussibule per un determinatu tippu è fetta d'entrata, ma solu e prestazioni di u vostru algoritmu devenu dipende da quessa, micca da a so currettezza.
    ///
    /// Hè permissibile per tutti i dati in entrata da esse restituiti cum'è prefissu o fetta di suffissu.
    ///
    /// Stu metudu ùn hà alcun scopu quandu l'elementu d'ingressu `T` o l'elementu di uscita `U` sò di dimensione zero è restituiranu a fetta originale senza sparte nunda.
    ///
    /// # Safety
    ///
    /// Stu metudu hè essenzialmente un `transmute` in quantu à l'elementi in a fetta media rientrata, dunque tutte e solite avvertenze pertinenti à `transmute::<T, U>` valenu ancu quì.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Nota chì a maiò parte di sta funzione serà costantemente valutata,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // manighjà ZST in particulare, chì hè-ùn li manighjà mancu.
            return (self, &mut [], &mut []);
        }

        // Prima, truvate à chì puntu ci dividemu trà a prima è a seconda fetta.
        // Facile cù ptr.align_offset.
        let ptr = self.as_ptr();
        // SICUREZZA: Quì ci assicuremu chì useremu puntatori allineati per U per u
        // restu di u metudu.Questu hè fattu passendu un puntatore à&[T] cun un allineamentu destinatu à U.
        // `crate::ptr::align_offset` hè chjamatu cù un puntatore currettamente alliniatu è validu `ptr` (vene da una riferenza à `self`) è cù una dimensione chì hè una putenza di dui (postu chì vene da l'alineamentu per U), soddisfacendu i so limiti di sicurezza.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Ùn pudemu micca aduprà `rest` torna dopu questu, chì invalidaria u so alias `mut_ptr`!SICUREZZA: vede i cumenti per `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Verifica se l'elementi di sta fetta sò urdinati.
    ///
    /// Questu hè, per ogni elementu `a` è u so elementu seguente `b`, `a <= b` deve tene.Se a fetta cede esattamente zeru o un elementu, `true` hè restituitu.
    ///
    /// Innota chì sì `Self::Item` hè solu `PartialOrd`, ma micca `Ord`, a definizione sopra implica chì sta funzione restituisce `false` se dui elementi consecutivi ùn sò micca paragunabili.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Verifica se l'elementi di sta fetta sò urdinati cù a funzione di comparatore data.
    ///
    /// Invece di aduprà `PartialOrd::partial_cmp`, sta funzione usa a funzione `compare` data per determinà l'ordine di dui elementi.
    /// In più di questu, hè equivalente à [`is_sorted`];vede a so ducumentazione per più infurmazione.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Verifica se l'elementi di sta fetta sò urdinati cù a funzione di estrazione di chjave data.
    ///
    /// Invece di paragunà l'elementi di a fetta direttamente, sta funzione compara e chjave di l'elementi, cumu determinatu da `f`.
    /// In più di questu, hè equivalente à [`is_sorted`];vede a so ducumentazione per più infurmazione.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Restituisce l'indice di u puntu di partizione secondu u predicatu datu (l'indice di u primu elementu di a seconda partizione).
    ///
    /// A fetta hè assunta partizionata secondu u predicatu datu.
    /// Ciò significa chì tutti l'elementi per i quali u predicatu ritorna veru sò à l'iniziu di a fetta è tutti l'elementi per i quali u predicatu ritorna falsu sò à a fine.
    ///
    /// Per esempiu, [7, 15, 3, 5, 4, 12, 6] hè un spartitu sottu u predicatu x% 2!=0 (tutti i numeri dispari sò à u principiu, tutti ancu à a fine).
    ///
    /// Se sta fetta ùn hè micca spartuta, u risultatu restituitu ùn hè micca specificatu è senza significatu, postu chì stu metudu face una spezia di ricerca binaria.
    ///
    /// Vede ancu [`binary_search`], [`binary_search_by`] è [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SICUREZZA: Quandu `left < right`, `left <= mid < right`.
            // Dunque `left` aumenta sempre è `right` diminuisce sempre, è unu o l'altru hè sceltu.In i dui casi `left <= right` hè cuntentu.Dunque se `left < right` in un passu, `left <= right` hè cuntentu in u prossimu passu.
            //
            // Dunque, finu à chì `left != right`, `0 <= left < right <= len` sia soddisfattu è sì stu casu `0 <= mid < len` sia cuntentu ancu.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Avemu bisognu di esplicitamente taglià li à a stessa lunghezza
        // per fà più faciule per l'ottimisatore di eliminà u cuntrollu di i limiti.
        // Ma postu chì ùn pò micca esse invucatu avemu ancu una specializazione esplicita per T: Copia.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Crea una fetta viota.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Crea una fetta viota mutevule.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// I mudelli in fette, attualmente, aduprati solu da `strip_prefix` è `strip_suffix`.
/// À un puntu future, speremu di generalizà `core::str::Pattern` (chì à u mumentu di a scrittura hè limitatu à `str`) à fette, è dopu questu trait serà rimpiazzatu o abolitu.
///
pub trait SlicePattern {
    /// U tippu d'elementu di a fetta accumpagnata.
    type Item;

    /// Attualmente, i consumatori di `SlicePattern` necessitanu una fetta.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}