// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Gira a gamma `[mid-left, mid+right)` tale chì l'elementu in `mid` diventa u primu elementu.Equivalentemente, gira l'elementi `left` di gamma à manca o elementi `right` à destra.
///
/// # Safety
///
/// A gamma specificata deve esse valida per a lettura è a scrittura.
///
/// # Algorithm
///
/// L'algoritmu 1 hè adupratu per i picculi valori di `left + right` o per i grandi `T`.
/// L'elementi sò sposti in e so pusizioni finali unu à volta partendu da `mid - left` è avanzendu da passi `right` modulu `left + right`, tale chì solu un tempurale hè necessariu.
/// Finalmente, tornemu à `mid - left`.
/// Tuttavia, se `gcd(left + right, right)` ùn hè micca 1, i passi sopra saltati nantu à l'elementi.
/// Per esempiu:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Fortunatamente, u numeru d'elementi saltati trà l'elementi finalizati hè sempre uguale, cusì pudemu solu compensà a nostra pusizione di partenza è fà di più giri (u numeru tutale di giri hè u `gcd(left + right, right)` value).
///
/// U risultatu finale hè chì tutti l'elementi sò finalizati una volta è una sola volta.
///
/// L'algoritmu 2 hè adupratu se `left + right` hè grande ma `min(left, right)` hè abbastanza chjucu da adattassi à un buffer di pila.
/// L'elementi `min(left, right)` sò cupiati nantu à u buffer, `memmove` hè applicatu à l'altri, è quelli chì sò nantu à u buffer sò sposti in u foru di u latu oppostu di induve sò originati.
///
/// Algoritmi chì ponu esse vectorizati superanu quellu sopra una volta chì `left + right` diventa abbastanza grande.
/// L'algoritmu 1 pò esse vetturizatu da chjappà è eseguendu parechji giri in una volta, ma ci sò troppu pochi giri in media finu à chì `left + right` hè enormu, è u peghju casu di una sola gira hè sempre quì.
/// Invece, l'algoritmu 3 utilizza scambii ripetuti di elementi `min(left, right)` finu à chì un prublema di rotazione più chjucu sia abbandunatu.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// quandu `left < right` u scambiu accade invece da a manca.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. l'algoritmi quì sottu ponu fiascà se sti casi ùn sò micca verificati
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritmu 1 Microbenchmarks indicanu chì a prestazione media per i turni aleatorii hè megliu finu à circa `left + right == 32`, ma a peghju prestazione di casu si rompe ancu intornu à 16.
            // 24 hè statu sceltu per mezu.
            // Se a dimensione di `T` hè più grande di 4 `usize`s, questu algoritmu supera ancu l'altri algoritmi.
            //
            //
            let x = unsafe { mid.sub(left) };
            // principiu di u primu giru
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` si pò truvà nanzu à manu calculendu `gcd(left + right, right)`, ma hè più veloce di fà una cicculata chì calcula u gcd cum'è effettu collaterale, dopu fendu u restu di u pezzu
            //
            //
            let mut gcd = right;
            // i benchmarks rivelanu chì hè più veloce di scambià temporarii finu à u mumentu invece di leghje una tempuraria una volta, copià in daretu, è dopu scrive quellu tempurariu à a fine.
            // Questu hè forse duvutu à u fattu chì scambià o rimpiazzà i pruvisorii usa solu un indirizzu di memoria in u ciclu invece di avè bisognu di gestisce dui.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // invece di incrementà `i` è dopu verificà s'ellu hè fora di i limiti, verificemu se `i` andrà fora di i limiti à u prossimu incrementu.
                // Quista impedisce qualsiasi imballu di puntatori o `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // fine di u primu giru
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // stu cundiziunale deve esse quì sì `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // finisce u pezzu cù più giri
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ùn hè micca un tipu di dimensione zero, allora hè bè di dividelu per a so dimensione.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritmu 2 U `[T; 0]` hè quì per assicurà chì questu sia adeguatamente alliniatu per T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritmu 3 Ci hè un modu alternativu di scambià chì implica truvà induve l'ultimu swap di questu algoritmu seria, è scambià aduprendu quellu ultimu pezzu invece di scambià pezzi adiacenti cum'è questu algoritmu, ma questu modu hè sempre più veloce.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritmu 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}