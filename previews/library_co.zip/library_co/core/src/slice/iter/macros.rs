//! Macro aduprate da iteratori di slice.

// Inlining is_empty è len face una sfarenza di prestazione tamanta
macro_rules! is_empty {
    // A manera di codificà a lunghezza di un iteratore ZST, funziona sia per ZST sia per non ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Per sbarrazzassi di qualchi cuntrolli di limiti (vede `position`), calculemu a lunghezza in un modu pocu inaspettatu.
// (Pruvatu da `codegen/slice-position-limits-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // simu qualchì volta aduprati in un bloccu periculosu

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Questu _cannot_ utilizza `unchecked_sub` perchè dipendemu di l'imballu per rapprisintà a lunghezza di lunghi iteratori di fette ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Sapemu chì `start <= end`, cusì pò fà megliu cà `offset_from`, chì deve trattà in firmatu.
            // Mettendu bandiere adatte quì pudemu dì à LLVM questu, chì l'aiuta à eliminà i cuntrolli di limiti.
            // SICUREZZA: Da u tipu invariante, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Dicendu dinò à LLVM chì i puntatori sò separati da un multiplu esattu di a dimensione di u tippu, pò ottimizà `len() == 0` finu à `start == end` invece di `(end - start) < size`.
            //
            // SICUREZZA: Da u tippu invariante, i puntatori sò allineati cusì u
            //         a distanza trà elli deve esse un multiplu di dimensione di punta
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// A definizione cumuna di l'iteratori `Iter` è `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Restituisce u primu elementu è move l'iniziu di l'iteratore in avanti di 1.
        // Migliora assai e prestazioni paragunatu à una funzione inline.
        // L'iteratore ùn deve micca esse viotu.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Restituisce l'ultimu elementu è move a fine di l'iteratore indietro di 1.
        // Migliora assai e prestazioni paragunatu à una funzione inline.
        // L'iteratore ùn deve micca esse viotu.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Riduce l'iteratore quandu T hè un ZST, muovendu a fine di l'iteratore indietro da `n`.
        // `n` ùn deve micca supere `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Funzione d'aiutu per creà una fetta da l'iteratore.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SICUREZZA: l'iteratore hè statu creatu da una fetta cù puntatore
                // `self.ptr` è lunghezza `len!(self)`.
                // Questu garantisce chì tutti i prerequisiti per `from_raw_parts` sò soddisfatti.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Funzione d'aiutu per spostà l'iniziu di l'iteratore in avanti da elementi `offset`, restituendu u vechju iniziu.
            //
            // Unsafe perchè l'offset ùn deve esse più di `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SICUREZZA: u chjamante garante chì `offset` ùn supere micca `self.len()`,
                    // dunque stu novu puntatore hè in `self` è cusì garantitu chì ùn serà micca nullu.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Funzione d'aiutu per spostà a fine di l'iteratore indietro da elementi `offset`, restituendu a nova fine.
            //
            // Unsafe perchè l'offset ùn deve esse più di `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SICUREZZA: u chjamante garante chì `offset` ùn supere micca `self.len()`,
                    // chì hè garantitu per ùn sferisce un `isize`.
                    // Inoltre, u puntatore resultante hè in limiti di `slice`, chì risponde à l'altri requisiti per `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // puderia esse implementatu cù fette, ma questu evita cuntrolli di limiti

                // SICUREZZA: E chjame `assume` sò sicure dapoi u puntatore d'iniziu di una fetta
                // deve esse micca nullu, è e fette nantu à non-ZSTs devenu ancu avè un puntatore finale micca nullu.
                // A chjama à `next_unchecked!` hè sicura postu chì verificemu se l'iteratore hè viotu prima.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Questu iteratore hè oramai viotu.
                    if mem::size_of::<T>() == 0 {
                        // Avemu da fà cusì cusì chì `ptr` pò mai esse 0, ma `end` puderia esse (per via di l'imballu).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SICUREZZA: a fine ùn pò esse 0 se T ùn hè micca ZST perchè ptr ùn hè 0 è fine>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SICUREZZA: Simu in limiti.`post_inc_start` face a cosa bona ancu per i ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Avemu annullatu l'implementazione predefinita, chì usa `try_fold`, perchè sta implementazione simplice genera menu LLVM IR è hè più veloce da compilà.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Avemu annullatu l'implementazione predefinita, chì usa `try_fold`, perchè sta implementazione simplice genera menu LLVM IR è hè più veloce da compilà.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Avemu annullatu l'implementazione predefinita, chì usa `try_fold`, perchè sta implementazione simplice genera menu LLVM IR è hè più veloce da compilà.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Avemu annullatu l'implementazione predefinita, chì usa `try_fold`, perchè sta implementazione simplice genera menu LLVM IR è hè più veloce da compilà.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Avemu annullatu l'implementazione predefinita, chì usa `try_fold`, perchè sta implementazione simplice genera menu LLVM IR è hè più veloce da compilà.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Avemu annullatu l'implementazione predefinita, chì usa `try_fold`, perchè sta implementazione simplice genera menu LLVM IR è hè più veloce da compilà.
            // Inoltre, u `assume` evita un cuntrollu di i limiti.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SICUREZZA: ci hè garantitu per esse in limiti da u loop invariante:
                        // quandu `i >= n`, `self.next()` restituisce `None` è u ciclu si rompe.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Avemu annullatu l'implementazione predefinita, chì usa `try_fold`, perchè sta implementazione simplice genera menu LLVM IR è hè più veloce da compilà.
            // Inoltre, u `assume` evita un cuntrollu di i limiti.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SICUREZZA: `i` deve esse più bassu di `n` postu chì cumencia à `n`
                        // è hè solu diminuente.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SICUREZZA: u chjamante deve garantisce chì `i` sia in i limiti di
                // a fetta sottostante, dunque `i` ùn pò micca trabuccà un `isize`, è e referenze restituite sò garantite per riferisce à un elementu di a fetta è cusì garantita per esse valida.
                //
                // Innota ancu chì u chjamante garantisce ancu chì ùn saremu mai chjamati cù u listessu indice di novu, è chì ùn sò chjamati altri metudi chì accede à stu sottuclice, dunque hè valevule per chì a riferenza restituita sia mutabile in u casu di
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // puderia esse implementatu cù fette, ma questu evita cuntrolli di limiti

                // SICUREZZA: E chjame `assume` sò sicure postu chì u puntatore d'iniziu di una fetta ùn deve esse nullu,
                // è e fette nantu à non-ZSTs devenu ancu avè un puntatore finale micca nullu.
                // A chjama à `next_back_unchecked!` hè sicura postu chì verificemu se l'iteratore hè viotu prima.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Questu iteratore hè oramai viotu.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SICUREZZA: Simu in limiti.`pre_dec_end` face a cosa bona ancu per i ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}