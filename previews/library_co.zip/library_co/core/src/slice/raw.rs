//! Funzioni gratuiti per creà `&[T]` è `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Forma una fetta da un puntatore è una lunghezza.
///
/// L'argumentu `len` hè u numeru di **elementi**, micca u numeru di byte.
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * `data` deve esse [valid] per leghje per `len * mem::size_of::<T>()` assai byte, è deve esse currettamente alliniatu.Questu significa in particulare:
///
///     * L'intera gamma di memoria di sta fetta deve esse cuntenuta in un unicu oggettu attribuitu!
///       E fette ùn ponu mai attraversà più oggetti attribuiti.Vede [below](#incorrect-usage) per un esempiu incorrectamente chì ùn tene micca questu in contu.
///     * `data` deve esse micca nullu è allinatu ancu per fette di lunghezza zero.
///     Una di e ragioni per questu hè chì l'ottimisazioni di layout enum ponu basà nantu à riferimenti (cumprese fette di ogni lunghezza) chì sò allineati è micca nulli per distingue li da altri dati.
///     Pudete uttene un puntatore chì pò esse adupratu cum'è `data` per fette di lunghezza zero cù [`NonNull::dangling()`].
///
/// * `data` deve indicà à `len` consecutivi valori inizializati currettamente di tippu `T`.
///
/// * A memoria riferita da a fetta restituita ùn deve esse mutata per a durata di a vita `'a`, eccettu in un `UnsafeCell`.
///
/// * A dimensione totale `len * mem::size_of::<T>()` di a fetta ùn deve esse più grande di `isize::MAX`.
///   Vede a documentazione di sicurezza di [`pointer::offset`].
///
/// # Caveat
///
/// A vita per a fetta restituita hè inferita da u so usu.
/// Per prevene un abusu accidentale, hè suggeritu di ligà a vita à quella vita di a fonte chì hè sicura in u cuntestu, cume furnendu una funzione d'aiutu pigliendu a vita di un valore host per a fetta, o per annotazione esplicita.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestà una fetta per un elementu unicu
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Usu incorrettu
///
/// A seguente funzione `join_slices` hè **scarsa** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // L'affirmazione sopra assicura chì `fst` è `snd` sò cunfinanti, ma puderianu ancu esse cuntenuti in _different allocated objects_, in quale casu a creazione di sta fetta hè un cumpurtamentu indefinitu.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` è `b` sò sfarenti ughjetti assignati ...
///     let a = 42;
///     let b = 27;
///     // ... chì pò quantunque esse disposti contiguamente in memoria: |a |b œ œ
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Esegue a stessa funzionalità cum'è [`from_raw_parts`], eccettu chì una fetta mutabile hè restituita.
///
/// # Safety
///
/// U cumpurtamentu ùn hè micca definitu se una di e cundizioni seguenti hè violata:
///
/// * `data` deve esse [valid] per leghje è scrive per `len * mem::size_of::<T>()` assai byte, è deve esse currettamente alliniatu.Questu significa in particulare:
///
///     * L'intera gamma di memoria di sta fetta deve esse cuntenuta in un unicu oggettu attribuitu!
///       E fette ùn ponu mai attraversà più oggetti attribuiti.
///     * `data` deve esse micca nullu è allinatu ancu per fette di lunghezza zero.
///     Una di e ragioni per questu hè chì l'ottimisazioni di layout enum ponu basà nantu à riferimenti (cumprese fette di ogni lunghezza) chì sò allineati è micca nulli per distingue li da altri dati.
///
///     Pudete uttene un puntatore chì pò esse adupratu cum'è `data` per fette di lunghezza zero cù [`NonNull::dangling()`].
///
/// * `data` deve indicà à `len` consecutivi valori inizializati currettamente di tippu `T`.
///
/// * A memoria riferita da a fetta restituita ùn deve esse accessu per mezu di alcun altru puntatore (micca derivatu da u valore di ritornu) per a durata di a vita `'a`.
///   Tramindui l'accessi di lettura è scrittura sò pruibiti.
///
/// * A dimensione totale `len * mem::size_of::<T>()` di a fetta ùn deve esse più grande di `isize::MAX`.
///   Vede a documentazione di sicurezza di [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SICUREZZA: u chjamante deve rispettà u cuntrattu di sicurezza per `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Converte una riferenza à T in una fetta di lunghezza 1 (senza cupià).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Converte una riferenza à T in una fetta di lunghezza 1 (senza cupià).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}