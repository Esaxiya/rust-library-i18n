//! Operazioni nantu à ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Verifica se tutti i bytes in sta fetta si trovanu in a gamma ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Verifica chì duie fette sò un match ASCII insensibile à u casu.
    ///
    /// Listessu chè `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ma senza allucazione è copia di pruvisorii.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Converte sta fetta in u so equivalente ASCII maiuscule in locu.
    ///
    /// E lettere ASCII 'a' à 'z' sò mappate à 'A' à 'Z', ma e lettere non ASCII sò invariate.
    ///
    /// Per restituisce un novu valore maiusculatu senza mudificà quellu esistente, aduprate [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Converte sta fetta in u so equivalente ASCII minuscule in locu.
    ///
    /// E lettere ASCII 'A' à 'Z' sò mappate à 'a' à 'z', ma e lettere non ASCII sò invariate.
    ///
    /// Per restituisce un novu valore minuscule senza mudificà quellu esistente, aduprate [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Restituisce `true` se qualchì byte in a parolla `v` hè nonascii (>=128).
/// Snarfed da `../str/mod.rs`, chì face qualcosa di simile per a validazione utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Test ASCII ottimizatu chì utilizerà operazioni usize-at-a-time invece di operazioni byte-at-a-time (quandu hè pussibule).
///
/// L'algoritmu chì usamu quì hè abbastanza semplice.Se `s` hè troppu cortu, basta à verificà ogni byte è esse fattu cun ellu.Osinnò:
///
/// - Leghjite a prima parolla cù una carica micca allineata.
/// - Alignate u puntatore, leghjite e parolle successive finu à a fine cù carichi allineati.
/// - Leghjite l'ultimu `usize` da `s` cù una carica senza allineamentu.
///
/// Se qualchissia di sti carichi produce qualcosa per chì `contains_nonascii` (above) ritorna veru, allora sapemu chì a risposta hè falsa.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Se ùn avissimu guadagnatu nunda da l'implementazione parolla à tempu, ricademu à un ciclu scalare.
    //
    // Facemu dinò questu per l'architetture induve `size_of::<usize>()` ùn hè micca abbastanza allineamentu per `usize`, perchè hè un casu stranu edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Avemu sempre lettu a prima parola senza allineamentu, chì significa chì `align_offset` hè
    // 0, averiamu lettu dinò u listessu valore per a lettura allineata.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SICUREZZA: Verificemu `len < USIZE_SIZE` sopra.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Avemu verificatu questu quì sopra, un pocu implicitamente.
    // Innota chì `offset_to_aligned` hè o `align_offset` o `USIZE_SIZE`, tramindui sò esplicitamente verificati sopra.
    //
    debug_assert!(offset_to_aligned <= len);

    // SICUREZZA: word_ptr hè u (adattatu currettamente) ustr ptr chì usemu per leghje u
    // pezzu mezzu di a fetta.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` hè l'indice di byte di `word_ptr`, adupratu per i controlli di fine ciclu.
    let mut byte_pos = offset_to_aligned;

    // Paranoia verificate nantu à l'allinjamentu, postu chì avemu da fà una mansa di carichi micca allineati.
    // In pratica questu duveria esse impussibule solu un bug in `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Leghjite e parolle successive finu à l'ultima parola allineata, escludendu l'ultima parola allineata da sola da fà in coda verificate dopu, per assicurà chì a coda sia sempre una `usize` à u massimu à branch `byte_pos == len` in più.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Verità di sanità chì a lettura sia in limiti
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // È chì e nostre assunzioni nantu à `byte_pos` valenu.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SICUREZZA: Sapemu chì `word_ptr` hè allinatu currettamente (per via di
        // "align_offset"), è sapemu chì avemu abbastanza byte trà `word_ptr` è a fine
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SICUREZZA: Sapemu chì `byte_pos <= len - USIZE_SIZE`, chì significa chì
        // dopu stu `add`, `word_ptr` serà à u più un passatu.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Verificazione di sanità per assicurà chì ci sia veramente solu un `usize`.
    // Questu deve esse garantitu da a nostra cundizione di ciclu.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SICUREZZA: Questu dipende da `len >= USIZE_SIZE`, chì verificemu à l'iniziu.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}