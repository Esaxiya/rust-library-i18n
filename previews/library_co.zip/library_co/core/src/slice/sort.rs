//! Sorting di fette
//!
//! Stu modulu cuntene un algoritmu di scelta basatu annantu à u quicksort di Orson Peters chì scunfighja u mudellu, publicatu à: <https://github.com/orlp/pdqsort>
//!
//!
//! A classificazione instabile hè cumpatibile cù libcore perchè ùn assigna micca memoria, à u cuntrariu di a nostra implementazione di classificazione stabile.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Quandu hè cascatu, copie da `src` in `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SICUREZZA: Questa hè una classa d'aiutu.
        //          Per piacè riferitevi à u so usu per a correttezza.
        //          Vale à dì, unu deve esse sicuru chì `src` è `dst` ùn si sovrapponenu micca cum'è richiestu da `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Sposta u primu elementu à a diritta finu à chì scontra un elementu più grande o uguale.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SICUREZZA: L'operazioni periculose sottu implicanu l'indexazione senza un cuntrollu ligatu (`get_unchecked` è `get_unchecked_mut`)
    // è copia di memoria (`ptr::copy_nonoverlapping`).
    //
    // a.Indexazione:
    //  1. Avemu verificatu a dimensione di l'array à>=2.
    //  2. Tutta l'indexazione chì faremu hè sempre trà {0 <= index < len} à u più.
    //
    // b.Copia di memoria
    //  1. Avemu ottene indicazioni per riferimenti chì sò garantiti per esse validi.
    //  2. Ùn si ponu micca sovrappone perchè uttenemu puntelli per indici di differenza di a fetta.
    //     Vale à dì, `i` è `i-1`.
    //  3. Se a fetta hè allineata currettamente, l'elementi sò allineati currettamente.
    //     Hè a responsabilità di u chjamante di assicurassi chì a fetta sia allineata currettamente.
    //
    // Vede i cumenti sottu per più dettu.
    unsafe {
        // Sì i primi dui elementi sò fora di ordine ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Leghjite u primu elementu in una variabile attribuita da stack.
            // Se una seguente operazione di paragone panics, `hole` serà abbandunatu è scrive automaticamente l'elementu in a fetta.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Spustà `i`-th elementu un locu à manca, trasfurmendu cusì u foru à diritta.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` hè cascatu è cusì copia `tmp` in u foru restante in `v`.
        }
    }
}

/// Sposta l'ultimu elementu à manca finu à chì scontra un elementu più chjucu o uguale.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SICUREZZA: L'operazioni periculose sottu implicanu l'indexazione senza un cuntrollu ligatu (`get_unchecked` è `get_unchecked_mut`)
    // è copia di memoria (`ptr::copy_nonoverlapping`).
    //
    // a.Indexazione:
    //  1. Avemu verificatu a dimensione di l'array à>=2.
    //  2. Tutta l'indexazione chì faremu hè sempre trà `0 <= index < len-1` à u più.
    //
    // b.Copia di memoria
    //  1. Avemu ottene indicazioni per riferimenti chì sò garantiti per esse validi.
    //  2. Ùn si ponu micca sovrappone perchè uttenemu puntelli per indici di differenza di a fetta.
    //     Vale à dì, `i` è `i+1`.
    //  3. Se a fetta hè allineata currettamente, l'elementi sò allineati currettamente.
    //     Hè a responsabilità di u chjamante di assicurassi chì a fetta sia allineata currettamente.
    //
    // Vede i cumenti sottu per più dettu.
    unsafe {
        // Sì l'ultimi dui elementi sò fora di ordine ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Leghjite l'ultimu elementu in una variabile attribuita da stack.
            // Se una seguente operazione di paragone panics, `hole` serà abbandunatu è scrive automaticamente l'elementu in a fetta.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Spustà `i`-th elementu un locu à diritta, trasfurmendu cusì u foru à manca.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` hè cascatu è cusì copia `tmp` in u foru restante in `v`.
        }
    }
}

/// Parzialmente sorte una fetta spustendu parechji elementi fora di ordine intornu.
///
/// Ritorna `true` se a fetta hè urdinata à a fine.Sta funzione hè *O*(*n*) u peghju casu.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Numaru massimu di coppie adiacenti fora di ordine chì seranu spostate.
    const MAX_STEPS: usize = 5;
    // Se a fetta hè più corta di questu, ùn cambiate micca elementi.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SICUREZZA: Avemu dighjà esplicitu u cuntrollatu ligatu cù `i < len`.
        // Tutti i nostri indizii successivi sò solu in a gamma `0 <= index < len`
        unsafe {
            // Truvate a prossima coppia di elementi adiacenti fora di ordine.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Avemu finitu?
        if i == len {
            return true;
        }

        // Ùn spustate micca elementi nantu à matrici brevi, chì hà un costu di prestazione.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Scambià u paru d'elementi truvatu.Questu li mette in ordine currettu.
        v.swap(i - 1, i);

        // Sposta l'elementu più chjucu à manca.
        shift_tail(&mut v[..i], is_less);
        // Sposta l'elementu più grande à a diritta.
        shift_head(&mut v[i..], is_less);
    }

    // Ùn hè micca riesciutu à sorte a fetta in u numeru limitatu di passi.
    false
}

/// Ordina una fetta cù una sorta d'inserzione, chì hè *O*(*n*^ 2) u peghju casu.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sorts `v` cù heapsort, chì guarantisci *O*(*n*\*log(* n*)) u peghju casu.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Stu munimentu binariu rispetta l'invariante `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Figlioli di `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Sceglite u zitellu più grande.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Stop si l'invariante si tene à `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Scambià `node` cù u figliolu maiò, muvite un passu in ghjò, è continuate a vagliatura.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Custruisce a mansa in tempu lineare.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop elementi massimi da a mansa.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partizioni `v` in elementi più chjucu cà `pivot`, seguitatu da elementi maiori o uguali à `pivot`.
///
///
/// Restituisce u numeru d'elementi più chjucu cà `pivot`.
///
/// U partizionamentu hè effettuatu bloccu per bloccu per minimizà u costu di l'operazioni di ramificazione.
/// Questa idea hè presentata in a carta [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Numaru d'elementi in un bloccu tipicu.
    const BLOCK: usize = 128;

    // L'algoritmu di spartimentu ripete i seguenti passi finu à a fine:
    //
    // 1. Traccia un bloccu da u latu sinistro per identificà elementi più grandi o uguali à u pivot.
    // 2. Traccia un bloccu da u latu drittu per identificà elementi più chjucu di u pivot.
    // 3. Scambià l'elementi identificati trà u latu sinistro è u dirittu.
    //
    // Mantenemu e seguenti variabili per un bloccu di elementi:
    //
    // 1. `block` - Numaru d'elementi in u bloccu.
    // 2. `start` - Accumincia u puntatore in a matrice `offsets`.
    // 3. `end` - Puntatore finale in a matrice `offsets`.
    // 4. `offsets, Indici di elementi fora di ordine in u bloccu.

    // U bloccu attuale à manca (da `l` à `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // U bloccu attuale à u latu drittu (da `r.sub(block_r)` to `r`).
    // SICUREZZA: A ducumentazione per .add() specificamente menziona chì `vec.as_ptr().add(vec.len())` hè sempre sicuru '
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Quandu avemu VLAs, pruvate à creà una serie di lunghezza `min(v.len(), 2 * BLOCK) `piuttostu
    // cà duie matrici fissi di lunghezza `BLOCK`.I VLA ponu esse più efficaci in cache.

    // Restituisce u numeru di elementi trà i puntatori `l` (inclusive) è `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Avemu finitu cù u partizionamentu bloccu per bloccu quandu `l` è `r` si avvicinanu assai.
        // Dopu femu un travagliu di patch-up per spartisce l'elementi restanti in mezu.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Numaru d'elementi restanti (sempre micca paragunatu à u pivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Aghjustate e dimensioni di u bloccu in modu chì u bloccu di manca è di diritta ùn si sovrapponganu, ma uttene perfettamente alliniatu per copre tuttu u spaziu restante.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Traccia elementi `block_l` da u latu sinistro.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SICUREZZA: L'operazioni di securità quì sottu implicanu l'usu di u `offset`.
                //         Sicondu e cundizioni richieste da a funzione, li suddisfemu perchè:
                //         1. `offsets_l` hè attribuitu in pila, è cusì cunsideratu oggettu assignatu separatu.
                //         2. A funzione `is_less` restituisce un `bool`.
                //            Lanciari un `bool` ùn sferrà mai `isize`.
                //         3. Avemu garantitu chì `block_l` serà `<= BLOCK`.
                //            In più, `end_l` hè statu inizialmente impostatu per u puntatore iniziale di `offsets_` chì hè statu dichjaratu nantu à a pila.
                //            Cusì, sapemu chì ancu in u peghju casu (tutte l'invucazioni di `is_less` rientranu falsi) seremu solu à u più 1 byte passà a fine.
                //        Un'altra operazione periculosa quì hè a deriferenza di `elem`.
                //        Tuttavia, `elem` era inizialmente u puntatore di partenza per a fetta chì hè sempre valida.
                unsafe {
                    // Cunfrontu senza ramificazioni.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Traccia elementi `block_r` da u latu drittu.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SICUREZZA: L'operazioni di securità quì sottu implicanu l'usu di u `offset`.
                //         Sicondu e cundizioni richieste da a funzione, li suddisfemu perchè:
                //         1. `offsets_r` hè attribuitu in pila, è cusì cunsideratu oggettu assignatu separatu.
                //         2. A funzione `is_less` restituisce un `bool`.
                //            Lanciari un `bool` ùn sferrà mai `isize`.
                //         3. Avemu garantitu chì `block_r` serà `<= BLOCK`.
                //            In più, `end_r` hè statu inizialmente impostatu per u puntatore iniziale di `offsets_` chì hè statu dichjaratu nantu à a pila.
                //            Cusì, sapemu chì ancu in u peghju casu (tutte l'invucazioni di `is_less` tornanu veri) seremu solu à u più 1 byte passà a fine.
                //        Un'altra operazione periculosa quì hè a deriferenza di `elem`.
                //        Tuttavia, `elem` era inizialmente `1 *sizeof(T)` passatu a fine è u decrementemu da `1* sizeof(T)` prima di accede.
                //        In più, `block_r` hè statu dichjaratu chì hè menu di `BLOCK` è `elem` dunque al massimu punterà versu u principiu di a fetta.
                unsafe {
                    // Cunfrontu senza ramificazioni.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Numaru d'elementi fora di ordine da scambià trà u latu sinistro è u dirittu.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Invece di scambià una coppia à u mumentu, hè più efficiente per fà una permutazione ciclica.
            // Questu ùn hè micca strettamente equivalente à scambià, ma produce un risultatu simile aduprendu menu operazioni di memoria.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Tutti l'elementi fora di ordine in u bloccu di manca sò stati sposti.Spustà à u prossimu bloccu.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Tutti l'elementi fora di ordine in u blocu di dirittu sò stati sposti.Move à u bloque precedente.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Tuttu ciò chì ferma avà hè à u più un bloccu (sia à manca sia à diritta) cù elementi fora di ordine chì devenu esse spustati.
    // Tali elementi restanti ponu esse semplicemente sposti à a fine in u so bloccu.
    //

    if start_l < end_l {
        // U bloccu di manca ferma.
        // Move i so elementi restanti fora di l'ordine à l'estrema destra.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // U bloccu ghjustu ferma.
        // Spustà i so elementi restanti fora di l'ordine à l'estrema manca.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nunda altru da fà, avemu finitu.
        width(v.as_mut_ptr(), l)
    }
}

/// Partizioni `v` in elementi più chjucu cà `v[pivot]`, seguitatu da elementi maiori o uguali à `v[pivot]`.
///
///
/// Restituisce una tupla di:
///
/// 1. Numaru d'elementi più chjucu cà `v[pivot]`.
/// 2. Hè veru se `v` era dighjà partizionatu.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Pone u pivot à l'iniziu di a fetta.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Leghjite u pivot in una variabile attribuita in pila per efficienza.
        // Se una seguente operazione di paragone panics, u pivot serà scrittu automaticamente in a fetta.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Truvate a prima coppia di elementi fora di ordine.
        let mut l = 0;
        let mut r = v.len();

        // SICUREZZA: L'insegurità sottu implica l'indexazione di una matrice.
        // Per u primu: Facemu digià i limiti verificendu quì cù `l < r`.
        // Per u secondu: Inizialmente avemu `l == 0` è `r == v.len()` è avemu verificatu chì `l < r` à ogni operazione d'indexazione.
        //                     Da quì sapemu chì `r` deve esse almenu `r == l` chì hè statu dimustratu per esse validu da u primu.
        unsafe {
            // Truvate u primu elementu più grande o uguale à u pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Truvate l'ultimu elementu più chjucu chì u pivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` esce da u scopu è scrive u pivot (chì hè una variabile attribuita in pila) torna in a fetta induve era uriginale.
        // Stu passu hè criticu per assicurà a sicurezza!
        //
    };

    // Pone u pivot trà e duie partizioni.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partizioni `v` in elementi uguali à `v[pivot]` seguiti da elementi più grande di `v[pivot]`.
///
/// Restituisce u numeru di elementi uguale à u pivot.
/// Hè assuntu chì `v` ùn cuntene elementi più chjucu cà u pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Pone u pivot à l'iniziu di a fetta.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Leghjite u pivot in una variabile attribuita in pila per efficienza.
    // Se una seguente operazione di paragone panics, u pivot serà scrittu automaticamente in a fetta.
    // SICUREZZA: U puntatore quì hè validu perchè hè ottenutu da un riferimentu à una fetta.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Avà partite a fetta.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SICUREZZA: L'insegurità sottu implica l'indexazione di una matrice.
        // Per u primu: Facemu digià i limiti verificendu quì cù `l < r`.
        // Per u secondu: Inizialmente avemu `l == 0` è `r == v.len()` è avemu verificatu chì `l < r` à ogni operazione d'indexazione.
        //                     Da quì sapemu chì `r` deve esse almenu `r == l` chì hè statu dimustratu per esse validu da u primu.
        unsafe {
            // Truvate u primu elementu più grande chì u pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Truvate l'ultimu elementu uguale à u pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Avemu finitu?
            if l >= r {
                break;
            }

            // Scambià u paru truvatu di elementi fora di ordine.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Avemu trovu elementi `l` uguali à u pivot.Aghjunghje 1 per cuntà u pivot stessu.
    l + 1

    // `_pivot_guard` esce da u scopu è scrive u pivot (chì hè una variabile attribuita in pila) torna in a fetta induve era uriginale.
    // Stu passu hè criticu per assicurà a sicurezza!
}

/// Sparisce alcuni elementi intornu à un tentativu di rompe mudelli chì puderebbenu causà partizioni sbilanciate in quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Generatore di numeri Pseudorandom da a carta "Xorshift RNGs" da George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Pigliate numeri aleatorii modulu stu numeru.
        // U numeru si adatta à `usize` perchè `len` ùn hè micca più grande di `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Alcuni candidati pivoti seranu in a vicinanza di questu indice.Fighjemu aleatoriu.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Generate un numeru casuale modulu `len`.
            // Tuttavia, per evità operazioni costose, pigliamu prima u modulu una putenza di dui, è dopu diminuemu di `len` finu à chì entre in a gamma `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` hè garantitu per esse menu di `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Sceglie un pivot in `v` è restituisce l'indice è `true` se a fetta hè prubabilmente digià ordinata.
///
/// Elementi in `v` ponu esse riordinati in u prucessu.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Lunghezza minima per sceglie u metudu mediana di mediane.
    // E fette più brevi usanu u metudu simplice medianu di trè.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Numaru massimu di swap chì ponu esse effettuati in questa funzione.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Trè indici vicinu à quale avemu da sceglie un pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Conta u numeru tutale di swap chì avemu da fà mentre selezziunate l'indici.
    let mut swaps = 0;

    if len >= 8 {
        // Indici di swaps in modo chì `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Indici di swaps in modo chì `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Truvà a mediana di `v[a - 1], v[a], v[a + 1]` è guarda l'indice in `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Truvate mediane in i quartieri di `a`, `b` è `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Truvate a mediana trà `a`, `b` è `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // U numeru massimu di swap hè statu effettuatu.
        // A probabilità hè chì a fetta sia discendente o soprattuttu discendente, dunque l'inversione probabilmente aiuterà à sorte più veloce.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sorts `v` recursivamente.
///
/// Se a fetta avia un predecessore in l'array originale, hè specificata cum'è `pred`.
///
/// `limit` hè u numeru di partizioni sbilanciate permesse prima di passà à `heapsort`.
/// Sì cero, sta funzione cambierà subitu in heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // E fette finu à sta lunghezza sò ordinate cù una sorta d'inserzione.
    const MAX_INSERTION: usize = 20;

    // Hè vera sì l'ultimu spartimentu era ragiunevolmente equilibratu.
    let mut was_balanced = true;
    // Hè vera sì l'ultimu partizionamentu ùn hà micca mescolatu elementi (a fetta era dighjà partizionata).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // I fette assai brevi sò urdinati cù una sorta d'inserzione.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Sì troppu scelte di pivot male sò state fatte, basta à ritruvà in heapsort per guarantisce `O(n * log(n))` u peghju casu.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Se l'ultimu partizionamentu era squilibratu, pruvate à rompe i mudelli in a fetta mischjendu alcuni elementi intornu.
        // Speremu chì scegliamu un pivot megliu sta volta.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Sceglite un pivot è pruvate à guessà se a fetta hè dighjà ordinata.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Se l'ultimu partizionamentu hè statu decentemente equilibratu è ùn hà micca mescolatu elementi, è se a selezzione pivot predice chì a fetta hè probabilmente dighjà ordinata ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Pruvate à identificà parechji elementi fora di ordine è di trasfurmalli in pusizioni currette.
            // Se a fetta finisce per esse cumpletamente ordinata, avemu finitu.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Se u pivot sceltu hè uguale à u predecessore, allora hè l'elementu più chjucu in a fetta.
        // Spartite a fetta in elementi uguali è elementi più grandi di u pivot.
        // Stu casu hè di solitu culpitu quandu a fetta cuntene parechji elementi duplicati.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Cuntinuà à sorte elementi più grande cà u pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Spartite a fetta.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Dividite a fetta in `left`, `pivot` è `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Recurse in u latu più cortu solu per minimizà u numeru tutale di chjamate ricorsive è cunsumà menu spaziu di stack.
        // Poi basta à cuntinuà cù u latu più longu (questu hè simile à a recursione di a coda).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Ordina `v` aduprendu quicksort di scunfitta di mudelli, chì hè *O*(*n*\*log(* n*)) u peghju casu.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // L'urdinamentu ùn hà micca cumpurtamentu significativu nantu à tippi di dimensioni zero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Limite u numeru di partizioni sbilanciate à `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Per e fette finu à sta lunghezza hè probabilmente più veloce di simplificà li solu.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Sceglite un pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Se u pivot sceltu hè uguale à u predecessore, allora hè l'elementu più chjucu in a fetta.
        // Spartite a fetta in elementi uguali è elementi più grandi di u pivot.
        // Stu casu hè di solitu culpitu quandu a fetta cuntene parechji elementi duplicati.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Se avemu passatu u nostru indice, allora simu boni.
                if mid > index {
                    return;
                }

                // Altrimenti, continuate à classificà elementi più grandi di u pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Dividite a fetta in `left`, `pivot` è `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Se mid==index, allora avemu finitu, postu chì partition() hà garantitu chì tutti l'elementi dopu mid sò più grande o uguali à mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // L'urdinamentu ùn hà micca cumpurtamentu significativu nantu à tippi di dimensioni zero.Ùn fà nunda.
    } else if index == v.len() - 1 {
        // Truvate l'elementu max è piazzate in l'ultima pusizione di a matrice.
        // Simu liberi di aduprà `unwrap()` quì perchè sapemu chì v ùn deve esse viotu.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Truvate l'elementu min è piazzate in a prima pusizione di a matrice.
        // Simu liberi di aduprà `unwrap()` quì perchè sapemu chì v ùn deve esse viotu.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}