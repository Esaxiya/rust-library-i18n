// Implementazione originale presa da rust-memchr.
// Copyright 2015 Andrew Gallant, bluss è Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Aduprate truncazione.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Restituisce `true` se `x` cuntene un byte zeru.
///
/// Da *Matters Computational*, J. Arndt:
///
/// "L'idea hè di sottrae unu da ognunu di i byte è dopu cercà byte induve u prestitu si propagò finu à u più significativu
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Restituisce u primu indice chì currisponde à u byte `x` in `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Percorsu veloce per piccule fette
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Scansà per un valore di byte unicu leggendu duie parole `usize` à a volta.
    //
    // Split `text` in trè parti
    // - parte iniziale senza allineamentu, prima di a prima parola allineata indirizzu in u testu
    // - corpu, scansione da 2 parolle à a volta
    // - l'ultima parte restante, <2 dimensione di parolla

    // cercà finu à un cunfini alliniatu
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // cercate u corpu di u testu
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SEGURITÀ: u predicatu di u tempu garantisce una distanza di almenu 2 * usize_bytes
        // trà l'offset è a fine di a fetta.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // rompe s'ellu ci hè un byte chì currisponde
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Truvate u byte dopu u puntu chì u ciclu di u corpu si hè fermatu.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Restituisce l'ultimu indice chì currisponde à u byte `x` in `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Scansà per un valore di byte unicu leggendu duie parole `usize` à a volta.
    //
    // Split `text` in trè parti:
    // - coda senza allineamentu, dopu l'ultima parola allineata indirizzu in u testu,
    // - corpu, scannatu da 2 parolle à a volta,
    // - i primi bytes restanti, dimensione di parola 2.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Chjamemu questu solu per ottene a lunghezza di u prefissu è di u suffissu.
        // In mezzu avemu sempre processatu dui pezzi à una volta.
        // SICUREZZA: a trasmissione `[u8]` à `[usize]` hè sicura eccettu per e differenze di dimensione chì sò gestite da `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Cercate u corpu di u testu, assicuratevi chì ùn attraversemu micca min_aligned_offset.
    // u offset hè sempre alliniatu, dunque solu testà `>` hè sufficiente è evita un pussibile overflow.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SICUREZZA: u offset parte da len, suffix.len(), basta chì sia più grande di
        // min_aligned_offset (prefix.len()) a distanza restante hè almenu 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Break s'ellu ci hè un byte currispondente.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Truvate u byte prima di u puntu chì u ciclu di u corpu si ferma.
    text[..offset].iter().rposition(|elt| *elt == x)
}