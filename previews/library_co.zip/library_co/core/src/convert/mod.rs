//! Traits per cunversione trà tippi.
//!
//! U traits in questu modulu furnisce un modu per cunvertisce da un tipu à un altru tipu.
//! Ogni trait serve un scopu diversu:
//!
//! - Implementate u [`AsRef`] trait per e cunversioni economiche di riferimentu à riferimentu
//! - Implementate u [`AsMut`] trait per cunversioni economiche mutevuli à mutevuli
//! - Implementate u [`From`] trait per cunsumà cunversione valore-valore
//! - Implementate u [`Into`] trait per cunsumà cunversione valore-valore à tippi fora di u crate attuale
//! - U [`TryFrom`] è [`TryInto`] traits si cumportanu cum'è [`From`] è [`Into`], ma devenu esse messu in opera quandu a cunversione pò fiascà.
//!
//! I traits in questu modulu sò spessu usati cum'è trait bounds per funzioni generiche tali chì à argumenti di più tippi sò supportati.Vede a ducumentazione di ogni trait per esempi.
//!
//! Cum'è un autore di biblioteca, duvete sempre preferisce l'implementazione di [`From<T>`][`From`] o [`TryFrom<T>`][`TryFrom`] piuttostu chì [`Into<U>`][`Into`] o [`TryInto<U>`][`TryInto`], chì [`From`] è [`TryFrom`] furniscenu una flessibilità più grande è offrenu implementazioni [`Into`] o [`TryInto`] equivalenti gratuitamente, grazia à una implementazione di manta in a biblioteca standard.
//! Quandu si mira una versione prima di Rust 1.41, pò esse necessariu implementà [`Into`] o [`TryInto`] direttamente quandu si cunverte in un tipu fora di u crate attuale.
//!
//! # Implementazioni Generiche
//!
//! - [`AsRef`] è [`AsMut`] autoreferenza se u tipu internu hè una riferenza
//! - [`Da`]`<U>per T` implica [`Into`]`</u><T><U>per U`</u>
//! - [`TryFrom`]`<U>per T` implica [`TryInto`]`</u><T><U>per U`</u>
//! - [`From`] è [`Into`] sò riflessivi, chì significa chì tutti i tipi ponu `into` stessi è `from` stessi
//!
//! Vede ogni trait per esempi di usu.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// A funzione identitaria.
///
/// Dui cose sò impurtanti da nutà nantu à sta funzione:
///
/// - Ùn hè micca sempre equivalente à una chjusura cum'è `|x| x`, postu chì a chjusura pò furzà `x` in un altru tipu.
///
/// - Sposta l'input `x` passatu à a funzione.
///
/// Mentre puderia sembra stranu avè una funzione chì ritorna appena l'entrata, ci sò alcuni usi interessanti.
///
///
/// # Examples
///
/// Aduprà `identity` per ùn fà nunda in una sequenza di altre funzioni interessanti:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Fighjemu chì aghjunghje una hè una funzione interessante.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Aduprà `identity` cum'è casu di basa "do nothing" in cundiziunale:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Fate cose più interessanti ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Aduprà `identity` per mantene e varianti `Some` di un iteratore di `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Adupratu per fà una cunversione economica di riferimentu à riferimentu.
///
/// Questu trait hè simile à [`AsMut`] chì hè adupratu per cunvertisce trà referenze mutevuli.
/// Se avete bisognu di fà una cunversione costosa hè megliu implementà [`From`] cù u tippu `&T` o scrive una funzione persunalizata.
///
/// `AsRef` hà a stessa firma cum'è [`Borrow`], ma [`Borrow`] hè diversu in pochi aspetti:
///
/// - A diversità di `AsRef`, [`Borrow`] hà una coperta per qualsiasi `T`, è pò esse adupratu per accettà una riferenza o un valore.
/// - [`Borrow`] richiede ancu chì [`Hash`], [`Eq`] è [`Ord`] per u valore prestitu sò equivalenti à quelli di u valore di pruprietà.
/// Per questa ragione, se vulete imprestà solu un campu unicu di una struttura pudete implementà `AsRef`, ma micca [`Borrow`].
///
/// **Note: Questu trait ùn deve micca fallu **.Se a cunversione pò fiascà, aduprate un metudu dedicatu chì rende un [`Option<T>`] o un [`Result<T, E>`].
///
/// # Implementazioni Generiche
///
/// - `AsRef` autoreferenze se u tipu internu hè una riferenza o una riferenza mutevule (per esempiu: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Usendu trait bounds pudemu accettà argumenti di sfarenti tippi basta ch'elli ponu esse cunvertiti in u tippu specificatu `T`.
///
/// Per esempiu: Creendu una funzione generica chì piglia un `AsRef<str>` sprimemu chì vulemu accettà tutte e referenze chì ponu esse cunvertite in [`&str`] cum'è argumentu.
/// Dapoi [`String`] è [`&str`] implementanu `AsRef<str>` pudemu accettà tramindui cum'è argumentu di input.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Esegue a cunversione.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Adupratu per fà una cunversione di riferimentu mutevule à mutevule.
///
/// Questu trait hè simile à [`AsRef`] ma hè adupratu per cunvertisce trà referenze mutevuli.
/// Se avete bisognu di fà una cunversione costosa hè megliu implementà [`From`] cù u tippu `&mut T` o scrive una funzione persunalizata.
///
/// **Note: Questu trait ùn deve micca fallu **.Se a cunversione pò fiascà, aduprate un metudu dedicatu chì rende un [`Option<T>`] o un [`Result<T, E>`].
///
/// # Implementazioni Generiche
///
/// - `AsMut` autoreferenze se u tipu internu hè una riferenza mutevule (per esempiu: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Aduprendu `AsMut` cum'è trait bound per una funzione generica pudemu accettà tutte e referenze mutevuli chì ponu esse convertite in tippu `&mut T`.
/// Perchè [`Box<T>`] implementa `AsMut<T>` pudemu scrive una funzione `add_one` chì piglia tutti l'argumenti chì ponu esse cunvertiti in `&mut u64`.
/// Perchè [`Box<T>`] implementa `AsMut<T>`, `add_one` accetta ancu argumenti di tipu `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Esegue a cunversione.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Una cunversione valore-valore chì cunsuma u valore di ingressu.L'oppostu di [`From`].
///
/// Si deve evità l'implementazione di [`Into`] è implementà invece [`From`].
/// L'implementazione di [`From`] furnisce automaticamente una cun una implementazione di [`Into`] grazia à l'implementazione di manta in a biblioteca standard.
///
/// Preferite aduprà [`Into`] sopra [`From`] quandu specificate trait bounds nantu à una funzione generica per assicurà chì i tippi chì implementanu solu [`Into`] ponu esse aduprati ancu.
///
/// **Note: Questu trait ùn deve micca fallu **.Se a cunversione pò fiascà, aduprate [`TryInto`].
///
/// # Implementazioni Generiche
///
/// - [`Da ']`<T>per U` implica `Into<U> for T`
/// - [`Into`] hè riflessivu, chì significa chì `Into<T> for T` hè implementatu
///
/// # Implementazione di [`Into`] per cunversione à tippi esterni in vechje versioni di Rust
///
/// Prima di Rust 1.41, se u tipu di destinazione ùn era micca parte di u crate attuale allora ùn puderete micca implementà [`From`] direttamente.
/// Per esempiu, pigliate stu codice:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Questu ùn puderà micca cumpilà in e versioni più vechje di a lingua perchè e regule orfane di Rust sò state un pocu più strette.
/// Per saltà questu, pudete implementà [`Into`] direttamente:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Hè impurtante di capisce chì [`Into`] ùn furnisce micca una implementazione [`From`] (cum'è [`From`] face cù [`Into`]).
/// Dunque, duvete sempre pruvà à implementà [`From`] è poi ricusà à [`Into`] se [`From`] ùn pò micca esse implementatu.
///
/// # Examples
///
/// [`String`] implementa [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Per sprime chì vulemu una funzione generica per piglià tutti l'argumenti chì ponu esse cunvertiti in un tipu specificatu `T`, pudemu aduprà un trait bound di [`Into`]`<T>`.
///
/// Per esempiu: A funzione `is_hello` piglia tutti l'argumenti chì ponu esse cunvertiti in un [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Esegue a cunversione.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Adupratu per fà cunversione valore-valore mentre cunsumate u valore di ingressu.Hè u reciproco di [`Into`].
///
/// Si deve sempre preferisce l'implementazione di `From` sopra [`Into`] perchè l'implementazione di `From` furnisce automaticamente una cun una implementazione di [`Into`] grazia à l'implementazione di manta in a biblioteca standard.
///
///
/// Implementate solu [`Into`] quandu dirigenu una versione precedente à Rust 1.41 è cunvertisce in un tipu fora di u crate attuale.
/// `From` ùn hè statu capace di fà sti tippi di cunversione in e versioni precedenti per via di e regule orfane di Rust.
/// Vede [`Into`] per più infurmazioni.
///
/// Preferite aduprà [`Into`] piuttostu chì aduprà `From` quandu specifiche trait bounds nantu à una funzione generica.
/// In questu modu, i tippi chì implementanu direttamente [`Into`] ponu esse aduprati ancu cum'è argumenti.
///
/// U `From` hè ancu assai utile quandu eseguisce a gestione di l'errore.Quandu si custruisce una funzione chì hè capace di fallu, u tippu di ritornu serà generalmente di a forma `Result<T, E>`.
/// U `From` trait simplifica a gestione di l'errore permettendu à una funzione di restituisce un tippu d'errore unicu chì incapsula più tipi d'errore.Vede a sezione "Examples" è [the book][book] per più dettagli.
///
/// **Note: Questu trait ùn deve micca fallu **.Se a cunversione pò fiascà, aduprate [`TryFrom`].
///
/// # Implementazioni Generiche
///
/// - `From<T> for U` implica [`Into`]`<U>per T`</u>
/// - `From` hè riflessivu, chì significa chì `From<T> for T` hè implementatu
///
/// # Examples
///
/// [`String`] implementa `From<&str>`:
///
/// Una cunversione esplicita da un `&str` à una String hè fatta cusì:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Mentre eseguite a gestione di l'errore hè spessu utile per implementà `From` per u vostru propiu tipu d'errore.
/// Cunvertendu i tipi di errore sottostanti à u nostru tippu d'errore persunalizatu chì incapsula u tippu d'errore sottostante, pudemu restituisce un tippu d'errore unicu senza perde informazioni nantu à a causa sottostante.
/// L'operatore '?' converte automaticamente u tippu di errore sottostante à u nostru tippu d'errore persunalizatu chjamendu `Into<CliError>::into` chì hè furnitu automaticamente quandu implementa `From`.
/// U compilatore deduce allora chì implementazione di `Into` deve esse aduprata.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Esegue a cunversione.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Una prova di cunversione chì cunsuma `self`, chì pò o ùn pò esse cara.
///
/// L'autori di e biblioteche ùn devenu micca generalmente implementà direttamente stu trait, ma devenu preferisce l'implementazione di [`TryFrom`] trait, chì offre una flessibilità più grande è furnisce una implementazione `TryInto` equivalente gratuitamente, grazia à una implementazione di manta in a biblioteca standard.
/// Per più infurmazione nantu à questu, vedi a documentazione per [`Into`].
///
/// # Implementazione di `TryInto`
///
/// Questu soffre e stesse restrizioni è ragiunamentu cum'è l'implementazione di [`Into`], vedi quì per i dettagli.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// U tippu ritorna in casu di errore di cunversione.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Esegue a cunversione.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Cunversione di tippu simplici è sicuri chì ponu fiascà di manera cuntrullata in certe circustanze.Hè u reciproco di [`TryInto`].
///
/// Questu hè utile quandu fate una cunversione di tippu chì pò riesce in maniera banale ma pò ancu avè bisognu di una gestione speciale.
/// Per esempiu, ùn ci hè manera di cunvertisce un [`i64`] in un [`i32`] cù u [`From`] trait, perchè un [`i64`] pò cuntene un valore chì un [`i32`] ùn pò micca representà è cusì a cunversione perde dati.
///
/// Questu pò esse gestitu truncendu u [`i64`] à un [`i32`] (essenzialmente dà u valore di u modulu [`i32::MAX`] di [`i64`]) o semplicemente restituendu [`i32::MAX`], o per qualchì altru metudu.
/// U [`From`] trait hè destinatu à cunversioni perfette, cusì u `TryFrom` trait informa u prugrammatore quandu una cunversione di tippu pò andà male è li lascia decide di trattà lu.
///
/// # Implementazioni Generiche
///
/// - `TryFrom<T> for U` implica [`TryInto`]`<U>per T`</u>
/// - [`try_from`] hè riflessivu, chì significa chì `TryFrom<T> for T` hè implementatu è ùn pò micca fallu-u tipu `Error` assuciatu per chjamà `T::try_from()` per un valore di tipu `T` hè [`Infallible`].
/// Quandu u tippu [`!`] hè stabilizatu [`Infallible`] è [`!`] saranu equivalenti.
///
/// `TryFrom<T>` pò esse implementatu cume:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Cum'è discrittu, [`i32`] implementa `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Truncate in silenziu `big_number`, richiede a rilevazione è a gestione di u truncamentu dopu u fattu.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Restituisce un errore perchè `big_number` hè troppu grande per adattassi à un `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Ritorna `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// U tippu ritorna in casu di errore di cunversione.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Esegue a cunversione.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS GENERICI
////////////////////////////////////////////////////////////////////////////////

// Cumu si solleva&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Cum'è ascensori sopra &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): rimpiazzate i impls sopra per&/&mut cù u seguente più generale:
// // Cum'è ascensori sopra Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Dimensione> AsRef <U>per D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut alza sopra &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): rimpiazzate l'implice sopra per &mut cù u seguente più generale:
// // AsMut alza sopra DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Dimensione> AsMut <U>per D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Da implica in
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Da (è cusì Into) hè riflessivu
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Nota di stabilità:** Questu impl ùn esiste ancu, ma simu "reserving space" per aghjunghje lu in u future.
/// Vede [rust-lang/rust#64715][#64715] per i dettagli.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): fà invece una riparazione di principiu.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom implica TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// E cunversioni infallibili sò semanticamente equivalenti à cunversioni fallibili cun un tipu d'errore disabitatu.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS CONCRETI
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// U TIPU DI ERRORE NO-ERROR
////////////////////////////////////////////////////////////////////////////////

/// U tippu d'errore per errori chì ùn ponu mai accade.
///
/// Postu chì questu enum ùn hà alcuna variante, un valore di stu tippu ùn pò mai esiste in realtà.
/// Questu pò esse utile per API generiche chì utilizanu [`Result`] è parametrizanu u tippu di errore, per indicà chì u risultatu hè sempre [`Ok`].
///
/// Per esempiu, u [`TryFrom`] trait (cunversione chì rende un [`Result`]) hà una implementazione di manta per tutti i tipi induve esiste una implementazione inversa [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Compatibilità Future
///
/// Questa enum hà u listessu rolu cum'è [the `!`“never”type][never], chì hè instabile in questa versione di Rust.
/// Quandu `!` hè stabilizatu, pianificemu di fà `Infallible` un tippu alias per questu:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... è infine deprecate `Infallible`.
///
/// In ogni casu ci hè un casu induve a sintassi `!` pò esse usata prima chì `!` sia stabilizzata cum'è un tippu cumpletu: in a pusizione di u tipu di ritornu di una funzione.
/// Specificamente, hè pussibule implementazioni per dui tippi di puntatori di funzione differenti:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Cù `Infallible` hè un enum, stu codice hè validu.
/// In ogni casu quandu `Infallible` diventa un aliasu per u never type, i dui `impl`s cuminceranu à sovrapposizione è dunque saranu annullati da e regule di coerenza trait di a lingua.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}