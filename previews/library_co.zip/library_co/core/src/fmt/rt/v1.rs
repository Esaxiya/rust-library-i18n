//! Questu hè un modulu internu adupratu da l'ifmt!runtime.Queste strutture sò emesse à matrici statichi per precompilà stringhe di furmatu prima di u tempu.
//!
//! Queste definizioni sò simili à i so equivalenti `ct`, ma differenu in quantu ponu esse staticamente attribuiti è sò ligeramente ottimizzati per u runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Possibili allineamenti chì ponu esse dumandati cum'è parte di una direttiva di furmatu.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indicazione chì u cuntenutu deve esse allinatu à sinistra.
    Left,
    /// Indicazione chì i cuntenuti devenu esse allineati à a destra.
    Right,
    /// Indicazione chì i cuntenuti devenu esse allineati à u centru.
    Center,
    /// Nisun alineamentu hè statu dumandatu.
    Unknown,
}

/// Adupratu da i specificatori [width](https://doc.rust-lang.org/std/fmt/#width) è [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Specificatu cù un numeru litterale, memorizza u valore
    Is(usize),
    /// Specificatu cù sintassi `$` è `*`, memorizza l'indice in `args`
    Param(usize),
    /// Micca specificatu
    Implied,
}