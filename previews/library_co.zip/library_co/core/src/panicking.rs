//! Supportu Panic per libcore
//!
//! A biblioteca principale ùn pò micca definisce u panicu, ma face *dichjarà* u panicu.
//! Ciò significa chì e funzioni in libcore sò permesse à panic, ma per esse utile un crate upstream deve definisce u panicu per libcore da aduprà.
//! L'interfaccia attuale per u panicu hè:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Questa definizione permette u panicu cù qualsiasi messagiu generale, ma ùn permette micca di fallu cun un valore `Box<Any>`.
//! (`PanicInfo` cuntene solu un `&(dyn Any + Send)`, per u quale inseremu un valore fittiziu in `PanicInfo: : internal_constructor`.) U mutivu di questu hè chì libcore ùn hè micca permessu di attribuisce.
//!
//!
//! Stu modulu cuntene uni pochi d'altre funzioni di panicu, ma sò solu l'articuli lang necessarii per u compilatore.Tutti i panics sò funneled through this one function.
//! U simbulu propiu hè dichjaratu per l'attributu `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// L'implementazione sottostante di a macro `panic!` di libcore quandu ùn hè aduprata alcuna formattazione.
#[cold]
// mai in linea à menu chì panic_immediate_abort per evità u gonfiamentu di codice in i siti di chjamata u più pussibule
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // necessariu da codegen per panic in overflow è altri terminatori `Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Aduprate Arguments::new_v1 invece di format_args! ("{}", Expr) per riduce potenzialmente a dimensione generale.
    // U format_args!macro usa str's Display trait per scrive expr, chì chjama Formatter::pad, chì deve accoglie truncamentu di stringe è padding (ancu se nimu ùn hè adupratu quì).
    //
    // Aduprà Arguments::new_v1 pò permette à u compilatore di omettere Formatter::pad da u binariu di output, salvendu finu à pochi kilobyte.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // necessariu per panics cost-valutatu
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // necessariu da codegen per panic nantu à l'accessu OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// L'implementazione sottostante di a macro `panic!` di libcore quandu u furmatu hè adupratu.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NOTA Sta funzione ùn francà mai a fruntiera FFI;hè una chjamata Rust-à-Rust chì si risolve per a funzione `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SICUREZZA: `panic_impl` hè definitu in u codice Rust sicuru è cusì hè sicuru di chjamà.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Funzione interna per macros `assert_eq!` è `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}