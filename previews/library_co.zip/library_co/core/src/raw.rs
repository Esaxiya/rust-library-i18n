#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Contene definizioni strutturali per u layout di tippi integrati di compilatore.
//!
//! Pò esse aduprati cum'è bersaglii di trasmutazioni in codice periculosu per manipulà direttamente e rapprisentazioni prime.
//!
//!
//! A so definizione deve sempre currisponde à l'ABI definita in `rustc_middle::ty::layout`.
//!

/// A rapprisintazione di un ogettu trait cum'è `&dyn SomeTrait`.
///
/// Sta struttura hà u listessu schema cum'è tippi cum'è `&dyn SomeTrait` è `Box<dyn AnotherTrait>`.
///
/// `TraitObject` hè garantitu per currisponde à i schemi, ma ùn hè micca u tippu d'ogetti trait (per esempiu, i campi ùn sò micca accessibili direttamente nantu à un `&dyn SomeTrait`) nè cuntrolla quellu schema (cambià a definizione ùn cambierà micca u schema di un `&dyn SomeTrait`).
///
/// Hè cuncepitu solu per esse adupratu da un codice periculosu chì deve manipulà i dettagli di bassu livellu.
///
/// Ùn ci hè manera di riferisce à tutti l'oggetti trait genericamente, allora l'unicu modu per creà valori di stu tippu hè cù funzioni cum'è [`std::mem::transmute`][transmute].
/// Similmente, l'unicu modu per creà un veru oggettu trait da un valore `TraitObject` hè cù `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Sintetizà un ogettu trait cù tippi disaccordati-unu induve a vtable ùn currisponde micca à u tippu di u valore à chì punta u puntatore di dati-hè assai prubabile di purtà à un cumpurtamentu indefinitu.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // un esempiu trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // lascia chì u compilatore fessi un ogettu trait
/// let object: &dyn Foo = &value;
///
/// // fighjate a rapprisintazione cruda
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // u puntatore di dati hè l'indirizzu di `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // custruisce un novu ughjettu, indicendu un altru `i32`, fendu casu à aduprà a vtable `i32` da `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // duverebbe travaglià cum'è se avissimu custruitu un ogettu trait fora di `other_value` direttamente
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}