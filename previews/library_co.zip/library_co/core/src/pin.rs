//! Tipi chì ponenu dati à a so situazione in memoria.
//!
//! A volte hè utile avè oggetti chì sò garantiti da ùn spostassi, in u sensu chì u so piazzamentu in memoria ùn cambia, è pò cusì esse invucatu.
//! Un esempiu primu di tale scenariu seria a custruzzione di strutture autoreferenziali, postu chì u muvimentu di un ogettu cù puntatori per ellu stessu li invaliderà, ciò chì puderia causà cumpurtamentu indefinitu.
//!
//! À un altu livellu, un [`Pin<P>`] assicura chì u puntatore di qualsiasi tippu di puntatore `P` abbia una pusizione stabile in memoria, vale à dì chì ùn pò micca esse spustatu in altrò è a so memoria ùn pò micca esse dislocata finu à chì sia cascata.Dicemu chì u puntu hè "pinned".E cose diventanu più suttili quandu si discute di tippi chì si combinanu appuntati cù dati micca appuntati;[see below](#projections-and-structural-pinning) per più infurmazioni.
//!
//! Per automaticamente, tutti i tippi in Rust sò mobili.
//! Rust permette di passà tutti i tippi per valore, è i tippi cumuni di puntatori intelligenti cum'è [`Box<T>`] è `&mut T` permettenu di rimpiazzà è spustà i valori chì cuntenenu: pudete spustà fora di un [`Box<T>`], o pudete aduprà [`mem::swap`].
//! [`Pin<P>`] fasce un puntatore di tippu `P`, dunque [`Pin`]`<`[`Box`] `<T>>`funziona assai cum'è una regula
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`hè cascatu, cusì face u so cuntenutu, è a memoria si face
//!
//! dislocatu.Similmente, [`Pin`]`<&mut T>`hè assai simile à `&mut T`.Tuttavia, [`Pin<P>`] ùn lascia micca i clienti uttene veramente un [`Box<T>`] o `&mut T` à i dati appuntati, chì implica chì ùn pudete micca aduprà operazioni cum'è [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` hà bisognu di `&mut T`, ma ùn pudemu micca ottene.
//!     // Simu bluccati, ùn pudemu micca scambià u cuntenutu di sti riferimenti.
//!     // Puderemu aduprà `Pin::get_unchecked_mut`, ma hè periculosu per una ragione:
//!     // ùn avemu micca permessu di aduprà per spustà e cose fora di u `Pin`.
//! }
//! ```
//!
//! Vale a pena ribadisce chì [`Pin<P>`]*ùn* cambia *u fattu chì un compilatore Rust cunsidereghja tutti i tippi mobile.[`mem::swap`] ferma chjamabile per qualsiasi `T`.Invece, [`Pin<P>`] impedisce chì certi* valori * (indicati da i puntatori avvolti in [`Pin<P>`]) sianu spustati rendendu impussibile chjamà metudi chì richiedenu `&mut T` nantu à elli (cum'è [`mem::swap`]).
//!
//! [`Pin<P>`] pò esse adupratu per avvolge ogni tippu di puntatore `P`, è cume interagisce cù [`Deref`] è [`DerefMut`].Un [`Pin<P>`] induve `P: Deref` deve esse cunsideratu cum'è "`P`-style pointer" à un `P::Target` appuntatu-dunque, un [`Pin`]`<`[`Box`] `<T>>`hè un puntatore appartenente à un `T` appuntatu, è un [`Pin`] `<` [`Rc`]`<T>>`hè un puntatore cuntatu di riferenza à un `T` appuntatu.
//! Per correttezza, [`Pin<P>`] si basa nantu à l'implementazioni di [`Deref`] è [`DerefMut`] per ùn spustà fora di u so parametru `self`, è solu per restituisce un puntatore à i dati appuntati quandu sò chjamati nantu à un puntatore appuntatu.
//!
//! # `Unpin`
//!
//! Parechji tippi sò sempre liberamente mobili, ancu quandu sò appuntati, perchè ùn si basanu micca nantu à avè un indirizzu stabile.Ciò include tutti i tippi di basa (cum'è [`bool`], [`i32`] è referenze) è ancu tippi cumposti solu da questi tippi.Tipi chì ùn si primuranu micca di u pinning implementanu [`Unpin`] auto-trait, chì annulla l'effettu di [`Pin<P>`].
//! Per `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`è [`Box<T>`] funzionanu identicamente, cume facenu [`Pin`] `<&mut T>` è `&mut T`.
//!
//! Innota chì u pinning è [`Unpin`] influenzanu solu u tippu `P::Target` appuntitu, micca u tippu `P` puntatore stessu chì hè statu avvoltu in [`Pin<P>`].Per esempiu, sì [`Box<T>`] hè [`Unpin`] o ùn hà nisun effettu nant'à u cumpurtamentu di [`Pin`]`<`[`Box`] `<T>>`(quì, `T` hè u tippu à punta).
//!
//! # Esempiu: strutt autoreferenziale
//!
//! Prima di andà in più dettagli per spiegà e garanzie è e scelte associate à `Pin<T>`, discurremu alcuni esempi per cume puderia esse adupratu.
//! Sentitevi liberi di [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Si tratta di una struttura autoreferenziale perchè u campu slice punta à u campu di dati.
//! // Ùn pudemu micca informà u compilatore di questu cun una riferenza normale, chì stu mudellu ùn pò micca esse descrittu cù e regule di prestitu abituali.
//! //
//! // Invece usemu un puntatore grezzu, ancu se unu chì si sà chì ùn hè nulu, cume sapemu chì punta à a stringa.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Per assicurà chì i dati ùn si movenu micca quandu a funzione ritorna, a piazzemu in a mansa induve resterà per a vita di l'ughjettu, è l'unicu modu per accede ci seria per mezu di un puntatore.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // creemu solu u puntatore una volta chì i dati sò in piazza altrimenti si serà dighjà spustatu prima ancu di principià
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // sapemu chì hè sicuru perchè mudificà un campu ùn move micca a struttura sana
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // U puntatore duveria puntà versu u locu currettu, fintantu chì a struct ùn si move micca.
//! //
//! // Intantu, simu liberi di spustà u puntatore intornu.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Siccomu u nostru tipu ùn implementa micca Unpin, questu ùn puderà micca cumpilà:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Esempiu: lista intrusiva doppia ligata
//!
//! In una lista intrusiva doppiamente ligata, a raccolta ùn attribuisce micca in realtà a memoria per l'elementi stessi.
//! L'allocazione hè cuntrullata da i clienti, è l'elementi ponu campà nantu à un quadru di pila chì vive più cortu chè a cullezzione.
//!
//! Per fà stu travagliu, ogni elementu hà indicazione per u so predecessore è successore in a lista.Elementi ponu esse aghjunti solu quandu sò appuntati, perchè muvendu l'elementi intornu invaliderebbe i puntatori.D'altronde, l'implementazione [`Drop`] di un elementu di lista cunnessu parcherà l'indicatori di u so predecessore è successore per rimuovere si da a lista.
//!
//! Crucialmente, duvemu esse capace di contà nantu à chì [`drop`] hè chjamatu.Se un elementu puderia esse dislocatu o altrimenti invalidatu senza chjamà [`drop`], i puntatori in ellu da i so elementi vicini diventeranu invalidi, ciò chì romperia a struttura di dati.
//!
//! Dunque, u pinning vene ancu cun una garanzia [-drop]] relative.
//!
//! # `Drop` guarantee
//!
//! U scopu di u pinning hè di pudè contà nantu à u piazzamentu di certi dati in memoria.
//! Per fà stu travagliu, micca solu u muvimentu di i dati hè ristrettu;A distribuzione, a ripusizione, o altrimenti invalidendu a memoria aduprata per magazzinà i dati hè ancu limitata.
//! Concretamente, per i dati appuntati duvete mantene l'invariante chì *a so memoria ùn serà micca invalidata o ripurposta da u mumentu ch'ella hè appuntata finu à quandu [`drop`] hè chjamatu*.Solu una volta chì [`drop`] torna o panics, a memoria pò esse riutilizzata.
//!
//! A memoria pò esse "invalidated" per deallocation, ma ancu rimpiazzendu un [`Some(v)`] per [`None`], o chjamendu [`Vec::set_len`] à "kill" alcuni elementi fora di un vector.Pò esse rimpiazzatu aduprendu [`ptr::write`] per rimpiazzallu senza chjamà prima u distruttore.Nunda di questu hè permessu per i dati appuntati senza chjamà [`drop`].
//!
//! Questu hè esattamente u tipu di garanzia chì a lista ligata intrusiva da a sezione precedente deve funzionà currettamente.
//!
//! Notate chì sta garanzia ùn significa * **chì a memoria ùn perde micca!Hè sempre cumpletamente bè di ùn chjamà mai [`drop`] nant'à un elementu appuntatu (per esempiu, pudete sempre chjamà [`mem::forget`] nant'à un [`Pin`]`<`[`Box`] `<T>>`).In l'esempiu di a lista doppiamente ligata, quellu elementu resterebbe solu in a lista.Tuttavia ùn pudete micca liberà o riutilizà l'almacenamiento* senza chjamà [`drop`] *.
//!
//! # `Drop` implementation
//!
//! Se u vostru tipu usa pinning (cum'è i dui esempii sopra), duvete esse attenti quandu implementate [`Drop`].A funzione [`drop`] piglia `&mut self`, ma si chjama *ancu se u vostru tippu hè statu appuntatu*!Hè cum'è se u compilatore chjamassi automaticamente [`Pin::get_unchecked_mut`].
//!
//! Questu ùn pò mai causà un prublema in u codice sicuru perchè l'implementazione di un tippu chì si basa nantu à u pinning richiede un codice periculosu, ma siate cuscenti chì a decisione di fà usu di u pinning in u vostru tipu (per esempiu mettendu in opera qualchì operazione in [`Pin`]`<&Self>`o [`Pin`] `<&mut Self>`) hà cunsequenze ancu per a vostra implementazione [`Drop`]: se un elementu di u vostru tipu puderia esse statu appiccicatu, duvete trattà [`Drop`] cum'è implicitamente piglià [`Pin`]`<&mut Self>`.
//!
//!
//! Per esempiu, pudete implementà `Drop` cume:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` va bè perchè sapemu chì stu valore ùn hè mai più adupratu dopu esse statu abbandunatu.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // U codice di goccia attuale va quì.
//!         }
//!     }
//! }
//! ```
//!
//! A funzione `inner_drop` hà u tippu chì [`drop`]*duverebbe* avè, dunque questu assicura chì ùn aduprate micca accidentalmente `self`/`this` in un modu chì sia in conflittu cù u pinning.
//!
//! D'altronde, se u vostru tippu hè `#[repr(packed)]`, u compilatore sposterà automaticamente i campi intornu per pudè lascià li falà.Puderia ancu fà ciò per i campi chì accadenu à esse abbastanza allineati.Di conseguenza, ùn pudete micca aduprà pinning cun un tippu `#[repr(packed)]`.
//!
//! # Proiezioni è Pinning Strutturali
//!
//! Quandu si travaglia cù structs appuntate, si pone a quistione cumu si pò accede à i campi di quella struct in un metudu chì pigghia solu [`Pin`]`<&mut Struct>`.
//! L'approcciu abituale hè di scrive metudi d'aiutu (cosiddette *pruiezioni*) chì trasformanu [`Pin`]`<&mut Struct>`in una riferenza à u campu, ma chì tippu deve avè quellu riferimentu?Hè [`Pin`]`<&mut Field>`o `&mut Field`?
//! A listessa dumanda si pone cù i campi di un `enum`, è ancu quandu si consideranu tippi container/wrapper cum'è [`Vec<T>`], [`Box<T>`], o [`RefCell<T>`].
//! (Sta dumanda s'applica à e referenze mutevuli è cumuni, usemu solu u casu più cumunu di referenze mutevuli quì per illustrà.)
//!
//! Si scopre chì tocca à l'autore di a struttura di dati di decide se a proiezione appuntata per un campu particulare trasforma [`Pin`]`<&mut Struct>`in [`Pin`] `<&mut Field>` o `&mut Field`.Ci hè qualchì limitazione quantunque, è a restrizione più impurtante hè *consistenza*:
//! ogni campu pò esse *sia* prughjettatu per un riferimentu appuntatu,*sia* avè rimessu u pinning cum'è parte di a pruiezione.
//! Sì entrambi sò fatti per u listessu campu, ùn serà probabilmente micca solidu!
//!
//! Cum'è l'autore di una struttura di dati, uttene decide di ogni campu se aghjunghjite "propagates" à questu campu o micca.
//! U pinning chì si propaga hè ancu chjamatu "structural", perchè seguita a struttura di u tippu.
//! In e seguenti sottusezioni, descrivemu e cunsiderazioni chì devenu esse fatte per una scelta.
//!
//! ## Pinning *ùn hè micca* strutturale per `field`
//!
//! Pò parè contru-intuitivu chì u campu di una struttura appuntata pò ùn esse appuntatu, ma hè in realtà a scelta a più faciule: se un [`Pin`]`<&mut Field>`ùn hè mai creatu, nunda pò sbaglia!Dunque, se decidite chì alcuni campi ùn anu micca pinning strutturali, tuttu ciò chì duvete assicurà hè chì ùn create mai una riferenza appuntata à quellu campu.
//!
//! I campi senza pinzatura strutturale ponu avè un metudu di prughjezzione chì trasforma [`Pin`]`<&mut Struct>`in `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Va bè perchè `field` ùn hè mai cunsideratu appuntatu.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Pudete ancu `impl Unpin for Struct`*ancu se* u tipu di `field` ùn hè micca [`Unpin`].Ciò chì u tippu pensa nantu à u pinning ùn hè micca pertinente quandu ùn hè mai creatu [[Pin]] `<&mut Field>`.
//!
//! ## Pinning *hè* strutturale per `field`
//!
//! L'altra opzione hè di decide chì u pinning hè "structural" per `field`, vale à dì chì se a struct hè appuntata allora hè ancu u campu.
//!
//! Questu permette di scrive una pruiezione chì crea un [`Pin`]`<&mut Field>`, testimunendu cusì chì u campu hè appuntatu:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Questu va bè perchè `field` hè appiccicatu quandu `self` hè.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Tuttavia, u pinning strutturale vene cun pochi requisiti in più:
//!
//! 1. A struttura deve esse solu [`Unpin`] se tutti i campi strutturali sò [`Unpin`].Questu hè u predefinitu, ma [`Unpin`] hè un trait sicuru, cusì cum'è autore di a struttura hè a vostra responsabilità *micca* di aghjunghje qualcosa cum'è `impl<T> Unpin for Struct<T>`.
//! (Notate chì l'aggiunta di un'operazione di proiezione richiede un codice periculosu, allora u fattu chì [`Unpin`] sia un trait sicuro ùn rompe u principiu chì avete da preoccupassi solu di qualcosa di questu se utilizate "periculosu".)
//! 2. U distruttore di a struttura ùn deve micca spostà campi strutturali fora di u so argumentu.Questu hè u puntu esattu chì hè statu risuscitatu in u [previous section][drop-impl]: `drop` piglia `&mut self`, ma a struttura (è dunque i so campi) puderia esse stata appiccicata prima.
//!     Duvete garantisce chì ùn muvite micca un campu in a vostra implementazione [`Drop`].
//!     In particulare, cum'è spiegatu prima, questu significa chì a vostra struttura ùn deve *micca* esse `#[repr(packed)]`.
//!     Vede quella sezzione per cumu scrive [`drop`] in un modu chì u compilatore pò aiutà à ùn spezziunà micca u pinning.
//! 3. Duvete assicurassi chì sustene u [`Drop` guarantee][drop-guarantee]:
//!     una volta chì a vostra struttura hè appuntata, a memoria chì cuntene u cuntenutu ùn hè micca sovrascritta o dislocata senza chjamà i distruttori di u cuntenutu.
//!     Questu pò esse complicatu, cum'è testimone di [`VecDeque<T>`]: u distruttore di [`VecDeque<T>`] pò fallu di chjamà [`drop`] nantu à tutti l'elementi se unu di i distruttori panics.Questa viola a garanzia [`Drop`], perchè pò purtà à l'elementi chì sò dislocati senza chì u so distruttore sia chjamatu.([`VecDeque<T>`] ùn hà micca pruiezioni di pinning, dunque questu ùn causa micca insolenza.)
//! 4. Ùn duvete micca offre alcuna altra operazione chì pò purtà à spustà i dati fora di i campi strutturali quandu u vostru tipu hè appiccicatu.Per esempiu, se a struttura cuntene un [`Option<T>`] è ci hè un'operazione simile à "piglià" cù u tippu `fn(Pin<&mut Struct<T>>) -> Option<T>`, quella operazione pò esse usata per spustà un `T` fora di un `Struct<T>` appuntatu-chì significa chì u pinning ùn pò micca esse strutturale per u campu chì tene questu dati.
//!
//!     Per un esempiu più cumplessu di spustamentu di dati fora di un tipu appuntatu, imaginate se [`RefCell<T>`] avia un metudu `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Dopu pudemu fà u seguitu:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Questu hè catastroficu, significa chì pudemu prima pinà u cuntenutu di u [`RefCell<T>`] (aduprendu `RefCell::get_pin_mut`) è dopu spostà quellu cuntenutu aduprendu a riferenza mutabile chì avemu avutu dopu.
//!
//! ## Examples
//!
//! Per un tippu cum'è [`Vec<T>`], entrambe e pussibilità (pinning strutturale o micca) anu sensu.
//! Un [`Vec<T>`] cù pinning strutturale puderia avè metudi `get_pin`/`get_pin_mut` per uttene riferimenti appuntati à elementi.Tuttavia, ùn pudia *micca* permette di chjamà [`pop`][Vec::pop] nantu à un [`Vec<T>`] appuntatu perchè chì spusterebbe u cuntenutu (strutturalmente appuntatu)!Nemmenu puderia permette [`push`][Vec::push], chì puderebbe riallocà è cusì move ancu u cuntenutu.
//!
//! Un [`Vec<T>`] senza pinning strutturale puderia `impl<T> Unpin for Vec<T>`, perchè u cuntenutu ùn hè mai appiccicatu è u [`Vec<T>`] stessu hè bè cù esse spustatu ancu.
//! À quellu puntu u pinning ùn hà mancu un effettu nant'à u vector.
//!
//! In a biblioteca standard, i tippi di puntatori generalmente ùn anu micca pinning strutturali, è cusì ùn offrenu micca proiezioni di pinning.Hè per quessa chì `Box<T>: Unpin` tene per tuttu `T`.
//! Hè logicu di fà questu per i tippi di puntatori, perchè muvendu u `Box<T>` ùn move micca in realtà u `T`: u [`Box<T>`] pò esse liberamente mobile (alias `Unpin`) ancu se `T` ùn hè micca.In fattu, ancu [`Pin`]`<`[`Box`] `<T>>`è [`Pin`] `<&mut T>` sò sempre [`Unpin`] stessi, per a stessa ragione: u so cuntenutu (u `T`) sò appuntati, ma i puntatori stessi ponu esse spostati senza spostà i dati appuntati.
//! Per [`Box<T>`] è [`Pin`]`<`[`Box`] `<T>>`, sì u cuntenutu sia appuntatu hè interamente indipendente da se u puntatore sia appuntatu, vale à dì chì u pinning ùn sia * strutturale.
//!
//! Quandu implementate un combinatore [`Future`], di solitu averete bisognu di pinzatura strutturale per i futures nidificati, cume avete bisognu di uttene riferenze appuntate per chjamà [`poll`].
//! Ma se u vostru cumbinatore cuntene altri dati chì ùn anu micca bisognu di esse appuntati, pudete rende quelli campi micca strutturali è dunque accede liberamente ad elli cù una riferenza mutevule ancu quandu avete solu [`Pin`]`<&mut Self>`(tale cum'è in a vostra propria implementazione [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Un puntatore appuntatu.
///
/// Si tratta di un involucru intornu à una spezia di puntatore chì face di quellu puntatore "pin" u so valore in locu, impedendu chì u valore riferitu da quellu puntatore sia spostatu a menu chì ùn implementi [`Unpin`].
///
///
/// *Vede a ducumentazione [`pin` module] per una spiegazione di pinning.*
///
/// [`pin` module]: self
///
// Note: u `Clone` derive quì sottu provoca a mancanza di solitudine in quantu hè pussibule di implementà
// `Clone` per referenze mutevuli.
// Vede <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> per più infurmazioni.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// E seguenti implementazioni ùn sò micca derivate per evità prublemi di solidità.
// `&self.pointer` ùn deve micca esse accessibile à l'implementazioni trait micca fidate.
//
// Vede <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> per più infurmazioni.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Custruisce un novu `Pin<P>` intornu à un puntatore per alcuni dati di un tippu chì implementa [`Unpin`].
    ///
    /// A differenza di `Pin::new_unchecked`, stu metudu hè sicuru perchè u puntatore `P` derifera à un tippu [`Unpin`], chì annulla e garanzie di pinning.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SICUREZZA: u valore indicatu hè `Unpin`, è dunque ùn hà micca esigenze
        // intornu à pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Scopre stu `Pin<P>` chì ritorna u puntatore sottostante.
    ///
    /// Questu richiede chì i dati in questu `Pin` sò [`Unpin`] in modo da pudemu ignorà l'invarianti di pinning quandu u sviloppu.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Custruisce un novu `Pin<P>` intornu à una riferenza à alcuni dati di un tippu chì pò o ùn pò implementà `Unpin`.
    ///
    /// Se `pointer` deriva à un tippu `Unpin`, `Pin::new` deve esse adupratu invece.
    ///
    /// # Safety
    ///
    /// Stu costruttore ùn hè micca sicuru perchè ùn pudemu micca garantì chì i dati indicati da `pointer` sò appuntati, vale à dì chì i dati ùn seranu micca sposti o u so almacenamentu invalidatu finu à ch'ella sia cascata.
    /// Se u `Pin<P>` custruitu ùn garantisce micca chì i dati chì `P` punta sia appuntati, hè una violazione di u cuntrattu API è pò purtà à un comportamentu indefinitu in operazioni (safe) successive.
    ///
    /// Usendu stu metudu, fate una promise nantu à l'implementazioni `P::Deref` è `P::DerefMut`, se esistenu.
    /// U più impurtante, ùn devenu micca spustà fora di i so argumenti `self`: `Pin::as_mut` è `Pin::as_ref` chjameranu `DerefMut::deref_mut` è `Deref::deref`*nantu à u puntatore appuntatu* è aspettanu chì sti metudi difendenu l'invarianti di pinning.
    /// D'altronde, chjamendu stu metudu promise chì a riferenza à e dereferenze `P` ùn serà micca spustata fora di novu;in particulare, ùn deve micca esse pussibule d'ottene un `&mut P::Target` è dopu surtite da quellu riferimentu (aduprendu, per esempiu [`mem::swap`]).
    ///
    ///
    /// Per esempiu, chjamà `Pin::new_unchecked` nantu à un `&'a mut T` ùn hè micca sicuru perchè mentre puderete pinzallu per a vita `'a` data, ùn avete micca cuntrollu se hè tenutu appuntatu una volta chì `'a` finisce:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Ciò duveria significà chì u puntatore `a` ùn pò mai move di più.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // L'indirizzu di `a` hà cambiatu in u slot di stack di "b", cusì `a` hè statu spostatu ancu se l'avemu appuntatu prima!Avemu violatu u cuntrattu di pinning API.
    /////
    /// }
    /// ```
    ///
    /// Un valore, una volta appuntatu, deve rimanere appuntatu per sempre (a menu chì u so tippu implementi `Unpin`).
    ///
    /// Similmente, chjamà `Pin::new_unchecked` nantu à un `Rc<T>` ùn hè micca sicuru perchè puderebbenu esse aliasi per i stessi dati chì ùn sò micca sottumessi à e restrizioni di pinning:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Questu deve significà chì u puntatore ùn pò mai più muvassi.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Avà, se `x` era l'unicu riferimentu, avemu un riferimentu mutevule à i dati chì avemu appiccicatu sopra, chì puderiamu aduprà per spustallu cum'è l'avemu vistu in l'esempiu precedente.
    ///     // Avemu violatu u cuntrattu di pinning API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Ottiene un riferimentu cumunu appuntatu da stu puntatore appuntatu.
    ///
    /// Questu hè un metudu genericu per andà da `&Pin<Pointer<T>>` à `Pin<&T>`.
    /// Hè sicuru perchè, cum'è parte di u cuntrattu di `Pin::new_unchecked`, u puntatore ùn pò micca spustà dopu chì `Pin<Pointer<T>>` hè statu creatu.
    ///
    /// "Malicious" l'implementazioni di `Pointer::Deref` sò ancu scartate da u cuntrattu di `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SICUREZZA: vede a ducumentazione annantu à sta funzione
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Scopre stu `Pin<P>` chì ritorna u puntatore sottostante.
    ///
    /// # Safety
    ///
    /// Sta funzione ùn hè micca sicura.Duvete garantì chì continuerete à trattà u puntatore `P` cum'è appiccicatu dopu à chjamà sta funzione, in modu chì l'invarianti di u tippu `Pin` ponu esse accolti.
    /// Se u codice chì utilizeghja u `P` resultante ùn cuntinueghja à mantene l'invarianti di pinning chì hè una violazione di u cuntrattu API è pò purtà à un comportamentu indefinitu in operazioni (safe) successive.
    ///
    ///
    /// Se i dati sottostanti sò [`Unpin`], [`Pin::into_inner`] deve esse adupratu invece.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Ottiene un riferimentu mutabile appuntatu da questu puntatore appuntatu.
    ///
    /// Questu hè un metudu genericu per andà da `&mut Pin<Pointer<T>>` à `Pin<&mut T>`.
    /// Hè sicuru perchè, cum'è parte di u cuntrattu di `Pin::new_unchecked`, u puntatore ùn pò micca spustà dopu chì `Pin<Pointer<T>>` hè statu creatu.
    ///
    /// "Malicious" l'implementazioni di `Pointer::DerefMut` sò ancu scartate da u cuntrattu di `Pin::new_unchecked`.
    ///
    /// Stu metudu hè utile quandu si facenu più chjamate à funzioni chì cunsumanu u tipu appuntatu.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // fà qualcosa
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` cunsuma `self`, dunque ripigliate u `Pin<&mut Self>` via `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SICUREZZA: vede a ducumentazione annantu à sta funzione
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Assigna un novu valore à a memoria daretu à a riferenza appuntata.
    ///
    /// Què rimpiazzà i dati appuntati, ma va bè: u so distruttore vene eseguitu prima di esse sovrascritti, dunque ùn hè viulata nisuna garanzia di pinning.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Custruisce un novu pin mappendu u valore interiore.
    ///
    /// Per esempiu, se vulete ottene un `Pin` di un campu di qualcosa, pudete aduprà questu per accede à quellu campu in una linea di codice.
    /// Tuttavia, ci sò parechji gotchas cù questi "pinning projections";
    /// vede a ducumentazione [`pin` module] per più infurmazioni nantu à questu tema.
    ///
    /// # Safety
    ///
    /// Sta funzione ùn hè micca sicura.
    /// Duvete garantì chì i dati chì restituite ùn si spustinu micca finu à quandu u valore di l'argumentu ùn si move (per esempiu, perchè hè unu di i campi di quellu valore), è ancu chì ùn spustate micca fora di l'argumentu chì ricevi à a funzione interiore.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SICUREZZA: u cuntrattu di sicurezza per `new_unchecked` deve esse
        // cunfirmatu da u chjamante.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Uttene un riferimentu cumunu fora di un pin.
    ///
    /// Questu hè sicuru perchè ùn hè micca pussibule di spustà fora di una riferenza cumuna.
    /// Pò parè chì quì ci sia un prublema cù a mutabilità interiore: in realtà,*hè* pussibule di spustà un `T` fora di un `&RefCell<T>`.
    /// Tuttavia, questu ùn hè micca un prublema finu à quandu ùn esiste ancu un `Pin<&T>` chì punta à i stessi dati, è `RefCell<T>` ùn vi lascia micca creà una riferenza appuntata à u so cuntenutu.
    ///
    /// Vede a discussione nantu à ["pinning projections"] per ulteriori dettagli.
    ///
    /// Note: `Pin` implementa ancu `Deref` à u target, chì pò esse adupratu per accede à u valore internu.
    /// Tuttavia, `Deref` furnisce solu una riferenza chì vive per u tempu di u prestitu di u `Pin`, micca a vita di u `Pin` stessu.
    /// Stu metudu permette di trasfurmà l `Pin` in una riferenza cù a stessa vita di l `Pin` originale.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Converte questu `Pin<&mut T>` in un `Pin<&T>` cù a stessa vita.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Ottiene una riferenza mutabile à i dati in questu `Pin`.
    ///
    /// Questu richiede chì i dati in questu `Pin` sò `Unpin`.
    ///
    /// Note: `Pin` implementa ancu `DerefMut` à i dati, chì ponu esse aduprati per accede à u valore internu.
    /// Tuttavia, `DerefMut` furnisce solu una riferenza chì vive per u tempu di u prestitu di u `Pin`, micca a vita di u `Pin` stessu.
    ///
    /// Stu metudu permette di trasfurmà l `Pin` in una riferenza cù a stessa vita di l `Pin` originale.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Ottiene una riferenza mutabile à i dati in questu `Pin`.
    ///
    /// # Safety
    ///
    /// Sta funzione ùn hè micca sicura.
    /// Duvete garantisce chì ùn spustarete mai i dati fora di a riferenza mutevule chì ricevi quandu chjamate sta funzione, affinchì l'invarianti di u tippu `Pin` ponu esse accolti.
    ///
    ///
    /// Se i dati sottostanti sò `Unpin`, `Pin::get_mut` deve esse adupratu invece.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Custruisce un novu pin mappendu u valore interiore.
    ///
    /// Per esempiu, se vulete ottene un `Pin` di un campu di qualcosa, pudete aduprà questu per accede à quellu campu in una linea di codice.
    /// Tuttavia, ci sò parechji gotchas cù questi "pinning projections";
    /// vede a ducumentazione [`pin` module] per più infurmazioni nantu à questu tema.
    ///
    /// # Safety
    ///
    /// Sta funzione ùn hè micca sicura.
    /// Duvete garantì chì i dati chì restituite ùn si spustinu micca finu à quandu u valore di l'argumentu ùn si move (per esempiu, perchè hè unu di i campi di quellu valore), è ancu chì ùn spustate micca fora di l'argumentu chì ricevi à a funzione interiore.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SICUREZZA: u chjamante hè rispunsevule per ùn spustà u
        // valore fora di sta riferenza.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SICUREZZA: cum'è u valore di `this` hè garantitu chì ùn hà micca
        // hè statu spustatu, sta chjamata à `new_unchecked` hè sicura.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Uttenite una riferenza appuntata da una riferenza statica.
    ///
    /// Questu hè sicuru, perchè `T` hè pigliatu in prestu per a vita `'static`, chì ùn finisce mai.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SICUREZZA: U 'prestitu staticu garantisce chì i dati ùn saranu micca
        // moved/invalidated finu à ch'ella sia cascata (chì ùn hè mai).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Uttenite una riferenza mutabile appuntata da una referenza mutabile statica.
    ///
    /// Questu hè sicuru, perchè `T` hè pigliatu in prestu per a vita `'static`, chì ùn finisce mai.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SICUREZZA: U 'prestitu staticu garantisce chì i dati ùn saranu micca
        // moved/invalidated finu à ch'ella sia cascata (chì ùn hè mai).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: questu significa chì qualsiasi impl di `CoerceUnsized` chì permette a coercizione da
// un tipu chì implica `Deref<Target=impl !Unpin>` à un tipu chì implica `Deref<Target=Unpin>` ùn hè micca solidu.
// Qualunque tale impl hè probabilmente insolente per altre ragioni, però, allora ci vole solu à fà casu di ùn permettà micca chì tali impls sbarcanu in std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}