//! char char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// U puntu di codice più altu validu chì un `char` pò avè.
    ///
    /// Un `char` hè un [Unicode Scalar Value], chì significa chì hè un [Code Point], ma solu in una certa gamma.
    /// `MAX` hè u puntu di codice più altu validu chì hè un [Unicode Scalar Value] validu.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () hè adupratu in Unicode per riprisentà un errore di decodifica.
    ///
    /// Pò accadere, per esempiu, quandu si dà UTF-8 byte mal furmati à [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// A versione di [Unicode](http://www.unicode.org/) chì si basa nantu à e parti Unicode di i metudi `char` è `str`.
    ///
    /// E nuove versioni di Unicode sò publicate regolarmente è dopu tutti i metudi in a libreria standard secondu Unicode sò aggiornati.
    /// Dunque u cumpurtamentu di certi metudi `char` è `str` è u valore di sta custante cambia cù u tempu.
    /// Questu hè *micca* cunsideratu cum'è un cambiamentu di punta.
    ///
    /// U schema di numerazione di versione hè spiegatu in [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Crea un iteratore sopra i punti codici codificati UTF-16 in `iter`, restituendu i surrogati senza paru cum'è `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Un decodificatore lossy pò esse ottenutu rimpiazzendu i risultati `Err` cù u caratteru di rimpiazzamentu:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Converte un `u32` in un `char`.
    ///
    /// Nutate bè chì tutti i `char` sò validi [`u32`] s, è ponu esse ghjittati à unu cù
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Tuttavia, l'inversu ùn hè micca veru: micca tutti i validi [`u32`] sò validi per`char`s.
    /// `from_u32()` restituverà `None` se l'entrata ùn hè micca un valore validu per un `char`.
    ///
    /// Per una versione periculosa di sta funzione chì ignora sti cuntrolli, vede [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Ritorna `None` quandu l'input ùn hè micca un `char` validu:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Converte un `u32` in un `char`, ignurendu a validità.
    ///
    /// Nutate bè chì tutti i `char` sò validi [`u32`] s, è ponu esse ghjittati à unu cù
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Tuttavia, l'inversu ùn hè micca veru: micca tutti i validi [`u32`] sò validi per`char`s.
    /// `from_u32_unchecked()` ignorerà questu, è ghjittarà à a ceca à `char`, forse creendu unu invalidu.
    ///
    ///
    /// # Safety
    ///
    /// Sta funzione ùn hè micca sicura, perchè pò custruisce valori `char` invalidi.
    ///
    /// Per una versione sicura di sta funzione, vedi a funzione [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SICUREZZA: u cuntrattu di sicurezza deve esse rispettatu da u chjamante.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Converte una cifra in a radice data in un `char`.
    ///
    /// Un 'radix' quì hè qualchì volta chjamatu ancu 'base'.
    /// Una radice di dui indica un numeru binariu, una radice di dece, decimale, è una radice di sedici, esadecimale, per dà alcuni valori cumuni.
    ///
    /// Radices arbitrarie sò supportate.
    ///
    /// `from_digit()` restituverà `None` se l'entrata ùn hè micca una cifra in a radice data.
    ///
    /// # Panics
    ///
    /// Panics se hè datu un radix più grande di 36.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Decimali 11 hè una sola cifra in basa 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Ritorna `None` quandu l'entrata ùn hè micca una cifra:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Passendu un grande radix, causendu un panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Verifica se un `char` hè un cifru in a radice data.
    ///
    /// Un 'radix' quì hè qualchì volta chjamatu ancu 'base'.
    /// Una radice di dui indica un numeru binariu, una radice di dece, decimale, è una radice di sedici, esadecimale, per dà alcuni valori cumuni.
    ///
    /// Radices arbitrarie sò supportate.
    ///
    /// Comparatu à [`is_numeric()`], sta funzione ricunnosce solu i caratteri `0-9`, `a-z` è `A-Z`.
    ///
    /// 'Digit' hè definitu solu i caratteri seguenti:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Per una comprensione più cumpleta di 'digit', vedi [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics se hè datu un radix più grande di 36.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Passendu un grande radix, causendu un panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Converte un `char` in un cifru in a radice data.
    ///
    /// Un 'radix' quì hè qualchì volta chjamatu ancu 'base'.
    /// Una radice di dui indica un numeru binariu, una radice di dece, decimale, è una radice di sedici, esadecimale, per dà alcuni valori cumuni.
    ///
    /// Radices arbitrarie sò supportate.
    ///
    /// 'Digit' hè definitu solu i caratteri seguenti:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Restituisce `None` se `char` ùn si riferisce micca à una cifra in a radice data.
    ///
    /// # Panics
    ///
    /// Panics se hè datu un radix più grande di 36.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Passà un non-cifru risultati in fallimentu:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Passendu un grande radix, causendu un panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // u codice hè spartutu quì per migliurà a velocità di esecuzione per i casi in cui u `radix` hè costante è 10 o più chjucu
        //
        let val = if likely(radix <= 10) {
            // Se micca una cifra, un numeru più grande di radix serà creatu.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Restituisce un iteratore chì dà a fuga esadecimale Unicode di un caratteru cum'è `char`s.
    ///
    /// Questu scapparà caratteri cù a sintassi Rust di a forma `\u{NNNNNN}` induve `NNNNNN` hè una rapprisintazione esadecimale.
    ///
    ///
    /// # Examples
    ///
    /// Cum'è iteratore:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Aduprà `println!` direttamente:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Tramindui sò equivalenti à:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Aduprendu `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 assicura chì per c==0 u codice calculi chì una cifra duverebbe esse stampata è (chì hè listessa) evita u sottofluu (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // l'indice di a cifra hex più significativa
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Una versione estesa di `escape_debug` chì permette facoltativamente di scappà di punti di codice Extended Grapheme.
    /// Questu ci permette di formattà caratteri cume marchi senza spaziatura megliu quandu sò à l'iniziu di una stringa.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Restituisce un iteratore chì dà u codice di fuga letterale di un caratteru cum'è `char`s.
    ///
    /// Questu scapparà i caratteri simili à l'implementazioni `Debug` di `str` o `char`.
    ///
    ///
    /// # Examples
    ///
    /// Cum'è iteratore:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Aduprà `println!` direttamente:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Tramindui sò equivalenti à:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Aduprendu `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Restituisce un iteratore chì dà u codice di fuga letterale di un caratteru cum'è `char`s.
    ///
    /// U predefinitu hè sceltu cù un preghjudiziu versu a produzzione di letterali chì sò legali in una varietà di lingue, cumpresu C++ 11 è lingue simili di a famiglia C.
    /// E regule esatte sò:
    ///
    /// * Tab hè scappatu cum'è `\t`.
    /// * U ritornu di u trasportu hè scappatu cum'è `\r`.
    /// * L'alimentazione di linea hè scappata cum'è `\n`.
    /// * Una sola cita hè scappata cum'è `\'`.
    /// * A doppia citazione hè scappata cum'è `\"`.
    /// * Backslash hè scappatu cum'è `\\`.
    /// * Qualchì caratteru di a stampa 'ASCII stampabile' `0x20` .. `0x7e` cumpresu ùn hè micca scappatu.
    /// * Tutti l'altri caratteri sò dati fughe Unicad esadecimali;vede [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Cum'è iteratore:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Aduprà `println!` direttamente:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Tramindui sò equivalenti à:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Aduprendu `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Restituisce u numeru di byte chì `char` averia bisognu se cudificatu in UTF-8.
    ///
    /// Ddu numeru di bytes hè sempre trà 1 è 4, cumpresu.
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// U tippu `&str` garantisce chì i so cuntenuti sò UTF-8, è cusì pudemu paragunà a lunghezza chì averia da piglià se ogni puntu di codice era rapprisentatu cum'è `char` vs in u `&str` stessu:
    ///
    ///
    /// ```
    /// // cum'è chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // tramindui ponu esse ripresentati cum'è trè byte
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // cum'è &str, sti dui sò codificati in UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // pudemu vede chì piglianu sei byte totali ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... cum'è u &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Restituisce u numeru di unità di codice à 16 bit chì questu `char` averia bisognu se codificatu in UTF-16.
    ///
    ///
    /// Vede a documentazione per [`len_utf8()`] per più spiegazione di stu cuncettu.
    /// Sta funzione hè un specchiu, ma per UTF-16 invece di UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Codifica stu caratteru cum'è UTF-8 in u buffer byte furnitu, è poi restituisce a sottuslice di u buffer chì cuntene u caratteru codificatu.
    ///
    ///
    /// # Panics
    ///
    /// Panics se u buffer ùn hè micca abbastanza grande.
    /// Un buffer di lunghezza quattru hè abbastanza grande per codificà qualsiasi `char`.
    ///
    /// # Examples
    ///
    /// In questi esempi, 'ß' piglia dui byte per codificà.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Un buffer troppu chjucu:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SICUREZZA: `char` ùn hè micca un sustitutu, dunque questu hè UTF-8 validu.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Codifica stu caratteru cum'è UTF-16 in u buffer `u16` furnitu, è poi restituisce a sottuslice di u buffer chì cuntene u caratteru codificatu.
    ///
    ///
    /// # Panics
    ///
    /// Panics se u buffer ùn hè micca abbastanza grande.
    /// Un buffer di lunghezza 2 hè abbastanza grande per codificà qualsiasi `char`.
    ///
    /// # Examples
    ///
    /// In entrambi questi esempi, '𝕊' piglia dui `u16` per codificà.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Un buffer troppu chjucu:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Ritorna `true` se questu `char` hà a pruprietà `Alphabetic`.
    ///
    /// `Alphabetic` hè descrittu in u Capitulu 4 (Caratteristiche Caratteristiche) di u [Unicode Standard] è specificatu in u [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // l'amore hè parechje cose, ma ùn hè micca alfabeticu
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Ritorna `true` se questu `char` hà a pruprietà `Lowercase`.
    ///
    /// `Lowercase` hè descrittu in u Capitulu 4 (Caratteristiche Caratteristiche) di u [Unicode Standard] è specificatu in u [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // I vari scritti cinesi è a puntuazione ùn anu micca casu, è cusì:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Ritorna `true` se questu `char` hà a pruprietà `Uppercase`.
    ///
    /// `Uppercase` hè descrittu in u Capitulu 4 (Caratteristiche Caratteristiche) di u [Unicode Standard] è specificatu in u [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // I vari scritti cinesi è a puntuazione ùn anu micca casu, è cusì:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Ritorna `true` se questu `char` hà a pruprietà `White_Space`.
    ///
    /// `White_Space` hè specificatu in u [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // un spaziu senza rumpitura
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Ritorna `true` se questu `char` soddisfa sia [`is_alphabetic()`] sia [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Ritorna `true` se questu `char` hà a categuria generale per i codici di cuntrollu.
    ///
    /// Codici di cuntrollu (punti di codice cù a categuria generale di `Cc`) sò descritti in u Capitulu 4 (Proprietà di Carattere) di u [Unicode Standard] è specificati in u [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// // U + 009C, TERMINATORE A CORDA
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Ritorna `true` se questu `char` hà a pruprietà `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` hè descrittu in [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] è specificatu in [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Ritorna `true` se questu `char` hà una di e categurie generali per i numeri.
    ///
    /// E categurie generali per i numeri (`Nd` per e cifre decimali, `Nl` per i caratteri numerichi cum'è lettera, è `No` per altri caratteri numerichi) sò specificate in u [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Usu di basa:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Restituisce un iteratore chì dà a cartografia minuscule di stu `char` cum'è unu o più
    /// `char`s.
    ///
    /// Se stu `char` ùn hà micca una cartografia minuscule, l'iteratore dà u listessu `char`.
    ///
    /// Se questu `char` hà una cartografia minuscula unu-à-unu data da u [Unicode Character Database][ucd] [`UnicodeData.txt`], l'iteratore rende quellu `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Se stu `char` richiede cunsiderazioni speciali (per esempiu multipli `char`s) l'iteratore dà u`char` (s) datu da [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Questa operazione esegue una cartografia incondizionale senza adattazione.Hè cusì, a cunversione hè indipendente da u cuntestu è da a lingua.
    ///
    /// In u [Unicode Standard], u Capitulu 4 (Caratteristiche Caratteristiche) discute a cartografia di casi in generale è u Capitulu 3 (Conformance) discute l'algoritmu predefinitu per a cunversione di casi.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Cum'è iteratore:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Aduprà `println!` direttamente:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Tramindui sò equivalenti à:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Aduprendu `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // A volte u risultatu hè più di un caratteru:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // I caratteri chì ùn anu micca maiuscule è minuscule si cunvertenu in se stessi.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Restituisce un iteratore chì dà a cartografia maiuscula di stu `char` cum'è unu o più
    /// `char`s.
    ///
    /// Se stu `char` ùn hà micca una cartografia maiuscula, l'iteratore rende u listessu `char`.
    ///
    /// Se stu `char` hà una cartografia maiuscula unu à unu data da u [Unicode Character Database][ucd] [`UnicodeData.txt`], l'iteratore rende quellu `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Se stu `char` richiede cunsiderazioni speciali (per esempiu multipli `char`s) l'iteratore dà u`char` (s) datu da [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Questa operazione esegue una cartografia incondizionale senza adattazione.Hè cusì, a cunversione hè indipendente da u cuntestu è da a lingua.
    ///
    /// In u [Unicode Standard], u Capitulu 4 (Caratteristiche Caratteristiche) discute a cartografia di casi in generale è u Capitulu 3 (Conformance) discute l'algoritmu predefinitu per a cunversione di casi.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Cum'è iteratore:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Aduprà `println!` direttamente:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Tramindui sò equivalenti à:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Aduprendu `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // A volte u risultatu hè più di un caratteru:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // I caratteri chì ùn anu micca maiuscule è minuscule si cunvertenu in se stessi.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Nota nantu à u locale
    ///
    /// In turcu, l'equivalente di 'i' in latinu hà cinque forme invece di duie:
    ///
    /// * 'Dotless': I/ı, qualchì volta scrittu ï
    /// * 'Dotted': İ/i
    ///
    /// Nutate bè chì u 'i' in minuscule spuntatu hè listessu chì u latinu.Dunque:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// U valore di `upper_i` si basa quì nantu à a lingua di u testu: se simu in `en-US`, duveria esse `"I"`, ma se simu in `tr_TR`, deve esse `"İ"`.
    /// `to_uppercase()` ùn ne tene micca contu, è cusì:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// tene in parechje lingue.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Verifica se u valore hè in u intervallu ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Rende una copia di u valore in u so equivalente in maiuscule ASCII.
    ///
    /// E lettere ASCII 'a' à 'z' sò mappate à 'A' à 'Z', ma e lettere non ASCII sò invariate.
    ///
    /// Per fà maiuscule u valore in locu, aduprate [`make_ascii_uppercase()`].
    ///
    /// Per caratteri ASCII maiuscule in più di caratteri non ASCII, aduprate [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Rende una copia di u valore in u so equivalente in minuscule ASCII.
    ///
    /// E lettere ASCII 'A' à 'Z' sò mappate à 'a' à 'z', ma e lettere non ASCII sò invariate.
    ///
    /// Per minuscule u valore in situ, utilizate [`make_ascii_lowercase()`].
    ///
    /// Per minuscule caratteri ASCII in più di caratteri non ASCII, aduprate [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Verifica chì dui valori sò un match ASCII case-insensitive.
    ///
    /// Equivalente à `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Converte stu tippu in u so equivalente in maiuscule ASCII in locu.
    ///
    /// E lettere ASCII 'a' à 'z' sò mappate à 'A' à 'Z', ma e lettere non ASCII sò invariate.
    ///
    /// Per restituisce un novu valore maiusculatu senza mudificà quellu esistente, aduprate [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Converte stu tipu in u so equivalente ASCII minuscule in locu.
    ///
    /// E lettere ASCII 'A' à 'Z' sò mappate à 'a' à 'z', ma e lettere non ASCII sò invariate.
    ///
    /// Per restituisce un novu valore minuscule senza mudificà quellu esistente, aduprate [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Verifica se u valore hè un caratteru alfabeticu ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', o
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Verifica se u valore hè un caratteru maiuscule ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Verifica se u valore hè un caratteru minuscule ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Verifica se u valore hè un caratteru alfanumericu ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', o
    /// - U + 0061 'a' ..=U + 007A 'z', o
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Verifica se u valore hè una cifra decimale ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Verifica se u valore hè un cifru esadecimale ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', o
    /// - U + 0041 'A' ..=U + 0046 'F', o
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Verifica se u valore hè un caratteru di puntuazione ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, o
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, o
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, o
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Verifica se u valore hè un caratteru graficu ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Verifica se u valore hè un caratteru di spaziu biancu ASCII:
    /// U + 0020 SPACE, U + 0009 TAB ORIZZONTALE, U + 000A ALIMENTAZIONE LINE, U + 000C FORM FEED, o U + 000D RITORNU CARRIAGE.
    ///
    /// Rust utilizza u [definition of ASCII whitespace][infra-aw] di WhatWG Infra Standard.Ci sò parechje altre definizioni in usu largu.
    /// Per esempiu, [the POSIX locale][pct] include U + 000B TAB VERTICAL è ancu tutti i caratteri sopra, ma-da a stessa specifica-[a regula predefinita per "field splitting" in u Bourne shell][bfs] cunsidereghja *solu* SPAZIU, TAB ORIZZONTALE, è LINE FEED cum'è spaziu biancu.
    ///
    ///
    /// Se state scrivendu un prugramma chì tratterà un furmatu di fugliale esistente, verificate ciò chì hè a definizione di quellu spaziu di u spaziu biancu prima di aduprà sta funzione.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Verifica se u valore hè un caratteru di cuntrollu ASCII:
    /// U + 0000 NUL ..=U + 001F SEPARATORE UNITÀ, o U + 007F ELIMINA.
    /// Nutate bè chì a maiò parte di i caratteri in spaziu ASCII sò caratteri di cuntrollu, ma SPACE ùn hè micca.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Codifica un valore crudu u32 cum'è UTF-8 in u buffer byte furnitu, è poi restituisce a sottuslice di u buffer chì cuntene u caratteru codificatu.
///
///
/// A differenza di `char::encode_utf8`, stu metudu gestisce ancu i punti di codici in a gamma surrogata.
/// (A creazione di un `char` in l'intervalu di sustitutu hè UB.) U risultatu hè [generalized UTF-8] validu ma micca UTF-8 validu.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics se u buffer ùn hè micca abbastanza grande.
/// Un buffer di lunghezza quattru hè abbastanza grande per codificà qualsiasi `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Codifica un valore crudu u32 cum'è UTF-16 in u buffer `u16` furnitu, è poi restituisce a sottuslice di u buffer chì cuntene u caratteru codificatu.
///
///
/// A differenza di `char::encode_utf16`, stu metudu gestisce ancu i punti di codici in a gamma surrogata.
/// (A creazione di un `char` in a gamma surrogata hè UB.)
///
/// # Panics
///
/// Panics se u buffer ùn hè micca abbastanza grande.
/// Un buffer di lunghezza 2 hè abbastanza grande per codificà qualsiasi `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SICUREZZA: ogni bracciu verifica s'ellu ci hè abbastanza pezzi per scrive
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // U BMP casca
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Aerei supplementari si rompenu in surrogati.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}