#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Espande à `$crate::panic::panic_2015` o `$crate::panic::panic_2021` secondu l'edizione di u chjamante.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Afferma chì duie espressioni sò uguali l'una à l'altra (aduprendu [`PartialEq`]).
///
/// In panic, sta macro stamperà i valori di l'espressioni cù e so rapprisentazioni di debug.
///
///
/// Cum'è [`assert!`], sta macro hà una seconda forma, induve un messagiu panic persunalizatu pò esse furnitu.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // I rimborsi quì sottu sò intenzionali.
                    // Senza elli, u slot di stack per u prestitu hè inizializatu ancu prima chì i valori sò paragunati, purtendu à un rallentamentu notevule.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // I rimborsi quì sottu sò intenzionali.
                    // Senza elli, u slot di stack per u prestitu hè inizializatu ancu prima chì i valori sò paragunati, purtendu à un rallentamentu notevule.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afferma chì duie espressioni ùn sò micca uguali tra di elle (aduprendu [`PartialEq`]).
///
/// In panic, sta macro stamperà i valori di l'espressioni cù e so rapprisentazioni di debug.
///
///
/// Cum'è [`assert!`], sta macro hà una seconda forma, induve un messagiu panic persunalizatu pò esse furnitu.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // I rimborsi quì sottu sò intenzionali.
                    // Senza elli, u slot di stack per u prestitu hè inizializatu ancu prima chì i valori sò paragunati, purtendu à un rallentamentu notevule.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // I rimborsi quì sottu sò intenzionali.
                    // Senza elli, u slot di stack per u prestitu hè inizializatu ancu prima chì i valori sò paragunati, purtendu à un rallentamentu notevule.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afferma chì una espressione booleana hè `true` in runtime.
///
/// Questu invucerà a macro [`panic!`] se l'espressione furnita ùn pò micca esse valutata à `true` in runtime.
///
/// Cum'è [`assert!`], sta macro hà ancu una seconda versione, induve un messagiu panic persunalizatu pò esse furnitu.
///
/// # Uses
///
/// A diversità di [`assert!`], e dichjarazioni `debug_assert!` sò attivate solu in builds micca ottimizzati per difettu.
/// Una custruzzione ottimizzata ùn eseguisce micca dichjarazioni `debug_assert!` a menu chì `-C debug-assertions` sia passatu à u compilatore.
/// Questu face `debug_assert!` utile per i cuntrolli chì sò troppu costosi per esse prisenti in una versione di versione ma ponu esse utili durante u sviluppu.
/// U risultatu di l'espansione `debug_assert!` hè sempre verificatu tippu.
///
/// Un'affirmazione senza cuntrollu permette à un prugramma in un statu incoerente di continuà à girà, ciò chì puderebbe avè cunsequenze inaspettate ma ùn introduce micca periculu fintantu chì questu accade solu in codice sicuru.
///
/// U costu di prestazione di l'affirmazioni, tuttavia, ùn hè micca misurabile in generale.
/// Rimpiazzà [`assert!`] cù `debug_assert!` hè dunque incuragitu solu dopu una prufilazione approfondita, è più impurtante, solu in codice sicuru!
///
/// # Examples
///
/// ```
/// // u missaghju panic per queste affirmazioni hè u valore stringificatu di l'espressione data.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // una funzione assai simplice
/// debug_assert!(some_expensive_computation());
///
/// // affirmà cù un missaghju persunalizatu
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Afferma chì duie spressioni sò uguali trà di elle.
///
/// In panic, sta macro stamperà i valori di l'espressioni cù e so rapprisentazioni di debug.
///
/// A diversità di [`assert_eq!`], e dichjarazioni `debug_assert_eq!` sò attivate solu in builds micca ottimizzati per difettu.
/// Una custruzzione ottimizzata ùn eseguisce micca dichjarazioni `debug_assert_eq!` a menu chì `-C debug-assertions` sia passatu à u compilatore.
/// Questu face `debug_assert_eq!` utile per i cuntrolli chì sò troppu costosi per esse prisenti in una versione di versione ma ponu esse utili durante u sviluppu.
///
/// U risultatu di l'espansione `debug_assert_eq!` hè sempre verificatu tippu.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Afferma chì duie spressioni ùn sò micca uguali trà elle.
///
/// In panic, sta macro stamperà i valori di l'espressioni cù e so rapprisentazioni di debug.
///
/// A diversità di [`assert_ne!`], e dichjarazioni `debug_assert_ne!` sò attivate solu in builds micca ottimizzati per difettu.
/// Una custruzzione ottimizzata ùn eseguisce micca dichjarazioni `debug_assert_ne!` a menu chì `-C debug-assertions` sia passatu à u compilatore.
/// Questu face `debug_assert_ne!` utile per i cuntrolli chì sò troppu costosi per esse prisenti in una versione di versione ma ponu esse utili durante u sviluppu.
///
/// U risultatu di l'espansione `debug_assert_ne!` hè sempre verificatu tippu.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Restituisce sì l'espressione data currisponde à qualsiasi di i mudelli dati.
///
/// Cum'è in una espressione `match`, u mudellu pò esse seguitu opzionalmente da `if` è una espressione di guardia chì hà accessu à nomi ligati da u mudellu.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Scopre un risultatu o propaga u so errore.
///
/// L'operatore `?` hè statu aghjuntu per rimpiazzà `try!` è deve esse adupratu invece.
/// Inoltre, `try` hè una parolla riservata in Rust 2018, allora se duvete aduprà, duverete aduprà [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` currisponde à u [`Result`] datu.In casu di a variante `Ok`, l'espressione hà u valore di u valore imballatu.
///
/// In casu di a variante `Err`, recupera l'errore internu.`try!` poi esegue a cunversione aduprendu `From`.
/// Questu furnisce una cunversione automatica trà errori specializati è più generali.
/// L'errore resultante hè allora immediatamente restituitu.
///
/// A causa di u primu ritornu, `try!` pò esse adupratu solu in funzioni chì restituiscenu [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // U metudu preferitu di Errori di ritornu rapidu
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // U metudu precedente di Errori di ritornu rapidu
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Questu hè equivalente à:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Scrive dati furmattati in un buffer.
///
/// Questa macro accetta un 'writer', una stringa di furmatu, è un elencu d'argumenti.
/// L'argumenti saranu furmattati secondu a stringa di furmatu specificata è u risultatu serà trasmessu à u scrittore.
/// U scrittore pò esse qualsiasi valore cù un metudu `write_fmt`;in generale questu vene da una implementazione sia di u [`fmt::Write`] sia di u [`io::Write`] trait.
/// A macro torna ciò chì u metudu `write_fmt` rende;comunemente un [`fmt::Result`], o un [`io::Result`].
///
/// Vede [`std::fmt`] per più infurmazione nantu à a sintassi di stringa di furmatu.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Un modulu pò impurtà tramindui `std::fmt::Write` è `std::io::Write` è chjamà `write!` nantu à l'uggetti chì implementanu sia, chì l'oggetti ùn implementanu micca tipicamente entrambi.
///
/// Tuttavia, u modulu deve importà u traits qualificatu per chì i so nomi ùn sianu micca in conflittu:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // usa fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // usa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Questa macro pò esse usata ancu in configurazioni `no_std`.
/// In una installazione `no_std` site rispunsevule per i dettagli di implementazione di i cumpunenti.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Scrive dati furmattati in un buffer, cù una nova linea aghjunta.
///
/// In tutte e piattaforme, a nova linea hè u caratteru LINE FEED (`\n`/`U+000A`) solu (senza RITORNU DI CARRURA addizionale (`\r`/`U+000D`).
///
/// Per più infurmazione, vedi [`write!`].Per infurmazione nantu à a sintassi di a stringa di furmatu, vede [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Un modulu pò impurtà tramindui `std::fmt::Write` è `std::io::Write` è chjamà `write!` nantu à l'uggetti chì implementanu sia, chì l'oggetti ùn implementanu micca tipicamente entrambi.
/// Tuttavia, u modulu deve importà u traits qualificatu per chì i so nomi ùn sianu micca in conflittu:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // usa fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // usa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Indica un codice inaccessibile.
///
/// Questu hè utile ogni volta chì u compilatore ùn pò micca determinà chì qualchì codice ùn sia micca ghjunghje.Per esempiu:
///
/// * Assucià e bracce cù e cundizioni di guardia.
/// * Cicli chì finiscenu dinamicamente.
/// * Iteratori chì finiscenu dinamicamente.
///
/// Se a determinazione chì u codice hè inaccessibile si dimostra sbagliata, u prugramma finisce subitu cù un [`panic!`].
///
/// A contraparte periculosa di sta macro hè a funzione [`unreachable_unchecked`], chì pruvucarà un cumpurtamentu indefinitu se u codice hè ghjuntu.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Questu serà sempre [`panic!`].
///
/// # Examples
///
/// Arme di partita:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // compile errore se cummentatu
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // una di e più povere implementazioni di x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Indica un codice micca implementatu in panicu cù un missaghju di "not implemented".
///
/// Questu permette à u vostru còdice di verificà u tippu, chì hè utile se site prototipu o implementate un trait chì richiede più metodi chì ùn avete micca pensatu di aduprà tuttu.
///
/// A differenza trà `unimplemented!` è [`todo!`] hè chì mentre `todo!` trasmette l'intenzione di implementà a funzionalità più tardi è u messaghju hè "not yet implemented", `unimplemented!` ùn face micca tali rivendicazioni.
/// U so messagiu hè "not implemented".
/// Ancu qualchì IDE marcarà `todo!` S.
///
/// # Panics
///
/// Questu serà sempre [`panic!`] perchè `unimplemented!` hè solu una stenografia per `panic!` cun un missaghju fissu, specificu.
///
/// Cum'è `panic!`, sta macro hà una seconda forma per vede valori persunalizati.
///
/// # Examples
///
/// Dicemu chì avemu un trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Vulemu implementà `Foo` per 'MyStruct', ma per qualchì ragione ùn hè sensu solu per implementà a funzione `bar()`.
/// `baz()` è `qux()` duveranu sempre esse definiti in a nostra implementazione di `Foo`, ma pudemu aduprà `unimplemented!` in e so definizioni per permette à u nostru còdice di compilà.
///
/// Vulemu sempre chì u nostru prugramma smetti di girà si i metudi micca implementati sò ghjunti.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Ùn hà sensu per `baz` un `MyStruct`, allora ùn avemu alcuna logica quì.
/////
///         // Questu mostrarà "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Avemu qualchì logica quì, Pudemu aghjunghje un missaghju à unimplemented!per vede a nostra omissione.
///         // Questu mostrarà: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Indica un codice micca finitu.
///
/// Questu pò esse utile se site prototipu è cercate solu avè u vostru tipecheck di codice.
///
/// A differenza trà [`unimplemented!`] è `todo!` hè chì mentre `todo!` trasmette l'intenzione di implementà a funzionalità più tardi è u messaghju hè "not yet implemented", `unimplemented!` ùn face micca tali rivendicazioni.
/// U so messagiu hè "not implemented".
/// Ancu qualchì IDE marcarà `todo!` S.
///
/// # Panics
///
/// Questu serà sempre [`panic!`].
///
/// # Examples
///
/// Eccu un esempiu di qualchì codice in corsu.Avemu un trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Vulemu implementà `Foo` nantu à unu di i nostri tippi, ma vulemu ancu travaglià solu nantu à `bar()`.Per u nostru codice per compilà, avemu bisognu di implementà `baz()`, cusì pudemu aduprà `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // l'implementazione va quì
///     }
///
///     fn baz(&self) {
///         // ùn v'inchietemu micca per l'implementazione di baz() per avà
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ùn simu mancu aduprendu baz(), allora va bè.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definizione di macro integrate.
///
/// A maiò parte di e pruprietà macro (stabilità, visibilità, ecc.) Sò presi da u codice surghjente quì, eccettu e funzioni di espansione chì trasformanu l'ingressi macro in output, quelle funzioni sò furnite da u compilatore.
///
///
pub(crate) mod builtin {

    /// Fà chì a compilazione fiaschi cù u messaghju d'errore datu quandu si trova.
    ///
    /// Questa macro deve esse aduprata quandu un crate utilizza una strategia di compilazione cundizionale per furnisce megliu messaggi d'errore per cundizioni erronee.
    ///
    /// Hè a forma à livellu di compilatore di [`panic!`], ma emette un errore durante a *compilazione* piuttostu chè à u *runtime*.
    ///
    /// # Examples
    ///
    /// Dui tali esempi sò macros è ambienti `#[cfg]`.
    ///
    /// Emettite un errore di compilatore megliu se una macro hè passata valori invalidi.
    /// Senza u branch finale, u compilatore emette sempre un errore, ma u missaghju di l'errore ùn menzionerebbe micca i dui valori validi.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emettite errore di compilatore se una di una serie di funzioni ùn hè micca dispunibile.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Custruisce parametri per l'altre macro di furmatu di stringa.
    ///
    /// Questa macro funziona pigliendu una stringa di formattazione litterale chì cuntene `{}` per ogni argumentu supplementu passatu.
    /// `format_args!` prepara i parametri addiziunali per assicurà chì l'output pò esse interpretatu cum'è una stringa è canonicalizza l'argumenti in un unicu tippu.
    /// Ogni valore chì implementa u [`Display`] trait pò esse passatu à `format_args!`, cume qualsiasi implementazione [`Debug`] pò esse passata à un `{:?}` in a stringa di furmatu.
    ///
    ///
    /// Questa macro produce un valore di tippu [`fmt::Arguments`].Stu valore pò esse passatu à e macros in [`std::fmt`] per eseguisce una redirezione utile.
    /// Tutte l'altre macro di furmatu ([`format!`], [`write!`], [`println!`], ecc.) Sò proxy attraversu questu.
    /// `format_args!`, à u cuntrariu di e so macro derivate, evita l'allocazioni di cumuli.
    ///
    /// Pudete utilizà u valore [`fmt::Arguments`] chì `format_args!` rende in cuntesti `Debug` è `Display` cum'è vistu sottu.
    /// L'esempiu mostra ancu chì u formatu `Debug` è `Display` à listessa cosa: a stringa di furmatu interpolata in `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Per più infurmazione, vedi a ducumentazione in [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Listessu cum'è `format_args`, ma aghjusta una nova linea à a fine.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Ispeziona una variabile d'ambiente in tempu di compilazione.
    ///
    /// Questa macro si espanderà à u valore di a variabile d'ambiente chjamata in tempu di compilazione, dendu una espressione di tippu `&'static str`.
    ///
    ///
    /// Se a variabile d'ambiente ùn hè micca definita, allora un errore di compilazione serà emessu.
    /// Per ùn emette un errore di compilazione, utilizate invece a macro [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Pudete persunalizà u missaghju d'errore passendu una stringa cum'è secondu paràmetru:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Se a variabile d'ambiente `documentation` ùn hè micca definita, riceverete u seguente errore:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Opcionalmente inspecciona una variabile d'ambiente in tempu di compilazione.
    ///
    /// Se a variabile d'ambiente chjamata hè presente in tempu di compilazione, questu si espanderà in una espressione di tipu `Option<&'static str>` chì u valore hè `Some` di u valore di a variabile d'ambiente.
    /// Se a variabile d'ambiente ùn hè micca presente, allora questu si espanderà à `None`.
    /// Vede [`Option<T>`][Option] per più infurmazione nantu à stu tipu.
    ///
    /// Un errore di tempu di compilazione ùn hè mai emessu quandu si usa sta macro indipendentemente da se a variabile d'ambiente hè presente o micca.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenate identificatori in un identificatore.
    ///
    /// Questa macro piglia un numeru numeru d'identificatori separati da virgole, è li concatena tutti in unu, dendu una spressione chì hè un novu identificatore.
    /// Innota chì l'igiene li rende tali chì sta macro ùn pò micca catturà variabili lucali.
    /// Inoltre, di regula generale, e macro sò permesse solu in pusizione di articulu, dichjarazione o spressione.
    /// Ciò significa chì mentre pudete aduprà sta macro per riferisce à variabili esistenti, funzioni o moduli ecc, ùn pudete micca definisce una nova cun ella.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (novu, divertente, nome) { }//micca aduprèvule in questu modu!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenate letterali in una fetta di stringa statica.
    ///
    /// Questa macro piglia un numeru di letterali separati da virgole, dendu una espressione di tippu `&'static str` chì raprisenta tutti i letterali concatenati da sinistra a destra.
    ///
    ///
    /// Litturali interi è à virgola flottante sò stringati per esse cuncatenati.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Si allarga à u numeru di linea chì hè statu invucatu.
    ///
    /// Cù [`column!`] è [`file!`], queste macro furniscenu informazioni di debugging per i sviluppatori nantu à a situazione in a fonte.
    ///
    /// L'espressione espansa hà u tippu `u32` è hè basata in 1, dunque a prima linea in ogni schedariu valuta à 1, a seconda à 2, ecc.
    /// Questu hè coherente cù i missaghji di errore da compilatori cumuni o editori populari.
    /// A linea restituita hè *micca necessariamente* a linea di l'invucazione `line!` stessa, ma piuttostu a prima invucazione macro chì porta à l'invucazione di a macro `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Si espande à u numeru di colonna induve hè statu invucatu.
    ///
    /// Cù [`line!`] è [`file!`], queste macro furniscenu informazioni di debugging per i sviluppatori nantu à a situazione in a fonte.
    ///
    /// L'espressione espansa hà u tippu `u32` è hè basata in 1, dunque a prima colonna in ogni linea valuta à 1, a seconda à 2, ecc.
    /// Questu hè coherente cù i missaghji di errore da compilatori cumuni o editori populari.
    /// A colonna restituita hè *micca necessariamente* a linea di l'invucazione `column!` stessa, ma piuttostu a prima invucazione macro chì porta à l'invucazione di a macro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Espande à u nome di u fugliale in u quale hè statu invucatu.
    ///
    /// Cù [`line!`] è [`column!`], queste macro furniscenu informazioni di debugging per i sviluppatori nantu à a situazione in a fonte.
    ///
    /// L'espressione espansa hà u tippu `&'static str`, è u fugliale restituitu ùn hè micca l'invucazione di a macro `file!` stessa, ma piuttostu a prima invucazione macro chì porta à l'invucazione di a macro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifica i so argumenti.
    ///
    /// Questa macro darà una espressione di tipu `&'static str` chì hè a stringificazione di tutti i tokens passati à a macro.
    /// Nisuna restrizione hè posta nantu à a sintassi di l'invucazione macro stessa.
    ///
    /// Nota chì i risultati espansi di l'input tokens ponu cambià in u future.Duvete esse attenti se vi basate nantu à u risultatu.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Include un file codificatu UTF-8 cum'è stringa.
    ///
    /// U fugliale hè situatu relative à u fugliale attuale (in modu simile à cumu si trovanu i moduli).
    /// U percorsu furnitu hè interpretatu in una manera specifica di piattaforma in tempu di compilazione.
    /// Cusì, per esempiu, una invucazione cù un percorsu Windows chì cuntene contraserrature `\` ùn si compilarà currettamente in Unix.
    ///
    ///
    /// Questa macro darà una espressione di tipu `&'static str` chì hè u cuntenutu di u fugliale.
    ///
    /// # Examples
    ///
    /// Assumemu chì ci sò dui fugliali in u listessu repertoriu cù u cuntenutu seguente:
    ///
    /// Schedariu 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Schedariu 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Cumpigliate 'main.rs' è eseguite u binariu resultante stamperà "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Include un fugliale cum'è riferimentu à una matrice di byte.
    ///
    /// U fugliale hè situatu relative à u fugliale attuale (in modu simile à cumu si trovanu i moduli).
    /// U percorsu furnitu hè interpretatu in una manera specifica di piattaforma in tempu di compilazione.
    /// Cusì, per esempiu, una invucazione cù un percorsu Windows chì cuntene contraserrature `\` ùn si compilarà currettamente in Unix.
    ///
    ///
    /// Questa macro darà una espressione di tipu `&'static [u8; N]` chì hè u cuntenutu di u fugliale.
    ///
    /// # Examples
    ///
    /// Assumemu chì ci sò dui fugliali in u listessu repertoriu cù u cuntenutu seguente:
    ///
    /// Schedariu 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Schedariu 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Cumpigliate 'main.rs' è eseguite u binariu resultante stamperà "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Espande à una stringa chì rapprisenta u percorsu di u modulu attuale.
    ///
    /// U percorsu di u modulu attuale pò esse pensatu cum'è a ierarchia di i moduli chì cunducenu a riserva à u crate root.
    /// U primu cumpunente di u percorsu restituitu hè u nome di u crate attualmente compilatu.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Valuta cumbinazioni booleani di bandiere di cunfigurazione in tempu di compilazione.
    ///
    /// In più di l'attributu `#[cfg]`, sta macro hè furnita per permette a valutazione di espressione booleana di bandiere di cunfigurazione.
    /// Questu porta spessu à un codice menu duplicatu.
    ///
    /// A sintassi data à sta macro hè a stessa sintassi di l'attributu [`cfg`].
    ///
    /// `cfg!`, à u cuntrariu di `#[cfg]`, ùn elimina alcun codice è valuta solu à veru o falsu.
    /// Per esempiu, tutti i blocchi in una espressione if/else anu da esse validi quandu `cfg!` hè adupratu per a cundizione, indipendentemente da ciò chì `cfg!` sta valutendu.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analizza un fugliale cum'è una espressione o un articulu secondu u cuntestu.
    ///
    /// U fugliale hè situatu relative à u fugliale attuale (in modu simile à cumu si trovanu i moduli).U percorsu furnitu hè interpretatu in una manera specifica di piattaforma in tempu di compilazione.
    /// Cusì, per esempiu, una invucazione cù un percorsu Windows chì cuntene contraserrature `\` ùn si compilarà currettamente in Unix.
    ///
    /// Aduprà sta macro hè spessu una gattiva idea, perchè se u fugliale hè analizatu cum'è una spressione, serà messu in u codice circundante senza igiene.
    /// Questa puderia risultà chì e variabili o funzioni sianu sfarenti di ciò chì u schedariu aspetta s'ellu ci sò variabili o funzioni chì anu u listessu nome in u fugliale attuale.
    ///
    ///
    /// # Examples
    ///
    /// Assumemu chì ci sò dui fugliali in u listessu repertoriu cù u cuntenutu seguente:
    ///
    /// Schedariu 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Schedariu 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Cumpigliate 'main.rs' è eseguite u binariu resultante stamperà "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Afferma chì una espressione booleana hè `true` in runtime.
    ///
    /// Questu invucerà a macro [`panic!`] se l'espressione furnita ùn pò micca esse valutata à `true` in runtime.
    ///
    /// # Uses
    ///
    /// L'asserzioni sò sempre verificate sia in debug sia in release build, è ùn ponu micca esse disattivati.
    /// Vede [`debug_assert!`] per l'affirmazioni chì ùn sò micca attivate in versione di versione per difettu.
    ///
    /// Un codice periculosu pò cuntà nantu à `assert!` per rinfurzà invarianti in esecuzione chì, se viulati puderebbenu purtà à securità.
    ///
    /// Altri casi d'usu di `assert!` includenu a prova è l'applicazione di invarianti in esecuzione in codice sicuru (chì a so violazione ùn pò micca risultà in periculu).
    ///
    ///
    /// # Missaghji Customizati
    ///
    /// Questa macro hà una seconda forma, induve un messagiu panic persunalizatu pò esse furnitu cù o senza argumenti per furmà.
    /// Vede [`std::fmt`] per sintassi per sta forma.
    /// E spressioni aduprate cum'è argumenti di furmatu seranu valutate solu se l'affirmazione fiasca.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // u missaghju panic per queste affirmazioni hè u valore stringificatu di l'espressione data.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // una funzione assai simplice
    ///
    /// assert!(some_computation());
    ///
    /// // affirmà cù un missaghju persunalizatu
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Assemblea in linea.
    ///
    /// Leghjite u [unstable book] per l'usu.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Assemblea in linea in stile LLVM.
    ///
    /// Leghjite u [unstable book] per l'usu.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Assemblea in linea à livellu di modulu.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Stampa passava tokens in a pruduzzioni standard.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Abilita o disabilita a funzionalità di tracciatura aduprata per u debug di altre macro.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Macro d'attributu adupratu per applicà macre derivate.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Macro attributu applicatu à una funzione per trasformallu in un test unitariu.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Atributu macro applicatu à una funzione per trasformallu in un test di benchmark.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Un dettagliu di implementazione di e macros `#[test]` è `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Attributu macro applicatu à una statica per registrallu cum'è allocatore globale.
    ///
    /// Vede ancu [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Mantene l'articulu à u quale hè applicatu se u percorsu passatu hè accessibile, è u rimuove altrimenti.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Espande tutti l'attributi `#[cfg]` è `#[cfg_attr]` in u fragmentu di codice à quale hè appiicatu.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Dettaglio di implementazione instabile di u compilatore `rustc`, ùn aduprate micca.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Dettaglio di implementazione instabile di u compilatore `rustc`, ùn aduprate micca.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}