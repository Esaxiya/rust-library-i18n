Panics u filu attuale.

Questu permette à un prugramma di finisce immediatamente è di furnisce feedback à u chjamante di u prugramma.
`panic!` duveria esse adupratu quandu un prugramma ghjunghje à un statu irrecuperabile.

Questa macro hè u modu perfettu per affirmà e cundizioni in l'esempiu di codice è in i testi.
`panic!` hè strettamente ligatu cù u metudu `unwrap` di e duie enumerazioni [`Option`][ounwrap] è [`Result`][runwrap].
Entrambe l'implementazioni chjamanu `panic!` quandu sò impostate à varianti [`None`] o [`Err`].

Quandu si usa `panic!()` pudete specificà una stringa di carica utile, chì hè custruita aduprendu a sintassi [`format!`].
Questa carica utile hè aduprata quandu si injecta u panic in u filu Rust chì chjama, causendu u filu à panic interamente.

U cumpurtamentu di u `std` hook predefinitu, ie
u codice chì corre direttamente dopu chì u panic hè invucatu, hè di stampà a carica utile di u messaghju à `stderr` cù l'infurmazioni file/line/column di a chjamata `panic!()`.

Pudete annullà u panic hook cù [`std::panic::set_hook()`].
Dentru u hook un panic pò esse accessu cum'è `&dyn Any + Send`, chì cuntene un `&str` o `String` per invucazioni regulari `panic!()`.
Per panic cun un valore di un altru tipu, [`panic_any`] pò esse adupratu.

[`Result`] enum hè spessu una soluzione migliore per recuperà da errori ch'è aduprà a macro `panic!`.
Questa macro deve esse aduprata per evità di procedere aduprendu valori sbagliati, cume da fonti esterne.
Informazioni dettagliate nantu à a gestione di l'errori si trovanu in [book].

Vede ancu a macro [`compile_error!`], per elevà errori durante a compilazione.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Implementazione attuale

Se u filu principale panics finirà tutti i vostri fili è finirà u vostru prugramma cù u codice `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





