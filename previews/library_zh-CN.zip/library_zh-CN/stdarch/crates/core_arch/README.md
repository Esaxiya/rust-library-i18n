`core::arch` - Rust 的核心库体系结构特定的内在函数
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` 模块实现了与体系结构相关的内在函数 (例如 SIMD)。

# Usage 

`core::arch` 可作为 `libcore` 的一部分获得，并由 `libstd` 重新导出。与通过此 crate 相比，更喜欢通过 `core::arch` 或 `std::arch` 使用它。
不稳定的特性通常可通过 `feature(stdsimd)` 在每晚的 Rust 中获得。

通过此 crate 使用 `core::arch` 需要每晚执行 Rust，并且它可能 (并且确实) 经常中断。您应该考虑通过此 crate 使用它的唯一情况是:

* 如果您需要自己重新编译 `core::arch`，例如，启用了 `libcore`/`libstd` 未启用的特定目标功能。
Note: 如果您需要针对非标准目标重新编译它，请优先使用 `xargo` 并根据需要重新编译 `libcore`/`libstd`，而不要使用此 crate。
  
* 使用某些即使在不稳定的 Rust 功能之后也可能无法使用的功能。我们尝试将这些限制降至最低。
如果您需要使用其中一些功能，请打开一个问题，以便我们可以在每晚的 Rust 中公开它们，然后从那里开始使用它们。

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` 主要根据 MIT 许可证和 Apache 许可证 (版本 2.0) 的条款进行分发，部分内容由各种类似 BSD 的许可证涵盖。

有关详细信息，请参见 LICENSE-APACHE 和 LICENSE-MIT。

# Contribution

除非您明确声明，否则 Apache-2.0 许可中定义的由您有意提交以供包含在 `core_arch` 中的任何贡献均应按照上述双重许可方式使用，没有任何其他条款或条件。


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












