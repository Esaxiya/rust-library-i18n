#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// 请参阅 [`prefetch`](fn._prefetch.html)。
pub const _PREFETCH_READ: i32 = 0;

/// 请参阅 [`prefetch`](fn._prefetch.html)。
pub const _PREFETCH_WRITE: i32 = 1;

/// 请参阅 [`prefetch`](fn._prefetch.html)。
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// 请参阅 [`prefetch`](fn._prefetch.html)。
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// 请参阅 [`prefetch`](fn._prefetch.html)。
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// 请参阅 [`prefetch`](fn._prefetch.html)。
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// 使用给定的 `rw` 和 `locality` 获取包含地址 `p` 的缓存行。
///
/// `rw` 必须是以下之一:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): 预取正在准备读取。
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): 预取正在准备写操作。
///
/// `locality` 必须是以下之一:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): 流或非时间预取，用于仅使用一次的数据。
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): 提取到 3 级缓存中。
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): 提取到 2 级缓存中。
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): 提取到 1 级缓存中。
///
/// 预取存储器指令向存储器系统发送信号，表明从指定地址进行的存储器访问可能发生在 future 附近。
/// 内存系统可以通过采取预期会加快内存访问速度的操作来做出响应，例如将指定的地址预加载到一个或多个高速缓存中。
///
/// 因为这些信号只是提示，所以对于特定的 CPU，将任何或所有预取指令视为 NOP 是有效的。
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // 我们将 `llvm.prefetch` 内部使用 `cache type` =1 (数据缓存)。
    // `rw` 和 `strategy` 基于函数参数。
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}