# 为 stdarch 做贡献

`stdarch` crate 乐于接受捐款! 首先，您可能需要切换到仓库，并确保测试通过:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

其中 `<your-target-arch>` 是 `rustup` 使用的目标三元组，例如 `x86_x64-unknown-linux-gnu` (没有任何先前的 `nightly-` 或类似物)。
还请记住，该仓库需要 Rust 的每晚通道!
实际上，以上测试确实要求将每晚的 rust 设置为系统上的默认设置，以使用 `rustup default nightly` (和 `rustup default stable` 进行还原) 进行设置。

如果以上任何步骤都不起作用， [please let us know][new]!

接下来，您可以使用 [find an issue][issues] 进行帮助，我们选择了一些带有 [`help wanted`][help] 和 [`impl-period`][impl] 标签的标签，这些标签可能特别有用。
您可能对 [#40][vendor] 最感兴趣，并在 x86 上实现了所有供应商内在函数。这个问题对于从哪里开始有一些很好的指示!

如果您有一般性问题，请随时向 [join us on gitter][gitter] 询问! 如有问题，请随时 ping@BurntSushi 或 @alexcrichton。

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# 如何为 stdarch 内部函数编写示例

为了使给定的内在函数正常工作，必须启用一些功能，并且该示例仅在 CPU 支持该功能时才可以由 `cargo test --doc` 运行。

结果，`rustdoc` 生成的默认 `fn main` 将不起作用 (在大多数情况下)。
考虑使用以下内容作为指导，以确保您的示例按预期工作。

```rust
/// # // 我们需要 cfg_target_feature 以确保该示例仅为
/// # // 当 CPU 支持该功能时，由 `cargo test --doc` 运行
/// # #![feature(cfg_target_feature)]
/// # // 我们需要 target_feature 才能使内在函数正常工作
/// # #![feature(target_feature)]
/// #
/// # // rustdoc 默认使用 `extern crate stdarch`，但我们需要
/// # // `#[macro_use]`
/// # #[macro_use] extern crate stdarch;
/// #
/// # // 真正的主要功能
/// # fn main() {
/// #     // 仅在支持 `<target feature>` 时运行此命令
/// #     如果 cfg_feature_enabled! (`<target feature>`) {
/// #         // 创建一个 `worker` 函数，该函数仅在目标功能部件下运行
/// #         // 受支持，并确保为您的工作人员启用了 `target_feature`
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         不安全的 fn worker() {
/// // 在此处写下您的示例。功能特定的内在函数将在这里起作用! 去野外!
///
/// #         }
///
/// #         不安全的 { worker(); }
/// #     }
/// # }
```

如果上述某些语法看起来不太熟悉，则 [Rust Book] 的 [Documentation as tests] 部分将很好地描述 `rustdoc` 语法。
与往常一样，请随时使用 [join us on gitter][gitter]，并询问我们是否遇到任何障碍，并感谢您帮助改善 `stdarch` 的文档!

# 替代测试说明

通常建议您使用 `ci/run.sh` 来运行测试。
但是，这可能对您不起作用，例如，如果您使用的是 Windows。

在这种情况下，您可以回头运行 `cargo +nightly test` 和 `cargo +nightly test --release -p core_arch` 来测试代码生成。
请注意，这些要求每夜安装一次工具链，并且 `rustc` 才能了解目标三元组及其 CPU。
特别是，您需要像设置 `ci/run.sh` 一样设置 `TARGET` 环境变量。
另外，您需要设置 `RUSTCFLAGS` (需要 `C`) 以指示目标功能，例如 `RUSTCFLAGS="-C -target-features=+avx2"`.
如果您正在针对当前的 CPU 开发 "just"，也可以设置 `-C -target-cpu=native`。

请注意，当您使用这些替代说明时，例如 [things may go less smoothly than they would with `ci/run.sh`][ci-run-good]
指令生成测试可能会失败，因为反汇编程序对它们的命名不同，例如
尽管它们的行为相同，但它可能会生成 `vaesenc` 而不是 `aesenc` 指令。
同样，这些指令执行的测试少于通常执行的测试，因此当您最终请求请求时，对于此处未涵盖的测试，可能会出现一些错误，请不要感到惊讶。

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






