/// 一个迭代器，用完后总是继续产生 `None`。
///
/// 确保一次返回 `None` 的融合迭代器上的 next 调用保证再次返回 [`None`]。
/// 该 trait 应该由以此方式运行的所有迭代器实现，因为它允许优化 [`Iterator::fuse()`]。
///
///
/// Note: 通常，如果需要融合的迭代器，则不应在泛型范围内使用 `FusedIterator`。
/// 相反，您应该只在迭代器上调用 [`Iterator::fuse()`]。
/// 如果迭代器已经融合，则额外的 [`Fuse`] 包装器将是无操作的，并且不会降低性能。
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// 一个使用 size_hint 报告准确长度的迭代器。
///
/// 迭代器报告一个大小提示，该提示是精确的 (下限等于上限)，或者上限是 [`None`]。
///
/// 如果实际的迭代器长度大于 [`usize::MAX`]，则上限必须仅为 [`None`]。
/// 在这种情况下，下限必须为 [`usize::MAX`]，从而导致 [`Iterator::size_hint()`] 为 `(usize::MAX, None)`。
///
/// 迭代器必须精确地生成它所报告或发散的元素数量，然后才能结束。
///
/// # Safety
///
/// trait 必须仅在遵守合同的情况下实现。
/// trait 的使用者必须检查 [`Iterator::size_hint()`]’s 上限。
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// 一个迭代器，当产生一个项时，它将从其基础 [`SourceIter`] 中获取至少一个元素。
///
/// 调用任何推进迭代器的方法，例如
/// [`next()`] [`try_fold()`] 或 [`try_fold()`]，可确保对于每一步，迭代器的基础源的至少一个值已移出，并且迭代器链的结果可以插入到其位置，前提是源的结构约束允许这种插入。
///
/// 换句话说，此 trait 表示可以在适当位置收集迭代器管道。
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}