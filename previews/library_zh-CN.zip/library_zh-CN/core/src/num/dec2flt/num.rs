//! 适用于 bignum 的 Utility 函数，不需要过多地理解为方法。

// FIXME 这个模块的名称有点不幸，因为其他模块也导入 `core::num`。

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// 测试是否将所有不重要于 `ones_place` 的位截断是否引入了小于，等于或大于 0.5 ULP 的相对误差。
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // 如果所有剩余位均为零，则为 = 0.5 ULP，否则 > 0.5 如果没有更多位 (half_bit==0)，则以下内容也将正确返回 Equal。
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// 将仅包含十进制数字的 ASCII 字符串转换为 `u64`。
///
/// 不检查溢出或无效字符，因此，如果调用者不小心，结果将是虚假的，并且可能为 panic (尽管不会是 `unsafe`)。
/// 此外，空字符串被视为零。
/// 之所以存在该函数，是因为
///
/// 1. 在 `&[u8]` 上使用 `FromStr` 需要 `from_utf8_unchecked`，这很糟糕，并且
/// 2. 将 `integral.parse()` 和 `fractional.parse()` 的结果组合在一起比整个函数要复杂得多。
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// 将 ASCII 数字字符串转换为 bignum。
///
/// 像 `from_str_unchecked` 一样，此函数依靠解析器清除非数字。
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// 将 bignum 解包为 64 位整数。Panics 如果数字太大。
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// 提取一定范围的位。

/// 索引 0 是最低有效位，范围照常半开。
/// Panics，如果要求提取超出返回类型的位数。
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}