//! 正向 IEEE 754 浮点数的摆弄。负数不是，也不需要处理。
//! 普通浮点数的规范表示为 (frac，exp)，因此值是 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>))，其中 N 是位数。
//!
//! 次普通法则略有不同和怪异，但适用相同的原理。
//!
//! 但是，在这里，我们将它们表示为 (sig，k)，且 f 为正，因此值为 f *
//! 2 <sup>e</sup>。除了使 "hidden bit" 显式显示之外，这还通过所谓的尾数转换来更改指数。
//!
//! 换句话说，通常将浮点数写为 (1)，但在这里将它们写为 (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! 我们将 (1) 称为 `分数表示`，将 (2) 称为 `积分表示`。
//!
//! 此模块中的许多函数仅处理普通数。对于非常小的数字和非常大的数字，dec2flt 例程保守地采用通用正确的慢路径 (算法 M)。
//! 该算法仅需要 next_float()，即可处理次态和零。
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// 一个帮助程序 trait，可以避免基本上复制 `f32` 和 `f64` 的所有转换代码。
///
/// 有关为什么这样做的必要信息，请参见父模块的文档注释。
///
/// **永远不要** 为其他类型实现或在 dec2flt 模块外部使用。
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` 和 `from_bits` 使用的类型。
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// 执行原始转换为整数。
    fn to_bits(self) -> Self::Bits;

    /// 从整数执行原始转换。
    fn from_bits(v: Self::Bits) -> Self;

    /// 返回此数字所属的类别。
    fn classify(self) -> FpCategory;

    /// 以整数形式返回尾数，指数和符号。
    fn integer_decode(self) -> (u64, i16, i8);

    /// 解码浮点数。
    fn unpack(self) -> Unpacked;

    /// 从可以精确表示的小整数进行转换。
    /// Panic 如果无法表示整数，则此模块中的其他代码确保永不让这种情况发生。
    fn from_int(x: u64) -> Self;

    /// 从预先计算的表中获取值 10 <sup>e</sup>。
    /// `e >= CEIL_LOG5_OF_MAX_SIG` 的 Panics。
    fn short_fast_pow10(e: usize) -> Self;

    /// 名字怎么说。
    /// 硬编码比杂凑内部函数和希望 LLVM 常量将其折叠起来容易。
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // 输入的小数位数的保守界限，不会产生溢出或零或
    /// 次正常。可能是最大值的十进制指数，因此得名。
    const MAX_NORMAL_DIGITS: usize;

    /// 当最高有效十进制数字的位数大于该数值时，该数字肯定会四舍五入为无穷大。
    ///
    const INF_CUTOFF: i64;

    /// 当最高有效十进制数字的位数小于该位数时，该数字肯定会四舍五入为零。
    ///
    const ZERO_CUTOFF: i64;

    /// 指数中的位数。
    const EXP_BITS: u8;

    /// 有效位数的位数，*包括* 隐藏位数。
    const SIG_BITS: u8;

    /// 有效位数的位数，*不包括* 隐藏位。
    const EXPLICIT_SIG_BITS: u8;

    /// 小数表示形式中的最大合法指数。
    const MAX_EXP: i16;

    /// 分数表示法中的最小合法指数，不包括次正规数。
    const MIN_EXP: i16;

    /// `MAX_EXP` 用于积分表示，即应用了移位。
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` 编码 (即具有偏移偏置)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` 用于积分表示，即应用了移位。
    const MIN_EXP_INT: i16;

    /// 整数表示形式中的最大归一化有效位数。
    const MAX_SIG: u64;

    /// 整数表示形式中的最小归一化有效位数。
    const MIN_SIG: u64;
}

// 通常是 #34344 的解决方法。
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// 以整数形式返回尾数，指数和符号。
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // 指数偏差 + 尾数偏移
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe 不确定 `as` 是否在所有平台上都能正确取整。
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// 以整数形式返回尾数，指数和符号。
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // 指数偏差 + 尾数偏移
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe 不确定 `as` 是否在所有平台上都能正确取整。
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// 将 `Fp` 转换为最接近的机器浮点类型。
/// 不处理不正常的结果。
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 是 64 位，因此 xe 的尾数偏移为 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 将 64 位有效位数四舍五入为 T::SIG_BITS 位。
/// 不处理指数溢出。
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // 调整尾数偏移
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// `RawFloat::unpack()` 的倒数，用于归一化的数字。
/// Panics (如果有效位数或指数对于标准化数字无效)。
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // 删除隐藏的位
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // 调整指数以实现指数偏差和尾数偏移
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 在 0 ("+") 处保留符号位，我们的数字均为正
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// 构造一个次正规的。允许尾数为 0 并构造零。
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // 编码指数为 0，符号位为 0，因此我们只需要重新解释这些位即可。
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// 大约有 Fp 的 bignum。在 0.5 ULP 中四舍五入至半数。
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // 我们将索引 `start` 之前的所有位都切除，也就是说，我们实际上右移了 `start`，因此这也是我们需要的指数。
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // 根据截断的位舍入 (half-to-even)。
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// 查找严格小于参数的最大浮点数。
/// 不处理次正规量，零或指数下溢。
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// 找到严格大于参数的最小浮点数。
// 此操作饱和，即 next_float(inf) ==inf。
// 与该模块中的大多数代码不同，此函数确实处理零，次正态和无穷大。
// 但是，像这里的所有其他代码一样，它不处理 NaN 和负数。
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // 这似乎太好了，难以置信，但它确实有效。
        // 0.0 被编码为全零字。次规范为 0x000m ... m，其中 m 为尾数。
        // 特别是，最小的次正规值为 0x0 ... 01，最大的为 0x000F ... F。
        // 最小的标准数是 0x0010 ... 0，因此此特殊情况也适用。
        // 如果增量使尾数溢出，则进位将根据需要递增指数，并且尾数位变为零。
        // 由于隐藏的位约定，这正是我们想要的!
        // 最后，f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY。
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}