//! Panic 对 libcore 的支持
//!
//! 核心库无法定义恐慌，但可以 *声明* 恐慌。
//! 这意味着 libcore 内部的函数被允许用于 panic，但是要使上游 crate 有用，必须定义恐慌以供 libcore 使用。
//! 当前的恐慌界面是:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! 此定义允许对任何常规消息进行恐慌，但不允许 `Box<Any>` 值失败。
//! (`PanicInfo` 仅包含一个 `&(dyn Any + Send)`，我们在其中将其填充为 `PanicInfo: : internal_constructor` 中的虚拟值。) 其原因是不允许 libcore 进行分配。
//!
//!
//! 该模块还包含其他一些紧急函数，但这只是编译器必需的 lang 项。所有 panics 都通过此函数进行了分配。
//! 实际符号通过 `#[panic_handler]` 属性声明。
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// 不使用格式时，libcore 的 `panic!` 宏的基础实现。
#[cold]
// 从不内联，除非 panic_immediate_abort 尽可能避免调用站点上的代码膨胀
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // 溢出和其他 `Assert` MIR 终结器时 panic 的代码生成所需的
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // 使用 Arguments::new_v1 代替 format_args! (`{}`，expr) 可能会减少大小开销。
    // format_args! 宏使用 str 的 Display trait 来编写 expr，该调用将调用 Formatter::pad，该 Formatter::pad 必须容纳字符串截断和填充 (即使此处未使用)。
    //
    // 使用 Arguments::new_v1 可使编译器从输出二进制文件中省略 Formatter::pad，从而节省多达几千字节的空间。
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // 常量评估的 panics 所需
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOO array/slice 访问上 panic 的代码生成所需的
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// 使用格式化时 libcore 的 `panic!` 宏的基础实现。
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // 注意此函数永远不会越过 FFI 边界。这是 Rust 到 Rust 的调用，已解析为 `#[panic_handler]` 函数。
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // 安全: `panic_impl` 是在安全的 Rust 代码中定义的，因此可以安全调用。
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` 和 `assert_ne!` 宏的内部函数
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}