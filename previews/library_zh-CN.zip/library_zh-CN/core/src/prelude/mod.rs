//! libcore prelude
//!
//! 该模块适用于 libcore 的用户，这些用户也未链接到 libstd。
//! 当以与标准库的 prelude 相同的方式使用 `#![no_std]` 时，默认情况下将导入此模块。
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// 核心 prelude 的 2015 版本。
///
/// 有关更多信息，请参见 [module-level documentation](self)。
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 核心 prelude 的 2018 版本。
///
/// 有关更多信息，请参见 [module-level documentation](self)。
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 核心 prelude 的 2021 版本。
///
/// 有关更多信息，请参见 [module-level documentation](self)。
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: 添加更多东西。
}