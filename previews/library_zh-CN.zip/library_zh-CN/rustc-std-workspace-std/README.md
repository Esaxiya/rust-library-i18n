# `rustc-std-workspace-std` crate

请参阅 `rustc-std-workspace-core` crate 的文档。