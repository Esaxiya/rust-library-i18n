use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // 编写第三方分配器和 `RawVec` 之间的集成测试有点棘手，因为 `RawVec` API 不会公开容易出错的分配方法，因此我们无法检查分配器用尽时会发生什么 (除了检测到 panic 之外)。
    //
    //
    // 相反，这仅检查 `RawVec` 方法在保留存储空间时是否至少通过了 Allocator API。
    //
    //
    //
    //
    //

    // 一个愚蠢的分配器，在分配尝试开始失败之前消耗固定量的燃料。
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (导致重新分配，因此使用 50 + 150=200 单位燃料)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // 首先，`reserve` 像 `reserve_exact` 一样进行分配。
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 大于 7 的两倍，因此 `reserve` 应该像 `reserve_exact` 一样工作。
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 小于 12 的一半，因此 `reserve` 必须成倍增长。
        // 在撰写本文时，该测试的增长因子为 2，因此新容量为 24，但是，1.5 的增长因子也可以。
        //
        // 因此，`>= 18` 处于断言状态。
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}