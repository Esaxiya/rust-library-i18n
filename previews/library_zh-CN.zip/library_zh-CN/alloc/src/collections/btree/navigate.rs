use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// 暂时取出另一个相同范围的不可变值。
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// 查找限定树中指定范围的不同叶边缘。
    /// 将一对不同的句柄返回到同一棵树或一对空选项。
    ///
    /// # Safety
    ///
    /// 除非 `BorrowType` 是 `Immut`，否则请勿使用重复的句柄访问同一 KV 两次。
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// 等效于 `(root1.first_leaf_edge()，root2.last_leaf_edge())`，但效率更高。
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// 查找在树中划定特定范围的一对叶边缘。
    ///
    /// 仅当按键对树进行排序 (如 `BTreeMap` 中的树) 时，结果才有意义。
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // 安全: 我们的借用类型是不可变。
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// 查找界定整个树的一对叶边。
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// 将一个唯一的 quot 分割为一对指定范围的叶子边缘。
    /// 结果是非唯一引号，允许 (some) 可变的，必须谨慎使用。
    ///
    /// 仅当按键对树进行排序 (如 `BTreeMap` 中的树) 时，结果才有意义。
    ///
    ///
    /// # Safety
    /// 请勿使用重复的句柄访问同一 KV 两次。
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// 将唯一的 `引用` 拆分为一对叶子边缘，从而界定了树的整个范围。
    /// 结果是非唯一引号，允许可变的 (仅值)，因此必须小心使用。
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // 我们在这里复制根 NodeRef－我们将永远不会访问同一 KV 两次，也永远不会出现重叠的引用值。
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// 将唯一的 `引用` 拆分为一对叶子边缘，从而界定了树的整个范围。
    /// 结果是非唯一引证的，允许大规模破坏性可变的，因此必须格外小心。
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // 我们在这里复制根 NodeRef－我们将永远不会以与从根获得的引用重叠的方式访问它。
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// 给定叶子 edge 句柄，将 [`Result::Ok`] 及其句柄返回到右侧的相邻 KV，该相邻 KV 在同一叶子节点中或在祖先节点中。
    ///
    /// 如果叶子 edge 是树中的最后一个叶子，则返回带有根节点的 [`Result::Err`]。
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// 给定叶子 edge 句柄，将 [`Result::Ok`] 及其句柄返回到左侧的相邻 KV，该相邻 KV 在同一叶子节点中或在祖先节点中。
    ///
    /// 如果叶子 edge 是树中的第一个叶子，则返回带有根节点的 [`Result::Err`]。
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// 给定一个内部 edge 句柄，将 [`Result::Ok`] 及其句柄返回到右侧的相邻 KV，该 KV 在同一内部节点中或在祖先节点中。
    ///
    /// 如果内部 edge 是树中的最后一个，则返回带有根节点的 [`Result::Err`]。
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// 给定一个即将死去的树的叶子 edge 句柄，则返回右侧的下一个叶子 edge，以及位于两者之间的键值对，它们在同一叶节点中，在祖先节点中或不存在。
    ///
    ///
    /// 此方法还会取消分配到达末尾的所有 node(s)。
    /// 这意味着如果不存在更多的键 / 值对，则树的整个其余部分将被释放，并且没有剩余可返回。
    ///
    /// # Safety
    /// 给定的 edge 一定不是先前由对方 `deallocating_next_back` 返回的。
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// 给定一个即将死去的树的叶子 edge 句柄，则返回左侧的下一个叶子 edge，并返回位于两者之间的键 / 值对，它们在同一叶节点中，在祖先节点中或不存在。
    ///
    ///
    /// 此方法还会取消分配到达末尾的所有 node(s)。
    /// 这意味着如果不存在更多的键 / 值对，则树的整个其余部分将被释放，并且没有剩余可返回。
    ///
    /// # Safety
    /// 给定的 edge 一定不是先前由对方 `deallocating_next` 返回的。
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// 从叶到根取消分配一堆节点。
    /// 这是在 `deallocating_next` 和 `deallocating_next_back` 一直在树的两边蚕食并且击中了相同的 edge 之后，重新分配树的其余部分的唯一方法。
    /// 由于仅在返回所有键和值后才调用它，因此不会对任何键或值进行清理。
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// 将叶子 edge 句柄移动到下一个叶子 edge，并在其中的键和值之间返回引号。
    ///
    ///
    /// # Safety
    /// 行驶方向上必须有另一个 KV。
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// 将叶子 edge 句柄移动到前一个叶子 edge，并在其中的键和值返回 quot。
    ///
    ///
    /// # Safety
    /// 行驶方向上必须有另一个 KV。
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// 将叶子 edge 句柄移动到下一个叶子 edge，并在其中的键和值之间返回引号。
    ///
    ///
    /// # Safety
    /// 行驶方向上必须有另一个 KV。
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // 根据基准测试，这样做的最后速度更快。
        kv.into_kv_valmut()
    }

    /// 将叶子 edge 句柄移动到上一个叶子，并在其中的键和值之间返回 quot。
    ///
    ///
    /// # Safety
    /// 行驶方向上必须有另一个 KV。
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // 根据基准测试，这样做的最后速度更快。
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// 将叶子 edge 的句柄移动到下一个叶子 edge，并返回它们之间的键和值，重新分配留下的任何节点，同时将对应的 edge 保留在其父子节点中。
    ///
    /// # Safety
    /// - 行驶方向上必须有另一个 KV。
    /// - 对方 `next_back_unchecked` 先前未在用于遍历树的任何句柄副本上返回该 KV。
    ///
    /// 进行更新后的句柄的唯一安全方法是对其进行比较，删除它，然后根据其安全条件再次调用此方法，或者根据其安全条件再次调用对应的 `next_back_unchecked`。
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// 将叶子 edge 句柄移动到上一个叶子 edge，并返回它们之间的键和值，重新分配留下的任何节点，同时将对应的 edge 保留在其父子节点中。
    ///
    /// # Safety
    /// - 行驶方向上必须有另一个 KV。
    /// - 对应的 `next_unchecked` 先前未在用于遍历树的句柄的任何副本上返回该叶 edge。
    ///
    /// 进行更新后的句柄的唯一安全方法是对其进行比较，删除它，然后根据其安全条件再次调用此方法，或根据其安全条件再次调用对应的 `next_unchecked`。
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// 返回节点中或节点下方的最左边的叶子 edge，换句话说，返回向前导航时需要的 edge (向后导航时需要的 edge)。
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// 返回节点内或节点下最右边的叶子 edge，换句话说，向前导航时需要最后一个 edge (向后导航时需要第一个 edge)。
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// 按键升序访问叶节点和内部 KV，还按深度优先顺序访问整个内部节点，这意味着内部节点先于其各个 KV 和其子节点。
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// 计算 (子) 树中的元素数。
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// 返回最接近 KV 的叶子 edge，以进行前向导航。
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// 返回最接近 KV 的叶子 edge，以进行向后导航。
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}