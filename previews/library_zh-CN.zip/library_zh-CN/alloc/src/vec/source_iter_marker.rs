use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// 专业化标记，用于在重复使用源分配的同时将迭代器管道收集到 Vec 中，即
/// 执行到位的管道。
///
/// SourceIter 父级 trait 是专用函数访问要重用的分配所必需的。
/// 但是，使专业化有效是不够的。
/// 请参见 impl 上的其他范围。
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std - 内部 SourceIter/InPlaceIterable traits 仅由适配器链实现 <Adapter<Adapter<IntoIter>>> (均归 core/std 所有)。
// 适配器实现的其他限制 (`impl<I: Trait> Trait for Adapter<I>` 以外) 仅取决于已标记为特殊化 traits 的其他 traits (Copy，TrustedRandomAccess，FusedIterator)。
//
// I.e. 该标记不取决于用户提供的类型的生命周期。模制 `复制` 孔，其他几个专业已经依赖该孔。
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // 无法通过 trait bounds 表示的其他要求。我们改用 const eval:
        // a) 没有 ZST，因为没有分配给重用，并且指针算术将为 panic b) 大小符合 Alloc 合约的要求 c) 对齐方式符合 Alloc 合约的要求
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // 回退到更多泛型实现
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // 使用 try-fold 自
        // - 它对某些迭代器适配器的矢量化效果更好
        // - 与大多数内部迭代方法不同，它只需要一个 &mut 自
        // - 它使我们可以通过内部遍历写入指针，并最终将其返回
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // 迭代成功，不要丢下头
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // 检查 SourceIter 合同是否被维护: 如果不是，我们甚至可能无法做到这一点
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // 检查 InPlaceIterable 合同。仅在迭代器完全提高了源指针的情况下才有可能。
        // 如果它通过 TrustedRandomAccess 使用未经检查的访问，则源指针将停留在其初始位置，我们不能将其用作引用
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // 在源的末尾删除所有剩余值，但一旦分配 panics，则防止分配本身下降 IntoIter 离开作用域，那么我们还将泄漏所有收集到的元素到 dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // 这里的 InPlaceIterable 合同无法精确验证，因为 try_fold 对源指针有一个唯一的引用，我们所能做的就是检查它是否仍在范围内
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}