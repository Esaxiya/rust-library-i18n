#![stable(feature = "rust1", since = "1.0.0")]

//! Punteros de recuento de referencias seguros para subprocesos.
//!
//! Consulte la documentación de [`Arc<T>`][Arc] para obtener más detalles.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Un límite suave en la cantidad de referencias que se pueden hacer a un `Arc`.
///
/// Superar este límite abortará su programa (aunque no necesariamente) en las referencias _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer no admite barreras de memoria.
// Para evitar informes de falsos positivos en la implementación de Arc/Weak, utilice cargas atómicas para la sincronización.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Un puntero de recuento de referencias seguro para subprocesos.'Arc' son las siglas de 'Atomically Reference Counted'.
///
/// El tipo `Arc<T>` proporciona la propiedad compartida de un valor de tipo `T`, asignado en el montón.La invocación de [`clone`][clone] en `Arc` produce una nueva instancia de `Arc`, que apunta a la misma asignación en el montón que la fuente `Arc`, al tiempo que aumenta el recuento de referencias.
/// Cuando se destruye el último puntero `Arc` a una asignación determinada, el valor almacenado en esa asignación (a menudo denominado "inner value") también se elimina.
///
/// Las referencias compartidas en Rust no permiten la mutación de forma predeterminada, y `Arc` no es una excepción: generalmente no se puede obtener una referencia mutable a algo dentro de un `Arc`.Si necesita mutar a través de un `Arc`, use [`Mutex`][mutex], [`RwLock`][rwlock] o uno de los tipos [`Atomic`][atomic].
///
/// ## Seguridad del hilo
///
/// A diferencia de [`Rc<T>`], `Arc<T>` utiliza operaciones atómicas para su recuento de referencias.Esto significa que es seguro para subprocesos.La desventaja es que las operaciones atómicas son más caras que los accesos a la memoria ordinaria.Si no comparte asignaciones contadas por referencias entre subprocesos, considere usar [`Rc<T>`] para reducir la sobrecarga.
/// [`Rc<T>`] es un valor predeterminado seguro, porque el compilador detectará cualquier intento de enviar un [`Rc<T>`] entre subprocesos.
/// Sin embargo, una biblioteca puede elegir `Arc<T>` para brindar a los consumidores de la biblioteca más flexibilidad.
///
/// `Arc<T>` implementará [`Send`] y [`Sync`] siempre que `T` implemente [`Send`] y [`Sync`].
/// ¿Por qué no puede poner un tipo `T` no seguro para subprocesos en un `Arc<T>` para hacerlo seguro para subprocesos?Esto puede ser un poco contrario a la intuición al principio: después de todo, ¿no es el objetivo de la seguridad del hilo `Arc<T>`?La clave es esta: `Arc<T>` hace que sea seguro para subprocesos tener varias propiedades de los mismos datos, pero no agrega seguridad para subprocesos a sus datos.
///
/// Considere `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] no es [`Sync`], y si `Arc<T>` siempre fue [`Send`], `Arc <` [`RefCell<T>`]`>`también lo sería.
/// Pero entonces tendríamos un problema:
/// [`RefCell<T>`] no es seguro para subprocesos;realiza un seguimiento del recuento de préstamos mediante operaciones no atómicas.
///
/// Al final, esto significa que es posible que deba emparejar `Arc<T>` con algún tipo de [`std::sync`], generalmente [`Mutex<T>`][mutex].
///
/// ## Rompiendo ciclos con `Weak`
///
/// El método [`downgrade`][downgrade] se puede utilizar para crear un puntero [`Weak`] que no sea propietario.Un puntero [`Weak`] se puede [`actualizar`][actualizar] d a un `Arc`, pero esto devolverá [`None`] si el valor almacenado en la asignación ya se ha eliminado.
/// En otras palabras, los punteros `Weak` no mantienen vivo el valor dentro de la asignación;sin embargo,*mantienen* viva la asignación (el almacén de respaldo para el valor).
///
/// Un ciclo entre punteros `Arc` nunca se desasignará.
/// Por esta razón, [`Weak`] se utiliza para romper ciclos.Por ejemplo, un árbol podría tener fuertes punteros `Arc` de los nodos principales a los hijos y [`Weak`] de los hijos a sus padres.
///
/// # Clonación de referencias
///
/// La creación de una nueva referencia a partir de un puntero contado de referencia existente se realiza utilizando `Clone` trait implementado para [`Arc<T>`][Arc] y [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Las dos sintaxis siguientes son equivalentes.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b y foo son todos arcos que apuntan a la misma ubicación de memoria
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` elimina automáticamente las referencias a `T` (a través de [`Deref`][deref] trait), por lo que puede llamar a los métodos de `T` en un valor de tipo `Arc<T>`.Para evitar conflictos de nombres con los métodos de `T`, los métodos de `Arc<T>` en sí son funciones asociadas, llamadas usando [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// Arco<T>Las implementaciones de traits como `Clone` también pueden llamarse utilizando una sintaxis totalmente calificada.
/// Algunas personas prefieren utilizar una sintaxis totalmente calificada, mientras que otras prefieren utilizar la sintaxis de llamada a método.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sintaxis de llamada a método
/// let arc2 = arc.clone();
/// // Sintaxis totalmente calificada
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] no autodesreferencia a `T`, porque es posible que el valor interno ya se haya eliminado.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Compartiendo algunos datos inmutables entre hilos:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Tenga en cuenta que **no** ejecutamos estas pruebas aquí.
// Los constructores de windows se sienten muy infelices si un hilo sobrevive al hilo principal y luego sale al mismo tiempo (algo se bloquea), por lo que simplemente evitamos esto por completo al no ejecutar estas pruebas.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Compartiendo un [`AtomicUsize`] mutable:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Consulte el [`rc` documentation][rc_examples] para obtener más ejemplos de recuento de referencias en general.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` es una versión de [`Arc`] que contiene una referencia de no propietario a la asignación administrada.
/// Se accede a la asignación llamando a [`upgrade`] en el puntero `Weak`, que devuelve una [`Option`]`<`[`Arc`] `<T>>`.
///
/// Dado que una referencia `Weak` no cuenta para la propiedad, no evitará que se elimine el valor almacenado en la asignación, y el propio `Weak` no garantiza que el valor aún esté presente.
///
/// Por lo tanto, puede devolver [`None`] cuando [`upgrade`] d.
/// Sin embargo, tenga en cuenta que una referencia `Weak`*no* evita que se desasigne la asignación en sí (la tienda de respaldo).
///
/// Un puntero `Weak` es útil para mantener una referencia temporal a la asignación administrada por [`Arc`] sin evitar que se elimine su valor interno.
/// También se utiliza para evitar referencias circulares entre punteros [`Arc`], ya que las referencias de propiedad mutua nunca permitirían descartar [`Arc`].
/// Por ejemplo, un árbol podría tener fuertes punteros [`Arc`] de los nodos principales a los hijos y `Weak` de los hijos a sus padres.
///
/// La forma típica de obtener un puntero `Weak` es llamar a [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Este es un `NonNull` para permitir optimizar el tamaño de este tipo en enumeraciones, pero no es necesariamente un puntero válido.
    //
    // `Weak::new` establece esto en `usize::MAX` para que no necesite asignar espacio en el montón.
    // Ese no es un valor que tendrá un puntero real porque RcBox tiene una alineación de al menos 2.
    // Esto solo es posible cuando `T: Sized`;`T` sin tamaño nunca cuelga.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Esto es de repr(C) a future a prueba de posibles reordenamientos de campo, lo que interferiría con el [into|from]_raw() seguro de tipos internos transmutables.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // el valor usize::MAX actúa como un centinela para temporalmente "locking" la capacidad de actualizar punteros débiles o degradar los fuertes;esto se usa para evitar carreras en `make_mut` y `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Construye un nuevo `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Inicie el recuento de punteros débiles como 1, que es el puntero débil que tienen todos los punteros fuertes (kinda), consulte std/rc.rs para obtener más información
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Construye un nuevo `Arc<T>` usando una referencia débil a sí mismo.
    /// Si intenta actualizar la referencia débil antes de que regrese esta función, se obtendrá un valor `None`.
    /// Sin embargo, la referencia débil se puede clonar libremente y almacenar para su uso en un momento posterior.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Construya el interior en el estado "uninitialized" con una única referencia débil.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Es importante que no cedamos la propiedad del puntero débil, de lo contrario, la memoria podría liberarse cuando regrese `data_fn`.
        // Si realmente quisiéramos pasar la propiedad, podríamos crear un puntero débil adicional para nosotros, pero esto daría como resultado actualizaciones adicionales para el recuento de referencias débiles que podrían no ser necesarias de otra manera.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Ahora podemos inicializar correctamente el valor interno y convertir nuestra referencia débil en una referencia fuerte.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // La escritura anterior en el campo de datos debe ser visible para cualquier hilo que observe un recuento fuerte distinto de cero.
            // Por lo tanto, necesitamos al menos un pedido "Release" para sincronizar con el `compare_exchange_weak` en `Weak::upgrade`.
            //
            // "Acquire" no es necesario realizar un pedido.
            // Al considerar los posibles comportamientos de `data_fn`, solo necesitamos ver lo que podría hacer con una referencia a un `Weak` no actualizable:
            //
            // - Puede *clonar* el `Weak`, aumentando el recuento de referencias débiles.
            // - Puede eliminar esos clones, disminuyendo el recuento de referencias débiles (pero nunca a cero).
            //
            // Estos efectos secundarios no nos afectan de ninguna manera, y no es posible que haya otros efectos secundarios solo con un código seguro.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Las referencias fuertes deben poseer colectivamente una referencia débil compartida, así que no ejecute el destructor para nuestra antigua referencia débil.
        //
        mem::forget(weak);
        strong
    }

    /// Construye un nuevo `Arc` con contenido no inicializado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialización diferida:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construye un nuevo `Arc` con contenido no inicializado, con la memoria llena con `0` bytes.
    ///
    ///
    /// Consulte [`MaybeUninit::zeroed`][zeroed] para ver ejemplos del uso correcto e incorrecto de este método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construye un nuevo `Pin<Arc<T>>`.
    /// Si `T` no implementa `Unpin`, entonces `data` se anclará en la memoria y no se podrá mover.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Construye un nuevo `Arc<T>` y devuelve un error si falla la asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Inicie el recuento de punteros débiles como 1, que es el puntero débil que tienen todos los punteros fuertes (kinda), consulte std/rc.rs para obtener más información
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Construye un nuevo `Arc` con contenido no inicializado y devuelve un error si falla la asignación.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inicialización diferida:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Construye un nuevo `Arc` con contenido no inicializado, con la memoria llena con `0` bytes, devolviendo un error si falla la asignación.
    ///
    ///
    /// Consulte [`MaybeUninit::zeroed`][zeroed] para ver ejemplos del uso correcto e incorrecto de este método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Devuelve el valor interno, si el `Arc` tiene exactamente una referencia fuerte.
    ///
    /// De lo contrario, se devuelve un [`Err`] con el mismo `Arc` que se pasó.
    ///
    ///
    /// Esto tendrá éxito incluso si hay referencias débiles sobresalientes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Haga un puntero débil para limpiar la referencia implícita fuerte-débil
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Construye un nuevo segmento contado por referencia atómicamente con contenido no inicializado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialización diferida:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Construye un nuevo segmento con conteo de referencia atómico con contenido no inicializado, con la memoria llena con `0` bytes.
    ///
    ///
    /// Consulte [`MaybeUninit::zeroed`][zeroed] para ver ejemplos del uso correcto e incorrecto de este método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Convierte a `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Al igual que con [`MaybeUninit::assume_init`], depende de la persona que llama garantizar que el valor interno realmente esté en un estado inicializado.
    ///
    /// Llamar a esto cuando el contenido aún no está completamente inicializado provoca un comportamiento indefinido inmediato.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialización diferida:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Convierte a `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Al igual que con [`MaybeUninit::assume_init`], depende de la persona que llama garantizar que el valor interno realmente esté en un estado inicializado.
    ///
    /// Llamar a esto cuando el contenido aún no está completamente inicializado provoca un comportamiento indefinido inmediato.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialización diferida:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Consume el `Arc`, devolviendo el puntero envuelto.
    ///
    /// Para evitar una pérdida de memoria, el puntero debe volver a convertirse a un `Arc` utilizando [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Proporciona un puntero sin procesar a los datos.
    ///
    /// Los recuentos no se ven afectados de ninguna manera y el `Arc` no se consume.
    /// El puntero es válido mientras haya recuentos fuertes en el `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SEGURIDAD: Esto no puede pasar por Deref::deref o RcBoxPtr::inner porque
        // esto es necesario para conservar la procedencia raw/mut de manera que, por ejemplo,
        // `get_mut` puede escribir a través del puntero después de que el Rc se recupere a través de `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Construye un `Arc<T>` a partir de un puntero sin formato.
    ///
    /// El puntero sin formato debe haber sido devuelto previamente por una llamada a [`Arc<U>::into_raw`][into_raw] donde `U` debe tener el mismo tamaño y alineación que `T`.
    /// Esto es trivialmente cierto si `U` es `T`.
    /// Tenga en cuenta que si `U` no es `T` pero tiene el mismo tamaño y alineación, esto es básicamente como transmutar referencias de diferentes tipos.
    /// Consulte [`mem::transmute`][transmute] para obtener más información sobre las restricciones que se aplican en este caso.
    ///
    /// El usuario de `from_raw` debe asegurarse de que un valor específico de `T` solo se elimine una vez.
    ///
    /// Esta función no es segura porque el uso inadecuado puede provocar la inseguridad de la memoria, incluso si nunca se accede al `Arc<T>` devuelto.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Convierta nuevamente a un `Arc` para evitar fugas.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Otras llamadas a `Arc::from_raw(x_ptr)` no serían seguras para la memoria.
    /// }
    ///
    /// // La memoria se liberó cuando `x` salió del alcance anterior, ¡por lo que `x_ptr` ahora está colgando!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Invierta el desplazamiento para encontrar el ArcInner original.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Crea un nuevo puntero [`Weak`] a esta asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Esto relajado está bien porque estamos verificando el valor en el CAS a continuación.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // compruebe si el contador débil es actualmente "locked";si es así, gira.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: este código actualmente ignora la posibilidad de desbordamiento
            // en usize::MAX;en general, tanto Rc como Arc deben ajustarse para hacer frente al desbordamiento.
            //

            // A diferencia de Clone(), necesitamos que sea una lectura de adquisición para sincronizar con la escritura que viene de `is_unique`, de modo que los eventos anteriores a esa escritura sucedan antes de esta lectura.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Asegúrese de que no creemos un Débil colgante
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Obtiene el número de punteros [`Weak`] a esta asignación.
    ///
    /// # Safety
    ///
    /// Este método por sí solo es seguro, pero su uso correcto requiere un cuidado especial.
    /// Otro hilo puede cambiar el conteo débil en cualquier momento, incluso potencialmente entre llamar a este método y actuar sobre el resultado.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Esta afirmación es determinista porque no hemos compartido `Arc` o `Weak` entre subprocesos.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Si el conteo débil está bloqueado actualmente, el valor del conteo era 0 justo antes de realizar el bloqueo.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Obtiene el número de punteros (`Arc`) potentes para esta asignación.
    ///
    /// # Safety
    ///
    /// Este método por sí solo es seguro, pero su uso correcto requiere un cuidado especial.
    /// Otro hilo puede cambiar el recuento fuerte en cualquier momento, incluso potencialmente entre llamar a este método y actuar sobre el resultado.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Esta afirmación es determinista porque no hemos compartido el `Arc` entre hilos.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Aumenta en uno el recuento de referencias fuertes en el `Arc<T>` asociado con el puntero proporcionado.
    ///
    /// # Safety
    ///
    /// El puntero debe haberse obtenido a través de `Arc::into_raw` y la instancia `Arc` asociada debe ser válida (es decir
    /// el recuento fuerte debe ser al menos 1) durante la duración de este método.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Esta afirmación es determinista porque no hemos compartido el `Arc` entre hilos.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Conserve Arc, pero no toque refcount envolviendo en ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Ahora aumente el recuento de ref., Pero tampoco elimine el recuento de ref.
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Disminuye en uno el recuento de referencias fuertes en el `Arc<T>` asociado con el puntero proporcionado.
    ///
    /// # Safety
    ///
    /// El puntero debe haberse obtenido a través de `Arc::into_raw` y la instancia `Arc` asociada debe ser válida (es decir
    /// el recuento fuerte debe ser al menos 1) al invocar este método.
    /// Este método se puede utilizar para liberar el `Arc` final y el almacenamiento de respaldo, pero **no** se debe llamar después de que se haya lanzado el `Arc` final.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Esas afirmaciones son deterministas porque no hemos compartido el `Arc` entre hilos.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Esta inseguridad está bien porque mientras este arco esté vivo, tenemos la garantía de que el puntero interno es válido.
        // Además, sabemos que la estructura `ArcInner` en sí es `Sync` porque los datos internos también son `Sync`, por lo que estamos bien prestando un puntero inmutable a estos contenidos.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Parte no alineada de `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Destruya los datos en este momento, aunque es posible que no liberemos la asignación del cuadro en sí (es posible que todavía haya indicadores débiles por ahí).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Elimine la referencia débil colectivamente sostenida por todas las referencias fuertes
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Devuelve `true` si los dos `Arc`s apuntan a la misma asignación (en una línea similar a [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Asigna un `ArcInner<T>` con espacio suficiente para un valor interno posiblemente sin tamaño donde el valor tiene el diseño proporcionado.
    ///
    /// La función `mem_to_arcinner` se llama con el puntero de datos y debe devolver un puntero (potencialmente gordo) para el `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Calcule el diseño utilizando el diseño de valor dado.
        // Anteriormente, el diseño se calculaba en la expresión `&*(ptr as* const ArcInner<T>)`, pero esto creaba una referencia desalineada (ver #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Asigna un `ArcInner<T>` con espacio suficiente para un valor interno posiblemente sin tamaño donde el valor tiene el diseño proporcionado, devolviendo un error si falla la asignación.
    ///
    ///
    /// La función `mem_to_arcinner` se llama con el puntero de datos y debe devolver un puntero (potencialmente gordo) para el `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Calcule el diseño utilizando el diseño de valor dado.
        // Anteriormente, el diseño se calculaba en la expresión `&*(ptr as* const ArcInner<T>)`, pero esto creaba una referencia desalineada (ver #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inicializar ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Asigna un `ArcInner<T>` con espacio suficiente para un valor interno sin tamaño.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Asigne para el `ArcInner<T>` usando el valor dado.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copiar valor como bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Libera la asignación sin dejar caer su contenido
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Asigna un `ArcInner<[T]>` con la longitud dada.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Copiar elementos del corte en el Arc <\[T\]> recién asignado
    ///
    /// Inseguro porque la persona que llama debe tomar posesión o vincular `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Construye un `Arc<[T]>` a partir de un iterador que se sabe que tiene un tamaño determinado.
    ///
    /// El comportamiento no está definido en caso de que el tamaño sea incorrecto.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Guardia Panic durante la clonación de elementos T.
        // En el caso de un panic, los elementos que se han escrito en el nuevo ArcInner se eliminarán y luego se liberará la memoria.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Puntero al primer elemento
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Todo claro.Olvídese del guardia para que no libere el nuevo ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Especialización trait utilizada para `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Hace un clon del puntero `Arc`.
    ///
    /// Esto crea otro puntero a la misma asignación, aumentando el recuento de referencias fuertes.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Usar un orden relajado está bien aquí, ya que el conocimiento de la referencia original evita que otros hilos eliminen erróneamente el objeto.
        //
        // Como se explica en el [Boost documentation][1], el aumento del contador de referencia siempre se puede hacer con memory_order_relaxed: las nuevas referencias a un objeto solo se pueden formar a partir de una referencia existente, y pasar una referencia existente de un hilo a otro ya debe proporcionar cualquier sincronización requerida.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Sin embargo, debemos protegernos de los recuentos masivos en caso de que alguien `mem: : olvide` Arcs.
        // Si no hacemos esto, el recuento puede desbordarse y los usuarios usarán después de forma gratuita.
        // Rápidamente saturamos a `isize::MAX` asumiendo que no hay ~2 mil millones de subprocesos que incrementen el recuento de referencias a la vez.
        //
        // Este branch nunca se tomará en ningún programa realista.
        //
        // Abortamos porque tal programa es increíblemente degenerado y no nos importa apoyarlo.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Hace una referencia mutable en el `Arc` dado.
    ///
    /// Si hay otros punteros `Arc` o [`Weak`] a la misma asignación, entonces `make_mut` creará una nueva asignación e invocará [`clone`][clone] en el valor interno para garantizar la propiedad única.
    /// Esto también se conoce como clonar al escribir.
    ///
    /// Tenga en cuenta que esto difiere del comportamiento de [`Rc::make_mut`] que disocia cualquier puntero `Weak` restante.
    ///
    /// Consulte también [`get_mut`][get_mut], que fallará en lugar de clonar.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // No clonará nada
    /// let mut other_data = Arc::clone(&data); // No clonará datos internos
    /// *Arc::make_mut(&mut data) += 1;         // Clona datos internos
    /// *Arc::make_mut(&mut data) += 1;         // No clonará nada
    /// *Arc::make_mut(&mut other_data) *= 2;   // No clonará nada
    ///
    /// // Ahora `data` y `other_data` apuntan a diferentes asignaciones.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Tenga en cuenta que tenemos una referencia fuerte y una referencia débil.
        // Por lo tanto, la liberación de nuestra referencia fuerte no provocará, por sí misma, que se desasigne la memoria.
        //
        // Utilice Adquirir para asegurarse de que veamos las escrituras en `weak` que suceden antes de las escrituras de lanzamiento (es decir, disminuciones) en `strong`.
        // Dado que tenemos un recuento débil, no hay posibilidad de que el ArcInner en sí pueda ser desasignado.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Existe otro puntero fuerte, por lo que debemos clonar.
            // Asigne previamente memoria para permitir escribir el valor clonado directamente.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Relajado es suficiente en lo anterior porque esto es fundamentalmente una optimización: siempre estamos compitiendo con punteros débiles que se caen.
            // En el peor de los casos, terminamos asignando un nuevo Arco innecesariamente.
            //

            // Eliminamos la última referencia fuerte, pero quedan referencias débiles adicionales.
            // Moveremos el contenido a un nuevo Arc e invalidaremos las otras referencias débiles.
            //

            // Tenga en cuenta que no es posible que la lectura de `weak` produzca usize::MAX (es decir, bloqueado), ya que el conteo débil solo puede bloquearse mediante un hilo con una referencia fuerte.
            //
            //

            // Materialice nuestro propio puntero débil implícito, para que pueda limpiar el ArcInner según sea necesario.
            //
            let _weak = Weak { ptr: this.ptr };

            // Puede robar los datos, todo lo que queda son débiles
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Éramos la única referencia de ambos tipos;Vuelva a subir el recuento de ref. fuerte.
            //
            this.inner().strong.store(1, Release);
        }

        // Al igual que con `get_mut()`, la inseguridad está bien porque nuestra referencia era única al principio o se convirtió en una al clonar el contenido.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Devuelve una referencia mutable en el `Arc` dado, si no hay otros punteros `Arc` o [`Weak`] a la misma asignación.
    ///
    ///
    /// De lo contrario, devuelve [`None`], porque no es seguro mutar un valor compartido.
    ///
    /// Consulte también [`make_mut`][make_mut], que será [`clone`][clone] el valor interno cuando haya otros punteros.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Esta inseguridad está bien porque tenemos la garantía de que el puntero devuelto es el *único* puntero que se devolverá a T.
            // Nuestro recuento de referencias está garantizado en 1 en este punto, y requerimos que el Arc en sí sea `mut`, por lo que devolvemos la única referencia posible a los datos internos.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Devuelve una referencia mutable en el `Arc` dado, sin ninguna verificación.
    ///
    /// Consulte también [`get_mut`], que es seguro y realiza las comprobaciones adecuadas.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Cualquier otro puntero `Arc` o [`Weak`] a la misma asignación no debe desreferenciarse durante la duración del préstamo devuelto.
    ///
    /// Este es trivialmente el caso si no existen tales punteros, por ejemplo, inmediatamente después de `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Tenemos cuidado de *no* crear una referencia que cubra los campos "count", ya que esto sería un alias con acceso concurrente a los recuentos de referencias (p. Ej.
        // por `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Determine si esta es la referencia única (incluidas las referencias débiles) a los datos subyacentes.
    ///
    ///
    /// Tenga en cuenta que esto requiere bloquear el recuento de referencias débiles.
    fn is_unique(&mut self) -> bool {
        // bloquear el recuento de puntero débil si parece que somos el único titular de puntero débil.
        //
        // La etiqueta de adquisición aquí asegura una relación de suceder antes con cualquier escritura en `strong` (en particular en `Weak::upgrade`) antes de las disminuciones del recuento de `weak` (a través de `Weak::drop`, que usa la versión).
        // Si la referencia débil mejorada nunca se eliminó, el CAS aquí fallará, por lo que no nos importa sincronizar.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Este debe ser un `Acquire` para sincronizarse con la disminución del contador `strong` en `drop`, el único acceso que ocurre cuando se descarta cualquier referencia excepto la última.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // La escritura de lanzamiento aquí se sincroniza con una lectura en `downgrade`, evitando efectivamente que la lectura anterior de `strong` ocurra después de la escritura.
            //
            //
            self.inner().weak.store(1, Release); // suelta la cerradura
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Deja caer el `Arc`.
    ///
    /// Esto disminuirá el recuento de referencias fuertes.
    /// Si el recuento de referencias fuertes llega a cero, las únicas otras referencias (si las hay) son [`Weak`], por lo que `drop` es el valor interno.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // No imprime nada
    /// drop(foo2);   // Imprime "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Debido a que `fetch_sub` ya es atómico, no necesitamos sincronizar con otros subprocesos a menos que vayamos a eliminar el objeto.
        // Esta misma lógica se aplica al siguiente `fetch_sub` para el recuento de `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Esta valla es necesaria para evitar la reordenación del uso de los datos y la eliminación de los datos.
        // Debido a que está marcado como `Release`, la disminución del recuento de referencia se sincroniza con esta cerca `Acquire`.
        // Esto significa que el uso de los datos ocurre antes de disminuir el recuento de referencias, lo que ocurre antes de esta valla, lo que ocurre antes de la eliminación de los datos.
        //
        // Como se explica en el [Boost documentation][1],
        //
        // > Es importante hacer cumplir cualquier posible acceso al objeto en una
        // > hilo (a través de una referencia existente) para *suceder antes de* eliminar
        // > el objeto en un hilo diferente.Esto se logra con un "release"
        // > operación después de soltar una referencia (cualquier acceso al objeto
        // > a través de esta referencia obviamente debe haber sucedido antes), y un
        // > "acquire" operación antes de eliminar el objeto.
        //
        // En particular, si bien el contenido de un Arc suele ser inmutable, es posible tener escrituras interiores en algo como un Mutex<T>.
        // Dado que un Mutex no se adquiere cuando se elimina, no podemos confiar en su lógica de sincronización para hacer que las escrituras en el hilo A sean visibles para un destructor que se ejecuta en el hilo B.
        //
        //
        // También tenga en cuenta que la cerca de adquisición aquí probablemente podría reemplazarse con una carga de adquisición, lo que podría mejorar el rendimiento en situaciones muy difíciles.Ver [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Intente bajar el `Arc<dyn Any + Send + Sync>` a un tipo concreto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Construye un nuevo `Weak<T>`, sin asignar memoria.
    /// Llamar a [`upgrade`] en el valor de retorno siempre da [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Tipo de ayuda para permitir acceder a los recuentos de referencia sin hacer ninguna afirmación sobre el campo de datos.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Devuelve un puntero sin formato al objeto `T` al que apunta este `Weak<T>`.
    ///
    /// El puntero es válido solo si hay algunas referencias sólidas.
    /// El puntero puede estar colgando, desalineado o incluso [`null`] de otra manera.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Ambos apuntan al mismo objeto
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // El fuerte aquí lo mantiene vivo, por lo que aún podemos acceder al objeto.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Pero ya no más.
    /// // Podemos hacer weak.as_ptr(), pero acceder al puntero conduciría a un comportamiento indefinido.
    /// // asert_eq! ("hola", inseguro {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Si el puntero está colgando, devolvemos el centinela directamente.
            // Esta no puede ser una dirección de carga útil válida, ya que la carga útil está al menos tan alineada como ArcInner (usize).
            ptr as *const T
        } else {
            // SEGURIDAD: si is_dangling devuelve falso, entonces el puntero es desreferenciable.
            // La carga útil puede caer en este punto, y tenemos que mantener la procedencia, así que use la manipulación del puntero sin procesar.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Consume el `Weak<T>` y lo convierte en un puntero sin formato.
    ///
    /// Esto convierte el puntero débil en un puntero sin formato, al tiempo que conserva la propiedad de una referencia débil (esta operación no modifica el recuento débil).
    /// Se puede convertir de nuevo en el `Weak<T>` con [`from_raw`].
    ///
    /// Se aplican las mismas restricciones de acceso al destino del puntero que con [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Convierte un puntero sin formato creado previamente por [`into_raw`] de nuevo en `Weak<T>`.
    ///
    /// Esto se puede usar para obtener de forma segura una referencia sólida (llamando a [`upgrade`] más tarde) o para desasignar el recuento débil eliminando el `Weak<T>`.
    ///
    /// Se apropia de una referencia débil (con la excepción de los punteros creados por [`new`], ya que estos no poseen nada; el método aún funciona en ellos).
    ///
    /// # Safety
    ///
    /// El puntero debe haberse originado en el [`into_raw`] y aún debe poseer su referencia débil potencial.
    ///
    /// Se permite que el recuento fuerte sea 0 en el momento de llamar a esto.
    /// Sin embargo, esto toma posesión de una referencia débil actualmente representada como un puntero sin formato (el conteo débil no es modificado por esta operación) y por lo tanto debe emparejarse con una llamada previa a [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Disminuye el último recuento débil.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Consulte Weak::as_ptr para obtener un contexto sobre cómo se deriva el puntero de entrada.

        let ptr = if is_dangling(ptr as *mut T) {
            // Este es un Débil colgando.
            ptr as *mut ArcInner<T>
        } else {
            // De lo contrario, tenemos la garantía de que el puntero proviene de un Débil que no cuelga.
            // SEGURIDAD: es seguro llamar a data_offset, ya que ptr hace referencia a un T.
            let offset = unsafe { data_offset(ptr) };
            // Por lo tanto, invertimos el desplazamiento para obtener el RcBox completo.
            // SEGURIDAD: el puntero se originó a partir de un Débil, por lo que este desplazamiento es seguro.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SEGURIDAD: ahora hemos recuperado el puntero Débil original, por lo que podemos crear el Puntero Débil.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Intenta actualizar el puntero `Weak` a un [`Arc`], retrasando la caída del valor interno si tiene éxito.
    ///
    ///
    /// Devuelve [`None`] si el valor interno se ha eliminado desde entonces.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Destruye todos los indicadores fuertes.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Usamos un bucle CAS para incrementar el recuento fuerte en lugar de un fetch_add ya que esta función nunca debería llevar el recuento de referencia de cero a uno.
        //
        //
        let inner = self.inner()?;

        // Carga relajada porque cualquier escritura de 0 que podamos observar deja el campo en un estado permanentemente cero (por lo que una lectura "stale" de 0 está bien), y cualquier otro valor se confirma a través del CAS a continuación.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Vea los comentarios en `Arc::clone` para saber por qué hacemos esto (para `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relajado está bien para el caso de falla porque no tenemos ninguna expectativa sobre el nuevo estado.
            // Adquirir es necesario para que el caso de éxito se sincronice con `Arc::new_cyclic`, cuando el valor interno se puede inicializar después de que ya se hayan creado las referencias `Weak`.
            // En ese caso, esperamos observar el valor completamente inicializado.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // nulo marcado arriba
                Err(old) => n = old,
            }
        }
    }

    /// Obtiene el número de punteros (`Arc`) fuertes que apuntan a esta asignación.
    ///
    /// Si `self` se creó con [`Weak::new`], devolverá 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Obtiene una aproximación del número de punteros `Weak` que apuntan a esta asignación.
    ///
    /// Si `self` se creó con [`Weak::new`], o si no quedan punteros fuertes, devolverá 0.
    ///
    /// # Accuracy
    ///
    /// Debido a los detalles de implementación, el valor devuelto puede estar desviado en 1 en cualquier dirección cuando otros hilos manipulan cualquier `Arc`s o`Weak`s apuntando a la misma asignación.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Dado que observamos que había al menos un puntero fuerte después de leer el conteo débil, sabemos que la referencia débil implícita (presente siempre que haya referencias fuertes vivas) todavía estaba presente cuando observamos el conteo débil y, por lo tanto, podemos restarlo de manera segura.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Devuelve `None` cuando el puntero está colgando y no hay `ArcInner` asignado (es decir, cuando este `Weak` fue creado por `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Tenemos cuidado de *no* crear una referencia que cubra el campo "data", ya que el campo puede mutarse al mismo tiempo (por ejemplo, si se elimina el último `Arc`, el campo de datos se colocará en el lugar).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Devuelve `true` si los dos `Débiles apuntan a la misma asignación (similar a [`ptr::eq`]), o si ambos no apuntan a ninguna asignación (porque fueron creados con `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Dado que esto compara punteros, significa que `Weak::new()` se igualarán entre sí, aunque no apunten a ninguna asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparando `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Hace un clon del puntero `Weak` que apunta a la misma asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Vea los comentarios en Arc::clone() para saber por qué esto es relajado.
        // Esto puede usar fetch_add (ignorando el bloqueo) porque el conteo débil solo está bloqueado donde *no existen otros* punteros débiles.
        //
        // (Entonces no podemos ejecutar este código en ese caso).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Vea los comentarios en Arc::clone() para saber por qué hacemos esto (para mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Construye un nuevo `Weak<T>`, sin asignar memoria.
    /// Llamar a [`upgrade`] en el valor de retorno siempre da [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Suelta el puntero `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // No imprime nada
    /// drop(foo);        // Imprime "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Si descubrimos que fuimos el último puntero débil, entonces es hora de desasignar los datos por completo.Vea la discusión en Arc::drop() sobre los pedidos de memoria
        //
        // No es necesario verificar el estado bloqueado aquí, porque el conteo débil solo se puede bloquear si había precisamente una referencia débil, lo que significa que la caída solo podría ejecutarse posteriormente en esa referencia débil restante, lo que solo puede suceder después de que se libere el bloqueo.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Estamos haciendo esta especialización aquí, y no como una optimización más general en `&T`, porque de lo contrario agregaría un costo a todas las verificaciones de igualdad en las referencias.
/// Suponemos que los `Arc`s se utilizan para almacenar valores grandes, que son lentos para clonar, pero también pesados para verificar la igualdad, lo que hace que este costo se amortice más fácilmente.
///
/// También es más probable tener dos clones `Arc`, que apuntan al mismo valor, que dos `&T`s.
///
/// Solo podemos hacer esto cuando `T: Eq` como `PartialEq` puede ser deliberadamente irreflexivo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Igualdad por dos arcos.
    ///
    /// Dos `Arc`s son iguales si sus valores internos son iguales, incluso si están almacenados en una asignación diferente.
    ///
    /// Si `T` también implementa `Eq` (lo que implica reflexividad de igualdad), dos `Arc`s que apuntan a la misma asignación son siempre iguales.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Desigualdad por dos arcos.
    ///
    /// Dos `Arc`s son desiguales si sus valores internos son desiguales.
    ///
    /// Si `T` también implementa `Eq` (lo que implica reflexividad de igualdad), dos `Arc`s que apuntan al mismo valor nunca son desiguales.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Comparación parcial de dos `Arc`s.
    ///
    /// Los dos se comparan llamando a `partial_cmp()` en sus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Comparación de menos de dos `Arc`s.
    ///
    /// Los dos se comparan llamando a `<` en sus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Comparación 'Menor o igual a' para dos 'Arc`s.
    ///
    /// Los dos se comparan llamando a `<=` en sus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Comparación mayor que para dos `Arc`s.
    ///
    /// Los dos se comparan llamando a `>` en sus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Comparación 'Mayor o igual a' para dos 'Arc`s.
    ///
    /// Los dos se comparan llamando a `>=` en sus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Comparación de dos `Arc`s.
    ///
    /// Los dos se comparan llamando a `cmp()` en sus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Crea un nuevo `Arc<T>`, con el valor `Default` para `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Asigne un segmento contado por referencia y rellénelo clonando los elementos de `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Asigne un `str` contado por referencia y copie `v` en él.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Asigne un `str` contado por referencia y copie `v` en él.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Mueva un objeto en caja a una nueva asignación contada por referencias.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Asigne un segmento contado por referencia y mueva los elementos de `v` a él.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Permita que el Vec libere su memoria, pero no destruya su contenido
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Toma cada elemento del `Iterator` y lo recopila en un `Arc<[T]>`.
    ///
    /// # Características de presentación
    ///
    /// ## El caso general
    ///
    /// En el caso general, la recopilación en `Arc<[T]>` se realiza primero mediante la recopilación en un `Vec<T>`.Es decir, al escribir lo siguiente:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// esto se comporta como si escribiéramos:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // El primer conjunto de asignaciones ocurre aquí.
    ///     .into(); // Aquí ocurre una segunda asignación para `Arc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Esto asignará tantas veces como sea necesario para construir el `Vec<T>` y luego asignará una vez para convertir el `Vec<T>` en el `Arc<[T]>`.
    ///
    ///
    /// ## Iteradores de longitud conocida
    ///
    /// Cuando su `Iterator` implemente `TrustedLen` y tenga un tamaño exacto, se realizará una única asignación para el `Arc<[T]>`.Por ejemplo:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Aquí ocurre una sola asignación.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Especialización trait utilizada para recolectar en `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Este es el caso de un iterador `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SEGURIDAD: Necesitamos asegurarnos de que el iterador tenga una longitud exacta y la tenemos.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Vuelva a la implementación normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Obtenga el desplazamiento dentro de un `ArcInner` para la carga útil detrás de un puntero.
///
/// # Safety
///
/// El puntero debe apuntar a (y tener metadatos válidos para) una instancia previamente válida de T, pero se permite descartar la T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Alinee el valor sin tamaño al final de ArcInner.
    // Debido a que RcBox es repr(C), siempre será el último campo en la memoria.
    // SEGURIDAD: dado que los únicos tipos sin tamaño posibles son cortes, objetos trait,
    // y tipos externos, el requisito de seguridad de entrada es actualmente suficiente para satisfacer los requisitos de align_of_val_raw;este es un detalle de implementación del lenguaje en el que no se puede confiar fuera de std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}