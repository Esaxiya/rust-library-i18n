//! El alloc Prelude
//!
//! El propósito de este módulo es aliviar las importaciones de elementos de uso común de `alloc` crate agregando una importación global en la parte superior de los módulos:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;