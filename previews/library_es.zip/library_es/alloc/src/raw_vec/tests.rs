use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Escribir una prueba de integración entre asignadores de terceros y `RawVec` es un poco complicado porque la API `RawVec` no expone métodos de asignación falibles, por lo que no podemos verificar qué sucede cuando se agota el asignador (más allá de detectar un panic).
    //
    //
    // En su lugar, esto solo verifica que los métodos `RawVec` al menos pasen por la API de Allocator cuando reserva almacenamiento.
    //
    //
    //
    //
    //

    // Un asignador tonto que consume una cantidad fija de combustible antes de que los intentos de asignación comiencen a fallar.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (provoca una reasignación, por lo que se utilizan 50 + 150=200 unidades de combustible)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Primero, `reserve` asigna como `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 es más del doble de 7, por lo que `reserve` debería funcionar como `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 es menos de la mitad de 12, por lo que `reserve` debe crecer exponencialmente.
        // En el momento de escribir este artículo, el factor de crecimiento de la prueba es 2, por lo que la nueva capacidad es 24; sin embargo, el factor de crecimiento de 1.5 también está bien.
        //
        // Por lo tanto, `>= 18` en afirmar.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}