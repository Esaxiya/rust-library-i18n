//! API de asignación de memoria

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Estos son los símbolos mágicos para llamar al asignador global.rustc los genera para llamar a `__rg_alloc`, etc.
    // si hay un atributo `#[global_allocator]` (el código que expande esa macro de atributo genera esas funciones), o para llamar a las implementaciones predeterminadas en libstd (`__rdl_alloc`, etc.
    //
    // en `library/std/src/alloc.rs`) de lo contrario.
    // El rustc fork de LLVM también aplica casos especiales a estos nombres de funciones para poder optimizarlos como `malloc`, `realloc` y `free`, respectivamente.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// El asignador de memoria global.
///
/// Este tipo implementa el [`Allocator`] trait reenviando las llamadas al asignador registrado con el atributo `#[global_allocator]` si lo hay, o al `std` crate predeterminado.
///
///
/// Note: si bien este tipo es inestable, se puede acceder a la funcionalidad que proporciona a través del [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Asignar memoria con el asignador global.
///
/// Esta función reenvía las llamadas al método [`GlobalAlloc::alloc`] del asignador registrado con el atributo `#[global_allocator]` si lo hay, o al `std` crate predeterminado.
///
///
/// Se espera que esta función quede obsoleta en favor del método `alloc` del tipo [`Global`] cuando este y el [`Allocator`] trait se estabilicen.
///
/// # Safety
///
/// Ver [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Desasignar memoria con el asignador global.
///
/// Esta función reenvía las llamadas al método [`GlobalAlloc::dealloc`] del asignador registrado con el atributo `#[global_allocator]` si lo hay, o al `std` crate predeterminado.
///
///
/// Se espera que esta función quede obsoleta en favor del método `dealloc` del tipo [`Global`] cuando este y el [`Allocator`] trait se estabilicen.
///
/// # Safety
///
/// Ver [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Reasigne la memoria con el asignador global.
///
/// Esta función reenvía las llamadas al método [`GlobalAlloc::realloc`] del asignador registrado con el atributo `#[global_allocator]` si lo hay, o al `std` crate predeterminado.
///
///
/// Se espera que esta función quede obsoleta en favor del método `realloc` del tipo [`Global`] cuando este y el [`Allocator`] trait se estabilicen.
///
/// # Safety
///
/// Ver [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Asigne memoria inicializada en cero con el asignador global.
///
/// Esta función reenvía las llamadas al método [`GlobalAlloc::alloc_zeroed`] del asignador registrado con el atributo `#[global_allocator]` si lo hay, o al `std` crate predeterminado.
///
///
/// Se espera que esta función quede obsoleta en favor del método `alloc_zeroed` del tipo [`Global`] cuando este y el [`Allocator`] trait se estabilicen.
///
/// # Safety
///
/// Ver [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // SEGURIDAD: `layout` tiene un tamaño distinto de cero,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // SEGURIDAD: Igual que `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // SEGURIDAD: `new_size` no es cero ya que `old_size` es mayor o igual que `new_size`
            // según lo requieran las condiciones de seguridad.La persona que llama debe respetar otras condiciones
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` probablemente busque `new_size >= old_layout.size()` o algo similar.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SEGURIDAD: debido a que `new_layout.size()` debe ser mayor o igual que `old_size`,
            // tanto la asignación de memoria antigua como la nueva son válidas para lecturas y escrituras de `old_size` bytes.
            // Además, debido a que la asignación anterior aún no se desasignó, no puede superponerse a `new_ptr`.
            // Por tanto, la llamada a `copy_nonoverlapping` es segura.
            // La persona que llama debe respetar el contrato de seguridad para `dealloc`.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // SEGURIDAD: `layout` tiene un tamaño distinto de cero,
            // otras condiciones deben ser confirmadas por la persona que llama
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURIDAD: la persona que llama debe respetar todas las condiciones
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURIDAD: la persona que llama debe respetar todas las condiciones
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // SEGURIDAD: la persona que llama debe respetar las condiciones
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // SEGURIDAD: `new_size` no es cero.La persona que llama debe respetar otras condiciones
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` probablemente busque `new_size <= old_layout.size()` o algo similar.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SEGURIDAD: debido a que `new_size` debe ser menor o igual que `old_layout.size()`,
            // tanto la asignación de memoria antigua como la nueva son válidas para lecturas y escrituras de `new_size` bytes.
            // Además, debido a que la asignación anterior aún no se desasignó, no puede superponerse a `new_ptr`.
            // Por tanto, la llamada a `copy_nonoverlapping` es segura.
            // La persona que llama debe respetar el contrato de seguridad para `dealloc`.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// El asignador de punteros únicos.
// Esta función no debe desenrollarse.Si lo hace, el codegen MIR fallará.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Esta firma tiene que ser la misma que `Box`, de lo contrario se producirá un ICE.
// Cuando se agrega un parámetro adicional a `Box` (como `A: Allocator`), esto también debe agregarse aquí.
// Por ejemplo, si `Box` se cambia a `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, esta función también debe cambiarse a `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Controlador de errores de asignación

extern "Rust" {
    // Este es el símbolo mágico para llamar al controlador de errores de asignación global.
    // rustc lo genera para llamar a `__rg_oom` si hay un `#[alloc_error_handler]`, o para llamar a las implementaciones predeterminadas debajo de (`__rdl_oom`) de lo contrario.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Abortar por error o falla de asignación de memoria.
///
/// Se recomienda a las personas que llaman a las API de asignación de memoria que deseen abortar el cálculo en respuesta a un error de asignación que llamen a esta función, en lugar de invocar directamente `panic!` o similar.
///
///
/// El comportamiento predeterminado de esta función es imprimir un mensaje de error estándar y abortar el proceso.
/// Puede ser reemplazado por [`set_alloc_error_hook`] y [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Para la prueba de asignación, `std::alloc::handle_alloc_error` se puede utilizar directamente.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // llamado a través de `__rust_alloc_error_handler` generado

    // si no hay `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // si hay un `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Especialice los clones en memoria preasignada y no inicializada.
/// Utilizado por `Box::clone` y `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Tener asignado *primero* puede permitir que el optimizador cree el valor clonado en el lugar, omitiendo el local y moviéndose.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Siempre podemos copiar en el lugar, sin involucrar nunca un valor local.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}