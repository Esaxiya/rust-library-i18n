#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// El contenido de la nueva memoria no está inicializado.
    Uninitialized,
    /// Se garantiza que la nueva memoria se pondrá a cero.
    Zeroed,
}

/// Una utilidad de bajo nivel para asignar, reasignar y desasignar de manera más ergonómica un búfer de memoria en el montón sin tener que preocuparse por todos los casos de esquina involucrados.
///
/// Este tipo es excelente para construir sus propias estructuras de datos como Vec y VecDeque.
/// En particular:
///
/// * Produce `Unique::dangling()` en tipos de tamaño cero.
/// * Produce `Unique::dangling()` en asignaciones de longitud cero.
/// * Evita liberar `Unique::dangling()`.
/// * Detecta todos los desbordamientos en los cálculos de capacidad (los promueve a "capacity overflow" panics).
/// * Protege contra sistemas de 32 bits que asignan más de isize::MAX bytes.
/// * Protege contra el desbordamiento de su longitud.
/// * Llama a `handle_alloc_error` para asignaciones falibles.
/// * Contiene un `ptr::Unique` y, por lo tanto, otorga al usuario todos los beneficios relacionados.
/// * Utiliza el exceso devuelto por el asignador para utilizar la mayor capacidad disponible.
///
/// Este tipo no inspecciona de ninguna manera la memoria que administra.Cuando se suelte,*liberará* su memoria, pero *no* intentará eliminar su contenido.
/// Depende del usuario de `RawVec` manejar las cosas reales *almacenadas* dentro de un `RawVec`.
///
/// Tenga en cuenta que el exceso de tipos de tamaño cero siempre es infinito, por lo que `capacity()` siempre devuelve `usize::MAX`.
/// Esto significa que debe tener cuidado al realizar un recorrido de ida y vuelta de este tipo con un `Box<[T]>`, ya que `capacity()` no cederá la longitud.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Esto existe porque `#[unstable]` `const fn`s no necesita ajustarse a `min_const_fn` y por lo tanto tampoco se pueden llamar en`min_const_fn`s.
    ///
    /// Si cambia `RawVec<T>::new` o las dependencias, tenga cuidado de no introducir nada que realmente viole `min_const_fn`.
    ///
    /// NOTE: Podríamos evitar este truco y verificar la conformidad con algún atributo `#[rustc_force_min_const_fn]` que requiere conformidad con `min_const_fn` pero no necesariamente permite llamarlo en `stable(...) const fn`/código de usuario que no habilita `foo` cuando `#[rustc_const_unstable(feature = "foo", issue = "01234")]` está presente.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Crea el mayor `RawVec` posible (en el montón del sistema) sin asignar.
    /// Si `T` tiene un tamaño positivo, esto crea un `RawVec` con capacidad `0`.
    /// Si `T` es de tamaño cero, entonces crea un `RawVec` con capacidad `usize::MAX`.
    /// Útil para implementar la asignación retrasada.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Crea un `RawVec` (en el montón del sistema) con exactamente los requisitos de capacidad y alineación para un `[T; capacity]`.
    /// Esto es equivalente a llamar a `RawVec::new` cuando `capacity` es `0` o `T` es de tamaño cero.
    /// Tenga en cuenta que si `T` es de tamaño cero, esto significa que *no* obtendrá un `RawVec` con la capacidad solicitada.
    ///
    /// # Panics
    ///
    /// Panics si la capacidad solicitada supera los `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Se cancela en OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Como `with_capacity`, pero garantiza que el búfer se ponga a cero.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Reconstituye un `RawVec` a partir de un puntero y capacidad.
    ///
    /// # Safety
    ///
    /// El `ptr` debe estar asignado (en el montón del sistema) y con el `capacity` dado.
    /// El `capacity` no puede exceder `isize::MAX` para tipos de tamaño.(solo una preocupación en sistemas de 32 bits).
    /// ZST vectors puede tener una capacidad de hasta `usize::MAX`.
    /// Si el `ptr` y el `capacity` provienen de un `RawVec`, esto está garantizado.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs son tontos.Pasemos a:
    // - 8 si el tamaño del elemento es 1, porque es probable que cualquier asignador de montón redondee una solicitud de menos de 8 bytes a al menos 8 bytes.
    //
    // - 4 si los elementos son de tamaño moderado (<=1 KiB).
    // - 1 de lo contrario, para evitar desperdiciar demasiado espacio para Vecs muy cortos.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Como `new`, pero parametrizado sobre la elección del asignador para el `RawVec` devuelto.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` significa "unallocated".Los tipos de tamaño cero se ignoran.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Como `with_capacity`, pero parametrizado sobre la elección del asignador para el `RawVec` devuelto.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Como `with_capacity_zeroed`, pero parametrizado sobre la elección del asignador para el `RawVec` devuelto.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Convierte un `Box<[T]>` en un `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Convierte todo el búfer en `Box<[MaybeUninit<T>]>` con el `len` especificado.
    ///
    /// Tenga en cuenta que esto reconstituirá correctamente cualquier cambio `cap` que se haya realizado.(Consulte la descripción del tipo para obtener más detalles).
    ///
    /// # Safety
    ///
    /// * `len` debe ser mayor o igual a la capacidad solicitada más recientemente, y
    /// * `len` debe ser menor o igual que `self.capacity()`.
    ///
    /// Tenga en cuenta que la capacidad solicitada y `self.capacity()` podrían diferir, ya que un asignador podría sobreasignar y devolver un bloque de memoria mayor que el solicitado.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Cordura: verifique la mitad del requisito de seguridad (no podemos verificar la otra mitad).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Evitamos `unwrap_or_else` aquí porque aumenta la cantidad de LLVM IR generada.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Reconstituye un `RawVec` a partir de un puntero, capacidad y asignador.
    ///
    /// # Safety
    ///
    /// El `ptr` debe asignarse (a través del asignador `alloc` dado) y con el `capacity` dado.
    /// El `capacity` no puede exceder `isize::MAX` para tipos de tamaño.
    /// (solo una preocupación en sistemas de 32 bits).
    /// ZST vectors puede tener una capacidad de hasta `usize::MAX`.
    /// Si el `ptr` y el `capacity` provienen de un `RawVec` creado a través de `alloc`, entonces esto está garantizado.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Obtiene un puntero sin formato al inicio de la asignación.
    /// Tenga en cuenta que esto es `Unique::dangling()` si `capacity == 0` o `T` es de tamaño cero.
    /// En el primer caso, debes tener cuidado.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Obtiene la capacidad de la asignación.
    ///
    /// Siempre será `usize::MAX` si `T` es de tamaño cero.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Devuelve una referencia compartida al asignador que respalda este `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Tenemos una porción de memoria asignada, por lo que podemos omitir las comprobaciones de tiempo de ejecución para obtener nuestro diseño actual.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Asegura que el búfer contenga al menos suficiente espacio para contener elementos `len + additional`.
    /// Si aún no tiene suficiente capacidad, reasignará suficiente espacio más espacio holgado cómodo para obtener un comportamiento amortizado *O*(1).
    ///
    /// Limitará este comportamiento si se causa innecesariamente a panic.
    ///
    /// Si `len` supera `self.capacity()`, es posible que esto no asigne realmente el espacio solicitado.
    /// Esto no es realmente inseguro, pero el código inseguro *que* escribe que se basa en el comportamiento de esta función puede fallar.
    ///
    /// Esto es ideal para implementar una operación de empuje masivo como `extend`.
    ///
    /// # Panics
    ///
    /// Panics si la nueva capacidad supera los `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Se cancela en OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // reserve habría abortado o entró en pánico si el len excediera `isize::MAX`, por lo que es seguro hacerlo sin marcar ahora.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Lo mismo que `reserve`, pero regresa por errores en lugar de entrar en pánico o abortar.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Asegura que el búfer contenga al menos suficiente espacio para contener elementos `len + additional`.
    /// Si aún no lo ha hecho, reasignará la cantidad mínima posible de memoria necesaria.
    /// Generalmente, esta será exactamente la cantidad de memoria necesaria, pero en principio el asignador es libre de devolver más de lo que pedimos.
    ///
    ///
    /// Si `len` supera `self.capacity()`, es posible que esto no asigne realmente el espacio solicitado.
    /// Esto no es realmente inseguro, pero el código inseguro *que* escribe que se basa en el comportamiento de esta función puede fallar.
    ///
    /// # Panics
    ///
    /// Panics si la nueva capacidad supera los `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Se cancela en OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Lo mismo que `reserve_exact`, pero regresa por errores en lugar de entrar en pánico o abortar.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Reduce la asignación a la cantidad especificada.
    /// Si la cantidad dada es 0, en realidad se desasigna por completo.
    ///
    /// # Panics
    ///
    /// Panics si la cantidad dada es *mayor* que la capacidad actual.
    ///
    /// # Aborts
    ///
    /// Se cancela en OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Devuelve si el búfer necesita crecer para cumplir con la capacidad adicional necesaria.
    /// Se utiliza principalmente para hacer posibles las llamadas de reserva en línea sin `grow` en línea.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Este método generalmente se instancia muchas veces.Por eso queremos que sea lo más pequeño posible, para mejorar los tiempos de compilación.
    // Pero también queremos que la mayor parte de su contenido sea computable estáticamente como sea posible, para que el código generado se ejecute más rápido.
    // Por lo tanto, este método se escribe cuidadosamente para que todo el código que depende de `T` esté dentro de él, mientras que la mayor parte posible del código que no depende de `T` se encuentre en funciones que no son genéricas en `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Esto está asegurado por los contextos de llamada.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Dado que devolvemos una capacidad de `usize::MAX` cuando `elem_size` es
            // 0, llegar hasta aquí necesariamente significa que el `RawVec` está sobrecargado.
            return Err(CapacityOverflow);
        }

        // Lamentablemente, no podemos hacer nada con respecto a estos controles.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Esto garantiza un crecimiento exponencial.
        // La duplicación no puede desbordarse porque `cap <= isize::MAX` y el tipo de `cap` es `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` no es genérico sobre `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Las restricciones de este método son muy parecidas a las de `grow_amortized`, pero este método generalmente se instancia con menos frecuencia, por lo que es menos crítico.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Dado que devolvemos una capacidad de `usize::MAX` cuando el tamaño de letra es
            // 0, llegar hasta aquí necesariamente significa que el `RawVec` está sobrecargado.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` no es genérico sobre `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Esta función está fuera de `RawVec` para minimizar los tiempos de compilación.Consulte el comentario anterior `RawVec::grow_amortized` para obtener más detalles.
// (El parámetro `A` no es significativo, porque la cantidad de tipos `A` diferentes que se ven en la práctica es mucho menor que la cantidad de tipos `T`).
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Compruebe el error aquí para minimizar el tamaño de `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // El asignador comprueba la igualdad de alineación
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Libera la memoria propiedad del `RawVec`*sin* intentar eliminar su contenido.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Función central para el manejo de errores de reserva.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Necesitamos garantizar lo siguiente:
// * Nunca asignamos objetos de tamaño de bytes `> isize::MAX`.
// * No desbordamos `usize::MAX` y de hecho asignamos muy poco.
//
// En 64 bits, solo necesitamos verificar el desbordamiento, ya que intentar asignar `> isize::MAX` bytes seguramente fallará.
// En 32 bits y 16 bits, necesitamos agregar una protección adicional para esto en caso de que estemos ejecutando en una plataforma que puede usar todos los 4 GB en el espacio de usuario, por ejemplo, PAE o x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Una función central responsable de informar sobre los desbordamientos de capacidad.
// Esto asegurará que la generación de código relacionada con estos panics sea mínima, ya que solo hay una ubicación que panics en lugar de un grupo en todo el módulo.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}