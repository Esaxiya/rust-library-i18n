#![stable(feature = "wake_trait", since = "1.51.0")]
//! Tipos y Traits para trabajar con tareas asincrónicas.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// La implementación de despertar una tarea en un ejecutor.
///
/// Este trait se puede utilizar para crear un [`Waker`].
/// Un ejecutor puede definir una implementación de este trait, y usar eso para construir un Waker para pasar a las tareas que se ejecutan en ese ejecutor.
///
/// Este trait es una alternativa ergonómica y segura para la memoria a la construcción de un [`RawWaker`].
/// Admite el diseño de ejecutor común en el que los datos utilizados para activar una tarea se almacenan en un [`Arc`].
/// Algunos ejecutores (especialmente aquellos para sistemas embebidos) no pueden usar esta API, razón por la cual [`RawWaker`] existe como una alternativa para esos sistemas.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Una función básica de `block_on` que toma un future y lo ejecuta hasta su finalización en el hilo actual.
///
/// **Note:** Este ejemplo cambia la corrección por la simplicidad.
/// Para evitar interbloqueos, las implementaciones de nivel de producción también deberán manejar llamadas intermedias a `thread::unpark`, así como invocaciones anidadas.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Un waker que despierta el hilo actual cuando se llama.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Ejecute un future hasta su finalización en el hilo actual.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Fija el future para que se pueda sondear.
///     let mut fut = Box::pin(fut);
///
///     // Cree un nuevo contexto para pasarlo al future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Ejecute future hasta su finalización.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Despierta esta tarea.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Despierta esta tarea sin consumir la vigilia.
    ///
    /// Si un ejecutor admite una forma más económica de despertar sin consumir el despertador, debería anular este método.
    /// De forma predeterminada, clona el [`Arc`] y llama a [`wake`] en el clon.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SEGURIDAD: Esto es seguro porque raw_waker construye de forma segura
        // un RawWaker de Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Se utiliza esta función privada para construir un RawWaker, en lugar de
// al incluir esto en el impl `From<Arc<W>> for RawWaker`, para garantizar que la seguridad de `From<Arc<W>> for Waker` no dependa del despacho correcto de trait, en su lugar, ambos impls llaman a esta función directa y explícitamente.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Incrementa el recuento de referencias del arco para clonarlo.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Despertar por valor, moviendo el Arco a la función Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Despertar por referencia, envolver el despertador en ManuallyDrop para evitar que se caiga
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Disminuir el recuento de referencia del arco al soltar
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}