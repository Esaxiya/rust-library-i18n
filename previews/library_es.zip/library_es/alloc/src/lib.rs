//! # La biblioteca de colecciones y asignación de núcleos Rust
//!
//! Esta biblioteca proporciona punteros y colecciones inteligentes para administrar valores asignados al montón.
//!
//! Esta biblioteca, como libcore, normalmente no necesita usarse directamente ya que su contenido se reexporta en el [`std` crate](../std/index.html).
//! Sin embargo, los Crates que usan el atributo `#![no_std]` normalmente no dependerán de `std`, por lo que usarían este crate en su lugar.
//!
//! ## Valores en caja
//!
//! El tipo [`Box`] es un tipo de puntero inteligente.Solo puede haber un propietario de un [`Box`], y el propietario puede decidir mutar el contenido, que vive en el montón.
//!
//! Este tipo se puede enviar entre subprocesos de manera eficiente ya que el tamaño de un valor `Box` es el mismo que el de un puntero.
//! Las estructuras de datos en forma de árbol a menudo se construyen con cajas porque cada nodo a menudo tiene un solo propietario, el padre.
//!
//! ## Punteros contados de referencia
//!
//! El tipo [`Rc`] es un tipo de puntero de recuento de referencias no seguro para subprocesos destinado a compartir memoria dentro de un subproceso.
//! Un puntero [`Rc`] envuelve un tipo, `T`, y solo permite el acceso a `&T`, una referencia compartida.
//!
//! Este tipo es útil cuando la mutabilidad heredada (como el uso de [`Box`]) es demasiado restrictiva para una aplicación y, a menudo, se combina con los tipos [`Cell`] o [`RefCell`] para permitir la mutación.
//!
//!
//! ## Punteros contados de referencia atómica
//!
//! El tipo [`Arc`] es el equivalente seguro para subprocesos del tipo [`Rc`].Proporciona la misma funcionalidad de [`Rc`], excepto que requiere que el tipo contenido `T` se pueda compartir.
//! Además, [`Arc<T>`][`Arc`] se puede enviar en sí mismo, mientras que [`Rc<T>`][`Rc`] no lo es.
//!
//! Este tipo permite el acceso compartido a los datos contenidos y, a menudo, se combina con primitivas de sincronización como mutex para permitir la mutación de recursos compartidos.
//!
//! ## Collections
//!
//! Las implementaciones de las estructuras de datos de propósito general más comunes se definen en esta biblioteca.Se reexportan a través del [standard collections library](../std/collections/index.html).
//!
//! ## Interfaces de montón
//!
//! El módulo [`alloc`](alloc/index.html) define la interfaz de bajo nivel al asignador global predeterminado.No es compatible con la API de asignación de libc.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Técnicamente, esto es un error en rustdoc: rustdoc ve que la documentación de los bloques `#[lang = slice_alloc]` es para `&[T]`, que también tiene documentación que usa esta característica en `core`, y se enoja porque la puerta de características no está habilitada.
// Idealmente, no buscaría la puerta de funciones para los documentos de otros crates, pero como esto solo puede aparecer para los elementos lang, no parece que valga la pena arreglarlo.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Permitir probar esta biblioteca

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Módulo con macros internas utilizadas por otros módulos (debe incluirse antes que otros módulos).
#[macro_use]
mod macros;

// Montones proporcionados para estrategias de asignación de bajo nivel

pub mod alloc;

// Tipos primitivos usando los montones de arriba

// Es necesario definir condicionalmente el mod de `boxed.rs` para evitar duplicar los elementos de idioma al compilar en cfg de prueba;pero también debe permitir que el código tenga declaraciones `use boxed::Box;`.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}