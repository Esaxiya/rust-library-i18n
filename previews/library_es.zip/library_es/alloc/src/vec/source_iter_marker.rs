use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Marcador de especialización para recopilar una tubería de iterador en un Vec mientras se reutiliza la asignación de origen, es decir
/// ejecutar el oleoducto en su lugar.
///
/// El padre SourceIter trait es necesario para que la función especializada acceda a la asignación que se va a reutilizar.
/// Pero no es suficiente para que la especialización sea válida.
/// Consulte límites adicionales en el impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Los std-internal SourceIter/InPlaceIterable traits solo se implementan mediante cadenas de adaptador <Adapter<Adapter<IntoIter>>> (todo propiedad de core/std).
// Los límites adicionales en las implementaciones del adaptador (más allá de `impl<I: Trait> Trait for Adapter<I>`) solo dependen de otros traits ya marcados como traits de especialización (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. el marcador no depende de la vida útil de los tipos suministrados por el usuario.Modulo the Copy hole, del que ya dependen varias otras especializaciones.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Requisitos adicionales que no se pueden expresar a través de trait bounds.En su lugar, confiamos en const eval:
        // a) sin ZST, ya que no habría asignación para reutilización y la aritmética de puntero sería panic b) el tamaño coincidiría según lo requerido por el contrato de Alloc c) las alineaciones coincidirían según lo requerido por el contrato de Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // respaldo a implementaciones más genéricas
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // use try-fold ya que
        // - se vectoriza mejor para algunos adaptadores de iteradores
        // - a diferencia de la mayoría de los métodos de iteración internos, solo se necesita un auto &mut
        // - nos permite pasar el puntero de escritura a través de sus entrañas y recuperarlo al final
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteración exitosa, no dejes caer la cabeza
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // compruebe si el contrato de SourceIter se mantuvo, advertencia: si no, es posible que ni siquiera lleguemos a este punto
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // comprobar contrato InPlaceIterable.Esto solo es posible si el iterador avanzó el puntero de origen.
        // Si usa un acceso no verificado a través de TrustedRandomAccess, entonces el puntero de la fuente permanecerá en su posición inicial y no podemos usarlo como referencia.
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // eliminar los valores restantes en la cola de la fuente, pero evitar la caída de la asignación en sí una vez que IntoIter sale del alcance si la caída panics, también filtramos los elementos recopilados en dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // el contrato InPlaceIterable no se puede verificar precisamente aquí ya que try_fold tiene una referencia exclusiva al puntero de la fuente, todo lo que podemos hacer es verificar si todavía está dentro del rango
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}