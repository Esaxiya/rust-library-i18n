use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Especialización trait utilizada para Vec::from_iter
///
/// ## El gráfico de delegación:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Un caso común es pasar un vector a una función que se vuelve a recopilar inmediatamente en un vector.
        // Podemos cortocircuitar esto si el IntoIter no se ha avanzado en absoluto.
        // Cuando se ha avanzado también podemos reutilizar la memoria y mover los datos al frente.
        // Pero solo lo hacemos cuando el Vec resultante no tendría más capacidad sin usar que la que tendría crearlo a través de la implementación genérica de FromIterator.
        //
        // Esa limitación no es estrictamente necesaria ya que el comportamiento de asignación de Vec no se especifica intencionalmente.
        // Pero es una elección conservadora.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // debe delegar en spec_extend() ya que el propio extend() delega en spec_from para Vecs vacíos
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Esto utiliza `iterator.as_slice().to_vec()` ya que spec_extend debe tomar más pasos para razonar sobre la capacidad final + longitud y, por lo tanto, hacer más trabajo.
// `to_vec()` asigna directamente la cantidad correcta y la llena exactamente.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): con cfg(test), el método `[T]::to_vec` inherente, que se requiere para esta definición de método, no está disponible.
    // En su lugar, utilice la función `slice::to_vec` que solo está disponible con cfg(test) NB; consulte el módulo slice::hack en slice.rs para obtener más información
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}