//! Un tipo de matriz de crecimiento contiguo con contenido asignado al montón, escrito `Vec<T>`.
//!
//! Los Vectors tienen indexación `O(1)`, empuje `O(1)` amortizado (hasta el final) y pop `O(1)` (desde el final).
//!
//!
//! Vectors se asegura de que nunca asignen más de `isize::MAX` bytes.
//!
//! # Examples
//!
//! Puede crear explícitamente un [`Vec`] con [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... o usando la macro [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // diez ceros
//! ```
//!
//! Puede [`push`] valores al final de un vector (que hará crecer el vector según sea necesario):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Los valores emergentes funcionan de la misma manera:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors también admite la indexación (a través de [`Index`] y [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Un tipo de matriz de crecimiento contiguo, escrito como `Vec<T>` y pronunciado 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// La macro [`vec!`] se proporciona para facilitar la inicialización:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// También puede inicializar cada elemento de un `Vec<T>` con un valor dado.
/// Esto puede ser más eficiente que realizar la asignación y la inicialización en pasos separados, especialmente al inicializar un vector de ceros:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Lo siguiente es equivalente, pero potencialmente más lento:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Para obtener más información, consulte [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Utilice un `Vec<T>` como una pila eficiente:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Imprime 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// El tipo `Vec` permite acceder a valores por índice, ya que implementa el [`Index`] trait.Un ejemplo será más explícito:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // mostrará '2'
/// ```
///
/// Sin embargo, tenga cuidado: si intenta acceder a un índice que no está en el `Vec`, ¡su software panic!No puedes hacer esto:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Utilice [`get`] y [`get_mut`] si desea comprobar si el índice está en `Vec`.
///
/// # Slicing
///
/// Un `Vec` puede ser mutable.Por otro lado, los sectores son objetos de solo lectura.
/// Para obtener un [slice][prim@slice], use [`&`].Ejemplo:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... ¡y eso es todo!
/// // también puedes hacerlo así:
/// let u: &[usize] = &v;
/// // o así:
/// let u: &[_] = &v;
/// ```
///
/// En Rust, es más común pasar segmentos como argumentos en lugar de vectors cuando solo desea proporcionar acceso de lectura.Lo mismo ocurre con [`String`] y [`&str`].
///
/// # Capacidad y reasignación
///
/// La capacidad de un vector es la cantidad de espacio asignada para cualquier elemento future que se agregará al vector.Esto no debe confundirse con la *longitud* de un vector, que especifica el número de elementos reales dentro del vector.
/// Si la longitud de un vector excede su capacidad, su capacidad aumentará automáticamente, pero sus elementos deberán reasignarse.
///
/// Por ejemplo, un vector con capacidad 10 y longitud 0 sería un vector vacío con espacio para 10 elementos más.Empujar 10 o menos elementos en el vector no cambiará su capacidad ni provocará la reasignación.
/// Sin embargo, si la longitud del vector se incrementa a 11, tendrá que reasignarse, lo que puede ser lento.Por esta razón, se recomienda usar [`Vec::with_capacity`] siempre que sea posible para especificar qué tan grande se espera que sea el vector.
///
/// # Guarantees
///
/// Debido a su naturaleza increíblemente fundamental, `Vec` ofrece muchas garantías sobre su diseño.Esto asegura que sea lo más bajo posible en el caso general y que pueda manipularse correctamente de forma primitiva mediante código inseguro.Tenga en cuenta que estas garantías se refieren a un `Vec<T>` no calificado.
/// Si se agregan parámetros de tipo adicionales (por ejemplo, para admitir asignadores personalizados), anular sus valores predeterminados puede cambiar el comportamiento.
///
/// Fundamentalmente, `Vec` es y siempre será un triplete (puntero, capacidad, longitud).Ni mas ni menos.El orden de estos campos no está especificado en absoluto y debe utilizar los métodos adecuados para modificarlos.
/// El puntero nunca será nulo, por lo que este tipo está optimizado para puntero nulo.
///
/// Sin embargo, es posible que el puntero no apunte realmente a la memoria asignada.
/// En particular, si construye un `Vec` con capacidad 0 a través de [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], o llamando a [`shrink_to_fit`] en un Vec vacío, no asignará memoria.De manera similar, si almacena tipos de tamaño cero dentro de un `Vec`, no les asignará espacio.
/// *Tenga en cuenta que, en este caso, es posible que `Vec` no informe un [`capacity`] de 0*.
/// `Vec` asignará si y solo si [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// En general, los detalles de asignación de `Vec` son muy sutiles; si tiene la intención de asignar memoria usando un `Vec` y usarla para otra cosa (ya sea para pasar a código inseguro o para construir su propia colección con respaldo de memoria), asegúrese de para desasignar esta memoria usando `from_raw_parts` para recuperar el `Vec` y luego soltándolo.
///
/// Si un `Vec`*tiene* memoria asignada, entonces la memoria a la que apunta está en el montón (según lo definido por el asignador Rust está configurado para usar de manera predeterminada), y su puntero apunta a [`len`] inicializado, elementos contiguos en orden (lo que haría vea si lo convirtió en un segmento), seguido de [`capacidad`]`,`[`len`] elementos contiguos lógicamente no inicializados.
///
///
/// Un vector que contiene los elementos `'a'` y `'b'` con capacidad 4 se puede visualizar a continuación.La parte superior es la estructura `Vec`, contiene un puntero al encabezado de la asignación en el montón, la longitud y la capacidad.
/// La parte inferior es la asignación en el montón, un bloque de memoria contiguo.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** representa la memoria que no está inicializada, consulte [`MaybeUninit`].
/// - Note: la ABI no es estable y `Vec` no ofrece garantías sobre su distribución de memoria (incluido el orden de los campos).
///
/// `Vec` nunca realizará un "small optimization" donde los elementos estén realmente almacenados en la pila por dos razones:
///
/// * Haría más difícil que el código inseguro manipulara correctamente un `Vec`.El contenido de un `Vec` no tendría una dirección estable si solo se moviera, y sería más difícil determinar si un `Vec` realmente ha asignado memoria.
///
/// * Penalizaría el caso general, incurriendo en un branch adicional en cada acceso.
///
/// `Vec` nunca se encogerá automáticamente, incluso si está completamente vacío.Esto asegura que no se produzcan asignaciones o desasignaciones innecesarias.Vaciar un `Vec` y luego volver a llenarlo hasta el mismo [`len`] no debería generar llamadas al asignador.Si desea liberar memoria no utilizada, utilice [`shrink_to_fit`] o [`shrink_to`].
///
/// [`push`] y [`insert`] nunca (re) asignará si la capacidad informada es suficiente.[`push`] y [`insert`]*se*(re) asignarán si [`len`]`==`[`capacidad`].Es decir, la capacidad informada es completamente precisa y se puede confiar en ella.Incluso se puede utilizar para liberar manualmente la memoria asignada por un `Vec` si se desea.
/// Los métodos de inserción masiva *pueden* reasignarse, incluso cuando no sea necesario.
///
/// `Vec` no garantiza ninguna estrategia de crecimiento en particular cuando se reasigna cuando está lleno, ni cuando se llama a [`reserve`].La estrategia actual es básica y puede resultar conveniente utilizar un factor de crecimiento no constante.Cualquier estrategia que se utilice garantizará, por supuesto,*O*(1) [`push`] amortizado.
///
/// `vec![x; n]`, `vec![a, b, c, d]` y [`Vec::with_capacity(n)`][`Vec::with_capacity`], todos producirán un `Vec` con exactamente la capacidad solicitada.
/// Si [`len`]`==`[`capacidad`], (como es el caso de la macro [`vec!`]), entonces un `Vec<T>` se puede convertir hacia y desde un [`Box<[T]>`][owned slice] sin reasignar o mover los elementos.
///
/// `Vec` no sobrescribirá específicamente ningún dato que se elimine de él, pero tampoco lo preservará específicamente.Su memoria no inicializada es un espacio temporal que puede usar como quiera.Por lo general, solo hará lo que sea más eficiente o fácil de implementar.No confíe en que los datos eliminados se borren por motivos de seguridad.
/// Incluso si deja caer un `Vec`, su búfer simplemente puede ser reutilizado por otro `Vec`.
/// Incluso si primero pone a cero la memoria de un `Vec`, es posible que eso no suceda porque el optimizador no lo considera un efecto secundario que debe conservarse.
/// Sin embargo, hay un caso que no vamos a romper: usar código `unsafe` para escribir hasta el exceso de capacidad y luego aumentar la longitud para igualarlo, siempre es válido.
///
/// Actualmente, `Vec` no garantiza el orden en el que se eliminan los elementos.
/// El orden ha cambiado en el pasado y puede volver a cambiar.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Métodos inherentes
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Construye un nuevo `Vec<T>` vacío.
    ///
    /// El vector no se asignará hasta que se inserten elementos en él.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Construye un nuevo `Vec<T>` vacío con la capacidad especificada.
    ///
    /// El vector podrá contener exactamente elementos `capacity` sin reasignarlos.
    /// Si `capacity` es 0, vector no se asignará.
    ///
    /// Es importante tener en cuenta que aunque el vector devuelto tiene la *capacidad* especificada, el vector tendrá una *longitud* cero.
    ///
    /// Para obtener una explicación de la diferencia entre longitud y capacidad, consulte *[Capacidad y reasignación]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // El vector no contiene elementos, aunque tiene capacidad para más
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Todo esto se hace sin reasignar ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... pero esto puede hacer que el vector se reasigne
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Crea un `Vec<T>` directamente a partir de los componentes sin procesar de otro vector.
    ///
    /// # Safety
    ///
    /// Esto es muy inseguro debido a la cantidad de invariantes que no se marcan:
    ///
    /// * `ptr` debe haber sido asignado previamente a través de [`String`]/`Vec<T>`(al menos, es muy probable que sea incorrecto si no lo fuera).
    /// * `T` debe tener el mismo tamaño y alineación que se asignó al `ptr`.
    ///   (`T` con una alineación menos estricta no es suficiente, la alineación realmente debe ser igual para satisfacer el requisito de [`dealloc`] de que la memoria debe asignarse y desasignarse con el mismo diseño).
    ///
    /// * `length` debe ser menor o igual que `capacity`.
    /// * `capacity` debe ser la capacidad con la que se asignó el puntero.
    ///
    /// La violación de estos puede causar problemas como la corrupción de las estructuras de datos internas del asignador.Por ejemplo,**no** es seguro construir un `Vec<u8>` desde un puntero a una matriz C `char` con longitud `size_t`.
    /// Tampoco es seguro construir uno a partir de un `Vec<u16>` y su longitud, porque el asignador se preocupa por la alineación y estos dos tipos tienen alineaciones diferentes.
    /// El búfer se asignó con la alineación 2 (para `u16`), pero después de convertirlo en un `Vec<u8>`, se desasignará con la alineación 1.
    ///
    /// La propiedad de `ptr` se transfiere efectivamente al `Vec<T>` que luego puede desasignar, reasignar o cambiar el contenido de la memoria apuntado por el puntero a voluntad.
    /// Asegúrese de que nada más use el puntero después de llamar a esta función.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Actualice esto cuando vec_into_raw_parts esté estabilizado.
    ///     // Evite ejecutar el destructor de `v` para que tengamos el control total de la asignación.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Extraiga los diversos datos importantes sobre `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Sobrescribir la memoria con 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Pon todo de nuevo junto en un Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Construye un nuevo `Vec<T, A>` vacío.
    ///
    /// El vector no se asignará hasta que se inserten elementos en él.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Construye un nuevo `Vec<T, A>` vacío con la capacidad especificada con el asignador proporcionado.
    ///
    /// El vector podrá contener exactamente elementos `capacity` sin reasignarlos.
    /// Si `capacity` es 0, vector no se asignará.
    ///
    /// Es importante tener en cuenta que aunque el vector devuelto tiene la *capacidad* especificada, el vector tendrá una *longitud* cero.
    ///
    /// Para obtener una explicación de la diferencia entre longitud y capacidad, consulte *[Capacidad y reasignación]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // El vector no contiene elementos, aunque tiene capacidad para más
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Todo esto se hace sin reasignar ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... pero esto puede hacer que el vector se reasigne
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Crea un `Vec<T, A>` directamente a partir de los componentes sin procesar de otro vector.
    ///
    /// # Safety
    ///
    /// Esto es muy inseguro debido a la cantidad de invariantes que no se marcan:
    ///
    /// * `ptr` debe haber sido asignado previamente a través de [`String`]/`Vec<T>`(al menos, es muy probable que sea incorrecto si no lo fuera).
    /// * `T` debe tener el mismo tamaño y alineación que se asignó al `ptr`.
    ///   (`T` con una alineación menos estricta no es suficiente, la alineación realmente debe ser igual para satisfacer el requisito de [`dealloc`] de que la memoria debe asignarse y desasignarse con el mismo diseño).
    ///
    /// * `length` debe ser menor o igual que `capacity`.
    /// * `capacity` debe ser la capacidad con la que se asignó el puntero.
    ///
    /// La violación de estos puede causar problemas como la corrupción de las estructuras de datos internas del asignador.Por ejemplo,**no** es seguro construir un `Vec<u8>` desde un puntero a una matriz C `char` con longitud `size_t`.
    /// Tampoco es seguro construir uno a partir de un `Vec<u16>` y su longitud, porque el asignador se preocupa por la alineación y estos dos tipos tienen alineaciones diferentes.
    /// El búfer se asignó con la alineación 2 (para `u16`), pero después de convertirlo en un `Vec<u8>`, se desasignará con la alineación 1.
    ///
    /// La propiedad de `ptr` se transfiere efectivamente al `Vec<T>` que luego puede desasignar, reasignar o cambiar el contenido de la memoria apuntado por el puntero a voluntad.
    /// Asegúrese de que nada más use el puntero después de llamar a esta función.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Actualice esto cuando vec_into_raw_parts esté estabilizado.
    ///     // Evite ejecutar el destructor de `v` para que tengamos el control total de la asignación.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Extraiga los diversos datos importantes sobre `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Sobrescribir la memoria con 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Pon todo de nuevo junto en un Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Descompone un `Vec<T>` en sus componentes en bruto.
    ///
    /// Devuelve el puntero sin procesar a los datos subyacentes, la longitud del vector (en elementos) y la capacidad asignada de los datos (en elementos).
    /// Estos son los mismos argumentos en el mismo orden que los argumentos de [`from_raw_parts`].
    ///
    /// Después de llamar a esta función, la persona que llama es responsable de la memoria previamente administrada por el `Vec`.
    /// La única forma de hacer esto es convertir el puntero en bruto, la longitud y la capacidad de nuevo en un `Vec` con la función [`from_raw_parts`], lo que permite que el destructor realice la limpieza.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Ahora podemos realizar cambios en los componentes, como transmutar el puntero sin formato a un tipo compatible.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Descompone un `Vec<T>` en sus componentes en bruto.
    ///
    /// Devuelve el puntero sin procesar a los datos subyacentes, la longitud del vector (en elementos), la capacidad asignada de los datos (en elementos) y el asignador.
    /// Estos son los mismos argumentos en el mismo orden que los argumentos de [`from_raw_parts_in`].
    ///
    /// Después de llamar a esta función, la persona que llama es responsable de la memoria previamente administrada por el `Vec`.
    /// La única forma de hacer esto es convertir el puntero en bruto, la longitud y la capacidad de nuevo en un `Vec` con la función [`from_raw_parts_in`], lo que permite que el destructor realice la limpieza.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Ahora podemos realizar cambios en los componentes, como transmutar el puntero sin formato a un tipo compatible.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Devuelve el número de elementos que vector puede contener sin reasignar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Reserva capacidad para que al menos `additional` más elementos se inserten en el `Vec<T>` dado.
    /// La colección puede reservar más espacio para evitar reasignaciones frecuentes.
    /// Después de llamar a `reserve`, la capacidad será mayor o igual a `self.len() + additional`.
    /// No hace nada si la capacidad ya es suficiente.
    ///
    /// # Panics
    ///
    /// Panics si la nueva capacidad supera los `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Reserva la capacidad mínima para que se inserten exactamente `additional` más elementos en el `Vec<T>` dado.
    ///
    /// Después de llamar a `reserve_exact`, la capacidad será mayor o igual a `self.len() + additional`.
    /// No hace nada si la capacidad ya es suficiente.
    ///
    /// Tenga en cuenta que el asignador puede dar a la colección más espacio del que solicita.
    /// Por lo tanto, no se puede confiar en que la capacidad sea precisamente mínima.
    /// Prefiera `reserve` si se esperan inserciones future.
    ///
    /// # Panics
    ///
    /// Panics si la nueva capacidad rebasa `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Intenta reservar capacidad para que al menos `additional` más elementos se inserten en el `Vec<T>` dado.
    /// La colección puede reservar más espacio para evitar reasignaciones frecuentes.
    /// Después de llamar a `try_reserve`, la capacidad será mayor o igual a `self.len() + additional`.
    /// No hace nada si la capacidad ya es suficiente.
    ///
    /// # Errors
    ///
    /// Si la capacidad se desborda o el asignador informa de una falla, se devuelve un error.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pre-reserve la memoria, saliendo si no podemos
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ahora sabemos que esto no puede OOM en medio de nuestro complejo trabajo
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // muy complicado
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Intenta reservar la capacidad mínima para que se inserten exactamente elementos `additional` en el `Vec<T>` dado.
    /// Después de llamar a `try_reserve_exact`, la capacidad será mayor o igual que `self.len() + additional` si devuelve `Ok(())`.
    ///
    /// No hace nada si la capacidad ya es suficiente.
    ///
    /// Tenga en cuenta que el asignador puede dar a la colección más espacio del que solicita.
    /// Por lo tanto, no se puede confiar en que la capacidad sea precisamente mínima.
    /// Prefiera `reserve` si se esperan inserciones future.
    ///
    /// # Errors
    ///
    /// Si la capacidad se desborda o el asignador informa de una falla, se devuelve un error.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pre-reserve la memoria, saliendo si no podemos
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Ahora sabemos que esto no puede OOM en medio de nuestro complejo trabajo
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // muy complicado
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Reduce la capacidad del vector tanto como sea posible.
    ///
    /// Se desplegará lo más cerca posible de la longitud, pero el asignador aún puede informar al vector que hay espacio para algunos elementos más.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // La capacidad nunca es menor que la longitud, y no hay nada que hacer cuando son iguales, por lo que podemos evitar el caso panic en `RawVec::shrink_to_fit` llamándolo solo con mayor capacidad.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Reduce la capacidad del vector con un límite inferior.
    ///
    /// La capacidad seguirá siendo al menos tan grande como la longitud y el valor suministrado.
    ///
    ///
    /// Si la capacidad actual es menor que el límite inferior, se trata de una operación no operativa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Convierte el vector en [`Box<[T]>`][owned slice].
    ///
    /// Tenga en cuenta que esto reducirá cualquier exceso de capacidad.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Se elimina cualquier exceso de capacidad:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Acorta el vector, conservando los primeros elementos `len` y descartando el resto.
    ///
    /// Si `len` es mayor que la longitud actual del vector, esto no tiene ningún efecto.
    ///
    /// El método [`drain`] puede emular `truncate`, pero hace que los elementos en exceso se devuelvan en lugar de eliminarlos.
    ///
    ///
    /// Tenga en cuenta que este método no tiene ningún efecto sobre la capacidad asignada del vector.
    ///
    /// # Examples
    ///
    /// Truncar un vector de cinco elementos en dos elementos:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// No se produce ningún truncamiento cuando `len` es mayor que la longitud actual de vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Truncar cuando `len == 0` es equivalente a llamar al método [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Esto es seguro porque:
        //
        // * el segmento pasado a `drop_in_place` es válido;el caso `len > self.len` evita la creación de un corte no válido, y
        // * el `len` del vector se reduce antes de llamar a `drop_in_place`, de modo que ningún valor se eliminará dos veces en caso de que `drop_in_place` fuera a panic una vez (si panics dos veces, el programa aborta).
        //
        //
        //
        unsafe {
            // Note: Es intencional que este sea `>` y no `>=`.
            //       Cambiarlo a `>=` tiene implicaciones de rendimiento negativas en algunos casos.
            //       Consulte #78884 para obtener más información.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Extrae un segmento que contiene todo el vector.
    ///
    /// Equivalente a `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Extrae una porción mutable de todo el vector.
    ///
    /// Equivalente a `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Devuelve un puntero sin formato al búfer de vector.
    ///
    /// La persona que llama debe asegurarse de que el vector sobreviva al puntero que devuelve esta función, o de lo contrario terminará apuntando a la basura.
    /// Modificar el vector puede hacer que su búfer sea reasignado, lo que también invalidaría cualquier puntero.
    ///
    /// La persona que llama también debe asegurarse de que la memoria a la que apunta el puntero (non-transitively) nunca se escriba (excepto dentro de un `UnsafeCell`) utilizando este puntero o cualquier puntero derivado de él.
    /// Si necesita mutar el contenido del segmento, use [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Sombreamos el método de corte del mismo nombre para evitar pasar por `deref`, que crea una referencia intermedia.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Devuelve un puntero mutable inseguro al búfer de vector.
    ///
    /// La persona que llama debe asegurarse de que el vector sobreviva al puntero que devuelve esta función, o de lo contrario terminará apuntando a la basura.
    ///
    /// Modificar el vector puede hacer que su búfer sea reasignado, lo que también invalidaría cualquier puntero.
    ///
    /// # Examples
    ///
    /// ```
    /// // Asigne vector lo suficientemente grande para 4 elementos.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Inicialice elementos mediante escrituras de puntero sin procesar, luego establezca la longitud.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Sombreamos el método de corte del mismo nombre para evitar pasar por `deref_mut`, que crea una referencia intermedia.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Devuelve una referencia al asignador subyacente.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Fuerza la longitud del vector a `new_len`.
    ///
    /// Esta es una operación de bajo nivel que no mantiene ninguno de los invariantes normales del tipo.
    /// Normalmente, el cambio de la longitud de un vector se realiza mediante una de las operaciones seguras, como [`truncate`], [`resize`], [`extend`] o [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` debe ser menor o igual que [`capacity()`].
    /// - Los elementos en `old_len..new_len` deben inicializarse.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Este método puede ser útil para situaciones en las que vector sirve como búfer para otro código, particularmente sobre FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Este es solo un esqueleto mínimo para el ejemplo de documento;
    /// # // no use esto como punto de partida para una biblioteca real.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Según los documentos del método FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SEGURIDAD: Cuando `deflateGetDictionary` devuelve `Z_OK`, sostiene que:
    ///     // 1. `dict_length` se inicializaron los elementos.
    ///     // 2.
    ///     // `dict_length` <=la capacidad (32_768) que hace que `set_len` sea seguro para llamar.
    ///     unsafe {
    ///         // Haga la llamada FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... y actualice la longitud a la inicializada.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Si bien el siguiente ejemplo es sólido, hay una pérdida de memoria ya que los vectors internos no se liberaron antes de la llamada `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` está vacío, por lo que no es necesario inicializar ningún elemento.
    /// // 2. `0 <= capacity` siempre contiene lo que sea `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normalmente, aquí, uno usaría [`clear`] en su lugar para eliminar correctamente el contenido y, por lo tanto, no perder memoria.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Elimina un elemento del vector y lo devuelve.
    ///
    /// El elemento eliminado se reemplaza por el último elemento del vector.
    ///
    /// Esto no conserva el orden, pero es O(1).
    ///
    /// # Panics
    ///
    /// Panics si `index` está fuera de los límites.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Reemplazamos self [index] con el último elemento.
            // Tenga en cuenta que si la comprobación de límites anterior tiene éxito, debe haber un último elemento (que puede ser el propio [índice]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Inserta un elemento en la posición `index` dentro del vector, desplazando todos los elementos que le siguen a la derecha.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // espacio para el nuevo elemento
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infalible El lugar para poner el nuevo valor
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Cambia todo para hacer espacio.
                // (Duplicando el elemento `index`th en dos lugares consecutivos).
                ptr::copy(p, p.offset(1), len - index);
                // Escríbalo, sobrescribiendo la primera copia del elemento `index`th.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Elimina y devuelve el elemento en la posición `index` dentro del vector, desplazando todos los elementos que le siguen a la izquierda.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `index` está fuera de los límites.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // el lugar de donde estamos tomando.
                let ptr = self.as_mut_ptr().add(index);
                // cópielo, teniendo inseguramente una copia del valor en la pila y en el vector al mismo tiempo.
                //
                ret = ptr::read(ptr);

                // Cambia todo hacia abajo para llenar ese lugar.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Conserva solo los elementos especificados por el predicado.
    ///
    /// En otras palabras, elimine todos los elementos `e` de modo que `f(&e)` devuelva `false`.
    /// Este método opera en el lugar, visitando cada elemento exactamente una vez en el orden original y preserva el orden de los elementos retenidos.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Debido a que los elementos se visitan exactamente una vez en el orden original, el estado externo puede usarse para decidir qué elementos conservar.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Evite la caída doble si no se ejecuta la protección contra caídas, ya que podemos hacer algunos agujeros durante el proceso.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-len procesado-> |^-junto a comprobar
        //                  | <-cnt eliminado-> |
        //      | <-original_len-> |Guardado: Elementos en los que el predicado devuelve verdadero.
        //
        // Agujero: Ranura de elemento movido o caído.
        // Sin marcar: elementos válidos sin marcar.
        //
        // Esta protección contra caídas se invocará cuando el predicado o `drop` del elemento entre en pánico.
        // Cambia los elementos no controlados para cubrir los agujeros y `set_len` a la longitud correcta.
        // En los casos en que el predicado y el `drop` nunca entren en pánico, se optimizará.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SEGURIDAD: Los elementos que siguen sin marcar deben ser válidos ya que nunca los tocamos.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SEGURIDAD: Después de llenar los orificios, todos los elementos quedan en la memoria contigua.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SEGURIDAD: El elemento sin marcar debe ser válido.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Avance temprano para evitar una doble caída si `drop_in_place` entró en pánico.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SEGURIDAD: Nunca volvemos a tocar este elemento después de la caída.
                unsafe { ptr::drop_in_place(cur) };
                // Ya avanzamos el contador.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SEGURIDAD: `deleted_cnt`> 0, por lo que la ranura del orificio no debe superponerse con el elemento actual.
                // Usamos copiar para mover, y nunca volvemos a tocar este elemento.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Se procesan todos los artículos.Esto se puede optimizar a `set_len` por LLVM.
        drop(g);
    }

    /// Elimina todos los elementos consecutivos del vector, excepto el primero, que se resuelven en la misma clave.
    ///
    ///
    /// Si el vector está ordenado, esto elimina todos los duplicados.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Elimina todos menos el primero de los elementos consecutivos en el vector que satisfacen una relación de igualdad dada.
    ///
    /// A la función `same_bucket` se le pasan referencias a dos elementos del vector y debe determinar si los elementos se comparan igual.
    /// Los elementos se pasan en orden opuesto a su orden en el segmento, por lo que si `same_bucket(a, b)` devuelve `true`, `a` se elimina.
    ///
    ///
    /// Si el vector está ordenado, esto elimina todos los duplicados.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Agrega un elemento al final de una colección.
    ///
    /// # Panics
    ///
    /// Panics si la nueva capacidad supera los `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Esto panic o abortará si asignamos> isize::MAX bytes o si el incremento de longitud se desbordaría para tipos de tamaño cero.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Elimina el último elemento de un vector y lo devuelve, o [`None`] si está vacío.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Mueve todos los elementos de `other` a `Self`, dejando `other` vacío.
    ///
    /// # Panics
    ///
    /// Panics si el número de elementos en el vector desborda un `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Agrega elementos a `Self` desde otro búfer.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Crea un iterador de drenaje que elimina el rango especificado en vector y produce los elementos eliminados.
    ///
    /// Cuando se elimina el iterador ** **, todos los elementos del rango se eliminan del vector, incluso si el iterador no se consumió por completo.
    /// Si el iterador **no** se elimina (con [`mem::forget`] por ejemplo), no se especifica cuántos elementos se eliminan.
    ///
    /// # Panics
    ///
    /// Panics si el punto inicial es mayor que el punto final o si el punto final es mayor que la longitud del vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Una gama completa borra el vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Seguridad de la memoria
        //
        // Cuando se crea el Drain por primera vez, acorta la longitud del vector de origen para asegurarse de que no se pueda acceder a ningún elemento no inicializado o movido si el destructor del Drain nunca llega a ejecutarse.
        //
        //
        // Drain sacará ptr::read los valores para eliminar.
        // Cuando termine, se copia la cola restante del vec para cubrir el agujero, y la longitud vector se restaura a la nueva longitud.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // configure las longitudes de self.vec para comenzar, para estar seguro en caso de que se filtre Drain
            self.set_len(start);
            // Utilice el préstamo en IterMut para indicar el comportamiento de préstamo de todo el iterador Drain (como &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Borra vector, eliminando todos los valores.
    ///
    /// Tenga en cuenta que este método no tiene ningún efecto sobre la capacidad asignada del vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Devuelve el número de elementos del vector, también denominado 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Devuelve `true` si vector no contiene elementos.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Divide la colección en dos en el índice dado.
    ///
    /// Devuelve un vector recién asignado que contiene los elementos en el rango `[at, len)`.
    /// Después de la llamada, se dejará el vector original que contiene los elementos `[0, at)` con su capacidad anterior sin cambios.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // el nuevo vector puede hacerse cargo del búfer original y evitar la copia
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Inseguramente `set_len` y copie elementos a `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Cambia el tamaño del `Vec` en el lugar para que `len` sea igual a `new_len`.
    ///
    /// Si `new_len` es mayor que `len`, `Vec` se extiende por la diferencia, con cada ranura adicional llena con el resultado de llamar al cierre `f`.
    ///
    /// Los valores de retorno de `f` terminarán en `Vec` en el orden en que se generaron.
    ///
    /// Si `new_len` es menor que `len`, `Vec` simplemente se trunca.
    ///
    /// Este método usa un cierre para crear nuevos valores en cada empuje.Si prefiere [`Clone`] un valor dado, use [`Vec::resize`].
    /// Si desea utilizar [`Default`] trait para generar valores, puede pasar [`Default::default`] como segundo argumento.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Consume y filtra el `Vec`, devolviendo una referencia mutable al contenido, `&'a mut [T]`.
    /// Tenga en cuenta que el tipo `T` debe sobrevivir a la vida útil elegida `'a`.
    /// Si el tipo solo tiene referencias estáticas, o ninguna en absoluto, se puede elegir que sea `'static`.
    ///
    /// Esta función es similar a la función [`leak`][Box::leak] en [`Box`], excepto que no hay forma de recuperar la memoria filtrada.
    ///
    ///
    /// Esta función es principalmente útil para los datos que se conservan durante el resto de la vida del programa.
    /// Eliminar la referencia devuelta provocará una pérdida de memoria.
    ///
    /// # Examples
    ///
    /// Uso simple:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Devuelve la capacidad de reserva restante del vector como una porción de `MaybeUninit<T>`.
    ///
    /// El segmento devuelto se puede utilizar para llenar el vector con datos (p. Ej.
    /// leyendo de un archivo) antes de marcar los datos como inicializados utilizando el método [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Asigne vector lo suficientemente grande para 10 elementos.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Complete los primeros 3 elementos.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Marque los primeros 3 elementos del vector como inicializados.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Este método no se implementa en términos de `split_at_spare_mut`, para evitar la invalidación de punteros al búfer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Devuelve el contenido de vector como un segmento de `T`, junto con la capacidad de reserva restante del vector como un segmento de `MaybeUninit<T>`.
    ///
    /// La porción de capacidad de reserva devuelta se puede usar para llenar el vector con datos (por ejemplo, leyendo de un archivo) antes de marcar los datos como inicializados usando el método [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Tenga en cuenta que esta es una API de bajo nivel, que debe usarse con cuidado con fines de optimización.
    /// Si necesita agregar datos a un `Vec`, puede usar [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] o [`resize_with`], según sus necesidades exactas.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Reserve espacio adicional lo suficientemente grande para 10 elementos.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Complete los siguientes 4 elementos.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Marque los 4 elementos del vector como inicializados.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - Len es ignorada y por eso nunca cambia
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Seguridad: cambiar el .2 devuelto (tamaño de &mut) se considera lo mismo que llamar a `.set_len(_)`.
    ///
    /// Este método se utiliza para tener acceso exclusivo a todas las partes vec a la vez en `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` se garantiza que es válido para elementos `len`
        // - `spare_ptr` apunta un elemento más allá del búfer, por lo que no se superpone con `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Cambia el tamaño del `Vec` en el lugar para que `len` sea igual a `new_len`.
    ///
    /// Si `new_len` es mayor que `len`, `Vec` se extiende por la diferencia, con cada ranura adicional llena con `value`.
    ///
    /// Si `new_len` es menor que `len`, `Vec` simplemente se trunca.
    ///
    /// Este método requiere que `T` implemente [`Clone`] para poder clonar el valor pasado.
    /// Si necesita más flexibilidad (o desea confiar en [`Default`] en lugar de [`Clone`]), use [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clona y agrega todos los elementos de un segmento al `Vec`.
    ///
    /// Repite el segmento `other`, clona cada elemento y luego lo agrega a este `Vec`.
    /// El `other` vector se atraviesa en orden.
    ///
    /// Tenga en cuenta que esta función es la misma que [`extend`], excepto que está especializada para trabajar con sectores.
    ///
    /// Si y cuando Rust se especialice, es probable que esta función quede obsoleta (pero aún esté disponible).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Copia elementos del rango `src` al final del vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garantiza que el rango dado es válido para autoindexarse
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Este código generaliza `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Extienda el vector por valores `n`, usando el generador dado.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Use SetLenOnDrop para solucionar el error en el que el compilador puede no darse cuenta de que la tienda a través de `ptr` a través de self.set_len() no tiene alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Escribe todos los elementos excepto el último
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Aumente la longitud en cada paso en caso de que next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Podemos escribir el último elemento directamente sin clonar innecesariamente
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len establecido por el protector de alcance
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Elimina elementos repetidos consecutivos en el vector de acuerdo con la implementación [`PartialEq`] trait.
    ///
    ///
    /// Si el vector está ordenado, esto elimina todos los duplicados.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Métodos y funciones internos
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` debe ser un índice válido
    /// - `self.capacity() - self.len()` debe ser `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len se incrementa solo después de inicializar elementos
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - la persona que llama garantiza que src es un índice válido
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element acaba de inicializarse con `MaybeUninit::write`, por lo que está bien aumentar len
            // - la longitud se aumenta después de cada elemento para evitar fugas (consulte el problema #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - la persona que llama garantiza que `src` es un índice válido
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Ambos punteros se crean a partir de referencias de corte únicas (`&mut [_]`) por lo que son válidos y no se superponen.
            //
            // - Los elementos son: Copiar, por lo que está bien copiarlos, sin hacer nada con los valores originales.
            // - `count` es igual a la longitud de `source`, por lo que la fuente es válida para lecturas `count`
            // - `.reserve(count)` garantiza que `spare.len() >= count` so spare es válido para escrituras `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Los elementos fueron inicializados por `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implementaciones comunes de trait para Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): con cfg(test), el método `[T]::to_vec` inherente, que se requiere para esta definición de método, no está disponible.
    // En su lugar, utilice la función `slice::to_vec` que solo está disponible con cfg(test) NB; consulte el módulo slice::hack en slice.rs para obtener más información
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // suelte cualquier cosa que no se sobrescriba
        self.truncate(other.len());

        // self.len <= other.len debido al truncado anterior, por lo que los cortes aquí siempre están dentro de los límites.
        //
        let (init, tail) = other.split_at(self.len());

        // reutilizar los valores contenidos allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Crea un iterador consumidor, es decir, uno que mueve cada valor fuera del vector (de principio a fin).
    /// El vector no se puede utilizar después de llamar a esto.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s tiene tipo String, no &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // método hoja al que delegan varias implementaciones de SpecFrom/SpecExtend cuando no tienen más optimizaciones para aplicar
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Este es el caso de un iterador general.
        //
        // Esta función debería ser el equivalente moral de:
        //
        //      para el elemento en el iterador {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB no se puede desbordar ya que habríamos tenido que asignar el espacio de direcciones
                self.set_len(len + 1);
            }
        }
    }

    /// Crea un iterador de empalme que reemplaza el rango especificado en el vector con el iterador `replace_with` dado y produce los elementos eliminados.
    ///
    /// `replace_with` no necesita tener la misma longitud que `range`.
    ///
    /// `range` se elimina incluso si el iterador no se consume hasta el final.
    ///
    /// No se especifica cuántos elementos se eliminan del vector si se filtra el valor `Splice`.
    ///
    /// El iterador de entrada `replace_with` solo se consume cuando se elimina el valor `Splice`.
    ///
    /// Esto es óptimo si:
    ///
    /// * La cola (elementos en el vector después de `range`) está vacía,
    /// * o `replace_with` produce menos elementos o iguales que la longitud del "rango"
    /// * o el límite inferior de su `size_hint()` es exacto.
    ///
    /// De lo contrario, se asigna un vector temporal y la cola se mueve dos veces.
    ///
    /// # Panics
    ///
    /// Panics si el punto inicial es mayor que el punto final o si el punto final es mayor que la longitud del vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Crea un iterador que usa un cierre para determinar si un elemento debe eliminarse.
    ///
    /// Si el cierre devuelve verdadero, entonces el elemento se elimina y se entrega.
    /// Si el cierre devuelve falso, el elemento permanecerá en el vector y no será cedido por el iterador.
    ///
    /// El uso de este método es equivalente al siguiente código:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // tu código aquí
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Pero `drain_filter` es más fácil de usar.
    /// `drain_filter` también es más eficiente, porque puede retroceder los elementos de la matriz de forma masiva.
    ///
    /// Tenga en cuenta que `drain_filter` también le permite mutar cada elemento en el cierre del filtro, independientemente de si elige mantenerlo o eliminarlo.
    ///
    ///
    /// # Examples
    ///
    /// Dividir una matriz en pares y probabilidades, reutilizando la asignación original:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Protéjase de que nos filtremos (amplificación de fugas)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Extienda la implementación que copia elementos de las referencias antes de enviarlos a Vec.
///
/// Esta implementación está especializada para iteradores de corte, donde usa [`copy_from_slice`] para agregar el corte completo a la vez.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Implementa la comparación de vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Implementa el pedido de vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // use drop para [T] use un segmento sin procesar para referirse a los elementos del vector como el tipo necesario más débil;
            //
            // podría evitar cuestiones de validez en ciertos casos
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec maneja la desasignación
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Crea un `Vec<T>` vacío.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: prueba extrae libstd, lo que provoca errores aquí
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: prueba extrae libstd, lo que provoca errores aquí
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Obtiene todo el contenido del `Vec<T>` como una matriz, si su tamaño coincide exactamente con el de la matriz solicitada.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Si la longitud no coincide, la entrada vuelve en `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Si está bien con solo obtener un prefijo de `Vec<T>`, puede llamar primero a [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SEGURIDAD: `.set_len(0)` siempre es sólido.
        unsafe { vec.set_len(0) };

        // SEGURIDAD: El puntero de un `Vec` siempre está alineado correctamente, y
        // la alineación que necesita la matriz es la misma que la de los elementos.
        // Verificamos anteriormente que tenemos suficientes artículos.
        // Los elementos no se caerán dos veces ya que el `set_len` le dice al `Vec` que no los deje caer también.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}