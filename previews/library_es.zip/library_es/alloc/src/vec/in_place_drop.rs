use core::ptr::{self};
use core::slice::{self};

// Una estructura auxiliar para la iteración in situ que elimina el segmento de destino de la iteración, es decir, la cabeza.
// IntoIter coloca el segmento de origen (la cola).
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}