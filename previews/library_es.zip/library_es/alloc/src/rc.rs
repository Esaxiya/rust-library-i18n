//! Punteros de recuento de referencias de un solo subproceso.'Rc' son las siglas de 'Referencia
//! Counted'.
//!
//! El tipo [`Rc<T>`][`Rc`] proporciona propiedad compartida de un valor de tipo `T`, asignado en el montón.
//! Invocar [`clone`][clone] en [`Rc`] produce un nuevo puntero a la misma asignación en el montón.
//! Cuando se destruye el último puntero [`Rc`] a una asignación determinada, el valor almacenado en esa asignación (a menudo denominado "inner value") también se elimina.
//!
//! Las referencias compartidas en Rust no permiten la mutación de forma predeterminada, y [`Rc`] no es una excepción: generalmente no se puede obtener una referencia mutable a algo dentro de un [`Rc`].
//! Si necesita mutabilidad, coloque un [`Cell`] o [`RefCell`] dentro del [`Rc`];ver [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] utiliza recuento de referencias no atómicas.
//! Esto significa que la sobrecarga es muy baja, pero no se puede enviar un [`Rc`] entre subprocesos y, en consecuencia, [`Rc`] no implementa [`Send`][send].
//! Como resultado, el compilador Rust comprobará *en el momento de la compilación* que no estás enviando [`Rc`] s entre subprocesos.
//! Si necesita un recuento de referencias atómicas de subprocesos múltiples, utilice [`sync::Arc`][arc].
//!
//! El método [`downgrade`][downgrade] se puede utilizar para crear un puntero [`Weak`] que no sea propietario.
//! Un puntero [`Weak`] se puede [`actualizar`][actualizar] d a un [`Rc`], pero esto devolverá [`None`] si el valor almacenado en la asignación ya se ha eliminado.
//! En otras palabras, los punteros `Weak` no mantienen vivo el valor dentro de la asignación;sin embargo,*mantienen* viva la asignación (el almacén de respaldo para el valor interno).
//!
//! Un ciclo entre punteros [`Rc`] nunca se desasignará.
//! Por esta razón, [`Weak`] se utiliza para romper ciclos.
//! Por ejemplo, un árbol podría tener fuertes punteros [`Rc`] de los nodos principales a los hijos y [`Weak`] de los hijos a sus padres.
//!
//! `Rc<T>` elimina automáticamente las referencias a `T` (a través de [`Deref`] trait), por lo que puede llamar a los métodos de `T` en un valor de tipo [`Rc<T>`][`Rc`].
//! Para evitar conflictos de nombres con los métodos de `T`, los métodos de [`Rc<T>`][`Rc`] en sí son funciones asociadas, llamadas usando [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Las implementaciones de traits como `Clone` también pueden llamarse utilizando una sintaxis totalmente calificada.
//! Algunas personas prefieren utilizar una sintaxis totalmente calificada, mientras que otras prefieren utilizar la sintaxis de llamada a método.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sintaxis de llamada a método
//! let rc2 = rc.clone();
//! // Sintaxis totalmente calificada
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] no autodesreferencia a `T`, porque es posible que el valor interno ya se haya eliminado.
//!
//! # Clonación de referencias
//!
//! La creación de una nueva referencia a la misma asignación que un puntero contado de referencia existente se realiza utilizando el `Clone` trait implementado para [`Rc<T>`][`Rc`] y [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Las dos sintaxis siguientes son equivalentes.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // ayb apuntan a la misma ubicación de memoria que foo.
//! ```
//!
//! La sintaxis `Rc::clone(&from)` es la más idiomática porque transmite más explícitamente el significado del código.
//! En el ejemplo anterior, esta sintaxis hace que sea más fácil ver que este código está creando una nueva referencia en lugar de copiar todo el contenido de foo.
//!
//! # Examples
//!
//! Considere un escenario en el que un conjunto de `Gadget`s pertenece a un `Owner` determinado.
//! Queremos que nuestro `Gadget`s apunte a su `Owner`.No podemos hacer esto con una propiedad única, porque más de un dispositivo puede pertenecer al mismo `Owner`.
//! [`Rc`] nos permite compartir un `Owner` entre múltiples `Gadget`s, y hacer que el `Owner` permanezca asignado siempre que cualquier `Gadget` apunte a él.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ...otros campos
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ...otros campos
//! }
//!
//! fn main() {
//!     // Cree un `Owner` con recuento de referencias.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Crea "Gadget" perteneciente a `gadget_owner`.
//!     // Clonar el `Rc<Owner>` nos da un nuevo puntero a la misma asignación de `Owner`, incrementando el recuento de referencias en el proceso.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Elimine nuestra variable local `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // A pesar de eliminar `gadget_owner`, todavía podemos imprimir el nombre del `Owner` de los `Gadget`s.
//!     // Esto se debe a que solo hemos eliminado un único `Rc<Owner>`, no el `Owner` al que apunta.
//!     // Mientras haya otros `Rc<Owner>` apuntando a la misma asignación `Owner`, permanecerá activo.
//!     // La proyección de campo `gadget1.owner.name` funciona porque `Rc<Owner>` elimina automáticamente las referencias a `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Al final de la función, se destruyen `gadget1` y `gadget2`, y con ellos las últimas referencias contadas a nuestro `Owner`.
//!     // Gadget Man ahora también se destruye.
//!     //
//! }
//! ```
//!
//! Si nuestros requisitos cambian y también necesitamos poder pasar de `Owner` a `Gadget`, tendremos problemas.
//! Un puntero [`Rc`] de `Owner` a `Gadget` introduce un ciclo.
//! Esto significa que sus recuentos de referencias nunca pueden llegar a 0 y la asignación nunca se destruirá:
//! una pérdida de memoria.Para evitar esto, podemos usar punteros [`Weak`].
//!
//! Rust en realidad hace que sea algo difícil producir este bucle en primer lugar.Para terminar con dos valores que se apunten entre sí, uno de ellos debe ser mutable.
//! Esto es difícil porque [`Rc`] refuerza la seguridad de la memoria al dar solo referencias compartidas al valor que envuelve, y estas no permiten la mutación directa.
//! Necesitamos envolver la parte del valor que deseamos mutar en un [`RefCell`], que proporciona *mutabilidad interior*: un método para lograr la mutabilidad a través de una referencia compartida.
//! [`RefCell`] hace cumplir las reglas de préstamo de Rust en tiempo de ejecución.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ...otros campos
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ...otros campos
//! }
//!
//! fn main() {
//!     // Cree un `Owner` con recuento de referencias.
//!     // Tenga en cuenta que hemos puesto el vector del `Owner` de`Gadget`s dentro de un `RefCell` para que podamos mutarlo a través de una referencia compartida.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Cree `Gadget`s perteneciente a `gadget_owner`, como antes.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Agregue los `Gadget`s a su `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` El préstamo dinámico termina aquí.
//!     }
//!
//!     // Repita nuestros `Gadget`s, imprimiendo sus detalles.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` es un `Weak<Gadget>`.
//!         // Dado que los punteros `Weak` no pueden garantizar que la asignación aún exista, debemos llamar a `upgrade`, que devuelve un `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // En este caso, sabemos que la asignación todavía existe, por lo que simplemente `unwrap` el `Option`.
//!         // En un programa más complicado, es posible que necesite un manejo de errores elegante para obtener un resultado `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Al final de la función, `gadget_owner`, `gadget1` y `gadget2` se destruyen.
//!     // Ahora no hay indicadores (`Rc`) fuertes para los dispositivos, por lo que están destruidos.
//!     // Esto pone a cero el recuento de referencias en Gadget Man, por lo que también se destruye.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Esto es de repr(C) a future a prueba de posibles reordenamientos de campo, lo que interferiría con el [into|from]_raw() seguro de tipos internos transmutables.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Un puntero de recuento de referencias de un solo subproceso.'Rc' son las siglas de 'Referencia
/// Counted'.
///
/// Consulte el [module-level documentation](./index.html) para obtener más detalles.
///
/// Los métodos inherentes de `Rc` son todas funciones asociadas, lo que significa que debe llamarlos como, por ejemplo, [`Rc::get_mut(&mut value)`][get_mut] en lugar de `value.get_mut()`.
/// Esto evita conflictos con métodos del tipo interno `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Esta inseguridad está bien porque mientras este Rc esté vivo, tenemos la garantía de que el puntero interno es válido.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Construye un nuevo `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Hay un puntero débil implícito propiedad de todos los punteros fuertes, que asegura que el destructor débil nunca libera la asignación mientras se ejecuta el destructor fuerte, incluso si el puntero débil se almacena dentro del fuerte.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Construye un nuevo `Rc<T>` usando una referencia débil a sí mismo.
    /// Si intenta actualizar la referencia débil antes de que regrese esta función, se obtendrá un valor `None`.
    ///
    /// Sin embargo, la referencia débil se puede clonar libremente y almacenar para su uso en un momento posterior.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... más campos
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Construya el interior en el estado "uninitialized" con una única referencia débil.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Es importante que no cedamos la propiedad del puntero débil, de lo contrario, la memoria podría liberarse cuando regrese `data_fn`.
        // Si realmente quisiéramos pasar la propiedad, podríamos crear un puntero débil adicional para nosotros, pero esto daría como resultado actualizaciones adicionales para el recuento de referencias débiles que podrían no ser necesarias de otra manera.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Las referencias fuertes deben poseer colectivamente una referencia débil compartida, así que no ejecute el destructor para nuestra antigua referencia débil.
        //
        mem::forget(weak);
        strong
    }

    /// Construye un nuevo `Rc` con contenido no inicializado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialización diferida:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construye un nuevo `Rc` con contenido no inicializado, con la memoria llena con `0` bytes.
    ///
    ///
    /// Consulte [`MaybeUninit::zeroed`][zeroed] para ver ejemplos del uso correcto e incorrecto de este método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construye un nuevo `Rc<T>` y devuelve un error si falla la asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Hay un puntero débil implícito propiedad de todos los punteros fuertes, que asegura que el destructor débil nunca libera la asignación mientras se ejecuta el destructor fuerte, incluso si el puntero débil se almacena dentro del fuerte.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Construye un nuevo `Rc` con contenido no inicializado y devuelve un error si falla la asignación
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inicialización diferida:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Construye un nuevo `Rc` con contenido no inicializado, con la memoria llena con `0` bytes, devolviendo un error si falla la asignación
    ///
    ///
    /// Consulte [`MaybeUninit::zeroed`][zeroed] para ver ejemplos del uso correcto e incorrecto de este método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Construye un nuevo `Pin<Rc<T>>`.
    /// Si `T` no implementa `Unpin`, entonces `value` se anclará en la memoria y no se podrá mover.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Devuelve el valor interno, si el `Rc` tiene exactamente una referencia fuerte.
    ///
    /// De lo contrario, se devuelve un [`Err`] con el mismo `Rc` que se pasó.
    ///
    ///
    /// Esto tendrá éxito incluso si hay referencias débiles sobresalientes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // copiar el objeto contenido

                // Indique a los débiles que no se pueden promover disminuyendo el recuento fuerte y luego elimine el puntero "strong weak" implícito mientras también maneja la lógica de caída simplemente creando un débil falso.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Construye un nuevo segmento contado por referencias con contenido no inicializado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialización diferida:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Construye un nuevo segmento contado por referencia con contenido no inicializado, con la memoria llena con `0` bytes.
    ///
    ///
    /// Consulte [`MaybeUninit::zeroed`][zeroed] para ver ejemplos del uso correcto e incorrecto de este método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Convierte a `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Al igual que con [`MaybeUninit::assume_init`], depende de la persona que llama garantizar que el valor interno realmente esté en un estado inicializado.
    ///
    /// Llamar a esto cuando el contenido aún no está completamente inicializado provoca un comportamiento indefinido inmediato.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialización diferida:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Convierte a `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Al igual que con [`MaybeUninit::assume_init`], depende de la persona que llama garantizar que el valor interno realmente esté en un estado inicializado.
    ///
    /// Llamar a esto cuando el contenido aún no está completamente inicializado provoca un comportamiento indefinido inmediato.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialización diferida:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Consume el `Rc`, devolviendo el puntero envuelto.
    ///
    /// Para evitar una pérdida de memoria, el puntero debe volver a convertirse a un `Rc` utilizando [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Proporciona un puntero sin procesar a los datos.
    ///
    /// Los recuentos no se ven afectados de ninguna manera y el `Rc` no se consume.
    /// El puntero es válido mientras haya recuentos fuertes en el `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SEGURIDAD: Esto no puede pasar por Deref::deref o Rc::inner porque
        // esto es necesario para conservar la procedencia raw/mut de manera que, por ejemplo,
        // `get_mut` puede escribir a través del puntero después de que el Rc se recupere a través de `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Construye un `Rc<T>` a partir de un puntero sin formato.
    ///
    /// El puntero sin formato debe haber sido devuelto previamente por una llamada a [`Rc<U>::into_raw`][into_raw] donde `U` debe tener el mismo tamaño y alineación que `T`.
    /// Esto es trivialmente cierto si `U` es `T`.
    /// Tenga en cuenta que si `U` no es `T` pero tiene el mismo tamaño y alineación, esto es básicamente como transmutar referencias de diferentes tipos.
    /// Consulte [`mem::transmute`][transmute] para obtener más información sobre las restricciones que se aplican en este caso.
    ///
    /// El usuario de `from_raw` debe asegurarse de que un valor específico de `T` solo se elimine una vez.
    ///
    /// Esta función no es segura porque el uso inadecuado puede provocar la inseguridad de la memoria, incluso si nunca se accede al `Rc<T>` devuelto.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Convierta nuevamente a un `Rc` para evitar fugas.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Otras llamadas a `Rc::from_raw(x_ptr)` no serían seguras para la memoria.
    /// }
    ///
    /// // La memoria se liberó cuando `x` salió del alcance anterior, ¡por lo que `x_ptr` ahora está colgando!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Invierta el desplazamiento para encontrar el RcBox original.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Crea un nuevo puntero [`Weak`] a esta asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Asegúrese de que no creemos un Débil colgante
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Obtiene el número de punteros [`Weak`] a esta asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Obtiene el número de punteros (`Rc`) potentes para esta asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Devuelve `true` si no hay otros punteros `Rc` o [`Weak`] para esta asignación.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Devuelve una referencia mutable en el `Rc` dado, si no hay otros punteros `Rc` o [`Weak`] a la misma asignación.
    ///
    ///
    /// De lo contrario, devuelve [`None`], porque no es seguro mutar un valor compartido.
    ///
    /// Consulte también [`make_mut`][make_mut], que será [`clone`][clone] el valor interno cuando haya otros punteros.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Devuelve una referencia mutable en el `Rc` dado, sin ninguna verificación.
    ///
    /// Consulte también [`get_mut`], que es seguro y realiza las comprobaciones adecuadas.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Cualquier otro puntero `Rc` o [`Weak`] a la misma asignación no debe desreferenciarse durante la duración del préstamo devuelto.
    ///
    /// Este es trivialmente el caso si no existen tales punteros, por ejemplo, inmediatamente después de `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Tenemos cuidado de *no* crear una referencia que cubra los campos "count", ya que esto entraría en conflicto con los accesos a los recuentos de referencias (p. Ej.
        // por `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Devuelve `true` si los dos `Rc`s apuntan a la misma asignación (en una línea similar a [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Hace una referencia mutable en el `Rc` dado.
    ///
    /// Si hay otros punteros `Rc` a la misma asignación, entonces `make_mut` aplicará [`clone`] el valor interno a una nueva asignación para garantizar la propiedad única.
    /// Esto también se conoce como clonar al escribir.
    ///
    /// Si no hay otros punteros `Rc` para esta asignación, los punteros [`Weak`] para esta asignación se desvincularán.
    ///
    /// Consulte también [`get_mut`], que fallará en lugar de clonar.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // No clonará nada
    /// let mut other_data = Rc::clone(&data);    // No clonará datos internos
    /// *Rc::make_mut(&mut data) += 1;        // Clona datos internos
    /// *Rc::make_mut(&mut data) += 1;        // No clonará nada
    /// *Rc::make_mut(&mut other_data) *= 2;  // No clonará nada
    ///
    /// // Ahora `data` y `other_data` apuntan a diferentes asignaciones.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] los punteros se desvincularán:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Tengo que clonar los datos, hay otros Rcs.
            // Asigne previamente memoria para permitir escribir el valor clonado directamente.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Puede robar los datos, todo lo que queda son débiles
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Elimine la referencia implícita fuerte-débil (no es necesario crear un débil falso aquí, sabemos que otros débiles pueden limpiar por nosotros)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Esta inseguridad está bien porque tenemos la garantía de que el puntero devuelto es el *único* puntero que se devolverá a T.
        // Nuestro recuento de referencias está garantizado en 1 en este punto, y requerimos que el propio `Rc<T>` sea `mut`, por lo que devolvemos la única referencia posible a la asignación.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Intente bajar el `Rc<dyn Any>` a un tipo concreto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Asigna un `RcBox<T>` con espacio suficiente para un valor interno posiblemente sin tamaño donde el valor tiene el diseño proporcionado.
    ///
    /// La función `mem_to_rcbox` se llama con el puntero de datos y debe devolver un puntero (potencialmente gordo) para el `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Calcule el diseño utilizando el diseño de valor dado.
        // Anteriormente, el diseño se calculaba en la expresión `&*(ptr as* const RcBox<T>)`, pero esto creaba una referencia desalineada (ver #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Asigna un `RcBox<T>` con espacio suficiente para un valor interno posiblemente sin tamaño donde el valor tiene el diseño proporcionado, devolviendo un error si falla la asignación.
    ///
    ///
    /// La función `mem_to_rcbox` se llama con el puntero de datos y debe devolver un puntero (potencialmente gordo) para el `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Calcule el diseño utilizando el diseño de valor dado.
        // Anteriormente, el diseño se calculaba en la expresión `&*(ptr as* const RcBox<T>)`, pero esto creaba una referencia desalineada (ver #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Asignar para el diseño.
        let ptr = allocate(layout)?;

        // Inicializar el RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Asigna un `RcBox<T>` con espacio suficiente para un valor interno sin tamaño
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Asigne para el `RcBox<T>` usando el valor dado.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copiar valor como bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Libera la asignación sin dejar caer su contenido
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Asigna un `RcBox<[T]>` con la longitud dada.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Copiar elementos del sector en Rc <\[T\]> recién asignado
    ///
    /// Inseguro porque la persona que llama debe tomar posesión o vincular `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Construye un `Rc<[T]>` a partir de un iterador que se sabe que tiene un tamaño determinado.
    ///
    /// El comportamiento no está definido en caso de que el tamaño sea incorrecto.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Guardia Panic durante la clonación de elementos T.
        // En el caso de un panic, los elementos que se hayan escrito en el nuevo RcBox se eliminarán y luego se liberará la memoria.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Puntero al primer elemento
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Todo claro.Olvídese del guardia para que no libere el nuevo RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Especialización trait utilizada para `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Deja caer el `Rc`.
    ///
    /// Esto disminuirá el recuento de referencias fuertes.
    /// Si el recuento de referencias fuertes llega a cero, las únicas otras referencias (si las hay) son [`Weak`], por lo que `drop` es el valor interno.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // No imprime nada
    /// drop(foo2);   // Imprime "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // destruir el objeto contenido
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // elimine el puntero "strong weak" implícito ahora que hemos destruido el contenido.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Hace un clon del puntero `Rc`.
    ///
    /// Esto crea otro puntero a la misma asignación, aumentando el recuento de referencias fuertes.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Crea un nuevo `Rc<T>`, con el valor `Default` para `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack para permitir la especialización en `Eq` aunque `Eq` tenga un método.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Estamos haciendo esta especialización aquí, y no como una optimización más general en `&T`, porque de lo contrario agregaría un costo a todas las verificaciones de igualdad en las referencias.
/// Suponemos que los `Rc` se utilizan para almacenar valores grandes, que son lentos para clonar, pero también pesados para verificar la igualdad, lo que hace que este costo se amortice más fácilmente.
///
/// También es más probable tener dos clones `Rc`, que apuntan al mismo valor, que dos `&T`s.
///
/// Solo podemos hacer esto cuando `T: Eq` como `PartialEq` puede ser deliberadamente irreflexivo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Igualdad para dos `Rc`s.
    ///
    /// Dos `Rc`s son iguales si sus valores internos son iguales, incluso si están almacenados en una asignación diferente.
    ///
    /// Si `T` también implementa `Eq` (lo que implica reflexividad de igualdad), dos `Rc` que apuntan a la misma asignación son siempre iguales.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Desigualdad para dos `Rc`s.
    ///
    /// Dos `Rc`s son desiguales si sus valores internos son desiguales.
    ///
    /// Si `T` también implementa `Eq` (lo que implica reflexividad de igualdad), dos `Rc` que apuntan a la misma asignación nunca son desiguales.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Comparación parcial de dos "Rc".
    ///
    /// Los dos se comparan llamando a `partial_cmp()` en sus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Comparación menor que para dos `Rc`s.
    ///
    /// Los dos se comparan llamando a `<` en sus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Comparación 'Menor o igual a' para dos 'Rc`s.
    ///
    /// Los dos se comparan llamando a `<=` en sus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Comparación mayor que para dos "Rc".
    ///
    /// Los dos se comparan llamando a `>` en sus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Comparación "mayor o igual a" para dos "Rc".
    ///
    /// Los dos se comparan llamando a `>=` en sus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Comparación de dos `Rc`s.
    ///
    /// Los dos se comparan llamando a `cmp()` en sus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Asigne un segmento contado por referencia y rellénelo clonando los elementos de `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Asigne un segmento de cadena contado por referencia y copie `v` en él.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Asigne un segmento de cadena contado por referencia y copie `v` en él.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Mover un objeto en caja a una nueva asignación contada por referencia.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Asigne un segmento contado por referencia y mueva los elementos de `v` a él.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Permita que el Vec libere su memoria, pero no destruya su contenido
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Toma cada elemento del `Iterator` y lo recopila en un `Rc<[T]>`.
    ///
    /// # Características de presentación
    ///
    /// ## El caso general
    ///
    /// En el caso general, la recopilación en `Rc<[T]>` se realiza primero mediante la recopilación en un `Vec<T>`.Es decir, al escribir lo siguiente:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// esto se comporta como si escribiéramos:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // El primer conjunto de asignaciones ocurre aquí.
    ///     .into(); // Aquí ocurre una segunda asignación para `Rc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Esto asignará tantas veces como sea necesario para construir el `Vec<T>` y luego asignará una vez para convertir el `Vec<T>` en el `Rc<[T]>`.
    ///
    ///
    /// ## Iteradores de longitud conocida
    ///
    /// Cuando su `Iterator` implemente `TrustedLen` y tenga un tamaño exacto, se realizará una única asignación para el `Rc<[T]>`.Por ejemplo:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Aquí ocurre una sola asignación.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Especialización trait utilizada para recolectar en `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Este es el caso de un iterador `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SEGURIDAD: Necesitamos asegurarnos de que el iterador tenga una longitud exacta y la tenemos.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Vuelva a la implementación normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` es una versión de [`Rc`] que contiene una referencia de no propietario a la asignación administrada.Se accede a la asignación llamando a [`upgrade`] en el puntero `Weak`, que devuelve una [`Option`]`<`[`Rc`] `<T>>`.
///
/// Dado que una referencia `Weak` no cuenta para la propiedad, no evitará que se elimine el valor almacenado en la asignación, y el propio `Weak` no garantiza que el valor aún esté presente.
/// Por lo tanto, puede devolver [`None`] cuando [`upgrade`] d.
/// Sin embargo, tenga en cuenta que una referencia `Weak`*no* evita que se desasigne la asignación en sí (la tienda de respaldo).
///
/// Un puntero `Weak` es útil para mantener una referencia temporal a la asignación administrada por [`Rc`] sin evitar que se elimine su valor interno.
/// También se utiliza para evitar referencias circulares entre punteros [`Rc`], ya que las referencias de propiedad mutua nunca permitirían descartar [`Rc`].
/// Por ejemplo, un árbol podría tener fuertes punteros [`Rc`] de los nodos principales a los hijos y `Weak` de los hijos a sus padres.
///
/// La forma típica de obtener un puntero `Weak` es llamar a [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Este es un `NonNull` para permitir optimizar el tamaño de este tipo en enumeraciones, pero no es necesariamente un puntero válido.
    //
    // `Weak::new` establece esto en `usize::MAX` para que no necesite asignar espacio en el montón.
    // Ese no es un valor que tendrá un puntero real porque RcBox tiene una alineación de al menos 2.
    // Esto solo es posible cuando `T: Sized`;`T` sin tamaño nunca cuelga.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Construye un nuevo `Weak<T>`, sin asignar memoria.
    /// Llamar a [`upgrade`] en el valor de retorno siempre da [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Tipo de ayuda para permitir acceder a los recuentos de referencia sin hacer ninguna afirmación sobre el campo de datos.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Devuelve un puntero sin formato al objeto `T` al que apunta este `Weak<T>`.
    ///
    /// El puntero es válido solo si hay algunas referencias sólidas.
    /// El puntero puede estar colgando, desalineado o incluso [`null`] de otra manera.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Ambos apuntan al mismo objeto
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // El fuerte aquí lo mantiene vivo, por lo que aún podemos acceder al objeto.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Pero ya no más.
    /// // Podemos hacer weak.as_ptr(), pero acceder al puntero conduciría a un comportamiento indefinido.
    /// // asert_eq! ("hola", inseguro {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Si el puntero está colgando, devolvemos el centinela directamente.
            // Esta no puede ser una dirección de carga útil válida, ya que la carga útil está al menos tan alineada como RcBox (usize).
            ptr as *const T
        } else {
            // SEGURIDAD: si is_dangling devuelve falso, entonces el puntero es desreferenciable.
            // La carga útil puede caer en este punto, y tenemos que mantener la procedencia, así que use la manipulación del puntero sin procesar.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Consume el `Weak<T>` y lo convierte en un puntero sin formato.
    ///
    /// Esto convierte el puntero débil en un puntero sin formato, al tiempo que conserva la propiedad de una referencia débil (esta operación no modifica el recuento débil).
    /// Se puede convertir de nuevo en el `Weak<T>` con [`from_raw`].
    ///
    /// Se aplican las mismas restricciones de acceso al destino del puntero que con [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Convierte un puntero sin formato creado previamente por [`into_raw`] de nuevo en `Weak<T>`.
    ///
    /// Esto se puede usar para obtener de forma segura una referencia sólida (llamando a [`upgrade`] más tarde) o para desasignar el recuento débil eliminando el `Weak<T>`.
    ///
    /// Se apropia de una referencia débil (con la excepción de los punteros creados por [`new`], ya que estos no poseen nada; el método aún funciona en ellos).
    ///
    /// # Safety
    ///
    /// El puntero debe haberse originado en el [`into_raw`] y aún debe poseer su referencia débil potencial.
    ///
    /// Se permite que el recuento fuerte sea 0 en el momento de llamar a esto.
    /// Sin embargo, esto toma posesión de una referencia débil actualmente representada como un puntero sin formato (el conteo débil no es modificado por esta operación) y por lo tanto debe emparejarse con una llamada previa a [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Disminuye el último recuento débil.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Consulte Weak::as_ptr para obtener un contexto sobre cómo se deriva el puntero de entrada.

        let ptr = if is_dangling(ptr as *mut T) {
            // Este es un Débil colgando.
            ptr as *mut RcBox<T>
        } else {
            // De lo contrario, tenemos la garantía de que el puntero proviene de un Débil que no cuelga.
            // SEGURIDAD: es seguro llamar a data_offset, ya que ptr hace referencia a un T.
            let offset = unsafe { data_offset(ptr) };
            // Por lo tanto, invertimos el desplazamiento para obtener el RcBox completo.
            // SEGURIDAD: el puntero se originó a partir de un Débil, por lo que este desplazamiento es seguro.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SEGURIDAD: ahora hemos recuperado el puntero Débil original, por lo que podemos crear el Puntero Débil.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Intenta actualizar el puntero `Weak` a un [`Rc`], retrasando la caída del valor interno si tiene éxito.
    ///
    ///
    /// Devuelve [`None`] si el valor interno se ha eliminado desde entonces.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Destruye todos los indicadores fuertes.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Obtiene el número de punteros (`Rc`) fuertes que apuntan a esta asignación.
    ///
    /// Si `self` se creó con [`Weak::new`], devolverá 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Obtiene el número de punteros `Weak` que apuntan a esta asignación.
    ///
    /// Si no quedan punteros fuertes, devolverá cero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // restar el ptr débil implícito
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Devuelve `None` cuando el puntero está colgando y no hay `RcBox` asignado (es decir, cuando este `Weak` fue creado por `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Tenemos cuidado de *no* crear una referencia que cubra el campo "data", ya que el campo puede mutarse al mismo tiempo (por ejemplo, si se elimina el último `Rc`, el campo de datos se colocará en el lugar).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Devuelve `true` si los dos `Débiles apuntan a la misma asignación (similar a [`ptr::eq`]), o si ambos no apuntan a ninguna asignación (porque fueron creados con `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Dado que esto compara punteros, significa que `Weak::new()` se igualarán entre sí, aunque no apunten a ninguna asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparando `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Suelta el puntero `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // No imprime nada
    /// drop(foo);        // Imprime "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // la cuenta débil comienza en 1 y solo llegará a cero si todos los indicadores fuertes han desaparecido.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Hace un clon del puntero `Weak` que apunta a la misma asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Construye un nuevo `Weak<T>`, asignando memoria para `T` sin inicializarlo.
    /// Llamar a [`upgrade`] en el valor de retorno siempre da [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Verificamos_add aquí para tratar con mem::forget de manera segura.En particular
// si mem::forget Rcs (o Débiles), el recuento de referencias puede desbordarse, y luego puede liberar la asignación mientras existan Rcs (o Débiles) pendientes.
//
// Abortamos porque este es un escenario tan degenerado que no nos importa lo que suceda; ningún programa real debería experimentar esto.
//
// Esto debería tener una sobrecarga insignificante, ya que en realidad no es necesario clonarlos mucho en Rust gracias a la propiedad y la semántica de movimiento.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Queremos abortar por desbordamiento en lugar de eliminar el valor.
        // El recuento de referencia nunca será cero cuando se llame a esto;
        // no obstante, insertamos un aborto aquí para sugerir a LLVM una optimización que de otro modo se hubiera perdido.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Queremos abortar por desbordamiento en lugar de eliminar el valor.
        // El recuento de referencia nunca será cero cuando se llame a esto;
        // no obstante, insertamos un aborto aquí para sugerir a LLVM una optimización que de otro modo se hubiera perdido.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Obtenga el desplazamiento dentro de un `RcBox` para la carga útil detrás de un puntero.
///
/// # Safety
///
/// El puntero debe apuntar a (y tener metadatos válidos para) una instancia previamente válida de T, pero se permite descartar la T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Alinee el valor sin tamaño al final de RcBox.
    // Debido a que RcBox es repr(C), siempre será el último campo en la memoria.
    // SEGURIDAD: dado que los únicos tipos sin tamaño posibles son cortes, objetos trait,
    // y tipos externos, el requisito de seguridad de entrada es actualmente suficiente para satisfacer los requisitos de align_of_val_raw;este es un detalle de implementación del lenguaje en el que no se puede confiar fuera de std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}