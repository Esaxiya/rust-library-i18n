//! Una cadena que puede crecer con codificación UTF-8.
//!
//! Este módulo contiene el tipo [`String`], el [`ToString`] trait para convertir a cadenas y varios tipos de errores que pueden resultar de trabajar con [`String`] s.
//!
//!
//! # Examples
//!
//! Hay varias formas de crear un nuevo [`String`] a partir de un literal de cadena:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Puede crear un nuevo [`String`] a partir de uno existente concatenando con
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Si tiene un vector de UTF-8 bytes válidos, puede convertirlo en un [`String`].También puedes hacer lo contrario.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Sabemos que estos bytes son válidos, por lo que usaremos `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Una cadena que puede crecer con codificación UTF-8.
///
/// El tipo `String` es el tipo de cadena más común que tiene propiedad sobre el contenido de la cadena.Tiene una estrecha relación con su homólogo prestado, el primitivo [`str`].
///
/// # Examples
///
/// Puede crear un `String` a partir de [a literal string][`str`] con [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Puede agregar un [`char`] a un `String` con el método [`push`] y agregar un [`&str`] con el método [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Si tiene un vector de UTF-8 bytes, puede crear un `String` a partir de él con el método [`from_utf8`]:
///
/// ```
/// // algunos bytes, en un vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Sabemos que estos bytes son válidos, por lo que usaremos `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// Las cadenas de caracteres son siempre válidas UTF-8.Esto tiene algunas implicaciones, la primera de las cuales es que si necesita una cadena que no sea UTF-8, considere [`OsString`].Es similar, pero sin la restricción UTF-8.La segunda implicación es que no puede indexar en un `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// La indexación está destinada a ser una operación de tiempo constante, pero la codificación UTF-8 no nos permite hacer esto.Además, no está claro qué tipo de cosa debería devolver el índice: un byte, un punto de código o un grupo de grafemas.
/// Los métodos [`bytes`] y [`chars`] devuelven iteradores sobre los dos primeros, respectivamente.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `Implementación de cadenas [` Deref`]`<Target=str>`, por lo que hereda todos los métodos de [` str`].Además, esto significa que puede pasar un `String` a una función que toma un [`&str`] usando un ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Esto creará un [`&str`] a partir del `String` y lo pasará. Esta conversión es muy económica y, por lo general, las funciones aceptarán [`&str`] s como argumentos a menos que necesiten un `String` por alguna razón específica.
///
/// En ciertos casos, Rust no tiene suficiente información para realizar esta conversión, conocida como coerción [`Deref`].En el siguiente ejemplo, un segmento de cadena [`&'a str`][`&str`] implementa trait `TraitExample`, y la función `example_func` toma cualquier cosa que implemente trait.
/// En este caso, Rust necesitaría realizar dos conversiones implícitas, que Rust no tiene los medios para hacer.
/// Por esa razón, el siguiente ejemplo no se compilará.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Hay dos opciones que funcionarían en su lugar.La primera sería cambiar la línea `example_func(&example_string);` a `example_func(example_string.as_str());`, utilizando el método [`as_str()`] para extraer explícitamente el segmento de cadena que contiene la cadena.
/// La segunda forma cambia `example_func(&example_string);` a `example_func(&*example_string);`.
/// En este caso, estamos eliminando la referencia de un `String` a un [`str`][`&str`] y luego volvemos a referenciar el [`str`][`&str`] a [`&str`].
/// La segunda forma es más idiomática, sin embargo, ambos trabajan para hacer la conversión explícitamente en lugar de depender de la conversión implícita.
///
/// # Representation
///
/// Un `String` se compone de tres componentes: un puntero a algunos bytes, una longitud y una capacidad.El puntero apunta a un búfer interno que `String` usa para almacenar sus datos.La longitud es el número de bytes almacenados actualmente en el búfer y la capacidad es el tamaño del búfer en bytes.
///
/// Como tal, la longitud siempre será menor o igual que la capacidad.
///
/// Este búfer siempre se almacena en el montón.
///
/// Puede verlos con los métodos [`as_ptr`], [`len`] y [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Actualice esto cuando vec_into_raw_parts esté estabilizado.
/// // Evitar que se caigan automáticamente los datos de la cadena
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // la historia tiene diecinueve bytes
/// assert_eq!(19, len);
///
/// // Podemos reconstruir un String a partir de ptr, len y capacity.
/// // Todo esto no es seguro porque somos responsables de asegurarnos de que los componentes sean válidos:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Si un `String` tiene suficiente capacidad, agregarle elementos no se reasignará.Por ejemplo, considere este programa:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Esto generará lo siguiente:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Al principio, no tenemos ninguna memoria asignada, pero a medida que agregamos a la cadena, aumenta su capacidad de manera adecuada.Si en cambio usamos el método [`with_capacity`] para asignar la capacidad correcta inicialmente:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Terminamos con una salida diferente:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Aquí, no es necesario asignar más memoria dentro del ciclo.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Un posible valor de error al convertir un `String` de un byte UTF-8 vector.
///
/// Este tipo es el tipo de error para el método [`from_utf8`] en [`String`].
/// Está diseñado de tal manera que evita cuidadosamente las reasignaciones: el método [`into_bytes`] devolverá el byte vector que se utilizó en el intento de conversión.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// El tipo [`Utf8Error`] proporcionado por [`std::str`] representa un error que puede ocurrir al convertir un segmento de [`u8`] sa un [`&str`].
/// En este sentido, es un análogo a `FromUtf8Error`, y puede obtener uno de un `FromUtf8Error` a través del método [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// // algunos bytes inválidos, en un vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Un posible valor de error al convertir un `String` de un segmento de bytes UTF-16.
///
/// Este tipo es el tipo de error para el método [`from_utf16`] en [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Uso básico:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Crea un nuevo `String` vacío.
    ///
    /// Dado que el `String` está vacío, esto no asignará ningún búfer inicial.Si bien eso significa que esta operación inicial es muy económica, puede causar una asignación excesiva más adelante cuando agregue datos.
    ///
    /// Si tiene una idea de la cantidad de datos que almacenará el `String`, considere el método [`with_capacity`] para evitar una reasignación excesiva.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Crea un nuevo `String` vacío con una capacidad particular.
    ///
    /// Las cadenas tienen un búfer interno para almacenar sus datos.
    /// La capacidad es la longitud de ese búfer y se puede consultar con el método [`capacity`].
    /// Este método crea un `String` vacío, pero uno con un búfer inicial que puede contener `capacity` bytes.
    /// Esto es útil cuando puede agregar una gran cantidad de datos al `String`, lo que reduce la cantidad de reasignaciones que necesita hacer.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Si la capacidad dada es `0`, no se realizará ninguna asignación y este método es idéntico al método [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // La cadena no contiene caracteres, aunque tiene capacidad para más
    /// assert_eq!(s.len(), 0);
    ///
    /// // Todo esto se hace sin reasignar ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... pero esto puede hacer que la cadena se reasigne
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): con cfg(test), el método `[T]::to_vec` inherente, que se requiere para esta definición de método, no está disponible.
    // Dado que no requerimos este método para fines de prueba, simplemente lo cortaré NB, consulte el módulo slice::hack en slice.rs para obtener más información
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Convierte un vector de bytes en un `String`.
    ///
    /// Una cadena ([`String`]) está formada por bytes ([`u8`]) y un vector de bytes ([`Vec<u8>`]) está formada por bytes, por lo que esta función convierte entre los dos.
    /// No todos los segmentos de bytes son `String`s válidos, sin embargo: `String` requiere que sea UTF-8 válido.
    /// `from_utf8()` comprueba que los bytes sean UTF-8 válidos y luego realiza la conversión.
    ///
    /// Si está seguro de que el segmento de bytes es UTF-8 válido y no desea incurrir en la sobrecarga de la verificación de validez, existe una versión insegura de esta función, [`from_utf8_unchecked`], que tiene el mismo comportamiento pero omite la verificación.
    ///
    ///
    /// Este método se encargará de no copiar el vector, en aras de la eficiencia.
    ///
    /// Si necesita un [`&str`] en lugar de un `String`, considere [`str::from_utf8`].
    ///
    /// El inverso de este método es [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Devuelve [`Err`] si el segmento no es UTF-8 con una descripción de por qué los bytes proporcionados no son UTF-8.El vector al que te mudaste también está incluido.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // algunos bytes, en un vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Sabemos que estos bytes son válidos, por lo que usaremos `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bytes incorrectos:
    ///
    /// ```
    /// // algunos bytes inválidos, en un vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Consulte los documentos de [`FromUtf8Error`] para obtener más detalles sobre lo que puede hacer con este error.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Convierte un segmento de bytes en una cadena, incluidos los caracteres no válidos.
    ///
    /// Las cadenas están formadas por bytes ([`u8`]) y una porción de bytes ([`&[u8]`][byteslice]) está formada por bytes, por lo que esta función convierte entre los dos.Sin embargo, no todos los segmentos de bytes son cadenas válidas: las cadenas deben ser UTF-8 válidas.
    /// Durante esta conversión, `from_utf8_lossy()` reemplazará cualquier secuencia UTF-8 no válida con [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], que se ve así:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Si está seguro de que el segmento de bytes es UTF-8 válido y no desea incurrir en la sobrecarga de la conversión, existe una versión insegura de esta función, [`from_utf8_unchecked`], que tiene el mismo comportamiento pero omite las comprobaciones.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Esta función devuelve un [`Cow<'a, str>`].Si nuestro segmento de bytes no es válido UTF-8, entonces necesitamos insertar los caracteres de reemplazo, lo que cambiará el tamaño de la cadena y, por lo tanto, requerirá un `String`.
    /// Pero si ya es UTF-8 válido, no necesitamos una nueva asignación.
    /// Este tipo de retorno nos permite manejar ambos casos.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // algunos bytes, en un vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bytes incorrectos:
    ///
    /// ```
    /// // algunos bytes inválidos
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Decodifique un vector `v` codificado en UTF-16 en un `String` y devuelva [`Err`] si `v` contiene datos no válidos.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Esto no se hace a través de recopilar: <Result<_, _>> () por motivos de rendimiento.
        // FIXME: la función se puede simplificar nuevamente cuando #48994 está cerrado.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Decodifique un segmento `v` codificado en UTF-16 en un `String`, reemplazando los datos no válidos con [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// A diferencia de [`from_utf8_lossy`] que devuelve un [`Cow<'a, str>`], `from_utf16_lossy` devuelve un `String` ya que la conversión de UTF-16 a UTF-8 requiere una asignación de memoria.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Descompone un `String` en sus componentes en bruto.
    ///
    /// Devuelve el puntero sin procesar a los datos subyacentes, la longitud de la cadena (en bytes) y la capacidad asignada de los datos (en bytes).
    /// Estos son los mismos argumentos en el mismo orden que los argumentos de [`from_raw_parts`].
    ///
    /// Después de llamar a esta función, la persona que llama es responsable de la memoria previamente administrada por el `String`.
    /// La única forma de hacer esto es convertir el puntero en bruto, la longitud y la capacidad de nuevo en un `String` con la función [`from_raw_parts`], lo que permite que el destructor realice la limpieza.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Crea un nuevo `String` a partir de una longitud, capacidad y puntero.
    ///
    /// # Safety
    ///
    /// Esto es muy inseguro debido a la cantidad de invariantes que no se marcan:
    ///
    /// * La memoria en `buf` debe haber sido asignada previamente por el mismo asignador que usa la biblioteca estándar, con una alineación requerida de exactamente 1.
    /// * `length` debe ser menor o igual que `capacity`.
    /// * `capacity` debe ser el valor correcto.
    /// * Los primeros bytes `length` en `buf` deben ser UTF-8 válidos.
    ///
    /// La violación de estos puede causar problemas como la corrupción de las estructuras de datos internas del asignador.
    ///
    /// La propiedad de `buf` se transfiere efectivamente al `String` que luego puede desasignar, reasignar o cambiar el contenido de la memoria apuntado por el puntero a voluntad.
    /// Asegúrese de que nada más use el puntero después de llamar a esta función.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Actualice esto cuando vec_into_raw_parts esté estabilizado.
    ///     // Evitar que se caigan automáticamente los datos de la cadena
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Convierte un vector de bytes en un `String` sin comprobar que la cadena contiene un UTF-8 válido.
    ///
    /// Consulte la versión segura, [`from_utf8`], para obtener más detalles.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Esta función no es segura porque no comprueba que los bytes que se le pasan sean UTF-8 válidos.
    /// Si se viola esta restricción, puede causar problemas de inseguridad en la memoria con los usuarios de future del `String`, ya que el resto de la biblioteca estándar asume que los `String`s son UTF-8 válidos.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // algunos bytes, en un vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Convierte un `String` en un byte vector.
    ///
    /// Esto consume el `String`, por lo que no necesitamos copiar su contenido.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Extrae un segmento de cadena que contiene todo el `String`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Convierte un `String` en un segmento de cuerda mutable.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Agrega un segmento de cadena determinado al final de este `String`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Devuelve la capacidad de este `String`, en bytes.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Asegura que la capacidad de esta "Cadena" sea al menos `additional` bytes mayor que su longitud.
    ///
    /// La capacidad puede aumentarse en más de `additional` bytes si así lo desea, para evitar reasignaciones frecuentes.
    ///
    ///
    /// Si no desea este comportamiento "at least", consulte el método [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics si la nueva capacidad rebasa [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Es posible que esto no aumente la capacidad:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ahora tiene una longitud de 2 y una capacidad de 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Como ya tenemos una capacidad extra de 8, llamando a esto ...
    /// s.reserve(8);
    ///
    /// // ... en realidad no aumenta.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Asegura que la capacidad de esta "Cadena" sea `additional` bytes mayor que su longitud.
    ///
    /// Considere usar el método [`reserve`] a menos que sepa absolutamente mejor que el asignador.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics si la nueva capacidad rebasa `usize`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Es posible que esto no aumente la capacidad:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ahora tiene una longitud de 2 y una capacidad de 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Como ya tenemos una capacidad extra de 8, llamando a esto ...
    /// s.reserve_exact(8);
    ///
    /// // ... en realidad no aumenta.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Intenta reservar capacidad para que al menos `additional` más elementos se inserten en el `String` dado.
    /// La colección puede reservar más espacio para evitar reasignaciones frecuentes.
    /// Después de llamar a `reserve`, la capacidad será mayor o igual a `self.len() + additional`.
    /// No hace nada si la capacidad ya es suficiente.
    ///
    /// # Errors
    ///
    /// Si la capacidad se desborda o el asignador informa de una falla, se devuelve un error.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pre-reserve la memoria, saliendo si no podemos
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ahora sabemos que esto no puede OOM en medio de nuestro complejo trabajo
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Intenta reservar la capacidad mínima para que se inserten exactamente `additional` más elementos en el `String` dado.
    ///
    /// Después de llamar a `reserve_exact`, la capacidad será mayor o igual a `self.len() + additional`.
    /// No hace nada si la capacidad ya es suficiente.
    ///
    /// Tenga en cuenta que el asignador puede dar a la colección más espacio del que solicita.
    /// Por lo tanto, no se puede confiar en que la capacidad sea precisamente mínima.
    /// Prefiera `reserve` si se esperan inserciones future.
    ///
    /// # Errors
    ///
    /// Si la capacidad se desborda o el asignador informa de una falla, se devuelve un error.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pre-reserve la memoria, saliendo si no podemos
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ahora sabemos que esto no puede OOM en medio de nuestro complejo trabajo
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Reduce la capacidad de este `String` para que coincida con su longitud.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Reduce la capacidad de este `String` con un límite inferior.
    ///
    /// La capacidad seguirá siendo al menos tan grande como la longitud y el valor suministrado.
    ///
    ///
    /// Si la capacidad actual es menor que el límite inferior, se trata de una operación no operativa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Agrega el [`char`] dado al final de este `String`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Devuelve un segmento de bytes del contenido de esta `Cadena`.
    ///
    /// El inverso de este método es [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Acorta este `String` a la longitud especificada.
    ///
    /// Si `new_len` es mayor que la longitud actual de la cadena, esto no tiene ningún efecto.
    ///
    ///
    /// Tenga en cuenta que este método no tiene ningún efecto sobre la capacidad asignada de la cadena
    ///
    /// # Panics
    ///
    /// Panics si `new_len` no se encuentra en un límite [`char`].
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Elimina el último carácter del búfer de cadena y lo devuelve.
    ///
    /// Devuelve [`None`] si este `String` está vacío.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Elimina un [`char`] de este `String` en una posición de byte y lo devuelve.
    ///
    /// Esta es una operación *O*(*n*), ya que requiere copiar todos los elementos del búfer.
    ///
    /// # Panics
    ///
    /// Panics si `idx` es mayor o igual que la longitud de la `Cadena`, o si no se encuentra en un límite [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Elimine todas las coincidencias del patrón `pat` en el `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Las coincidencias se detectarán y eliminarán de forma iterativa, por lo que en los casos en que los patrones se superponen, solo se eliminará el primer patrón:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SEGURIDAD: el inicio y el final estarán en los límites de bytes utf8 por
        // los documentos del buscador
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Conserva solo los caracteres especificados por el predicado.
    ///
    /// En otras palabras, elimine todos los caracteres `c` de modo que `f(c)` devuelva `false`.
    /// Este método funciona en el lugar, visitando cada carácter exactamente una vez en el orden original y conserva el orden de los caracteres retenidos.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// El orden exacto puede ser útil para rastrear el estado externo, como un índice.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Apunta idx al siguiente carácter
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Inserta un carácter en este `String` en una posición de byte.
    ///
    /// Esta es una operación *O*(*n*) ya que requiere copiar cada elemento en el búfer.
    ///
    /// # Panics
    ///
    /// Panics si `idx` es mayor que la longitud de la `Cadena`, o si no se encuentra en un límite [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Inserta un segmento de cadena en este `String` en una posición de byte.
    ///
    /// Esta es una operación *O*(*n*) ya que requiere copiar cada elemento en el búfer.
    ///
    /// # Panics
    ///
    /// Panics si `idx` es mayor que la longitud de la `Cadena`, o si no se encuentra en un límite [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Devuelve una referencia mutable al contenido de este `String`.
    ///
    /// # Safety
    ///
    /// Esta función no es segura porque no comprueba que los bytes que se le pasan sean UTF-8 válidos.
    /// Si se viola esta restricción, puede causar problemas de inseguridad en la memoria con los usuarios de future del `String`, ya que el resto de la biblioteca estándar asume que los `String`s son UTF-8 válidos.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Devuelve la longitud de este `String`, en bytes, no en [`char`] so grafemas.
    /// En otras palabras, puede que no sea lo que un humano considera la longitud de la cuerda.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Devuelve `true` si este `String` tiene una longitud de cero y `false` en caso contrario.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Divide la cadena en dos en el índice de bytes dado.
    ///
    /// Devuelve un `String` recién asignado.
    /// `self` contiene los bytes `[0, at)` y el `String` devuelto contiene los bytes `[at, len)`.
    /// `at` debe estar en el límite de un punto de código UTF-8.
    ///
    /// Tenga en cuenta que la capacidad de `self` no cambia.
    ///
    /// # Panics
    ///
    /// Panics si `at` no está en un límite de punto de código `UTF-8`, o si está más allá del último punto de código de la cadena.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Trunca este `String`, eliminando todo el contenido.
    ///
    /// Si bien esto significa que el `String` tendrá una longitud de cero, no toca su capacidad.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Crea un iterador de drenaje que elimina el rango especificado en el `String` y produce el `chars` eliminado.
    ///
    ///
    /// Note: El rango de elementos se elimina incluso si el iterador no se consume hasta el final.
    ///
    /// # Panics
    ///
    /// Panics si el punto de inicio o el punto final no se encuentran en un límite [`char`], o si están fuera de los límites.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Retire el rango hacia arriba hasta el β de la cadena
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Un rango completo borra la cuerda
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Seguridad de la memoria
        //
        // La versión String de Drain no tiene los problemas de seguridad de memoria de la versión vector.
        // Los datos son simplemente bytes.
        // Debido a que la eliminación del rango ocurre en Drop, si se filtra el iterador Drain, la eliminación no sucederá.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Obtenga dos préstamos simultáneos.
        // No se accederá a la cadena &mut hasta que finalice la iteración, en Drop.
        let self_ptr = self as *mut _;
        // SEGURIDAD: `slice::range` y `is_char_boundary` realizan las comprobaciones de límites correspondientes.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Elimina el rango especificado en la cadena y lo reemplaza con la cadena dada.
    /// La cadena dada no necesita tener la misma longitud que el rango.
    ///
    /// # Panics
    ///
    /// Panics si el punto de inicio o el punto final no se encuentran en un límite [`char`], o si están fuera de los límites.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Reemplaza el rango hasta el β de la cadena
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Seguridad de la memoria
        //
        // Replace_range no tiene los problemas de seguridad de memoria de un empalme vector.
        // de la versión vector.Los datos son simplemente bytes.

        // ADVERTENCIA: Insertar esta variable sería incorrecto (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // ADVERTENCIA: Insertar esta variable sería incorrecto (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Usar `range` nuevamente sería incorrecto (#81138) Suponemos que los límites informados por `range` siguen siendo los mismos, pero una implementación contradictoria podría cambiar entre llamadas
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Convierte este `String` en un [`Box`]`<`[`str`] `>`.
    ///
    /// Esto eliminará cualquier exceso de capacidad.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Devuelve un segmento de [`u8`] bytes que se intentó convertir a `String`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // algunos bytes inválidos, en un vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Devuelve los bytes que se intentaron convertir a `String`.
    ///
    /// Este método se construye cuidadosamente para evitar la asignación.
    /// Consumirá el error, sacando los bytes, de modo que no sea necesario realizar una copia de los bytes.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // algunos bytes inválidos, en un vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Busque un `Utf8Error` para obtener más detalles sobre el error de conversión.
    ///
    /// El tipo [`Utf8Error`] proporcionado por [`std::str`] representa un error que puede ocurrir al convertir un segmento de [`u8`] sa un [`&str`].
    /// En este sentido, es un análogo a `FromUtf8Error`.
    /// Consulte su documentación para obtener más detalles sobre su uso.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // algunos bytes inválidos, en un vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // el primer byte no es válido aquí
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Debido a que estamos iterando sobre `String`s, podemos evitar al menos una asignación obteniendo la primera cadena del iterador y añadiéndole todas las cadenas subsiguientes.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Debido a que estamos iterando sobre CoWs, podemos (potentially) evitar al menos una asignación obteniendo el primer elemento y agregando a él todos los elementos subsiguientes.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Una conveniencia implícita que delega al impl para `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Crea un `String` vacío.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Implementa el operador `+` para concatenar dos cadenas.
///
/// Esto consume el `String` en el lado izquierdo y reutiliza su búfer (haciéndolo crecer si es necesario).
/// Esto se hace para evitar asignar un nuevo `String` y copiar todo el contenido en cada operación, lo que daría lugar a un tiempo de ejecución *O*(*n*^ 2) al construir una cadena de *n* bytes por concatenación repetida.
///
///
/// La cuerda del lado derecho solo se toma prestada;su contenido se copia en el `String` devuelto.
///
/// # Examples
///
/// La concatenación de dos `String`s toma el primero por valor y toma prestado el segundo:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` se mueve y ya no se puede utilizar aquí.
/// ```
///
/// Si desea seguir usando el primer `String`, puede clonarlo y agregarlo al clon en su lugar:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` sigue siendo válido aquí.
/// ```
///
/// Se pueden concatenar los cortes `&str` convirtiendo el primero en un `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Implementa el operador `+=` para agregar a un `String`.
///
/// Tiene el mismo comportamiento que el método [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Un alias de tipo para [`Infallible`].
///
/// Este alias existe por compatibilidad con versiones anteriores y, eventualmente, puede quedar obsoleto.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// Un trait para convertir un valor en un `String`.
///
/// Este trait se implementa automáticamente para cualquier tipo que implemente el [`Display`] trait.
/// Como tal, `ToString` no debe implementarse directamente:
/// [`Display`] debe implementarse en su lugar, y obtiene la implementación `ToString` de forma gratuita.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Convierte el valor dado en un `String`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// En esta implementación, el método `to_string` panics si la implementación `Display` devuelve un error.
/// Esto indica una implementación incorrecta de `Display` ya que `fmt::Write for String` nunca devuelve un error en sí mismo.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Una pauta común es no incluir funciones genéricas en línea.
    // Sin embargo, eliminar `#[inline]` de este método provoca regresiones no despreciables.
    // Ver <https://github.com/rust-lang/rust/pull/74852>, el último intento para intentar eliminarlo.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Convierte un `&mut str` en un `String`.
    ///
    /// El resultado se asigna en el montón.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: prueba extrae libstd, lo que provoca errores aquí
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Convierte el segmento `str` en caja dado en un `String`.
    /// Es de destacar que se posee el segmento `str`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Convierte el `String` dado en un segmento `str` en caja que es propiedad.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Convierte un segmento de cadena en una variante prestada.
    /// No se realiza ninguna asignación de montón y la cadena no se copia.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Convierte una cadena en una variante propia.
    /// No se realiza ninguna asignación de montón y la cadena no se copia.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Convierte una referencia de cadena en una variante prestada.
    /// No se realiza ninguna asignación de montón y la cadena no se copia.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Convierte el `String` dado en un vector `Vec` que contiene valores de tipo `u8`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Un iterador agotador para `String`.
///
/// Esta estructura es creada por el método [`drain`] en [`String`].
/// Consulte su documentación para obtener más información.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Se usará como&'una cadena mut en el destructor
    string: *mut String,
    /// Inicio de la pieza a eliminar
    start: usize,
    /// Fin de la pieza para eliminar
    end: usize,
    /// Rango restante actual para eliminar
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Utilice Vec::drain.
            // "Reaffirm" los límites se comprueban para evitar que se vuelva a insertar el código panic.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Devuelve la (sub) cadena restante de este iterador como un segmento.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: descomente las implicaciones de AsRef a continuación al estabilizar.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Descomente al estabilizar `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>para Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> para Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}