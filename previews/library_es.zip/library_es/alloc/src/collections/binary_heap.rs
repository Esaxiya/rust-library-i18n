//! Una cola de prioridad implementada con un montón binario.
//!
//! Insertar y hacer estallar el elemento más grande tiene una complejidad de tiempo *O*(log(*n*)).
//! La verificación del elemento más grande es *O*(1).La conversión de un vector en un montón binario se puede hacer en el lugar y tiene una complejidad *O*(*n*).
//! Un montón binario también se puede convertir en un vector ordenado en el lugar, lo que permite que se use para un *O*(*n*\*log(* n*)) en el lugar.
//!
//! # Examples
//!
//! Este es un ejemplo más grande que implementa [Dijkstra's algorithm][dijkstra] para resolver el [shortest path problem][sssp] en un [directed graph][dir_graph].
//!
//! Muestra cómo utilizar [`BinaryHeap`] con tipos personalizados.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // La cola de prioridad depende de `Ord`.
//! // Implemente explícitamente trait para que la cola se convierta en un montón mínimo en lugar de un montón máximo.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Observe que cambiamos el orden por los costos.
//!         // En caso de empate comparamos posiciones, este paso es necesario para que las implementaciones de `PartialEq` y `Ord` sean consistentes.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` también debe implementarse.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Cada nodo se representa como un `usize`, para una implementación más corta.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // El algoritmo de ruta más corta de Dijkstra.
//!
//! // Comience en `start` y use `dist` para rastrear la distancia más corta actual a cada nodo.Esta implementación no es eficiente en la memoria, ya que puede dejar nodos duplicados en la cola.
//! //
//! // También usa `usize::MAX` como valor centinela, para una implementación más simple.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [nodo]=distancia más corta actual de `start` a `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Estamos en `start`, sin costo
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Examine la frontera con nodos de menor costo primero (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Alternativamente, podríamos haber seguido encontrando todos los caminos más cortos.
//!         if position == goal { return Some(cost); }
//!
//!         // Importante, ya que es posible que ya hayamos encontrado una mejor manera
//!         if cost > dist[position] { continue; }
//!
//!         // Para cada nodo que podamos alcanzar, veamos si podemos encontrar una manera con un costo menor pasando por este nodo.
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Si es así, agrégalo a la frontera y continúa
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Relajación, ahora hemos encontrado una mejor manera
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Objetivo no alcanzable
//!     None
//! }
//!
//! fn main() {
//!     // Este es el gráfico dirigido que vamos a utilizar.
//!     // Los números de nodo corresponden a los diferentes estados y los pesos edge simbolizan el costo de moverse de un nodo a otro.
//!     //
//!     // Tenga en cuenta que los bordes son unidireccionales.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // El gráfico se representa como una lista de adyacencia donde cada índice, correspondiente a un valor de nodo, tiene una lista de bordes salientes.
//!     // Elegido por su eficacia.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Nodo 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Nodo 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Nodo 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Nodo 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Nodo 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Una cola de prioridad implementada con un montón binario.
///
/// Este será un montón máximo.
///
/// Es un error lógico que un artículo se modifique de tal manera que el orden del artículo en relación con cualquier otro artículo, según lo determinado por `Ord` trait, cambie mientras está en el montón.
///
/// Esto normalmente solo es posible a través de `Cell`, `RefCell`, estado global, I/O o código inseguro.
/// El comportamiento resultante de tal error lógico no se especifica, pero no dará como resultado un comportamiento indefinido.
/// Esto podría incluir panics, resultados incorrectos, abortos, pérdidas de memoria y no terminación.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // La inferencia de tipo nos permite omitir una firma de tipo explícita (que sería `BinaryHeap<i32>` en este ejemplo).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Podemos usar Peek para ver el siguiente elemento del montón.
/// // En este caso, todavía no hay elementos allí, por lo que obtenemos Ninguno.
/// assert_eq!(heap.peek(), None);
///
/// // Agreguemos algunas puntuaciones ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Ahora peek muestra el elemento más importante del montón.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Podemos comprobar la longitud de un montón.
/// assert_eq!(heap.len(), 3);
///
/// // Podemos iterar sobre los elementos del montón, aunque se devuelven en un orden aleatorio.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Si, en cambio, sacamos estos puntajes, deberían volver a ordenarse.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Podemos limpiar el montón de elementos restantes.
/// heap.clear();
///
/// // El montón ahora debería estar vacío.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Se puede utilizar `std::cmp::Reverse` o una implementación personalizada de `Ord` para hacer de `BinaryHeap` un min-heap.
/// Esto hace que `heap.pop()` devuelva el valor más pequeño en lugar del mayor.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Envolver valores en `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Si sacamos estos puntajes ahora, deberían volver en el orden inverso.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Complejidad del tiempo
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// El valor de `push` es un costo esperado;la documentación del método proporciona un análisis más detallado.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Estructura que envuelve una referencia mutable al elemento más grande en un `BinaryHeap`.
///
///
/// Este `struct` se crea mediante el método [`peek_mut`] en [`BinaryHeap`].
/// Consulte su documentación para obtener más información.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SEGURIDAD: PeekMut solo se crea una instancia para montones no vacíos.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SEGURO: PeekMut solo se crea una instancia para montones no vacíos
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SEGURO: PeekMut solo se crea una instancia para montones no vacíos
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Elimina el valor peeked del montón y lo devuelve.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Crea un `BinaryHeap<T>` vacío.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Crea un `BinaryHeap` vacío como un montón máximo.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Crea un `BinaryHeap` vacío con una capacidad específica.
    /// Esto preasigna suficiente memoria para los elementos `capacity`, de modo que el `BinaryHeap` no tenga que reasignarse hasta que contenga al menos esa cantidad de valores.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Devuelve una referencia mutable al elemento más grande del montón binario, o `None` si está vacío.
    ///
    /// Note: Si se filtra el valor `PeekMut`, el montón puede estar en un estado incoherente.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Complejidad del tiempo
    ///
    /// Si se modifica el elemento, la complejidad del tiempo en el peor de los casos es *O*(log(*n*)); de lo contrario, es *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Elimina el elemento más grande del montón binario y lo devuelve, o `None` si está vacío.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Complejidad del tiempo
    ///
    /// El costo del peor caso de `pop` en un montón que contiene *n* elementos es *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SEGURIDAD: !self.is_empty() significa que self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Inserta un elemento en el montón binario.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Complejidad del tiempo
    ///
    /// El costo esperado de `push`, promediado sobre cada posible orden de los elementos que se empujan, y sobre un número suficientemente grande de empujes, es *O*(1).
    ///
    /// Esta es la métrica de costos más significativa cuando se empujan elementos que *no* ya están en ningún patrón ordenado.
    ///
    /// La complejidad del tiempo se degrada si los elementos se empujan en orden predominantemente ascendente.
    /// En el peor de los casos, los elementos se insertan en orden ascendente y el costo amortizado por envío es *O*(log(*n*)) contra un montón que contiene *n* elementos.
    ///
    /// El peor costo de caso de una llamada *única* a `push` es *O*(*n*).El peor de los casos ocurre cuando se agota la capacidad y es necesario cambiar el tamaño.
    /// El coste de redimensionamiento se ha amortizado en las cifras anteriores.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SEGURIDAD: Dado que lanzamos un nuevo artículo, significa que
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Consume el `BinaryHeap` y devuelve un vector en el orden (ascending) ordenado.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SEGURIDAD: `end` pasa de `self.len() - 1` a 1 (ambos incluidos),
            //  por lo que siempre es un índice válido para acceder.
            //  Es seguro acceder al índice 0 (es decir, `ptr`), porque
            //  1 <=end <self.len(), lo que significa self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SEGURIDAD: `end` pasa de `self.len() - 1` a 1 (ambos incluidos) por lo que:
            //  0 <1 <=final <= self.len(), 1 <self.len() Lo que significa 0 <final y final <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Las implementaciones de sift_up y sift_down usan bloques inseguros para sacar un elemento del vector (dejando un agujero), cambiar a lo largo de los demás y mover el elemento eliminado de nuevo al vector en la ubicación final del agujero.
    //
    // El tipo `Hole` se usa para representar esto, y asegúrese de que el orificio se vuelva a llenar al final de su alcance, incluso en panic.
    // El uso de un agujero reduce el factor constante en comparación con el uso de intercambios, que implica el doble de movimientos.
    //
    //
    //
    //

    /// # Safety
    ///
    /// La persona que llama debe garantizar que `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Saque el valor en `pos` y cree un agujero.
        // SEGURIDAD: La persona que llama garantiza que pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SEGURIDAD: hole.pos()> inicio>=0, lo que significa hole.pos()> 0
            //  y entonces hole.pos(), no puedo subdesarrollar.
            //  Esto garantiza que el padre <hole.pos(), por lo que es un índice válido y también!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SEGURIDAD: Igual que arriba
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Tome un elemento en `pos` y muévalo hacia abajo en el montón, mientras que sus hijos son más grandes.
    ///
    ///
    /// # Safety
    ///
    /// La persona que llama debe garantizar que `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SEGURIDAD: La persona que llama garantiza que pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Invariable de bucle: hijo==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // compare con el mayor de los dos hijos SEGURIDAD: hijo <final, 1 <self.len() y hijo + 1 <final <= self.len(), por lo que son índices válidos.
            //
            //  niño==2 *hole.pos() + 1!= hole.pos() y niño + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 o 2* hole.pos() + 2 podrían desbordarse si T es un ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // si ya estamos en orden, para.
            // SEGURIDAD: el niño ahora es el niño mayor o el niño mayor + 1
            //  Ya probamos que ambos son <self.len() y!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SEGURIDAD: igual que arriba.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SEGURIDAD: &&cortocircuito, lo que significa que en el
        //  segunda condición ya es cierto que child==end, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SEGURIDAD: ya se ha demostrado que el niño es un índice válido y
            //  niño==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// La persona que llama debe garantizar que `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SEGURIDAD: pos <len está garantizado por la persona que llama y
        //  obviamente len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Tome un elemento en `pos` y muévalo hasta el fondo del montón, luego crínelo hasta su posición.
    ///
    ///
    /// Note: Esto es más rápido cuando se sabe que el elemento es grande/debería estar más cerca del fondo.
    ///
    /// # Safety
    ///
    /// La persona que llama debe garantizar que `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SEGURIDAD: La persona que llama garantiza que pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Invariable de bucle: hijo==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SEGURIDAD: niño <fin, 1 <self.len() y
            //  child + 1 <end <= self.len(), por lo que son índices válidos.
            //  niño==2 *hole.pos() + 1!= hole.pos() y niño + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 o 2* hole.pos() + 2 podrían desbordarse si T es un ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SEGURIDAD: Igual que arriba
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SEGURIDAD: child==end, 1 <self.len(), por lo que es un índice válido
            //  y niño==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SEGURIDAD: pos es la posición en el agujero y ya fue probado
        //  para ser un índice válido.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SEGURIDAD: n comienza desde self.len()/2 y baja a 0.
            //  El único caso en el que! (N <self.len()) es si self.len() ==0, pero está descartado por la condición del ciclo.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Mueve todos los elementos de `other` a `self`, dejando `other` vacío.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` toma operaciones O(len1 + len2) y aproximadamente 2 *(len1 + len2) comparaciones en el peor de los casos, mientras que `extend` toma operaciones O(len2* log(len1)) y aproximadamente 1 *len2* log_2(len1) comparaciones en el peor de los casos, asumiendo len1>= len2.
        // Para montones más grandes, el punto de cruce ya no sigue este razonamiento y se determinó empíricamente.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Devuelve un iterador que recupera elementos en orden de pila.
    /// Los elementos recuperados se eliminan del montón original.
    /// Los elementos restantes se eliminarán al colocarlos en orden de pila.
    ///
    /// Note:
    /// * `.drain_sorted()` es *O*(*n*\*log(* n*)); mucho más lento que `.drain()`.
    ///   Debería utilizar este último en la mayoría de los casos.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // elimina todos los elementos en orden de pila
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Conserva solo los elementos especificados por el predicado.
    ///
    /// En otras palabras, elimine todos los elementos `e` de modo que `f(&e)` devuelva `false`.
    /// Los elementos se visitan en un orden no clasificado (y no especificado).
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // solo mantén números pares
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Devuelve un iterador que visita todos los valores del vector subyacente, en orden arbitrario.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Imprime 1, 2, 3, 4 en orden arbitrario
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Devuelve un iterador que recupera elementos en orden de pila.
    /// Este método consume el montón original.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Devuelve el elemento más grande del montón binario, o `None` si está vacío.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Complejidad del tiempo
    ///
    /// El costo es *O*(1) en el peor de los casos.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Devuelve el número de elementos que el montón binario puede contener sin reasignar.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Reserva la capacidad mínima para que se inserten exactamente `additional` más elementos en el `BinaryHeap` dado.
    /// No hace nada si la capacidad ya es suficiente.
    ///
    /// Tenga en cuenta que el asignador puede dar a la colección más espacio del que solicita.
    /// Por lo tanto, no se puede confiar en que la capacidad sea precisamente mínima.
    /// Prefiera [`reserve`] si se esperan inserciones future.
    ///
    /// # Panics
    ///
    /// Panics si la nueva capacidad rebasa `usize`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Reserva capacidad para que al menos `additional` más elementos se inserten en el `BinaryHeap`.
    /// La colección puede reservar más espacio para evitar reasignaciones frecuentes.
    ///
    /// # Panics
    ///
    /// Panics si la nueva capacidad rebasa `usize`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Descarta tanta capacidad adicional como sea posible.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Descarta la capacidad con un límite inferior.
    ///
    /// La capacidad seguirá siendo al menos tan grande como la longitud y el valor suministrado.
    ///
    ///
    /// Si la capacidad actual es menor que el límite inferior, se trata de una operación no operativa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Consume el `BinaryHeap` y devuelve el vector subyacente en orden arbitrario.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Imprimirá en algún orden
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Devuelve la longitud del montón binario.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Comprueba si el montón binario está vacío.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Borra el montón binario, devolviendo un iterador sobre los elementos eliminados.
    ///
    /// Los elementos se eliminan en orden arbitrario.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Elimina todos los elementos del montón binario.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Agujero representa un agujero en un corte, es decir, un índice sin valor válido (porque se movió o se duplicó).
///
/// En caída, `Hole` restaurará el corte llenando la posición del agujero con el valor que se eliminó originalmente.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Cree un nuevo `Hole` en el índice `pos`.
    ///
    /// Inseguro porque la posición debe estar dentro del segmento de datos.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SEGURO: la posición debe estar dentro de la rebanada
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Devuelve una referencia al elemento eliminado.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Devuelve una referencia al elemento en `index`.
    ///
    /// Inseguro porque el índice debe estar dentro del segmento de datos y no ser igual a pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Mover el hoyo a una nueva ubicación
    ///
    /// Inseguro porque el índice debe estar dentro del segmento de datos y no ser igual a pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // llena el hoyo de nuevo
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Un iterador sobre los elementos de un `BinaryHeap`.
///
/// Este `struct` es creado por [`BinaryHeap::iter()`].
/// Consulte su documentación para obtener más información.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Eliminar a favor de `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Un iterador propietario sobre los elementos de un `BinaryHeap`.
///
/// Este `struct` es creado por [`BinaryHeap::into_iter()`] (proporcionado por `IntoIterator` trait).
/// Consulte su documentación para obtener más información.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Un iterador agotador sobre los elementos de un `BinaryHeap`.
///
/// Este `struct` es creado por [`BinaryHeap::drain()`].
/// Consulte su documentación para obtener más información.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Un iterador agotador sobre los elementos de un `BinaryHeap`.
///
/// Este `struct` es creado por [`BinaryHeap::drain_sorted()`].
/// Consulte su documentación para obtener más información.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Elimina los elementos del montón en orden de montón.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Convierte un `Vec<T>` en un `BinaryHeap<T>`.
    ///
    /// Esta conversión ocurre en el lugar y tiene *O*(*n*) complejidad de tiempo.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Convierte un `BinaryHeap<T>` en un `Vec<T>`.
    ///
    /// Esta conversión no requiere movimiento o asignación de datos y tiene una complejidad de tiempo constante.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Crea un iterador consumidor, es decir, uno que mueve cada valor fuera del montón binario en orden arbitrario.
    /// El montón binario no se puede utilizar después de llamar a this.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Imprime 1, 2, 3, 4 en orden arbitrario
    /// for x in heap.into_iter() {
    ///     // x tiene tipo i32, no &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}