use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modela un reborrow de alguna referencia única, cuando sabe que el reborrow y todos sus descendientes (es decir, todos los punteros y referencias derivadas de él) ya no se utilizarán en algún momento, después de lo cual desea volver a utilizar la referencia única original. .
///
///
/// El verificador de préstamos generalmente maneja este apilamiento de préstamos por usted, pero algunos flujos de control que logran este apilamiento son demasiado complicados para que el compilador los siga.
/// Un `DormantMutRef` le permite verificar el préstamo usted mismo, mientras expresa su naturaleza apilada y encapsula el código de puntero sin procesar necesario para hacer esto sin un comportamiento indefinido.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Obtenga un préstamo único y vuelva a pedirlo inmediatamente.
    /// Para el compilador, la vida útil de la nueva referencia es la misma que la vida útil de la referencia original, pero Z0 se compromete a utilizarla durante un período más corto.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SEGURIDAD: mantenemos el préstamo a lo largo de 'a a través de `_marker`, y exponemos
        // solo esta referencia, por lo que es única.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Revertir al préstamo único capturado inicialmente.
    ///
    /// # Safety
    ///
    /// El reborrow debe haber terminado, es decir, la referencia devuelta por `new` y todos los punteros y referencias derivadas de él, no deben usarse más.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SEGURIDAD: nuestras propias condiciones de seguridad implican que esta referencia es nuevamente única.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;