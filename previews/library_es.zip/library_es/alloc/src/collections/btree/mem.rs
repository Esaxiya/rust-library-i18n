use core::intrinsics;
use core::mem;
use core::ptr;

/// Esto reemplaza el valor detrás de la referencia única `v` llamando a la función relevante.
///
///
/// Si ocurre un panic en el cierre del `change`, se abortará todo el proceso.
#[allow(dead_code)] // mantener como ilustración y para uso future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Esto reemplaza el valor detrás de la referencia única `v` llamando a la función relevante y devuelve un resultado obtenido a lo largo del camino.
///
///
/// Si ocurre un panic en el cierre del `change`, se abortará todo el proceso.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}