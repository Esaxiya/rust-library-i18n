use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Agrega todos los pares clave-valor de la unión de dos iteradores ascendentes, aumentando una variable `length` a lo largo del camino.Esto último hace que sea más fácil para la persona que llama evitar una fuga cuando un manipulador de gotas entra en pánico.
    ///
    /// Si ambos iteradores producen la misma clave, este método elimina el par del iterador izquierdo y agrega el par del iterador derecho.
    ///
    /// Si desea que el árbol termine en un orden estrictamente ascendente, como para un `BTreeMap`, ambos iteradores deben producir claves en orden estrictamente ascendente, cada una mayor que todas las claves en el árbol, incluidas las claves que ya están en el árbol al ingresar.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Nos preparamos para fusionar `left` y `right` en una secuencia ordenada en tiempo lineal.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Mientras tanto, construimos un árbol a partir de la secuencia ordenada en tiempo lineal.
        self.bulk_push(iter, length)
    }

    /// Empuja todos los pares clave-valor al final del árbol, incrementando una variable `length` a lo largo del camino.
    /// Esto último hace que sea más fácil para la persona que llama evitar una fuga cuando el iterador entra en pánico.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Itere a través de todos los pares clave-valor, empujándolos hacia los nodos en el nivel correcto.
        for (key, value) in iter {
            // Intente insertar el par clave-valor en el nodo hoja actual.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // No queda espacio, sube y empuja allí.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Encontré un nodo con espacio restante, presione aquí.
                                open_node = parent;
                                break;
                            } else {
                                // Sube de nuevo.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Estamos en la parte superior, creamos un nuevo nodo raíz y empujamos allí.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Empuje el par clave-valor y el nuevo subárbol derecho.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Vuelve a bajar a la hoja más a la derecha.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Incremente la longitud en cada iteración, para asegurarse de que el mapa descarta los elementos añadidos incluso si el iterador avanza en pánico.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Un iterador para fusionar dos secuencias ordenadas en una
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Si dos claves son iguales, devuelve el par clave-valor de la fuente correcta.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}