// Este es un intento de implementación siguiendo el ideal
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Dado que Rust en realidad no tiene tipos dependientes ni recursividad polimórfica, nos conformamos con mucha inseguridad.
//

// Un objetivo principal de este módulo es evitar la complejidad tratando el árbol como un contenedor genérico (aunque de forma extraña) y evitando lidiar con la mayoría de los invariantes B-Tree.
//
// Como tal, a este módulo no le importa si las entradas están ordenadas, qué nodos pueden estar incompletos o incluso qué significa insuficiente.Sin embargo, confiamos en algunos invariantes:
//
// - Los árboles deben tener uniforme depth/height.Esto significa que cada camino hacia una hoja desde un nodo dado tiene exactamente la misma longitud.
// - Un nodo de longitud `n` tiene claves `n`, valores `n` y bordes `n + 1`.
//   Esto implica que incluso un nodo vacío tiene al menos un edge.
//   Para un nodo de hoja, "having an edge" solo significa que podemos identificar una posición en el nodo, ya que los bordes de la hoja están vacíos y no necesitan representación de datos.
// En un nodo interno, un edge identifica una posición y contiene un puntero a un nodo hijo.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// La representación subyacente de los nodos hoja y parte de la representación de los nodos internos.
struct LeafNode<K, V> {
    /// Queremos ser covariantes en `K` y `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// El índice de este nodo en la matriz `edges` del nodo principal.
    /// `*node.parent.edges[node.parent_idx]` debería ser lo mismo que `node`.
    /// Solo se garantiza que se inicializará cuando `parent` no sea nulo.
    parent_idx: MaybeUninit<u16>,

    /// El número de claves y valores que almacena este nodo.
    len: u16,

    /// Las matrices que almacenan los datos reales del nodo.
    /// Solo los primeros elementos `len` de cada matriz están inicializados y son válidos.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inicializa un nuevo `LeafNode` in situ.
    unsafe fn init(this: *mut Self) {
        // Como política general, dejamos los campos sin inicializar si es posible, ya que esto debería ser un poco más rápido y más fácil de rastrear en Valgrind.
        //
        unsafe {
            // parent_idx, keys y vals son todos MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Crea un nuevo `LeafNode` en caja.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// La representación subyacente de los nodos internos.Al igual que con `LeafNode`s, estos deben estar ocultos detrás de`BoxedNode`s para evitar que se caigan claves y valores no inicializados.
/// Cualquier puntero a un `InternalNode` se puede enviar directamente a un puntero a la parte `LeafNode` subyacente del nodo, lo que permite que el código actúe en los nodos internos y de hoja de forma genérica sin tener que comprobar siquiera a cuál de los dos apunta un puntero.
///
/// Esta propiedad está habilitada por el uso de `repr(C)`.
///
#[repr(C)]
// gdb_providers.py utiliza este nombre de tipo para la introspección.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Los punteros a los hijos de este nodo.
    /// `len + 1` de estos se consideran inicializados y válidos, excepto que cerca del final, mientras que el árbol se mantiene a través del tipo de préstamo `Dying`, algunos de estos indicadores están colgando.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Crea un nuevo `InternalNode` en caja.
    ///
    /// # Safety
    /// Un invariante de los nodos internos es que tienen al menos un edge inicializado y válido.
    /// Esta función no configura tal edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Solo necesitamos inicializar los datos;los bordes son MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Un puntero administrado no nulo a un nodo.Este es un puntero propio a `LeafNode<K, V>` o un puntero propio a `InternalNode<K, V>`.
///
/// Sin embargo, `BoxedNode` no contiene información sobre cuál de los dos tipos de nodos contiene realmente y, en parte debido a esta falta de información, no es un tipo separado y no tiene destructor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// El nodo raíz de un árbol propio.
///
/// Tenga en cuenta que esto no tiene un destructor y debe limpiarse manualmente.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Devuelve un nuevo árbol de propiedad, con su propio nodo raíz que inicialmente está vacío.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` no debe ser cero.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Toma prestado de forma mutable el nodo raíz de su propiedad.
    /// A diferencia de `reborrow_mut`, esto es seguro porque el valor de retorno no se puede usar para destruir la raíz y no puede haber otras referencias al árbol.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Toma prestado de forma levemente mutante el nodo raíz que posee.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Transiciones irreversibles a una referencia que permite el recorrido y ofrece métodos destructivos y poco más.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Agrega un nuevo nodo interno con un solo edge apuntando al nodo raíz anterior, convierte ese nuevo nodo en el nodo raíz y lo devuelve.
    /// Esto aumenta la altura en 1 y es lo opuesto a `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, excepto que nos olvidamos de que somos internos ahora:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Elimina el nodo raíz interno, utilizando su primer hijo como nuevo nodo raíz.
    /// Como solo se debe llamar cuando el nodo raíz tiene solo un hijo, no se realiza ninguna limpieza en ninguna de las claves, valores y otros hijos.
    ///
    /// Esto disminuye la altura en 1 y es lo opuesto a `push_internal_level`.
    ///
    /// Requiere acceso exclusivo al objeto `Root` pero no al nodo raíz;
    /// no invalidará otros identificadores o referencias al nodo raíz.
    ///
    /// Panics si no hay nivel interno, es decir, si el nodo raíz es una hoja.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SEGURIDAD: afirmamos ser internos.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SEGURIDAD: tomamos prestado `self` exclusivamente y su tipo de préstamo es exclusivo.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SEGURIDAD: el primer edge siempre se inicializa.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` siempre es covariante en `K` y `V`, incluso cuando `BorrowType` es `Mut`.
// Esto es técnicamente incorrecto, pero no puede resultar en ninguna inseguridad debido al uso interno de `NodeRef` porque permanecemos completamente genéricos sobre `K` y `V`.
//
// Sin embargo, siempre que un tipo público envuelva `NodeRef`, asegúrese de que tenga la variación correcta.
//
/// Una referencia a un nodo.
///
/// Este tipo tiene una serie de parámetros que controlan cómo actúa:
/// - `BorrowType`: Un tipo ficticio que describe el tipo de préstamo y lleva toda la vida.
///    - Cuando se trata de `Immut<'a>`, el `NodeRef` actúa más o menos como `&'a Node`.
///    - Cuando se trata de `ValMut<'a>`, `NodeRef` actúa más o menos como `&'a Node` con respecto a las claves y la estructura del árbol, pero también permite que coexistan muchas referencias mutables a valores en todo el árbol.
///    - Cuando es `Mut<'a>`, `NodeRef` actúa más o menos como `&'a mut Node`, aunque los métodos de inserción permiten que coexista un puntero mutable a un valor.
///    - Cuando se trata de `Owned`, `NodeRef` actúa más o menos como `Box<Node>`, pero no tiene un destructor y debe limpiarse manualmente.
///    - Cuando se trata de `Dying`, el `NodeRef` todavía actúa más o menos como `Box<Node>`, pero tiene métodos para destruir el árbol poco a poco, y los métodos ordinarios, aunque no están marcados como inseguros para llamar, pueden invocar a UB si se llaman incorrectamente.
///
///   Dado que cualquier `NodeRef` permite navegar a través del árbol, `BorrowType` se aplica efectivamente a todo el árbol, no solo al nodo en sí.
/// - `K` y `V`: estos son los tipos de claves y valores almacenados en los nodos.
/// - `Type`: Puede ser `Leaf`, `Internal` o `LeafOrInternal`.
/// Cuando es `Leaf`, `NodeRef` apunta a un nodo hoja, cuando es `Internal`, `NodeRef` apunta a un nodo interno, y cuando es `LeafOrInternal`, `NodeRef` podría estar apuntando a cualquier tipo de nodo.
///   `Type` se llama `NodeType` cuando se utiliza fuera de `NodeRef`.
///
/// Tanto `BorrowType` como `NodeType` restringen los métodos que implementamos para aprovechar la seguridad de tipo estático.Existen limitaciones en la forma en que podemos aplicar tales restricciones:
/// - Para cada parámetro de tipo, solo podemos definir un método de forma genérica o para un tipo en particular.
/// Por ejemplo, no podemos definir un método como `into_kv` genéricamente para todos los `BorrowType`, o una vez para todos los tipos que tienen una vida útil, porque queremos que devuelva referencias `&'a`.
///   Por lo tanto, lo definimos solo para el tipo `Immut<'a>` menos potente.
/// - No podemos obtener una coerción implícita de, digamos, `Mut<'a>` a `Immut<'a>`.
///   Por lo tanto, tenemos que llamar explícitamente a `reborrow` en un `NodeRef` más potente para llegar a un método como `into_kv`.
///
/// Todos los métodos en `NodeRef` que devuelven algún tipo de referencia, ya sea:
/// - Tome `self` por valor y devuelva la vida útil de `BorrowType`.
///   A veces, para invocar un método de este tipo, necesitamos llamar a `reborrow_mut`.
/// - Tome `self` por referencia, y (implicitly) devuelve la vida útil de esa referencia, en lugar de la vida útil que lleva `BorrowType`.
/// De esa manera, el verificador de préstamos garantiza que el `NodeRef` permanece prestado siempre que se utilice la referencia devuelta.
///   Los métodos que soportan la inserción modifican esta regla al devolver un puntero sin formato, es decir, una referencia sin vida útil.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// El número de niveles que el nodo y el nivel de hojas están separados, una constante del nodo que `Type` no puede describir completamente y que el nodo en sí no almacena.
    /// Solo necesitamos almacenar la altura del nodo raíz y derivar la altura de todos los demás nodos a partir de él.
    /// Debe ser cero si `Type` es `Leaf` y distinto de cero si `Type` es `Internal`.
    ///
    ///
    height: usize,
    /// El puntero a la hoja o al nodo interno.
    /// La definición de `InternalNode` asegura que el puntero sea válido de cualquier manera.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Desempaquete una referencia de nodo empaquetada como `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Expone los datos de un nodo interno.
    ///
    /// Devuelve un ptr sin formato para evitar invalidar otras referencias a este nodo.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SEGURIDAD: el tipo de nodo estático es `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Toma prestado acceso exclusivo a los datos de un nodo interno.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Calcula la longitud del nodo.Este es el número de claves o valores.
    /// El número de aristas es `len() + 1`.
    /// Tenga en cuenta que, a pesar de ser seguro, llamar a esta función puede tener el efecto secundario de invalidar las referencias mutables que ha creado el código inseguro.
    ///
    pub fn len(&self) -> usize {
        // Fundamentalmente, solo accedemos al campo `len` aquí.
        // Si BorrowType es marker::ValMut, puede haber referencias mutables pendientes a valores que no debemos invalidar.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Devuelve el número de niveles que el nodo y las hojas están separados.
    /// La altura cero significa que el nodo es una hoja en sí.
    /// Si imagina árboles con la raíz en la parte superior, el número indica a qué altura aparece el nodo.
    /// Si imagina árboles con hojas en la parte superior, el número indica qué tan alto se extiende el árbol por encima del nodo.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Elimina temporalmente otra referencia inmutable al mismo nodo.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Expone la porción de hoja de cualquier hoja o nodo interno.
    ///
    /// Devuelve un ptr sin formato para evitar invalidar otras referencias a este nodo.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // El nodo debe ser válido para al menos la parte LeafNode.
        // Esta no es una referencia en el tipo NodeRef porque no sabemos si debe ser única o compartida.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Encuentra el padre del nodo actual.
    /// Devuelve `Ok(handle)` si el nodo actual realmente tiene un padre, donde `handle` apunta al edge del padre que apunta al nodo actual.
    ///
    /// Devuelve `Err(self)` si el nodo actual no tiene padre, devolviendo el `NodeRef` original.
    ///
    /// El nombre del método asume que usted representa árboles con el nodo raíz en la parte superior.
    ///
    /// `edge.descend().ascend().unwrap()` y `node.ascend().unwrap().descend()` no deberían hacer nada, en caso de éxito.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Necesitamos usar punteros sin procesar a los nodos porque, si BorrowType es marker::ValMut, puede haber referencias mutables pendientes a valores que no debemos invalidar.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Tenga en cuenta que `self` no debe estar vacío.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Tenga en cuenta que `self` no debe estar vacío.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Expone la porción de hoja de cualquier hoja o nodo interno en un árbol inmutable.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SEGURIDAD: no puede haber referencias mutables en este árbol prestado como `Immut`.
        unsafe { &*ptr }
    }

    /// Toma prestada una vista de las claves almacenadas en el nodo.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Similar a `ascend`, obtiene una referencia al nodo principal de un nodo, pero también desasigna el nodo actual en el proceso.
    /// Esto no es seguro porque el nodo actual seguirá siendo accesible a pesar de haber sido desasignado.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Afirma de forma insegura al compilador la información estática de que este nodo es un `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Afirma de forma insegura al compilador la información estática de que este nodo es un `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Elimina temporalmente otra referencia mutable al mismo nodo.Tenga cuidado, ya que este método es muy peligroso, doblemente porque puede que no parezca peligroso de inmediato.
    ///
    /// Debido a que los punteros mutables pueden desplazarse por cualquier parte del árbol, el puntero devuelto se puede usar fácilmente para hacer que el puntero original cuelgue, se salga de los límites o sea inválido bajo reglas de préstamo apiladas.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) considere agregar otro parámetro de tipo a `NodeRef` que restrinja el uso de métodos de navegación en punteros reorientados, evitando esta inseguridad.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Toma prestado acceso exclusivo a la porción de hoja de cualquier hoja o nodo interno.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SEGURIDAD: tenemos acceso exclusivo a todo el nodo.
        unsafe { &mut *ptr }
    }

    /// Ofrece acceso exclusivo a la parte hoja de cualquier hoja o nodo interno.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SEGURIDAD: tenemos acceso exclusivo a todo el nodo.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Toma prestado acceso exclusivo a un elemento del área de almacenamiento de llaves.
    ///
    /// # Safety
    /// `index` está dentro de los límites de 0..CAPACIDAD
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SEGURIDAD: la persona que llama no podrá llamar a otros métodos por sí mismo
        // hasta que se elimine la referencia de segmento clave, ya que tenemos acceso único durante la vida útil del préstamo.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Toma prestado acceso exclusivo a un elemento o porción del área de almacenamiento de valor del nodo.
    ///
    /// # Safety
    /// `index` está dentro de los límites de 0..CAPACIDAD
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SEGURIDAD: la persona que llama no podrá llamar a otros métodos por sí mismo
        // hasta que se elimine la referencia del segmento de valor, ya que tenemos acceso único durante la vida útil del préstamo.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Toma prestado acceso exclusivo a un elemento o porción del área de almacenamiento del nodo para el contenido de edge.
    ///
    /// # Safety
    /// `index` está dentro de los límites de 0..CAPACIDAD + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SEGURIDAD: la persona que llama no podrá llamar a otros métodos por sí mismo
        // hasta que se elimine la referencia del segmento edge, ya que tenemos acceso exclusivo durante la vida útil del préstamo.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - El nodo tiene más de elementos inicializados `idx`.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Solo creamos una referencia al elemento que nos interesa, para evitar el alias con referencias sobresalientes a otros elementos, en particular, los devueltos al llamador en iteraciones anteriores.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Debemos forzarnos a punteros de matriz sin tamaño debido al problema #74679 de Rust.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Pide prestado acceso exclusivo a la longitud del nodo.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Establece el enlace del nodo a su padre edge, sin invalidar otras referencias al nodo.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Borra el enlace de la raíz a su padre edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Agrega un par clave-valor al final del nodo.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Cada elemento devuelto por `range` es un índice edge válido para el nodo.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Agrega un par clave-valor y un edge para ir a la derecha de ese par, al final del nodo.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Comprueba si un nodo es un nodo `Internal` o un nodo `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Una referencia a un par clave-valor específico o edge dentro de un nodo.
/// El parámetro `Node` debe ser `NodeRef`, mientras que `Type` puede ser `KV` (que significa un identificador en un par clave-valor) o `Edge` (que significa un identificador en un edge).
///
/// Tenga en cuenta que incluso los nodos `Leaf` pueden tener identificadores `Edge`.
/// En lugar de representar un puntero a un nodo secundario, estos representan los espacios donde los punteros secundarios irían entre los pares clave-valor.
/// Por ejemplo, en un nodo con longitud 2, habría 3 posibles ubicaciones edge, una a la izquierda del nodo, una entre los dos pares y una a la derecha del nodo.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// No necesitamos la generalidad completa de `#[derive(Clone)]`, ya que la única vez que `Node` será `Clone`able es cuando sea una referencia inmutable y por lo tanto `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Recupera el nodo que contiene el edge o el par clave-valor al que apunta este identificador.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Devuelve la posición de este identificador en el nodo.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Crea un nuevo identificador para un par clave-valor en `node`.
    /// Inseguro porque la persona que llama debe asegurarse de que `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Podría ser una implementación pública de PartialEq, pero solo se usa en este módulo.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Saca temporalmente otra manija inmutable en el mismo lugar.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // No podemos usar Handle::new_kv o Handle::new_edge porque no conocemos nuestro tipo
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Afirma de forma insegura al compilador la información estática de que el nodo del identificador es un `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Extrae temporalmente otra manija mutable en la misma ubicación.
    /// Tenga cuidado, ya que este método es muy peligroso, doblemente porque puede que no parezca peligroso de inmediato.
    ///
    ///
    /// Para obtener más información, consulte `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // No podemos usar Handle::new_kv o Handle::new_edge porque no conocemos nuestro tipo
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Crea un nuevo identificador para un edge en `node`.
    /// Inseguro porque la persona que llama debe asegurarse de que `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Dado un índice edge donde queremos insertar en un nodo lleno hasta su capacidad, calcula un índice KV sensible de un punto de división y dónde realizar la inserción.
///
/// El objetivo del punto de división es que su clave y valor terminen en un nodo principal;
/// las claves, valores y bordes a la izquierda del punto de división se convierten en el hijo izquierdo;
/// las claves, valores y bordes a la derecha del punto de división se convierten en el hijo correcto.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // El problema Rust #74834 intenta explicar estas reglas simétricas.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inserta un nuevo par clave-valor entre los pares clave-valor a la derecha e izquierda de este edge.
    /// Este método asume que hay suficiente espacio en el nodo para que quepa el nuevo par.
    ///
    /// El puntero devuelto apunta al valor insertado.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inserta un nuevo par clave-valor entre los pares clave-valor a la derecha e izquierda de este edge.
    /// Este método divide el nodo si no hay suficiente espacio.
    ///
    /// El puntero devuelto apunta al valor insertado.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Corrige el puntero principal y el índice en el nodo secundario al que se vincula este edge.
    /// Esto es útil cuando se ha cambiado el orden de los bordes,
    fn correct_parent_link(self) {
        // Cree backpointer sin invalidar otras referencias al nodo.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Inserta un nuevo par clave-valor y un edge que irá a la derecha de ese nuevo par entre este edge y el par clave-valor a la derecha de este edge.
    /// Este método asume que hay suficiente espacio en el nodo para que quepa el nuevo par.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Inserta un nuevo par clave-valor y un edge que irá a la derecha de ese nuevo par entre este edge y el par clave-valor a la derecha de este edge.
    /// Este método divide el nodo si no hay suficiente espacio.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inserta un nuevo par clave-valor entre los pares clave-valor a la derecha e izquierda de este edge.
    /// Este método divide el nodo si no hay suficiente espacio e intenta insertar la parte dividida en el nodo principal de forma recursiva, hasta que se alcanza la raíz.
    ///
    ///
    /// Si el resultado devuelto es un `Fit`, el nodo de su identificador puede ser el nodo de este edge o un ancestro.
    /// Si el resultado devuelto es un `Split`, el campo `left` será el nodo raíz.
    /// El puntero devuelto apunta al valor insertado.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Encuentra el nodo al que apunta este edge.
    ///
    /// El nombre del método asume que usted representa árboles con el nodo raíz en la parte superior.
    ///
    /// `edge.descend().ascend().unwrap()` y `node.ascend().unwrap().descend()` no deberían hacer nada, en caso de éxito.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Necesitamos usar punteros sin procesar a los nodos porque, si BorrowType es marker::ValMut, puede haber referencias mutables pendientes a valores que no debemos invalidar.
        // No hay que preocuparse por acceder al campo de altura porque ese valor se copia.
        // Tenga en cuenta que, una vez que se desreferencia el puntero del nodo, accedemos a la matriz de bordes con una referencia (Rust, problema #73987) e invalidamos cualquier otra referencia a la matriz o dentro de ella, en caso de que exista alguna.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // No podemos llamar a métodos de clave y valor separados, porque llamar al segundo invalida la referencia devuelta por el primero.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Reemplace la clave y el valor al que se refiere el identificador KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Ayuda a las implementaciones de `split` para un `NodeType` en particular, al cuidar los datos de hoja.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Divide el nodo subyacente en tres partes:
    ///
    /// - El nodo se trunca para contener solo los pares clave-valor a la izquierda de este identificador.
    /// - Se extraen la clave y el valor al que apunta este identificador.
    /// - Todos los pares clave-valor a la derecha de este identificador se colocan en un nodo recién asignado.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Elimina el par clave-valor al que apunta este identificador y lo devuelve, junto con el edge en el que se contrajo el par clave-valor.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Divide el nodo subyacente en tres partes:
    ///
    /// - El nodo se trunca para contener solo los bordes y los pares clave-valor a la izquierda de este identificador.
    /// - Se extraen la clave y el valor al que apunta este identificador.
    /// - Todos los bordes y pares clave-valor a la derecha de este identificador se colocan en un nodo recién asignado.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Representa una sesión para evaluar y realizar una operación de equilibrio en torno a un par clave-valor interno.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Elige un contexto de equilibrio que involucra al nodo como hijo, por lo tanto, entre el KV inmediatamente a la izquierda oa la derecha en el nodo padre.
    /// Devuelve un `Err` si no hay un padre.
    /// Panics si el padre está vacío.
    ///
    /// Prefiere el lado izquierdo, para ser óptimo si el nodo dado está de alguna manera incompleto, lo que significa que aquí solo tiene menos elementos que su hermano izquierdo y que su hermano derecho, si existen.
    /// En ese caso, fusionarse con el hermano izquierdo es más rápido, ya que solo necesitamos mover los N elementos del nodo, en lugar de moverlos hacia la derecha y mover más de N elementos al frente.
    /// Robar al hermano izquierdo también suele ser más rápido, ya que solo necesitamos mover los N elementos del nodo hacia la derecha, en lugar de mover al menos N de los elementos del hermano hacia la izquierda.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Devuelve si la fusión es posible, es decir, si hay suficiente espacio en un nodo para combinar el KV central con ambos nodos secundarios adyacentes.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Realiza una fusión y deja que un cierre decida qué devolver.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SEGURIDAD: la altura de los nodos que se fusionan es uno por debajo de la altura
                // del nodo de este edge, por lo tanto, por encima de cero, por lo que son internos.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Fusiona el par clave-valor del padre y los dos nodos secundarios adyacentes en el nodo secundario izquierdo y devuelve el nodo principal reducido.
    ///
    ///
    /// Panics a menos que `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Fusiona el par clave-valor del padre y los dos nodos secundarios adyacentes en el nodo secundario izquierdo y devuelve ese nodo secundario.
    ///
    ///
    /// Panics a menos que `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Fusiona el par clave-valor del padre y los dos nodos secundarios adyacentes en el nodo secundario izquierdo y devuelve el identificador edge en ese nodo secundario donde terminó el secundario edge seguido,
    ///
    ///
    /// Panics a menos que `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Quita un par clave-valor del elemento secundario izquierdo y lo coloca en el almacenamiento clave-valor del principal, al tiempo que inserta el par clave-valor principal anterior en el elemento secundario derecho.
    ///
    /// Devuelve un identificador al edge en el elemento secundario derecho correspondiente a donde terminó el edge original especificado por `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Quita un par clave-valor del elemento secundario derecho y lo coloca en el almacenamiento clave-valor del elemento principal, al tiempo que inserta el antiguo par clave-valor principal en el elemento secundario izquierdo.
    ///
    /// Devuelve un identificador al edge en el elemento secundario izquierdo especificado por `track_left_edge_idx`, que no se movió.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Esto hace un robo similar al `steal_left` pero roba varios elementos a la vez.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Asegúrese de que podamos robar con seguridad.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mueva los datos de la hoja.
            {
                // Haga espacio para los elementos robados en el niño adecuado.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Mueva elementos del hijo izquierdo al derecho.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Mueva el par robado más a la izquierda al padre.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Mueva el par clave-valor del padre al hijo correcto.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Haga espacio para los bordes robados.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Robar bordes.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// El clon simétrico de `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Asegúrese de que podamos robar con seguridad.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mueva los datos de la hoja.
            {
                // Mueva el par robado más a la derecha al padre.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Mueva el par clave-valor del padre al hijo izquierdo.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Mueva elementos del hijo derecho al izquierdo.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Llenar el espacio donde solían estar los elementos robados.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Robar bordes.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Llene el espacio donde solían estar los bordes robados.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Elimina cualquier información estática que afirme que este nodo es un nodo `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Elimina cualquier información estática que afirme que este nodo es un nodo `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Comprueba si el nodo subyacente es un nodo `Internal` o un nodo `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Mueva el sufijo después de `self` de un nodo a otro.`right` debe estar vacío.
    /// El primer edge de `right` permanece sin cambios.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Resultado de la inserción, cuando un nodo necesitaba expandirse más allá de su capacidad.
pub struct SplitResult<'a, K, V, NodeType> {
    // Nodo alterado en el árbol existente con elementos y aristas que pertenecen a la izquierda de `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Algunas claves y valores se separan para insertarse en otro lugar.
    pub kv: (K, V),
    // Nuevo nodo propio, sin adjuntar, con elementos y bordes que pertenecen a la derecha de `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Si las referencias de nodo de este tipo de préstamo permiten atravesar otros nodos del árbol.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // El recorrido no es necesario, sucede utilizando el resultado de `borrow_mut`.
        // Al deshabilitar el recorrido y solo crear nuevas referencias a las raíces, sabemos que cada referencia del tipo `Owned` es a un nodo raíz.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Inserta un valor en un segmento de elementos inicializados seguido de un elemento no inicializado.
///
/// # Safety
/// El segmento tiene más de elementos `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Elimina y devuelve un valor de un segmento de todos los elementos inicializados, dejando un elemento final sin inicializar.
///
///
/// # Safety
/// El segmento tiene más de elementos `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Desplaza los elementos de un sector `distance` posiciones a la izquierda.
///
/// # Safety
/// El segmento tiene al menos elementos `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Desplaza los elementos de un sector `distance` posiciones a la derecha.
///
/// # Safety
/// El segmento tiene al menos elementos `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Mueve todos los valores de un segmento de elementos inicializados a un segmento de elementos no inicializados, dejando atrás `src` como todo sin inicializar.
///
/// Funciona como `dst.copy_from_slice(src)` pero no requiere que `T` sea `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;