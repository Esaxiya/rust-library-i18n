use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Extrae temporalmente otro equivalente inmutable del mismo rango.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Encuentra los distintos bordes de las hojas que delimitan un rango específico en un árbol.
    /// Devuelve un par de identificadores diferentes en el mismo árbol o un par de opciones vacías.
    ///
    /// # Safety
    ///
    /// A menos que `BorrowType` sea `Immut`, no utilice los identificadores duplicados para visitar el mismo KV dos veces.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Equivalente a `(root1.first_leaf_edge(), root2.last_leaf_edge())` pero más eficiente.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Encuentra el par de bordes de las hojas que delimitan un rango específico en un árbol.
    ///
    /// El resultado es significativo solo si el árbol está ordenado por clave, como lo está el árbol en un `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SEGURIDAD: nuestro tipo de préstamo es inmutable.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Encuentra el par de bordes de las hojas que delimitan un árbol completo.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Divide una referencia única en un par de bordes de hojas que delimitan un rango específico.
    /// El resultado son referencias no únicas que permiten la mutación (some), que debe usarse con cuidado.
    ///
    /// El resultado es significativo solo si el árbol está ordenado por clave, como lo está el árbol en un `BTreeMap`.
    ///
    ///
    /// # Safety
    /// No use las manijas duplicadas para visitar el mismo KV dos veces.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Divide una referencia única en un par de bordes de hojas que delimitan el rango completo del árbol.
    /// Los resultados son referencias no únicas que permiten la mutación (solo de valores), por lo que deben usarse con cuidado.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Aquí duplicamos la raíz NodeRef: nunca visitaremos el mismo KV dos veces y nunca terminaremos con referencias de valores superpuestas.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Divide una referencia única en un par de bordes de hojas que delimitan el rango completo del árbol.
    /// Los resultados son referencias no únicas que permiten una mutación masivamente destructiva, por lo que deben usarse con sumo cuidado.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Duplicamos la raíz NodeRef aquí; nunca accederemos a ella de una manera que se superponga a las referencias obtenidas de la raíz.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Dado un identificador de hoja edge, devuelve [`Result::Ok`] con un identificador al KV vecino en el lado derecho, que está en el mismo nodo de hoja o en un nodo ancestro.
    ///
    /// Si la hoja edge es la última en el árbol, devuelve [`Result::Err`] con el nodo raíz.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Dado un identificador de hoja edge, devuelve [`Result::Ok`] con un identificador al KV vecino en el lado izquierdo, que está en el mismo nodo de hoja o en un nodo ancestro.
    ///
    /// Si la hoja edge es la primera en el árbol, devuelve [`Result::Err`] con el nodo raíz.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Dado un identificador edge interno, devuelve [`Result::Ok`] con un identificador al KV vecino en el lado derecho, que está en el mismo nodo interno o en un nodo ancestro.
    ///
    /// Si el edge interno es el último en el árbol, devuelve [`Result::Err`] con el nodo raíz.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Dado un identificador de hoja edge en un árbol moribundo, devuelve la siguiente hoja edge en el lado derecho y el par clave-valor en el medio, que está en el mismo nodo hoja, en un nodo ancestro o no existe.
    ///
    ///
    /// Este método también desasigna cualquier node(s) del que llega al final.
    /// Esto implica que si no existe más par clave-valor, se habrá desasignado todo el resto del árbol y no quedará nada para devolver.
    ///
    /// # Safety
    /// El edge proporcionado no debe haber sido devuelto previamente por la contraparte `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Dado un identificador de hoja edge en un árbol moribundo, devuelve la siguiente hoja edge en el lado izquierdo y el par clave-valor en el medio, que está en el mismo nodo hoja, en un nodo ancestro o no existe.
    ///
    ///
    /// Este método también desasigna cualquier node(s) del que llega al final.
    /// Esto implica que si no existe más par clave-valor, se habrá desasignado todo el resto del árbol y no quedará nada para devolver.
    ///
    /// # Safety
    /// El edge proporcionado no debe haber sido devuelto previamente por la contraparte `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Distribuye una pila de nodos desde la hoja hasta la raíz.
    /// Esta es la única forma de desasignar el resto de un árbol después de que `deallocating_next` y `deallocating_next_back` hayan estado mordisqueando a ambos lados del árbol y hayan alcanzado el mismo edge.
    /// Como solo se debe llamar cuando se hayan devuelto todas las claves y valores, no se realiza ninguna limpieza en ninguna de las claves o valores.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Mueve el identificador de hoja edge a la siguiente hoja edge y devuelve referencias a la clave y el valor intermedio.
    ///
    ///
    /// # Safety
    /// Debe haber otro KV en la dirección recorrida.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Mueve el mango de la hoja edge a la hoja anterior edge y devuelve referencias a la clave y el valor intermedio.
    ///
    ///
    /// # Safety
    /// Debe haber otro KV en la dirección recorrida.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Mueve el identificador de hoja edge a la siguiente hoja edge y devuelve referencias a la clave y el valor intermedio.
    ///
    ///
    /// # Safety
    /// Debe haber otro KV en la dirección recorrida.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Hacer esto último es más rápido, según los puntos de referencia.
        kv.into_kv_valmut()
    }

    /// Mueve el identificador de hoja edge a la hoja anterior y devuelve referencias a la clave y el valor intermedio.
    ///
    ///
    /// # Safety
    /// Debe haber otro KV en la dirección recorrida.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Hacer esto último es más rápido, según los puntos de referencia.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Mueve el identificador de la hoja edge a la siguiente hoja edge y devuelve la clave y el valor intermedio, desasignando cualquier nodo dejado atrás mientras deja colgando el edge correspondiente en su nodo principal.
    ///
    /// # Safety
    /// - Debe haber otro KV en la dirección recorrida.
    /// - Ese KV no fue devuelto previamente por la contraparte `next_back_unchecked` en ninguna copia de las manijas que se usaban para atravesar el árbol.
    ///
    /// La única forma segura de proceder con el mango actualizado es compararlo, soltarlo, volver a llamar a este método sujeto a sus condiciones de seguridad o llamar a la contraparte `next_back_unchecked` sujeto a sus condiciones de seguridad.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Mueve el identificador edge de la hoja al edge de la hoja anterior y devuelve la clave y el valor intermedio, desasignando cualquier nodo dejado atrás mientras deja colgando el edge correspondiente en su nodo principal.
    ///
    /// # Safety
    /// - Debe haber otro KV en la dirección recorrida.
    /// - Esa hoja edge no fue devuelta previamente por la contraparte `next_unchecked` en ninguna copia de las manijas que se usaban para atravesar el árbol.
    ///
    /// La única forma segura de proceder con el mango actualizado es compararlo, soltarlo, volver a llamar a este método sujeto a sus condiciones de seguridad o llamar a la contraparte `next_unchecked` sujeto a sus condiciones de seguridad.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Devuelve la hoja más a la izquierda edge dentro o debajo de un nodo, en otras palabras, el edge que necesita primero cuando navega hacia adelante (o el último cuando navega hacia atrás).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Devuelve el edge de la hoja más a la derecha dentro o debajo de un nodo, en otras palabras, el edge que necesita al final cuando navega hacia adelante (o primero cuando navega hacia atrás).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Visita los nodos hoja y los KV internos en orden ascendente de claves, y también visita los nodos internos como un todo en un primer orden en profundidad, lo que significa que los nodos internos preceden a sus KV individuales y sus nodos secundarios.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Calcula el número de elementos en un (sub) árbol.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Devuelve la hoja edge más cercana a un KV para navegación hacia adelante.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Devuelve la hoja edge más cercana a un KV para la navegación hacia atrás.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}