//! Utilidades para formatear e imprimir `String`s.
//!
//! Este módulo contiene el soporte de tiempo de ejecución para la extensión de sintaxis [`format!`].
//! Esta macro se implementa en el compilador para emitir llamadas a este módulo con el fin de formatear argumentos en tiempo de ejecución en cadenas.
//!
//! # Usage
//!
//! La macro [`format!`] está destinada a ser familiar para aquellos que provienen de las funciones `printf`/`fprintf` de C o la función `str.format` de Python.
//!
//! Algunos ejemplos de la extensión [`format!`] son:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" con ceros a la izquierda
//! ```
//!
//! A partir de estos, puede ver que el primer argumento es una cadena de formato.El compilador requiere que sea una cadena literal;no puede ser una variable pasada (para realizar una verificación de validez).
//! A continuación, el compilador analizará la cadena de formato y determinará si la lista de argumentos proporcionada es adecuada para pasar a esta cadena de formato.
//!
//! Para convertir un solo valor en una cadena, use el método [`to_string`].Esto usará el formato [`Display`] trait.
//!
//! ## Parámetros posicionales
//!
//! A cada argumento de formato se le permite especificar a qué argumento de valor hace referencia y, si se omite, se asume que es "the next argument".
//! Por ejemplo, la cadena de formato `{} {} {}` tomaría tres parámetros y se formatearían en el mismo orden en que se dan.
//! Sin embargo, la cadena de formato `{2} {1} {0}` formatearía los argumentos en orden inverso.
//!
//! Las cosas pueden complicarse un poco una vez que empiezas a mezclar los dos tipos de especificadores posicionales.El especificador "next argument" se puede considerar como un iterador sobre el argumento.
//! Cada vez que se ve un especificador "next argument", el iterador avanza.Esto conduce a un comportamiento como este:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! El iterador interno sobre el argumento no se ha avanzado en el momento en que se ve el primer `{}`, por lo que imprime el primer argumento.Luego, al llegar al segundo `{}`, el iterador avanzó al segundo argumento.
//! Esencialmente, los parámetros que nombran explícitamente su argumento no afectan los parámetros que no nombran un argumento en términos de especificadores posicionales.
//!
//! Se requiere una cadena de formato para usar todos sus argumentos; de lo contrario, es un error en tiempo de compilación.Puede hacer referencia al mismo argumento más de una vez en la cadena de formato.
//!
//! ## Parámetros nombrados
//!
//! Rust en sí no tiene un equivalente similar a Python de parámetros con nombre para una función, pero la macro [`format!`] es una extensión de sintaxis que le permite aprovechar los parámetros con nombre.
//! Los parámetros con nombre se enumeran al final de la lista de argumentos y tienen la sintaxis:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Por ejemplo, las siguientes expresiones [`format!`] utilizan argumentos con nombre:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! No es válido poner parámetros posicionales (aquellos sin nombre) después de los argumentos que tienen nombre.Al igual que con los parámetros posicionales, no es válido proporcionar parámetros con nombre que la cadena de formato no utiliza.
//!
//! # Parámetros de formato
//!
//! Cada argumento que se formatea se puede transformar mediante una serie de parámetros de formato (correspondientes a `format_spec` en [the syntax](#syntax)). Estos parámetros afectan la representación de cadena de lo que se formatea.
//!
//! ## Width
//!
//! ```
//! // Todos estos imprimen "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Este es un parámetro para el "minimum width" que debería tomar el formato.
//! Si la cadena del valor no llena esta cantidad de caracteres, entonces se usará el relleno especificado por fill/alignment para ocupar el espacio requerido (ver más abajo).
//!
//! El valor para el ancho también se puede proporcionar como [`usize`] en la lista de parámetros agregando un sufijo `$`, lo que indica que el segundo argumento es un [`usize`] que especifica el ancho.
//!
//! Hacer referencia a un argumento con la sintaxis del dólar no afecta al contador "next argument", por lo que suele ser una buena idea hacer referencia a los argumentos por posición o utilizar argumentos con nombre.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! El carácter de relleno y la alineación opcionales se proporcionan normalmente junto con el parámetro [`width`](#width).Debe definirse antes de `width`, justo después de `:`.
//! Esto indica que si el valor que se está formateando es menor que `width`, se imprimirán algunos caracteres adicionales a su alrededor.
//! El llenado viene en las siguientes variantes para diferentes alineaciones:
//!
//! * `[fill]<` - el argumento está alineado a la izquierda en columnas `width`
//! * `[fill]^` - el argumento está alineado al centro en columnas `width`
//! * `[fill]>` - el argumento está alineado a la derecha en columnas `width`
//!
//! El [fill/alignment](#fillalignment) predeterminado para los no numéricos es un espacio y está alineado a la izquierda.El valor predeterminado para los formateadores numéricos también es un carácter de espacio pero con alineación a la derecha.
//! Si la bandera `0` (ver más abajo) se especifica para números, entonces el carácter de relleno implícito es `0`.
//!
//! Tenga en cuenta que es posible que algunos tipos no implementen la alineación.En particular, generalmente no se implementa para el `Debug` trait.
//! Una buena forma de asegurarse de que se aplique el relleno es formatear su entrada y luego rellenar esta cadena resultante para obtener su salida:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "¡Hola Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Todos estos son indicadores que alteran el comportamiento del formateador.
//!
//! * `+` - Está destinado a tipos numéricos e indica que el letrero siempre debe imprimirse.Los signos positivos nunca se imprimen de forma predeterminada y el signo negativo solo se imprime de manera predeterminada para el `Signed` trait.
//! Esta bandera indica que siempre se debe imprimir el signo correcto (`+` o `-`).
//! * `-` - Actualmente no se utiliza
//! * `#` - Esta bandera indica que se debe utilizar la forma de impresión "alternate".Las formas alternativas son:
//!     * `#?` - Pretty-print el formato [`Debug`]
//!     * `#x` - precede al argumento con un `0x`
//!     * `#X` - precede al argumento con un `0x`
//!     * `#b` - precede al argumento con un `0b`
//!     * `#o` - precede al argumento con un `0o`
//! * `0` - Esto se usa para indicar para formatos enteros que el relleno a `width` debe hacerse tanto con un carácter `0` como con reconocimiento de signos.
//! Un formato como `{:08}` produciría `00000001` para el entero `1`, mientras que el mismo formato produciría `-0000001` para el entero `-1`.
//! Observe que la versión negativa tiene un cero menos que la versión positiva.
//!         Tenga en cuenta que los ceros de relleno siempre se colocan después del signo (si lo hay) y antes de los dígitos.Cuando se usa junto con la bandera `#`, se aplica una regla similar: los ceros de relleno se insertan después del prefijo pero antes de los dígitos.
//!         El prefijo está incluido en el ancho total.
//!
//! ## Precision
//!
//! Para los tipos no numéricos, esto se puede considerar un "maximum width".
//! Si la cadena resultante es más larga que este ancho, entonces se trunca a esta cantidad de caracteres y ese valor truncado se emite con `fill`, `alignment` y `width` adecuados si esos parámetros están configurados.
//!
//! Para los tipos integrales, esto se ignora.
//!
//! Para los tipos de punto flotante, esto indica cuántos dígitos después del punto decimal deben imprimirse.
//!
//! Hay tres formas posibles de especificar el `precision` deseado:
//!
//! 1. Un número entero `.N`:
//!
//!    el entero `N` en sí es la precisión.
//!
//! 2. Un número entero o un nombre seguido del signo de dólar `.N$`:
//!
//!    use formato *argumento*`N` (que debe ser un `usize`) como precisión.
//!
//! 3. Un asterisco `.*`:
//!
//!    `.*` significa que este `{...}` está asociado con *dos* entradas de formato en lugar de una: la primera entrada contiene la precisión `usize` y la segunda contiene el valor para imprimir.
//!    Tenga en cuenta que en este caso, si se usa la cadena de formato `{<arg>:<spec>.*}`, entonces la parte `<arg>` se refiere al* valor * para imprimir, y el `precision` debe venir en la entrada que precede a `<arg>`.
//!
//! Por ejemplo, todas las siguientes llamadas imprimen lo mismo `Hello x is 0.01000`:
//!
//! ```
//! // Hola {arg 0 ("x")} es {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hola {arg 1 ("x")} es {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hola {arg 0 ("x")} es {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hola {next arg ("x")} es {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hola {next arg ("x")} es {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hola {next arg ("x")} es {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Mientras estos:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! imprime tres cosas significativamente diferentes:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! En algunos lenguajes de programación, el comportamiento de las funciones de formateo de cadenas depende de la configuración regional del sistema operativo.
//! Las funciones de formato proporcionadas por la biblioteca estándar de Rust no tienen ningún concepto de configuración regional y producirán los mismos resultados en todos los sistemas independientemente de la configuración del usuario.
//!
//! Por ejemplo, el siguiente código siempre imprimirá `1.5` incluso si la configuración regional del sistema usa un separador decimal que no sea un punto.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Los caracteres literales `{` y `}` pueden incluirse en una cadena precediéndolos con el mismo carácter.Por ejemplo, el carácter `{` se escapa con `{{` y el carácter `}` se escapa con `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Para resumir, aquí puede encontrar la gramática completa de cadenas de formato.
//! La sintaxis del lenguaje de formato utilizado se extrae de otros lenguajes, por lo que no debería resultar demasiado extraño.Los argumentos están formateados con una sintaxis similar a Python, lo que significa que los argumentos están rodeados por `{}` en lugar de `%` similar a C.
//! La gramática real de la sintaxis de formato es:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! En la gramática anterior, `text` no puede contener ningún carácter `'{'` o `'}'`.
//!
//! # Formateo de traits
//!
//! Cuando solicita que un argumento sea formateado con un tipo en particular, en realidad está solicitando que un argumento se atribuya a un trait en particular.
//! Esto permite formatear varios tipos reales a través de `{:x}` (como [`i8`] y [`isize`]).El mapeo actual de tipos a traits es:
//!
//! * *nada* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] con números enteros hexadecimales en minúsculas
//! * `X?` ⇒ [`Debug`] con números enteros hexadecimales en mayúsculas
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Lo que esto significa es que cualquier tipo de argumento que implemente [`fmt::Binary`][`Binary`] trait se puede formatear con `{:b}`.La biblioteca estándar también proporciona implementaciones para estos traits para varios tipos primitivos.
//!
//! Si no se especifica ningún formato (como en `{}` o `{:6}`), entonces el formato trait utilizado es el [`Display`] trait.
//!
//! Al implementar un formato trait para su propio tipo, deberá implementar un método de la firma:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // nuestro tipo personalizado
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Su tipo se pasará como `self` por referencia, y luego la función debería emitir una salida en el flujo `f.buf`.Depende de cada implementación de trait de formato adherirse correctamente a los parámetros de formato solicitados.
//! Los valores de estos parámetros se enumerarán en los campos de la estructura [`Formatter`].Para ayudar con esto, la estructura [`Formatter`] también proporciona algunos métodos auxiliares.
//!
//! Además, el valor de retorno de esta función es [`fmt::Result`], que es un alias de tipo de [`Result`]`<(),`[`std: : fmt::Error`] `>`.
//! Las implementaciones de formato deben garantizar que propaguen errores desde el [`Formatter`] (por ejemplo, al llamar a [`write!`]).
//! Sin embargo, nunca deben devolver errores de forma falsa.
//! Es decir, una implementación de formato debe y solo puede devolver un error si el [`Formatter`] pasado devuelve un error.
//! Esto se debe a que, contrariamente a lo que podría sugerir la firma de la función, el formateo de cadenas es una operación infalible.
//! Esta función solo devuelve un resultado porque la escritura en la secuencia subyacente puede fallar y debe proporcionar una forma de propagar el hecho de que se ha producido un error en la pila.
//!
//! Un ejemplo de implementación del formato traits se vería así:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // El valor `f` implementa el `Write` trait, ¡que es lo que escribe!macro está esperando.
//!         // Tenga en cuenta que este formato ignora las diversas marcas proporcionadas para formatear cadenas.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Diferentes traits permiten diferentes formas de salida de un tipo.
//! // El significado de este formato es imprimir la magnitud de un vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respete las marcas de formato utilizando el método auxiliar `pad_integral` en el objeto Formatter.
//!         // Consulte la documentación del método para obtener más detalles, y la función `pad` se puede utilizar para rellenar cadenas.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` frente a `fmt::Debug`
//!
//! Estos dos formatos traits tienen distintos propósitos:
//!
//! - [`fmt::Display`][`Display`] Las implementaciones afirman que el tipo se puede representar fielmente como una cadena UTF-8 en todo momento.**No** se espera que todos los tipos implementen [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] las implementaciones deben implementarse para **todos** tipos públicos.
//!   Normalmente, la salida representará el estado interno de la forma más fiel posible.
//!   El propósito del [`Debug`] trait es facilitar la depuración del código Rust.En la mayoría de los casos, el uso de `#[derive(Debug)]` es suficiente y recomendado.
//!
//! Algunos ejemplos de la salida de ambos traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macros relacionadas
//!
//! Hay varias macros relacionadas en la familia [`format!`].Los que se encuentran implementados actualmente son:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! This y [`writeln!`] son dos macros que se utilizan para emitir la cadena de formato a una secuencia especificada.Esto se utiliza para evitar asignaciones intermedias de cadenas de formato y, en su lugar, escribe directamente la salida.
//! Bajo el capó, esta función en realidad está invocando la función [`write_fmt`] definida en el [`std::io::Write`] trait.
//! El uso de ejemplo es:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Este y [`println!`] emiten su salida a stdout.De manera similar a la macro [`write!`], el objetivo de estas macros es evitar asignaciones intermedias al imprimir la salida.El uso de ejemplo es:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Las macros [`eprint!`] y [`eprintln!`] son idénticas a [`print!`] y [`println!`], respectivamente, excepto que emiten su salida a stderr.
//!
//! ### `format_args!`
//!
//! Esta es una macro curiosa que se utiliza para pasar de forma segura un objeto opaco que describe la cadena de formato.Este objeto no requiere ninguna asignación de montón para crearse y solo hace referencia a la información de la pila.
//! Bajo el capó, todas las macros relacionadas se implementan en términos de esto.
//! En primer lugar, algunos ejemplos de uso son:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! El resultado de la macro [`format_args!`] es un valor de tipo [`fmt::Arguments`].
//! Esta estructura se puede pasar luego a las funciones [`write`] y [`format`] dentro de este módulo para procesar la cadena de formato.
//! El objetivo de esta macro es evitar aún más las asignaciones intermedias cuando se trata de formatear cadenas.
//!
//! Por ejemplo, una biblioteca de registro podría usar la sintaxis de formato estándar, pero pasaría internamente esta estructura hasta que se haya determinado a dónde debe ir la salida.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// La función `format` toma una estructura [`Arguments`] y devuelve la cadena formateada resultante.
///
///
/// La instancia [`Arguments`] se puede crear con la macro [`format_args!`].
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Tenga en cuenta que puede ser preferible utilizar [`format!`].
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}