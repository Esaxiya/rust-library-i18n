use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Esta no es un área de superficie estable, pero ayuda a mantener el `?` barato entre ellos, incluso si LLVM no siempre puede aprovecharlo en este momento.
    //
    // (Lamentablemente, Result y Option son inconsistentes, por lo que ControlFlow no puede coincidir con ambos).

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}