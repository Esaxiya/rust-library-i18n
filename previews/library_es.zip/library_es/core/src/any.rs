//! Este módulo implementa el `Any` trait, que permite la escritura dinámica de cualquier tipo `'static` a través de la reflexión en tiempo de ejecución.
//!
//! `Any` en sí mismo se puede usar para obtener un `TypeId` y tiene más funciones cuando se usa como un objeto trait.
//! Como `&dyn Any` (un objeto trait prestado), tiene los métodos `is` y `downcast_ref` para probar si el valor contenido es de un tipo determinado y obtener una referencia al valor interno como tipo.
//! Como `&mut dyn Any`, también existe el método `downcast_mut`, para obtener una referencia mutable al valor interno.
//! `Box<dyn Any>` agrega el método `downcast`, que intenta convertir a un `Box<T>`.
//! Consulte la documentación de [`Box`] para obtener todos los detalles.
//!
//! Tenga en cuenta que `&dyn Any` se limita a probar si un valor es de un tipo concreto específico y no se puede utilizar para probar si un tipo implementa un trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Punteros inteligentes y `dyn Any`
//!
//! Un comportamiento a tener en cuenta al usar `Any` como un objeto trait, especialmente con tipos como `Box<dyn Any>` o `Arc<dyn Any>`, es que simplemente llamar a `.type_id()` en el valor producirá el `TypeId` del *contenedor*, no el objeto trait subyacente.
//!
//! Esto se puede evitar convirtiendo el puntero inteligente en un `&dyn Any`, que devolverá el `TypeId` del objeto.
//! Por ejemplo:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Es más probable que desee esto:
//! let actual_id = (&*boxed).type_id();
//! // ... que esto:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Considere una situación en la que queremos cerrar la sesión de un valor pasado a una función.
//! Sabemos el valor en el que estamos trabajando implementa Debug, pero no sabemos su tipo concreto.Queremos dar un tratamiento especial a ciertos tipos: en este caso imprimiendo la longitud de los valores de String antes de su valor.
//! No conocemos el tipo concreto de nuestro valor en tiempo de compilación, por lo que debemos usar la reflexión en tiempo de ejecución.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Función de registrador para cualquier tipo que implemente Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Intente convertir nuestro valor a un `String`.
//!     // Si tiene éxito, queremos generar la longitud de String` así como su valor.
//!     // Si no es así, es de un tipo diferente: simplemente imprímalo sin adornos.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Esta función quiere cerrar la sesión de su parámetro antes de trabajar con él.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... hacer algún otro trabajo
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Cualquier trait
///////////////////////////////////////////////////////////////////////////////

/// Un trait para emular la escritura dinámica.
///
/// La mayoría de los tipos implementan `Any`.Sin embargo, cualquier tipo que contenga una referencia no "estática" no lo hace.
/// Consulte el [module-level documentation][mod] para obtener más detalles.
///
/// [mod]: crate::any
// Este trait no es inseguro, aunque confiamos en los detalles de la función `type_id` de su única impl en código inseguro (por ejemplo, `downcast`).Normalmente, eso sería un problema, pero debido a que la única implicación de `Any` es una implementación general, ningún otro código puede implementar `Any`.
//
// Podríamos hacer plausiblemente inseguro este trait-no causaría roturas, ya que controlamos todas las implementaciones-pero elegimos no hacerlo ya que no es realmente necesario y puede confundir a los usuarios sobre la distinción entre trait inseguro y métodos inseguros (es decir, `type_id` aún sería seguro para llamar, pero es probable que queramos indicarlo como tal en la documentación).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Obtiene el `TypeId` de `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Métodos de extensión para cualquier objeto trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Asegúrese de que el resultado de, por ejemplo, unir un hilo pueda imprimirse y, por tanto, utilizarse con `unwrap`.
// Eventualmente, puede que ya no sea necesario si el envío funciona con upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Devuelve `true` si el tipo en caja es el mismo que `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Obtenga `TypeId` del tipo con el que se crea una instancia de esta función.
        let t = TypeId::of::<T>();

        // Obtenga `TypeId` del tipo del objeto trait (`self`).
        let concrete = self.type_id();

        // Compare ambos `TypeId`s en igualdad.
        t == concrete
    }

    /// Devuelve alguna referencia al valor en caja si es de tipo `T`, o `None` si no lo es.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SEGURIDAD: acaba de comprobar si estamos apuntando al tipo correcto, y podemos confiar en
            // que verifican la seguridad de la memoria porque hemos implementado Any para todos los tipos;no pueden existir otras implicaciones, ya que entrarían en conflicto con nuestra implicación.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Devuelve alguna referencia mutable al valor en caja si es de tipo `T`, o `None` si no lo es.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SEGURIDAD: acaba de comprobar si estamos apuntando al tipo correcto, y podemos confiar en
            // que verifican la seguridad de la memoria porque hemos implementado Any para todos los tipos;no pueden existir otras implicaciones, ya que entrarían en conflicto con nuestra implicación.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Reenvía al método definido en el tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Reenvía al método definido en el tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Reenvía al método definido en el tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Reenvía al método definido en el tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Reenvía al método definido en el tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Reenvía al método definido en el tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID y sus métodos
///////////////////////////////////////////////////////////////////////////////

/// Un `TypeId` representa un identificador único global para un tipo.
///
/// Cada `TypeId` es un objeto opaco que no permite la inspección de lo que hay dentro, pero sí permite operaciones básicas como clonación, comparación, impresión y visualización.
///
///
/// Actualmente, un `TypeId` solo está disponible para los tipos que se adscriben a `'static`, pero esta limitación puede eliminarse en future.
///
/// Si bien `TypeId` implementa `Hash`, `PartialOrd` y `Ord`, vale la pena señalar que los valores hash y el orden variarán entre las versiones de Rust.
/// ¡Tenga cuidado de confiar en ellos dentro de su código!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Devuelve el `TypeId` del tipo con el que se ha instanciado esta función genérica.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Devuelve el nombre de un tipo como un segmento de cadena.
///
/// # Note
///
/// Está diseñado para uso diagnóstico.
/// El contenido exacto y el formato de la cadena devuelta no se especifican, aparte de ser una descripción de mejor esfuerzo del tipo.
/// Por ejemplo, entre las cadenas que `type_name::<Option<String>>()` podría devolver se encuentran `"Option<String>"` y `"std::option::Option<std::string::String>"`.
///
///
/// La cadena devuelta no debe considerarse un identificador único de un tipo, ya que varios tipos pueden correlacionarse con el mismo nombre de tipo.
/// De manera similar, no hay garantía de que todas las partes de un tipo aparezcan en la cadena devuelta: por ejemplo, los especificadores de por vida no están incluidos actualmente.
/// Además, la salida puede cambiar entre versiones del compilador.
///
/// La implementación actual usa la misma infraestructura que el diagnóstico del compilador y la información de depuración, pero esto no está garantizado.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Devuelve el nombre del tipo de valor apuntado como un segmento de cadena.
/// Es lo mismo que `type_name::<T>()`, pero se puede utilizar cuando el tipo de variable no está fácilmente disponible.
///
/// # Note
///
/// Está diseñado para uso diagnóstico.El contenido exacto y el formato de la cadena no se especifican, aparte de ser una descripción de mejor esfuerzo del tipo.
/// Por ejemplo, `type_name_of_val::<Option<String>>(None)` podría devolver `"Option<String>"` o `"std::option::Option<std::string::String>"`, pero no `"foobar"`.
///
/// Además, la salida puede cambiar entre versiones del compilador.
///
/// Esta función no resuelve los objetos trait, lo que significa que `type_name_of_val(&7u32 as &dyn Debug)` puede devolver `"dyn Debug"`, pero no `"u32"`.
///
/// El nombre del tipo no debe considerarse un identificador único de un tipo;
/// varios tipos pueden compartir el mismo nombre de tipo.
///
/// La implementación actual usa la misma infraestructura que el diagnóstico del compilador y la información de depuración, pero esto no está garantizado.
///
/// # Examples
///
/// Imprime los tipos enteros y flotantes predeterminados.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}