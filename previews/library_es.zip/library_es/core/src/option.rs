//! Valores opcionales.
//!
//! El tipo [`Option`] representa un valor opcional: cada [`Option`] es [`Some`] y contiene un valor, o [`None`] y no lo contiene.
//! [`Option`] Los tipos son muy comunes en el código Rust, ya que tienen varios usos:
//!
//! * Valores iniciales
//! * Valores de retorno para funciones que no están definidas en todo su rango de entrada (funciones parciales)
//! * Valor de retorno para informar errores simples de otro modo, donde [`None`] se devuelve en caso de error
//! * Campos de estructura opcionales
//! * Campos de estructura que se pueden prestar o "taken"
//! * Argumentos de funciones opcionales
//! * Punteros que aceptan valores NULL
//! * Cambiar cosas de situaciones difíciles
//!
//! Las [`Option`] se combinan comúnmente con la coincidencia de patrones para consultar la presencia de un valor y tomar medidas, siempre teniendo en cuenta el caso [`None`].
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // El valor de retorno de la función es una opción.
//! let result = divide(2.0, 3.0);
//!
//! // Coincidencia de patrón para recuperar el valor
//! match result {
//!     // La división fue válida
//!     Some(x) => println!("Result: {}", x),
//!     // La división era inválida
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: Muestre cómo se usa `Option` en la práctica, con muchos métodos
//
//! # Opciones y punteros (punteros "nullable")
//!
//! Los tipos de puntero de Rust siempre deben apuntar a una ubicación válida;no hay referencias de "null".En su lugar, Rust tiene punteros *opcionales*, como el cuadro de propiedad opcional, [`Option`]`<`[`Box<T>`]`>`.
//!
//! El siguiente ejemplo usa [`Option`] para crear una caja opcional de [`i32`].
//! Observe que para usar primero el valor interno de [`i32`], la función `check_optional` necesita usar la coincidencia de patrones para determinar si la caja tiene un valor (es decir, es [`Some(...)`][`Some`]) o no ([`None`]).
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust garantiza optimizar los siguientes tipos `T` de manera que [`Option<T>`] tenga el mismo tamaño que `T`:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` estructura alrededor de uno de los tipos de esta lista.
//!
//! Además, se garantiza que, para los casos anteriores, se puede [`mem::transmute`] de todos los valores válidos de `T` a `Option<T>` y de `Some::<T>(_)` a `T` (pero transmutar `None::<T>` a `T` es un comportamiento indefinido).
//!
//! # Examples
//!
//! Coincidencia de patrones básicos en [`Option`]:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // Toma una referencia a la cadena contenida
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // Retire la cadena contenida, destruyendo la opción
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! Inicialice un resultado en [`None`] antes de un bucle:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // Una lista de datos para buscar.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // Vamos a buscar el nombre del animal más grande, pero para empezar, solo tenemos `None`.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // Ahora hemos encontrado el nombre de un animal grande
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// El tipo `Option`.Consulte [the module level documentation](self) para obtener más información.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// Sin valor
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// Algún valor `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// Implementación de tipo
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // Consultando los valores contenidos
    /////////////////////////////////////////////////////////////////////////

    /// Devuelve `true` si la opción es un valor [`Some`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// Devuelve `true` si la opción es un valor [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// Devuelve `true` si la opción es un valor [`Some`] que contiene el valor dado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Adaptador para trabajar con referencias
    /////////////////////////////////////////////////////////////////////////

    /// Convierte de `&Option<T>` a `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Convierte una `Option <` [`String`]`>`en una`Option <`[`usize`] `>`, conservando el original.
    /// El método [`map`] toma el argumento `self` por valor, consumiendo el original, por lo que esta técnica usa `as_ref` para llevar primero un `Option` a una referencia al valor dentro del original.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // Primero, transmita `Option<String>` a `Option<&String>` con `as_ref`, luego consuma *eso* con `map`, dejando `text` en la pila.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// Convierte de `&mut Option<T>` a `Option<&mut T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// Convierte de [`Pin`]`<&Opción<T>>`a`Opción <`[`Pin`] `<&T>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // SEGURIDAD: `x` está garantizado para estar anclado porque proviene de `self`
        // que está anclado.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// Convierte de [`Pin`]`<&mut Option<T>>`a`Opción <`[`Pin`] `<&mut T>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // SEGURIDAD: `get_unchecked_mut` nunca se usa para mover el `Option` dentro de `self`.
        // `x` está garantizado para estar anclado porque proviene de `self` que está anclado.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // Llegar a valores contenidos
    /////////////////////////////////////////////////////////////////////////

    /// Devuelve el valor [`Some`] contenido, consumiendo el valor `self`.
    ///
    /// # Panics
    ///
    /// Panics si el valor es un [`None`] con un mensaje panic personalizado proporcionado por `msg`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// Devuelve el valor [`Some`] contenido, consumiendo el valor `self`.
    ///
    /// Debido a que esta función puede panic, generalmente se desaconseja su uso.
    /// En su lugar, prefiera utilizar la coincidencia de patrones y manejar el caso [`None`] de forma explícita, o llamar a [`unwrap_or`], [`unwrap_or_else`] o [`unwrap_or_default`].
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics si el valor propio es igual a [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// Devuelve el valor [`Some`] contenido o un valor predeterminado proporcionado.
    ///
    /// Los argumentos que se pasan a `unwrap_or` se evalúan con entusiasmo;si está pasando el resultado de una llamada de función, se recomienda utilizar [`unwrap_or_else`], que se evalúa de forma perezosa.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// Devuelve el valor [`Some`] contenido o lo calcula a partir de un cierre.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// Devuelve el valor [`Some`] contenido, consumiendo el valor `self`, sin comprobar que el valor no es [`None`].
    ///
    ///
    /// # Safety
    ///
    /// Llamar a este método en [`None`] es *[comportamiento indefinido]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // Comportamiento indefinido!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Transformando valores contenidos
    /////////////////////////////////////////////////////////////////////////

    /// Mapea un `Option<T>` a `Option<U>` aplicando una función a un valor contenido.
    ///
    /// # Examples
    ///
    /// Convierte una `Option <` [`String`]`>`en una`Option <`[`usize`] `>`, consumiendo el original:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` se toma a sí mismo *por valor*, consumiendo `maybe_some_string`
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// Aplica una función al valor contenido (si lo hay) o devuelve el valor predeterminado proporcionado (si no es así).
    ///
    /// Los argumentos que se pasan a `map_or` se evalúan con entusiasmo;si está pasando el resultado de una llamada de función, se recomienda utilizar [`map_or_else`], que se evalúa de forma perezosa.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// Aplica una función al valor contenido (si lo hay) o calcula un valor predeterminado (si no es así).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// Transforma el `Option<T>` en un [`Result<T, E>`], mapeando [`Some(v)`] a [`Ok(v)`] y [`None`] a [`Err(err)`].
    ///
    /// Los argumentos que se pasan a `ok_or` se evalúan con entusiasmo;si está pasando el resultado de una llamada de función, se recomienda utilizar [`ok_or_else`], que se evalúa de forma perezosa.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// Transforma el `Option<T>` en un [`Result<T, E>`], mapeando [`Some(v)`] a [`Ok(v)`] y [`None`] a [`Err(err())`].
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// Inserta `value` en la opción y luego devuelve una referencia mutable.
    ///
    /// Si la opción ya contiene un valor, se descarta el valor anterior.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // SEGURIDAD: el código anterior acaba de completar la opción
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Constructores de iteradores
    /////////////////////////////////////////////////////////////////////////

    /// Devuelve un iterador sobre el valor posiblemente contenido.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// Devuelve un iterador mutable sobre el valor posiblemente contenido.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // Operaciones booleanas sobre los valores, ansiosas y perezosas.
    /////////////////////////////////////////////////////////////////////////

    /// Devuelve [`None`] si la opción es [`None`]; de lo contrario, devuelve `optb`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// Devuelve [`None`] si la opción es [`None`]; de lo contrario, llama a `f` con el valor envuelto y devuelve el resultado.
    ///
    ///
    /// Algunos lenguajes llaman a esta operación mapa plano.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// Devuelve [`None`] si la opción es [`None`]; de lo contrario, llama a `predicate` con el valor envuelto y devuelve:
    ///
    ///
    /// - [`Some(t)`] si `predicate` devuelve `true` (donde `t` es el valor envuelto), y
    /// - [`None`] si `predicate` devuelve `false`.
    ///
    /// Esta función funciona de manera similar a [`Iterator::filter()`].
    /// Puede imaginarse que el `Option<T>` es un iterador sobre uno o cero elementos.
    /// `filter()` le permite decidir qué elementos conservar.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// Devuelve la opción si contiene un valor; de lo contrario, devuelve `optb`.
    ///
    /// Los argumentos que se pasan a `or` se evalúan con entusiasmo;si está pasando el resultado de una llamada de función, se recomienda utilizar [`or_else`], que se evalúa de forma perezosa.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// Devuelve la opción si contiene un valor; de lo contrario, llama a `f` y devuelve el resultado.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// Devuelve [`Some`] si exactamente uno de `self`, `optb` es [`Some`]; de lo contrario, devuelve [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Operaciones de entrada para insertar si no hay y devolver una referencia
    /////////////////////////////////////////////////////////////////////////

    /// Inserta `value` en la opción si es [`None`], luego devuelve una referencia mutable al valor contenido.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// Inserta el valor predeterminado en la opción si es [`None`], luego devuelve una referencia mutable al valor contenido.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// Inserta un valor calculado a partir de `f` en la opción si es [`None`], luego devuelve una referencia mutable al valor contenido.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // SEGURIDAD: una variante `None` para `self` habría sido reemplazada por una `Some`
            // variante en el código anterior.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// Elimina el valor de la opción, dejando un [`None`] en su lugar.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// Reemplaza el valor real en la opción por el valor dado en el parámetro, devolviendo el valor anterior si está presente, dejando un [`Some`] en su lugar sin desinicializar ninguno.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// Cierra `self` con otro `Option`.
    ///
    /// Si `self` es `Some(s)` y `other` es `Some(o)`, este método devuelve `Some((s, o))`.
    /// De lo contrario, se devuelve `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// Cremalleras `self` y otra `Option` con función `f`.
    ///
    /// Si `self` es `Some(s)` y `other` es `Some(o)`, este método devuelve `Some(f(s, o))`.
    /// De lo contrario, se devuelve `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// Asigna un `Option<&T>` a un `Option<T>` copiando el contenido de la opción.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// Asigna un `Option<&mut T>` a un `Option<T>` copiando el contenido de la opción.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// Asigna un `Option<&T>` a un `Option<T>` clonando el contenido de la opción.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// Asigna un `Option<&mut T>` a un `Option<T>` clonando el contenido de la opción.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// Consume `self` mientras espera [`None`] y no devuelve nada.
    ///
    /// # Panics
    ///
    /// Panics si el valor es [`Some`], con un mensaje panic que incluye el mensaje pasado y el contenido del [`Some`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Esto no será panic, ya que todas las claves son únicas.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// Consume `self` mientras espera [`None`] y no devuelve nada.
    ///
    /// # Panics
    ///
    /// Panics si el valor es [`Some`], con un mensaje panic personalizado proporcionado por el valor de [`Some`].
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Esto no será panic, ya que todas las claves son únicas.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// Devuelve el valor [`Some`] contenido o un valor predeterminado
    ///
    /// Consume el argumento `self`, luego, si [`Some`], devuelve el valor contenido; de lo contrario, si [`None`], devuelve [default value] para ese tipo.
    ///
    ///
    /// # Examples
    ///
    /// Convierte una cadena en un número entero, convirtiendo las cadenas mal formadas en 0 (el valor predeterminado para los números enteros).
    /// [`parse`] convierte una cadena en cualquier otro tipo que implemente [`FromStr`], devolviendo [`None`] en caso de error.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// Convierte de `Option<T>` (o `&Option<T>`) a `Option<&T::Target>`.
    ///
    /// Deja la opción original en su lugar, creando una nueva con una referencia a la original, además de coaccionar el contenido a través de [`Deref`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// Convierte de `Option<T>` (o `&mut Option<T>`) a `Option<&mut T::Target>`.
    ///
    /// Deja el `Option` original en su lugar, creando uno nuevo que contiene una referencia mutable al tipo `Deref::Target` del tipo interno.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// Transpone un `Option` de un [`Result`] a un [`Result`] de un `Option`.
    ///
    /// [`None`] se asignará a [`Ok`]`(`[`None`] `)`.
    /// [`Some`]`(`[`Ok`] `(_))` y [`Some`]`(`[`Err`] `(_))` se asignarán a [`Ok`]`(`[`Some`] `(_))` y [`Err`]`(_)`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// Esta es una función separada para reducir el tamaño del código del propio .expect().
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// Esta es una función separada para reducir el tamaño del código del propio .expect_none().
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Implementaciones Trait
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// Devuelve [`None`][Option::None].
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Devuelve un iterador consumidor sobre el valor posiblemente contenido.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// Copia `val` en un nuevo `Some`.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// Convierte de `&Option<T>` a `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Convierte una `Option <` [`String`]`>`en una`Option <`[`usize`] `>`, conservando el original.
    /// El método [`map`] toma el argumento `self` por valor, consumiendo el original, por lo que esta técnica usa `as_ref` para llevar primero un `Option` a una referencia al valor dentro del original.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// Convierte de `&mut Option<T>` a `Option<&mut T>`
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Los iteradores de opciones
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// Un iterador sobre una referencia a la variante [`Some`] de un [`Option`].
///
/// El iterador produce un valor si el [`Option`] es un [`Some`], de lo contrario ninguno.
///
/// Este `struct` es creado por la función [`Option::iter`].
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// Un iterador sobre una referencia mutable a la variante [`Some`] de un [`Option`].
///
/// El iterador produce un valor si el [`Option`] es un [`Some`], de lo contrario ninguno.
///
/// Este `struct` es creado por la función [`Option::iter_mut`].
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// Un iterador sobre el valor en la variante [`Some`] de un [`Option`].
///
/// El iterador produce un valor si el [`Option`] es un [`Some`], de lo contrario ninguno.
///
/// Este `struct` es creado por la función [`Option::into_iter`].
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// Toma cada elemento del [`Iterator`]: si es [`None`][Option::None], no se toman más elementos y se devuelve el [`None`][Option::None].
    /// Si no se produce [`None`][Option::None], se devuelve un contenedor con los valores de cada [`Option`].
    ///
    /// # Examples
    ///
    /// Aquí hay un ejemplo que incrementa cada entero en un vector.
    /// Usamos la variante marcada de `add` que devuelve `None` cuando el cálculo daría como resultado un desbordamiento.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// Como puede ver, esto devolverá los elementos válidos esperados.
    ///
    /// Aquí hay otro ejemplo que intenta restar uno de otra lista de enteros, esta vez verificando el subdesbordamiento:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// Dado que el último elemento es cero, se desbordaría.Por tanto, el valor resultante es `None`.
    ///
    /// Aquí hay una variación del ejemplo anterior, que muestra que no se toman más elementos de `iter` después del primer `None`.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Dado que el tercer elemento provocó un subdesbordamiento, no se tomaron más elementos, por lo que el valor final de `shared` es 6 (= `3 + 2 + 1`), no 16.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): Esto podría reemplazarse con Iterator::scan cuando se cierre este error de rendimiento.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// El tipo de error que resulta de aplicar el operador try (`?`) a un valor `None`.
/// Si desea permitir que `x?` (donde `x` es un `Option<T>`) se convierta en su tipo de error, puede implementar `impl From<NoneError>` para `YourErrorType`.
///
/// En ese caso, `x?` dentro de una función que devuelve `Result<_, YourErrorType>` traducirá un valor `None` en un resultado `Err`.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// Convierte de `Option<Option<T>>` a `Option<T>`
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// El aplanamiento solo elimina un nivel de anidamiento a la vez:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}