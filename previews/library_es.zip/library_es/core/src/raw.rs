#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Contiene definiciones de estructura para el diseño de los tipos integrados del compilador.
//!
//! Se pueden usar como objetivos de transmutaciones en código inseguro para manipular las representaciones en bruto directamente.
//!
//!
//! Su definición siempre debe coincidir con la ABI definida en `rustc_middle::ty::layout`.
//!

/// La representación de un objeto trait como `&dyn SomeTrait`.
///
/// Esta estructura tiene el mismo diseño que tipos como `&dyn SomeTrait` y `Box<dyn AnotherTrait>`.
///
/// `TraitObject` se garantiza que coincida con los diseños, pero no es el tipo de objetos trait (por ejemplo, los campos no son directamente accesibles en un `&dyn SomeTrait`) ni controla ese diseño (cambiar la definición no cambiará el diseño de un `&dyn SomeTrait`).
///
/// Solo está diseñado para ser utilizado por código inseguro que necesita manipular los detalles de bajo nivel.
///
/// No hay forma de referirse a todos los objetos trait de forma genérica, por lo que la única forma de crear valores de este tipo es con funciones como [`std::mem::transmute`][transmute].
/// De manera similar, la única forma de crear un verdadero objeto trait a partir de un valor `TraitObject` es con `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Sintetizar un objeto trait con tipos no coincidentes, uno en el que vtable no se corresponde con el tipo de valor al que apunta el puntero de datos, es muy probable que dé lugar a un comportamiento indefinido.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // un ejemplo trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // deje que el compilador cree un objeto trait
/// let object: &dyn Foo = &value;
///
/// // mira la representación en bruto
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // el puntero de datos es la dirección de `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // construir un nuevo objeto, apuntando a un `i32` diferente, teniendo cuidado de usar la vtable `i32` de `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // debería funcionar como si hubiéramos construido un objeto trait a partir de `other_value` directamente
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}