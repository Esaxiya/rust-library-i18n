use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Un asignador de memoria que se puede registrar como predeterminado de la biblioteca estándar a través del atributo `#[global_allocator]`.
///
/// Algunos de los métodos requieren que un bloque de memoria esté *actualmente asignado* a través de un asignador.Esto significa que:
///
/// * la dirección de inicio para ese bloque de memoria fue devuelta previamente por una llamada anterior a un método de asignación como `alloc`, y
///
/// * el bloque de memoria no se ha desasignado posteriormente, donde los bloques se desasignan pasándose a un método de desasignación como `dealloc` o pasándose a un método de reasignación que devuelve un puntero no nulo.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// El `GlobalAlloc` trait es un `unsafe` trait por varias razones, y los implementadores deben asegurarse de cumplir con estos contratos:
///
/// * Es un comportamiento indefinido si los asignadores globales se relajan.Esta restricción puede levantarse en el future, pero actualmente un panic de cualquiera de estas funciones puede conducir a la inseguridad de la memoria.
///
/// * `Layout` las consultas y cálculos en general deben ser correctos.Las personas que llaman a este trait pueden confiar en los contratos definidos en cada método, y los implementadores deben asegurarse de que dichos contratos sigan siendo verdaderos.
///
/// * Es posible que no confíe en las asignaciones que ocurren realmente, incluso si hay asignaciones de montón explícitas en el origen.
/// El optimizador puede detectar asignaciones no utilizadas que puede eliminar por completo o mover a la pila y, por lo tanto, nunca invocar al asignador.
/// El optimizador puede suponer además que la asignación es infalible, por lo que el código que solía fallar debido a fallas del asignador ahora puede funcionar repentinamente porque el optimizador solucionó la necesidad de una asignación.
/// Más concretamente, el siguiente ejemplo de código no es sólido, independientemente de si su asignador personalizado permite contar cuántas asignaciones han ocurrido.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Tenga en cuenta que las optimizaciones mencionadas anteriormente no son la única optimización que se puede aplicar.Por lo general, es posible que no confíe en las asignaciones de montón si se pueden eliminar sin cambiar el comportamiento del programa.
///   Si las asignaciones ocurren o no, no es parte del comportamiento del programa, incluso si pudiera detectarse a través de un asignador que rastrea las asignaciones imprimiendo o teniendo efectos secundarios.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Asigne memoria como se describe en el `layout` dado.
    ///
    /// Devuelve un puntero a la memoria recién asignada o un valor nulo para indicar un error de asignación.
    ///
    /// # Safety
    ///
    /// Esta función no es segura porque puede producirse un comportamiento indefinido si la persona que llama no se asegura de que `layout` tenga un tamaño distinto de cero.
    ///
    /// (Los sustratos de extensión pueden proporcionar límites más específicos en el comportamiento, por ejemplo, garantizar una dirección centinela o un puntero nulo en respuesta a una solicitud de asignación de tamaño cero).
    ///
    /// El bloque de memoria asignado puede o no inicializarse.
    ///
    /// # Errors
    ///
    /// Devolver un puntero nulo indica que la memoria está agotada o que `layout` no cumple con las restricciones de alineación o tamaño de este asignador.
    ///
    /// Se recomienda que las implementaciones devuelvan un valor nulo cuando se agote la memoria en lugar de abortar, pero esto no es un requisito estricto.
    /// (Específicamente: es *legal* implementar este trait encima de una biblioteca de asignación nativa subyacente que aborta cuando se agota la memoria).
    ///
    /// Se recomienda a los clientes que deseen abortar el cálculo en respuesta a un error de asignación que llamen a la función [`handle_alloc_error`], en lugar de invocar directamente `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Desasigne el bloque de memoria en el puntero `ptr` dado con el `layout` dado.
    ///
    /// # Safety
    ///
    /// Esta función no es segura porque puede producirse un comportamiento indefinido si la persona que llama no garantiza todo lo siguiente:
    ///
    ///
    /// * `ptr` debe denotar un bloque de memoria asignado actualmente a través de este asignador,
    ///
    /// * `layout` debe tener el mismo diseño que se utilizó para asignar ese bloque de memoria.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Se comporta como `alloc`, pero también garantiza que el contenido se establezca en cero antes de ser devuelto.
    ///
    /// # Safety
    ///
    /// Esta función no es segura por las mismas razones que `alloc`.
    /// Sin embargo, se garantiza la inicialización del bloque de memoria asignado.
    ///
    /// # Errors
    ///
    /// Devolver un puntero nulo indica que la memoria está agotada o que `layout` no cumple con las restricciones de alineación o tamaño del asignador, al igual que en `alloc`.
    ///
    /// Se recomienda a los clientes que deseen abortar el cálculo en respuesta a un error de asignación que llamen a la función [`handle_alloc_error`], en lugar de invocar directamente `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `alloc`.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SEGURIDAD: cuando la asignación se realizó correctamente, la región de `ptr`
            // de tamaño `size` se garantiza que es válido para escrituras.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Reducir o aumentar un bloque de memoria al `new_size` dado.
    /// El bloque se describe mediante el puntero `ptr` y `layout` dados.
    ///
    /// Si esto devuelve un puntero no nulo, entonces la propiedad del bloque de memoria al que hace referencia `ptr` se ha transferido a este asignador.
    /// La memoria puede haber sido desasignada o no, y debe considerarse inutilizable (a menos que, por supuesto, se haya transferido nuevamente a la persona que llama a través del valor de retorno de este método).
    /// El nuevo bloque de memoria se asigna con `layout`, pero con el `size` actualizado a `new_size`.
    /// Este nuevo diseño debe usarse al desasignar el nuevo bloque de memoria con `dealloc`.
    /// Se garantiza que el rango `0..min(layout.size(), new_size) `del nuevo bloque de memoria tiene los mismos valores que el bloque original.
    ///
    /// Si este método devuelve un valor nulo, la propiedad del bloque de memoria no se ha transferido a este asignador y el contenido del bloque de memoria no se modifica.
    ///
    /// # Safety
    ///
    /// Esta función no es segura porque puede producirse un comportamiento indefinido si la persona que llama no garantiza todo lo siguiente:
    ///
    /// * `ptr` debe asignarse actualmente a través de este asignador,
    ///
    /// * `layout` debe ser el mismo diseño que se utilizó para asignar ese bloque de memoria,
    ///
    /// * `new_size` Debe ser mayor que cero.
    ///
    /// * `new_size`, cuando se redondea al múltiplo más cercano de `layout.align()`, no debe desbordarse (es decir, el valor redondeado debe ser menor que `usize::MAX`).
    ///
    /// (Los sustratos de extensión pueden proporcionar límites más específicos en el comportamiento, por ejemplo, garantizar una dirección centinela o un puntero nulo en respuesta a una solicitud de asignación de tamaño cero).
    ///
    /// # Errors
    ///
    /// Devuelve nulo si el nuevo diseño no cumple con las restricciones de tamaño y alineación del asignador, o si la reasignación falla.
    ///
    /// Se recomienda que las implementaciones devuelvan un valor nulo por agotamiento de la memoria en lugar de entrar en pánico o abortar, pero este no es un requisito estricto.
    /// (Específicamente: es *legal* implementar este trait encima de una biblioteca de asignación nativa subyacente que aborta cuando se agota la memoria).
    ///
    /// Se recomienda a los clientes que deseen abortar el cálculo en respuesta a un error de reasignación que llamen a la función [`handle_alloc_error`], en lugar de invocar directamente `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SEGURIDAD: la persona que llama debe asegurarse de que el `new_size` no se desborde.
        // `layout.align()` proviene de un `Layout` y, por lo tanto, se garantiza su validez.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SEGURIDAD: la persona que llama debe asegurarse de que `new_layout` sea mayor que cero.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SEGURIDAD: el bloque asignado anteriormente no puede superponerse al bloque recién asignado.
            // La persona que llama debe respetar el contrato de seguridad para `dealloc`.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}