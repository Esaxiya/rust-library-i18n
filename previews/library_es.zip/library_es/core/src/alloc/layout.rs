use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Si bien esta función se usa en un solo lugar y su implementación podría estar insertada, los intentos anteriores de hacerlo hicieron que rustc sea más lento:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Disposición de un bloque de memoria.
///
/// Una instancia de `Layout` describe un diseño particular de memoria.
/// Construye un `Layout` como entrada para dárselo a un asignador.
///
/// Todos los diseños tienen un tamaño asociado y una alineación de potencia de dos.
///
/// (Tenga en cuenta que *no* se requiere que los diseños tengan un tamaño distinto de cero, aunque `GlobalAlloc` requiere que todas las solicitudes de memoria tengan un tamaño distinto de cero.
/// Una persona que llama debe asegurarse de que se cumplan condiciones como esta, usar asignadores específicos con requisitos más flexibles o usar la interfaz `Allocator` más indulgente).
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // tamaño del bloque de memoria solicitado, medido en bytes.
    size_: usize,

    // alineación del bloque de memoria solicitado, medida en bytes.
    // nos aseguramos de que esto sea siempre una potencia de dos, porque las API como `posix_memalign` lo requieren y es una restricción razonable para imponer a los constructores de Layout.
    //
    //
    // (Sin embargo, no requerimos análogamente `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Construye un `Layout` a partir de un `size` y `align` dados, o devuelve `LayoutError` si no se cumple alguna de las siguientes condiciones:
    ///
    /// * `align` no debe ser cero,
    ///
    /// * `align` debe ser un poder de dos,
    ///
    /// * `size`, cuando se redondea al múltiplo más cercano de `align`, no debe desbordarse (es decir, el valor redondeado debe ser menor o igual que `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (potencia de dos implica alinear!=0.)

        // El tamaño redondeado es:
        //   tamaño_rodeado_up=(tamaño + alinear, 1)&! (alinear, 1);
        //
        // Sabemos desde arriba que align!=0.
        // Si la suma (alinear, 1) no se desborda, entonces el redondeo estará bien.
        //
        // Por el contrario,&-masking con! (Align, 1) restará solo bits de orden bajo.
        // Por lo tanto, si se produce un desbordamiento con la suma, la&-mask no puede restar lo suficiente para deshacer ese desbordamiento.
        //
        //
        // Lo anterior implica que la verificación del desbordamiento de la suma es necesaria y suficiente.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SEGURIDAD: se han cumplido las condiciones para `from_size_align_unchecked`
        // marcado arriba.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Crea un diseño, omitiendo todas las comprobaciones.
    ///
    /// # Safety
    ///
    /// Esta función no es segura ya que no verifica las condiciones previas de [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SEGURIDAD: la persona que llama debe asegurarse de que `align` sea mayor que cero.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// El tamaño mínimo en bytes para un bloque de memoria de este diseño.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// La alineación de bytes mínima para un bloque de memoria de este diseño.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Construye un `Layout` adecuado para contener un valor de tipo `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SEGURIDAD: Rust garantiza que la alineación es una potencia de dos y
        // el combo tamaño + alineación está garantizado para caber en nuestro espacio de direcciones.
        // Como resultado, use el constructor desmarcado aquí para evitar insertar código que panics si no está lo suficientemente optimizado.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produce un diseño que describe un registro que podría usarse para asignar una estructura de respaldo para `T` (que podría ser un trait u otro tipo sin tamaño como un segmento).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SEGURIDAD: consulte la justificación en `new` de por qué se utiliza la variante insegura
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produce un diseño que describe un registro que podría usarse para asignar una estructura de respaldo para `T` (que podría ser un trait u otro tipo sin tamaño como un segmento).
    ///
    /// # Safety
    ///
    /// Solo es seguro llamar a esta función si se cumplen las siguientes condiciones:
    ///
    /// - Si `T` es `Sized`, siempre es seguro llamar a esta función.
    /// - Si la cola sin tamaño de `T` es:
    ///     - a [slice], entonces la longitud de la cola del segmento debe ser un número entero inicializado y el tamaño del *valor completo*(longitud de cola dinámica + prefijo de tamaño estático) debe caber en `isize`.
    ///     - a [trait object], entonces la parte vtable del puntero debe apuntar a una vtable válida para el tipo `T` adquirido por una coersión sin tamaño, y el tamaño del *valor completo*(longitud de cola dinámica + prefijo de tamaño estático) debe caber en `isize`.
    ///
    ///     - un (unstable) [extern type], entonces esta función siempre es segura para llamar, pero puede panic o devolver el valor incorrecto, ya que no se conoce el diseño del tipo externo.
    ///     Este es el mismo comportamiento que [`Layout::for_value`] en una referencia a una cola de tipo externo.
    ///     - de lo contrario, no se permite de forma conservadora llamar a esta función.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SEGURIDAD: transmitimos los requisitos previos de estas funciones a la persona que llama
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SEGURIDAD: consulte la justificación en `new` de por qué se utiliza la variante insegura
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Crea un `NonNull` que cuelga, pero bien alineado para este diseño.
    ///
    /// Tenga en cuenta que el valor del puntero puede representar potencialmente un puntero válido, lo que significa que no debe utilizarse como un valor centinela "not yet initialized".
    /// Los tipos que asignan de manera perezosa deben realizar un seguimiento de la inicialización por otros medios.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SEGURIDAD: se garantiza que la alineación sea distinta de cero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Crea un diseño que describe el registro que puede contener un valor del mismo diseño que `self`, pero que también está alineado con la alineación `align` (medido en bytes).
    ///
    ///
    /// Si `self` ya cumple con la alineación prescrita, devuelve `self`.
    ///
    /// Tenga en cuenta que este método no agrega ningún relleno al tamaño general, independientemente de si el diseño devuelto tiene una alineación diferente.
    /// En otras palabras, si `K` tiene el tamaño 16, `K.align_to(32)`*todavía* tendrá el tamaño 16.
    ///
    /// Devuelve un error si la combinación de `self.size()` y el `align` dado viola las condiciones enumeradas en [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Devuelve la cantidad de relleno que debemos insertar después de `self` para garantizar que la siguiente dirección satisfaga `align` (medido en bytes).
    ///
    /// por ejemplo, si `self.size()` es 9, entonces `self.padding_needed_for(4)` devuelve 3, porque ese es el número mínimo de bytes de relleno necesarios para obtener una dirección alineada en 4 (asumiendo que el bloque de memoria correspondiente comienza en una dirección alineada en 4).
    ///
    ///
    /// El valor de retorno de esta función no tiene significado si `align` no es una potencia de dos.
    ///
    /// Tenga en cuenta que la utilidad del valor devuelto requiere que `align` sea menor o igual que la alineación de la dirección inicial para todo el bloque de memoria asignado.Una forma de satisfacer esta restricción es garantizar `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // El valor redondeado es:
        //   len_unded_up=(len + alinear, 1)&! (alinear, 1);
        // y luego devolvemos la diferencia de relleno: `len_rounded_up - len`.
        //
        // Usamos aritmética modular en todo:
        //
        // 1. Se garantiza que align es> 0, por lo que align, 1 siempre es válido.
        //
        // 2.
        // `len + align - 1` puede desbordarse como máximo en `align - 1`, por lo que la&-mask con `!(align - 1)` asegurará que, en caso de desbordamiento, `len_rounded_up` será 0.
        //
        //    Por lo tanto, el relleno devuelto, cuando se agrega a `len`, produce 0, que satisface trivialmente la alineación `align`.
        //
        // (Por supuesto, los intentos de asignar bloques de memoria cuyo tamaño y desbordamiento de relleno de la manera anterior deberían hacer que el asignador produzca un error de todos modos).
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Crea un diseño redondeando el tamaño de este diseño a un múltiplo de la alineación del diseño.
    ///
    ///
    /// Esto equivale a agregar el resultado de `padding_needed_for` al tamaño actual del diseño.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Esto no puede desbordarse.Citando del invariante de Layout:
        // > `size`, cuando se redondea al múltiplo más cercano de `align`,
        // > no debe desbordarse (es decir, el valor redondeado debe ser menor que
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Crea un diseño que describe el registro para las instancias `n` de `self`, con una cantidad adecuada de relleno entre cada uno para garantizar que a cada instancia se le asigne el tamaño y la alineación solicitados.
    /// En caso de éxito, devuelve `(k, offs)` donde `k` es el diseño de la matriz y `offs` es la distancia entre el inicio de cada elemento de la matriz.
    ///
    /// En caso de desbordamiento aritmético, devuelve `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Esto no puede desbordarse.Citando del invariante de Layout:
        // > `size`, cuando se redondea al múltiplo más cercano de `align`,
        // > no debe desbordarse (es decir, el valor redondeado debe ser menor que
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SEGURIDAD: Ya se sabe que self.align es válido y alloc_size ha sido
        // ya acolchado.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Crea un diseño que describe el registro para `self` seguido de `next`, incluido el relleno necesario para garantizar que `next` se alineará correctamente, pero *sin relleno final*.
    ///
    /// Para hacer coincidir el diseño de representación C `repr(C)`, debe llamar a `pad_to_align` después de extender el diseño con todos los campos.
    /// (No hay forma de coincidir con el diseño de representación predeterminado Rust `repr(Rust)`, as it is unspecified.)
    ///
    /// Tenga en cuenta que la alineación del diseño resultante será la máxima de las de `self` y `next`, con el fin de garantizar la alineación de ambas partes.
    ///
    /// Devuelve `Ok((k, offset))`, donde `k` es el diseño del registro concatenado y `offset` es la ubicación relativa, en bytes, del inicio del `next` incrustado dentro del registro concatenado (asumiendo que el registro en sí comienza en el desplazamiento 0).
    ///
    ///
    /// En caso de desbordamiento aritmético, devuelve `LayoutError`.
    ///
    /// # Examples
    ///
    /// Para calcular el diseño de una estructura `#[repr(C)]` y las compensaciones de los campos de los diseños de sus campos:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // ¡Recuerde finalizar con `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // prueba que funciona
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Crea un diseño que describe el registro para instancias `n` de `self`, sin relleno entre cada instancia.
    ///
    /// Tenga en cuenta que, a diferencia de `repeat`, `repeat_packed` no garantiza que las instancias repetidas de `self` estén alineadas correctamente, incluso si una instancia determinada de `self` está alineada correctamente.
    /// En otras palabras, si el diseño devuelto por `repeat_packed` se usa para asignar una matriz, no se garantiza que todos los elementos de la matriz estén alineados correctamente.
    ///
    /// En caso de desbordamiento aritmético, devuelve `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Crea un diseño que describe el registro para `self` seguido de `next` sin relleno adicional entre los dos.
    /// Dado que no se inserta ningún relleno, la alineación de `next` es irrelevante y no se incorpora *en absoluto* en el diseño resultante.
    ///
    ///
    /// En caso de desbordamiento aritmético, devuelve `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Crea un diseño que describe el registro de un `[T; n]`.
    ///
    /// En caso de desbordamiento aritmético, devuelve `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Los parámetros dados a `Layout::from_size_align` o algún otro constructor de `Layout` no satisfacen sus restricciones documentadas.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (necesitamos esto para la implicación descendente del error trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}