//! API de asignación de memoria

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// El error `AllocError` indica un error de asignación que puede deberse al agotamiento de los recursos oa algo incorrecto al combinar los argumentos de entrada dados con este asignador.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (necesitamos esto para la implicación descendente del error trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Una implementación de `Allocator` puede asignar, aumentar, reducir y desasignar bloques arbitrarios de datos descritos a través de [`Layout`][].
///
/// `Allocator` está diseñado para implementarse en ZST, referencias o punteros inteligentes porque tener un asignador como `MyAlloc([u8; N])` no se puede mover sin actualizar los punteros a la memoria asignada.
///
/// A diferencia de [`GlobalAlloc`][], se permiten asignaciones de tamaño cero en `Allocator`.
/// Si un asignador subyacente no admite esto (como jemalloc) o devuelve un puntero nulo (como `libc::malloc`), la implementación debe detectarlo.
///
/// ### Memoria asignada actualmente
///
/// Algunos de los métodos requieren que un bloque de memoria esté *actualmente asignado* a través de un asignador.Esto significa que:
///
/// * la dirección inicial para ese bloque de memoria fue previamente devuelta por [`allocate`], [`grow`] o [`shrink`], y
///
/// * el bloque de memoria no se ha desasignado posteriormente, donde los bloques se desasignan directamente al pasar a [`deallocate`] o se cambiaron al pasar a [`grow`] o [`shrink`] que devuelve `Ok`.
///
/// Si `grow` o `shrink` han devuelto `Err`, el puntero pasado sigue siendo válido.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Ajuste de memoria
///
/// Algunos de los métodos requieren que un diseño *se ajuste* a un bloque de memoria.
/// Lo que significa para un diseño para "fit" un bloque de memoria significa (o de manera equivalente, para un bloque de memoria para "fit" un diseño) es que se deben cumplir las siguientes condiciones:
///
/// * El bloque debe asignarse con la misma alineación que [`layout.align()`], y
///
/// * El [`layout.size()`] proporcionado debe estar en el rango `min ..= max`, donde:
///   - `min` es el tamaño del diseño utilizado más recientemente para asignar el bloque, y
///   - `max` es el último tamaño real devuelto por [`allocate`], [`grow`] o [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Los bloques de memoria devueltos por un asignador deben apuntar a una memoria válida y conservar su validez hasta que se eliminen la instancia y todos sus clones.
///
/// * clonar o mover el asignador no debe invalidar los bloques de memoria devueltos por este asignador.Un asignador clonado debe comportarse como el mismo asignador y
///
/// * cualquier puntero a un bloque de memoria que sea [*currently allocated*] puede pasarse a cualquier otro método del asignador.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Intenta asignar un bloque de memoria.
    ///
    /// Si tiene éxito, devuelve un [`NonNull<[u8]>`][NonNull] que cumple con las garantías de tamaño y alineación de `layout`.
    ///
    /// El bloque devuelto puede tener un tamaño mayor que el especificado por `layout.size()` y puede o no tener su contenido inicializado.
    ///
    /// # Errors
    ///
    /// Devolver `Err` indica que la memoria está agotada o que `layout` no cumple con las restricciones de alineación o tamaño del asignador.
    ///
    /// Se recomienda a las implementaciones que devuelvan `Err` cuando se agote la memoria en lugar de entrar en pánico o abortar, pero este no es un requisito estricto.
    /// (Específicamente: es *legal* implementar este trait encima de una biblioteca de asignación nativa subyacente que aborta cuando se agota la memoria).
    ///
    /// Se recomienda a los clientes que deseen abortar el cálculo en respuesta a un error de asignación que llamen a la función [`handle_alloc_error`], en lugar de invocar directamente `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Se comporta como `allocate`, pero también garantiza que la memoria devuelta se inicialice a cero.
    ///
    /// # Errors
    ///
    /// Devolver `Err` indica que la memoria está agotada o que `layout` no cumple con las restricciones de alineación o tamaño del asignador.
    ///
    /// Se recomienda a las implementaciones que devuelvan `Err` cuando se agote la memoria en lugar de entrar en pánico o abortar, pero este no es un requisito estricto.
    /// (Específicamente: es *legal* implementar este trait encima de una biblioteca de asignación nativa subyacente que aborta cuando se agota la memoria).
    ///
    /// Se recomienda a los clientes que deseen abortar el cálculo en respuesta a un error de asignación que llamen a la función [`handle_alloc_error`], en lugar de invocar directamente `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SEGURIDAD: `alloc` devuelve un bloque de memoria válido
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Desasigna la memoria a la que hace referencia `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` debe denotar un bloque de memoria [*currently allocated*] a través de este asignador, y
    /// * `layout` Debe [*fit*] ese bloque de memoria.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Intenta ampliar el bloque de memoria.
    ///
    /// Devuelve un nuevo [`NonNull<[u8]>`][NonNull] que contiene un puntero y el tamaño real de la memoria asignada.El puntero es adecuado para almacenar datos descritos por `new_layout`.
    /// Para lograr esto, el asignador puede extender la asignación a la que hace referencia `ptr` para adaptarse al nuevo diseño.
    ///
    /// Si devuelve `Ok`, entonces la propiedad del bloque de memoria al que hace referencia `ptr` se ha transferido a este asignador.
    /// Es posible que la memoria se haya liberado o no, y debe considerarse inutilizable a menos que se haya transferido nuevamente a la persona que llama a través del valor de retorno de este método.
    ///
    /// Si este método devuelve `Err`, entonces la propiedad del bloque de memoria no se ha transferido a este asignador y el contenido del bloque de memoria no se modifica.
    ///
    /// # Safety
    ///
    /// * `ptr` debe denotar un bloque de memoria [*currently allocated*] a través de este asignador.
    /// * `old_layout` debe [*fit*] ese bloque de memoria (el argumento `new_layout` no necesita ajustarse).
    /// * `new_layout.size()` debe ser mayor o igual que `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Devuelve `Err` si el nuevo diseño no cumple con las restricciones de alineación y tamaño del asignador del asignador, o si el crecimiento falla.
    ///
    /// Se recomienda a las implementaciones que devuelvan `Err` cuando se agote la memoria en lugar de entrar en pánico o abortar, pero este no es un requisito estricto.
    /// (Específicamente: es *legal* implementar este trait encima de una biblioteca de asignación nativa subyacente que aborta cuando se agota la memoria).
    ///
    /// Se recomienda a los clientes que deseen abortar el cálculo en respuesta a un error de asignación que llamen a la función [`handle_alloc_error`], en lugar de invocar directamente `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SEGURIDAD: porque `new_layout.size()` debe ser mayor o igual que
        // `old_layout.size()`, tanto la asignación de memoria antigua como la nueva son válidas para lecturas y escrituras de `old_layout.size()` bytes.
        // Además, debido a que la asignación anterior aún no se desasignó, no puede superponerse a `new_ptr`.
        // Por tanto, la llamada a `copy_nonoverlapping` es segura.
        // La persona que llama debe respetar el contrato de seguridad para `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Se comporta como `grow`, pero también garantiza que los nuevos contenidos se establezcan en cero antes de ser devueltos.
    ///
    /// El bloque de memoria contendrá los siguientes contenidos después de una llamada exitosa a
    /// `grow_zeroed`:
    ///   * Los bytes `0..old_layout.size()` se conservan de la asignación original.
    ///   * Los bytes `old_layout.size()..old_size` se conservarán o se pondrán a cero, según la implementación del asignador.
    ///   `old_size` se refiere al tamaño del bloque de memoria antes de la llamada `grow_zeroed`, que puede ser mayor que el tamaño que se solicitó originalmente cuando se asignó.
    ///   * Los bytes `old_size..new_size` se ponen a cero.`new_size` se refiere al tamaño del bloque de memoria devuelto por la llamada `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` debe denotar un bloque de memoria [*currently allocated*] a través de este asignador.
    /// * `old_layout` debe [*fit*] ese bloque de memoria (el argumento `new_layout` no necesita ajustarse).
    /// * `new_layout.size()` debe ser mayor o igual que `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Devuelve `Err` si el nuevo diseño no cumple con las restricciones de alineación y tamaño del asignador del asignador, o si el crecimiento falla.
    ///
    /// Se recomienda a las implementaciones que devuelvan `Err` cuando se agote la memoria en lugar de entrar en pánico o abortar, pero este no es un requisito estricto.
    /// (Específicamente: es *legal* implementar este trait encima de una biblioteca de asignación nativa subyacente que aborta cuando se agota la memoria).
    ///
    /// Se recomienda a los clientes que deseen abortar el cálculo en respuesta a un error de asignación que llamen a la función [`handle_alloc_error`], en lugar de invocar directamente `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SEGURIDAD: porque `new_layout.size()` debe ser mayor o igual que
        // `old_layout.size()`, tanto la asignación de memoria antigua como la nueva son válidas para lecturas y escrituras de `old_layout.size()` bytes.
        // Además, debido a que la asignación anterior aún no se desasignó, no puede superponerse a `new_ptr`.
        // Por tanto, la llamada a `copy_nonoverlapping` es segura.
        // La persona que llama debe respetar el contrato de seguridad para `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Intenta reducir el bloque de memoria.
    ///
    /// Devuelve un nuevo [`NonNull<[u8]>`][NonNull] que contiene un puntero y el tamaño real de la memoria asignada.El puntero es adecuado para almacenar datos descritos por `new_layout`.
    /// Para lograr esto, el asignador puede reducir la asignación a la que hace referencia `ptr` para adaptarse al nuevo diseño.
    ///
    /// Si devuelve `Ok`, entonces la propiedad del bloque de memoria al que hace referencia `ptr` se ha transferido a este asignador.
    /// Es posible que la memoria se haya liberado o no, y debe considerarse inutilizable a menos que se haya transferido nuevamente a la persona que llama a través del valor de retorno de este método.
    ///
    /// Si este método devuelve `Err`, entonces la propiedad del bloque de memoria no se ha transferido a este asignador y el contenido del bloque de memoria no se modifica.
    ///
    /// # Safety
    ///
    /// * `ptr` debe denotar un bloque de memoria [*currently allocated*] a través de este asignador.
    /// * `old_layout` debe [*fit*] ese bloque de memoria (el argumento `new_layout` no necesita ajustarse).
    /// * `new_layout.size()` debe ser menor o igual que `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Devuelve `Err` si el nuevo diseño no cumple con las restricciones de alineación y tamaño del asignador del asignador, o si la reducción falla.
    ///
    /// Se recomienda a las implementaciones que devuelvan `Err` cuando se agote la memoria en lugar de entrar en pánico o abortar, pero este no es un requisito estricto.
    /// (Específicamente: es *legal* implementar este trait encima de una biblioteca de asignación nativa subyacente que aborta cuando se agota la memoria).
    ///
    /// Se recomienda a los clientes que deseen abortar el cálculo en respuesta a un error de asignación que llamen a la función [`handle_alloc_error`], en lugar de invocar directamente `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SEGURIDAD: porque `new_layout.size()` debe ser menor o igual que
        // `old_layout.size()`, tanto la asignación de memoria antigua como la nueva son válidas para lecturas y escrituras de `new_layout.size()` bytes.
        // Además, debido a que la asignación anterior aún no se desasignó, no puede superponerse a `new_ptr`.
        // Por tanto, la llamada a `copy_nonoverlapping` es segura.
        // La persona que llama debe respetar el contrato de seguridad para `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Crea un adaptador "by reference" para esta instancia de `Allocator`.
    ///
    /// El adaptador devuelto también implementa `Allocator` y simplemente lo tomará prestado.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}