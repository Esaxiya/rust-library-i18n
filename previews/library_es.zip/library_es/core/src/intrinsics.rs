//! Intrínsecos del compilador.
//!
//! Las definiciones correspondientes están en `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Las implementaciones const correspondientes están en `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrínsecos
//!
//! Note: cualquier cambio en la consistencia de los elementos intrínsecos debe discutirse con el equipo de idiomas.
//! Esto incluye cambios en la estabilidad de la constness.
//!
//! Para hacer un intrínseco utilizable en tiempo de compilación, es necesario copiar la implementación de <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> a `compiler/rustc_mir/src/interpret/intrinsics.rs` y agregar un `#[rustc_const_unstable(feature = "foo", issue = "01234")]` al intrínseco.
//!
//!
//! Si se supone que se va a utilizar un intrínseco desde un `const fn` con un atributo `rustc_const_stable`, el atributo del intrínseco también debe ser `rustc_const_stable`.
//! Este cambio no debe realizarse sin la consulta de T-lang, porque integra una característica en el lenguaje que no se puede replicar en el código de usuario sin el soporte del compilador.
//!
//! # Volatiles
//!
//! Los intrínsecos volátiles proporcionan operaciones destinadas a actuar en la memoria I/O, que están garantizadas para que el compilador no los reordene a través de otros intrínsecos volátiles.Consulte la documentación de LLVM sobre [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Los intrínsecos atómicos proporcionan operaciones atómicas comunes en palabras de máquina, con múltiples ordenaciones de memoria posibles.Obedecen la misma semántica que C++ 11.Consulte la documentación de LLVM sobre [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Un repaso rápido sobre los pedidos de memoria:
//!
//! * Adquirir, una barrera para adquirir un candado.Las lecturas y escrituras posteriores tienen lugar después de la barrera.
//! * Release, una barrera para liberar un candado.Las lecturas y escrituras anteriores tienen lugar antes de la barrera.
//! * Se garantiza que las operaciones secuencialmente consistentes, secuencialmente consistentes sucedan en orden.Este es el modo estándar para trabajar con tipos atómicos y es equivalente al `volatile` de Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Estas importaciones se utilizan para simplificar los enlaces intradoc.
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SEGURIDAD: ver `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, estos elementos intrínsecos toman punteros sin procesar porque mutan la memoria con alias, que no es válida para `&` o `&mut`.
    //

    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange` pasando [`Ordering::SeqCst`] como los parámetros `success` y `failure`.
    ///
    /// Por ejemplo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange` pasando [`Ordering::Acquire`] como los parámetros `success` y `failure`.
    ///
    /// Por ejemplo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange` pasando [`Ordering::Release`] como `success` y [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por ejemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange` pasando [`Ordering::AcqRel`] como `success` y [`Ordering::Acquire`] como parámetros `failure`.
    /// Por ejemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange` pasando [`Ordering::Relaxed`] como los parámetros `success` y `failure`.
    ///
    /// Por ejemplo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange` pasando [`Ordering::SeqCst`] como `success` y [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por ejemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange` pasando [`Ordering::SeqCst`] como `success` y [`Ordering::Acquire`] como parámetros `failure`.
    /// Por ejemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange` pasando [`Ordering::Acquire`] como `success` y [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por ejemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange` pasando [`Ordering::AcqRel`] como `success` y [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por ejemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange_weak` pasando [`Ordering::SeqCst`] como los parámetros `success` y `failure`.
    ///
    /// Por ejemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange_weak` pasando [`Ordering::Acquire`] como los parámetros `success` y `failure`.
    ///
    /// Por ejemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange_weak` pasando [`Ordering::Release`] como `success` y [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por ejemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange_weak` pasando [`Ordering::AcqRel`] como `success` y [`Ordering::Acquire`] como parámetros `failure`.
    /// Por ejemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange_weak` pasando [`Ordering::Relaxed`] como los parámetros `success` y `failure`.
    ///
    /// Por ejemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange_weak` pasando [`Ordering::SeqCst`] como `success` y [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por ejemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange_weak` pasando [`Ordering::SeqCst`] como `success` y [`Ordering::Acquire`] como parámetros `failure`.
    /// Por ejemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange_weak` pasando [`Ordering::Acquire`] como `success` y [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por ejemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor si el valor actual es el mismo que el valor `old`.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `compare_exchange_weak` pasando [`Ordering::AcqRel`] como `success` y [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por ejemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Carga el valor actual del puntero.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `load` pasando [`Ordering::SeqCst`] como `order`.
    /// Por ejemplo, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Carga el valor actual del puntero.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `load` pasando [`Ordering::Acquire`] como `order`.
    /// Por ejemplo, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Carga el valor actual del puntero.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `load` pasando [`Ordering::Relaxed`] como `order`.
    /// Por ejemplo, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Almacena el valor en la ubicación de memoria especificada.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `store` pasando [`Ordering::SeqCst`] como `order`.
    /// Por ejemplo, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Almacena el valor en la ubicación de memoria especificada.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `store` pasando [`Ordering::Release`] como `order`.
    /// Por ejemplo, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Almacena el valor en la ubicación de memoria especificada.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `store` pasando [`Ordering::Relaxed`] como `order`.
    /// Por ejemplo, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Almacena el valor en la ubicación de memoria especificada, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `swap` pasando [`Ordering::SeqCst`] como `order`.
    /// Por ejemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Almacena el valor en la ubicación de memoria especificada, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `swap` pasando [`Ordering::Acquire`] como `order`.
    /// Por ejemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Almacena el valor en la ubicación de memoria especificada, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `swap` pasando [`Ordering::Release`] como `order`.
    /// Por ejemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Almacena el valor en la ubicación de memoria especificada, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `swap` pasando [`Ordering::AcqRel`] como `order`.
    /// Por ejemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Almacena el valor en la ubicación de memoria especificada, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `swap` pasando [`Ordering::Relaxed`] como `order`.
    /// Por ejemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Se suma al valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_add` pasando [`Ordering::SeqCst`] como `order`.
    /// Por ejemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Se suma al valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_add` pasando [`Ordering::Acquire`] como `order`.
    /// Por ejemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Se suma al valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_add` pasando [`Ordering::Release`] como `order`.
    /// Por ejemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Se suma al valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_add` pasando [`Ordering::AcqRel`] como `order`.
    /// Por ejemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Se suma al valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_add` pasando [`Ordering::Relaxed`] como `order`.
    /// Por ejemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Restar del valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_sub` pasando [`Ordering::SeqCst`] como `order`.
    /// Por ejemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Restar del valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_sub` pasando [`Ordering::Acquire`] como `order`.
    /// Por ejemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Restar del valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_sub` pasando [`Ordering::Release`] como `order`.
    /// Por ejemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Restar del valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_sub` pasando [`Ordering::AcqRel`] como `order`.
    /// Por ejemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Restar del valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_sub` pasando [`Ordering::Relaxed`] como `order`.
    /// Por ejemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise y con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_and` pasando [`Ordering::SeqCst`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise y con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_and` pasando [`Ordering::Acquire`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise y con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_and` pasando [`Ordering::Release`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise y con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_and` pasando [`Ordering::AcqRel`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise y con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_and` pasando [`Ordering::Relaxed`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Nand bit a bit con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en el tipo [`AtomicBool`] a través del método `fetch_nand` pasando [`Ordering::SeqCst`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand bit a bit con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en el tipo [`AtomicBool`] a través del método `fetch_nand` pasando [`Ordering::Acquire`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand bit a bit con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en el tipo [`AtomicBool`] a través del método `fetch_nand` pasando [`Ordering::Release`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand bit a bit con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en el tipo [`AtomicBool`] a través del método `fetch_nand` pasando [`Ordering::AcqRel`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand bit a bit con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en el tipo [`AtomicBool`] a través del método `fetch_nand` pasando [`Ordering::Relaxed`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise o con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_or` pasando [`Ordering::SeqCst`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_or` pasando [`Ordering::Acquire`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_or` pasando [`Ordering::Release`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_or` pasando [`Ordering::AcqRel`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_or` pasando [`Ordering::Relaxed`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_xor` pasando [`Ordering::SeqCst`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_xor` pasando [`Ordering::Acquire`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_xor` pasando [`Ordering::Release`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_xor` pasando [`Ordering::AcqRel`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor con el valor actual, devolviendo el valor anterior.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos [`atomic`] a través del método `fetch_xor` pasando [`Ordering::Relaxed`] como `order`.
    /// Por ejemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Máximo con el valor actual usando una comparación con signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros con signo [`atomic`] a través del método `fetch_max` pasando [`Ordering::SeqCst`] como `order`.
    /// Por ejemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo con el valor actual usando una comparación con signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros con signo [`atomic`] a través del método `fetch_max` pasando [`Ordering::Acquire`] como `order`.
    /// Por ejemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo con el valor actual usando una comparación con signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros con signo [`atomic`] a través del método `fetch_max` pasando [`Ordering::Release`] como `order`.
    /// Por ejemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo con el valor actual usando una comparación con signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros con signo [`atomic`] a través del método `fetch_max` pasando [`Ordering::AcqRel`] como `order`.
    /// Por ejemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo con el valor actual.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros con signo [`atomic`] a través del método `fetch_max` pasando [`Ordering::Relaxed`] como `order`.
    /// Por ejemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mínimo con el valor actual usando una comparación con signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros con signo [`atomic`] a través del método `fetch_min` pasando [`Ordering::SeqCst`] como `order`.
    /// Por ejemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo con el valor actual usando una comparación con signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros con signo [`atomic`] a través del método `fetch_min` pasando [`Ordering::Acquire`] como `order`.
    /// Por ejemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo con el valor actual usando una comparación con signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros con signo [`atomic`] a través del método `fetch_min` pasando [`Ordering::Release`] como `order`.
    /// Por ejemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo con el valor actual usando una comparación con signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros con signo [`atomic`] a través del método `fetch_min` pasando [`Ordering::AcqRel`] como `order`.
    /// Por ejemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo con el valor actual usando una comparación con signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros con signo [`atomic`] a través del método `fetch_min` pasando [`Ordering::Relaxed`] como `order`.
    /// Por ejemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mínimo con el valor actual usando una comparación sin signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros sin signo [`atomic`] a través del método `fetch_min` pasando [`Ordering::SeqCst`] como `order`.
    /// Por ejemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo con el valor actual usando una comparación sin signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros sin signo [`atomic`] a través del método `fetch_min` pasando [`Ordering::Acquire`] como `order`.
    /// Por ejemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo con el valor actual usando una comparación sin signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros sin signo [`atomic`] a través del método `fetch_min` pasando [`Ordering::Release`] como `order`.
    /// Por ejemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo con el valor actual usando una comparación sin signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros sin signo [`atomic`] a través del método `fetch_min` pasando [`Ordering::AcqRel`] como `order`.
    /// Por ejemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo con el valor actual usando una comparación sin signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros sin signo [`atomic`] a través del método `fetch_min` pasando [`Ordering::Relaxed`] como `order`.
    /// Por ejemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Máximo con el valor actual usando una comparación sin signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros sin signo [`atomic`] a través del método `fetch_max` pasando [`Ordering::SeqCst`] como `order`.
    /// Por ejemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo con el valor actual usando una comparación sin signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros sin signo [`atomic`] a través del método `fetch_max` pasando [`Ordering::Acquire`] como `order`.
    /// Por ejemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo con el valor actual usando una comparación sin signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros sin signo [`atomic`] a través del método `fetch_max` pasando [`Ordering::Release`] como `order`.
    /// Por ejemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo con el valor actual usando una comparación sin signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros sin signo [`atomic`] a través del método `fetch_max` pasando [`Ordering::AcqRel`] como `order`.
    /// Por ejemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo con el valor actual usando una comparación sin signo.
    ///
    /// La versión estabilizada de este intrínseco está disponible en los tipos de enteros sin signo [`atomic`] a través del método `fetch_max` pasando [`Ordering::Relaxed`] como `order`.
    /// Por ejemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// El intrínseco `prefetch` es una sugerencia para que el generador de código inserte una instrucción de captación previa si es compatible;de lo contrario, no es una operación.
    /// Las captaciones previas no tienen ningún efecto sobre el comportamiento del programa, pero pueden cambiar sus características de rendimiento.
    ///
    /// El argumento `locality` debe ser un entero constante y es un especificador de localidad temporal que va desde (0), sin localidad, a (3), extremadamente local mantener en caché.
    ///
    ///
    /// Este intrínseco no tiene una contraparte estable.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// El intrínseco `prefetch` es una sugerencia para que el generador de código inserte una instrucción de captación previa si es compatible;de lo contrario, no es una operación.
    /// Las captaciones previas no tienen ningún efecto sobre el comportamiento del programa, pero pueden cambiar sus características de rendimiento.
    ///
    /// El argumento `locality` debe ser un entero constante y es un especificador de localidad temporal que va desde (0), sin localidad, a (3), extremadamente local mantener en caché.
    ///
    ///
    /// Este intrínseco no tiene una contraparte estable.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// El intrínseco `prefetch` es una sugerencia para que el generador de código inserte una instrucción de captación previa si es compatible;de lo contrario, no es una operación.
    /// Las captaciones previas no tienen ningún efecto sobre el comportamiento del programa, pero pueden cambiar sus características de rendimiento.
    ///
    /// El argumento `locality` debe ser un entero constante y es un especificador de localidad temporal que va desde (0), sin localidad, a (3), extremadamente local mantener en caché.
    ///
    ///
    /// Este intrínseco no tiene una contraparte estable.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// El intrínseco `prefetch` es una sugerencia para que el generador de código inserte una instrucción de captación previa si es compatible;de lo contrario, no es una operación.
    /// Las captaciones previas no tienen ningún efecto sobre el comportamiento del programa, pero pueden cambiar sus características de rendimiento.
    ///
    /// El argumento `locality` debe ser un entero constante y es un especificador de localidad temporal que va desde (0), sin localidad, a (3), extremadamente local mantener en caché.
    ///
    ///
    /// Este intrínseco no tiene una contraparte estable.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Una valla atómica.
    ///
    /// La versión estabilizada de este intrínseco está disponible en [`atomic::fence`] pasando [`Ordering::SeqCst`] como `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Una valla atómica.
    ///
    /// La versión estabilizada de este intrínseco está disponible en [`atomic::fence`] pasando [`Ordering::Acquire`] como `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Una valla atómica.
    ///
    /// La versión estabilizada de este intrínseco está disponible en [`atomic::fence`] pasando [`Ordering::Release`] como `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Una valla atómica.
    ///
    /// La versión estabilizada de este intrínseco está disponible en [`atomic::fence`] pasando [`Ordering::AcqRel`] como `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Una barrera de memoria solo para compiladores.
    ///
    /// Los accesos a la memoria nunca serán reordenados a través de esta barrera por el compilador, pero no se emitirán instrucciones para ello.
    /// Esto es apropiado para operaciones en el mismo hilo que pueden ser reemplazadas, como cuando se interactúa con manejadores de señales.
    ///
    /// La versión estabilizada de este intrínseco está disponible en [`atomic::compiler_fence`] pasando [`Ordering::SeqCst`] como `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Una barrera de memoria solo para compiladores.
    ///
    /// Los accesos a la memoria nunca serán reordenados a través de esta barrera por el compilador, pero no se emitirán instrucciones para ello.
    /// Esto es apropiado para operaciones en el mismo hilo que pueden ser reemplazadas, como cuando se interactúa con manejadores de señales.
    ///
    /// La versión estabilizada de este intrínseco está disponible en [`atomic::compiler_fence`] pasando [`Ordering::Acquire`] como `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Una barrera de memoria solo para compiladores.
    ///
    /// Los accesos a la memoria nunca serán reordenados a través de esta barrera por el compilador, pero no se emitirán instrucciones para ello.
    /// Esto es apropiado para operaciones en el mismo hilo que pueden ser reemplazadas, como cuando se interactúa con manejadores de señales.
    ///
    /// La versión estabilizada de este intrínseco está disponible en [`atomic::compiler_fence`] pasando [`Ordering::Release`] como `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Una barrera de memoria solo para compiladores.
    ///
    /// Los accesos a la memoria nunca serán reordenados a través de esta barrera por el compilador, pero no se emitirán instrucciones para ello.
    /// Esto es apropiado para operaciones en el mismo hilo que pueden ser reemplazadas, como cuando se interactúa con manejadores de señales.
    ///
    /// La versión estabilizada de este intrínseco está disponible en [`atomic::compiler_fence`] pasando [`Ordering::AcqRel`] como `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magia intrínseca que deriva su significado de los atributos adscritos a la función.
    ///
    /// Por ejemplo, el flujo de datos usa esto para inyectar aserciones estáticas para que `rustc_peek(potentially_uninitialized)` realmente verifique dos veces que el flujo de datos realmente calculó que no está inicializado en ese punto del flujo de control.
    ///
    ///
    /// Este intrínseco no debe usarse fuera del compilador.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Anula la ejecución del proceso.
    ///
    /// Una versión más estable y fácil de usar de esta operación es [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informa al optimizador que este punto del código no es accesible, lo que permite optimizaciones adicionales.
    ///
    /// NB, esto es muy diferente de la macro `unreachable!()`: a diferencia de la macro, que panics cuando se ejecuta, es *comportamiento indefinido* llegar al código marcado con esta función.
    ///
    ///
    /// La versión estabilizada de este intrínseco es [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informa al optimizador que una condición siempre es verdadera.
    /// Si la condición es falsa, el comportamiento no está definido.
    ///
    /// No se genera código para este intrínseco, pero el optimizador intentará preservarlo (y su condición) entre pasadas, lo que puede interferir con la optimización del código circundante y reducir el rendimiento.
    /// No debe utilizarse si el optimizador puede descubrir el invariante por sí solo, o si no habilita ninguna optimización significativa.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Sugiere al compilador que es probable que la condición branch sea verdadera.
    /// Devuelve el valor que se le ha pasado.
    ///
    /// Cualquier uso que no sea con declaraciones `if` probablemente no tendrá ningún efecto.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Sugiere al compilador que es probable que la condición branch sea falsa.
    /// Devuelve el valor que se le ha pasado.
    ///
    /// Cualquier uso que no sea con declaraciones `if` probablemente no tendrá ningún efecto.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Ejecuta una trampa de punto de interrupción para que un depurador la inspeccione.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    pub fn breakpoint();

    /// El tamaño de un tipo en bytes.
    ///
    /// Más específicamente, este es el desplazamiento en bytes entre elementos sucesivos del mismo tipo, incluido el relleno de alineación.
    ///
    ///
    /// La versión estabilizada de este intrínseco es [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// La alineación mínima de un tipo.
    ///
    /// La versión estabilizada de este intrínseco es [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// La alineación preferida de un tipo.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// El tamaño del valor referenciado en bytes.
    ///
    /// La versión estabilizada de este intrínseco es [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// La alineación requerida del valor referenciado.
    ///
    /// La versión estabilizada de este intrínseco es [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Obtiene un segmento de cadena estática que contiene el nombre de un tipo.
    ///
    /// La versión estabilizada de este intrínseco es [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Obtiene un identificador que es globalmente único para el tipo especificado.
    /// Esta función devolverá el mismo valor para un tipo independientemente del crate en el que se invoque.
    ///
    ///
    /// La versión estabilizada de este intrínseco es [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Una protección para funciones inseguras que nunca se pueden ejecutar si `T` está deshabitado:
    /// Esto significará estáticamente panic o no hará nada.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Una protección para funciones inseguras que no se pueden ejecutar nunca si `T` no permite la inicialización cero: esto significará estáticamente panic o no hará nada.
    ///
    ///
    /// Este intrínseco no tiene una contraparte estable.
    pub fn assert_zero_valid<T>();

    /// Una protección para funciones inseguras que no se pueden ejecutar nunca si `T` tiene patrones de bits no válidos: esto significará panic estáticamente o no hará nada.
    ///
    ///
    /// Este intrínseco no tiene una contraparte estable.
    pub fn assert_uninit_valid<T>();

    /// Obtiene una referencia a un `Location` estático que indica dónde se llamó.
    ///
    /// Considere usar [`core::panic::Location::caller`](crate::panic::Location::caller) en su lugar.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Mueve un valor fuera del alcance sin ejecutar pegamento.
    ///
    /// Esto existe únicamente para [`mem::forget_unsized`];`forget` normal usa `ManuallyDrop` en su lugar.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterpreta los bits de un valor de un tipo como otro tipo.
    ///
    /// Ambos tipos deben tener el mismo tamaño.
    /// Ni el original ni el resultado pueden ser un [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` es semánticamente equivalente a un movimiento bit a bit de un tipo a otro.Copia los bits del valor de origen al valor de destino y luego olvida el original.
    /// Es equivalente al `memcpy` de C debajo del capó, al igual que el `transmute_copy`.
    ///
    /// Debido a que `transmute` es una operación por valor, la alineación de los *valores transmutados en sí* no es una preocupación.
    /// Al igual que con cualquier otra función, el compilador ya garantiza que tanto `T` como `U` estén correctamente alineados.
    /// Sin embargo, al transmutar valores que *apuntan a otra parte*(como punteros, referencias, casillas ...), el llamador debe garantizar la alineación adecuada de los valores apuntados.
    ///
    /// `transmute` es **increíblemente** inseguro.Hay una gran cantidad de formas de causar [undefined behavior][ub] con esta función.`transmute` debería ser el último recurso absoluto.
    ///
    /// El [nomicon](../../nomicon/transmutes.html) tiene documentación adicional.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Hay algunas cosas para las que `transmute` es realmente útil.
    ///
    /// Convirtiendo un puntero en un puntero de función.Esto *no* es portátil para máquinas donde los punteros de función y los punteros de datos tienen diferentes tamaños.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Prolongar una vida útil o acortar una vida útil invariable.¡Esto es Rust avanzado y muy inseguro!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// No se desespere: muchos usos de `transmute` se pueden lograr a través de otros medios.
    /// A continuación, se muestran aplicaciones comunes de `transmute` que pueden reemplazarse con construcciones más seguras.
    ///
    /// Convirtiendo bytes(`&[u8]`) sin procesar a `u32`, `f64`, etc .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // use `u32::from_ne_bytes` en su lugar
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // o use `u32::from_le_bytes` o `u32::from_be_bytes` para especificar el endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Convertir un puntero en un `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Use un yeso `as` en su lugar
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Convirtiendo un `*mut T` en un `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Use un nuevo mañana en su lugar
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Convirtiendo un `&mut T` en un `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Ahora, junte `as` y el représtamo, tenga en cuenta que el encadenamiento de `as` `as` no es transitivo
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Convirtiendo un `&str` en un `&[u8]`:
    ///
    /// ```
    /// // esta no es una buena forma de hacerlo.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Podrías usar `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // O simplemente use una cadena de bytes, si tiene control sobre la cadena literal
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Convirtiendo un `Vec<&T>` en un `Vec<Option<&T>>`.
    ///
    /// Para transmutar el tipo interno del contenido de un contenedor, debe asegurarse de no violar ninguno de los invariantes del contenedor.
    /// Para `Vec`, esto significa que tanto el tamaño *como la alineación* de los tipos internos deben coincidir.
    /// Otros contenedores pueden depender del tamaño del tipo, la alineación o incluso el `TypeId`, en cuyo caso la transmutación no sería posible en absoluto sin violar las invariantes del contenedor.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clona el vector ya que lo reutilizaremos más tarde
    /// let v_clone = v_orig.clone();
    ///
    /// // Uso de transmutar: esto se basa en el diseño de datos no especificado de `Vec`, lo cual es una mala idea y podría causar un comportamiento indefinido.
    /////
    /// // Sin embargo, no se puede copiar.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Esta es la forma segura y sugerida.
    /// // Sin embargo, copia todo el vector en una nueva matriz.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Esta es la forma insegura y sin copia adecuada de "transmuting" a `Vec`, sin depender del diseño de datos.
    /// // En lugar de llamar literalmente a `transmute`, realizamos un lanzamiento de puntero, pero en términos de convertir el tipo interno original (`&i32`) al nuevo (`Option<&i32>`), esto tiene las mismas advertencias.
    /////
    /// // Además de la información proporcionada anteriormente, también consulte la documentación de [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Actualice esto cuando vec_into_raw_parts esté estabilizado.
    ///     // Asegúrese de que el vector original no se caiga.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementación de `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Hay varias formas de hacer esto y hay varios problemas con la siguiente forma (transmute).
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // primero: transmutar no es seguro de tipos;todo lo que verifica es que T y
    ///         // U son del mismo tamaño.
    ///         // En segundo lugar, aquí mismo, tiene dos referencias mutables que apuntan a la misma memoria.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Esto elimina los problemas de seguridad del tipo;`&mut *`* solo *le dará un `&mut T` de un `&mut T` o `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // sin embargo, todavía tiene dos referencias mutables que apuntan a la misma memoria.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Así es como lo hace la biblioteca estándar.
    /// // Este es el mejor método, si necesita hacer algo como esto
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Esto ahora tiene tres referencias mutables que apuntan a la misma memoria.`slice`, el rvalue ret.0 y el rvalue ret.1.
    ///         // `slice` nunca se usa después de `let ptr = ...`, por lo que se puede tratar como "dead" y, por lo tanto, solo tiene dos rebanadas mutables reales.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Si bien esto hace que la const intrínseca sea estable, tenemos un código personalizado en const fn
    // controles que impiden su uso dentro de `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Devuelve `true` si el tipo real dado como `T` requiere gota de pegamento;devuelve `false` si el tipo real proporcionado para `T` implementa `Copy`.
    ///
    ///
    /// Si el tipo real no requiere gota de pegamento ni implementa `Copy`, entonces el valor de retorno de esta función no está especificado.
    ///
    /// La versión estabilizada de este intrínseco es [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Calcula el desplazamiento de un puntero.
    ///
    /// Esto se implementa como un intrínseco para evitar la conversión hacia y desde un entero, ya que la conversión arrojaría información de aliasing.
    ///
    /// # Safety
    ///
    /// Tanto el puntero inicial como el resultante deben estar dentro de los límites o un byte más allá del final de un objeto asignado.
    /// Si alguno de los punteros está fuera de los límites o se produce un desbordamiento aritmético, cualquier uso adicional del valor devuelto dará como resultado un comportamiento indefinido.
    ///
    ///
    /// La versión estabilizada de este intrínseco es [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Calcula el desplazamiento de un puntero, posiblemente envolviendo.
    ///
    /// Esto se implementa como un intrínseco para evitar convertir hacia y desde un número entero, ya que la conversión inhibe ciertas optimizaciones.
    ///
    /// # Safety
    ///
    /// A diferencia del intrínseco `offset`, este intrínseco no restringe el puntero resultante para apuntar a un byte más allá del final de un objeto asignado, y se envuelve con aritmética en complemento a dos.
    /// El valor resultante no es necesariamente válido para ser utilizado para acceder realmente a la memoria.
    ///
    /// La versión estabilizada de este intrínseco es [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Equivalente al intrínseco `llvm.memcpy.p0i8.0i8.*` apropiado, con un tamaño de `count`*`size_of::<T>()` y una alineación de
    ///
    /// `min_align_of::<T>()`
    ///
    /// El parámetro volátil se establece en `true`, por lo que no se optimizará a menos que el tamaño sea igual a cero.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equivalente al intrínseco `llvm.memmove.p0i8.0i8.*` apropiado, con un tamaño de `count* size_of::<T>()` y una alineación de
    ///
    /// `min_align_of::<T>()`
    ///
    /// El parámetro volátil se establece en `true`, por lo que no se optimizará a menos que el tamaño sea igual a cero.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equivalente al intrínseco `llvm.memset.p0i8.*` apropiado, con un tamaño de `count* size_of::<T>()` y una alineación de `min_align_of::<T>()`.
    ///
    ///
    /// El parámetro volátil se establece en `true`, por lo que no se optimizará a menos que el tamaño sea igual a cero.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Realiza una carga volátil desde el puntero `src`.
    ///
    /// La versión estabilizada de este intrínseco es [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Realiza un almacenamiento volátil al puntero `dst`.
    ///
    /// La versión estabilizada de este intrínseco es [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Realiza una carga volátil desde el puntero `src` No es necesario que el puntero esté alineado.
    ///
    ///
    /// Este intrínseco no tiene una contraparte estable.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Realiza un almacenamiento volátil al puntero `dst`.
    /// No es necesario alinear el puntero.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Devuelve la raíz cuadrada de un `f32`
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Devuelve la raíz cuadrada de un `f64`
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Eleva un `f32` a una potencia entera.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Eleva un `f64` a una potencia entera.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Devuelve el seno de un `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Devuelve el seno de un `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Devuelve el coseno de un `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Devuelve el coseno de un `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Eleva un `f32` a una potencia `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Eleva un `f64` a una potencia `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Devuelve el exponencial de un `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Devuelve el exponencial de un `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Devuelve 2 elevado a la potencia de un `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Devuelve 2 elevado a la potencia de un `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Devuelve el logaritmo natural de `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Devuelve el logaritmo natural de `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Devuelve el logaritmo en base 10 de un `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Devuelve el logaritmo en base 10 de un `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Devuelve el logaritmo en base 2 de un `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Devuelve el logaritmo en base 2 de un `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Devuelve `a * b + c` para los valores `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Devuelve `a * b + c` para los valores `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Devuelve el valor absoluto de un `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Devuelve el valor absoluto de un `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Devuelve el mínimo de dos valores `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Devuelve el mínimo de dos valores `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Devuelve el máximo de dos valores `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Devuelve el máximo de dos valores `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Copia el signo de `y` a `x` para los valores de `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Copia el signo de `y` a `x` para los valores `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Devuelve el entero más grande menor o igual que `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Devuelve el entero más grande menor o igual que `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Devuelve el número entero más pequeño mayor o igual que `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Devuelve el número entero más pequeño mayor o igual que `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Devuelve la parte entera de un `f32`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Devuelve la parte entera de un `f64`.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Devuelve el número entero más cercano a `f32`.
    /// Puede generar una excepción de punto flotante inexacta si el argumento no es un número entero.
    pub fn rintf32(x: f32) -> f32;
    /// Devuelve el número entero más cercano a `f64`.
    /// Puede generar una excepción de punto flotante inexacta si el argumento no es un número entero.
    pub fn rintf64(x: f64) -> f64;

    /// Devuelve el número entero más cercano a `f32`.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Devuelve el número entero más cercano a `f64`.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Devuelve el número entero más cercano a `f32`.Redondea los casos a la mitad de cero.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Devuelve el número entero más cercano a `f64`.Redondea los casos a la mitad de cero.
    ///
    /// La versión estabilizada de este intrínseco es
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Suma flotante que permite optimizaciones basadas en reglas algebraicas.
    /// Puede asumir que las entradas son finitas.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Resta flotante que permite optimizaciones basadas en reglas algebraicas.
    /// Puede asumir que las entradas son finitas.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Multiplicación flotante que permite optimizaciones basadas en reglas algebraicas.
    /// Puede asumir que las entradas son finitas.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// División flotante que permite optimizaciones basadas en reglas algebraicas.
    /// Puede asumir que las entradas son finitas.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Resto flotante que permite optimizaciones basadas en reglas algebraicas.
    /// Puede asumir que las entradas son finitas.
    ///
    /// Este intrínseco no tiene una contraparte estable.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Convierta con fptoui/fptosi de LLVM, que puede devolver undef para valores fuera de rango
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Estabilizado como [`f32::to_int_unchecked`] y [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Devuelve el número de bits establecidos en un tipo entero `T`
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `count_ones`.
    /// Por ejemplo,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Devuelve el número de bits (zeroes) iniciales sin establecer en un tipo entero `T`.
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `leading_zeros`.
    /// Por ejemplo,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Un `x` con valor `0` devolverá el ancho de bit de `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Como `ctlz`, pero muy inseguro ya que devuelve `undef` cuando se le da un `x` con valor `0`.
    ///
    ///
    /// Este intrínseco no tiene una contraparte estable.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Devuelve el número de bits (zeroes) finales sin establecer en un tipo entero `T`.
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `trailing_zeros`.
    /// Por ejemplo,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Un `x` con valor `0` devolverá el ancho de bit de `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Como `cttz`, pero muy inseguro ya que devuelve `undef` cuando se le da un `x` con valor `0`.
    ///
    ///
    /// Este intrínseco no tiene una contraparte estable.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Invierte los bytes en un tipo entero `T`.
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `swap_bytes`.
    /// Por ejemplo,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Invierte los bits en un tipo entero `T`.
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `reverse_bits`.
    /// Por ejemplo,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Realiza la suma de enteros comprobados.
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `overflowing_add`.
    /// Por ejemplo,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Realiza una resta de números enteros comprobados
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `overflowing_sub`.
    /// Por ejemplo,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Realiza multiplicación de enteros comprobados
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `overflowing_mul`.
    /// Por ejemplo,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Realiza una división exacta, lo que da como resultado un comportamiento indefinido donde `x % y != 0` o `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Este intrínseco no tiene una contraparte estable.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Realiza una división sin marcar, lo que da como resultado un comportamiento indefinido donde `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Las envolturas seguras para este intrínseco están disponibles en las primitivas enteras mediante el método `checked_div`.
    /// Por ejemplo,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Devuelve el resto de una división sin marcar, lo que da como resultado un comportamiento indefinido cuando `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Las envolturas seguras para este intrínseco están disponibles en las primitivas enteras mediante el método `checked_rem`.
    /// Por ejemplo,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Realiza un desplazamiento a la izquierda sin marcar, lo que da como resultado un comportamiento indefinido cuando `y < 0` o `y >= N`, donde N es el ancho de T en bits.
    ///
    ///
    /// Las envolturas seguras para este intrínseco están disponibles en las primitivas enteras mediante el método `checked_shl`.
    /// Por ejemplo,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Realiza un desplazamiento a la derecha sin marcar, lo que da como resultado un comportamiento indefinido cuando `y < 0` o `y >= N`, donde N es el ancho de T en bits.
    ///
    ///
    /// Las envolturas seguras para este intrínseco están disponibles en las primitivas enteras mediante el método `checked_shr`.
    /// Por ejemplo,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Devuelve el resultado de una suma sin marcar, lo que da como resultado un comportamiento indefinido cuando `x + y > T::MAX` o `x + y < T::MIN`.
    ///
    ///
    /// Este intrínseco no tiene una contraparte estable.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Devuelve el resultado de una resta sin marcar, lo que da como resultado un comportamiento indefinido cuando `x - y > T::MAX` o `x - y < T::MIN`.
    ///
    ///
    /// Este intrínseco no tiene una contraparte estable.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Devuelve el resultado de una multiplicación sin marcar, lo que da como resultado un comportamiento indefinido cuando `x *y > T::MAX` o `x* y < T::MIN`.
    ///
    ///
    /// Este intrínseco no tiene una contraparte estable.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Realiza rotar a la izquierda.
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `rotate_left`.
    /// Por ejemplo,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Realiza girar a la derecha.
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `rotate_right`.
    /// Por ejemplo,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Devuelve (a + b) mod 2 <sup>N</sup>, donde N es el ancho de T en bits.
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `wrapping_add`.
    /// Por ejemplo,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Devuelve (a, b) mod 2 <sup>N</sup>, donde N es el ancho de T en bits.
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `wrapping_sub`.
    /// Por ejemplo,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Devuelve (a * b) mod 2 <sup>N</sup>, donde N es el ancho de T en bits.
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `wrapping_mul`.
    /// Por ejemplo,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Calcula `a + b`, saturando en límites numéricos.
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `saturating_add`.
    /// Por ejemplo,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Calcula `a - b`, saturando en límites numéricos.
    ///
    /// Las versiones estabilizadas de este intrínseco están disponibles en las primitivas enteras mediante el método `saturating_sub`.
    /// Por ejemplo,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Devuelve el valor del discriminante para la variante en 'v';
    /// si `T` no tiene discriminante, devuelve `0`.
    ///
    /// La versión estabilizada de este intrínseco es [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Devuelve el número de variantes del tipo `T` cast a un `usize`;
    /// si `T` no tiene variantes, devuelve `0`.Se contarán las variantes deshabitadas.
    ///
    /// La versión a estabilizar de este intrínseco es [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// La construcción "try catch" de Rust que invoca el puntero de función `try_fn` con el puntero de datos `data`.
    ///
    /// El tercer argumento es una función llamada si ocurre un panic.
    /// Esta función toma el puntero de datos y un puntero al objeto de excepción específico del destino que se capturó.
    ///
    /// Para obtener más información, consulte la fuente del compilador y la implementación de captura de std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emite una tienda `!nontemporal` según LLVM (consulte sus documentos).
    /// Probablemente nunca se estabilizará.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Consulte la documentación de `<*const T>::offset_from` para obtener más detalles.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Consulte la documentación de `<*const T>::guaranteed_eq` para obtener más detalles.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Consulte la documentación de `<*const T>::guaranteed_ne` para obtener más detalles.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Asignar en tiempo de compilación.No se debe llamar en tiempo de ejecución.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Algunas funciones se definen aquí porque accidentalmente se pusieron a disposición en este módulo en estable.
// Ver <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` también entra en esta categoría, pero no se puede empaquetar debido a la verificación de que `T` y `U` tienen el mismo tamaño).
//

/// Comprueba si `ptr` está correctamente alineado con respecto a `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Copia `count *size_of::<T>()` bytes de `src` a `dst`.El origen y el destino* no * deben superponerse.
///
/// Para regiones de memoria que puedan superponerse, utilice [`copy`] en su lugar.
///
/// `copy_nonoverlapping` es semánticamente equivalente al [`memcpy`] de C, pero con el orden de los argumentos intercambiado.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * `src` debe ser [valid] para lecturas de `count * size_of::<T>()` bytes.
///
/// * `dst` debe ser [valid] para escrituras de `count * size_of::<T>()` bytes.
///
/// * Tanto `src` como `dst` deben estar correctamente alineados.
///
/// * La región de la memoria que comienza en `src` con un tamaño de `count *
///   tamaño de: :<T>() `bytes *no* deben superponerse con la región de memoria que comienza en `dst` con el mismo tamaño.
///
/// Al igual que [`read`], `copy_nonoverlapping` crea una copia bit a bit de `T`, independientemente de si `T` es [`Copy`].
/// Si `T` no es [`Copy`], usar *ambos* los valores en la región que comienza en `*src` y la región que comienza en `* dst` puede ser [violate memory safety][read-ownership].
///
///
/// Tenga en cuenta que incluso si el tamaño efectivamente copiado (`count * size_of: :<T>()`) es `0`, los punteros no deben ser NULL y estar correctamente alineados.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Implementar manualmente [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Mueve todos los elementos de `src` a `dst`, dejando `src` vacío.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Asegúrese de que `dst` tenga suficiente capacidad para contener todo `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // La llamada al desplazamiento siempre es segura porque `Vec` nunca asignará más de `isize::MAX` bytes.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncar `src` sin dejar caer su contenido.
///         // Hacemos esto primero, para evitar problemas en caso de que algo más abajo panics.
///         src.set_len(0);
///
///         // Las dos regiones no pueden superponerse porque las referencias mutables no tienen alias y dos vectores diferentes no pueden poseer la misma memoria.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Notifique a `dst` que ahora contiene el contenido de `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Realice estas comprobaciones solo en tiempo de ejecución
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Sin entrar en pánico para reducir el impacto del codegen.
        abort();
    }*/

    // SEGURIDAD: el contrato de seguridad para `copy_nonoverlapping` debe ser
    // sostenido por la persona que llama.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Copia `count * size_of::<T>()` bytes de `src` a `dst`.El origen y el destino pueden superponerse.
///
/// Si el origen y el destino *nunca* se superponen, se puede utilizar [`copy_nonoverlapping`] en su lugar.
///
/// `copy` es semánticamente equivalente al [`memmove`] de C, pero con el orden de los argumentos intercambiado.
/// La copia se realiza como si los bytes se hubieran copiado de `src` a una matriz temporal y luego se hubieran copiado de la matriz a `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * `src` debe ser [valid] para lecturas de `count * size_of::<T>()` bytes.
///
/// * `dst` debe ser [valid] para escrituras de `count * size_of::<T>()` bytes.
///
/// * Tanto `src` como `dst` deben estar correctamente alineados.
///
/// Al igual que [`read`], `copy` crea una copia bit a bit de `T`, independientemente de si `T` es [`Copy`].
/// Si `T` no es [`Copy`], el uso de los valores de la región que comienza en `*src` y la región que comienza en `* dst` puede ser [violate memory safety][read-ownership].
///
///
/// Tenga en cuenta que incluso si el tamaño efectivamente copiado (`count * size_of: :<T>()`) es `0`, los punteros no deben ser NULL y estar correctamente alineados.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Cree de manera eficiente un Rust vector desde un búfer inseguro:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` debe estar alineado correctamente para su tipo y distinto de cero.
/// /// * `ptr` debe ser válido para lecturas de elementos contiguos `elts` de tipo `T`.
/// /// * Estos elementos no deben usarse después de llamar a esta función a menos que sea `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SEGURIDAD: Nuestra condición previa garantiza que la fuente esté alineada y sea válida,
///     // y `Vec::with_capacity` asegura que tengamos espacio utilizable para escribirlos.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SEGURIDAD: Lo creamos con tanta capacidad antes,
///     // y el `copy` anterior ha inicializado estos elementos.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Realice estas comprobaciones solo en tiempo de ejecución
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Sin entrar en pánico para reducir el impacto del codegen.
        abort();
    }*/

    // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `copy`.
    unsafe { copy(src, dst, count) }
}

/// Establece `count * size_of::<T>()` bytes de memoria comenzando en `dst` a `val`.
///
/// `write_bytes` es similar al [`memset`] de C, pero establece los bytes `count * size_of::<T>()` en `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * `dst` debe ser [valid] para escrituras de `count * size_of::<T>()` bytes.
///
/// * `dst` deben estar correctamente alineados.
///
/// Además, la persona que llama debe asegurarse de que la escritura de bytes `count * size_of::<T>()` en la región de memoria dada dé como resultado un valor válido de `T`.
/// El uso de una región de memoria escrita como `T` que contiene un valor no válido de `T` es un comportamiento indefinido.
///
/// Tenga en cuenta que incluso si el tamaño efectivamente copiado (`count * size_of: :<T>()`) es `0`, el puntero no debe ser NULL y estar correctamente alineado.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Creando un valor inválido:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Filtra el valor retenido anteriormente al sobrescribir el `Box<T>` con un puntero nulo.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // En este punto, el uso o la eliminación de `v` da como resultado un comportamiento indefinido.
/// // drop(v); // ERROR
///
/// // Incluso filtrando `v` "uses", y por lo tanto, su comportamiento es indefinido.
/// // mem::forget(v); // ERROR
///
/// // De hecho, `v` no es válido según los invariantes de diseño de tipo básico, por lo que *cualquier* operación que lo toque es un comportamiento indefinido.
/////
/// // sea v2 =v;//ERROR
///
/// unsafe {
///     // En su lugar, pongamos un valor válido
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Ahora la caja esta bien
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `write_bytes`.
    unsafe { write_bytes(dst, val, count) }
}