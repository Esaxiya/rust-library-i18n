//! Define el iterador propiedad de `IntoIter` para matrices.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Un iterador [array] por valor.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Esta es la matriz sobre la que estamos iterando.
    ///
    /// Los elementos con índice `i` donde `alive.start <= i < alive.end` aún no se han obtenido y son entradas de matriz válidas.
    /// Los elementos con índices `i < alive.start` o `i >= alive.end` ya se han generado y ya no se debe acceder a ellos.¡Esos elementos muertos podrían incluso estar en un estado completamente no inicializado!
    ///
    ///
    /// Entonces las invariantes son:
    /// - `data[alive]` está vivo (es decir, contiene elementos válidos)
    /// - `data[..alive.start]` y `data[alive.end..]` están muertos (es decir, los elementos ya se han leído y no se deben tocar más).
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Los elementos de `data` que aún no se han cedido.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Crea un nuevo iterador sobre el `array` dado.
    ///
    /// *Nota*: este método podría quedar obsoleto en future, después de [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // El tipo de `value` es un `i32` aquí, en lugar de `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SEGURIDAD: La transmutación aquí es realmente segura.Los documentos de `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` se garantiza que tenga el mismo tamaño y alineación
        // > como `T`.
        //
        // Los documentos incluso muestran una transmutación de una matriz de `MaybeUninit<T>` a una matriz de `T`.
        //
        //
        // Con eso, esta inicialización satisface las invariantes.

        // FIXME(LukasKalbertodt): realmente use `mem::transmute` aquí, una vez que funcione con const genéricos:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Hasta entonces, podemos usar `mem::transmute_copy` para crear una copia bit a bit como un tipo diferente, luego olvidarnos de `array` para que no se elimine.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Devuelve un segmento inmutable de todos los elementos que aún no se han generado.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SEGURIDAD: Sabemos que todos los elementos dentro de `alive` están correctamente inicializados.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Devuelve un segmento mutable de todos los elementos que aún no se han generado.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SEGURIDAD: Sabemos que todos los elementos dentro de `alive` están correctamente inicializados.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Obtenga el siguiente índice del frente.
        //
        // Incrementar `alive.start` en 1 mantiene la invariante con respecto a `alive`.
        // Sin embargo, debido a este cambio, por un corto tiempo, la zona viva ya no es `data[alive]`, sino `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Lea el elemento de la matriz.
            // SEGURIDAD: `idx` es un índice de la antigua región "alive" del
            // formación.La lectura de este elemento significa que `data[idx]` se considera muerto ahora (es decir, no se toca).
            // Como `idx` fue el comienzo de la zona viva, la zona viva ahora es `data[alive]` nuevamente, restaurando todos los invariantes.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Obtenga el siguiente índice del reverso.
        //
        // Disminuir `alive.end` en 1 mantiene el invariante con respecto a `alive`.
        // Sin embargo, debido a este cambio, por un corto tiempo, la zona viva ya no es `data[alive]`, sino `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Lea el elemento de la matriz.
            // SEGURIDAD: `idx` es un índice de la antigua región "alive" del
            // formación.La lectura de este elemento significa que `data[idx]` se considera muerto ahora (es decir, no se toca).
            // Como `idx` fue el final de la zona viva, la zona viva ahora es `data[alive]` nuevamente, restaurando todos los invariantes.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SEGURIDAD: Esto es seguro: `as_mut_slice` devuelve exactamente el sub-segmento
        // de elementos que aún no se han movido y que quedan por eliminar.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Nunca subdesbordará debido al invariante `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// De hecho, el iterador informa la longitud correcta.
// El número de elementos "alive" (que aún se cederán) es la longitud del rango `alive`.
// Este rango se reduce en longitud en `next` o `next_back`.
// Siempre se reduce en 1 en esos métodos, pero solo si se devuelve `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Tenga en cuenta que en realidad no necesitamos hacer coincidir exactamente el mismo rango vivo, por lo que podemos clonar en el desplazamiento 0 independientemente de dónde esté `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clona todos los elementos vivos.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Escriba un clon en la nueva matriz, luego actualice su rango vivo.
            // Si clona panics, eliminaremos correctamente los elementos anteriores.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Imprima solo los elementos que aún no se han entregado: ya no podemos acceder a los elementos entregados.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}