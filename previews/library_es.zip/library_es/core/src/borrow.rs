//! Un módulo para trabajar con datos prestados.

#![stable(feature = "rust1", since = "1.0.0")]

/// Un trait para tomar prestados datos.
///
/// En Rust, es común proporcionar diferentes representaciones de un tipo para diferentes casos de uso.
/// Por ejemplo, la ubicación de almacenamiento y la administración de un valor se pueden elegir específicamente según sea apropiado para un uso particular a través de tipos de puntero como [`Box<T>`] o [`Rc<T>`].
/// Más allá de estos envoltorios genéricos que se pueden usar con cualquier tipo, algunos tipos proporcionan facetas opcionales que brindan una funcionalidad potencialmente costosa.
/// Un ejemplo de este tipo es [`String`], que agrega la capacidad de extender una cadena al [`str`] básico.
/// Esto requiere mantener información adicional innecesaria para una cadena simple e inmutable.
///
/// Estos tipos brindan acceso a los datos subyacentes a través de referencias al tipo de esos datos.Se dice que están "prestados como" de ese tipo.
/// Por ejemplo, un [`Box<T>`] se puede pedir prestado como `T`, mientras que un [`String`] se puede pedir prestado como `str`.
///
/// Los tipos expresan que se pueden tomar prestados como algunos tipos `T` implementando `Borrow<T>`, proporcionando una referencia a un `T` en el método [`borrow`] de trait.Un tipo es libre de pedir prestado como varios tipos diferentes.
/// Si desea tomar prestado de manera mutante como el tipo, lo que permite que se modifiquen los datos subyacentes, también puede implementar [`BorrowMut<T>`].
///
/// Además, al proporcionar implementaciones para traits adicionales, se debe considerar si deben comportarse de manera idéntica a las del tipo subyacente como consecuencia de actuar como una representación de ese tipo subyacente.
/// El código genérico generalmente usa `Borrow<T>` cuando se basa en el comportamiento idéntico de estas implementaciones adicionales de trait.
/// Estos traits probablemente aparecerán como trait bounds adicionales.
///
/// En particular, `Eq`, `Ord` y `Hash` deben ser equivalentes para valores prestados y propios: `x.borrow() == y.borrow()` debe dar el mismo resultado que `x == y`.
///
/// Si el código genérico simplemente necesita funcionar para todos los tipos que pueden proporcionar una referencia al tipo relacionado `T`, a menudo es mejor usar [`AsRef<T>`] ya que más tipos pueden implementarlo de manera segura.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Como recopilación de datos, [`HashMap<K, V>`] posee tanto claves como valores.Si los datos reales de la clave están envueltos en un tipo de gestión de algún tipo, debería ser posible, sin embargo, buscar un valor utilizando una referencia a los datos de la clave.
/// Por ejemplo, si la clave es una cadena, es probable que se almacene con el mapa hash como [`String`], mientras que debería ser posible buscar usando un [`&str`][`str`].
/// Por lo tanto, `insert` necesita operar en un `String` mientras que `get` necesita poder usar un `&str`.
///
/// Ligeramente simplificado, las partes relevantes de `HashMap<K, V>` se ven así:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // campos omitidos
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// El mapa hash completo es genérico sobre un tipo de clave `K`.Debido a que estas claves se almacenan con el mapa hash, este tipo debe poseer los datos de la clave.
/// Al insertar un par clave-valor, el mapa recibe un `K` y necesita encontrar el depósito de hash correcto y verificar si la clave ya está presente en base a ese `K`.Por lo tanto, requiere `K: Hash + Eq`.
///
/// Sin embargo, al buscar un valor en el mapa, tener que proporcionar una referencia a un `K` como clave para buscar requeriría crear siempre dicho valor de propiedad.
/// Para las claves de cadena, esto significaría que se debe crear un valor `String` solo para la búsqueda de casos en los que solo un `str` está disponible.
///
/// En cambio, el método `get` es genérico sobre el tipo de datos clave subyacentes, llamado `Q` en la firma del método anterior.Establece que `K` toma prestado como `Q` al requerir que `K: Borrow<Q>`.
/// Al requerir adicionalmente `Q: Hash + Eq`, señala el requisito de que `K` y `Q` tengan implementaciones de `Hash` y `Eq` traits que produzcan resultados idénticos.
///
/// La implementación de `get` se basa, en particular, en implementaciones idénticas de `Hash` al determinar el depósito de hash de la clave llamando a `Hash::hash` en el valor `Q` aunque insertó la clave en función del valor hash calculado a partir del valor `K`.
///
///
/// Como consecuencia, el mapa hash se rompe si un `K` que envuelve un valor `Q` produce un hash diferente al de `Q`.Por ejemplo, imagina que tienes un tipo que envuelve una cadena pero compara letras ASCII ignorando su caso:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Debido a que dos valores iguales deben producir el mismo valor hash, la implementación de `Hash` también debe ignorar el caso ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// ¿Puede `CaseInsensitiveString` implementar `Borrow<str>`?Ciertamente puede proporcionar una referencia a un segmento de cadena a través de su cadena de propiedad contenida.
/// Pero debido a que su implementación `Hash` es diferente, se comporta de manera diferente a `str` y, por lo tanto, no debe, de hecho, implementar `Borrow<str>`.
/// Si quiere permitir que otros accedan al `str` subyacente, puede hacerlo a través de `AsRef<str>`, que no tiene requisitos adicionales.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Inmutablemente toma prestado de un valor propio.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Un trait para tomar prestados datos de forma mutante.
///
/// Como complemento de [`Borrow<T>`], este trait permite que un tipo tome prestado como tipo subyacente al proporcionar una referencia mutable.
/// Consulte [`Borrow<T>`] para obtener más información sobre los préstamos como otro tipo.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Toma prestado de forma variable de un valor propio.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}