//! Formas de crear un segmento `str` a partir de bytes.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Convierte un segmento de bytes en un segmento de cadena.
///
/// Un segmento de cadena ([`&str`]) está formado por bytes ([`u8`]) y un segmento de bytes ([`&[u8]`][byteslice]) está compuesto por bytes, por lo que esta función convierte entre los dos.
/// Sin embargo, no todos los segmentos de bytes son segmentos de cadena válidos: [`&str`] requiere que sea UTF-8 válido.
/// `from_utf8()` comprueba que los bytes sean UTF-8 válidos y luego realiza la conversión.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Si está seguro de que el segmento de bytes es UTF-8 válido y no desea incurrir en la sobrecarga de la verificación de validez, existe una versión insegura de esta función, [`from_utf8_unchecked`], que tiene el mismo comportamiento pero omite la verificación.
///
///
/// Si necesita un `String` en lugar de un `&str`, considere [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Debido a que puede apilar-asignar un `[u8; N]`, y puede tomar un [`&[u8]`][byteslice] de él, esta función es una forma de tener una cadena asignada a la pila.Hay un ejemplo de esto en la sección de ejemplos a continuación.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Devuelve `Err` si el segmento no es UTF-8 con una descripción de por qué el segmento proporcionado no es UTF-8.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::str;
///
/// // algunos bytes, en un vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Sabemos que estos bytes son válidos, así que use `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Bytes incorrectos:
///
/// ```
/// use std::str;
///
/// // algunos bytes inválidos, en un vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Consulte los documentos de [`Utf8Error`] para obtener más detalles sobre los tipos de errores que se pueden devolver.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // algunos bytes, en una matriz asignada a la pila
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Sabemos que estos bytes son válidos, así que use `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SEGURIDAD: Acabo de ejecutar la validación.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Convierte un segmento mutable de bytes en un segmento de cadena mutable.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" como un vector mutable
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Como sabemos que estos bytes son válidos, podemos usar `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Bytes incorrectos:
///
/// ```
/// use std::str;
///
/// // Algunos bytes no válidos en un vector mutable
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Consulte los documentos de [`Utf8Error`] para obtener más detalles sobre los tipos de errores que se pueden devolver.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SEGURIDAD: Acabo de ejecutar la validación.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Convierte un segmento de bytes en un segmento de cadena sin comprobar que la cadena contiene UTF-8 válido.
///
/// Consulte la versión segura, [`from_utf8`], para obtener más información.
///
/// # Safety
///
/// Esta función no es segura porque no comprueba que los bytes que se le pasan sean UTF-8 válidos.
/// Si se viola esta restricción, se produce un comportamiento indefinido, ya que el resto de Rust asume que [`&str`] s son UTF-8 válidos.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::str;
///
/// // algunos bytes, en un vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SEGURIDAD: la persona que llama debe garantizar que los bytes `v` son UTF-8 válidos.
    // También se basa en que `&str` y `&[u8]` tengan el mismo diseño.
    unsafe { mem::transmute(v) }
}

/// Convierte un segmento de bytes en un segmento de cadena sin comprobar que la cadena contiene UTF-8 válido;versión mutable.
///
///
/// Consulte la versión inmutable, [`from_utf8_unchecked()`] para obtener más información.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SEGURIDAD: la persona que llama debe garantizar que los bytes `v`
    // son UTF-8 válidos, por lo que la conversión a `*mut str` es segura.
    // Además, la desreferencia del puntero es segura porque ese puntero proviene de una referencia que se garantiza que es válida para escrituras.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}