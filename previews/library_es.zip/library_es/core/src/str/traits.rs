//! Implementaciones de Trait para `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementa el orden de cadenas.
///
/// Las cadenas se ordenan [lexicographically](Ord#lexicographical-comparison) por sus valores de bytes.
/// Esto ordena los puntos de código Unicode en función de sus posiciones en los gráficos de código.
/// Este no es necesariamente el mismo que el pedido "alphabetical", que varía según el idioma y la configuración regional.
/// La clasificación de cadenas de acuerdo con estándares culturalmente aceptados requiere datos específicos de la configuración regional que están fuera del alcance del tipo `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementa operaciones de comparación en cadenas.
///
/// Las cadenas se comparan [lexicographically](Ord#lexicographical-comparison) por sus valores de bytes.
/// Esto compara los puntos de código Unicode en función de sus posiciones en los gráficos de código.
/// Este no es necesariamente el mismo que el pedido "alphabetical", que varía según el idioma y la configuración regional.
/// La comparación de cadenas de acuerdo con estándares culturalmente aceptados requiere datos específicos de la configuración regional que están fuera del alcance del tipo `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementa la división de subcadenas con la sintaxis `&self[..]` o `&mut self[..]`.
///
/// Devuelve una porción de toda la cadena, es decir, devuelve `&self` o `&mut self`.Equivalente a `&self [0 ..
/// len] `o`&mut self [0 ..
/// len]`.
/// A diferencia de otras operaciones de indexación, esto nunca puede panic.
///
/// Esta operación es *O*(1).
///
/// Antes de 1.20.0, estas operaciones de indexación todavía eran compatibles con la implementación directa de `Index` y `IndexMut`.
///
/// Equivalente a `&self[0 .. len]` o `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementa la división de subcadenas con la sintaxis `&self[begin .. end]` o `&mut self[begin .. end]`.
///
/// Devuelve una porción de la cadena dada del rango de bytes [`begin`, `end`).
///
/// Esta operación es *O*(1).
///
/// Antes de 1.20.0, estas operaciones de indexación todavía eran compatibles con la implementación directa de `Index` y `IndexMut`.
///
/// # Panics
///
/// Panics si `begin` o `end` no apunta al desplazamiento del byte inicial de un carácter (como lo define `is_char_boundary`), si `begin > end` o si `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // estos serán panic:
/// // el byte 2 se encuentra dentro de `ö`:
/// // &s [2,3];
///
/// // el byte 8 se encuentra dentro de `老`&s [1 ..
/// // 8];
///
/// // el byte 100 está fuera de la cadena&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEGURIDAD: acabo de comprobar que `start` y `end` están en un límite de caracteres,
            // y estamos pasando una referencia segura, por lo que el valor de retorno también será uno.
            // También verificamos los límites de caracteres, por lo que este es un UTF-8 válido.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEGURIDAD: acaba de comprobar que `start` y `end` están en un límite de caracteres.
            // Sabemos que el puntero es único porque lo obtuvimos de `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SEGURIDAD: la persona que llama garantiza que `self` está dentro de los límites de `slice`
        // que satisface todas las condiciones para `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SEGURIDAD: consulte los comentarios para `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary comprueba que el índice esté en [0, .len()] no puede reutilizar `get` como se indicó anteriormente, debido a problemas de NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEGURIDAD: acabo de comprobar que `start` y `end` están en un límite de caracteres,
            // y estamos pasando una referencia segura, por lo que el valor de retorno también será uno.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementa la división de subcadenas con la sintaxis `&self[.. end]` o `&mut self[.. end]`.
///
/// Devuelve una porción de la cadena dada del rango de bytes [`0`, `end`).
/// Equivalente a `&self[0 .. end]` o `&mut self[0 .. end]`.
///
/// Esta operación es *O*(1).
///
/// Antes de 1.20.0, estas operaciones de indexación todavía eran compatibles con la implementación directa de `Index` y `IndexMut`.
///
/// # Panics
///
/// Panics si `end` no apunta al desplazamiento del byte inicial de un carácter (como lo define `is_char_boundary`), o si `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SEGURIDAD: acabo de comprobar que `end` está en un límite de carbonización,
            // y estamos pasando una referencia segura, por lo que el valor de retorno también será uno.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SEGURIDAD: acabo de comprobar que `end` está en un límite de carbonización,
            // y estamos pasando una referencia segura, por lo que el valor de retorno también será uno.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SEGURIDAD: acabo de comprobar que `end` está en un límite de carbonización,
            // y estamos pasando una referencia segura, por lo que el valor de retorno también será uno.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementa la división de subcadenas con la sintaxis `&self[begin ..]` o `&mut self[begin ..]`.
///
/// Devuelve una porción de la cadena dada del rango de bytes [`begin`, `len`).Equivalente a `&self [begin ..
/// len] `o`&mut self [begin ..
/// len]`.
///
/// Esta operación es *O*(1).
///
/// Antes de 1.20.0, estas operaciones de indexación todavía eran compatibles con la implementación directa de `Index` y `IndexMut`.
///
/// # Panics
///
/// Panics si `begin` no apunta al desplazamiento del byte inicial de un carácter (como lo define `is_char_boundary`), o si `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SEGURIDAD: acabo de comprobar que `start` está en un límite de carbonización,
            // y estamos pasando una referencia segura, por lo que el valor de retorno también será uno.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SEGURIDAD: acabo de comprobar que `start` está en un límite de carbonización,
            // y estamos pasando una referencia segura, por lo que el valor de retorno también será uno.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SEGURIDAD: la persona que llama garantiza que `self` está dentro de los límites de `slice`
        // que satisface todas las condiciones para `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SEGURIDAD: idéntica a `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SEGURIDAD: acabo de comprobar que `start` está en un límite de carbonización,
            // y estamos pasando una referencia segura, por lo que el valor de retorno también será uno.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementa la división de subcadenas con la sintaxis `&self[begin ..= end]` o `&mut self[begin ..= end]`.
///
/// Devuelve una porción de la cadena dada del rango de bytes [`begin`, `end`].Equivalente a `&self [begin .. end + 1]` o `&mut self[begin .. end + 1]`, excepto si `end` tiene el valor máximo para `usize`.
///
/// Esta operación es *O*(1).
///
/// # Panics
///
/// Panics si `begin` no apunta al desplazamiento del byte inicial de un carácter (según lo definido por `is_char_boundary`), si `end` no apunta al desplazamiento del byte final de un carácter (`end + 1` es un desplazamiento del byte inicial o igual a `len`), si `begin > end`, o si `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementa la división de subcadenas con la sintaxis `&self[..= end]` o `&mut self[..= end]`.
///
/// Devuelve una porción de la cadena dada del rango de bytes [0, `end`].
/// Equivalente a `&self [0 .. end + 1]`, excepto si `end` tiene el valor máximo para `usize`.
///
/// Esta operación es *O*(1).
///
/// # Panics
///
/// Panics si `end` no apunta al desplazamiento del byte final de un carácter (`end + 1` es un desplazamiento del byte inicial definido por `is_char_boundary`, o igual a `len`), o si `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analizar un valor de una cadena
///
/// El método [`from_str`] de `FromStr` se usa a menudo implícitamente, a través del método [`parse`] de [`str`].
/// Consulte la documentación de [`parse`] para ver ejemplos.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` no tiene un parámetro de duración, por lo que solo puede analizar los tipos que no contienen un parámetro de duración.
///
/// En otras palabras, puede analizar un `i32` con `FromStr`, pero no un `&i32`.
/// Puede analizar una estructura que contenga un `i32`, pero no una que contenga un `&i32`.
///
/// # Examples
///
/// Implementación básica de `FromStr` en un ejemplo de tipo `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// El error asociado que se puede devolver al analizar.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analiza una cadena `s` para devolver un valor de este tipo.
    ///
    /// Si el análisis se realiza correctamente, devuelva el valor dentro de [`Ok`]; de lo contrario, cuando la cadena tenga un formato incorrecto, devuelva un error específico del interior de [`Err`].
    /// El tipo de error es específico de la implementación de trait.
    ///
    /// # Examples
    ///
    /// Uso básico con [`i32`], un tipo que implementa `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analizar un `bool` a partir de una cadena.
    ///
    /// Produce un `Result<bool, ParseBoolError>`, porque `s` puede o no ser analizable.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Tenga en cuenta que, en muchos casos, el método `.parse()` en `str` es más adecuado.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}