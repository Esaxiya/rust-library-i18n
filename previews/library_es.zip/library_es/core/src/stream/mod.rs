//! Iteración asincrónica componible.
//!
//! Si futures son valores asincrónicos, los flujos son iteradores asincrónicos.
//! Si se ha encontrado con una colección asincrónica de algún tipo y necesita realizar una operación en los elementos de dicha colección, rápidamente se encontrará con 'streams'.
//! Las transmisiones se utilizan mucho en el código Rust asíncrono idiomático, por lo que vale la pena familiarizarse con ellas.
//!
//! Antes de explicar más, hablemos de cómo está estructurado este módulo:
//!
//! # Organization
//!
//! Este módulo está organizado en gran parte por tipo:
//!
//! * [Traits] son la parte central: estos traits definen qué tipo de corrientes existen y qué puede hacer con ellas.Vale la pena dedicar un tiempo de estudio adicional a los métodos de estos traits.
//! * Las funciones proporcionan algunas formas útiles de crear algunas transmisiones básicas.
//! * Las estructuras son a menudo los tipos de retorno de los diversos métodos en traits de este módulo.Por lo general, querrá ver el método que crea el `struct`, en lugar del `struct` en sí.
//! Para obtener más detalles sobre el motivo, consulte '[Implementación de flujo](#deployment-stream)'.
//!
//! [Traits]: #traits
//!
//! ¡Eso es!Profundicemos en las corrientes.
//!
//! # Stream
//!
//! El corazón y el alma de este módulo es el [`Stream`] trait.El núcleo de [`Stream`] se ve así:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! A diferencia de `Iterator`, `Stream` hace una distinción entre el método [`poll_next`] que se usa al implementar un `Stream` y un método (to-be-implemented) `next` que se usa al consumir un flujo.
//!
//! Los consumidores de `Stream` solo deben considerar `next`, que cuando se llama, devuelve un future que produce `Option<Stream::Item>`.
//!
//! El future devuelto por `next` producirá `Some(Item)` siempre que haya elementos, y una vez que se hayan agotado todos, producirá `None` para indicar que la iteración ha finalizado.
//! Si estamos esperando que se resuelva algo asincrónico, future esperará hasta que la transmisión esté lista para volver a ceder.
//!
//! Las transmisiones individuales pueden optar por reanudar la iteración, por lo que llamar a `next` nuevamente puede o no producir `Some(Item)` nuevamente en algún momento.
//!
//! La definición completa de [`Stream`] incluye una serie de otros métodos también, pero son métodos predeterminados, construidos sobre [`poll_next`], por lo que los obtienes gratis.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implementación de Stream
//!
//! La creación de una transmisión propia implica dos pasos: crear un `struct` para mantener el estado de la transmisión y luego implementar [`Stream`] para ese `struct`.
//!
//! Hagamos un flujo llamado `Counter` que cuente desde `1` hasta `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Primero, la estructura:
//!
//! /// Una corriente que cuenta del uno al cinco
//! struct Counter {
//!     count: usize,
//! }
//!
//! // queremos que nuestro recuento comience en uno, así que agreguemos un método new() para ayudar.
//! // Esto no es estrictamente necesario, pero es conveniente.
//! // Tenga en cuenta que comenzamos `count` en cero, veremos por qué en la implementación de `poll_next()`'s a continuación.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Luego, implementamos `Stream` para nuestro `Counter`:
//!
//! impl Stream for Counter {
//!     // contaremos con usize
//!     type Item = usize;
//!
//!     // poll_next() es el único método requerido
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Incrementa nuestro recuento.Por eso empezamos de cero.
//!         self.count += 1;
//!
//!         // Compruebe si hemos terminado de contar o no.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Las transmisiones son *perezosas*.Esto significa que la creación de un flujo no es mucho _do_.Realmente no pasa nada hasta que llama a `next`.
//! A veces, esto es una fuente de confusión cuando se crea una transmisión únicamente por sus efectos secundarios.
//! El compilador nos advertirá sobre este tipo de comportamiento:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;