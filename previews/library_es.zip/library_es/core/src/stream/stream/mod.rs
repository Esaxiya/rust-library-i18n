use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Una interfaz para tratar con iteradores asincrónicos.
///
/// Esta es la corriente principal trait.
/// Para obtener más información sobre el concepto de transmisiones en general, consulte el [module-level documentation].
/// En particular, es posible que desee saber cómo utilizar [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// El tipo de elementos generados por la secuencia.
    type Item;

    /// Intente extraer el siguiente valor de esta secuencia, registrando la tarea actual para reactivarla si el valor aún no está disponible y devolviendo `None` si la secuencia está agotada.
    ///
    /// # Valor devuelto
    ///
    /// Hay varios valores de retorno posibles, cada uno de los cuales indica un estado de transmisión distinto:
    ///
    /// - `Poll::Pending` significa que el siguiente valor de esta transmisión aún no está listo.Las implementaciones garantizarán que la tarea actual sea notificada cuando el próximo valor esté listo.
    ///
    /// - `Poll::Ready(Some(val))` significa que la secuencia ha producido con éxito un valor, `val`, y puede producir más valores en las siguientes llamadas `poll_next`.
    ///
    /// - `Poll::Ready(None)` significa que la secuencia ha terminado y no se debe volver a invocar `poll_next`.
    ///
    /// # Panics
    ///
    /// Una vez que una secuencia ha finalizado (devuelve `Ready(None)` from `poll_next`), llamar a su método `poll_next` nuevamente puede panic, bloquearse para siempre o causar otro tipo de problemas; `Stream` trait no impone requisitos sobre los efectos de dicha llamada.
    ///
    /// Sin embargo, como el método `poll_next` no está marcado como `unsafe`, se aplican las reglas habituales de Rust: las llamadas nunca deben causar un comportamiento indefinido (corrupción de la memoria, uso incorrecto de las funciones `unsafe` o similares), independientemente del estado de la secuencia.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Devuelve los límites de la longitud restante de la secuencia.
    ///
    /// Específicamente, `size_hint()` devuelve una tupla donde el primer elemento es el límite inferior y el segundo elemento es el límite superior.
    ///
    /// La segunda mitad de la tupla que se devuelve es una [`Option`]`<`[`usize`] `>`.
    /// Un [`None`] aquí significa que no hay un límite superior conocido o que el límite superior es mayor que [`usize`].
    ///
    /// # Notas de implementación
    ///
    /// No se impone que una implementación de flujo produzca el número declarado de elementos.Una corriente con errores puede producir menos que el límite inferior o más que el límite superior de elementos.
    ///
    /// `size_hint()` está destinado principalmente a ser utilizado para optimizaciones tales como reservar espacio para los elementos de la secuencia, pero no se debe confiar para, por ejemplo, omitir comprobaciones de límites en código inseguro.
    /// Una implementación incorrecta de `size_hint()` no debería dar lugar a violaciones de seguridad de la memoria.
    ///
    /// Dicho esto, la implementación debería proporcionar una estimación correcta, porque de lo contrario sería una violación del protocolo de trait.
    ///
    /// La implementación predeterminada devuelve `(0,` [`None`]`)`que es correcto para cualquier flujo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}