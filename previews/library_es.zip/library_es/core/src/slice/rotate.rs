// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Gira el rango `[mid-left, mid+right)` de modo que el elemento en `mid` se convierta en el primer elemento.De manera equivalente, rota los elementos `left` del rango hacia la izquierda o los elementos `right` hacia la derecha.
///
/// # Safety
///
/// El rango especificado debe ser válido para lectura y escritura.
///
/// # Algorithm
///
/// El algoritmo 1 se utiliza para valores pequeños de `left + right` o para `T` grandes.
/// Los elementos se mueven a sus posiciones finales uno a la vez comenzando en `mid - left` y avanzando por pasos de `right` módulo `left + right`, de modo que solo se necesita un temporal.
/// Finalmente, llegamos a `mid - left`.
/// Sin embargo, si `gcd(left + right, right)` no es 1, los pasos anteriores omitieron elementos.
/// Por ejemplo:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Afortunadamente, el número de elementos omitidos entre los elementos finalizados es siempre igual, por lo que podemos compensar nuestra posición inicial y hacer más rondas (el número total de rondas es el `gcd(left + right, right)` value).
///
/// El resultado final es que todos los elementos se finalizan una sola vez.
///
/// El algoritmo 2 se usa si `left + right` es grande pero `min(left, right)` es lo suficientemente pequeño como para caber en un búfer de pila.
/// Los elementos `min(left, right)` se copian en el búfer, `memmove` se aplica a los demás y los que están en el búfer se mueven nuevamente al agujero en el lado opuesto de donde se originaron.
///
/// Los algoritmos que se pueden vectorizar superan a los anteriores una vez que `left + right` se vuelve lo suficientemente grande.
/// El algoritmo 1 se puede vectorizar fragmentando y realizando muchas rondas a la vez, pero hay muy pocas rondas en promedio hasta que `left + right` es enorme, y el peor caso de una sola ronda siempre está ahí.
/// En cambio, el algoritmo 3 utiliza el intercambio repetido de elementos `min(left, right)` hasta que queda un problema de rotación más pequeño.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// cuando `left < right`, el intercambio ocurre desde la izquierda.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. los algoritmos siguientes pueden fallar si estos casos no se verifican
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Los microbenchmarks del algoritmo 1 indican que el rendimiento promedio para los cambios aleatorios es mejor hasta aproximadamente `left + right == 32`, pero el peor de los casos, el rendimiento se rompe incluso alrededor de 16.
            // 24 fue elegido como término medio.
            // Si el tamaño de `T` es mayor que 4 "usize", este algoritmo también supera a otros algoritmos.
            //
            //
            let x = unsafe { mid.sub(left) };
            // comienzo de la primera ronda
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` se puede encontrar de antemano calculando `gcd(left + right, right)`, pero es más rápido hacer un ciclo que calcula el mcd como efecto secundario, y luego hacer el resto del fragmento
            //
            //
            let mut gcd = right;
            // Los puntos de referencia revelan que es más rápido intercambiar los temporales hasta el final en lugar de leer uno temporal una vez, copiar al revés y luego escribir ese temporal al final.
            // Esto posiblemente se deba al hecho de que al intercambiar o reemplazar los temporales se usa solo una dirección de memoria en el bucle en lugar de tener que administrar dos.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // en lugar de incrementar `i` y luego verificar si está fuera de los límites, verificamos si `i` saldrá de los límites en el siguiente incremento.
                // Esto evita cualquier envoltura de punteros o `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // final de la primera ronda
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // este condicional debe estar aquí si `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // terminar el trozo con más rondas
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` no es un tipo de tamaño cero, por lo que está bien dividir por su tamaño.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritmo 2 El `[T; 0]` aquí es para asegurar que esté alineado apropiadamente para T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritmo 3 Existe una forma alternativa de intercambio que implica encontrar dónde estaría el último intercambio de este algoritmo e intercambiar usando ese último fragmento en lugar de intercambiar fragmentos adyacentes como lo hace este algoritmo, pero de esta manera es aún más rápido.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritmo 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}