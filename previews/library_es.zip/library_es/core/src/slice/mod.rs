// ignore-tidy-filelength

//! Manejo y manipulación de cortes.
//!
//! Para obtener más detalles, consulte [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Implementación pura de memchr rust, tomada de rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Esta función es pública solo porque no hay otra forma de realizar pruebas unitarias de heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Devuelve el número de elementos del sector.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SEGURIDAD: sonido constante porque transmutamos el campo de longitud como un tamaño (que debe ser)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SEGURIDAD: esto es seguro porque `&[T]` y `FatPtr<T>` tienen el mismo diseño.
            // Solo `std` puede hacer esta garantía.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Reemplace con `crate::ptr::metadata(self)` cuando sea estable.
            // En el momento de escribir estas líneas, esto provoca un error "Const-stable functions can only call other const-stable functions".
            //

            // SEGURIDAD: Acceder al valor de la unión `PtrRepr` es seguro ya que * const T
            // y PtrComponents<T>tienen los mismos diseños de memoria.
            // Solo std puede hacer esta garantía.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Devuelve `true` si el segmento tiene una longitud de 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Devuelve el primer elemento del sector, o `None` si está vacío.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Devuelve un puntero mutable al primer elemento del segmento, o `None` si está vacío.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Devuelve el primero y todos los demás elementos del segmento, o `None` si está vacío.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Devuelve el primero y todos los demás elementos del segmento, o `None` si está vacío.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Devuelve el último y todos los demás elementos del segmento, o `None` si está vacío.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Devuelve el último y todos los demás elementos del segmento, o `None` si está vacío.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Devuelve el último elemento del sector, o `None` si está vacío.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Devuelve un puntero mutable al último elemento del sector.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Devuelve una referencia a un elemento o sublicencia según el tipo de índice.
    ///
    /// - Si se le da una posición, devuelve una referencia al elemento en esa posición o `None` si está fuera de los límites.
    ///
    /// - Si se le da un rango, devuelve la sublicencia correspondiente a ese rango, o `None` si está fuera de los límites.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Devuelve una referencia mutable a un elemento o sublicencia según el tipo de índice (consulte [`get`]) o `None` si el índice está fuera de los límites.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Devuelve una referencia a un elemento o sublicencia, sin comprobar los límites.
    ///
    /// Para una alternativa segura, consulte [`get`].
    ///
    /// # Safety
    ///
    /// Llamar a este método con un índice fuera de límites es *[comportamiento indefinido]* incluso si no se utiliza la referencia resultante.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SEGURIDAD: la persona que llama debe cumplir con la mayoría de los requisitos de seguridad para `get_unchecked`;
        // el segmento es desreferenciable porque `self` es una referencia segura.
        // El puntero devuelto es seguro porque las implicaciones de `SliceIndex` deben garantizar que lo sea.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Devuelve una referencia mutable a un elemento o sublicencia, sin verificar los límites.
    ///
    /// Para una alternativa segura, consulte [`get_mut`].
    ///
    /// # Safety
    ///
    /// Llamar a este método con un índice fuera de límites es *[comportamiento indefinido]* incluso si no se utiliza la referencia resultante.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SEGURIDAD: la persona que llama debe cumplir con los requisitos de seguridad para `get_unchecked_mut`;
        // el segmento es desreferenciable porque `self` es una referencia segura.
        // El puntero devuelto es seguro porque las implicaciones de `SliceIndex` deben garantizar que lo sea.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Devuelve un puntero sin procesar al búfer del segmento.
    ///
    /// La persona que llama debe asegurarse de que el segmento sobreviva al puntero que devuelve esta función o, de lo contrario, terminará apuntando a la basura.
    ///
    /// La persona que llama también debe asegurarse de que la memoria a la que apunta el puntero (non-transitively) nunca se escriba (excepto dentro de un `UnsafeCell`) utilizando este puntero o cualquier puntero derivado de él.
    /// Si necesita mutar el contenido del segmento, use [`as_mut_ptr`].
    ///
    /// La modificación del contenedor al que hace referencia este segmento puede hacer que su búfer se reasigne, lo que también invalidaría cualquier puntero.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Devuelve un puntero mutable inseguro al búfer del segmento.
    ///
    /// La persona que llama debe asegurarse de que el segmento sobreviva al puntero que devuelve esta función o, de lo contrario, terminará apuntando a la basura.
    ///
    /// La modificación del contenedor al que hace referencia este segmento puede hacer que su búfer se reasigne, lo que también invalidaría cualquier puntero.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Devuelve los dos punteros sin procesar que abarcan el sector.
    ///
    /// El rango devuelto está semiabierto, lo que significa que el puntero final apunta *uno más allá* del último elemento del segmento.
    /// De esta forma, un sector vacío se representa mediante dos punteros iguales y la diferencia entre los dos punteros representa el tamaño del sector.
    ///
    /// Consulte [`as_ptr`] para conocer las advertencias sobre el uso de estos indicadores.El puntero final requiere precaución adicional, ya que no apunta a un elemento válido en el sector.
    ///
    /// Esta función es útil para interactuar con interfaces externas que usan dos punteros para referirse a un rango de elementos en la memoria, como es común en C++ .
    ///
    ///
    /// También puede resultar útil comprobar si un puntero a un elemento se refiere a un elemento de este segmento:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SEGURIDAD: El `add` aquí es seguro porque:
        //
        //   - Ambos punteros son parte del mismo objeto, ya que apuntar directamente más allá del objeto también cuenta.
        //
        //   - El tamaño del segmento nunca supera los isize::MAX bytes, como se indica aquí:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - No hay ningún ajuste involucrado, ya que los segmentos no se ajustan más allá del final del espacio de direcciones.
        //
        // Consulte la documentación de pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Devuelve los dos punteros mutables inseguros que abarcan el segmento.
    ///
    /// El rango devuelto está semiabierto, lo que significa que el puntero final apunta *uno más allá* del último elemento del segmento.
    /// De esta forma, un sector vacío se representa mediante dos punteros iguales y la diferencia entre los dos punteros representa el tamaño del sector.
    ///
    /// Consulte [`as_mut_ptr`] para conocer las advertencias sobre el uso de estos indicadores.
    /// El puntero final requiere precaución adicional, ya que no apunta a un elemento válido en el sector.
    ///
    /// Esta función es útil para interactuar con interfaces externas que usan dos punteros para referirse a un rango de elementos en la memoria, como es común en C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SEGURIDAD: Consulte as_ptr_range() arriba para saber por qué `add` aquí es seguro.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Intercambia dos elementos del sector.
    ///
    /// # Arguments
    ///
    /// * a, el índice del primer elemento
    /// * b, el índice del segundo elemento
    ///
    /// # Panics
    ///
    /// Panics si `a` o `b` están fuera de los límites.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // No se pueden tomar dos préstamos mutables de un vector, así que en su lugar use punteros sin procesar.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SEGURIDAD: `pa` y `pb` se han creado a partir de referencias mutables seguras y consulte
        // a los elementos del segmento y, por lo tanto, se garantiza que sean válidos y estén alineados.
        // Tenga en cuenta que el acceso a los elementos detrás de `a` y `b` está marcado y panic cuando está fuera de los límites.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Invierte el orden de los elementos en el sector, en su lugar.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Para tipos muy pequeños, todas las lecturas individuales en la ruta normal funcionan mal.
        // Podemos hacerlo mejor, dado un load/store eficiente no alineado, cargando un fragmento más grande e invirtiendo un registro.
        //

        // Idealmente LLVM haría esto por nosotros, ya que sabe mejor que nosotros si las lecturas no alineadas son eficientes (ya que eso cambia entre diferentes versiones de ARM, por ejemplo) y cuál sería el mejor tamaño de fragmento.
        // Desafortunadamente, a partir de LLVM 4.0 (2017-05), solo desenrolla el bucle, por lo que debemos hacerlo nosotros mismos.
        // (Hipótesis: el reverso es problemático porque los lados se pueden alinear de manera diferente, lo será, cuando la longitud sea impar, por lo que no hay forma de emitir preludios y posludios para usar SIMD completamente alineado en el medio).
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Utilice el llvm.bswap intrínseco para revertir u8 en un tamaño
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SEGURIDAD: Hay varias cosas para verificar aquí:
                //
                // - Tenga en cuenta que `chunk` es 4 u 8 debido a la verificación cfg anterior.Entonces `chunk - 1` es positivo.
                // - La indexación con el índice `i` está bien, ya que la verificación de bucle garantiza
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - La indexación con el índice `ln - i - chunk = ln - (i + chunk)` está bien:
                //   - `i + chunk > 0` es trivialmente cierto.
                //   - La verificación de bucle garantiza:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, por lo que la resta no se desborda.
                // - Las llamadas `read_unaligned` y `write_unaligned` están bien:
                //   - `pa` apunta al índice `i` donde `i < ln / 2 - (chunk - 1)` (ver arriba) y `pb` apunta al índice `ln - i - chunk`, por lo que ambos están al menos `chunk` a muchos bytes del final de `self`.
                //
                //   - Cualquier memoria inicializada es `usize` válida.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Utilice rotar por 16 para revertir u16 en un u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SEGURIDAD: Se puede leer un u32 no alineado desde `i` si `i + 1 < ln`
                // (y obviamente `i < ln`), porque cada elemento tiene 2 bytes y estamos leyendo 4.
                //
                // `i + chunk - 1 < ln / 2` # mientras que la condición
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Dado que es menor que la longitud dividida por 2, entonces debe estar dentro de los límites.
                //
                // Esto también significa que siempre se respeta la condición `0 < i + chunk <= ln`, lo que garantiza que el puntero `pb` se pueda utilizar de forma segura.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SEGURIDAD: `i` es inferior a la mitad de la longitud de la rebanada, por lo que
            // acceder a `i` y `ln - i - 1` es seguro (`i` comienza en 0 y no irá más allá de `ln / 2 - 1`).
            // Los punteros resultantes `pa` y `pb` son, por tanto, válidos y alineados, y se pueden leer y escribir en ellos.
            //
            //
            unsafe {
                // Intercambio inseguro para evitar la verificación de límites en intercambio seguro.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Devuelve un iterador sobre el sector.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Devuelve un iterador que permite modificar cada valor.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Devuelve un iterador sobre todos los windows contiguos de longitud `size`.
    /// El windows se superpone.
    /// Si el segmento es más corto que `size`, el iterador no devuelve ningún valor.
    ///
    /// # Panics
    ///
    /// Panics si `size` es 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Si el corte es más corto que `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Devuelve un iterador sobre los elementos `chunk_size` del segmento a la vez, comenzando por el principio del segmento.
    ///
    /// Los trozos son rodajas y no se superponen.Si `chunk_size` no divide la longitud del corte, el último fragmento no tendrá la longitud `chunk_size`.
    ///
    /// Consulte [`chunks_exact`] para ver una variante de este iterador que devuelve fragmentos de elementos siempre exactamente `chunk_size`, y [`rchunks`] para el mismo iterador pero comenzando al final del segmento.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` es 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Devuelve un iterador sobre los elementos `chunk_size` del segmento a la vez, comenzando por el principio del segmento.
    ///
    /// Los trozos son cortes mutables y no se superponen.Si `chunk_size` no divide la longitud del corte, el último fragmento no tendrá la longitud `chunk_size`.
    ///
    /// Consulte [`chunks_exact_mut`] para ver una variante de este iterador que devuelve fragmentos de elementos siempre exactamente `chunk_size`, y [`rchunks_mut`] para el mismo iterador pero comenzando al final del segmento.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` es 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Devuelve un iterador sobre los elementos `chunk_size` del segmento a la vez, comenzando por el principio del segmento.
    ///
    /// Los trozos son rodajas y no se superponen.
    /// Si `chunk_size` no divide la longitud del segmento, se omitirán los últimos elementos hasta `chunk_size-1` y se podrán recuperar de la función `remainder` del iterador.
    ///
    ///
    /// Debido a que cada fragmento tiene exactamente elementos `chunk_size`, el compilador a menudo puede optimizar el código resultante mejor que en el caso de [`chunks`].
    ///
    /// Consulte [`chunks`] para ver una variante de este iterador que también devuelve el resto como un fragmento más pequeño y [`rchunks_exact`] para el mismo iterador pero comenzando al final del segmento.
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` es 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Devuelve un iterador sobre los elementos `chunk_size` del segmento a la vez, comenzando por el principio del segmento.
    ///
    /// Los trozos son cortes mutables y no se superponen.
    /// Si `chunk_size` no divide la longitud del segmento, se omitirán los últimos elementos hasta `chunk_size-1` y se podrán recuperar de la función `into_remainder` del iterador.
    ///
    ///
    /// Debido a que cada fragmento tiene exactamente elementos `chunk_size`, el compilador a menudo puede optimizar el código resultante mejor que en el caso de [`chunks_mut`].
    ///
    /// Consulte [`chunks_mut`] para ver una variante de este iterador que también devuelve el resto como un fragmento más pequeño y [`rchunks_exact_mut`] para el mismo iterador pero comenzando al final del segmento.
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` es 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Divide la porción en una porción de matrices de elementos "N", asumiendo que no hay resto.
    ///
    ///
    /// # Safety
    ///
    /// Esto solo se puede llamar cuando
    /// - El segmento se divide exactamente en trozos de elementos `N` (también conocido como `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SEGURIDAD: los trozos de 1 elemento nunca tienen resto
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SEGURIDAD: La longitud de corte (6) es un múltiplo de 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Estos serían incorrectos:
    /// // dejar trozos: &[[_;5]]= slice.as_chunks_unchecked()//La longitud del sector no es un múltiplo de 5 let chunks:&[[_;0]]= slice.as_chunks_unchecked()//No se permiten trozos de longitud cero
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SEGURIDAD: Nuestra condición previa es exactamente lo que se necesita para llamar a esto
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SEGURIDAD: Lanzamos una porción de elementos `new_len * N` en
        // una porción de `new_len` muchos trozos de elementos `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Divide el segmento en un segmento de matrices de elementos "N", comenzando al principio del segmento, y un segmento restante con una longitud estrictamente menor que `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `N` es 0. Lo más probable es que esta comprobación se cambie a un error de tiempo de compilación antes de que se estabilice este método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SEGURIDAD: Ya entramos en pánico por cero, y lo garantizó la construcción.
        // que la longitud de la sublicencia es un múltiplo de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Divide el segmento en un segmento de matrices de elementos "N", comenzando al final del segmento, y un segmento restante con una longitud estrictamente menor que `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `N` es 0. Lo más probable es que esta comprobación se cambie a un error de tiempo de compilación antes de que se estabilice este método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SEGURIDAD: Ya entramos en pánico por cero, y lo garantizó la construcción.
        // que la longitud de la sublicencia es un múltiplo de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Devuelve un iterador sobre los elementos `N` del segmento a la vez, comenzando por el principio del segmento.
    ///
    /// Los fragmentos son referencias de matriz y no se superponen.
    /// Si `N` no divide la longitud del segmento, se omitirán los últimos elementos hasta `N-1` y se podrán recuperar de la función `remainder` del iterador.
    ///
    ///
    /// Este método es el equivalente genérico constante de [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics si `N` es 0. Lo más probable es que esta comprobación se cambie a un error de tiempo de compilación antes de que se estabilice este método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Divide la porción en una porción de matrices de elementos "N", asumiendo que no hay resto.
    ///
    ///
    /// # Safety
    ///
    /// Esto solo se puede llamar cuando
    /// - El segmento se divide exactamente en trozos de elementos `N` (también conocido como `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SEGURIDAD: los trozos de 1 elemento nunca tienen resto
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SEGURIDAD: La longitud de corte (6) es un múltiplo de 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Estos serían incorrectos:
    /// // dejar trozos: &[[_;5]]= slice.as_chunks_unchecked_mut()//La longitud del sector no es un múltiplo de 5 let chunks:&[[_;0]]= slice.as_chunks_unchecked_mut()//No se permiten trozos de longitud cero
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SEGURIDAD: Nuestra condición previa es exactamente lo que se necesita para llamar a esto
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SEGURIDAD: Lanzamos una porción de elementos `new_len * N` en
        // una porción de `new_len` muchos trozos de elementos `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Divide el segmento en un segmento de matrices de elementos "N", comenzando al principio del segmento, y un segmento restante con una longitud estrictamente menor que `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `N` es 0. Lo más probable es que esta comprobación se cambie a un error de tiempo de compilación antes de que se estabilice este método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SEGURIDAD: Ya entramos en pánico por cero, y lo garantizó la construcción.
        // que la longitud de la sublicencia es un múltiplo de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Divide el segmento en un segmento de matrices de elementos "N", comenzando al final del segmento, y un segmento restante con una longitud estrictamente menor que `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `N` es 0. Lo más probable es que esta comprobación se cambie a un error de tiempo de compilación antes de que se estabilice este método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SEGURIDAD: Ya entramos en pánico por cero, y lo garantizó la construcción.
        // que la longitud de la sublicencia es un múltiplo de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Devuelve un iterador sobre los elementos `N` del segmento a la vez, comenzando por el principio del segmento.
    ///
    /// Los fragmentos son referencias de matriz mutables y no se superponen.
    /// Si `N` no divide la longitud del segmento, se omitirán los últimos elementos hasta `N-1` y se podrán recuperar de la función `into_remainder` del iterador.
    ///
    ///
    /// Este método es el equivalente genérico constante de [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics si `N` es 0. Lo más probable es que esta comprobación se cambie a un error de tiempo de compilación antes de que se estabilice este método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Devuelve un iterador sobre windows superpuesto de elementos `N` de un sector, comenzando por el principio del sector.
    ///
    ///
    /// Este es el equivalente genérico constante de [`windows`].
    ///
    /// Si `N` es mayor que el tamaño del segmento, no devolverá windows.
    ///
    /// # Panics
    ///
    /// Panics si `N` es 0.
    /// Lo más probable es que esta comprobación se cambie a un error de tiempo de compilación antes de que este método se estabilice.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Devuelve un iterador sobre los elementos `chunk_size` del segmento a la vez, comenzando al final del segmento.
    ///
    /// Los trozos son rodajas y no se superponen.Si `chunk_size` no divide la longitud del corte, el último fragmento no tendrá la longitud `chunk_size`.
    ///
    /// Consulte [`rchunks_exact`] para ver una variante de este iterador que devuelve fragmentos de elementos siempre exactamente `chunk_size`, y [`chunks`] para el mismo iterador pero comenzando al principio del segmento.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` es 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Devuelve un iterador sobre los elementos `chunk_size` del segmento a la vez, comenzando al final del segmento.
    ///
    /// Los trozos son cortes mutables y no se superponen.Si `chunk_size` no divide la longitud del corte, el último fragmento no tendrá la longitud `chunk_size`.
    ///
    /// Consulte [`rchunks_exact_mut`] para ver una variante de este iterador que devuelve fragmentos de elementos siempre exactamente `chunk_size`, y [`chunks_mut`] para el mismo iterador pero comenzando al principio del segmento.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` es 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Devuelve un iterador sobre los elementos `chunk_size` del segmento a la vez, comenzando al final del segmento.
    ///
    /// Los trozos son rodajas y no se superponen.
    /// Si `chunk_size` no divide la longitud del segmento, se omitirán los últimos elementos hasta `chunk_size-1` y se podrán recuperar de la función `remainder` del iterador.
    ///
    /// Debido a que cada fragmento tiene exactamente elementos `chunk_size`, el compilador a menudo puede optimizar el código resultante mejor que en el caso de [`chunks`].
    ///
    /// Consulte [`rchunks`] para ver una variante de este iterador que también devuelve el resto como un fragmento más pequeño, y [`chunks_exact`] para el mismo iterador pero comenzando al principio del segmento.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` es 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Devuelve un iterador sobre los elementos `chunk_size` del segmento a la vez, comenzando al final del segmento.
    ///
    /// Los trozos son cortes mutables y no se superponen.
    /// Si `chunk_size` no divide la longitud del segmento, se omitirán los últimos elementos hasta `chunk_size-1` y se podrán recuperar de la función `into_remainder` del iterador.
    ///
    /// Debido a que cada fragmento tiene exactamente elementos `chunk_size`, el compilador a menudo puede optimizar el código resultante mejor que en el caso de [`chunks_mut`].
    ///
    /// Consulte [`rchunks_mut`] para ver una variante de este iterador que también devuelve el resto como un fragmento más pequeño, y [`chunks_exact_mut`] para el mismo iterador pero comenzando al principio del segmento.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` es 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Devuelve un iterador sobre el segmento que produce ejecuciones de elementos que no se superponen utilizando el predicado para separarlos.
    ///
    /// El predicado se llama en dos elementos que siguen a sí mismos, significa que el predicado se llama en `slice[0]` y `slice[1]`, luego en `slice[1]` y `slice[2]` y así sucesivamente.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Este método se puede utilizar para extraer las sublices ordenadas:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Devuelve un iterador sobre el segmento que produce ejecuciones mutables de elementos que no se superponen utilizando el predicado para separarlos.
    ///
    /// El predicado se llama en dos elementos que siguen a sí mismos, significa que el predicado se llama en `slice[0]` y `slice[1]`, luego en `slice[1]` y `slice[2]` y así sucesivamente.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Este método se puede utilizar para extraer las sublices ordenadas:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Divide una porción en dos en un índice.
    ///
    /// El primero contendrá todos los índices de `[0, mid)` (excluyendo el índice `mid` en sí) y el segundo contendrá todos los índices de `[mid, len)` (excluyendo el índice `len` en sí).
    ///
    ///
    /// # Panics
    ///
    /// Panics si `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SEGURIDAD: `[ptr; mid]` y `[mid; len]` están dentro de `self`, que
        // cumple los requisitos de `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Divide un segmento mutable en dos en un índice.
    ///
    /// El primero contendrá todos los índices de `[0, mid)` (excluyendo el índice `mid` en sí) y el segundo contendrá todos los índices de `[mid, len)` (excluyendo el índice `len` en sí).
    ///
    ///
    /// # Panics
    ///
    /// Panics si `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SEGURIDAD: `[ptr; mid]` y `[mid; len]` están dentro de `self`, que
        // cumple los requisitos de `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Divide una porción en dos en un índice, sin verificar los límites.
    ///
    /// El primero contendrá todos los índices de `[0, mid)` (excluyendo el índice `mid` en sí) y el segundo contendrá todos los índices de `[mid, len)` (excluyendo el índice `len` en sí).
    ///
    ///
    /// Para una alternativa segura, consulte [`split_at`].
    ///
    /// # Safety
    ///
    /// Llamar a este método con un índice fuera de límites es *[comportamiento indefinido]* incluso si no se utiliza la referencia resultante.La persona que llama debe asegurarse de que `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SEGURIDAD: La persona que llama debe verificar que `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Divide un segmento mutable en dos en un índice, sin verificar los límites.
    ///
    /// El primero contendrá todos los índices de `[0, mid)` (excluyendo el índice `mid` en sí) y el segundo contendrá todos los índices de `[mid, len)` (excluyendo el índice `len` en sí).
    ///
    ///
    /// Para una alternativa segura, consulte [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Llamar a este método con un índice fuera de límites es *[comportamiento indefinido]* incluso si no se utiliza la referencia resultante.La persona que llama debe asegurarse de que `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SEGURIDAD: La persona que llama debe verificar que `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` y `[mid; len]` no se superponen, por lo que devolver una referencia mutable está bien.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Devuelve un iterador sobre sublices separados por elementos que coinciden con `pred`.
    /// El elemento emparejado no está contenido en las sublicencias.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Si el primer elemento coincide, un segmento vacío será el primer elemento devuelto por el iterador.
    /// De manera similar, si el último elemento del segmento coincide, un segmento vacío será el último elemento devuelto por el iterador:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Si dos elementos coincidentes son directamente adyacentes, habrá un segmento vacío entre ellos:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Devuelve un iterador sobre sublices mutables separados por elementos que coinciden con `pred`.
    /// El elemento emparejado no está contenido en las sublicencias.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Devuelve un iterador sobre sublices separados por elementos que coinciden con `pred`.
    /// El elemento emparejado está contenido al final de la sublicencia anterior como terminador.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Si el último elemento del segmento coincide, ese elemento se considerará el terminador del segmento anterior.
    ///
    /// Ese segmento será el último elemento devuelto por el iterador.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Devuelve un iterador sobre sublices mutables separados por elementos que coinciden con `pred`.
    /// El elemento emparejado está contenido en la sublicencia anterior como terminador.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Devuelve un iterador sobre sublices separados por elementos que coinciden con `pred`, comenzando al final del segmento y trabajando hacia atrás.
    /// El elemento emparejado no está contenido en las sublicencias.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Al igual que con `split()`, si el primer o el último elemento coincide, un segmento vacío será el primer (o último) elemento devuelto por el iterador.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Devuelve un iterador sobre sublices mutables separados por elementos que coinciden con `pred`, comenzando al final del segmento y trabajando hacia atrás.
    /// El elemento emparejado no está contenido en las sublicencias.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Devuelve un iterador sobre sublices separados por elementos que coinciden con `pred`, limitado a devolver como máximo elementos `n`.
    /// El elemento emparejado no está contenido en las sublicencias.
    ///
    /// El último elemento devuelto, si lo hubiera, contendrá el resto del segmento.
    ///
    /// # Examples
    ///
    /// Imprima el corte dividido una vez por números divisibles por 3 (es decir, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Devuelve un iterador sobre sublices separados por elementos que coinciden con `pred`, limitado a devolver como máximo elementos `n`.
    /// El elemento emparejado no está contenido en las sublicencias.
    ///
    /// El último elemento devuelto, si lo hubiera, contendrá el resto del segmento.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Devuelve un iterador sobre sublices separados por elementos que coinciden con `pred` limitado a devolver como máximo elementos `n`.
    /// Esto comienza al final del corte y funciona al revés.
    /// El elemento emparejado no está contenido en las sublicencias.
    ///
    /// El último elemento devuelto, si lo hubiera, contendrá el resto del segmento.
    ///
    /// # Examples
    ///
    /// Imprima el corte dividido una vez, comenzando desde el final, por números divisibles por 3 (es decir, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Devuelve un iterador sobre sublices separados por elementos que coinciden con `pred` limitado a devolver como máximo elementos `n`.
    /// Esto comienza al final del corte y funciona al revés.
    /// El elemento emparejado no está contenido en las sublicencias.
    ///
    /// El último elemento devuelto, si lo hubiera, contendrá el resto del segmento.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Devuelve `true` si el sector contiene un elemento con el valor dado.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Si no tiene un `&T`, pero solo un `&U` tal que `T: Borrow<U>` (p. Ej.
    /// `Cadena: Pedir prestado<str>`), puede utilizar `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // rebanada de `String`
    /// assert!(v.iter().any(|e| e == "hello")); // buscar con `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Devuelve `true` si `needle` es un prefijo del segmento.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Siempre devuelve `true` si `needle` es un segmento vacío:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Devuelve `true` si `needle` es un sufijo del sector.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Siempre devuelve `true` si `needle` es un segmento vacío:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Devuelve una sublicencia con el prefijo eliminado.
    ///
    /// Si el segmento comienza con `prefix`, devuelve el sublicto después del prefijo, envuelto en `Some`.
    /// Si `prefix` está vacío, simplemente devuelve el segmento original.
    ///
    /// Si el segmento no comienza con `prefix`, devuelve `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Esta función necesitará ser reescrita siempre y cuando SlicePattern se vuelva más sofisticado.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Devuelve una sublicencia con el sufijo eliminado.
    ///
    /// Si el sector termina con `suffix`, devuelve el sublicto antes del sufijo, envuelto en `Some`.
    /// Si `suffix` está vacío, simplemente devuelve el segmento original.
    ///
    /// Si el segmento no termina con `suffix`, devuelve `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Esta función necesitará ser reescrita siempre y cuando SlicePattern se vuelva más sofisticado.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary busca en este segmento ordenado un elemento determinado.
    ///
    /// Si se encuentra el valor, se devuelve [`Result::Ok`], que contiene el índice del elemento coincidente.
    /// Si hay varias coincidencias, se puede devolver cualquiera de las coincidencias.
    /// Si no se encuentra el valor, se devuelve [`Result::Err`], que contiene el índice donde se podría insertar un elemento coincidente manteniendo el orden ordenado.
    ///
    ///
    /// Consulte también [`binary_search_by`], [`binary_search_by_key`] y [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Busca una serie de cuatro elementos.
    /// Se encuentra el primero, con una posición determinada unívocamente;el segundo y el tercero no se encuentran;el cuarto podría coincidir con cualquier posición en `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Si desea insertar un elemento en un vector ordenado, manteniendo el orden de clasificación:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binary busca este segmento ordenado con una función de comparación.
    ///
    /// La función de comparación debe implementar un orden consistente con el orden de clasificación del segmento subyacente, devolviendo un código de orden que indique si su argumento es `Less`, `Equal` o `Greater` el objetivo deseado.
    ///
    ///
    /// Si se encuentra el valor, se devuelve [`Result::Ok`], que contiene el índice del elemento coincidente.Si hay varias coincidencias, se puede devolver cualquiera de las coincidencias.
    /// Si no se encuentra el valor, se devuelve [`Result::Err`], que contiene el índice donde se podría insertar un elemento coincidente manteniendo el orden ordenado.
    ///
    /// Consulte también [`binary_search`], [`binary_search_by_key`] y [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Busca una serie de cuatro elementos.Se encuentra el primero, con una posición determinada unívocamente;el segundo y el tercero no se encuentran;el cuarto podría coincidir con cualquier posición en `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SEGURIDAD: la llamada se hace segura mediante las siguientes invariantes:
            // - `mid >= 0`
            // - `mid < size`: `mid` está limitado por el límite `[left; right)`.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // La razón por la que usamos el flujo de control if/else en lugar de la coincidencia es porque la coincidencia reordena las operaciones de comparación, que son sensibles al rendimiento.
            //
            // Este es el conjunto x86 para u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binary busca este segmento ordenado con una función de extracción de claves.
    ///
    /// Supone que el segmento se ordena por clave, por ejemplo, con [`sort_by_key`] utilizando la misma función de extracción de clave.
    ///
    /// Si se encuentra el valor, se devuelve [`Result::Ok`], que contiene el índice del elemento coincidente.
    /// Si hay varias coincidencias, se puede devolver cualquiera de las coincidencias.
    /// Si no se encuentra el valor, se devuelve [`Result::Err`], que contiene el índice donde se podría insertar un elemento coincidente manteniendo el orden ordenado.
    ///
    ///
    /// Consulte también [`binary_search`], [`binary_search_by`] y [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Busca una serie de cuatro elementos en una porción de pares ordenados por sus segundos elementos.
    /// Se encuentra el primero, con una posición determinada unívocamente;el segundo y el tercero no se encuentran;el cuarto podría coincidir con cualquier posición en `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links está permitido ya que `slice::sort_by_key` está en crate `alloc` y, como tal, aún no existe cuando se construye `core`.
    //
    // enlaces a crate descendente: #74481.Dado que las primitivas solo se documentan en libstd (#73423), esto nunca conduce a enlaces rotos en la práctica.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Ordena el sector, pero es posible que no conserve el orden de elementos iguales.
    ///
    /// Esta clasificación es inestable (es decir, puede reordenar elementos iguales), en el lugar (es decir, no asigna) y *O*(*n*\*log(* n*)) en el peor de los casos.
    ///
    /// # Implementación actual
    ///
    /// El algoritmo actual se basa en [pattern-defeating quicksort][pdqsort] de Orson Peters, que combina el caso promedio rápido de ordenación rápida aleatoria con el peor caso rápido de ordenación en pilas, al tiempo que logra un tiempo lineal en cortes con ciertos patrones.
    /// Utiliza cierta aleatorización para evitar casos degenerados, pero con un seed fijo para proporcionar siempre un comportamiento determinista.
    ///
    /// Por lo general, es más rápido que la clasificación estable, excepto en algunos casos especiales, por ejemplo, cuando el segmento consta de varias secuencias clasificadas concatenadas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Ordena el sector con una función de comparación, pero es posible que no conserve el orden de elementos iguales.
    ///
    /// Esta clasificación es inestable (es decir, puede reordenar elementos iguales), en el lugar (es decir, no asigna) y *O*(*n*\*log(* n*)) en el peor de los casos.
    ///
    /// La función de comparación debe definir un orden total para los elementos del sector.Si el orden no es total, el orden de los elementos no se especifica.Un pedido es un pedido total si lo es (para todos los `a`, `b` y `c`):
    ///
    /// * total y antisimétrico: exactamente uno de `a < b`, `a == b` o `a > b` es verdadero, y
    /// * transitivo, `a < b` y `b < c` implica `a < c`.Lo mismo debe aplicarse tanto para `==` como para `>`.
    ///
    /// Por ejemplo, si bien [`f64`] no implementa [`Ord`] porque `NaN != NaN`, podemos usar `partial_cmp` como nuestra función de clasificación cuando sabemos que el segmento no contiene un `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Implementación actual
    ///
    /// El algoritmo actual se basa en [pattern-defeating quicksort][pdqsort] de Orson Peters, que combina el caso promedio rápido de ordenación rápida aleatoria con el peor caso rápido de ordenación en pilas, al tiempo que logra un tiempo lineal en cortes con ciertos patrones.
    /// Utiliza cierta aleatorización para evitar casos degenerados, pero con un seed fijo para proporcionar siempre un comportamiento determinista.
    ///
    /// Por lo general, es más rápido que la clasificación estable, excepto en algunos casos especiales, por ejemplo, cuando el segmento consta de varias secuencias clasificadas concatenadas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // clasificación inversa
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Ordena el segmento con una función de extracción de claves, pero es posible que no conserve el orden de elementos iguales.
    ///
    /// Este tipo es inestable (es decir, puede reordenar elementos iguales), en el lugar (es decir, no asigna) y *O*(m\* * n *\* log(*n*)) en el peor de los casos, donde la función clave es *O*(*metro*).
    ///
    /// # Implementación actual
    ///
    /// El algoritmo actual se basa en [pattern-defeating quicksort][pdqsort] de Orson Peters, que combina el caso promedio rápido de ordenación rápida aleatoria con el peor caso rápido de ordenación en pilas, al tiempo que logra un tiempo lineal en cortes con ciertos patrones.
    /// Utiliza cierta aleatorización para evitar casos degenerados, pero con un seed fijo para proporcionar siempre un comportamiento determinista.
    ///
    /// Debido a su estrategia de llamada de tecla, es probable que [`sort_unstable_by_key`](#method.sort_unstable_by_key) sea más lento que [`sort_by_cached_key`](#method.sort_by_cached_key) en los casos en que la función de la tecla sea cara.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Reordene el sector de modo que el elemento en `index` esté en su posición final ordenada.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Reordene el segmento con una función de comparación de modo que el elemento en `index` esté en su posición final ordenada.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Reordene el corte con una función de extracción de clave de modo que el elemento en `index` esté en su posición final ordenada.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Reordene el sector de modo que el elemento en `index` esté en su posición final ordenada.
    ///
    /// Esta reordenación tiene la propiedad adicional de que cualquier valor en la posición `i < index` será menor o igual que cualquier valor en la posición `j > index`.
    /// Además, este reordenamiento es inestable (es decir
    /// cualquier número de elementos iguales puede terminar en la posición `index`), en el lugar (es decir
    /// no asigna), y *O*(*n*) en el peor de los casos.
    /// Esta función también se conoce como "kth element" en otras bibliotecas.
    /// Devuelve un triplete de los siguientes valores: todos los elementos menores que el del índice dado, el valor del índice dado y todos los elementos mayores que el del índice dado.
    ///
    ///
    /// # Implementación actual
    ///
    /// El algoritmo actual se basa en la parte de selección rápida del mismo algoritmo de ordenación rápida utilizado para [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics cuando `index >= len()`, lo que significa que siempre panics en rebanadas vacías.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Encuentra la mediana
    /// v.select_nth_unstable(2);
    ///
    /// // Solo se nos garantiza que el segmento será uno de los siguientes, según la forma en que clasificamos el índice especificado.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reordene el segmento con una función de comparación de modo que el elemento en `index` esté en su posición final ordenada.
    ///
    /// Esta reordenación tiene la propiedad adicional de que cualquier valor en la posición `i < index` será menor o igual a cualquier valor en una posición `j > index` usando la función de comparación.
    /// Además, este reordenamiento es inestable (es decir, cualquier número de elementos iguales puede terminar en la posición `index`), en el lugar (es decir, no asigna) y *O*(*n*) en el peor de los casos.
    /// Esta función también se conoce como "kth element" en otras bibliotecas.
    /// Devuelve un triplete de los siguientes valores: todos los elementos menores que el del índice dado, el valor del índice dado y todos los elementos mayores que el del índice dado, utilizando la función de comparación proporcionada.
    ///
    ///
    /// # Implementación actual
    ///
    /// El algoritmo actual se basa en la parte de selección rápida del mismo algoritmo de ordenación rápida utilizado para [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics cuando `index >= len()`, lo que significa que siempre panics en rebanadas vacías.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Encuentre la mediana como si el sector estuviera ordenado en orden descendente.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Solo se nos garantiza que el segmento será uno de los siguientes, según la forma en que clasificamos el índice especificado.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reordene el corte con una función de extracción de clave de modo que el elemento en `index` esté en su posición final ordenada.
    ///
    /// Esta reordenación tiene la propiedad adicional de que cualquier valor en la posición `i < index` será menor o igual que cualquier valor en una posición `j > index` usando la función de extracción de claves.
    /// Además, este reordenamiento es inestable (es decir, cualquier número de elementos iguales puede terminar en la posición `index`), en el lugar (es decir, no asigna) y *O*(*n*) en el peor de los casos.
    /// Esta función también se conoce como "kth element" en otras bibliotecas.
    /// Devuelve un triplete de los siguientes valores: todos los elementos menores que el del índice dado, el valor del índice dado y todos los elementos mayores que el del índice dado, utilizando la función de extracción de claves proporcionada.
    ///
    ///
    /// # Implementación actual
    ///
    /// El algoritmo actual se basa en la parte de selección rápida del mismo algoritmo de ordenación rápida utilizado para [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics cuando `index >= len()`, lo que significa que siempre panics en rebanadas vacías.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Devuelve la mediana como si la matriz estuviera ordenada según el valor absoluto.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Solo se nos garantiza que el segmento será uno de los siguientes, según la forma en que clasificamos el índice especificado.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Mueve todos los elementos repetidos consecutivos al final del segmento de acuerdo con la implementación [`PartialEq`] trait.
    ///
    ///
    /// Devuelve dos rebanadas.El primero no contiene elementos repetidos consecutivos.
    /// El segundo contiene todos los duplicados sin ningún orden especificado.
    ///
    /// Si el sector está ordenado, el primer sector devuelto no contiene duplicados.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Mueve todos los elementos consecutivos excepto el primero al final del segmento que satisface una relación de igualdad dada.
    ///
    /// Devuelve dos rebanadas.El primero no contiene elementos repetidos consecutivos.
    /// El segundo contiene todos los duplicados sin ningún orden especificado.
    ///
    /// A la función `same_bucket` se le pasan referencias a dos elementos del segmento y debe determinar si los elementos se comparan igual.
    /// Los elementos se pasan en orden opuesto a su orden en el segmento, por lo que si `same_bucket(a, b)` devuelve `true`, `a` se mueve al final del segmento.
    ///
    ///
    /// Si el sector está ordenado, el primer sector devuelto no contiene duplicados.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Aunque tenemos una referencia mutable a `self`, no podemos hacer cambios *arbitrarios*.Las llamadas `same_bucket` podrían panic, por lo que debemos asegurarnos de que el segmento esté en un estado válido en todo momento.
        //
        // La forma en que manejamos esto es mediante intercambios;iteramos sobre todos los elementos, intercambiando sobre la marcha para que al final los elementos que deseamos conservar estén al frente y los que deseamos rechazar al final.
        // Luego podemos dividir la rebanada.
        // Esta operación sigue siendo `O(n)`.
        //
        // Ejemplo: comenzamos en este estado, donde `r` representa "siguiente
        // read "y `w` representa" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Comparando self[r] con self [w-1], esto no es un duplicado, por lo que intercambiamos self[r] y self[w] (sin efecto como r==w) y luego incrementamos tanto r como w, dejándonos con:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Comparando self[r] con self [w-1], este valor es un duplicado, por lo que incrementamos `r` pero dejamos todo lo demás sin cambios:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Comparando self[r] con self [w-1], esto no es un duplicado, así que intercambie self[r] y self[w] y avance r y w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // No es un duplicado, repita:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplicar, advance r. End de rebanada.Dividir en w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SEGURIDAD: la condición `while` garantiza `next_read` y `next_write`
        // son menores que `len`, por lo que están dentro de `self`.
        // `prev_ptr_write` apunta a un elemento antes de `ptr_write`, pero `next_write` comienza en 1, por lo que `prev_ptr_write` nunca es menor que 0 y está dentro del segmento.
        // Esto cumple con los requisitos para desreferenciar `ptr_read`, `prev_ptr_write` y `ptr_write`, y para usar `ptr.add(next_read)`, `ptr.add(next_write - 1)` y `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` también se incrementa como máximo una vez por ciclo, lo que significa que no se omite ningún elemento cuando sea necesario intercambiarlo.
        //
        // `ptr_read` y `prev_ptr_write` nunca apuntan al mismo elemento.Esto es necesario para que `&mut *ptr_read`, `&mut* prev_ptr_write` sea seguro.
        // La explicación es simplemente que `next_read >= next_write` siempre es cierto, por lo que `next_read > next_write - 1` también lo es.
        //
        //
        //
        //
        //
        unsafe {
            // Evite las comprobaciones de límites utilizando punteros sin formato.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Mueve todos los elementos consecutivos excepto el primero al final del segmento que se resuelve en la misma clave.
    ///
    ///
    /// Devuelve dos rebanadas.El primero no contiene elementos repetidos consecutivos.
    /// El segundo contiene todos los duplicados sin ningún orden especificado.
    ///
    /// Si el sector está ordenado, el primer sector devuelto no contiene duplicados.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Gira el corte en su lugar de modo que los primeros elementos `mid` del corte se muevan hacia el final mientras que los últimos elementos `self.len() - mid` se mueven hacia el frente.
    /// Después de llamar a `rotate_left`, el elemento anteriormente en el índice `mid` se convertirá en el primer elemento del segmento.
    ///
    /// # Panics
    ///
    /// Esta función se activará panic si `mid` es mayor que la longitud del corte.Tenga en cuenta que `mid == self.len()` hace _not_ panic y es una rotación sin operación.
    ///
    /// # Complexity
    ///
    /// Toma lineal (en tiempo `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Rotación de una sublicencia:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SEGURIDAD: La gama `[p.add(mid) - mid, p.add(mid) + k)` es trivialmente
        // válido para lectura y escritura, como lo requiere `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Gira el corte en su lugar de modo que los primeros elementos `self.len() - k` del corte se muevan hacia el final mientras que los últimos elementos `k` se mueven hacia el frente.
    /// Después de llamar a `rotate_right`, el elemento anteriormente en el índice `self.len() - k` se convertirá en el primer elemento del segmento.
    ///
    /// # Panics
    ///
    /// Esta función se activará panic si `k` es mayor que la longitud del corte.Tenga en cuenta que `k == self.len()` hace _not_ panic y es una rotación sin operación.
    ///
    /// # Complexity
    ///
    /// Toma lineal (en tiempo `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Rotar una sublicencia:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SEGURIDAD: La gama `[p.add(mid) - mid, p.add(mid) + k)` es trivialmente
        // válido para lectura y escritura, como lo requiere `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Rellena `self` con elementos clonando `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Llena `self` con elementos devueltos llamando repetidamente a un cierre.
    ///
    /// Este método usa un cierre para crear nuevos valores.Si prefiere [`Clone`] un valor dado, use [`fill`].
    /// Si desea utilizar [`Default`] trait para generar valores, puede pasar [`Default::default`] como argumento.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Copia los elementos de `src` a `self`.
    ///
    /// La longitud de `src` debe ser la misma que `self`.
    ///
    /// Si `T` implementa `Copy`, puede ser más eficaz usar [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Esta función se activará panic si los dos cortes tienen diferentes longitudes.
    ///
    /// # Examples
    ///
    /// Clonando dos elementos de un corte a otro:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Debido a que los cortes deben tener la misma longitud, cortamos el corte de origen de cuatro elementos a dos.
    /// // Será panic si no hacemos esto.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust hace cumplir que solo puede haber una referencia mutable sin referencias inmutables a un dato particular en un alcance particular.
    /// Debido a esto, intentar usar `clone_from_slice` en un solo segmento resultará en un error de compilación:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Para solucionar este problema, podemos usar [`split_at_mut`] para crear dos sub-sectores distintos a partir de un sector:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Copia todos los elementos de `src` a `self`, utilizando un archivo memcpy.
    ///
    /// La longitud de `src` debe ser la misma que `self`.
    ///
    /// Si `T` no implementa `Copy`, use [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Esta función se activará panic si los dos cortes tienen diferentes longitudes.
    ///
    /// # Examples
    ///
    /// Copiar dos elementos de un corte a otro:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Debido a que los cortes deben tener la misma longitud, cortamos el corte de origen de cuatro elementos a dos.
    /// // Será panic si no hacemos esto.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust hace cumplir que solo puede haber una referencia mutable sin referencias inmutables a un dato particular en un alcance particular.
    /// Debido a esto, intentar usar `copy_from_slice` en un solo segmento resultará en un error de compilación:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Para solucionar este problema, podemos usar [`split_at_mut`] para crear dos sub-sectores distintos a partir de un sector:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // La ruta del código panic se puso en una función fría para no sobrecargar el sitio de la llamada.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SEGURIDAD: `self` es válido para elementos `self.len()` por definición, y `src` fue
        // comprobado para tener la misma longitud.
        // Los cortes no se pueden superponer porque las referencias mutables son exclusivas.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Copia elementos de una parte del sector a otra parte de sí mismo, mediante memmove.
    ///
    /// `src` es el rango dentro de `self` desde el que copiar.
    /// `dest` es el índice inicial del rango dentro de `self` al que copiar, que tendrá la misma longitud que `src`.
    /// Los dos rangos pueden superponerse.
    /// Los extremos de los dos rangos deben ser menores o iguales a `self.len()`.
    ///
    /// # Panics
    ///
    /// Esta función se activará panic si cualquiera de los rangos excede el final del segmento, o si el final de `src` es antes del inicio.
    ///
    ///
    /// # Examples
    ///
    /// Copiando cuatro bytes dentro de un segmento:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SEGURIDAD: todas las condiciones para `ptr::copy` se han verificado anteriormente,
        // al igual que los de `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Intercambia todos los elementos de `self` con los de `other`.
    ///
    /// La longitud de `other` debe ser la misma que `self`.
    ///
    /// # Panics
    ///
    /// Esta función se activará panic si los dos cortes tienen diferentes longitudes.
    ///
    /// # Example
    ///
    /// Intercambiar dos elementos en sectores:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust hace cumplir que solo puede haber una referencia mutable a un dato particular en un ámbito particular.
    ///
    /// Debido a esto, intentar usar `swap_with_slice` en un solo segmento resultará en un error de compilación:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Para solucionar esto, podemos usar [`split_at_mut`] para crear dos sub-sectores distintos mutables a partir de un sector:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SEGURIDAD: `self` es válido para elementos `self.len()` por definición, y `src` fue
        // comprobado para tener la misma longitud.
        // Los cortes no se pueden superponer porque las referencias mutables son exclusivas.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Función para calcular las longitudes del corte medio y final para `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Lo que vamos a hacer con `rest` es averiguar qué múltiplo de "U" podemos poner en el número más bajo de "T".
        //
        // Y cuántas 'T`s necesitamos para cada "multiple".
        //
        // Considere, por ejemplo, T=u8 U=u16.Entonces podemos poner 1 U en 2 Ts.Sencillo.
        // Ahora, considere, por ejemplo, un caso en el que size_of: :<T>=16, tamaño_de::<U>=24.</u>
        // Podemos poner 2 Us en lugar de cada 3 Ts en el segmento `rest`.
        // Un poco más complicado.
        //
        // La fórmula para calcular esto es:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/tamaño_de: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/tamaño_de::</u><T>
        //
        // Ampliado y simplificado:
        //
        // Nosotros=tamaño_de: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=tamaño_de::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Afortunadamente, dado que todo esto se evalúa constantemente ... ¡el rendimiento aquí no importa!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // algoritmo de stein iterativo Todavía deberíamos hacer este `const fn` (y volver al algoritmo recursivo si lo hacemos) porque confiar en llvm para consteval todo esto es ... bueno, me incomoda.
            //
            //

            // SEGURIDAD: Se verifica que `a` y `b` sean valores distintos de cero.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // eliminar todos los factores de 2 de b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SEGURIDAD: Se verifica que `b` sea distinto de cero.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // ¡Armados con este conocimiento, podemos encontrar cuántas 'U`s podemos caber!
        let us_len = self.len() / ts * us;
        // ¡Y cuántas "T" habrá en el segmento final!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmutar la rebanada en una rebanada de otro tipo, asegurando que se mantenga la alineación de los tipos.
    ///
    /// Este método divide el segmento en tres segmentos distintos: prefijo, segmento medio correctamente alineado de un nuevo tipo y segmento de sufijo.
    /// El método puede hacer que el segmento medio tenga la mayor longitud posible para un tipo y segmento de entrada determinados, pero solo el rendimiento de su algoritmo debería depender de eso, no de su exactitud.
    ///
    /// Se permite que todos los datos de entrada se devuelvan como prefijo o segmento de sufijo.
    ///
    /// Este método no tiene ningún propósito cuando el elemento de entrada `T` o el elemento de salida `U` son de tamaño cero y devolverán el segmento original sin dividir nada.
    ///
    /// # Safety
    ///
    /// Este método es esencialmente un `transmute` con respecto a los elementos del segmento medio devuelto, por lo que todas las advertencias habituales relativas a `transmute::<T, U>` también se aplican aquí.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Tenga en cuenta que la mayor parte de esta función se evaluará constantemente,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // maneje los ZST especialmente, que es-no los maneje en absoluto.
            return (self, &[], &[]);
        }

        // Primero, encuentre en qué punto dividimos entre la primera y la segunda porción.
        // Fácil con ptr.align_offset.
        let ptr = self.as_ptr();
        // SEGURIDAD: Consulte el método `align_to_mut` para obtener un comentario de seguridad detallado.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SEGURIDAD: ahora `rest` está definitivamente alineado, por lo que `from_raw_parts` a continuación está bien,
            // ya que la persona que llama garantiza que podemos transmutar `T` a `U` de forma segura.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmutar la rebanada en una rebanada de otro tipo, asegurando que se mantenga la alineación de los tipos.
    ///
    /// Este método divide el segmento en tres segmentos distintos: prefijo, segmento medio correctamente alineado de un nuevo tipo y segmento de sufijo.
    /// El método puede hacer que el segmento medio tenga la mayor longitud posible para un tipo y segmento de entrada determinados, pero solo el rendimiento de su algoritmo debería depender de eso, no de su exactitud.
    ///
    /// Se permite que todos los datos de entrada se devuelvan como prefijo o segmento de sufijo.
    ///
    /// Este método no tiene ningún propósito cuando el elemento de entrada `T` o el elemento de salida `U` son de tamaño cero y devolverán el segmento original sin dividir nada.
    ///
    /// # Safety
    ///
    /// Este método es esencialmente un `transmute` con respecto a los elementos del segmento medio devuelto, por lo que todas las advertencias habituales relativas a `transmute::<T, U>` también se aplican aquí.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Tenga en cuenta que la mayor parte de esta función se evaluará constantemente,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // maneje los ZST especialmente, que es-no los maneje en absoluto.
            return (self, &mut [], &mut []);
        }

        // Primero, encuentre en qué punto dividimos entre la primera y la segunda porción.
        // Fácil con ptr.align_offset.
        let ptr = self.as_ptr();
        // SEGURIDAD: Aquí nos aseguramos de que usaremos punteros alineados para U para el
        // resto del método.Esto se hace pasando un puntero a&[T] con una alineación dirigida a U.
        // `crate::ptr::align_offset` se llama con un puntero `ptr` correctamente alineado y válido (proviene de una referencia a `self`) y con un tamaño que es una potencia de dos (ya que proviene de la alineación para U), cumpliendo sus restricciones de seguridad.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // No podemos usar `rest` nuevamente después de esto, ¡eso invalidaría su alias `mut_ptr`!SEGURIDAD: consulte los comentarios para `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Comprueba si los elementos de este segmento están ordenados.
    ///
    /// Es decir, para cada elemento `a` y su siguiente elemento `b`, debe mantenerse `a <= b`.Si el segmento produce exactamente cero o un elemento, se devuelve `true`.
    ///
    /// Tenga en cuenta que si `Self::Item` es solo `PartialOrd`, pero no `Ord`, la definición anterior implica que esta función devuelve `false` si dos elementos consecutivos no son comparables.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Comprueba si los elementos de este segmento se ordenan utilizando la función de comparación dada.
    ///
    /// En lugar de usar `PartialOrd::partial_cmp`, esta función usa la función `compare` dada para determinar el orden de dos elementos.
    /// Aparte de eso, es equivalente a [`is_sorted`];consulte su documentación para obtener más información.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Comprueba si los elementos de este segmento se ordenan utilizando la función de extracción de claves dada.
    ///
    /// En lugar de comparar los elementos del segmento directamente, esta función compara las claves de los elementos, según lo determinado por `f`.
    /// Aparte de eso, es equivalente a [`is_sorted`];consulte su documentación para obtener más información.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Devuelve el índice del punto de partición según el predicado dado (el índice del primer elemento de la segunda partición).
    ///
    /// Se supone que el segmento está particionado de acuerdo con el predicado dado.
    /// Esto significa que todos los elementos para los que el predicado devuelve verdadero están al comienzo del segmento y todos los elementos para los que el predicado devuelve falso están al final.
    ///
    /// Por ejemplo, [7, 15, 3, 5, 4, 12, 6] está particionado bajo el predicado x% 2!=0 (todos los números impares están al principio, todos pares al final).
    ///
    /// Si este segmento no está particionado, el resultado devuelto no se especifica y no tiene sentido, ya que este método realiza una especie de búsqueda binaria.
    ///
    /// Consulte también [`binary_search`], [`binary_search_by`] y [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SEGURIDAD: Cuando `left < right`, `left <= mid < right`.
            // Por lo tanto, `left` siempre aumenta y `right` siempre disminuye, y se selecciona cualquiera de ellos.En ambos casos se cumple `left <= right`.Por lo tanto, si `left < right` en un paso, `left <= right` se satisface en el siguiente paso.
            //
            // Por lo tanto, siempre que `left != right`, `0 <= left < right <= len` se satisfaga y, si este caso, `0 <= mid < len` también se satisface.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Necesitamos cortarlos explícitamente a la misma longitud
        // para que al optimizador le resulte más fácil eludir la comprobación de límites.
        // Pero como no se puede confiar en él, también tenemos una especialización explícita para T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Crea una rebanada vacía.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Crea un segmento vacío mutable.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Patrones en cortes, actualmente, solo los usan `strip_prefix` y `strip_suffix`.
/// En un punto future, esperamos generalizar `core::str::Pattern` (que en el momento de escribir este artículo está limitado a `str`) a cortes, y luego este trait será reemplazado o abolido.
///
pub trait SlicePattern {
    /// El tipo de elemento del segmento con el que se hace coincidir.
    type Item;

    /// Actualmente, los consumidores de `SlicePattern` necesitan una porción.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}