//! Clasificación de rebanadas
//!
//! Este módulo contiene un algoritmo de clasificación basado en el ordenamiento rápido que derrota patrones de Orson Peters, publicado en: <https://github.com/orlp/pdqsort>
//!
//!
//! La ordenación inestable es compatible con libcore porque no asigna memoria, a diferencia de nuestra implementación de ordenación estable.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Cuando se suelta, copia de `src` a `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SEGURIDAD: Esta es una clase de ayuda.
        //          Consulte su uso para conocer la corrección.
        //          Es decir, uno debe asegurarse de que `src` y `dst` no se superpongan como lo requiere `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Desplaza el primer elemento hacia la derecha hasta que encuentra un elemento mayor o igual.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SEGURIDAD: Las operaciones inseguras a continuación implican la indexación sin una verificación limitada (`get_unchecked` y `get_unchecked_mut`)
    // y copiando la memoria (`ptr::copy_nonoverlapping`).
    //
    // una.Indexación:
    //  1. Verificamos el tamaño de la matriz a>=2.
    //  2. Toda la indexación que haremos será siempre entre {0 <= index < len} como máximo.
    //
    // B.Copia de memoria
    //  1. Estamos obteniendo indicadores de referencias cuya validez está garantizada.
    //  2. No pueden superponerse porque obtenemos punteros a índices de diferencia del corte.
    //     A saber, `i` y `i-1`.
    //  3. Si el corte está alineado correctamente, los elementos están alineados correctamente.
    //     Es responsabilidad de la persona que llama asegurarse de que el corte esté correctamente alineado.
    //
    // Consulte los comentarios a continuación para obtener más detalles.
    unsafe {
        // Si los dos primeros elementos están fuera de servicio ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Lea el primer elemento en una variable asignada a la pila.
            // Si se realiza una siguiente operación de comparación panics, `hole` se eliminará y automáticamente volverá a escribir el elemento en el segmento.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Mueva el elemento `i`-ésimo un lugar a la izquierda, desplazando así el agujero hacia la derecha.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` se deja caer y, por lo tanto, copia `tmp` en el orificio restante en `v`.
        }
    }
}

/// Desplaza el último elemento a la izquierda hasta que encuentra un elemento más pequeño o igual.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SEGURIDAD: Las operaciones inseguras a continuación implican la indexación sin una verificación limitada (`get_unchecked` y `get_unchecked_mut`)
    // y copiando la memoria (`ptr::copy_nonoverlapping`).
    //
    // una.Indexación:
    //  1. Verificamos el tamaño de la matriz a>=2.
    //  2. Toda la indexación que haremos será siempre entre `0 <= index < len-1` como máximo.
    //
    // B.Copia de memoria
    //  1. Estamos obteniendo indicadores de referencias cuya validez está garantizada.
    //  2. No pueden superponerse porque obtenemos punteros a índices de diferencia del corte.
    //     A saber, `i` y `i+1`.
    //  3. Si el corte está alineado correctamente, los elementos están alineados correctamente.
    //     Es responsabilidad de la persona que llama asegurarse de que el corte esté correctamente alineado.
    //
    // Consulte los comentarios a continuación para obtener más detalles.
    unsafe {
        // Si los dos últimos elementos están fuera de servicio ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Lea el último elemento en una variable asignada a la pila.
            // Si se realiza una siguiente operación de comparación panics, `hole` se eliminará y automáticamente volverá a escribir el elemento en el segmento.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Mueva el elemento `i`-ésimo un lugar a la derecha, desplazando así el agujero hacia la izquierda.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` se deja caer y, por lo tanto, copia `tmp` en el orificio restante en `v`.
        }
    }
}

/// Ordena parcialmente un segmento cambiando varios elementos desordenados.
///
/// Devuelve `true` si el sector se ordena al final.Esta función es *O*(*n*) en el peor de los casos.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Número máximo de pares adyacentes fuera de orden que se desplazarán.
    const MAX_STEPS: usize = 5;
    // Si el corte es más corto que esto, no mueva ningún elemento.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SEGURIDAD: Ya hicimos explícitamente la comprobación de límites con `i < len`.
        // Toda nuestra indexación posterior está solo en el rango `0 <= index < len`
        unsafe {
            // Encuentre el siguiente par de elementos adyacentes desordenados.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // ¿Terminamos?
        if i == len {
            return true;
        }

        // No cambie elementos en arreglos cortos, eso tiene un costo de rendimiento.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Intercambia el par de elementos encontrados.Esto los pone en el orden correcto.
        v.swap(i - 1, i);

        // Mueva el elemento más pequeño a la izquierda.
        shift_tail(&mut v[..i], is_less);
        // Mueva el elemento mayor a la derecha.
        shift_head(&mut v[i..], is_less);
    }

    // No logré ordenar el corte en el número limitado de pasos.
    false
}

/// Ordena un sector mediante la ordenación por inserción, que es *O*(*n*^ 2) en el peor de los casos.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Ordena `v` usando heapsort, que garantiza *O*(*n*\*log(* n*)) en el peor de los casos.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Este montón binario respeta el invariante `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Hijos de `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Elige al niño mayor.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Deténgase si el invariante se mantiene en `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Cambie `node` por el niño mayor, baje un escalón y continúe tamizando.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Construye el montón en tiempo lineal.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Saque los elementos máximos del montón.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Divide `v` en elementos más pequeños que `pivot`, seguidos de elementos mayores o iguales a `pivot`.
///
///
/// Devuelve el número de elementos menores que `pivot`.
///
/// El particionamiento se realiza bloque por bloque para minimizar el costo de las operaciones de ramificación.
/// Esta idea se presenta en el documento [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Número de elementos en un bloque típico.
    const BLOCK: usize = 128;

    // El algoritmo de partición repite los siguientes pasos hasta su finalización:
    //
    // 1. Trace un bloque desde el lado izquierdo para identificar elementos mayores o iguales al pivote.
    // 2. Trace un bloque desde el lado derecho para identificar elementos más pequeños que el pivote.
    // 3. Intercambia los elementos identificados entre el lado izquierdo y derecho.
    //
    // Mantenemos las siguientes variables para un bloque de elementos:
    //
    // 1. `block` - Número de elementos del bloque.
    // 2. `start` - Inicie el puntero en la matriz `offsets`.
    // 3. `end` - Puntero final en la matriz `offsets`.
    // 4. `compensaciones, índices de elementos fuera de orden dentro del bloque.

    // El bloque actual en el lado izquierdo (de `l` a `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // El bloque actual en el lado derecho (de `r.sub(block_r)` to `r`).
    // SEGURIDAD: La documentación para .add() menciona específicamente que `vec.as_ptr().add(vec.len())` siempre es seguro`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Cuando obtengamos VLA, intente crear una matriz de longitud `min(v.len(), 2 * BLOCK) `en lugar de
    // que dos matrices de tamaño fijo de longitud `BLOCK`.Los VLA pueden ser más eficientes en caché.

    // Devuelve el número de elementos entre los punteros `l` (inclusive) y `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Terminamos con la partición bloque a bloque cuando `l` y `r` se acercan mucho.
        // Luego hacemos un trabajo de parcheo para dividir los elementos restantes en el medio.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Número de elementos restantes (aún sin comparar con el pivote).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Ajuste los tamaños de los bloques para que los bloques izquierdo y derecho no se superpongan, sino que se alineen perfectamente para cubrir todo el espacio restante.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Trace los elementos `block_l` desde el lado izquierdo.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SEGURIDAD: Las siguientes operaciones de inseguridad implican el uso del `offset`.
                //         Según las condiciones requeridas por la función, las satisfacemos porque:
                //         1. `offsets_l` se asigna en la pila y, por lo tanto, se considera un objeto asignado separado.
                //         2. La función `is_less` devuelve un `bool`.
                //            Lanzar un `bool` nunca desbordará `isize`.
                //         3. Hemos garantizado que `block_l` será `<= BLOCK`.
                //            Además, `end_l` se estableció inicialmente en el puntero de inicio de `offsets_` que se declaró en la pila.
                //            Por lo tanto, sabemos que incluso en el peor de los casos (todas las invocaciones de `is_less` devuelven falsas) solo seremos como máximo 1 byte para pasar el final.
                //        Otra operación insegura aquí es eliminar la referencia a `elem`.
                //        Sin embargo, `elem` fue inicialmente el puntero de inicio al segmento que siempre es válido.
                unsafe {
                    // Comparación sin ramas.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Trace los elementos `block_r` desde el lado derecho.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SEGURIDAD: Las siguientes operaciones de inseguridad implican el uso del `offset`.
                //         Según las condiciones requeridas por la función, las satisfacemos porque:
                //         1. `offsets_r` se asigna en la pila y, por lo tanto, se considera un objeto asignado separado.
                //         2. La función `is_less` devuelve un `bool`.
                //            Lanzar un `bool` nunca desbordará `isize`.
                //         3. Hemos garantizado que `block_r` será `<= BLOCK`.
                //            Además, `end_r` se estableció inicialmente en el puntero de inicio de `offsets_` que se declaró en la pila.
                //            Por lo tanto, sabemos que incluso en el peor de los casos (todas las invocaciones de `is_less` devuelven verdaderas) solo seremos como máximo 1 byte al final.
                //        Otra operación insegura aquí es eliminar la referencia a `elem`.
                //        Sin embargo, `elem` fue inicialmente `1 *sizeof(T)` más allá del final y lo disminuimos en `1* sizeof(T)` antes de acceder a él.
                //        Además, se afirmó que `block_r` era menor que `BLOCK` y, por lo tanto, `elem` como mucho apuntará al comienzo del segmento.
                unsafe {
                    // Comparación sin ramas.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Número de elementos desordenados para intercambiar entre el lado izquierdo y el derecho.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // En lugar de intercambiar un par a la vez, es más eficiente realizar una permutación cíclica.
            // Esto no es estrictamente equivalente al intercambio, pero produce un resultado similar utilizando menos operaciones de memoria.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Se movieron todos los elementos fuera de orden en el bloque de la izquierda.Pasar al siguiente bloque.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Se movieron todos los elementos fuera de orden en el bloque de la derecha.Pasar al bloque anterior.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Todo lo que queda ahora es como máximo un bloque (ya sea a la izquierda o a la derecha) con elementos desordenados que deben moverse.
    // Dichos elementos restantes se pueden desplazar simplemente al final dentro de su bloque.
    //

    if start_l < end_l {
        // El bloque de la izquierda permanece.
        // Mueva los elementos restantes fuera de orden al extremo derecho.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Queda el bloque de la derecha.
        // Mueva los elementos restantes fuera de orden al extremo izquierdo.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nada más que hacer, hemos terminado.
        width(v.as_mut_ptr(), l)
    }
}

/// Divide `v` en elementos más pequeños que `v[pivot]`, seguidos de elementos mayores o iguales a `v[pivot]`.
///
///
/// Devuelve una tupla de:
///
/// 1. Número de elementos menores que `v[pivot]`.
/// 2. Verdadero si `v` ya estaba particionado.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Coloque el pivote al comienzo de la rebanada.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Lea el pivote en una variable asignada a la pila para mayor eficiencia.
        // Si se realiza una siguiente operación de comparación panics, el pivote se volverá a escribir automáticamente en el segmento.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Encuentre el primer par de elementos desordenados.
        let mut l = 0;
        let mut r = v.len();

        // SEGURIDAD: La siguiente inseguridad implica indexar una matriz.
        // Para el primero: ya verificamos los límites aquí con `l < r`.
        // Para el segundo: inicialmente tenemos `l == 0` y `r == v.len()` y verificamos que `l < r` en cada operación de indexación.
        //                     Desde aquí sabemos que `r` debe ser al menos `r == l`, que se demostró que es válido desde el primero.
        unsafe {
            // Encuentre el primer elemento mayor o igual que el pivote.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Encuentra el último elemento más pequeño que el pivote.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` sale del alcance y escribe el pivote (que es una variable asignada a la pila) de nuevo en el segmento donde estaba originalmente.
        // ¡Este paso es fundamental para garantizar la seguridad!
        //
    };

    // Coloque el pivote entre las dos particiones.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Divide `v` en elementos iguales a `v[pivot]` seguidos de elementos mayores que `v[pivot]`.
///
/// Devuelve el número de elementos igual al pivote.
/// Se supone que `v` no contiene elementos más pequeños que el pivote.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Coloque el pivote al comienzo de la rebanada.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Lea el pivote en una variable asignada a la pila para mayor eficiencia.
    // Si se realiza una siguiente operación de comparación panics, el pivote se volverá a escribir automáticamente en el segmento.
    // SEGURIDAD: El puntero aquí es válido porque se obtiene de una referencia a un segmento.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Ahora particione la rebanada.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SEGURIDAD: La siguiente inseguridad implica indexar una matriz.
        // Para el primero: ya verificamos los límites aquí con `l < r`.
        // Para el segundo: inicialmente tenemos `l == 0` y `r == v.len()` y verificamos que `l < r` en cada operación de indexación.
        //                     Desde aquí sabemos que `r` debe ser al menos `r == l`, que se demostró que es válido desde el primero.
        unsafe {
            // Encuentra el primer elemento mayor que el pivote.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Encuentra el último elemento igual al pivote.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // ¿Terminamos?
            if l >= r {
                break;
            }

            // Cambie el par encontrado de elementos fuera de orden.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Encontramos elementos `l` iguales al pivote.Agregue 1 para tener en cuenta el pivote en sí.
    l + 1

    // `_pivot_guard` sale del alcance y escribe el pivote (que es una variable asignada a la pila) de nuevo en el segmento donde estaba originalmente.
    // ¡Este paso es fundamental para garantizar la seguridad!
}

/// Dispersa algunos elementos en un intento de romper los patrones que podrían causar particiones desequilibradas en el ordenamiento rápido.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Generador de números pseudoaleatorios del artículo "Xorshift RNGs" de George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Tome números aleatorios módulo este número.
        // El número encaja en `usize` porque `len` no es mayor que `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Algunos candidatos pivote estarán cerca de este índice.Distribuyémoslos al azar.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Genere un número aleatorio módulo `len`.
            // Sin embargo, para evitar operaciones costosas, primero lo tomamos módulo una potencia de dos, y luego lo disminuimos en `len` hasta que encaje en el rango `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` se garantiza que sea inferior a `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Elige un pivote en `v` y devuelve el índice y `true` si es probable que el segmento ya esté ordenado.
///
/// Los elementos de `v` pueden reordenarse en el proceso.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Longitud mínima para elegir el método de la mediana de las medianas.
    // Las porciones más cortas utilizan el método simple de mediana de tres.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Número máximo de intercambios que se pueden realizar en esta función.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tres índices cerca de los cuales vamos a elegir un pivote.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Cuenta el número total de intercambios que estamos a punto de realizar mientras clasificamos índices.
    let mut swaps = 0;

    if len >= 8 {
        // Intercambia índices para que `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Intercambia índices para que `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Encuentra la mediana de `v[a - 1], v[a], v[a + 1]` y almacena el índice en `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Encuentre medianas en las cercanías de `a`, `b` y `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Encuentre la mediana entre `a`, `b` y `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Se realizó el número máximo de swaps.
        // Lo más probable es que el corte sea descendente o en su mayor parte descendente, por lo que invertir probablemente ayudará a clasificarlo más rápido.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Ordena `v` de forma recursiva.
///
/// Si el segmento tenía un predecesor en la matriz original, se especifica como `pred`.
///
/// `limit` es el número de particiones desequilibradas permitidas antes de cambiar a `heapsort`.
/// Si es cero, esta función cambiará inmediatamente a heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Los cortes de hasta esta longitud se ordenan mediante la ordenación por inserción.
    const MAX_INSERTION: usize = 20;

    // Verdadero si la última partición estuvo razonablemente equilibrada.
    let mut was_balanced = true;
    // Verdadero si la última partición no mezcló elementos (el segmento ya estaba particionado).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Los cortes muy cortos se ordenan mediante la ordenación por inserción.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Si se tomaron demasiadas decisiones de pivote incorrectas, simplemente recurra al heapsort para garantizar el peor de los casos de `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Si la última partición estaba desequilibrada, intente romper los patrones en el segmento mezclando algunos elementos.
        // Con suerte, esta vez elegiremos un pivote mejor.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Elija un pivote e intente adivinar si el sector ya está ordenado.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Si la última partición se equilibró decentemente y no barajó los elementos, y si la selección dinámica predice que es probable que el segmento ya esté ordenado ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Intente identificar varios elementos fuera de orden y colóquelos en las posiciones correctas.
            // Si la rebanada termina completamente ordenada, hemos terminado.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Si el pivote elegido es igual al predecesor, entonces es el elemento más pequeño del segmento.
        // Divida el sector en elementos iguales y mayores que el pivote.
        // Este caso suele darse cuando el sector contiene muchos elementos duplicados.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Continúe ordenando elementos mayores que el pivote.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Divida la rebanada.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Divida la porción en `left`, `pivot` y `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Recurra al lado más corto solo para minimizar el número total de llamadas recursivas y consumir menos espacio en la pila.
        // Luego simplemente continúe con el lado más largo (esto es similar a la recursividad de la cola).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Ordena `v` utilizando una ordenación rápida que anula los patrones, que es *O*(*n*\*log(* n*)) en el peor de los casos.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // La clasificación no tiene un comportamiento significativo en tipos de tamaño cero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Limite el número de particiones desequilibradas a `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Para cortes de hasta esta longitud, probablemente sea más rápido simplemente ordenarlos.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Elige un pivote
        let (pivot, _) = choose_pivot(v, is_less);

        // Si el pivote elegido es igual al predecesor, entonces es el elemento más pequeño del segmento.
        // Divida el sector en elementos iguales y mayores que el pivote.
        // Este caso suele darse cuando el sector contiene muchos elementos duplicados.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Si pasamos nuestro índice, entonces estamos bien.
                if mid > index {
                    return;
                }

                // De lo contrario, continúe ordenando elementos mayores que el pivote.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Divida la porción en `left`, `pivot` y `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Si mid==index, entonces hemos terminado, ya que partition() garantiza que todos los elementos después de mid son mayores o iguales a mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // La clasificación no tiene un comportamiento significativo en tipos de tamaño cero.Hacer nada.
    } else if index == v.len() - 1 {
        // Encuentre el elemento máximo y colóquelo en la última posición de la matriz.
        // Somos libres de usar `unwrap()` aquí porque sabemos que v no debe estar vacío.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Encuentra el elemento min y colócalo en la primera posición de la matriz.
        // Somos libres de usar `unwrap()` aquí porque sabemos que v no debe estar vacío.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}