// Implementación original tomada de rust-memchr.
// Copyright 2015 Andrew Gallant, bluss y Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Utilice truncamiento.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Devuelve `true` si `x` contiene un byte cero.
///
/// De *Matters Computational*, J. Arndt:
///
/// "La idea es restar uno de cada uno de los bytes y luego buscar bytes donde el préstamo se propagó hasta el más significativo
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Devuelve el primer índice que coincide con el byte `x` en `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Camino rápido para rodajas pequeñas
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Busque un valor de un solo byte leyendo dos palabras `usize` a la vez.
    //
    // Dividir `text` en tres partes
    // - parte inicial no alineada, antes de la primera palabra dirección alineada en el texto
    // - cuerpo, escanee 2 palabras a la vez
    // - la última parte restante, tamaño <2 palabras

    // buscar hasta un límite alineado
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // buscar el cuerpo del texto
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SEGURIDAD: el predicado while garantiza una distancia de al menos 2 * usize_bytes
        // entre el desplazamiento y el final del corte.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // romper si hay un byte coincidente
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Encuentre el byte después del punto en el que se detuvo el bucle del cuerpo.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Devuelve el último índice que coincide con el byte `x` en `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Busque un valor de un solo byte leyendo dos palabras `usize` a la vez.
    //
    // Divida `text` en tres partes:
    // - cola no alineada, después de la última palabra alineada en el texto,
    // - cuerpo, escaneado por 2 palabras a la vez,
    // - los primeros bytes restantes, tamaño de <2 palabras.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Llamamos a esto solo para obtener la longitud del prefijo y el sufijo.
        // En el medio siempre procesamos dos trozos a la vez.
        // SEGURIDAD: la transmutación de `[u8]` a `[usize]` es segura, excepto por las diferencias de tamaño que maneja `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Busque en el cuerpo del texto, asegúrese de no cruzar min_aligned_offset.
    // El desplazamiento siempre está alineado, por lo que solo probar `>` es suficiente y evita un posible desbordamiento.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SEGURIDAD: el desplazamiento comienza en len, suffix.len(), siempre que sea mayor que
        // min_aligned_offset (prefix.len()) la distancia restante es de al menos 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Romper si hay un byte coincidente.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Encuentre el byte antes del punto en el que se detuvo el bucle del cuerpo.
    text[..offset].iter().rposition(|elt| *elt == x)
}