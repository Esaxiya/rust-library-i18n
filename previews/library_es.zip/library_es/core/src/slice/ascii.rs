//! Operaciones en ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Comprueba si todos los bytes de este segmento están dentro del rango ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Comprueba que dos sectores sean una coincidencia que no distinga entre mayúsculas y minúsculas en ASCII.
    ///
    /// Igual que `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, pero sin asignar ni copiar temporales.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Convierte este segmento a su equivalente en mayúsculas ASCII in situ.
    ///
    /// Las letras ASCII 'a' a 'z' se asignan a 'A' a 'Z', pero las letras que no son ASCII no se modifican.
    ///
    /// Para devolver un nuevo valor en mayúsculas sin modificar el existente, use [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Convierte este segmento a su equivalente en minúsculas ASCII in situ.
    ///
    /// Las letras ASCII 'A' a 'Z' se asignan a 'a' a 'z', pero las letras que no son ASCII no se modifican.
    ///
    /// Para devolver un nuevo valor en minúsculas sin modificar el existente, use [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Devuelve `true` si algún byte de la palabra `v` no es ascii (>=128).
/// Snarfed de `../str/mod.rs`, que hace algo similar para la validación de utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Prueba ASCII optimizada que utilizará operaciones usize-at-a-time en lugar de operaciones byte-at-a-time (cuando sea posible).
///
/// El algoritmo que usamos aquí es bastante simple.Si `s` es demasiado corto, simplemente verificamos cada byte y terminamos con él.De lo contrario:
///
/// - Lea la primera palabra con una carga no alineada.
/// - Alinee el puntero, lea las palabras siguientes hasta el final con cargas alineadas.
/// - Lea el último `usize` de `s` con una carga no alineada.
///
/// Si alguna de estas cargas produce algo para lo que `contains_nonascii` (above) devuelve verdadero, entonces sabemos que la respuesta es falsa.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Si no obtendríamos nada de la implementación palabra a la vez, recurra a un bucle escalar.
    //
    // También hacemos esto para arquitecturas donde `size_of::<usize>()` no es suficiente alineación para `usize`, porque es un caso extraño de edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Siempre leemos la primera palabra sin alinear, lo que significa que `align_offset` es
    // 0, volveríamos a leer el mismo valor para la lectura alineada.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SEGURIDAD: Verificamos `len < USIZE_SIZE` arriba.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Verificamos esto arriba, algo implícitamente.
    // Tenga en cuenta que `offset_to_aligned` es `align_offset` o `USIZE_SIZE`, ambos están marcados explícitamente arriba.
    //
    debug_assert!(offset_to_aligned <= len);

    // SEGURIDAD: word_ptr es el ptr usize (correctamente alineado) que usamos para leer el
    // trozo medio de la rebanada.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` es el índice de bytes de `word_ptr`, utilizado para comprobaciones de final de ciclo.
    let mut byte_pos = offset_to_aligned;

    // La paranoia comprueba la alineación, ya que estamos a punto de hacer un montón de cargas no alineadas.
    // Sin embargo, en la práctica, esto debería ser imposible salvo un error en `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Lea las palabras subsiguientes hasta la última palabra alineada, excluyendo la última palabra alineada por sí misma para realizar la verificación de cola más adelante, para asegurarse de que la cola sea siempre una `usize` como máximo para branch `byte_pos == len` adicional.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Comprobación de cordura que la lectura esté dentro de los límites
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Y que nuestras suposiciones sobre `byte_pos` se mantienen.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SEGURIDAD: Sabemos que `word_ptr` está correctamente alineado (debido a
        // `align_offset`), y sabemos que tenemos suficientes bytes entre `word_ptr` y el final
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SEGURIDAD: Sabemos que `byte_pos <= len - USIZE_SIZE`, lo que significa que
        // después de este `add`, `word_ptr` será como mucho uno más allá del final.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Verifique la cordura para asegurarse de que realmente solo queda un `usize`.
    // Esto debería estar garantizado por nuestra condición de bucle.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SEGURIDAD: Esto se basa en `len >= USIZE_SIZE`, que verificamos al principio.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}