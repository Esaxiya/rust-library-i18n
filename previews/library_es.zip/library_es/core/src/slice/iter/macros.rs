//! Macros utilizadas por iteradores de sector.

// La inserción de is_empty y len marca una gran diferencia de rendimiento
macro_rules! is_empty {
    // La forma en que codificamos la longitud de un iterador ZST funciona tanto para ZST como para no ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Para deshacernos de algunas comprobaciones de límites (ver `position`), calculamos la longitud de una manera algo inesperada.
// (Probado por `codegen/slice-position-limits-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // a veces nos utilizan dentro de un bloque inseguro

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Este _cannot_ usa `unchecked_sub` porque dependemos de la envoltura para representar la longitud de los iteradores de corte ZST largos.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Sabemos que `start <= end`, por lo que puede hacerlo mejor que `offset_from`, que debe negociarse firmado.
            // Al establecer las banderas apropiadas aquí, podemos decirle a LLVM esto, lo que lo ayuda a eliminar las comprobaciones de límites.
            // SEGURIDAD: Por el tipo invariante, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Al decirle también a LLVM que los punteros están separados por un múltiplo exacto del tamaño de la letra, puede optimizar `len() == 0` hasta `start == end` en lugar de `(end - start) < size`.
            //
            // SEGURIDAD: Por el tipo invariante, los punteros están alineados
            //         la distancia entre ellos debe ser un múltiplo del tamaño de la punta
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// La definición compartida de los iteradores `Iter` y `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Devuelve el primer elemento y mueve el inicio del iterador hacia adelante en 1.
        // Mejora enormemente el rendimiento en comparación con una función en línea.
        // El iterador no debe estar vacío.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Devuelve el último elemento y mueve el final del iterador hacia atrás en 1.
        // Mejora enormemente el rendimiento en comparación con una función en línea.
        // El iterador no debe estar vacío.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Reduce el iterador cuando T es un ZST, moviendo el final del iterador hacia atrás `n`.
        // `n` no debe exceder `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Función auxiliar para crear un segmento a partir del iterador.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SEGURIDAD: el iterador se creó a partir de un segmento con puntero
                // `self.ptr` y longitud `len!(self)`.
                // Esto garantiza que se cumplan todos los requisitos previos para `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Función auxiliar para mover el inicio del iterador hacia adelante por elementos `offset`, devolviendo el inicio anterior.
            //
            // Inseguro porque el desplazamiento no debe exceder `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SEGURIDAD: la persona que llama garantiza que `offset` no supera `self.len()`,
                    // por lo que este nuevo puntero está dentro de `self` y, por lo tanto, se garantiza que no es nulo.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Función auxiliar para mover el final del iterador hacia atrás por elementos `offset`, devolviendo el nuevo final.
            //
            // Inseguro porque el desplazamiento no debe exceder `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SEGURIDAD: la persona que llama garantiza que `offset` no supera `self.len()`,
                    // que está garantizado para no desbordar un `isize`.
                    // Además, el puntero resultante está dentro de los límites de `slice`, lo que cumple con los demás requisitos de `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // podría implementarse con porciones, pero esto evita verificaciones de límites

                // SEGURIDAD: las llamadas `assume` son seguras desde el puntero de inicio de un segmento
                // debe ser no nulo, y los sectores que no sean ZST también deben tener un puntero final no nulo.
                // La llamada a `next_unchecked!` es segura ya que primero verificamos si el iterador está vacío.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Este iterador ahora está vacío.
                    if mem::size_of::<T>() == 0 {
                        // Tenemos que hacerlo de esta manera ya que `ptr` puede que nunca sea 0, pero `end` podría serlo (debido al ajuste).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SEGURIDAD: end no puede ser 0 si T no es ZST porque ptr no es 0 y end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SEGURIDAD: Estamos dentro de los límites.`post_inc_start` hace lo correcto incluso para ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Anulamos la implementación predeterminada, que usa `try_fold`, porque esta implementación simple genera menos LLVM IR y es más rápida de compilar.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Anulamos la implementación predeterminada, que usa `try_fold`, porque esta implementación simple genera menos LLVM IR y es más rápida de compilar.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Anulamos la implementación predeterminada, que usa `try_fold`, porque esta implementación simple genera menos LLVM IR y es más rápida de compilar.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Anulamos la implementación predeterminada, que usa `try_fold`, porque esta implementación simple genera menos LLVM IR y es más rápida de compilar.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Anulamos la implementación predeterminada, que usa `try_fold`, porque esta implementación simple genera menos LLVM IR y es más rápida de compilar.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Anulamos la implementación predeterminada, que usa `try_fold`, porque esta implementación simple genera menos LLVM IR y es más rápida de compilar.
            // Además, el `assume` evita una verificación de límites.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SEGURIDAD: estamos garantizados para estar dentro de los límites del ciclo invariante:
                        // cuando `i >= n`, `self.next()` devuelve `None` y el bucle se rompe.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Anulamos la implementación predeterminada, que usa `try_fold`, porque esta implementación simple genera menos LLVM IR y es más rápida de compilar.
            // Además, el `assume` evita una verificación de límites.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SEGURIDAD: `i` debe ser menor que `n` ya que comienza en `n`
                        // y solo está disminuyendo.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SEGURIDAD: la persona que llama debe garantizar que `i` está dentro de los límites
                // el segmento subyacente, por lo que `i` no puede desbordar un `isize`, y se garantiza que las referencias devueltas se refieren a un elemento del segmento y, por lo tanto, se garantiza su validez.
                //
                // También tenga en cuenta que la persona que llama también garantiza que nunca se nos volverá a llamar con el mismo índice y que no se llamará a ningún otro método que acceda a este sublicio, por lo que es válido que la referencia devuelta sea mutable en el caso de
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // podría implementarse con porciones, pero esto evita verificaciones de límites

                // SEGURIDAD: las llamadas `assume` son seguras ya que el puntero de inicio de un segmento no debe ser nulo,
                // y los sectores que no sean ZST también deben tener un puntero final que no sea nulo.
                // La llamada a `next_back_unchecked!` es segura ya que primero verificamos si el iterador está vacío.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Este iterador ahora está vacío.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SEGURIDAD: Estamos dentro de los límites.`pre_dec_end` hace lo correcto incluso para ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}