//! Funciones gratuitas para crear `&[T]` y `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Forma un corte a partir de un puntero y una longitud.
///
/// El argumento `len` es el número de **elementos**, no el número de bytes.
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * `data` debe ser [valid] para lecturas de `len * mem::size_of::<T>()` muchos bytes, y debe estar alineado correctamente.Esto significa en particular:
///
///     * ¡Todo el rango de memoria de este segmento debe estar contenido en un solo objeto asignado!
///       Los sectores nunca pueden abarcar varios objetos asignados.Consulte [below](#incorrect-usage) para ver un ejemplo incorrecto sin tener esto en cuenta.
///     * `data` debe ser no nulo y alineado incluso para cortes de longitud cero.
///     Una razón de esto es que las optimizaciones de diseño de enumeración pueden depender de que las referencias (incluidas las secciones de cualquier longitud) estén alineadas y no sean nulas para distinguirlas de otros datos.
///     Puede obtener un puntero que se puede utilizar como `data` para cortes de longitud cero utilizando [`NonNull::dangling()`].
///
/// * `data` debe apuntar a `len` valores consecutivos correctamente inicializados de tipo `T`.
///
/// * La memoria a la que hace referencia el segmento devuelto no debe mutarse durante el tiempo de vida `'a`, excepto dentro de un `UnsafeCell`.
///
/// * El tamaño total `len * mem::size_of::<T>()` del corte no debe ser mayor que `isize::MAX`.
///   Consulte la documentación de seguridad de [`pointer::offset`].
///
/// # Caveat
///
/// La vida útil del segmento devuelto se infiere de su uso.
/// Para evitar un uso indebido accidental, se sugiere vincular la vida útil a la vida útil de la fuente que sea segura en el contexto, como proporcionar una función auxiliar que tome la vida útil de un valor de host para el segmento, o mediante una anotación explícita.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestar un corte para un solo elemento
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Uso incorrecto
///
/// La siguiente función `join_slices` es **incorrecta** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // La afirmación anterior garantiza que `fst` y `snd` sean contiguos, pero es posible que aún estén contenidos dentro de _different allocated objects_, en cuyo caso la creación de este segmento es un comportamiento indefinido.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` y `b` son objetos asignados diferentes ...
///     let a = 42;
///     let b = 27;
///     // ... que, no obstante, se puede disponer de forma contigua en la memoria: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Realiza la misma funcionalidad que [`from_raw_parts`], excepto que se devuelve un segmento mutable.
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * `data` debe ser [valid] para lecturas y escrituras para `len * mem::size_of::<T>()` muchos bytes, y debe estar alineado correctamente.Esto significa en particular:
///
///     * ¡Todo el rango de memoria de este segmento debe estar contenido en un solo objeto asignado!
///       Los sectores nunca pueden abarcar varios objetos asignados.
///     * `data` debe ser no nulo y alineado incluso para cortes de longitud cero.
///     Una razón de esto es que las optimizaciones de diseño de enumeración pueden depender de que las referencias (incluidas las secciones de cualquier longitud) estén alineadas y no sean nulas para distinguirlas de otros datos.
///
///     Puede obtener un puntero que se puede utilizar como `data` para cortes de longitud cero utilizando [`NonNull::dangling()`].
///
/// * `data` debe apuntar a `len` valores consecutivos correctamente inicializados de tipo `T`.
///
/// * No se debe acceder a la memoria a la que hace referencia el segmento devuelto a través de ningún otro puntero (que no se derive del valor de retorno) durante el tiempo de vida `'a`.
///   Están prohibidos los accesos tanto de lectura como de escritura.
///
/// * El tamaño total `len * mem::size_of::<T>()` del corte no debe ser mayor que `isize::MAX`.
///   Consulte la documentación de seguridad de [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Convierte una referencia a T en un segmento de longitud 1 (sin copiar).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Convierte una referencia a T en un segmento de longitud 1 (sin copiar).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}