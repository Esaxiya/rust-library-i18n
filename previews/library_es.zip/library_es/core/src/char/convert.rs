//! Conversiones de personajes.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Convierte un `u32` en un `char`.
///
/// Tenga en cuenta que todos los [`char`] son válidos [`u32`] y se pueden convertir a uno con
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Sin embargo, lo contrario no es cierto: no todos los [`u32`] válidos son [`char`] válidos.
/// `from_u32()` devolverá `None` si la entrada no es un valor válido para un [`char`].
///
/// Para ver una versión insegura de esta función que ignora estas comprobaciones, consulte [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Devolver `None` cuando la entrada no es un [`char`] válido:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Convierte un `u32` en un `char`, ignorando la validez.
///
/// Tenga en cuenta que todos los [`char`] son válidos [`u32`] y se pueden convertir a uno con
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Sin embargo, lo contrario no es cierto: no todos los [`u32`] válidos son [`char`] válidos.
/// `from_u32_unchecked()` ignorará esto y emitirá ciegamente a [`char`], posiblemente creando uno no válido.
///
///
/// # Safety
///
/// Esta función no es segura, ya que puede generar valores `char` no válidos.
///
/// Para obtener una versión segura de esta función, consulte la función [`from_u32`].
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SEGURIDAD: la persona que llama debe garantizar que `i` es un valor de carácter válido.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Convierte un [`char`] en un [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Convierte un [`char`] en un [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // El carácter se convierte en el valor del punto de código, luego se extiende a cero a 64 bits.
        // Ver [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Convierte un [`char`] en un [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // El carácter se convierte en el valor del punto de código, luego se extiende a cero a 128 bits.
        // Ver [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Asigna un byte en 0x00 ..=0xFF a un `char` cuyo punto de código tiene el mismo valor, en U + 0000 ..=U + 00FF.
///
/// Unicode está diseñado de tal manera que decodifica de manera efectiva bytes con la codificación de caracteres que IANA llama ISO-8859-1.
/// Esta codificación es compatible con ASCII.
///
/// Tenga en cuenta que esto es diferente de ISO/IEC 8859-1 también conocido como
/// ISO 8859-1 (con un guión menos), que deja algunos "blanks", valores de bytes que no se asignan a ningún carácter.
/// ISO-8859-1 (el de IANA) los asigna a los códigos de control C0 y C1.
///
/// Tenga en cuenta que esto *también* es diferente de Windows-1252 también conocido como
/// página de códigos 1252, que es un superconjunto ISO/IEC 8859-1 que asigna algunos espacios en blanco (¡no todos!) a la puntuación y varios caracteres latinos.
///
/// Para confundir aún más las cosas, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` y `windows-1252` son todos alias de un superconjunto de Windows-1252 que llena los espacios en blanco restantes con los códigos de control correspondientes C0 y C1.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Convierte un [`u8`] en un [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Un error que se puede devolver al analizar un char.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SEGURIDAD: comprobado que es un valor unicode legal
            Ok(unsafe { transmute(i) })
        }
    }
}

/// El tipo de error devuelto cuando falla una conversión de u32 a char.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Convierte un dígito en la base dada en un `char`.
///
/// Un 'radix' aquí a veces también se llama 'base'.
/// Una base de dos indica un número binario, una base de diez, decimal, y una base de dieciséis, hexadecimal, para dar algunos valores comunes.
///
/// Se admiten radices arbitrarias.
///
/// `from_digit()` devolverá `None` si la entrada no es un dígito en la base dada.
///
/// # Panics
///
/// Panics si se le da una base mayor que 36.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // El decimal 11 es un solo dígito en base 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Devolver `None` cuando la entrada no es un dígito:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Pasar una raíz grande, provocando un panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}