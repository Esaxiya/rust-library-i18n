//! Contenedores mutables compartibles.
//!
//! La seguridad de la memoria Rust se basa en esta regla: Dado un objeto `T`, solo es posible tener uno de los siguientes:
//!
//! - Tener varias referencias (`&T`) inmutables al objeto (también conocido como **aliasing**).
//! - Tener una referencia mutable (`&mut T`) al objeto (también conocida como **mutabilidad**).
//!
//! Esto es reforzado por el compilador Rust.Sin embargo, hay situaciones en las que esta regla no es lo suficientemente flexible.A veces es necesario tener varias referencias a un objeto y, sin embargo, mutarlo.
//!
//! Existen contenedores mutables compartibles para permitir la mutabilidad de una manera controlada, incluso en presencia de aliasing.Tanto [`Cell<T>`] como [`RefCell<T>`] permiten hacer esto de una manera de un solo subproceso.
//! Sin embargo, ni `Cell<T>` ni `RefCell<T>` son seguros para subprocesos (no implementan [`Sync`]).
//! Si necesita hacer aliasing y mutación entre múltiples subprocesos, es posible usar los tipos [`Mutex<T>`], [`RwLock<T>`] o [`atomic`].
//!
//! Los valores de los tipos `Cell<T>` y `RefCell<T>` pueden mutarse a través de referencias compartidas (p. Ej.
//! el tipo común `&T`), mientras que la mayoría de los tipos Rust solo pueden mutarse a través de referencias únicas (`&mut T`).
//! Decimos que `Cell<T>` y `RefCell<T>` proporcionan 'mutabilidad interior', en contraste con los tipos típicos de Rust que exhiben 'mutabilidad heredada'.
//!
//! Los tipos de células vienen en dos sabores: `Cell<T>` y `RefCell<T>`.`Cell<T>` implementa la mutabilidad interior al mover valores dentro y fuera del `Cell<T>`.
//! Para usar referencias en lugar de valores, se debe usar el tipo `RefCell<T>`, adquiriendo un bloqueo de escritura antes de mutar.`Cell<T>` proporciona métodos para recuperar y cambiar el valor interior actual:
//!
//!  - Para los tipos que implementan [`Copy`], el método [`get`](Cell::get) recupera el valor interior actual.
//!  - Para los tipos que implementan [`Default`], el método [`take`](Cell::take) reemplaza el valor interior actual con [`Default::default()`] y devuelve el valor reemplazado.
//!  - Para todos los tipos, el método [`replace`](Cell::replace) reemplaza el valor interior actual y devuelve el valor reemplazado y el método [`into_inner`](Cell::into_inner) consume el `Cell<T>` y devuelve el valor interior.
//!  Además, el método [`set`](Cell::set) reemplaza el valor interior, eliminando el valor reemplazado.
//!
//! `RefCell<T>` utiliza la vida útil de Rust para implementar el "préstamo dinámico", un proceso mediante el cual uno puede reclamar acceso temporal, exclusivo y mutable al valor interno.
//! Préstamos para `RefCell<T>Los`s se rastrean 'en tiempo de ejecución', a diferencia de los tipos de referencia nativos de Rust que se rastrean completamente de forma estática, en tiempo de compilación.
//! Debido a que los préstamos de `RefCell<T>` son dinámicos, es posible intentar tomar prestado un valor que ya está prestado de manera mutante;cuando esto sucede, da como resultado el hilo panic.
//!
//! # Cuando elegir la mutabilidad interior
//!
//! La mutabilidad heredada más común, donde uno debe tener acceso único para mutar un valor, es uno de los elementos clave del lenguaje que le permite a Rust razonar fuertemente sobre el alias de puntero, evitando estáticamente fallas.
//! Por eso, se prefiere la mutabilidad heredada, y la mutabilidad interior es algo así como un último recurso.
//! Dado que los tipos de células permiten la mutación donde de otro modo no estaría permitida, hay ocasiones en las que la mutabilidad interior podría ser apropiada, o incluso *debe* usarse, p.
//!
//! * Presentamos la mutabilidad 'inside' de algo inmutable
//! * Detalles de implementación de métodos lógicamente inmutables.
//! * Implementaciones mutantes de [`Clone`].
//!
//! ## Presentamos la mutabilidad 'inside' de algo inmutable
//!
//! Muchos tipos de punteros inteligentes compartidos, incluidos [`Rc<T>`] y [`Arc<T>`], proporcionan contenedores que se pueden clonar y compartir entre varias partes.
//! Debido a que los valores contenidos pueden tener un alias múltiple, solo se pueden tomar prestados con `&`, no con `&mut`.
//! Sin celdas, sería imposible mutar los datos dentro de estos punteros inteligentes.
//!
//! Entonces, es muy común colocar un `RefCell<T>` dentro de tipos de punteros compartidos para reintroducir la mutabilidad:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Cree un nuevo bloque para limitar el alcance del préstamo dinámico
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Tenga en cuenta que si no hubiéramos dejado que el préstamo anterior del caché cayera fuera del alcance, el préstamo posterior provocaría un subproceso dinámico panic.
//!     //
//!     // Este es el mayor peligro de usar `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Tenga en cuenta que este ejemplo usa `Rc<T>` y no `Arc<T>`.`RefCell<T>`s son para escenarios de un solo subproceso.Considere usar [`RwLock<T>`] o [`Mutex<T>`] si necesita mutabilidad compartida en una situación de subprocesos múltiples.
//!
//! ## Detalles de implementación de métodos lógicamente inmutables
//!
//! Ocasionalmente, puede ser deseable no exponer en una API que se está produciendo una mutación "under the hood".
//! Esto puede deberse a que, lógicamente, la operación es inmutable, pero, por ejemplo, el almacenamiento en caché obliga a la implementación a realizar una mutación;o porque debe emplear la mutación para implementar un método trait que se definió originalmente para tomar `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Aquí van los costosos cálculos
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Implementaciones mutantes de `Clone`
//!
//! Este es simplemente un caso especial, pero común, de lo anterior: ocultar la mutabilidad para operaciones que parecen inmutables.
//! Se espera que el método [`clone`](Clone::clone) no cambie el valor fuente y se declara que toma `&self`, no `&mut self`.
//! Por lo tanto, cualquier mutación que ocurra en el método `clone` debe usar tipos de células.
//! Por ejemplo, [`Rc<T>`] mantiene sus recuentos de referencia dentro de un `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Una ubicación de memoria mutable.
///
/// # Examples
///
/// En este ejemplo, puede ver que `Cell<T>` habilita la mutación dentro de una estructura inmutable.
/// En otras palabras, habilita "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ERROR: `my_struct` es inmutable
/// // my_struct.regular_field =nuevo_valor;
///
/// // FUNCIONA: aunque `my_struct` es inmutable, `special_field` es un `Cell`,
/// // que siempre se puede mutar
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Consulte el [module-level documentation](self) para obtener más información.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Crea un `Cell<T>`, con el valor `Default` para T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Crea un nuevo `Cell` que contiene el valor dado.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Establece el valor contenido.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Intercambia los valores de dos celdas.
    /// La diferencia con `std::mem::swap` es que esta función no requiere la referencia `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SEGURIDAD: Esto puede ser arriesgado si se llama desde subprocesos separados, pero `Cell`
        // es `!Sync`, por lo que esto no sucederá.
        // Esto tampoco invalidará ningún puntero, ya que `Cell` se asegura de que nada más apunte a ninguno de estos `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Reemplaza el valor contenido por `val` y devuelve el valor contenido anterior.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SEGURIDAD: esto puede causar carreras de datos si se llama desde un hilo separado,
        // pero `Cell` es `!Sync`, por lo que esto no sucederá.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Desenvuelve el valor.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Devuelve una copia del valor contenido.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SEGURIDAD: esto puede causar carreras de datos si se llama desde un hilo separado,
        // pero `Cell` es `!Sync`, por lo que esto no sucederá.
        unsafe { *self.value.get() }
    }

    /// Actualiza el valor contenido mediante una función y devuelve el nuevo valor.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Devuelve un puntero sin procesar a los datos subyacentes en esta celda.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Devuelve una referencia mutable a los datos subyacentes.
    ///
    /// Esta llamada toma prestado `Cell` de forma mutante (en tiempo de compilación), lo que garantiza que poseemos la única referencia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Devuelve un `&Cell<T>` de un `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SEGURIDAD: `&mut` garantiza un acceso exclusivo.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Toma el valor de la celda, dejando `Default::default()` en su lugar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Devuelve un `&[Cell<T>]` de un `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SEGURIDAD: `Cell<T>` tiene el mismo diseño de memoria que `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Una ubicación de memoria mutable con reglas de préstamo comprobadas dinámicamente
///
/// Consulte el [module-level documentation](self) para obtener más información.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Un error devuelto por [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Un error devuelto por [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Los valores positivos representan el número de `Ref` activos.Los valores negativos representan el número de `RefMut` activos.
// Múltiples `RefMut`s solo pueden estar activos a la vez si se refieren a componentes distintos y no superpuestos de un `RefCell` (por ejemplo, diferentes rangos de un segmento).
//
// `Ref` y `RefMut` tienen dos palabras en tamaño, por lo que es probable que nunca existan suficientes `Ref`s o`RefMut`s para desbordar la mitad del rango `usize`.
// Por lo tanto, un `BorrowFlag` probablemente nunca se desbordará ni se subirá.
// Sin embargo, esto no es una garantía, ya que un programa patológico podría crear repetidamente y luego mem::forget `Ref`s o`RefMut`s.
// Por lo tanto, todo el código debe verificar explícitamente el desbordamiento y el subdesbordamiento para evitar inseguridad, o al menos comportarse correctamente en caso de que ocurra un desbordamiento o subdesbordamiento (por ejemplo, consulte BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Crea un nuevo `RefCell` que contiene `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Consume el `RefCell`, devolviendo el valor envuelto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Dado que esta función toma `self` (el `RefCell`) por valor, el compilador verifica estáticamente que no está prestado actualmente.
        //
        self.value.into_inner()
    }

    /// Reemplaza el valor envuelto por uno nuevo, devolviendo el valor anterior, sin desinicializar ninguno de los dos.
    ///
    ///
    /// Esta función corresponde a [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics si el valor está actualmente prestado.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Reemplaza el valor envuelto por uno nuevo calculado a partir de `f`, devolviendo el valor anterior, sin desinicializar ninguno.
    ///
    ///
    /// # Panics
    ///
    /// Panics si el valor está actualmente prestado.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Intercambia el valor empaquetado de `self` con el valor empaquetado de `other`, sin desinicializar ninguno de los dos.
    ///
    ///
    /// Esta función corresponde a [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics si el valor de `RefCell` está actualmente prestado.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Inmutablemente toma prestado el valor envuelto.
    ///
    /// El préstamo dura hasta que el `Ref` devuelto sale del alcance.
    /// Se pueden obtener varios préstamos inmutables al mismo tiempo.
    ///
    /// # Panics
    ///
    /// Panics si el valor está actualmente prestado de manera mutante.
    /// Para una variante sin pánico, use [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Un ejemplo de panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Toma prestado inmutablemente el valor envuelto, devolviendo un error si el valor está actualmente prestado de manera mutante.
    ///
    ///
    /// El préstamo dura hasta que el `Ref` devuelto sale del alcance.
    /// Se pueden obtener varios préstamos inmutables al mismo tiempo.
    ///
    /// Esta es la variante sin pánico de [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SEGURIDAD: `BorrowRef` garantiza que solo haya acceso inmutable
            // al valor en préstamo.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Toma prestado mutantemente el valor envuelto.
    ///
    /// El préstamo dura hasta que el `RefMut` devuelto o todos los `RefMut`s derivados de su alcance de salida.
    ///
    /// El valor no se puede tomar prestado mientras este préstamo esté activo.
    ///
    /// # Panics
    ///
    /// Panics si el valor está actualmente prestado.
    /// Para una variante sin pánico, use [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Un ejemplo de panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Toma prestado de manera mutable el valor envuelto, devolviendo un error si el valor está prestado actualmente.
    ///
    ///
    /// El préstamo dura hasta que el `RefMut` devuelto o todos los `RefMut`s derivados de su alcance de salida.
    /// El valor no se puede tomar prestado mientras este préstamo esté activo.
    ///
    /// Esta es la variante sin pánico de [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SEGURIDAD: `BorrowRef` garantiza un acceso exclusivo.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Devuelve un puntero sin procesar a los datos subyacentes en esta celda.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Devuelve una referencia mutable a los datos subyacentes.
    ///
    /// Esta llamada toma prestado `RefCell` de forma mutante (en tiempo de compilación), por lo que no es necesario realizar comprobaciones dinámicas.
    ///
    /// Sin embargo, tenga cuidado: este método espera que `self` sea mutable, lo que generalmente no es el caso cuando se usa un `RefCell`.
    ///
    /// En su lugar, eche un vistazo al método [`borrow_mut`] si `self` no es mutable.
    ///
    /// Además, tenga en cuenta que este método es solo para circunstancias especiales y, por lo general, no es lo que desea.
    /// En caso de duda, utilice [`borrow_mut`] en su lugar.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Deshaga el efecto de los protectores filtrados en el estado de préstamo del `RefCell`.
    ///
    /// Esta llamada es similar a [`get_mut`] pero más especializada.
    /// Toma prestado `RefCell` de manera mutante para garantizar que no existan préstamos y luego restablece el estado que rastrea los préstamos compartidos.
    /// Esto es relevante si se han filtrado algunos préstamos de `Ref` o `RefMut`.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Toma prestado inmutablemente el valor envuelto, devolviendo un error si el valor está actualmente prestado de manera mutante.
    ///
    /// # Safety
    ///
    /// A diferencia de `RefCell::borrow`, este método no es seguro porque no devuelve un `Ref`, por lo que deja intacta la marca de préstamo.
    /// Tomar prestado de forma mutable el `RefCell` mientras la referencia devuelta por este método está viva es un comportamiento indefinido.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SEGURIDAD: Verificamos que nadie esté escribiendo activamente ahora, pero es
            // La responsabilidad de la persona que llama es asegurarse de que nadie escriba hasta que la referencia devuelta ya no esté en uso.
            // Además, `self.value.get()` se refiere al valor propiedad de `self` y, por lo tanto, se garantiza que será válido durante la vida útil de `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Toma el valor envuelto, dejando `Default::default()` en su lugar.
    ///
    /// # Panics
    ///
    /// Panics si el valor está actualmente prestado.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics si el valor está actualmente prestado de manera mutante.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Crea un `RefCell<T>`, con el valor `Default` para T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics si el valor de `RefCell` está actualmente prestado.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics si el valor de `RefCell` está actualmente prestado.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics si el valor de `RefCell` está actualmente prestado.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si el valor de `RefCell` está actualmente prestado.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si el valor de `RefCell` está actualmente prestado.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si el valor de `RefCell` está actualmente prestado.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics si el valor de `RefCell` está actualmente prestado.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Incrementar el préstamo puede resultar en un valor de no lectura (<=0) en estos casos:
            // 1. Era <0, es decir, hay préstamos de escritura, por lo que no podemos permitir un préstamo de lectura debido a las reglas de alias de referencia de Rust
            // 2.
            // Era isize::MAX (la cantidad máxima de préstamos de lectura) y se desbordó en isize::MIN (la cantidad máxima de préstamos de escritura), por lo que no podemos permitir un préstamo de lectura adicional porque isize no puede representar tantos préstamos de lectura (esto solo puede suceder si usted mem::forget más que una pequeña cantidad constante de `Ref`s, lo cual no es una buena práctica)
            //
            //
            //
            //
            None
        } else {
            // Incrementar el préstamo puede resultar en un valor de lectura (> 0) en estos casos:
            // 1. Era=0, es decir, no se tomó prestado, y estamos tomando prestado la primera lectura
            // 2. Fue> 0 y <isize::MAX, es decir
            // hubo préstamos de lectura, e isize es lo suficientemente grande como para representar tener un préstamo de lectura más
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Dado que existe esta Ref, sabemos que el indicador de préstamo es un préstamo de lectura.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Evite que el contador de préstamos se desborde y se convierta en un préstamo por escrito.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Envuelve una referencia prestada a un valor en una caja `RefCell`.
/// Un tipo de contenedor para un valor prestado inmutablemente de un `RefCell<T>`.
///
/// Consulte el [module-level documentation](self) para obtener más información.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Copia un `Ref`.
    ///
    /// El `RefCell` ya está prestado de manera inmutable, por lo que no puede fallar.
    ///
    /// Esta es una función asociada que debe usarse como `Ref::clone(...)`.
    /// Una implementación de `Clone` o un método interferiría con el uso generalizado de `r.borrow().clone()` para clonar el contenido de un `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Hace un nuevo `Ref` para un componente de los datos prestados.
    ///
    /// El `RefCell` ya está prestado de manera inmutable, por lo que no puede fallar.
    ///
    /// Esta es una función asociada que debe usarse como `Ref::map(...)`.
    /// Un método interferiría con los métodos del mismo nombre en el contenido de un `RefCell` utilizado a través de `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Hace un nuevo `Ref` para un componente opcional de los datos prestados.
    /// La protección original se devuelve como `Err(..)` si el cierre devuelve `None`.
    ///
    /// El `RefCell` ya está prestado de manera inmutable, por lo que no puede fallar.
    ///
    /// Esta es una función asociada que debe usarse como `Ref::filter_map(...)`.
    /// Un método interferiría con los métodos del mismo nombre en el contenido de un `RefCell` utilizado a través de `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Divide un `Ref` en múltiples `Ref`s para diferentes componentes de los datos prestados.
    ///
    /// El `RefCell` ya está prestado de manera inmutable, por lo que no puede fallar.
    ///
    /// Esta es una función asociada que debe usarse como `Ref::map_split(...)`.
    /// Un método interferiría con los métodos del mismo nombre en el contenido de un `RefCell` utilizado a través de `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Convierta en una referencia a los datos subyacentes.
    ///
    /// El `RefCell` subyacente nunca se podrá tomar prestado de manera mutante y siempre aparecerá ya prestado de manera inmutable.
    ///
    /// No es una buena idea filtrar más que un número constante de referencias.
    /// El `RefCell` se puede tomar prestado de nuevo de manera inmutable si solo se ha producido un número menor de fugas en total.
    ///
    /// Esta es una función asociada que debe usarse como `Ref::leak(...)`.
    /// Un método interferiría con los métodos del mismo nombre en el contenido de un `RefCell` utilizado a través de `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Al olvidar esta Ref, nos aseguramos de que el contador de préstamos en la RefCell no pueda volver a NO UTILIZADO durante la vida útil del `'b`.
        // Restablecer el estado de seguimiento de referencia requeriría una referencia única a la RefCell prestada.
        // No se pueden crear más referencias mutables a partir de la celda original.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Hace un nuevo `RefMut` para un componente de los datos prestados, por ejemplo, una variante de enumeración.
    ///
    /// El `RefCell` ya está prestado de manera mutante, por lo que no puede fallar.
    ///
    /// Esta es una función asociada que debe usarse como `RefMut::map(...)`.
    /// Un método interferiría con los métodos del mismo nombre en el contenido de un `RefCell` utilizado a través de `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): arreglar pedir prestado
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Hace un nuevo `RefMut` para un componente opcional de los datos prestados.
    /// La protección original se devuelve como `Err(..)` si el cierre devuelve `None`.
    ///
    /// El `RefCell` ya está prestado de manera mutante, por lo que no puede fallar.
    ///
    /// Esta es una función asociada que debe usarse como `RefMut::filter_map(...)`.
    /// Un método interferiría con los métodos del mismo nombre en el contenido de un `RefCell` utilizado a través de `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): arreglar pedir prestado
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SEGURIDAD: la función mantiene una referencia exclusiva durante el tiempo
        // de su llamada a través de `orig`, y el puntero solo se desreferencia dentro de la llamada a la función, nunca permitiendo que escape la referencia exclusiva.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SEGURIDAD: igual que arriba.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Divide un `RefMut` en múltiples `RefMut`s para diferentes componentes de los datos prestados.
    ///
    /// El `RefCell` subyacente permanecerá prestado de manera mutante hasta que ambos `RefMut` devueltos salgan del alcance.
    ///
    /// El `RefCell` ya está prestado de manera mutante, por lo que no puede fallar.
    ///
    /// Esta es una función asociada que debe usarse como `RefMut::map_split(...)`.
    /// Un método interferiría con los métodos del mismo nombre en el contenido de un `RefCell` utilizado a través de `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Convierta en una referencia mutable a los datos subyacentes.
    ///
    /// No se puede volver a tomar prestado el `RefCell` subyacente y siempre aparecerá ya prestado de manera mutante, lo que hace que la referencia devuelta sea la única para el interior.
    ///
    ///
    /// Esta es una función asociada que debe usarse como `RefMut::leak(...)`.
    /// Un método interferiría con los métodos del mismo nombre en el contenido de un `RefCell` utilizado a través de `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Al olvidar este BorrowRefMut, nos aseguramos de que el contador de préstamos en RefCell no pueda volver a NO UTILIZADO durante la vida útil del `'b`.
        // Restablecer el estado de seguimiento de referencia requeriría una referencia única a la RefCell prestada.
        // No se pueden crear más referencias a partir de la celda original dentro de esa vida, lo que hace que el préstamo actual sea la única referencia para la vida restante.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: A diferencia de BorrowRefMut::clone, se llama a new para crear la inicial
        // referencia mutable, por lo que actualmente no debe haber referencias existentes.
        // Por lo tanto, mientras clone incrementa el refcount mutable, aquí solo permitimos explícitamente pasar de UNUSED a UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clona un `BorrowRefMut`.
    //
    // Esto solo es válido si cada `BorrowRefMut` se usa para rastrear una referencia mutable a un rango distinto y no superpuesto del objeto original.
    //
    // Esto no está en un clon implícito, por lo que el código no lo llama implícitamente.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Evite que el contador de préstamos se desborde.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Un tipo de contenedor para un valor prestado de manera mutante de un `RefCell<T>`.
///
/// Consulte el [module-level documentation](self) para obtener más información.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// El núcleo primitivo para la mutabilidad interior en Rust.
///
/// Si tiene una referencia `&T`, normalmente en Rust el compilador realiza optimizaciones basándose en el conocimiento de que `&T` apunta a datos inmutables.La mutación de esos datos, por ejemplo, a través de un alias o al transmutar un `&T` en un `&mut T`, se considera un comportamiento indefinido.
/// `UnsafeCell<T>` exclusión voluntaria de la garantía de inmutabilidad para `&T`: una referencia compartida `&UnsafeCell<T>` puede apuntar a datos que se están mutando.Esto se llama "interior mutability".
///
/// Todos los demás tipos que permiten la mutabilidad interna, como `Cell<T>` y `RefCell<T>`, utilizan internamente `UnsafeCell` para envolver sus datos.
///
/// Tenga en cuenta que `UnsafeCell` solo afecta la garantía de inmutabilidad para referencias compartidas.La garantía de unicidad para referencias mutables no se ve afectada.*No* existe una forma legal de obtener el aliasing `&mut`, ni siquiera con `UnsafeCell<T>`.
///
/// La API `UnsafeCell` en sí es técnicamente muy simple: [`.get()`] le da un puntero `*mut T` sin procesar a su contenido.Depende de _you_, como diseñador de abstracción, utilizar correctamente ese puntero sin procesar.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Las reglas precisas de alias de Rust están algo en proceso de cambio, pero los puntos principales no son polémicos:
///
/// - Si crea una referencia segura con `'a` de por vida (ya sea una referencia `&T` o `&mut T`) a la que se puede acceder mediante un código seguro (por ejemplo, porque lo devolvió), entonces no debe acceder a los datos de ninguna manera que contradiga esa referencia para el resto de `'a`.
/// Por ejemplo, esto significa que si toma el `*mut T` de un `UnsafeCell<T>` y lo convierte en un `&T`, entonces los datos en `T` deben permanecer inmutables (módulo cualquier dato `UnsafeCell` encontrado dentro de `T`, por supuesto) hasta que expire la vida útil de esa referencia.
/// De manera similar, si crea una referencia `&mut T` que se publica en un código seguro, no debe acceder a los datos dentro del `UnsafeCell` hasta que esa referencia caduque.
///
/// - En todo momento, debes evitar las carreras de datos.Si varios subprocesos tienen acceso al mismo `UnsafeCell`, entonces cualquier escritura debe tener una relación adecuada de suceder antes de todos los demás accesos (o usar atomics).
///
/// Para ayudar con el diseño adecuado, los siguientes escenarios se declaran explícitamente legales para el código de un solo subproceso:
///
/// 1. Una referencia `&T` se puede liberar a un código seguro y allí puede coexistir con otras referencias `&T`, pero no con un `&mut T`
///
/// 2. Se puede liberar una referencia `&mut T` a un código seguro siempre que no coexistan otros `&mut T` ni `&T` con él.Un `&mut T` siempre debe ser único.
///
/// Tenga en cuenta que aunque mutar el contenido de un `&UnsafeCell<T>` (incluso mientras que otros `&UnsafeCell<T>` hacen referencia al alias de la celda) está bien (siempre que aplique los invariantes anteriores de alguna otra manera), aún es un comportamiento indefinido tener múltiples alias `&mut UnsafeCell<T>`.
/// Es decir, `UnsafeCell` es un contenedor diseñado para tener una interacción especial con _shared_ accesses (_i.e._, a través de una referencia `&UnsafeCell<_>`);no hay magia alguna cuando se trata de _exclusive_ accesses (_e.g._, a través de un `&mut UnsafeCell<_>`): ni la celda ni el valor envuelto pueden tener un alias durante la duración de ese préstamo `&mut`.
///
/// Esto se muestra con el acceso [`.get_mut()`], que es un _safe_ getter que produce un `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Aquí hay un ejemplo que muestra cómo mutar de manera sólida el contenido de un `UnsafeCell<_>` a pesar de que existen múltiples referencias que hacen alias de la celda:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Obtenga referencias múltiples/compartidas al mismo `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SEGURIDAD: dentro de este alcance no hay otras referencias al contenido de `x`,
///     // por lo que el nuestro es efectivamente único.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- pedir prestado-+
///     *p1_exclusive += 27; // |
/// } // <---------- no puedo ir más allá de este punto -------------------+
///
/// unsafe {
///     // SEGURIDAD: dentro de este ámbito nadie espera tener acceso exclusivo a los contenidos de `x`,
///     // para que podamos tener múltiples accesos compartidos al mismo tiempo.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// El siguiente ejemplo muestra el hecho de que el acceso exclusivo a un `UnsafeCell<T>` implica acceso exclusivo a su `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // con accesos exclusivos,
///                         // `UnsafeCell` es una envoltura transparente sin operación, por lo que no es necesario el `unsafe` aquí.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Obtenga una referencia única verificada en tiempo de compilación para `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Con una referencia exclusiva, podemos mutar los contenidos de forma gratuita.
/// *p_unique.get_mut() = 0;
/// // O equivalente:
/// x = UnsafeCell::new(0);
///
/// // Cuando poseemos el valor, podemos extraer el contenido de forma gratuita.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Construye una nueva instancia de `UnsafeCell` que ajustará el valor especificado.
    ///
    ///
    /// Todo el acceso al valor interno a través de métodos es `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Desenvuelve el valor.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Obtiene un puntero mutable al valor envuelto.
    ///
    /// Esto se puede convertir a un puntero de cualquier tipo.
    /// Asegúrese de que el acceso sea único (sin referencias activas, mutables o no) al transmitir a `&mut T`, y asegúrese de que no haya mutaciones o alias mutables al transmitir a `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Podemos simplemente lanzar el puntero de `UnsafeCell<T>` a `T` debido a #[repr(transparent)].
        // Esto explota el estado especial de libstd, ¡no hay garantía de que el código de usuario funcione en las versiones future del compilador!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Devuelve una referencia mutable a los datos subyacentes.
    ///
    /// Esta llamada toma prestado el `UnsafeCell` de manera mutante (en tiempo de compilación), lo que garantiza que poseemos la única referencia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Obtiene un puntero mutable al valor envuelto.
    /// La diferencia con [`get`] es que esta función acepta un puntero sin formato, lo que es útil para evitar la creación de referencias temporales.
    ///
    /// El resultado se puede convertir a un puntero de cualquier tipo.
    /// Asegúrese de que el acceso sea único (sin referencias activas, mutables o no) cuando se transmita a `&mut T`, y asegúrese de que no haya mutaciones o alias mutables cuando se transmita a `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// La inicialización gradual de un `UnsafeCell` requiere `raw_get`, ya que llamar a `get` requeriría crear una referencia a datos no inicializados:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Podemos simplemente lanzar el puntero de `UnsafeCell<T>` a `T` debido a #[repr(transparent)].
        // Esto explota el estado especial de libstd, ¡no hay garantía de que el código de usuario funcione en las versiones future del compilador!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Crea un `UnsafeCell`, con el valor `Default` para T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}