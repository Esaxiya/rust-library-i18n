use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` pero distinto de cero y covariante.
///
/// A menudo, esto es lo correcto cuando se construyen estructuras de datos usando punteros sin procesar, pero en última instancia, es más peligroso de usar debido a sus propiedades adicionales.Si no está seguro de si debe usar `NonNull<T>`, ¡simplemente use `*mut T`!
///
/// A diferencia de `*mut T`, el puntero siempre debe ser no nulo, incluso si el puntero nunca se desreferencia.Esto es para que las enumeraciones puedan usar este valor prohibido como discriminante: `Option<NonNull<T>>` tiene el mismo tamaño que `* mut T`.
/// Sin embargo, el puntero aún puede colgar si no está desreferenciado.
///
/// A diferencia de `*mut T`, se eligió `NonNull<T>` para ser covariante sobre `T`.Esto hace posible usar `NonNull<T>` al construir tipos covariantes, pero introduce el riesgo de fallas si se usa en un tipo que en realidad no debería ser covariante.
/// (Se tomó la decisión opuesta para `*mut T`, aunque técnicamente la falla solo podría ser causada por llamar a funciones inseguras).
///
/// La covarianza es correcta para la mayoría de las abstracciones seguras, como `Box`, `Rc`, `Arc`, `Vec` y `LinkedList`.Este es el caso porque proporcionan una API pública que sigue las reglas mutables XOR compartidas normales de Rust.
///
/// Si su tipo no puede ser covariante de forma segura, debe asegurarse de que contenga algún campo adicional para proporcionar invariancia.A menudo, este campo será un tipo [`PhantomData`] como `PhantomData<Cell<T>>` o `PhantomData<&'a mut T>`.
///
/// Observe que `NonNull<T>` tiene una instancia `From` para `&T`.Sin embargo, esto no cambia el hecho de que mutar a través de un (puntero derivado de una) referencia compartida es un comportamiento indefinido a menos que la mutación ocurra dentro de un [`UnsafeCell<T>`].Lo mismo ocurre con la creación de una referencia mutable a partir de una referencia compartida.
///
/// Cuando utilice esta instancia `From` sin un `UnsafeCell<T>`, es su responsabilidad asegurarse de que nunca se llame a `as_mut` y que nunca se utilice `as_ptr` para la mutación.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` Los punteros no son `Send` porque los datos a los que hacen referencia pueden tener un alias.
// NB, esta implicación es innecesaria, pero debería proporcionar mejores mensajes de error.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` Los punteros no son `Sync` porque los datos a los que hacen referencia pueden tener un alias.
// NB, esta implicación es innecesaria, pero debería proporcionar mejores mensajes de error.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Crea un nuevo `NonNull` que cuelga, pero bien alineado.
    ///
    /// Esto es útil para inicializar tipos que asignan de manera perezosa, como lo hace `Vec::new`.
    ///
    /// Tenga en cuenta que el valor del puntero puede representar potencialmente un puntero válido a un `T`, lo que significa que no debe usarse como un valor centinela "not yet initialized".
    /// Los tipos que asignan de manera perezosa deben realizar un seguimiento de la inicialización por otros medios.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SEGURIDAD: mem::align_of() devuelve un uso distinto de cero que luego se lanza
        // a un * mut T.
        // Por tanto, `ptr` no es nulo y se respetan las condiciones para llamar a new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Devuelve referencias compartidas al valor.A diferencia de [`as_ref`], esto no requiere que se deba inicializar el valor.
    ///
    /// Para la contraparte mutable, consulte [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Al llamar a este método, debe asegurarse de que todo lo siguiente sea cierto:
    ///
    /// * El puntero debe estar correctamente alineado.
    ///
    /// * Debe ser "dereferencable" en el sentido definido en [the module documentation].
    ///
    /// * Debe hacer cumplir las reglas de creación de alias de Rust, ya que la vida útil devuelta `'a` se elige arbitrariamente y no refleja necesariamente la vida útil real de los datos.
    ///
    ///   En particular, durante la duración de esta vida, la memoria a la que apunta el puntero no debe mutarse (excepto dentro de `UnsafeCell`).
    ///
    /// ¡Esto se aplica incluso si el resultado de este método no se utiliza!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SEGURIDAD: la persona que llama debe garantizar que `self` cumple con todos los
        // requisitos para una referencia.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Devuelve referencias únicas al valor.A diferencia de [`as_mut`], esto no requiere que se deba inicializar el valor.
    ///
    /// Para la contraparte compartida, consulte [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Al llamar a este método, debe asegurarse de que todo lo siguiente sea cierto:
    ///
    /// * El puntero debe estar correctamente alineado.
    ///
    /// * Debe ser "dereferencable" en el sentido definido en [the module documentation].
    ///
    /// * Debe hacer cumplir las reglas de creación de alias de Rust, ya que la vida útil devuelta `'a` se elige arbitrariamente y no refleja necesariamente la vida útil real de los datos.
    ///
    ///   En particular, durante esta vida útil, no se debe acceder (leer o escribir) a la memoria a la que apunta el puntero a través de ningún otro puntero.
    ///
    /// ¡Esto se aplica incluso si el resultado de este método no se utiliza!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SEGURIDAD: la persona que llama debe garantizar que `self` cumple con todos los
        // requisitos para una referencia.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Crea un nuevo `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` debe ser no nulo.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SEGURIDAD: la persona que llama debe garantizar que `ptr` no sea nulo.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Crea un nuevo `NonNull` si `ptr` no es nulo.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SEGURIDAD: el puntero ya está marcado y no es nulo
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Realiza la misma funcionalidad que [`std::ptr::from_raw_parts`], excepto que se devuelve un puntero `NonNull`, a diferencia de un puntero `*const` sin formato.
    ///
    ///
    /// Consulte la documentación de [`std::ptr::from_raw_parts`] para obtener más detalles.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SEGURIDAD: El resultado de `ptr::from::raw_parts_mut` no es nulo porque `data_address` lo es.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Descomponga un puntero (posiblemente ancho) en sus componentes de dirección y metadatos.
    ///
    /// El puntero se puede reconstruir posteriormente con [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Adquiere el puntero `*mut` subyacente.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Devuelve una referencia compartida al valor.Si es posible que el valor no esté inicializado, se debe utilizar [`as_uninit_ref`] en su lugar.
    ///
    /// Para la contraparte mutable, consulte [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Al llamar a este método, debe asegurarse de que todo lo siguiente sea cierto:
    ///
    /// * El puntero debe estar correctamente alineado.
    ///
    /// * Debe ser "dereferencable" en el sentido definido en [the module documentation].
    ///
    /// * El puntero debe apuntar a una instancia inicializada de `T`.
    ///
    /// * Debe hacer cumplir las reglas de creación de alias de Rust, ya que la vida útil devuelta `'a` se elige arbitrariamente y no refleja necesariamente la vida útil real de los datos.
    ///
    ///   En particular, durante la duración de esta vida, la memoria a la que apunta el puntero no debe mutarse (excepto dentro de `UnsafeCell`).
    ///
    /// ¡Esto se aplica incluso si el resultado de este método no se utiliza!
    /// (La parte sobre la inicialización aún no está completamente decidida, pero hasta que lo esté, el único enfoque seguro es asegurarse de que estén realmente inicializados).
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SEGURIDAD: la persona que llama debe garantizar que `self` cumple con todos los
        // requisitos para una referencia.
        unsafe { &*self.as_ptr() }
    }

    /// Devuelve una referencia única al valor.Si es posible que el valor no esté inicializado, se debe utilizar [`as_uninit_mut`] en su lugar.
    ///
    /// Para la contraparte compartida, consulte [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Al llamar a este método, debe asegurarse de que todo lo siguiente sea cierto:
    ///
    /// * El puntero debe estar correctamente alineado.
    ///
    /// * Debe ser "dereferencable" en el sentido definido en [the module documentation].
    ///
    /// * El puntero debe apuntar a una instancia inicializada de `T`.
    ///
    /// * Debe hacer cumplir las reglas de creación de alias de Rust, ya que la vida útil devuelta `'a` se elige arbitrariamente y no refleja necesariamente la vida útil real de los datos.
    ///
    ///   En particular, durante esta vida útil, no se debe acceder (leer o escribir) a la memoria a la que apunta el puntero a través de ningún otro puntero.
    ///
    /// ¡Esto se aplica incluso si el resultado de este método no se utiliza!
    /// (La parte sobre la inicialización aún no está completamente decidida, pero hasta que lo esté, el único enfoque seguro es asegurarse de que estén realmente inicializados).
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SEGURIDAD: la persona que llama debe garantizar que `self` cumple con todos los
        // requisitos para una referencia mutable.
        unsafe { &mut *self.as_ptr() }
    }

    /// Se lanza a un puntero de otro tipo.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SEGURIDAD: `self` es un puntero `NonNull` que necesariamente no es nulo
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Crea un segmento sin formato no nulo a partir de un puntero delgado y una longitud.
    ///
    /// El argumento `len` es el número de **elementos**, no el número de bytes.
    ///
    /// Esta función es segura, pero eliminar la referencia al valor de retorno no es seguro.
    /// Consulte la documentación de [`slice::from_raw_parts`] para conocer los requisitos de seguridad de los cortes.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // crear un puntero de corte al comenzar con un puntero al primer elemento
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Tenga en cuenta que este ejemplo demuestra artificialmente el uso de este método, pero `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SEGURIDAD: `data` es un puntero `NonNull` que necesariamente no es nulo
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Devuelve la longitud de un segmento sin formato no nulo.
    ///
    /// El valor devuelto es el número de **elementos**, no el número de bytes.
    ///
    /// Esta función es segura, incluso cuando el segmento sin formato no nulo no se puede desreferenciar a un segmento porque el puntero no tiene una dirección válida.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Devuelve un puntero no nulo al búfer del segmento.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SEGURIDAD: Sabemos que `self` no es nulo.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Devuelve un puntero sin procesar al búfer del segmento.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Devuelve una referencia compartida a un segmento de valores posiblemente no inicializados.A diferencia de [`as_ref`], esto no requiere que se deba inicializar el valor.
    ///
    /// Para la contraparte mutable, consulte [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Al llamar a este método, debe asegurarse de que todo lo siguiente sea cierto:
    ///
    /// * El puntero debe ser [valid] para lecturas de `ptr.len() * mem::size_of::<T>()` de muchos bytes y debe estar alineado correctamente.Esto significa en particular:
    ///
    ///     * ¡Todo el rango de memoria de este segmento debe estar contenido en un solo objeto asignado!
    ///       Los sectores nunca pueden abarcar varios objetos asignados.
    ///
    ///     * El puntero debe estar alineado incluso para cortes de longitud cero.
    ///     Una razón de esto es que las optimizaciones de diseño de enumeración pueden depender de que las referencias (incluidas las secciones de cualquier longitud) estén alineadas y no sean nulas para distinguirlas de otros datos.
    ///
    ///     Puede obtener un puntero que se puede utilizar como `data` para cortes de longitud cero utilizando [`NonNull::dangling()`].
    ///
    /// * El tamaño total `ptr.len() * mem::size_of::<T>()` del corte no debe ser mayor que `isize::MAX`.
    ///   Consulte la documentación de seguridad de [`pointer::offset`].
    ///
    /// * Debe hacer cumplir las reglas de creación de alias de Rust, ya que la vida útil devuelta `'a` se elige arbitrariamente y no refleja necesariamente la vida útil real de los datos.
    ///   En particular, durante la duración de esta vida, la memoria a la que apunta el puntero no debe mutarse (excepto dentro de `UnsafeCell`).
    ///
    /// ¡Esto se aplica incluso si el resultado de este método no se utiliza!
    ///
    /// Consulte también [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Devuelve una referencia única a un segmento de valores posiblemente no inicializados.A diferencia de [`as_mut`], esto no requiere que se deba inicializar el valor.
    ///
    /// Para la contraparte compartida, consulte [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Al llamar a este método, debe asegurarse de que todo lo siguiente sea cierto:
    ///
    /// * El puntero debe ser [valid] para lecturas y escrituras para `ptr.len() * mem::size_of::<T>()` de muchos bytes, y debe estar alineado correctamente.Esto significa en particular:
    ///
    ///     * ¡Todo el rango de memoria de este segmento debe estar contenido en un solo objeto asignado!
    ///       Los sectores nunca pueden abarcar varios objetos asignados.
    ///
    ///     * El puntero debe estar alineado incluso para cortes de longitud cero.
    ///     Una razón de esto es que las optimizaciones de diseño de enumeración pueden depender de que las referencias (incluidas las secciones de cualquier longitud) estén alineadas y no sean nulas para distinguirlas de otros datos.
    ///
    ///     Puede obtener un puntero que se puede utilizar como `data` para cortes de longitud cero utilizando [`NonNull::dangling()`].
    ///
    /// * El tamaño total `ptr.len() * mem::size_of::<T>()` del corte no debe ser mayor que `isize::MAX`.
    ///   Consulte la documentación de seguridad de [`pointer::offset`].
    ///
    /// * Debe hacer cumplir las reglas de creación de alias de Rust, ya que la vida útil devuelta `'a` se elige arbitrariamente y no refleja necesariamente la vida útil real de los datos.
    ///   En particular, durante esta vida útil, no se debe acceder (leer o escribir) a la memoria a la que apunta el puntero a través de ningún otro puntero.
    ///
    /// ¡Esto se aplica incluso si el resultado de este método no se utiliza!
    ///
    /// Consulte también [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Esto es seguro ya que `memory` es válido para lecturas y escrituras de `memory.len()` con muchos bytes.
    /// // Tenga en cuenta que aquí no se permite llamar a `memory.as_mut()` ya que es posible que el contenido no esté inicializado.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Devuelve un puntero sin formato a un elemento o sublicencia, sin verificar los límites.
    ///
    /// Llamar a este método con un índice fuera de límites o cuando `self` no es desreferenciable es *[comportamiento indefinido]* incluso si no se utiliza el puntero resultante.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SEGURIDAD: la persona que llama se asegura de que `self` sea desreferenciable y `index` dentro de los límites.
        // Como consecuencia, el puntero resultante no puede ser NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SEGURIDAD: Un puntero único no puede ser nulo, por lo que las condiciones para
        // new_unchecked() son respetados.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SEGURIDAD: Una referencia mutable no puede ser nula.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SEGURIDAD: Una referencia no puede ser nula, por lo que las condiciones para
        // new_unchecked() son respetados.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}