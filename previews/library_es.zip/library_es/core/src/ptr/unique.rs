use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Un contenedor alrededor de un `*mut T` no nulo sin formato que indica que el poseedor de este contenedor es el propietario del referente.
/// Útil para construir abstracciones como `Box<T>`, `Vec<T>`, `String` y `HashMap<K, V>`.
///
/// A diferencia de `*mut T`, `Unique<T>` se comporta como "as if", era una instancia de `T`.
/// Implementa `Send`/`Sync` si `T` es `Send`/`Sync`.
/// También implica el tipo de alias fuerte que garantiza que una instancia de `T` puede esperar:
/// el referente del puntero no debe modificarse sin una ruta única a su único propietario.
///
/// Si no está seguro de si es correcto usar `Unique` para sus propósitos, considere usar `NonNull`, que tiene una semántica más débil.
///
///
/// A diferencia de `*mut T`, el puntero siempre debe ser no nulo, incluso si el puntero nunca se desreferencia.
/// Esto es para que las enumeraciones puedan usar este valor prohibido como discriminante: `Option<Unique<T>>` tiene el mismo tamaño que `Unique<T>`.
/// Sin embargo, el puntero aún puede colgar si no está desreferenciado.
///
/// A diferencia de `*mut T`, `Unique<T>` es covariante sobre `T`.
/// Esto siempre debe ser correcto para cualquier tipo que cumpla con los requisitos de alias de Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: este marcador no tiene consecuencias para la varianza, pero es necesario
    // para que Dropck entienda que lógicamente poseemos un `T`.
    //
    // Para obtener más detalles, consulte:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` los punteros son `Send` si `T` es `Send` porque los datos a los que hacen referencia no están alineados.
/// Tenga en cuenta que el sistema de tipos no aplica este invariante de alias;la abstracción que usa el `Unique` debe hacerla cumplir.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` los punteros son `Sync` si `T` es `Sync` porque los datos a los que hacen referencia no están alineados.
/// Tenga en cuenta que el sistema de tipos no aplica este invariante de alias;la abstracción que usa el `Unique` debe hacerla cumplir.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Crea un nuevo `Unique` que cuelga, pero bien alineado.
    ///
    /// Esto es útil para inicializar tipos que asignan de manera perezosa, como lo hace `Vec::new`.
    ///
    /// Tenga en cuenta que el valor del puntero puede representar potencialmente un puntero válido a un `T`, lo que significa que no debe usarse como un valor centinela "not yet initialized".
    /// Los tipos que asignan de manera perezosa deben realizar un seguimiento de la inicialización por otros medios.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SEGURIDAD: mem::align_of() devuelve un puntero válido y no nulo.La
        // Se respetan así las condiciones para llamar a new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Crea un nuevo `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` debe ser no nulo.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SEGURIDAD: la persona que llama debe garantizar que `ptr` no sea nulo.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Crea un nuevo `Unique` si `ptr` no es nulo.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SEGURIDAD: El puntero ya ha sido verificado y no es nulo.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Adquiere el puntero `*mut` subyacente.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Desreferencia el contenido.
    ///
    /// La vida útil resultante está ligada a sí misma, por lo que se comporta "as if", en realidad era una instancia de T que se está tomando prestada.
    /// Si se necesita una vida útil más larga de (unbound), utilice `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SEGURIDAD: la persona que llama debe garantizar que `self` cumple con todos los
        // requisitos para una referencia.
        unsafe { &*self.as_ptr() }
    }

    /// Desreferencia mutablemente el contenido.
    ///
    /// La vida útil resultante está ligada a sí misma, por lo que se comporta "as if", en realidad era una instancia de T que se está tomando prestada.
    /// Si se necesita una vida útil más larga de (unbound), utilice `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SEGURIDAD: la persona que llama debe garantizar que `self` cumple con todos los
        // requisitos para una referencia mutable.
        unsafe { &mut *self.as_ptr() }
    }

    /// Se lanza a un puntero de otro tipo.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SEGURIDAD: Unique::new_unchecked() crea un nuevo único y necesita
        // que el puntero dado no sea nulo.
        // Dado que estamos pasando self como puntero, no puede ser nulo.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SEGURIDAD: una referencia mutable no puede ser nula
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}