#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Proporciona el tipo de metadatos de puntero de cualquier tipo apuntado.
///
/// # Metadatos de puntero
///
/// Los tipos de puntero sin procesar y los tipos de referencia en Rust se pueden considerar compuestos de dos partes:
/// un puntero de datos que contiene la dirección de memoria del valor y algunos metadatos.
///
/// Para los tipos de tamaño estático (que implementan `Sized` traits), así como para los tipos `extern`, se dice que los punteros son `delgados`: los metadatos son de tamaño cero y su tipo es `()`.
///
///
/// Se dice que los punteros a [dynamically-sized types][dst] son "anchos" o "gruesos", tienen metadatos de tamaño distinto de cero:
///
/// * Para estructuras cuyo último campo es un DST, los metadatos son los metadatos del último campo
/// * Para el tipo `str`, los metadatos son la longitud en bytes como `usize`
/// * Para tipos de sector como `[T]`, los metadatos son la longitud en elementos como `usize`
/// * Para objetos trait como `dyn SomeTrait`, los metadatos son [`DynMetadata<Self>`][DynMetadata] (por ejemplo, `DynMetadata<dyn SomeTrait>`)
///
/// En future, el lenguaje Rust puede ganar nuevos tipos de tipos que tienen diferentes metadatos de puntero.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # El `Pointee` trait
///
/// El punto de este trait es su tipo asociado `Metadata`, que es `()` o `usize` o `DynMetadata<_>` como se describe arriba.
/// Se implementa automáticamente para cada tipo.
/// Se puede suponer que se implementa en un contexto genérico, incluso sin un límite correspondiente.
///
/// # Usage
///
/// Los punteros sin procesar se pueden descomponer en la dirección de datos y los componentes de metadatos con su método [`to_raw_parts`].
///
/// Alternativamente, los metadatos solos se pueden extraer con la función [`metadata`].
/// Una referencia se puede pasar a [`metadata`] y coaccionar implícitamente.
///
/// Un puntero (possibly-wide) se puede volver a armar a partir de su dirección y metadatos con [`from_raw_parts`] o [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// El tipo de metadatos en punteros y referencias a `Self`.
    #[lang = "metadata_type"]
    // NOTE: Mantenga trait bounds en `static_assert_expected_bounds_for_metadata`
    //
    // en `library/core/src/ptr/metadata.rs` en sincronía con los de aquí:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Los punteros a los tipos que implementan este alias trait son "delgados".
///
/// Esto incluye los tipos de tamaño estático y los tipos `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: ¿No estabiliza esto antes de que los alias de trait sean estables en el idioma?
pub trait Thin = Pointee<Metadata = ()>;

/// Extrae el componente de metadatos de un puntero.
///
/// Los valores de tipo `*mut T`, `&T` o `&mut T` se pueden pasar directamente a esta función, ya que coaccionan implícitamente a `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SEGURIDAD: Acceder al valor de la unión `PtrRepr` es seguro ya que * const T
    // y PtrComponents<T>tienen los mismos diseños de memoria.
    // Solo std puede hacer esta garantía.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Forma un puntero sin procesar (possibly-wide) a partir de una dirección de datos y metadatos.
///
/// Esta función es segura, pero el puntero devuelto no es necesariamente seguro para eliminar la referencia.
/// Para cortes, consulte la documentación de [`slice::from_raw_parts`] para conocer los requisitos de seguridad.
/// Para los objetos trait, los metadatos deben provenir de un puntero al mismo tipo ereased subyacente.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SEGURIDAD: Acceder al valor de la unión `PtrRepr` es seguro ya que * const T
    // y PtrComponents<T>tienen los mismos diseños de memoria.
    // Solo std puede hacer esta garantía.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Realiza la misma funcionalidad que [`from_raw_parts`], excepto que se devuelve un puntero `*mut` sin formato, a diferencia de un puntero `* const` sin formato.
///
///
/// Consulte la documentación de [`from_raw_parts`] para obtener más detalles.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SEGURIDAD: Acceder al valor de la unión `PtrRepr` es seguro ya que * const T
    // y PtrComponents<T>tienen los mismos diseños de memoria.
    // Solo std puede hacer esta garantía.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Implicación manual necesaria para evitar el enlace `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Implicación manual necesaria para evitar el enlace `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Los metadatos para un tipo de objeto `Dyn = dyn SomeTrait` trait.
///
/// Es un puntero a una vtable (tabla de llamadas virtuales) que representa toda la información necesaria para manipular el tipo concreto almacenado dentro de un objeto trait.
/// La vtable contiene en particular:
///
/// * tamaño de letra
/// * alineación de tipo
/// * un puntero al impl `drop_in_place` del tipo (puede ser una opción no operativa para datos antiguos sin formato)
/// * punteros a todos los métodos para la implementación del tipo de trait
///
/// Tenga en cuenta que los tres primeros son especiales porque son necesarios para asignar, eliminar y desasignar cualquier objeto trait.
///
/// Es posible nombrar esta estructura con un parámetro de tipo que no sea un objeto `dyn` trait (por ejemplo, `DynMetadata<u64>`) pero no para obtener un valor significativo de esa estructura.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// El prefijo común de todas las tablas virtuales.Le siguen punteros de función para los métodos trait.
///
/// Detalle de implementación privada de `DynMetadata::size_of`, etc.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Devuelve el tamaño del tipo asociado con este vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Devuelve la alineación del tipo asociado con este vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Devuelve el tamaño y la alineación juntos como `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SEGURIDAD: el compilador emitió este vtable para un tipo concreto Rust que
        // se sabe que tiene un diseño válido.Misma lógica que en `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Implicaciones manuales necesarias para evitar límites `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}