//! Administre manualmente la memoria a través de punteros sin procesar.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Muchas funciones de este módulo toman punteros sin formato como argumentos y leen o escriben en ellos.Para que esto sea seguro, estos punteros deben ser *válidos*.
//! La validez de un puntero depende de la operación para la que se utiliza (lectura o escritura) y la extensión de la memoria a la que se accede (es decir, cuántos bytes son read/written).
//! La mayoría de las funciones usan `*mut T` y `* const T` para acceder a un solo valor, en cuyo caso la documentación omite el tamaño e implícitamente asume que es `size_of::<T>()` bytes.
//!
//! Las reglas precisas de validez aún no están determinadas.Las garantías que se brindan en este punto son mínimas:
//!
//! * Un puntero [null]*nunca* es válido, ni siquiera para accesos de [size zero][zst].
//! * Para que un puntero sea válido, es necesario, pero no siempre suficiente, que el puntero sea *desreferenciable*: el rango de memoria del tamaño dado que comienza en el puntero debe estar dentro de los límites de un único objeto asignado.
//!
//! Tenga en cuenta que en Rust, cada variable (stack-allocated) se considera un objeto asignado por separado.
//! * Incluso para operaciones de [size zero][zst], el puntero no debe apuntar a la memoria desasignada, es decir, la desasignación hace que los punteros sean inválidos incluso para operaciones de tamaño cero.
//! Sin embargo, convertir cualquier entero *literal* distinto de cero a un puntero es válido para accesos de tamaño cero, incluso si existe algo de memoria en esa dirección y se desasigna.
//! Esto corresponde a escribir su propio asignador: asignar objetos de tamaño cero no es muy difícil.
//! La forma canónica de obtener un puntero válido para accesos de tamaño cero es [`NonNull::dangling`].
//! * Todos los accesos realizados por funciones en este módulo son *no atómicos* en el sentido de [atomic operations] usado para sincronizar entre subprocesos.
//! Esto significa que es un comportamiento indefinido realizar dos accesos simultáneos a la misma ubicación desde diferentes subprocesos, a menos que ambos accesos solo lean desde la memoria.
//! Tenga en cuenta que esto incluye explícitamente [`read_volatile`] y [`write_volatile`]: los accesos volátiles no se pueden utilizar para la sincronización entre subprocesos.
//! * El resultado de lanzar una referencia a un puntero es válido mientras el objeto subyacente esté activo y no se utilice ninguna referencia (solo punteros sin formato) para acceder a la misma memoria.
//!
//! Estos axiomas, junto con el uso cuidadoso de [`offset`] para la aritmética de punteros, son suficientes para implementar correctamente muchas cosas útiles en código inseguro.
//! Con el tiempo, se proporcionarán garantías más sólidas, ya que se están determinando las reglas [aliasing].
//! Para obtener más información, consulte el [book], así como la sección de la referencia dedicada a [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Los punteros en bruto válidos como se definen anteriormente no están necesariamente alineados correctamente (donde la alineación "proper" está definida por el tipo de puntero, es decir, `*const T` debe estar alineado con `mem::align_of::<T>()`).
//! Sin embargo, la mayoría de las funciones requieren que sus argumentos estén correctamente alineados y declararán explícitamente este requisito en su documentación.
//! Las excepciones notables a esto son [`read_unaligned`] y [`write_unaligned`].
//!
//! Cuando una función requiere una alineación adecuada, lo hace incluso si el acceso tiene tamaño 0, es decir, incluso si la memoria no se toca realmente.Considere usar [`NonNull::dangling`] en tales casos.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Ejecuta el destructor (si lo hay) del valor apuntado.
///
/// Esto es semánticamente equivalente a llamar a [`ptr::read`] y descartar el resultado, pero tiene las siguientes ventajas:
///
/// * Es *obligatorio* usar `drop_in_place` para eliminar tipos sin tamaño como objetos trait, porque no se pueden leer en la pila y soltarlos normalmente.
///
/// * Es más amigable para el optimizador hacer esto sobre [`ptr::read`] al eliminar la memoria asignada manualmente (por ejemplo, en las implementaciones de `Box`/`Rc`/`Vec`), ya que el compilador no necesita demostrar que es correcto eludir la copia.
///
///
/// * Se puede usar para eliminar datos [pinned] cuando `T` no es `repr(packed)` (los datos anclados no se deben mover antes de eliminarlos).
///
/// Los valores no alineados no se pueden colocar en su lugar, primero se deben copiar en una ubicación alineada utilizando [`ptr::read_unaligned`].Para estructuras empaquetadas, el compilador realiza este movimiento automáticamente.
/// Esto significa que los campos de estructuras empaquetadas no se colocan en el lugar.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * `to_drop` debe ser [valid] tanto para lectura como para escritura.
///
/// * `to_drop` deben estar correctamente alineados.
///
/// * El valor al que apunta `to_drop` debe ser válido para la eliminación, lo que puede significar que debe mantener invariantes adicionales, esto depende del tipo.
///
/// Además, si `T` no es [`Copy`], usar el valor apuntado después de llamar a `drop_in_place` puede causar un comportamiento indefinido.Tenga en cuenta que `*to_drop = foo` cuenta como un uso porque hará que el valor se elimine nuevamente.
/// [`write()`] se puede utilizar para sobrescribir datos sin que se eliminen.
///
/// Tenga en cuenta que incluso si `T` tiene el tamaño `0`, el puntero debe ser no NULL y estar correctamente alineado.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Elimine manualmente el último elemento de un vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Obtenga un puntero sin procesar al último elemento en `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Acorte `v` para evitar que se caiga el último elemento.
///     // Lo hacemos primero, para evitar problemas si el `drop_in_place` está por debajo de panics.
///     v.set_len(1);
///     // Sin una llamada `drop_in_place`, el último elemento nunca se eliminaría y la memoria que administra se filtraría.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Asegúrese de que se haya eliminado el último elemento.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Tenga en cuenta que el compilador realiza esta copia automáticamente al eliminar estructuras empaquetadas, es decir, normalmente no tiene que preocuparse por estos problemas a menos que llame a `drop_in_place` manualmente.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // El código aquí no importa, el compilador lo reemplaza por el pegamento de gota real.
    //

    // SEGURIDAD: ver comentario arriba
    unsafe { drop_in_place(to_drop) }
}

/// Crea un puntero sin formato nulo.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Crea un puntero sin formato mutable nulo.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Implicación manual necesaria para evitar el enlace `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Implicación manual necesaria para evitar el enlace `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Forma un corte sin procesar a partir de un puntero y una longitud.
///
/// El argumento `len` es el número de **elementos**, no el número de bytes.
///
/// Esta función es segura, pero en realidad usar el valor de retorno no es seguro.
/// Consulte la documentación de [`slice::from_raw_parts`] para conocer los requisitos de seguridad de los cortes.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // crear un puntero de corte al comenzar con un puntero al primer elemento
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SEGURIDAD: Acceder al valor de la unión `Repr` es seguro ya que * const [T]
        //
        // y FatPtr tienen los mismos diseños de memoria.Solo std puede hacer esta garantía.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Realiza la misma funcionalidad que [`slice_from_raw_parts`], excepto que se devuelve un segmento mutable sin procesar, a diferencia de un segmento inmutable sin procesar.
///
///
/// Consulte la documentación de [`slice_from_raw_parts`] para obtener más detalles.
///
/// Esta función es segura, pero en realidad usar el valor de retorno no es seguro.
/// Consulte la documentación de [`slice::from_raw_parts_mut`] para conocer los requisitos de seguridad de los cortes.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // asignar un valor en un índice en el segmento
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SEGURIDAD: Acceder al valor de la unión `Repr` es seguro ya que * mut [T]
        // y FatPtr tienen los mismos diseños de memoria
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Intercambia los valores en dos ubicaciones mutables del mismo tipo, sin desinicializar ninguna de las dos.
///
/// Pero para las siguientes dos excepciones, esta función es semánticamente equivalente a [`mem::swap`]:
///
///
/// * Opera en punteros sin procesar en lugar de referencias.
/// Cuando hay referencias disponibles, se debe preferir [`mem::swap`].
///
/// * Los dos valores señalados pueden superponerse.
/// Si los valores se superponen, se utilizará la región de memoria superpuesta de `x`.
/// Esto se demuestra en el segundo ejemplo a continuación.
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * Tanto `x` como `y` deben ser [valid] tanto para lectura como para escritura.
///
/// * Tanto `x` como `y` deben estar correctamente alineados.
///
/// Tenga en cuenta que incluso si `T` tiene el tamaño `0`, los punteros deben ser no NULL y estar correctamente alineados.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Intercambio de dos regiones que no se superponen:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // esto es `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // esto es `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Intercambio de dos regiones superpuestas:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // esto es `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // esto es `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Los índices `1..3` del segmento se superponen entre `x` y `y`.
///     // Los resultados razonables serían para ellos `[2, 3]`, por lo que los índices `0..3` son `[1, 2, 3]` (coincidiendo con `y` antes que `swap`);o para que sean `[0, 1]` de modo que los índices `1..4` sean `[0, 1, 2]` (coincidiendo con `x` antes de `swap`).
/////
///     // Esta implementación se define para hacer la última elección.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Démonos un poco de espacio para trabajar.
    // No tenemos que preocuparnos por las caídas: `MaybeUninit` no hace nada cuando se cae.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Realizar el intercambio SEGURIDAD: la persona que llama debe garantizar que `x` y `y` son válidos para escrituras y están alineados correctamente.
    // `tmp` no se puede superponer ni a `x` ni a `y` porque `tmp` acaba de asignarse en la pila como un objeto asignado separado.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` y `y` pueden superponerse
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Intercambia bytes `count * size_of::<T>()` entre las dos regiones de memoria que comienzan en `x` y `y`.
/// Las dos regiones *no* deben superponerse.
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * Tanto `x` como `y` deben ser [valid] para lecturas y escrituras de `count *
///   tamaño de: :<T>() `bytes.
///
/// * Tanto `x` como `y` deben estar correctamente alineados.
///
/// * La región de la memoria que comienza en `x` con un tamaño de `count *
///   tamaño de: :<T>() `bytes *no* deben superponerse con la región de memoria que comienza en `y` con el mismo tamaño.
///
/// Tenga en cuenta que incluso si el tamaño efectivamente copiado (`count * size_of: :<T>()`) es `0`, los punteros no deben ser NULL y estar correctamente alineados.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SEGURIDAD: la persona que llama debe garantizar que `x` y `y` están
    // válido para escrituras y alineado correctamente.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Para tipos más pequeños que la optimización de bloques a continuación, simplemente cambie directamente para evitar pesimismo de codegen.
    //
    if mem::size_of::<T>() < 32 {
        // SEGURIDAD: la persona que llama debe garantizar que `x` y `y` son válidos
        // para escrituras, alineadas correctamente y sin superposición.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // El enfoque aquí es utilizar simd para intercambiar x e y de manera eficiente.
    // Las pruebas revelan que intercambiar 32 bytes o 64 bytes a la vez es más eficiente para los procesadores Intel Haswell E.
    // LLVM es más capaz de optimizar si le damos a una estructura un #[repr(simd)], incluso si no usamos esta estructura directamente.
    //
    //
    // FIXME repr(simd) roto en emscripten y redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Recorra x e y, copiándolos `Block` a la vez El optimizador debería desenrollar el bucle por completo para la mayoría de los tipos NB
    // No podemos usar un bucle for ya que el impl de `range` llama a `mem::swap` de forma recursiva
    //
    let mut i = 0;
    while i + block_size <= len {
        // Cree algo de memoria no inicializada como espacio temporal Declarar `t` aquí evita alinear la pila cuando este bucle no se usa
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SEGURIDAD: Como `i < len`, y como la persona que llama debe garantizar que `x` y `y` son válidos
        // para bytes `len`, `x + i` y `y + i` deben ser direcciones válidas, lo que cumple con el contrato de seguridad para `add`.
        //
        // Además, la persona que llama debe garantizar que `x` y `y` son válidos para escrituras, alineados correctamente y no superpuestos, lo que cumple con el contrato de seguridad para `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Intercambiar un bloque de bytes de x&y, usando t como búfer temporal Esto debe optimizarse en operaciones SIMD eficientes donde estén disponibles
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Intercambia los bytes restantes
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SEGURIDAD: ver comentario de seguridad anterior.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Mueve `src` al `dst` puntiagudo, devolviendo el valor `dst` anterior.
///
/// No se descarta ningún valor.
///
/// Esta función es semánticamente equivalente a [`mem::replace`] excepto que opera en punteros sin formato en lugar de referencias.
/// Cuando hay referencias disponibles, se debe preferir [`mem::replace`].
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * `dst` debe ser [valid] tanto para lectura como para escritura.
///
/// * `dst` deben estar correctamente alineados.
///
/// * `dst` debe apuntar a un valor inicializado correctamente de tipo `T`.
///
/// Tenga en cuenta que incluso si `T` tiene el tamaño `0`, el puntero debe ser no NULL y estar correctamente alineado.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` tendría el mismo efecto sin requerir el bloqueo inseguro.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SEGURIDAD: la persona que llama debe garantizar que `dst` es válido para ser
    // emitir a una referencia mutable (válido para escrituras, alineado, inicializado), y no puede superponerse a `src` ya que `dst` debe apuntar a un objeto asignado distinto.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // no se puede superponer
    }
    src
}

/// Lee el valor de `src` sin moverlo.Esto deja la memoria en `src` sin cambios.
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * `src` debe ser [valid] para lecturas.
///
/// * `src` deben estar correctamente alineados.Utilice [`read_unaligned`] si este no es el caso.
///
/// * `src` debe apuntar a un valor inicializado correctamente de tipo `T`.
///
/// Tenga en cuenta que incluso si `T` tiene el tamaño `0`, el puntero debe ser no NULL y estar correctamente alineado.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implementar manualmente [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Cree una copia bit a bit del valor en `a` en `tmp`.
///         let tmp = ptr::read(a);
///
///         // Salir en este punto (ya sea regresando explícitamente o llamando a una función que panics) haría que el valor en `tmp` se elimine mientras `a` todavía hace referencia al mismo valor.
///         // Esto podría desencadenar un comportamiento indefinido si `T` no es `Copy`.
/////
/////
///
///         // Cree una copia bit a bit del valor en `b` en `a`.
///         // Esto es seguro porque las referencias mutables no pueden utilizar alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Como se indicó anteriormente, salir de aquí podría desencadenar un comportamiento indefinido porque `a` y `b` hacen referencia al mismo valor.
/////
///
///         // Mueva `tmp` a `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` se ha movido (`write` toma posesión de su segundo argumento), por lo que no se descarta nada implícitamente aquí.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Propiedad del valor devuelto
///
/// `read` crea una copia bit a bit de `T`, independientemente de si `T` es [`Copy`].
/// Si `T` no es [`Copy`], usar tanto el valor devuelto como el valor en `*src` puede violar la seguridad de la memoria.
/// Tenga en cuenta que la asignación a `*src` cuenta como un uso porque intentará eliminar el valor en `* src`.
///
/// [`write()`] se puede utilizar para sobrescribir datos sin que se eliminen.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` ahora apunta a la misma memoria subyacente que `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // La asignación a `s2` hace que se elimine su valor original.
///     // Más allá de este punto, `s` ya no se debe utilizar, ya que se ha liberado la memoria subyacente.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // La asignación a `s` haría que el valor anterior se descartara nuevamente, lo que daría como resultado un comportamiento indefinido.
/////
///     // s= String::from("bar");//ERROR
///
///     // `ptr::write` se puede utilizar para sobrescribir un valor sin eliminarlo.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SEGURIDAD: la persona que llama debe garantizar que `src` es válido para lecturas.
    // `src` no se puede superponer a `tmp` porque `tmp` acaba de asignarse en la pila como un objeto asignado separado.
    //
    //
    // Además, dado que acabamos de escribir un valor válido en `tmp`, se garantiza que se inicializará correctamente.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Lee el valor de `src` sin moverlo.Esto deja la memoria en `src` sin cambios.
///
/// A diferencia de [`read`], `read_unaligned` funciona con punteros no alineados.
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * `src` debe ser [valid] para lecturas.
///
/// * `src` debe apuntar a un valor inicializado correctamente de tipo `T`.
///
/// Al igual que [`read`], `read_unaligned` crea una copia bit a bit de `T`, independientemente de si `T` es [`Copy`].
/// Si `T` no es [`Copy`], usar tanto el valor devuelto como el valor en `*src` puede ser [violate memory safety][read-ownership].
///
/// Tenga en cuenta que incluso si `T` tiene el tamaño `0`, el puntero no debe ser NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## En estructuras `packed`
///
/// Actualmente es imposible crear punteros sin procesar a campos no alineados de una estructura empaquetada.
///
/// Intentar crear un puntero sin formato a un campo de estructura `unaligned` con una expresión como `&packed.unaligned as *const FieldType` crea una referencia no alineada intermedia antes de convertirla en un puntero sin formato.
///
/// El hecho de que esta referencia sea temporal y se transmita inmediatamente no tiene importancia, ya que el compilador siempre espera que las referencias estén alineadas correctamente.
/// Como resultado, el uso de `&packed.unaligned as *const FieldType` provoca un* comportamiento indefinido * inmediato en su programa.
///
/// Un ejemplo de lo que no se debe hacer y cómo esto se relaciona con `read_unaligned` es:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Aquí intentamos tomar la dirección de un entero de 32 bits que no está alineado.
///     let unaligned =
///         // Aquí se crea una referencia no alineada temporal que da como resultado un comportamiento indefinido independientemente de si la referencia se utiliza o no.
/////
///         &packed.unaligned
///         // Transmitir a un puntero sin formato no ayuda;el error ya sucedió.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Sin embargo, acceder a los campos no alineados directamente con, por ejemplo, `packed.unaligned` es seguro.
///
///
///
///
///
///
// FIXME: Actualice los documentos según el resultado de RFC #2582 y sus amigos.
/// # Examples
///
/// Lea un valor de uso de un búfer de bytes:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SEGURIDAD: la persona que llama debe garantizar que `src` es válido para lecturas.
    // `src` no se puede superponer a `tmp` porque `tmp` acaba de asignarse en la pila como un objeto asignado separado.
    //
    //
    // Además, dado que acabamos de escribir un valor válido en `tmp`, se garantiza que se inicializará correctamente.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Sobrescribe una ubicación de memoria con el valor dado sin leer ni eliminar el valor anterior.
///
/// `write` no deja caer el contenido de `dst`.
/// Esto es seguro, pero podría filtrar asignaciones o recursos, por lo que se debe tener cuidado de no sobrescribir un objeto que deba descartarse.
///
///
/// Además, no deja caer `src`.Semánticamente, `src` se mueve a la ubicación señalada por `dst`.
///
/// Esto es apropiado para inicializar la memoria no inicializada o para sobrescribir la memoria de la que se ha utilizado anteriormente [`read`].
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * `dst` debe ser [valid] para escrituras.
///
/// * `dst` deben estar correctamente alineados.Utilice [`write_unaligned`] si este no es el caso.
///
/// Tenga en cuenta que incluso si `T` tiene el tamaño `0`, el puntero debe ser no NULL y estar correctamente alineado.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implementar manualmente [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Cree una copia bit a bit del valor en `a` en `tmp`.
///         let tmp = ptr::read(a);
///
///         // Salir en este punto (ya sea regresando explícitamente o llamando a una función que panics) haría que el valor en `tmp` se elimine mientras `a` todavía hace referencia al mismo valor.
///         // Esto podría desencadenar un comportamiento indefinido si `T` no es `Copy`.
/////
/////
///
///         // Cree una copia bit a bit del valor en `b` en `a`.
///         // Esto es seguro porque las referencias mutables no pueden utilizar alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Como se indicó anteriormente, salir de aquí podría desencadenar un comportamiento indefinido porque `a` y `b` hacen referencia al mismo valor.
/////
///
///         // Mueva `tmp` a `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` se ha movido (`write` toma posesión de su segundo argumento), por lo que no se descarta nada implícitamente aquí.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Estamos llamando a los intrínsecos directamente para evitar llamadas a funciones en el código generado, ya que `intrinsics::copy_nonoverlapping` es una función contenedora.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SEGURIDAD: la persona que llama debe garantizar que `dst` es válido para escrituras.
    // `dst` no se puede superponer a `src` porque la persona que llama tiene acceso mutable a `dst`, mientras que `src` es propiedad de esta función.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Sobrescribe una ubicación de memoria con el valor dado sin leer ni eliminar el valor anterior.
///
/// A diferencia de [`write()`], el puntero puede estar desalineado.
///
/// `write_unaligned` no deja caer el contenido de `dst`.Esto es seguro, pero podría filtrar asignaciones o recursos, por lo que se debe tener cuidado de no sobrescribir un objeto que deba descartarse.
///
/// Además, no deja caer `src`.Semánticamente, `src` se mueve a la ubicación señalada por `dst`.
///
/// Esto es apropiado para inicializar la memoria no inicializada o sobrescribir la memoria que se ha leído previamente con [`read_unaligned`].
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * `dst` debe ser [valid] para escrituras.
///
/// Tenga en cuenta que incluso si `T` tiene el tamaño `0`, el puntero no debe ser NULL.
///
/// [valid]: self#safety
///
/// ## En estructuras `packed`
///
/// Actualmente es imposible crear punteros sin procesar a campos no alineados de una estructura empaquetada.
///
/// Intentar crear un puntero sin formato a un campo de estructura `unaligned` con una expresión como `&packed.unaligned as *const FieldType` crea una referencia no alineada intermedia antes de convertirla en un puntero sin formato.
///
/// El hecho de que esta referencia sea temporal y se transmita inmediatamente no tiene importancia, ya que el compilador siempre espera que las referencias estén alineadas correctamente.
/// Como resultado, el uso de `&packed.unaligned as *const FieldType` provoca un* comportamiento indefinido * inmediato en su programa.
///
/// Un ejemplo de lo que no se debe hacer y cómo esto se relaciona con `write_unaligned` es:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Aquí intentamos tomar la dirección de un entero de 32 bits que no está alineado.
///     let unaligned =
///         // Aquí se crea una referencia no alineada temporal que da como resultado un comportamiento indefinido independientemente de si la referencia se utiliza o no.
/////
///         &mut packed.unaligned
///         // Transmitir a un puntero sin formato no ayuda;el error ya sucedió.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Sin embargo, acceder a los campos no alineados directamente con, por ejemplo, `packed.unaligned` es seguro.
///
///
///
///
///
///
///
///
///
// FIXME: Actualice los documentos según el resultado de RFC #2582 y sus amigos.
/// # Examples
///
/// Escriba un valor de uso en un búfer de bytes:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SEGURIDAD: la persona que llama debe garantizar que `dst` es válido para escrituras.
    // `dst` no se puede superponer a `src` porque la persona que llama tiene acceso mutable a `dst`, mientras que `src` es propiedad de esta función.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Estamos llamando al intrínseco directamente para evitar llamadas a funciones en el código generado.
        intrinsics::forget(src);
    }
}

/// Realiza una lectura volátil del valor de `src` sin moverlo.Esto deja la memoria en `src` sin cambios.
///
/// Las operaciones volátiles están diseñadas para actuar en la memoria I/O y se garantiza que el compilador no las elide ni las reordena en otras operaciones volátiles.
///
/// # Notes
///
/// Rust no tiene actualmente un modelo de memoria definido de manera rigurosa y formal, por lo que la semántica precisa de lo que "volatile" significa aquí está sujeta a cambios con el tiempo.
/// Dicho esto, la semántica casi siempre terminará siendo bastante similar a [C11's definition of volatile][c11].
///
/// El compilador no debería cambiar el orden relativo o el número de operaciones de memoria volátil.
/// Sin embargo, las operaciones de memoria volátil en tipos de tamaño cero (por ejemplo, si se pasa un tipo de tamaño cero a `read_volatile`) no son errores y pueden ignorarse.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * `src` debe ser [valid] para lecturas.
///
/// * `src` deben estar correctamente alineados.
///
/// * `src` debe apuntar a un valor inicializado correctamente de tipo `T`.
///
/// Al igual que [`read`], `read_volatile` crea una copia bit a bit de `T`, independientemente de si `T` es [`Copy`].
/// Si `T` no es [`Copy`], usar tanto el valor devuelto como el valor en `*src` puede ser [violate memory safety][read-ownership].
/// Sin embargo, es casi seguro que almacenar tipos que no sean [`Copy`] en la memoria volátil sea incorrecto.
///
/// Tenga en cuenta que incluso si `T` tiene el tamaño `0`, el puntero debe ser no NULL y estar correctamente alineado.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Al igual que en C, el hecho de que una operación sea volátil no influye en absoluto en cuestiones relacionadas con el acceso simultáneo desde varios subprocesos.Los accesos volátiles se comportan exactamente como los accesos no atómicos en ese sentido.
///
/// En particular, una carrera entre un `read_volatile` y cualquier operación de escritura en la misma ubicación es un comportamiento indefinido.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Sin entrar en pánico para reducir el impacto del codegen.
        abort();
    }
    // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Realiza una escritura volátil de una ubicación de memoria con el valor dado sin leer o eliminar el valor anterior.
///
/// Las operaciones volátiles están diseñadas para actuar en la memoria I/O y se garantiza que el compilador no las elide ni las reordena en otras operaciones volátiles.
///
/// `write_volatile` no deja caer el contenido de `dst`.Esto es seguro, pero podría filtrar asignaciones o recursos, por lo que se debe tener cuidado de no sobrescribir un objeto que deba descartarse.
///
/// Además, no deja caer `src`.Semánticamente, `src` se mueve a la ubicación señalada por `dst`.
///
/// # Notes
///
/// Rust no tiene actualmente un modelo de memoria definido de manera rigurosa y formal, por lo que la semántica precisa de lo que "volatile" significa aquí está sujeta a cambios con el tiempo.
/// Dicho esto, la semántica casi siempre terminará siendo bastante similar a [C11's definition of volatile][c11].
///
/// El compilador no debería cambiar el orden relativo o el número de operaciones de memoria volátil.
/// Sin embargo, las operaciones de memoria volátil en tipos de tamaño cero (por ejemplo, si se pasa un tipo de tamaño cero a `write_volatile`) no son errores y pueden ignorarse.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// El comportamiento no está definido si se infringe alguna de las siguientes condiciones:
///
/// * `dst` debe ser [valid] para escrituras.
///
/// * `dst` deben estar correctamente alineados.
///
/// Tenga en cuenta que incluso si `T` tiene el tamaño `0`, el puntero debe ser no NULL y estar correctamente alineado.
///
/// [valid]: self#safety
///
/// Al igual que en C, el hecho de que una operación sea volátil no influye en absoluto en cuestiones relacionadas con el acceso simultáneo desde varios subprocesos.Los accesos volátiles se comportan exactamente como los accesos no atómicos en ese sentido.
///
/// En particular, una carrera entre un `write_volatile` y cualquier otra operación (lectura o escritura) en la misma ubicación es un comportamiento indefinido.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Sin entrar en pánico para reducir el impacto del codegen.
        abort();
    }
    // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Alinear el puntero `p`.
///
/// Calcule el desplazamiento (en términos de elementos de la zancada `stride`) que debe aplicarse al puntero `p` para que el puntero `p` se alinee con `a`.
///
/// Note: Esta implementación se ha diseñado cuidadosamente para no panic.Es UB para esto a panic.
/// El único cambio real que se puede hacer aquí es el cambio de `INV_TABLE_MOD_16` y las constantes asociadas.
///
/// Si alguna vez decidimos hacer posible llamar al intrínseco con `a` que no sea una potencia de dos, probablemente será más prudente simplemente cambiar a una implementación ingenua en lugar de intentar adaptar esto para acomodar ese cambio.
///
///
/// Cualquier pregunta vaya a@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): El uso directo de estos elementos intrínsecos mejora el codegen significativamente a nivel de opt <=
    // 1, donde las versiones de método de estas operaciones no están en línea.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Calcule el inverso modular multiplicativo de `x` módulo `m`.
    ///
    /// Esta implementación está diseñada para `align_offset` y tiene las siguientes condiciones previas:
    ///
    /// * `m` es una potencia de dos;
    /// * `x < m`; (si es `x ≥ m`, pase `x % m` en su lugar)
    ///
    /// La implementación de esta función no panic.Siempre.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Tabla inversa modular multiplicativa módulo 2⁴=16.
        ///
        /// Tenga en cuenta que esta tabla no contiene valores donde el inverso no existe (es decir, para `0⁻¹ mod 16`, `2⁻¹ mod 16`, etc.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Módulo para el que está destinado el `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SEGURIDAD: Se requiere que `m` sea una potencia de dos, por lo tanto, no cero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Iteramos "up" usando la siguiente fórmula:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // hasta 2²ⁿ ≥ m.Entonces podemos reducir a nuestro `m` deseado tomando el resultado `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Tenga en cuenta que aquí usamos operaciones de envoltura intencionalmente: la fórmula original usa, por ejemplo, la resta `mod n`.
                // Está completamente bien hacerlos `mod usize::MAX` en su lugar, porque tomamos el resultado `mod n` al final de todos modos.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SEGURIDAD: `a` es una potencia de dos, por lo tanto diferente de cero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` case se puede calcular de forma más sencilla a través de `-p (mod a)`, pero hacerlo inhibe la capacidad de LLVM para seleccionar instrucciones como `lea`.En su lugar, calculamos
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // que distribuye las operaciones en torno al soporte de carga, pero pesimiza lo suficiente a `and` para que LLVM pueda utilizar las diversas optimizaciones que conoce.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Ya alineado.¡Hurra!
        return 0;
    } else if stride == 0 {
        // Si el puntero no está alineado y el elemento tiene un tamaño de cero, ninguna cantidad de elementos alineará el puntero.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SEGURIDAD: a es potencia de dos, por lo tanto, no es cero.stride==0 caso se maneja arriba.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SEGURIDAD: gcdpow tiene un límite superior que es como máximo el número de bits en un tamaño de uso.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SEGURIDAD: mcd siempre es mayor o igual a 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Esta branch resuelve la siguiente ecuación de congruencia lineal:
        //
        // ` p + so = 0 mod a `
        //
        // `p` aquí está el valor del puntero, `s`, paso de `T`, desplazamiento `o` en `T`s, y `a`, la alineación solicitada.
        //
        // Con `g = gcd(a, s)`, y la condición anterior afirmando que `p` también es divisible por `g`, podemos denotar `a' = a/g`, `s' = s/g`, `p' = p/g`, entonces esto se vuelve equivalente a:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // El primer término es "the relative alignment of `p` to `a`" (dividido por `g`), el segundo término es "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (nuevamente dividido por `g`).
        //
        // La división por `g` es necesaria para que la inversa esté bien formada si `a` y `s` no son coprimos.
        //
        // Además, el resultado producido por esta solución no es "minimal", por lo que es necesario tomar el resultado `o mod lcm(s, a)`.Podemos reemplazar `lcm(s, a)` con solo un `a'`.
        //
        //
        //
        //
        //

        // SEGURIDAD: `gcdpow` tiene un límite superior no mayor que el número de bits 0 finales en `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SEGURIDAD: `a2` no es cero.El cambio de `a` por `gcdpow` no puede desplazar ninguno de los bits establecidos
        // en `a` (del cual tiene exactamente uno).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SEGURIDAD: `gcdpow` tiene un límite superior no mayor que el número de bits 0 finales en `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SEGURIDAD: `gcdpow` tiene un límite superior no mayor que el número de bits 0 finales en
        // `a`.
        // Además, la resta no puede desbordarse, porque `a2 = a >> gcdpow` siempre será estrictamente mayor que `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SEGURIDAD: `a2` es una potencia de dos, como se demostró anteriormente.`s2` es estrictamente menor que `a2`
        // porque `(s % a) >> gcdpow` es estrictamente menor que `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // No se puede alinear en absoluto.
    usize::MAX
}

/// Compara punteros sin procesar para la igualdad.
///
/// Es lo mismo que usar el operador `==`, pero menos genérico:
/// los argumentos deben ser punteros sin formato `*const T`, no nada que implemente `PartialEq`.
///
/// Esto se puede usar para comparar referencias `&T` (que coaccionan implícitamente a `*const T`) por su dirección en lugar de comparar los valores a los que apuntan (que es lo que hace la implementación `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Las rebanadas también se comparan por su longitud (punteros de grasa):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits también se comparan por su implementación:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Los punteros tienen direcciones iguales.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Los objetos tienen direcciones iguales, pero `Trait` tiene diferentes implementaciones.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // La conversión de la referencia a un `*const u8` compara por dirección.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Aplique un puntero sin procesar.
///
/// Esto se puede usar para hacer un hash de una referencia `&T` (que coacciona implícitamente a `*const T`) por su dirección en lugar del valor al que apunta (que es lo que hace la implementación de `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls para punteros de función
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Se requiere el yeso intermedio como tamaño de uso para AVR
                // de modo que el espacio de direcciones del puntero de función de origen se conserva en el puntero de función final.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Se requiere el yeso intermedio como tamaño de uso para AVR
                // de modo que el espacio de direcciones del puntero de función de origen se conserva en el puntero de función final.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Sin funciones variadas con 0 parámetros
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Cree un puntero sin formato `const` a un lugar, sin crear una referencia intermedia.
///
/// Solo se permite crear una referencia con `&`/`&mut` si el puntero está correctamente alineado y apunta a los datos inicializados.
/// En los casos en que esos requisitos no se cumplan, se deben utilizar punteros sin procesar.
/// Sin embargo, `&expr as *const _` crea una referencia antes de convertirla en un puntero sin formato, y esa referencia está sujeta a las mismas reglas que todas las demás referencias.
///
/// Esta macro puede crear un puntero sin formato *sin* crear una referencia primero.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` crearía una referencia no alineada y, por lo tanto, sería un comportamiento indefinido.
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Cree un puntero sin formato `mut` a un lugar, sin crear una referencia intermedia.
///
/// Solo se permite crear una referencia con `&`/`&mut` si el puntero está correctamente alineado y apunta a los datos inicializados.
/// En los casos en que esos requisitos no se cumplan, se deben utilizar punteros sin procesar.
/// Sin embargo, `&mut expr as *mut _` crea una referencia antes de convertirla en un puntero sin formato, y esa referencia está sujeta a las mismas reglas que todas las demás referencias.
///
/// Esta macro puede crear un puntero sin formato *sin* crear una referencia primero.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` crearía una referencia no alineada y, por lo tanto, sería un comportamiento indefinido.
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` fuerza a copiar el campo en lugar de crear una referencia.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}