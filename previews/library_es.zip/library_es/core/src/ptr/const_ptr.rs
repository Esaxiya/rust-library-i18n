use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Devuelve `true` si el puntero es nulo.
    ///
    /// Tenga en cuenta que los tipos sin tamaño tienen muchos punteros nulos posibles, ya que solo se considera el puntero de datos sin procesar, no su longitud, vtable, etc.
    /// Por lo tanto, es posible que dos punteros que son nulos aún no se comparen iguales entre sí.
    ///
    /// ## Comportamiento durante la evaluación constante
    ///
    /// Cuando esta función se usa durante la evaluación constante, puede devolver `false` para punteros que resultan ser nulos en tiempo de ejecución.
    /// Específicamente, cuando un puntero a alguna memoria se desplaza más allá de sus límites de tal manera que el puntero resultante es nulo, la función aún devolverá `false`.
    ///
    /// No hay forma de que CTFE sepa la posición absoluta de esa memoria, por lo que no podemos saber si el puntero es nulo o no.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Compare a través de un molde con un puntero delgado, por lo que los punteros gordos solo consideran su parte "data" para la nulidad.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Se lanza a un puntero de otro tipo.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Descomponga un puntero (posiblemente ancho) en sus componentes de dirección y metadatos.
    ///
    /// El puntero se puede reconstruir posteriormente con [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Devuelve `None` si el puntero es nulo o, de lo contrario, devuelve una referencia compartida al valor envuelto en `Some`.Si es posible que el valor no esté inicializado, se debe utilizar [`as_uninit_ref`] en su lugar.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Al llamar a este método, debe asegurarse de que *o* el puntero sea NULL *o* que todo lo siguiente sea verdadero:
    ///
    /// * El puntero debe estar correctamente alineado.
    ///
    /// * Debe ser "dereferencable" en el sentido definido en [the module documentation].
    ///
    /// * El puntero debe apuntar a una instancia inicializada de `T`.
    ///
    /// * Debe hacer cumplir las reglas de creación de alias de Rust, ya que la vida útil devuelta `'a` se elige arbitrariamente y no refleja necesariamente la vida útil real de los datos.
    ///   En particular, durante la duración de esta vida, la memoria a la que apunta el puntero no debe mutarse (excepto dentro de `UnsafeCell`).
    ///
    /// ¡Esto se aplica incluso si el resultado de este método no se utiliza!
    /// (La parte sobre la inicialización aún no está completamente decidida, pero hasta que lo esté, el único enfoque seguro es asegurarse de que estén realmente inicializados).
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Versión nula sin marcar
    ///
    /// Si está seguro de que el puntero nunca puede ser nulo y está buscando algún tipo de `as_ref_unchecked` que devuelva `&T` en lugar de `Option<&T>`, sepa que puede eliminar la referencia del puntero directamente.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SEGURIDAD: la persona que llama debe garantizar que `self` es válido
        // para una referencia si no es nulo.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Devuelve `None` si el puntero es nulo o, de lo contrario, devuelve una referencia compartida al valor envuelto en `Some`.
    /// A diferencia de [`as_ref`], esto no requiere que se deba inicializar el valor.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Al llamar a este método, debe asegurarse de que *o* el puntero sea NULL *o* que todo lo siguiente sea verdadero:
    ///
    /// * El puntero debe estar correctamente alineado.
    ///
    /// * Debe ser "dereferencable" en el sentido definido en [the module documentation].
    ///
    /// * Debe hacer cumplir las reglas de creación de alias de Rust, ya que la vida útil devuelta `'a` se elige arbitrariamente y no refleja necesariamente la vida útil real de los datos.
    ///
    ///   En particular, durante la duración de esta vida, la memoria a la que apunta el puntero no debe mutarse (excepto dentro de `UnsafeCell`).
    ///
    /// ¡Esto se aplica incluso si el resultado de este método no se utiliza!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SEGURIDAD: la persona que llama debe garantizar que `self` cumple con todos los
        // requisitos para una referencia.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Calcula el desplazamiento de un puntero.
    ///
    /// `count` está en unidades de T;por ejemplo, un `count` de 3 representa un desplazamiento de puntero de `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Si se infringe alguna de las siguientes condiciones, el resultado es un comportamiento indefinido:
    ///
    /// * Tanto el puntero inicial como el resultante deben estar dentro de los límites o un byte más allá del final del mismo objeto asignado.
    /// Tenga en cuenta que en Rust, cada variable (stack-allocated) se considera un objeto asignado por separado.
    ///
    /// * El desplazamiento calculado,**en bytes**, no puede desbordar un `isize`.
    ///
    /// * El desplazamiento dentro de los límites no puede depender de "wrapping around" el espacio de direcciones.Es decir, la suma de precisión infinita,**en bytes** debe caber en un usize.
    ///
    /// El compilador y la biblioteca estándar generalmente intentan garantizar que las asignaciones nunca alcancen un tamaño en el que un desplazamiento sea una preocupación.
    /// Por ejemplo, `Vec` y `Box` garantizan que nunca asignen más de `isize::MAX` bytes, por lo que `vec.as_ptr().add(vec.len())` siempre es seguro.
    ///
    /// La mayoría de las plataformas fundamentalmente ni siquiera pueden construir tal asignación.
    /// Por ejemplo, ninguna plataforma conocida de 64 bits puede atender una solicitud de <sup>263</sup> bytes debido a las limitaciones de la tabla de páginas o la división del espacio de direcciones.
    /// Sin embargo, algunas plataformas de 32 y 16 bits pueden atender con éxito una solicitud de más de `isize::MAX` bytes con cosas como la Extensión de dirección física.
    ///
    /// Como tal, la memoria adquirida directamente de asignadores o archivos mapeados en memoria *puede* ser demasiado grande para manejar con esta función.
    ///
    /// Considere usar [`wrapping_offset`] en su lugar si estas restricciones son difíciles de satisfacer.
    /// La única ventaja de este método es que permite optimizaciones del compilador más agresivas.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Calcula el desplazamiento de un puntero mediante aritmética de ajuste.
    ///
    /// `count` está en unidades de T;por ejemplo, un `count` de 3 representa un desplazamiento de puntero de `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Esta operación en sí es siempre segura, pero el uso del puntero resultante no lo es.
    ///
    /// El puntero resultante permanece adjunto al mismo objeto asignado al que apunta `self`.
    /// Es posible que *no* se utilice para acceder a un objeto asignado diferente.Tenga en cuenta que en Rust, cada variable (stack-allocated) se considera un objeto asignado por separado.
    ///
    /// En otras palabras, `let z = x.wrapping_offset((y as isize) - (x as isize))`*no* hace que `z` sea lo mismo que `y` incluso si asumimos que `T` tiene el tamaño `1` y no hay desbordamiento: `z` todavía está adjunto al objeto al que está adjunto `x`, y desreferenciarlo es un comportamiento indefinido a menos que `x` y `y` apunta al mismo objeto asignado.
    ///
    /// En comparación con [`offset`], este método básicamente retrasa el requisito de permanecer dentro del mismo objeto asignado: [`offset`] es un comportamiento indefinido inmediato al cruzar los límites del objeto;`wrapping_offset` produce un puntero, pero aún conduce a un comportamiento indefinido si se elimina la referencia de un puntero cuando está fuera de los límites del objeto al que está adjunto.
    /// [`offset`] se puede optimizar mejor y, por lo tanto, es preferible en código sensible al rendimiento.
    ///
    /// La verificación retrasada solo considera el valor del puntero que fue desreferenciado, no los valores intermedios usados durante el cálculo del resultado final.
    /// Por ejemplo, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` es siempre igual que `x`.En otras palabras, se permite dejar el objeto asignado y luego volver a ingresarlo.
    ///
    /// Si necesita cruzar los límites de un objeto, convierta el puntero en un número entero y haga la aritmética allí.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // Iterar usando un puntero sin procesar en incrementos de dos elementos
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Este bucle imprime "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SEGURIDAD: el `arith_offset` intrínseco no tiene requisitos previos para ser llamado.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Calcula la distancia entre dos punteros.El valor devuelto está en unidades de T: la distancia en bytes se divide por `mem::size_of::<T>()`.
    ///
    /// Esta función es la inversa de [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Si se infringe alguna de las siguientes condiciones, el resultado es un comportamiento indefinido:
    ///
    /// * Tanto el puntero inicial como el otro deben estar dentro de los límites o un byte más allá del final del mismo objeto asignado.
    /// Tenga en cuenta que en Rust, cada variable (stack-allocated) se considera un objeto asignado por separado.
    ///
    /// * Ambos punteros deben *derivarse de* un puntero al mismo objeto.
    ///   (Vea a continuación un ejemplo).
    ///
    /// * La distancia entre los punteros, en bytes, debe ser un múltiplo exacto del tamaño de `T`.
    ///
    /// * La distancia entre los punteros,**en bytes**, no puede desbordar un `isize`.
    ///
    /// * La distancia dentro de los límites no puede depender de "wrapping around" el espacio de direcciones.
    ///
    /// Los tipos Rust nunca son mayores que `isize::MAX` y las asignaciones Rust nunca se ajustan al espacio de direcciones, por lo que dos punteros dentro de algún valor de cualquier tipo `T` de Rust siempre satisfarán las dos últimas condiciones.
    ///
    /// La biblioteca estándar también generalmente garantiza que las asignaciones nunca alcancen un tamaño en el que una compensación sea una preocupación.
    /// Por ejemplo, `Vec` y `Box` garantizan que nunca asignen más de `isize::MAX` bytes, por lo que `ptr_into_vec.offset_from(vec.as_ptr())` siempre cumple las dos últimas condiciones.
    ///
    /// La mayoría de las plataformas fundamentalmente ni siquiera pueden construir una asignación tan grande.
    /// Por ejemplo, ninguna plataforma conocida de 64 bits puede atender una solicitud de <sup>263</sup> bytes debido a las limitaciones de la tabla de páginas o la división del espacio de direcciones.
    /// Sin embargo, algunas plataformas de 32 y 16 bits pueden atender con éxito una solicitud de más de `isize::MAX` bytes con cosas como la Extensión de dirección física.
    /// Como tal, la memoria adquirida directamente de asignadores o archivos mapeados en memoria *puede* ser demasiado grande para manejar con esta función.
    /// (Tenga en cuenta que [`offset`] y [`add`] también tienen una limitación similar y, por lo tanto, tampoco se pueden utilizar en asignaciones tan grandes).
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Esta función panics si `T` es un tipo ("ZST") de tamaño cero.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Uso incorrecto*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Haga que ptr2_other sea un "alias" de ptr2, pero derivado de ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Dado que ptr2_other y ptr2 se derivan de punteros a diferentes objetos, calcular su desplazamiento es un comportamiento indefinido, ¡aunque apunten a la misma dirección!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Comportamiento indefinido
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Devuelve si se garantiza que dos punteros son iguales.
    ///
    /// En tiempo de ejecución, esta función se comporta como `self == other`.
    /// Sin embargo, en algunos contextos (por ejemplo, evaluación en tiempo de compilación), no siempre es posible determinar la igualdad de dos punteros, por lo que esta función puede devolver falsamente `false` para punteros que luego resulten ser iguales.
    ///
    /// Pero cuando devuelve `true`, se garantiza que los punteros son iguales.
    ///
    /// Esta función es el espejo de [`guaranteed_ne`], pero no su inversa.Hay comparaciones de punteros para las que ambas funciones devuelven `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// El valor de retorno puede cambiar dependiendo de la versión del compilador y es posible que el código inseguro no dependa del resultado de esta función para su solidez.
    /// Se sugiere usar esta función solo para optimizaciones de rendimiento donde los valores de retorno de `false` falsos por esta función no afectan el resultado, sino solo el rendimiento.
    /// No se han explorado las consecuencias de usar este método para hacer que el tiempo de ejecución y el código de tiempo de compilación se comporten de manera diferente.
    /// Este método no debe usarse para introducir tales diferencias y tampoco debe estabilizarse antes de que comprendamos mejor este problema.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Devuelve si se garantiza que dos punteros son desiguales.
    ///
    /// En tiempo de ejecución, esta función se comporta como `self != other`.
    /// Sin embargo, en algunos contextos (por ejemplo, evaluación en tiempo de compilación), no siempre es posible determinar la desigualdad de dos punteros, por lo que esta función puede devolver falsamente `false` para punteros que luego resulten ser desiguales.
    ///
    /// Pero cuando devuelve `true`, se garantiza que los punteros no serán iguales.
    ///
    /// Esta función es el espejo de [`guaranteed_eq`], pero no su inversa.Hay comparaciones de punteros para las que ambas funciones devuelven `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// El valor de retorno puede cambiar dependiendo de la versión del compilador y es posible que el código inseguro no dependa del resultado de esta función para su solidez.
    /// Se sugiere usar esta función solo para optimizaciones de rendimiento donde los valores de retorno de `false` falsos por esta función no afectan el resultado, sino solo el rendimiento.
    /// No se han explorado las consecuencias de usar este método para hacer que el tiempo de ejecución y el código de tiempo de compilación se comporten de manera diferente.
    /// Este método no debe usarse para introducir tales diferencias y tampoco debe estabilizarse antes de que comprendamos mejor este problema.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Calcula el desplazamiento a partir de un puntero (conveniente para `.offset(count as isize)`).
    ///
    /// `count` está en unidades de T;por ejemplo, un `count` de 3 representa un desplazamiento de puntero de `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Si se infringe alguna de las siguientes condiciones, el resultado es un comportamiento indefinido:
    ///
    /// * Tanto el puntero inicial como el resultante deben estar dentro de los límites o un byte más allá del final del mismo objeto asignado.
    /// Tenga en cuenta que en Rust, cada variable (stack-allocated) se considera un objeto asignado por separado.
    ///
    /// * El desplazamiento calculado,**en bytes**, no puede desbordar un `isize`.
    ///
    /// * El desplazamiento dentro de los límites no puede depender de "wrapping around" el espacio de direcciones.Es decir, la suma de precisión infinita debe caber en un `usize`.
    ///
    /// El compilador y la biblioteca estándar generalmente intentan garantizar que las asignaciones nunca alcancen un tamaño en el que un desplazamiento sea una preocupación.
    /// Por ejemplo, `Vec` y `Box` garantizan que nunca asignen más de `isize::MAX` bytes, por lo que `vec.as_ptr().add(vec.len())` siempre es seguro.
    ///
    /// La mayoría de las plataformas fundamentalmente ni siquiera pueden construir tal asignación.
    /// Por ejemplo, ninguna plataforma conocida de 64 bits puede atender una solicitud de <sup>263</sup> bytes debido a las limitaciones de la tabla de páginas o la división del espacio de direcciones.
    /// Sin embargo, algunas plataformas de 32 y 16 bits pueden atender con éxito una solicitud de más de `isize::MAX` bytes con cosas como la Extensión de dirección física.
    ///
    /// Como tal, la memoria adquirida directamente de asignadores o archivos mapeados en memoria *puede* ser demasiado grande para manejar con esta función.
    ///
    /// Considere usar [`wrapping_add`] en su lugar si estas restricciones son difíciles de satisfacer.
    /// La única ventaja de este método es que permite optimizaciones del compilador más agresivas.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Calcula el desplazamiento a partir de un puntero (conveniencia para `.offset ((cuenta como isize).wrapping_neg())`).
    ///
    /// `count` está en unidades de T;por ejemplo, un `count` de 3 representa un desplazamiento de puntero de `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Si se infringe alguna de las siguientes condiciones, el resultado es un comportamiento indefinido:
    ///
    /// * Tanto el puntero inicial como el resultante deben estar dentro de los límites o un byte más allá del final del mismo objeto asignado.
    /// Tenga en cuenta que en Rust, cada variable (stack-allocated) se considera un objeto asignado por separado.
    ///
    /// * El desplazamiento calculado no puede exceder `isize::MAX`**bytes**.
    ///
    /// * El desplazamiento dentro de los límites no puede depender de "wrapping around" el espacio de direcciones.Es decir, la suma de precisión infinita debe caber en un tamaño.
    ///
    /// El compilador y la biblioteca estándar generalmente intentan garantizar que las asignaciones nunca alcancen un tamaño en el que un desplazamiento sea una preocupación.
    /// Por ejemplo, `Vec` y `Box` garantizan que nunca asignen más de `isize::MAX` bytes, por lo que `vec.as_ptr().add(vec.len()).sub(vec.len())` siempre es seguro.
    ///
    /// La mayoría de las plataformas fundamentalmente ni siquiera pueden construir tal asignación.
    /// Por ejemplo, ninguna plataforma conocida de 64 bits puede atender una solicitud de <sup>263</sup> bytes debido a las limitaciones de la tabla de páginas o la división del espacio de direcciones.
    /// Sin embargo, algunas plataformas de 32 y 16 bits pueden atender con éxito una solicitud de más de `isize::MAX` bytes con cosas como la Extensión de dirección física.
    ///
    /// Como tal, la memoria adquirida directamente de asignadores o archivos mapeados en memoria *puede* ser demasiado grande para manejar con esta función.
    ///
    /// Considere usar [`wrapping_sub`] en su lugar si estas restricciones son difíciles de satisfacer.
    /// La única ventaja de este método es que permite optimizaciones del compilador más agresivas.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Calcula el desplazamiento de un puntero mediante aritmética de ajuste.
    /// (conveniencia para `.wrapping_offset(count as isize)`)
    ///
    /// `count` está en unidades de T;por ejemplo, un `count` de 3 representa un desplazamiento de puntero de `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Esta operación en sí es siempre segura, pero el uso del puntero resultante no lo es.
    ///
    /// El puntero resultante permanece adjunto al mismo objeto asignado al que apunta `self`.
    /// Es posible que *no* se utilice para acceder a un objeto asignado diferente.Tenga en cuenta que en Rust, cada variable (stack-allocated) se considera un objeto asignado por separado.
    ///
    /// En otras palabras, `let z = x.wrapping_add((y as usize) - (x as usize))`*no* hace que `z` sea lo mismo que `y` incluso si asumimos que `T` tiene el tamaño `1` y no hay desbordamiento: `z` todavía está adjunto al objeto al que está adjunto `x`, y desreferenciarlo es un comportamiento indefinido a menos que `x` y `y` apunta al mismo objeto asignado.
    ///
    /// En comparación con [`add`], este método básicamente retrasa el requisito de permanecer dentro del mismo objeto asignado: [`add`] es un comportamiento indefinido inmediato al cruzar los límites del objeto;`wrapping_add` produce un puntero, pero aún conduce a un comportamiento indefinido si se elimina la referencia de un puntero cuando está fuera de los límites del objeto al que está adjunto.
    /// [`add`] se puede optimizar mejor y, por lo tanto, es preferible en código sensible al rendimiento.
    ///
    /// La verificación retrasada solo considera el valor del puntero que fue desreferenciado, no los valores intermedios usados durante el cálculo del resultado final.
    /// Por ejemplo, `x.wrapping_add(o).wrapping_sub(o)` es siempre igual que `x`.En otras palabras, se permite dejar el objeto asignado y luego volver a ingresarlo.
    ///
    /// Si necesita cruzar los límites de un objeto, convierta el puntero en un número entero y haga la aritmética allí.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // Iterar usando un puntero sin procesar en incrementos de dos elementos
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Este bucle imprime "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Calcula el desplazamiento de un puntero mediante aritmética de ajuste.
    /// (conveniencia para `.wrapping_offset ((cuenta como isize).wrapping_neg())`)
    ///
    /// `count` está en unidades de T;por ejemplo, un `count` de 3 representa un desplazamiento de puntero de `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Esta operación en sí es siempre segura, pero el uso del puntero resultante no lo es.
    ///
    /// El puntero resultante permanece adjunto al mismo objeto asignado al que apunta `self`.
    /// Es posible que *no* se utilice para acceder a un objeto asignado diferente.Tenga en cuenta que en Rust, cada variable (stack-allocated) se considera un objeto asignado por separado.
    ///
    /// En otras palabras, `let z = x.wrapping_sub((x as usize) - (y as usize))`*no* hace que `z` sea lo mismo que `y` incluso si asumimos que `T` tiene el tamaño `1` y no hay desbordamiento: `z` todavía está adjunto al objeto al que está adjunto `x`, y desreferenciarlo es un comportamiento indefinido a menos que `x` y `y` apunta al mismo objeto asignado.
    ///
    /// En comparación con [`sub`], este método básicamente retrasa el requisito de permanecer dentro del mismo objeto asignado: [`sub`] es un comportamiento indefinido inmediato al cruzar los límites del objeto;`wrapping_sub` produce un puntero, pero aún conduce a un comportamiento indefinido si se elimina la referencia de un puntero cuando está fuera de los límites del objeto al que está adjunto.
    /// [`sub`] se puede optimizar mejor y, por lo tanto, es preferible en código sensible al rendimiento.
    ///
    /// La verificación retrasada solo considera el valor del puntero que fue desreferenciado, no los valores intermedios usados durante el cálculo del resultado final.
    /// Por ejemplo, `x.wrapping_add(o).wrapping_sub(o)` es siempre igual que `x`.En otras palabras, se permite dejar el objeto asignado y luego volver a ingresarlo.
    ///
    /// Si necesita cruzar los límites de un objeto, convierta el puntero en un número entero y haga la aritmética allí.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // Iterar usando un puntero sin procesar en incrementos de dos elementos (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Este bucle imprime "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Establece el valor del puntero en `ptr`.
    ///
    /// En caso de que `self` sea un puntero (fat) a un tipo sin tamaño, esta operación solo afectará a la parte del puntero, mientras que para los punteros (thin) a tipos con tamaño, esto tiene el mismo efecto que una asignación simple.
    ///
    /// El puntero resultante tendrá la procedencia de `val`, es decir, para un puntero grueso, esta operación es semánticamente la misma que crear un nuevo puntero grueso con el valor del puntero de datos de `val` pero los metadatos de `self`.
    ///
    ///
    /// # Examples
    ///
    /// Esta función es principalmente útil para permitir la aritmética de punteros por bytes en punteros potencialmente gordos:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // imprimirá "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SEGURIDAD: En caso de un puntero delgado, esta operación es idéntica
        // a una simple tarea.
        // En el caso de un puntero gordo, con la implementación actual de diseño de puntero gordo, el primer campo de dicho puntero es siempre el puntero de datos, que también está asignado.
        //
        unsafe { *thin = val };
        self
    }

    /// Lee el valor de `self` sin moverlo.
    /// Esto deja la memoria en `self` sin cambios.
    ///
    /// Consulte [`ptr::read`] para ver ejemplos y preocupaciones de seguridad.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `read`.
        unsafe { read(self) }
    }

    /// Realiza una lectura volátil del valor de `self` sin moverlo.Esto deja la memoria en `self` sin cambios.
    ///
    /// Las operaciones volátiles están diseñadas para actuar en la memoria I/O y se garantiza que el compilador no las elide ni las reordena en otras operaciones volátiles.
    ///
    ///
    /// Consulte [`ptr::read_volatile`] para ver ejemplos y preocupaciones de seguridad.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Lee el valor de `self` sin moverlo.
    /// Esto deja la memoria en `self` sin cambios.
    ///
    /// A diferencia de `read`, el puntero puede estar desalineado.
    ///
    /// Consulte [`ptr::read_unaligned`] para ver ejemplos y preocupaciones de seguridad.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Copia `count * size_of<T>` bytes de `self` a `dest`.
    /// El origen y el destino pueden superponerse.
    ///
    /// NOTE: tiene el *mismo* orden de argumentos que [`ptr::copy`].
    ///
    /// Consulte [`ptr::copy`] para ver ejemplos y preocupaciones de seguridad.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Copia `count * size_of<T>` bytes de `self` a `dest`.
    /// Es posible que el origen y el destino *no* se superpongan.
    ///
    /// NOTE: tiene el *mismo* orden de argumentos que [`ptr::copy_nonoverlapping`].
    ///
    /// Consulte [`ptr::copy_nonoverlapping`] para ver ejemplos y preocupaciones de seguridad.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Calcula el desplazamiento que debe aplicarse al puntero para alinearlo con `align`.
    ///
    /// Si no es posible alinear el puntero, la implementación devuelve `usize::MAX`.
    /// Está permitido que la implementación *siempre* devuelva `usize::MAX`.
    /// Solo el rendimiento de su algoritmo puede depender de obtener una compensación utilizable aquí, no su corrección.
    ///
    /// El desplazamiento se expresa en número de elementos `T` y no en bytes.El valor devuelto se puede utilizar con el método `wrapping_add`.
    ///
    /// No hay garantía alguna de que la compensación del puntero no se desborde ni vaya más allá de la asignación a la que apunta el puntero.
    ///
    /// Depende de la persona que llama asegurarse de que el desplazamiento devuelto sea correcto en todos los términos, excepto en la alineación.
    ///
    /// # Panics
    ///
    /// La función panics si `align` no es una potencia de dos.
    ///
    /// # Examples
    ///
    /// Accediendo a `u8` adyacente como `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // mientras que el puntero se puede alinear a través de `offset`, apuntaría fuera de la asignación
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SEGURIDAD: Se ha comprobado que `align` tiene una potencia de 2 arriba
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Devuelve la longitud de una rebanada sin procesar.
    ///
    /// El valor devuelto es el número de **elementos**, no el número de bytes.
    ///
    /// Esta función es segura, incluso cuando el segmento sin procesar no se puede convertir en una referencia de segmento porque el puntero es nulo o no está alineado.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SEGURIDAD: esto es seguro porque `*const [T]` y `FatPtr<T>` tienen el mismo diseño.
            // Solo `std` puede hacer esta garantía.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Devuelve un puntero sin procesar al búfer del segmento.
    ///
    /// Esto es equivalente a convertir `self` a `*const T`, pero es más seguro para los tipos.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Devuelve un puntero sin formato a un elemento o sublicencia, sin verificar los límites.
    ///
    /// Llamar a este método con un índice fuera de límites o cuando `self` no es desreferenciable es *[comportamiento indefinido]* incluso si no se utiliza el puntero resultante.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SEGURIDAD: la persona que llama se asegura de que `self` sea desreferenciable y `index` dentro de los límites.
        unsafe { index.get_unchecked(self) }
    }

    /// Devuelve `None` si el puntero es nulo o, de lo contrario, devuelve un segmento compartido al valor envuelto en `Some`.
    /// A diferencia de [`as_ref`], esto no requiere que se deba inicializar el valor.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Al llamar a este método, debe asegurarse de que *o* el puntero sea NULL *o* que todo lo siguiente sea verdadero:
    ///
    /// * El puntero debe ser [valid] para lecturas de `ptr.len() * mem::size_of::<T>()` de muchos bytes y debe estar alineado correctamente.Esto significa en particular:
    ///
    ///     * ¡Todo el rango de memoria de este segmento debe estar contenido en un solo objeto asignado!
    ///       Los sectores nunca pueden abarcar varios objetos asignados.
    ///
    ///     * El puntero debe estar alineado incluso para cortes de longitud cero.
    ///     Una razón de esto es que las optimizaciones de diseño de enumeración pueden depender de que las referencias (incluidas las secciones de cualquier longitud) estén alineadas y no sean nulas para distinguirlas de otros datos.
    ///
    ///     Puede obtener un puntero que se puede utilizar como `data` para cortes de longitud cero utilizando [`NonNull::dangling()`].
    ///
    /// * El tamaño total `ptr.len() * mem::size_of::<T>()` del corte no debe ser mayor que `isize::MAX`.
    ///   Consulte la documentación de seguridad de [`pointer::offset`].
    ///
    /// * Debe hacer cumplir las reglas de creación de alias de Rust, ya que la vida útil devuelta `'a` se elige arbitrariamente y no refleja necesariamente la vida útil real de los datos.
    ///   En particular, durante la duración de esta vida, la memoria a la que apunta el puntero no debe mutarse (excepto dentro de `UnsafeCell`).
    ///
    /// ¡Esto se aplica incluso si el resultado de este método no se utiliza!
    ///
    /// Consulte también [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SEGURIDAD: la persona que llama debe respetar el contrato de seguridad para `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Igualdad para los punteros
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Comparación de punteros
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}