#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Un `RawWaker` permite al implementador de un ejecutor de tareas crear un [`Waker`] que proporciona un comportamiento de activación personalizado.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Consta de un puntero de datos y un [virtual function pointer table (vtable)][vtable] que personaliza el comportamiento del `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Un puntero de datos, que se puede utilizar para almacenar datos arbitrarios según lo requiera el ejecutor.
    /// Esto podría ser, por ejemplo,
    /// un puntero de tipo borrado a un `Arc` que está asociado con la tarea.
    /// El valor de este campo se pasa a todas las funciones que forman parte de vtable como primer parámetro.
    ///
    data: *const (),
    /// Tabla de punteros de función virtual que personaliza el comportamiento de este waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Crea un nuevo `RawWaker` a partir del puntero `data` proporcionado y `vtable`.
    ///
    /// El puntero `data` se puede utilizar para almacenar datos arbitrarios según lo requiera el ejecutor.Esto podría ser, por ejemplo,
    /// un puntero de tipo borrado a un `Arc` que está asociado con la tarea.
    /// El valor de este puntero se pasará a todas las funciones que forman parte del `vtable` como primer parámetro.
    ///
    /// El `vtable` personaliza el comportamiento de un `Waker` que se crea a partir de un `RawWaker`.
    /// Para cada operación en el `Waker`, se llamará a la función asociada en el `vtable` del `RawWaker` subyacente.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Una tabla de punteros de función virtual (vtable) que especifica el comportamiento de un [`RawWaker`].
///
/// El puntero que se pasa a todas las funciones dentro de la vtable es el puntero `data` del objeto [`RawWaker`] adjunto.
///
/// Las funciones dentro de esta estructura solo están diseñadas para ser llamadas en el puntero `data` de un objeto [`RawWaker`] construido correctamente desde dentro de la implementación [`RawWaker`].
/// Llamar a una de las funciones contenidas utilizando cualquier otro puntero `data` provocará un comportamiento indefinido.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Esta función se llamará cuando se clone el [`RawWaker`], por ejemplo, cuando se clone el [`Waker`] en el que está almacenado el [`RawWaker`].
    ///
    /// La implementación de esta función debe retener todos los recursos necesarios para esta instancia adicional de un [`RawWaker`] y la tarea asociada.
    /// Llamar a `wake` en el [`RawWaker`] resultante debería resultar en una reactivación de la misma tarea que habría despertado el [`RawWaker`] original.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Esta función se llamará cuando se llame a `wake` en el [`Waker`].
    /// Debe despertar la tarea asociada con este [`RawWaker`].
    ///
    /// La implementación de esta función debe asegurarse de liberar los recursos asociados con esta instancia de un [`RawWaker`] y la tarea asociada.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Esta función se llamará cuando se llame a `wake_by_ref` en el [`Waker`].
    /// Debe despertar la tarea asociada con este [`RawWaker`].
    ///
    /// Esta función es similar a `wake`, pero no debe consumir el puntero de datos proporcionado.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Esta función se llama cuando se descarta un [`RawWaker`].
    ///
    /// La implementación de esta función debe asegurarse de liberar los recursos asociados con esta instancia de un [`RawWaker`] y la tarea asociada.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Crea un nuevo `RawWakerVTable` a partir de las funciones `clone`, `wake`, `wake_by_ref` y `drop` proporcionadas.
    ///
    /// # `clone`
    ///
    /// Esta función se llamará cuando se clone el [`RawWaker`], por ejemplo, cuando se clone el [`Waker`] en el que está almacenado el [`RawWaker`].
    ///
    /// La implementación de esta función debe retener todos los recursos necesarios para esta instancia adicional de un [`RawWaker`] y la tarea asociada.
    /// Llamar a `wake` en el [`RawWaker`] resultante debería resultar en una reactivación de la misma tarea que habría despertado el [`RawWaker`] original.
    ///
    /// # `wake`
    ///
    /// Esta función se llamará cuando se llame a `wake` en el [`Waker`].
    /// Debe despertar la tarea asociada con este [`RawWaker`].
    ///
    /// La implementación de esta función debe asegurarse de liberar los recursos asociados con esta instancia de un [`RawWaker`] y la tarea asociada.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Esta función se llamará cuando se llame a `wake_by_ref` en el [`Waker`].
    /// Debe despertar la tarea asociada con este [`RawWaker`].
    ///
    /// Esta función es similar a `wake`, pero no debe consumir el puntero de datos proporcionado.
    ///
    /// # `drop`
    ///
    /// Esta función se llama cuando se descarta un [`RawWaker`].
    ///
    /// La implementación de esta función debe asegurarse de liberar los recursos asociados con esta instancia de un [`RawWaker`] y la tarea asociada.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// El `Context` de una tarea asincrónica.
///
/// Actualmente, `Context` solo sirve para proporcionar acceso a un `&Waker` que se puede utilizar para reactivar la tarea actual.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Asegúrese de que estamos a prueba de future contra cambios de varianza forzando que la vida útil sea invariante (la vida útil de la posición de argumento es contravariante mientras que la vida útil de la posición de retorno es covariante).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Cree un nuevo `Context` a partir de un `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Devuelve una referencia al `Waker` para la tarea actual.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Un `Waker` es un identificador para activar una tarea notificando a su ejecutor que está lista para ejecutarse.
///
/// Este identificador encapsula una instancia [`RawWaker`], que define el comportamiento de activación específico del ejecutor.
///
///
/// Implementa [`Clone`], [`Send`] y [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Despierta la tarea asociada con este `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // La llamada de activación real se delega a través de una llamada de función virtual a la implementación que es definida por el ejecutor.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // No llame a `drop`: `wake` consumirá el despertador.
        crate::mem::forget(self);

        // SEGURIDAD: Esto es seguro porque `Waker::from_raw` es la única forma
        // para inicializar `wake` y `data` requiriendo que el usuario reconozca que el contrato de `RawWaker` se mantiene.
        //
        unsafe { (wake)(data) };
    }

    /// Despierta la tarea asociada con este `Waker` sin consumir el `Waker`.
    ///
    /// Esto es similar a `wake`, pero puede ser un poco menos eficiente en el caso de que esté disponible un `Waker` propio.
    /// Se debe preferir este método a llamar a `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // La llamada de activación real se delega a través de una llamada de función virtual a la implementación que es definida por el ejecutor.
        //

        // SEGURIDAD: ver `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Devuelve `true` si este `Waker` y otro `Waker` han despertado la misma tarea.
    ///
    /// Esta función trabaja sobre la base del mejor esfuerzo y puede devolver falso incluso cuando el `Waker`s despertara la misma tarea.
    /// Sin embargo, si esta función devuelve `true`, se garantiza que los `Waker` despertarán la misma tarea.
    ///
    /// Esta función se utiliza principalmente con fines de optimización.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Crea un nuevo `Waker` a partir de [`RawWaker`].
    ///
    /// El comportamiento del `Waker` devuelto no está definido si el contrato definido en la documentación de [`RawWaker`] y de [`RawWakerVTable`] no se cumple.
    ///
    /// Por tanto, este método no es seguro.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SEGURIDAD: Esto es seguro porque `Waker::from_raw` es la única forma
            // para inicializar `clone` y `data` requiriendo que el usuario reconozca que el contrato de [`RawWaker`] se mantiene.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SEGURIDAD: Esto es seguro porque `Waker::from_raw` es la única forma
        // para inicializar `drop` y `data` requiriendo que el usuario reconozca que el contrato de `RawWaker` se mantiene.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}