/// Código personalizado dentro del destructor.
///
/// Cuando ya no se necesita un valor, Rust ejecutará un "destructor" en ese valor.
/// La forma más común en la que un valor ya no es necesario es cuando se sale de su alcance.Los destructores pueden seguir funcionando en otras circunstancias, pero aquí nos centraremos en el alcance de los ejemplos.
/// Para conocer algunos de esos otros casos, consulte la sección [the reference] sobre destructores.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Este destructor consta de dos componentes:
/// - Una llamada a `Drop::drop` para ese valor, si se implementa este `Drop` trait especial para su tipo.
/// - El "drop glue" generado automáticamente que llama recursivamente a los destructores de todos los campos de este valor.
///
/// Como Rust llama automáticamente a los destructores de todos los campos contenidos, no es necesario implementar `Drop` en la mayoría de los casos.
/// Pero hay algunos casos en los que es útil, por ejemplo, para tipos que gestionan directamente un recurso.
/// Ese recurso puede ser memoria, puede ser un descriptor de archivo, puede ser un conector de red.
/// Una vez que un valor de ese tipo ya no se va a utilizar, debería "clean up" su recurso liberando la memoria o cerrando el archivo o socket.
/// Este es el trabajo de un destructor y, por lo tanto, el trabajo de `Drop::drop`.
///
/// ## Examples
///
/// Para ver los destructores en acción, echemos un vistazo al siguiente programa:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust primero llamará a `Drop::drop` para `_x` y luego para `_x.one` y `_x.two`, lo que significa que ejecutar esto imprimirá
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Incluso si eliminamos la implementación de `Drop` para `HasTwoDrop`, los destructores de sus campos aún se llaman.
/// Esto daría como resultado
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## No puede llamar a `Drop::drop` usted mismo
///
/// Debido a que `Drop::drop` se usa para limpiar un valor, puede ser peligroso usar este valor después de que se haya llamado al método.
/// Como `Drop::drop` no se apropia de su entrada, Rust evita el uso indebido al no permitirle llamar directamente a `Drop::drop`.
///
/// En otras palabras, si intenta llamar explícitamente a `Drop::drop` en el ejemplo anterior, obtendrá un error del compilador.
///
/// Si desea llamar explícitamente al destructor de un valor, se puede usar [`mem::drop`] en su lugar.
///
/// [`mem::drop`]: drop
///
/// ## Orden de gota
///
/// Sin embargo, ¿cuál de nuestros dos `HasDrop` cae primero?Para las estructuras, es el mismo orden en que se declaran: primero `one`, luego `two`.
/// Si desea probar esto usted mismo, puede modificar `HasDrop` anterior para que contenga algunos datos, como un número entero, y luego usarlo en el `println!` dentro de `Drop`.
/// Este comportamiento está garantizado por el idioma.
///
/// A diferencia de las estructuras, las variables locales se eliminan en orden inverso:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Esto imprimirá
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Consulte [the reference] para conocer las reglas completas.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` y `Drop` son exclusivos
///
/// No puede implementar tanto [`Copy`] como `Drop` en el mismo tipo.Los tipos que son `Copy` son duplicados implícitamente por el compilador, lo que hace que sea muy difícil predecir cuándo y con qué frecuencia se ejecutarán los destructores.
///
/// Como tal, estos tipos no pueden tener destructores.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Ejecuta el destructor para este tipo.
    ///
    /// Este método se llama implícitamente cuando el valor sale del alcance y no se puede llamar explícitamente (este es el error del compilador [E0040]).
    /// Sin embargo, la función [`mem::drop`] en prelude se puede usar para llamar a la implementación `Drop` del argumento.
    ///
    /// Cuando se ha llamado a este método, `self` aún no se ha desasignado.
    /// Eso solo sucede después de que termina el método.
    /// Si este no fuera el caso, `self` sería una referencia pendiente.
    ///
    /// # Panics
    ///
    /// Dado que un [`panic!`] llamará a `drop` a medida que se desenrolla, es probable que cualquier [`panic!`] en una implementación de `drop` se anule.
    ///
    /// Tenga en cuenta que incluso si este panics, el valor se considera descartado;
    /// no debe hacer que se vuelva a llamar a `drop`.
    /// Esto normalmente lo maneja el compilador automáticamente, pero cuando se usa código inseguro, a veces puede ocurrir de manera involuntaria, particularmente cuando se usa [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}