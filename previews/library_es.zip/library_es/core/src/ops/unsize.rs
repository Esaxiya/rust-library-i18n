use crate::marker::Unsize;

/// Trait que indica que se trata de un puntero o un contenedor para uno, donde se puede realizar un cambio de tamaño en el puntero.
///
/// Consulte [DST coercion RFC][dst-coerce] y [the nomicon entry on coercion][nomicon-coerce] para obtener más detalles.
///
/// Para los tipos de punteros incorporados, los punteros a `T` forzarán a los punteros a `U` si `T: Unsize<U>` mediante la conversión de un puntero delgado a un puntero grueso.
///
/// Para los tipos personalizados, la coerción aquí funciona coaccionando `Foo<T>` a `Foo<U>` siempre que exista una impl de `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Una implícita de este tipo solo se puede escribir si `Foo<T>` tiene solo un campo no fantasma que involucre a `T`.
/// Si el tipo de ese campo es `Bar<T>`, debe existir una implementación de `CoerceUnsized<Bar<U>> for Bar<T>`.
/// La coerción funcionará coaccionando el campo `Bar<T>` en `Bar<U>` y completando el resto de los campos de `Foo<T>` para crear un `Foo<U>`.
/// Esto efectivamente profundizará en un campo de puntero y lo forzará.
///
/// Generalmente, para los punteros inteligentes, implementará `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, con un `?Sized` opcional enlazado en el propio `T`.
/// Para los tipos de envoltura que incrustan directamente `T` como `Cell<T>` y `RefCell<T>`, puede implementar directamente `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Esto permitirá que funcionen coacciones de tipos como `Cell<Box<T>>`.
///
/// [`Unsize`][unsize] se utiliza para marcar tipos que pueden ser coaccionados a DST si están detrás de punteros.Es implementado automáticamente por el compilador.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Esto se utiliza para la seguridad de los objetos, para comprobar que se puede enviar el tipo de receptor de un método.
///
/// Una implementación de ejemplo de trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}