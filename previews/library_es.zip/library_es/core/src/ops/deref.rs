/// Se utiliza para operaciones de desreferenciación inmutables, como `*v`.
///
/// Además de utilizarse para operaciones explícitas de desreferenciación con el operador (unary) `*` en contextos inmutables, el compilador también utiliza implícitamente `Deref` en muchas circunstancias.
/// Este mecanismo se llama ['`Deref` coercion'][more].
/// En contextos mutables, se utiliza [`DerefMut`].
///
/// La implementación de `Deref` para punteros inteligentes hace que el acceso a los datos detrás de ellos sea conveniente, por lo que implementan `Deref`.
/// Por otro lado, las reglas relativas a `Deref` y [`DerefMut`] se diseñaron específicamente para adaptarse a los punteros inteligentes.
/// Debido a esto,**`Deref` solo debe implementarse para punteros inteligentes** para evitar confusiones.
///
/// Por razones similares,**este trait nunca debería fallar**.La falla durante la eliminación de referencias puede ser extremadamente confusa cuando `Deref` se invoca implícitamente.
///
/// # Más sobre la coerción `Deref`
///
/// Si `T` implementa `Deref<Target = U>` y `x` es un valor de tipo `T`, entonces:
///
/// * En contextos inmutables, `*x` (donde `T` no es ni una referencia ni un puntero sin formato) es equivalente a `* Deref::deref(&x)`.
/// * Los valores del tipo `&T` se convierten en valores del tipo `&U`.
/// * `T` implementa implícitamente todos los métodos (immutable) del tipo `U`.
///
/// Para obtener más detalles, visite [the chapter in *The Rust Programming Language*][book], así como las secciones de referencia sobre [the dereference operator][ref-deref-op], [method resolution] y [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Una estructura con un solo campo al que se puede acceder desreferenciando la estructura.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// El tipo resultante después de desreferenciar.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Desreferencia el valor.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Se utiliza para operaciones de eliminación de referencias mutables, como en `*v = 1;`.
///
/// Además de utilizarse para operaciones explícitas de eliminación de referencias con el operador (unary) `*` en contextos mutables, el compilador también utiliza implícitamente `DerefMut` en muchas circunstancias.
/// Este mecanismo se llama ['`Deref` coercion'][more].
/// En contextos inmutables, se utiliza [`Deref`].
///
/// La implementación de `DerefMut` para punteros inteligentes hace que la mutación de los datos detrás de ellos sea conveniente, por lo que implementan `DerefMut`.
/// Por otro lado, las reglas relativas a [`Deref`] y `DerefMut` se diseñaron específicamente para adaptarse a los punteros inteligentes.
/// Debido a esto,**`DerefMut` solo debe implementarse para punteros inteligentes** para evitar confusiones.
///
/// Por razones similares,**este trait nunca debería fallar**.La falla durante la eliminación de referencias puede ser extremadamente confusa cuando se invoca implícitamente `DerefMut`.
///
/// # Más sobre la coerción `Deref`
///
/// Si `T` implementa `DerefMut<Target = U>` y `x` es un valor de tipo `T`, entonces:
///
/// * En contextos mutables, `*x` (donde `T` no es ni una referencia ni un puntero sin formato) es equivalente a `* DerefMut::deref_mut(&mut x)`.
/// * Los valores del tipo `&mut T` se convierten en valores del tipo `&mut U`.
/// * `T` implementa implícitamente todos los métodos (mutable) del tipo `U`.
///
/// Para obtener más detalles, visite [the chapter in *The Rust Programming Language*][book], así como las secciones de referencia sobre [the dereference operator][ref-deref-op], [method resolution] y [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Una estructura con un solo campo que se puede modificar desreferenciando la estructura.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Desreferencia mutablemente el valor.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Indica que una estructura se puede utilizar como receptor de método, sin la función `arbitrary_self_types`.
///
/// Esto se implementa mediante tipos de puntero stdlib como `Box<T>`, `Rc<T>`, `&T` y `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}