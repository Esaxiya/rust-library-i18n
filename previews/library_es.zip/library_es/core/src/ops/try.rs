/// Un trait para personalizar el comportamiento del operador `?`.
///
/// Un tipo que implementa `Try` es uno que tiene una forma canónica de verlo en términos de una dicotomía success/failure.
/// Este trait permite extraer esos valores de éxito o fracaso de una instancia existente y crear una nueva instancia a partir de un valor de éxito o fracaso.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// El tipo de este valor cuando se considera correcto.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// El tipo de este valor cuando se ve como fallido.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Aplica el operador "?".Un retorno de `Ok(t)` significa que la ejecución debe continuar normalmente y el resultado de `?` es el valor `t`.
    /// Un retorno de `Err(e)` significa que la ejecución debe branch al `catch` que encierra más interno, o regresar de la función.
    ///
    /// Si se devuelve un resultado `Err(e)`, el valor `e` será "wrapped" en el tipo de retorno del alcance adjunto (que debe implementar `Try`).
    ///
    /// Específicamente, se devuelve el valor `X::from_error(From::from(e))`, donde `X` es el tipo de retorno de la función adjunta.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Envuelva un valor de error para construir el resultado compuesto.
    /// Por ejemplo, `Result::Err(x)` y `Result::from_error(x)` son equivalentes.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Envuelva un valor OK para construir el resultado compuesto.
    /// Por ejemplo, `Result::Ok(x)` y `Result::from_ok(x)` son equivalentes.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}