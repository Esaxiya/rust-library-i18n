/// La versión del operador de llamadas que toma un receptor inmutable.
///
/// Las instancias de `Fn` se pueden llamar repetidamente sin cambiar el estado.
///
/// *Este trait (`Fn`) no debe confundirse con [function pointers] (`fn`).*
///
/// `Fn` se implementa automáticamente mediante cierres que solo toman referencias inmutables a variables capturadas o no capturan nada en absoluto, así como (safe) [function pointers] (con algunas advertencias, consulte su documentación para obtener más detalles).
///
/// Además, para cualquier tipo `F` que implemente `Fn`, `&F` también implementa `Fn`.
///
/// Dado que tanto [`FnMut`] como [`FnOnce`] son superraits de `Fn`, cualquier instancia de `Fn` puede usarse como parámetro donde se espera [`FnMut`] o [`FnOnce`].
///
/// Utilice `Fn` como un límite cuando desee aceptar un parámetro de tipo de función y necesite llamarlo repetidamente y sin estado mutado (por ejemplo, al llamarlo al mismo tiempo).
/// Si no necesita requisitos tan estrictos, utilice [`FnMut`] o [`FnOnce`] como límites.
///
/// Consulte el [chapter on closures in *The Rust Programming Language*][book] para obtener más información sobre este tema.
///
/// También es de destacar la sintaxis especial para `Fn` traits (p. Ej.
/// `Fn(usize, bool) -> usize`).Aquellos interesados en los detalles técnicos de esto pueden referirse a [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Llamar a un cierre
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Usando un parámetro `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // para que regex pueda confiar en que `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Realiza la operación de llamada.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// La versión del operador de llamada que acepta un receptor mutable.
///
/// Las instancias de `FnMut` se pueden llamar repetidamente y pueden cambiar de estado.
///
/// `FnMut` se implementa automáticamente mediante cierres que toman referencias mutables a las variables capturadas, así como todos los tipos que implementan [`Fn`], por ejemplo, (safe) [function pointers] (ya que `FnMut` es un supertretrato de [`Fn`]).
/// Además, para cualquier tipo `F` que implemente `FnMut`, `&mut F` también implementa `FnMut`.
///
/// Dado que [`FnOnce`] es un superretrato de `FnMut`, se puede usar cualquier instancia de `FnMut` donde se espera un [`FnOnce`], y dado que [`Fn`] es un sustrato de `FnMut`, se puede usar cualquier instancia de [`Fn`] donde se espera `FnMut`.
///
/// Utilice `FnMut` como un límite cuando desee aceptar un parámetro de tipo de función y necesite llamarlo repetidamente, mientras le permite mutar el estado.
/// Si no desea que el parámetro cambie de estado, use [`Fn`] como límite;si no necesita llamarlo repetidamente, use [`FnOnce`].
///
/// Consulte el [chapter on closures in *The Rust Programming Language*][book] para obtener más información sobre este tema.
///
/// También es de destacar la sintaxis especial para `Fn` traits (p. Ej.
/// `Fn(usize, bool) -> usize`).Aquellos interesados en los detalles técnicos de esto pueden referirse a [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Llamar a un cierre de captura mutante
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Usando un parámetro `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // para que regex pueda confiar en que `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Realiza la operación de llamada.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// La versión del operador de llamadas que toma un receptor por valor.
///
/// Se pueden llamar instancias de `FnOnce`, pero es posible que no se puedan llamar varias veces.Por eso, si lo único que se sabe de un tipo es que implementa `FnOnce`, solo se puede llamar una vez.
///
/// `FnOnce` se implementa automáticamente mediante cierres que pueden consumir variables capturadas, así como todos los tipos que implementan [`FnMut`], por ejemplo, (safe) [function pointers] (ya que `FnOnce` es un supertretrato de [`FnMut`]).
///
///
/// Dado que tanto [`Fn`] como [`FnMut`] son sustracciones de `FnOnce`, se puede usar cualquier instancia de [`Fn`] o [`FnMut`] donde se espera un `FnOnce`.
///
/// Utilice `FnOnce` como límite cuando desee aceptar un parámetro de tipo función y solo necesite llamarlo una vez.
/// Si necesita llamar al parámetro repetidamente, use [`FnMut`] como límite;si también lo necesita para no mutar el estado, use [`Fn`].
///
/// Consulte el [chapter on closures in *The Rust Programming Language*][book] para obtener más información sobre este tema.
///
/// También es de destacar la sintaxis especial para `Fn` traits (p. Ej.
/// `Fn(usize, bool) -> usize`).Aquellos interesados en los detalles técnicos de esto pueden referirse a [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Usando un parámetro `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` consume sus variables capturadas, por lo que no se puede ejecutar más de una vez.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Intentar invocar `func()` nuevamente arrojará un error `use of moved value` para `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ya no se puede invocar en este momento
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // para que regex pueda confiar en que `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// El tipo devuelto después de que se utiliza el operador de llamada.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Realiza la operación de llamada.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}