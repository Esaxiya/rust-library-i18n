//! Operadores recargables.
//!
//! La implementación de estos traits le permite sobrecargar a ciertos operadores.
//!
//! Algunos de estos traits son importados por prelude, por lo que están disponibles en todos los programas Rust.Solo los operadores respaldados por traits pueden estar sobrecargados.
//! Por ejemplo, el operador de suma (`+`) se puede sobrecargar a través de [`Add`] trait, pero dado que el operador de asignación (`=`) no tiene trait de respaldo, no hay forma de sobrecargar su semántica.
//! Además, este módulo no proporciona ningún mecanismo para crear nuevos operadores.
//! Si se requieren operadores personalizados o sobrecarga sin rasgos, debe buscar macros o complementos del compilador para extender la sintaxis de Rust.
//!
//! Las implementaciones del operador traits no deberían sorprender en sus respectivos contextos, teniendo en cuenta sus significados habituales y [operator precedence].
//! Por ejemplo, al implementar [`Mul`], la operación debe tener cierto parecido con la multiplicación (y compartir propiedades esperadas como la asociatividad).
//!
//! Tenga en cuenta que los operadores `&&` y `||` cortocircuitan, es decir, solo evalúan su segundo operando si contribuye al resultado.Dado que traits no puede hacer cumplir este comportamiento, `&&` y `||` no se admiten como operadores sobrecargas.
//!
//! Muchos de los operadores toman sus operandos por valor.En contextos no genéricos que involucran tipos integrados, esto no suele ser un problema.
//! Sin embargo, el uso de estos operadores en código genérico requiere cierta atención si los valores deben reutilizarse en lugar de dejar que los operadores los consuman.Una opción es utilizar ocasionalmente [`clone`].
//! Otra opción es confiar en los tipos involucrados que proporcionan implementaciones de operador adicionales para referencias.
//! Por ejemplo, para un tipo `T` definido por el usuario que se supone que admite la adición, probablemente sea una buena idea que tanto `T` como `&T` implementen traits [`Add<T>`][`Add`] y [`Add<&T>`][`Add`] para que el código genérico se pueda escribir sin clonación innecesaria.
//!
//!
//! # Examples
//!
//! Este ejemplo crea una estructura `Point` que implementa [`Add`] y [`Sub`], y luego demuestra sumar y restar dos `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Consulte la documentación de cada trait para ver una implementación de ejemplo.
//!
//! [`Fn`], [`FnMut`] y [`FnOnce`] traits se implementan por tipos que se pueden invocar como funciones.Tenga en cuenta que [`Fn`] toma `&self`, [`FnMut`] toma `&mut self` y [`FnOnce`] toma `self`.
//! Estos corresponden a los tres tipos de métodos que se pueden invocar en una instancia: llamada por referencia, llamada por referencia mutable y llamada por valor.
//! El uso más común de estos traits es actuar como límites a funciones de nivel superior que toman funciones o cierres como argumentos.
//!
//! Tomando un [`Fn`] como parámetro:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Tomando un [`FnMut`] como parámetro:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Tomando un [`FnOnce`] como parámetro:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` consume sus variables capturadas, por lo que no se puede ejecutar más de una vez
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Intentar invocar `func()` nuevamente arrojará un error `use of moved value` para `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ya no se puede invocar en este momento
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;