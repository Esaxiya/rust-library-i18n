use crate::marker::Unpin;
use crate::pin::Pin;

/// El resultado de la reanudación de un generador.
///
/// Esta enumeración se devuelve del método `Generator::resume` e indica los posibles valores de retorno de un generador.
/// Actualmente, esto corresponde a un punto de suspensión (`Yielded`) o un punto de terminación (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// El generador suspendido con un valor.
    ///
    /// Este estado indica que se ha suspendido un generador y, por lo general, corresponde a una declaración `yield`.
    /// El valor proporcionado en esta variante corresponde a la expresión pasada a `yield` y permite a los generadores proporcionar un valor cada vez que ceden.
    ///
    ///
    Yielded(Y),

    /// El generador se completó con un valor de retorno.
    ///
    /// Este estado indica que un generador ha finalizado la ejecución con el valor proporcionado.
    /// Una vez que un generador ha devuelto `Complete`, se considera un error del programador volver a llamar a `resume`.
    ///
    Complete(R),
}

/// El trait implementado por tipos de generadores incorporados.
///
/// Los generadores, también conocidos como corrutinas, son actualmente una característica de lenguaje experimental en Rust.
/// Los generadores agregados en [RFC 2033] actualmente están destinados principalmente a proporcionar un bloque de construcción para la sintaxis async/await, pero probablemente se extenderán para proporcionar también una definición ergonómica para iteradores y otras primitivas.
///
///
/// La sintaxis y la semántica de los generadores es inestable y requerirá un RFC adicional para la estabilización.En este momento, sin embargo, la sintaxis es similar a una clausura:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Se puede encontrar más documentación sobre generadores en el libro inestable.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// El tipo de valor que produce este generador.
    ///
    /// Este tipo asociado corresponde a la expresión `yield` y los valores que se pueden devolver cada vez que cede un generador.
    ///
    /// Por ejemplo, un iterador como generador probablemente tendría este tipo como `T`, el tipo que se está iterando.
    ///
    type Yield;

    /// El tipo de valor que devuelve este generador.
    ///
    /// Esto corresponde al tipo devuelto por un generador, ya sea con una instrucción `return` o implícitamente como la última expresión de un literal de generador.
    /// Por ejemplo, futures usaría esto como `Result<T, E>` ya que representa un future completo.
    ///
    ///
    type Return;

    /// Reanuda la ejecución de este generador.
    ///
    /// Esta función reanudará la ejecución del generador o iniciará la ejecución si aún no lo ha hecho.
    /// Esta llamada volverá al último punto de suspensión del generador, reanudando la ejecución desde el último `yield`.
    /// El generador continuará ejecutándose hasta que ceda o regrese, momento en el que esta función regresará.
    ///
    /// # Valor devuelto
    ///
    /// La enumeración `GeneratorState` devuelta por esta función indica en qué estado se encuentra el generador al regresar.
    /// Si se devuelve la variante `Yielded`, el generador ha alcanzado un punto de suspensión y se ha obtenido un valor.
    /// Los generadores en este estado están disponibles para reanudarse en un momento posterior.
    ///
    /// Si se devuelve `Complete`, el generador ha terminado por completo con el valor proporcionado.No es válido que el generador se reanude nuevamente.
    ///
    /// # Panics
    ///
    /// Esta función puede panic si se llama después de que se haya devuelto previamente la variante `Complete`.
    /// Si bien los literales del generador en el lenguaje están garantizados para panic al reanudarse después de `Complete`, esto no está garantizado para todas las implementaciones de `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}