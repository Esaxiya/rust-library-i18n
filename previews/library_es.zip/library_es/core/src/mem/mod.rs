//! Funciones básicas para lidiar con la memoria.
//!
//! Este módulo contiene funciones para consultar el tamaño y alineación de tipos, inicializar y manipular la memoria.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Toma propiedad y "forgets" sobre el valor **sin ejecutar su destructor**.
///
/// Cualquier recurso que gestione el valor, como la memoria de pila o un identificador de archivo, permanecerá para siempre en un estado inalcanzable.Sin embargo, no garantiza que los punteros a esta memoria sigan siendo válidos.
///
/// * Si desea perder memoria, consulte [`Box::leak`].
/// * Si desea obtener un puntero sin formato a la memoria, consulte [`Box::into_raw`].
/// * Si desea deshacerse de un valor correctamente, ejecutando su destructor, consulte [`mem::drop`].
///
/// # Safety
///
/// `forget` no está marcado como `unsafe`, porque las garantías de seguridad de Rust no incluyen una garantía de que los destructores siempre se ejecutarán.
/// Por ejemplo, un programa puede crear un ciclo de referencia usando [`Rc`][rc] o llamar a [`process::exit`][exit] para salir sin ejecutar destructores.
/// Por lo tanto, permitir `mem::forget` desde un código seguro no cambia fundamentalmente las garantías de seguridad de Rust.
///
/// Dicho esto, la fuga de recursos como la memoria u objetos I/O generalmente no es deseable.
/// En algunos casos de uso especializado surge la necesidad de FFI o código inseguro, pero incluso entonces, generalmente se prefiere [`ManuallyDrop`].
///
/// Debido a que se permite olvidar un valor, cualquier código `unsafe` que escriba debe permitir esta posibilidad.No puede devolver un valor y esperar que el llamador ejecute necesariamente el destructor del valor.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// El uso canónico seguro de `mem::forget` es eludir el destructor de un valor implementado por `Drop` trait.Por ejemplo, esto filtrará un `File`, es decir
/// Recupere el espacio ocupado por la variable pero nunca cierre el recurso del sistema subyacente:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Esto es útil cuando la propiedad del recurso subyacente se transfirió previamente a un código fuera de Rust, por ejemplo, transmitiendo el descriptor de archivo sin procesar al código C.
///
/// # Relación con `ManuallyDrop`
///
/// Si bien `mem::forget` también se puede usar para transferir la propiedad de *memoria*, hacerlo es propenso a errores.
/// [`ManuallyDrop`] debe utilizarse en su lugar.Considere, por ejemplo, este código:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Construye un `String` usando el contenido de `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // filtrar `v` porque su memoria ahora es administrada por `s`
/// mem::forget(v);  // ERROR, v no es válido y no debe pasarse a una función
/// assert_eq!(s, "Az");
/// // `s` se descarta implícitamente y se desasigna su memoria.
/// ```
///
/// Hay dos problemas con el ejemplo anterior:
///
/// * Si se agregara más código entre la construcción de `String` y la invocación de `mem::forget()`, un panic dentro de él causaría un doble libre porque la misma memoria es manejada tanto por `v` como por `s`.
/// * Después de llamar a `v.as_mut_ptr()` y transmitir la propiedad de los datos a `s`, el valor de `v` no es válido.
/// Incluso cuando un valor simplemente se mueve a `mem::forget` (que no lo inspecciona), algunos tipos tienen requisitos estrictos sobre sus valores que los hacen inválidos cuando están colgados o ya no son de su propiedad.
/// El uso de valores no válidos de cualquier manera, incluido pasarlos o devolverlos desde funciones, constituye un comportamiento indefinido y puede romper las suposiciones hechas por el compilador.
///
/// Cambiar a `ManuallyDrop` evita ambos problemas:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Antes de desmontar el `v` en sus partes en bruto, ¡asegúrese de que no se caiga!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Ahora desmonte `v`.Estas operaciones no pueden panic, por lo que no puede haber una fuga.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Finalmente, construya un `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` se descarta implícitamente y se desasigna su memoria.
/// ```
///
/// `ManuallyDrop` previene robustamente el doble libre porque deshabilitamos el destructor de `v` antes de hacer cualquier otra cosa.
/// `mem::forget()` no permite esto porque consume su argumento, lo que nos obliga a llamarlo solo después de extraer cualquier cosa que necesitemos de `v`.
/// Incluso si se introdujera un panic entre la construcción de `ManuallyDrop` y la construcción de la cadena (lo que no puede suceder en el código como se muestra), resultaría en una fuga y no un doble libre.
/// En otras palabras, `ManuallyDrop` se equivoca por el lado de la fuga en lugar de por el lado de la (doble) caída.
///
/// Además, `ManuallyDrop` evita que tengamos que "touch" `v` después de transferir la propiedad a `s`; el paso final de interactuar con `v` para deshacerse de él sin ejecutar su destructor se evita por completo.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Como [`forget`], pero también acepta valores sin tamaño.
///
/// Esta función es solo una cuña que debe quitarse cuando la función `unsized_locals` se estabilice.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Devuelve el tamaño de un tipo en bytes.
///
/// Más específicamente, este es el desplazamiento en bytes entre elementos sucesivos en una matriz con ese tipo de elemento, incluido el relleno de alineación.
///
/// Por tanto, para cualquier tipo `T` y longitud `n`, `[T; n]` tiene un tamaño de `n * size_of::<T>()`.
///
/// En general, el tamaño de un tipo no es estable en todas las compilaciones, pero los tipos específicos, como las primitivas, sí lo son.
///
/// La siguiente tabla muestra el tamaño de las primitivas.
///
/// Tipo |tamaño de: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Además, `usize` y `isize` tienen el mismo tamaño.
///
/// Los tipos `*const T`, `&T`, `Box<T>`, `Option<&T>` y `Option<Box<T>>` tienen todos el mismo tamaño.
/// Si `T` es de tamaño, todos esos tipos tienen el mismo tamaño que `usize`.
///
/// La mutabilidad de un puntero no cambia su tamaño.Como tal, `&T` y `&mut T` tienen el mismo tamaño.
/// Lo mismo ocurre con `*const T` y `* mut T`.
///
/// # Tamaño de los elementos `#[repr(C)]`
///
/// La representación `C` para artículos tiene un diseño definido.
/// Con este diseño, el tamaño de los elementos también es estable siempre que todos los campos tengan un tamaño estable.
///
/// ## Tamaño de las estructuras
///
/// Para `structs`, el tamaño se determina mediante el siguiente algoritmo.
///
/// Para cada campo de la estructura ordenado por orden de declaración:
///
/// 1. Agrega el tamaño del campo.
/// 2. Redondea el tamaño actual al múltiplo más cercano del [alignment] del siguiente campo.
///
/// Finalmente, redondee el tamaño de la estructura al múltiplo más cercano de su [alignment].
/// La alineación de la estructura suele ser la alineación más grande de todos sus campos;esto se puede cambiar con el uso de `repr(align(N))`.
///
/// A diferencia de `C`, las estructuras de tamaño cero no se redondean a un tamaño de un byte.
///
/// ## Tamaño de las enumeraciones
///
/// Las enumeraciones que no contienen más datos que el discriminante tienen el mismo tamaño que las enumeraciones C en la plataforma para la que se compilan.
///
/// ## Tamaño de los sindicatos
///
/// El tamaño de una unión es el tamaño de su campo más grande.
///
/// A diferencia de `C`, las uniones de tamaño cero no se redondean a un tamaño de un byte.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Algunos primitivos
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Algunas matrices
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Igualdad de tamaño de puntero
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Usando `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // El tamaño del primer campo es 1, así que agregue 1 al tamaño.El tamaño es 1.
/// // La alineación del segundo campo es 2, así que agregue 1 al tamaño para el relleno.El tamaño es 2.
/// // El tamaño del segundo campo es 2, así que agregue 2 al tamaño.El tamaño es 4.
/// // La alineación del tercer campo es 1, así que agregue 0 al tamaño para el relleno.El tamaño es 4.
/// // El tamaño del tercer campo es 1, así que agregue 1 al tamaño.El tamaño es 5.
/// // Finalmente, la alineación de la estructura es 2 (porque la alineación más grande entre sus campos es 2), así que agregue 1 al tamaño para el relleno.
/// // El tamaño es 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Las estructuras de tupla siguen las mismas reglas.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Tenga en cuenta que reordenar los campos puede reducir el tamaño.
/// // Podemos eliminar ambos bytes de relleno poniendo `third` antes de `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // El tamaño de la unión es el tamaño del campo más grande.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Devuelve el tamaño del valor apuntado en bytes.
///
/// Suele ser lo mismo que `size_of::<T>()`.
/// Sin embargo, cuando `T`*no tiene* un tamaño conocido estáticamente, por ejemplo, un corte [`[T]`][slice] o [trait object], entonces `size_of_val` puede usarse para obtener el tamaño conocido dinámicamente.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURIDAD: `val` es una referencia, por lo que es un puntero sin formato válido
    unsafe { intrinsics::size_of_val(val) }
}

/// Devuelve el tamaño del valor apuntado en bytes.
///
/// Suele ser lo mismo que `size_of::<T>()`.Sin embargo, cuando `T`*no tiene* un tamaño conocido estáticamente, por ejemplo, un corte [`[T]`][slice] o [trait object], entonces `size_of_val_raw` puede usarse para obtener el tamaño conocido dinámicamente.
///
/// # Safety
///
/// Solo es seguro llamar a esta función si se cumplen las siguientes condiciones:
///
/// - Si `T` es `Sized`, siempre es seguro llamar a esta función.
/// - Si la cola sin tamaño de `T` es:
///     - a [slice], entonces la longitud de la cola del segmento debe ser un número entero inicializado y el tamaño del *valor completo*(longitud de cola dinámica + prefijo de tamaño estático) debe caber en `isize`.
///     - a [trait object], entonces la parte vtable del puntero debe apuntar a una vtable válida adquirida por una coerción sin tamaño, y el tamaño del *valor completo*(longitud de cola dinámica + prefijo de tamaño estático) debe caber en `isize`.
///
///     - un (unstable) [extern type], entonces esta función siempre es segura para llamar, pero puede panic o devolver el valor incorrecto, ya que no se conoce el diseño del tipo externo.
///     Este es el mismo comportamiento que [`size_of_val`] en una referencia a un tipo con una cola de tipo externo.
///     - de lo contrario, no se permite de forma conservadora llamar a esta función.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SEGURIDAD: la persona que llama debe proporcionar un puntero sin formato válido
    unsafe { intrinsics::size_of_val(val) }
}

/// Devuelve la alineación mínima requerida por [ABI] de un tipo.
///
/// Toda referencia a un valor del tipo `T` debe ser un múltiplo de este número.
///
/// Esta es la alineación utilizada para los campos de estructura.Puede ser más pequeño que la alineación preferida.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Devuelve la alineación mínima requerida por [ABI] del tipo de valor al que apunta `val`.
///
/// Toda referencia a un valor del tipo `T` debe ser un múltiplo de este número.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURIDAD: val es una referencia, por lo que es un puntero sin formato válido
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Devuelve la alineación mínima requerida por [ABI] de un tipo.
///
/// Toda referencia a un valor del tipo `T` debe ser un múltiplo de este número.
///
/// Esta es la alineación utilizada para los campos de estructura.Puede ser más pequeño que la alineación preferida.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Devuelve la alineación mínima requerida por [ABI] del tipo de valor al que apunta `val`.
///
/// Toda referencia a un valor del tipo `T` debe ser un múltiplo de este número.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURIDAD: val es una referencia, por lo que es un puntero sin formato válido
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Devuelve la alineación mínima requerida por [ABI] del tipo de valor al que apunta `val`.
///
/// Toda referencia a un valor del tipo `T` debe ser un múltiplo de este número.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Solo es seguro llamar a esta función si se cumplen las siguientes condiciones:
///
/// - Si `T` es `Sized`, siempre es seguro llamar a esta función.
/// - Si la cola sin tamaño de `T` es:
///     - a [slice], entonces la longitud de la cola del segmento debe ser un número entero inicializado y el tamaño del *valor completo*(longitud de cola dinámica + prefijo de tamaño estático) debe caber en `isize`.
///     - a [trait object], entonces la parte vtable del puntero debe apuntar a una vtable válida adquirida por una coerción sin tamaño, y el tamaño del *valor completo*(longitud de cola dinámica + prefijo de tamaño estático) debe caber en `isize`.
///
///     - un (unstable) [extern type], entonces esta función siempre es segura para llamar, pero puede panic o devolver el valor incorrecto, ya que no se conoce el diseño del tipo externo.
///     Este es el mismo comportamiento que [`align_of_val`] en una referencia a un tipo con una cola de tipo externo.
///     - de lo contrario, no se permite de forma conservadora llamar a esta función.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SEGURIDAD: la persona que llama debe proporcionar un puntero sin formato válido
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Devuelve `true` si es importante eliminar valores de tipo `T`.
///
/// Esto es puramente una sugerencia de optimización y se puede implementar de forma conservadora:
/// puede devolver `true` para tipos que en realidad no necesitan descartarse.
/// Como tal, devolver siempre `true` sería una implementación válida de esta función.Sin embargo, si esta función realmente devuelve `false`, entonces puede estar seguro de que eliminar `T` no tiene efectos secundarios.
///
/// Las implementaciones de bajo nivel de cosas como colecciones, que necesitan eliminar manualmente sus datos, deben usar esta función para evitar intentar eliminar innecesariamente todo su contenido cuando se destruyen.
///
/// Es posible que esto no haga una diferencia en las compilaciones de lanzamiento (donde un bucle que no tiene efectos secundarios se detecta y elimina fácilmente), pero a menudo es una gran ventaja para las compilaciones de depuración.
///
/// Tenga en cuenta que [`drop_in_place`] ya realiza esta comprobación, por lo que si su carga de trabajo se puede reducir a una pequeña cantidad de llamadas [`drop_in_place`], no es necesario utilizarla.
/// En particular, tenga en cuenta que puede [`drop_in_place`] una porción, y eso hará una sola verificación de need_drop para todos los valores.
///
/// Tipos como Vec, por lo tanto, solo `drop_in_place(&mut self[..])` sin usar `needs_drop` explícitamente.
/// Los tipos como [`HashMap`], por otro lado, tienen que eliminar los valores uno a la vez y deben usar esta API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// A continuación, se muestra un ejemplo de cómo una colección podría hacer uso de `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // soltar los datos
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Devuelve el valor de tipo `T` representado por el patrón de bytes todo cero.
///
/// Esto significa que, por ejemplo, el byte de relleno en `(u8, u16)` no necesariamente se pone a cero.
///
/// No hay garantía de que un patrón de bytes todo cero represente un valor válido de algún tipo `T`.
/// Por ejemplo, el patrón de bytes todo-cero no es un valor válido para tipos de referencia (`&T`, `&mut T`) y punteros de funciones.
/// El uso de `zeroed` en tales tipos provoca [undefined behavior][ub] inmediato porque [the Rust compiler assumes][inv] que siempre hay un valor válido en una variable que considera inicializada.
///
///
/// Esto tiene el mismo efecto que [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// A veces es útil para FFI, pero generalmente debe evitarse.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Uso correcto de esta función: inicializar un número entero con cero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Uso incorrecto* de esta función: inicializar una referencia con cero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Comportamiento indefinido!
/// let _y: fn() = unsafe { mem::zeroed() }; // ¡Y otra vez!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SEGURIDAD: la persona que llama debe garantizar que un valor todo cero es válido para `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Omite las comprobaciones normales de inicialización de memoria de Rust pretendiendo producir un valor de tipo `T`, sin hacer nada en absoluto.
///
/// **Esta función está obsoleta.** Utilice [`MaybeUninit<T>`] en su lugar.
///
/// El motivo de la desaprobación es que la función básicamente no se puede utilizar correctamente: tiene el mismo efecto que [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Como explica el [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] que los valores se inicializan correctamente.
/// Como consecuencia, llamar, por ejemplo,
/// `mem::uninitialized::<bool>()` provoca un comportamiento inmediato indefinido para devolver un `bool` que no es definitivamente `true` o `false`.
/// Peor aún, la memoria verdaderamente no inicializada como la que se devuelve aquí es especial porque el compilador sabe que no tiene un valor fijo.
/// Esto hace que sea un comportamiento indefinido tener datos sin inicializar en una variable incluso si esa variable tiene un tipo entero.
/// (Tenga en cuenta que las reglas sobre los enteros no inicializados aún no están finalizadas, pero hasta que lo estén, es aconsejable evitarlas).
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SEGURIDAD: la persona que llama debe garantizar que un valor unificado sea válido para `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Intercambia los valores en dos ubicaciones mutables, sin desinicializar ninguna.
///
/// * Si desea intercambiar con un valor predeterminado o ficticio, consulte [`take`].
/// * Si desea intercambiar con un valor pasado, devolviendo el valor anterior, consulte [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SEGURIDAD: los punteros en bruto se han creado a partir de referencias mutables seguras que satisfacen todas las
    // restricciones en `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Reemplaza `dest` con el valor predeterminado de `T`, devolviendo el valor `dest` anterior.
///
/// * Si desea reemplazar los valores de dos variables, consulte [`swap`].
/// * Si desea reemplazar con un valor pasado en lugar del valor predeterminado, consulte [`replace`].
///
/// # Examples
///
/// Un simple ejemplo:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` permite tomar posesión de un campo de estructura reemplazándolo con un valor "empty".
/// Sin `take`, puede encontrarse con problemas como estos:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Tenga en cuenta que `T` no necesariamente implementa [`Clone`], por lo que ni siquiera puede clonar y restablecer `self.buf`.
/// Pero `take` se puede usar para disociar el valor original de `self.buf` de `self`, lo que permite que se devuelva:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Mueve `src` al `dest` referenciado, devolviendo el valor `dest` anterior.
///
/// No se descarta ningún valor.
///
/// * Si desea reemplazar los valores de dos variables, consulte [`swap`].
/// * Si desea reemplazarlo con un valor predeterminado, consulte [`take`].
///
/// # Examples
///
/// Un simple ejemplo:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` permite el consumo de un campo de estructura reemplazándolo con otro valor.
/// Sin `replace`, puede encontrarse con problemas como estos:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Tenga en cuenta que `T` no necesariamente implementa [`Clone`], por lo que ni siquiera podemos clonar `self.buf[i]` para evitar el movimiento.
/// Pero `replace` se puede usar para disociar el valor original en ese índice de `self`, lo que permite que se devuelva:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SEGURIDAD: leemos de `dest` pero luego escribimos directamente `src` en él,
    // de modo que el valor anterior no se duplique.
    // Nada se deja caer y nada aquí puede panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Dispone de un valor.
///
/// Esto lo hace llamando a la implementación del argumento de [`Drop`][drop].
///
/// Esto efectivamente no hace nada para los tipos que implementan `Copy`, p. Ej.
/// integers.
/// Dichos valores se copian y _then_ se mueve a la función, por lo que el valor persiste después de esta llamada a la función.
///
///
/// Esta función no es mágica;se define literalmente como
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Debido a que `_x` se mueve a la función, se elimina automáticamente antes de que vuelva la función.
///
/// [drop]: Drop
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // soltar explícitamente el vector
/// ```
///
/// Dado que [`RefCell`] aplica las reglas de préstamo en tiempo de ejecución, `drop` puede liberar un préstamo [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // renunciar al préstamo mutable en esta ranura
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Los enteros y otros tipos que implementan [`Copy`] no se ven afectados por `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // una copia de `x` se mueve y se suelta
/// drop(y); // una copia de `y` se mueve y se suelta
///
/// println!("x: {}, y: {}", x, y.0); // aun disponible
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpreta que `src` tiene el tipo `&U` y luego lee `src` sin mover el valor contenido.
///
/// Esta función asumirá de manera insegura que el puntero `src` es válido para [`size_of::<U>`][size_of] bytes al transmutar `&T` a `&U` y luego leer el `&U` (excepto que esto se hace de una manera correcta incluso cuando `&U` tiene requisitos de alineación más estrictos que `&T`).
/// También creará de forma insegura una copia del valor contenido en lugar de salir de `src`.
///
/// No es un error en tiempo de compilación si `T` y `U` tienen tamaños diferentes, pero se recomienda encarecidamente invocar esta función solo cuando `T` y `U` tengan el mismo tamaño.Esta función activa [undefined behavior][ub] si `U` es mayor que `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Copie los datos de 'foo_array' y trátelos como 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Modificar los datos copiados
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // El contenido de 'foo_array' no debería haber cambiado
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Si U tiene un requisito de alineación más alto, es posible que src no esté alineado adecuadamente.
    if align_of::<U>() > align_of::<T>() {
        // SEGURIDAD: `src` es una referencia cuya validez se garantiza para las lecturas.
        // La persona que llama debe garantizar que la transmutación real sea segura.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SEGURIDAD: `src` es una referencia cuya validez se garantiza para las lecturas.
        // Acabamos de comprobar que `src as *const U` estuviera correctamente alineado.
        // La persona que llama debe garantizar que la transmutación real sea segura.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Tipo opaco que representa el discriminante de una enumeración.
///
/// Consulte la función [`discriminant`] en este módulo para obtener más información.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Estas implementaciones de trait no se pueden derivar porque no queremos límites en T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Devuelve un valor que identifica de forma única la variante de enumeración en `v`.
///
/// Si `T` no es una enumeración, llamar a esta función no dará como resultado un comportamiento indefinido, pero el valor de retorno no se especifica.
///
///
/// # Stability
///
/// El discriminante de una variante de enumeración puede cambiar si cambia la definición de enumeración.
/// Un discriminante de alguna variante no cambiará entre compilaciones con el mismo compilador.
///
/// # Examples
///
/// Esto se puede usar para comparar enumeraciones que contienen datos, sin tener en cuenta los datos reales:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Devuelve el número de variantes en el tipo de enumeración `T`.
///
/// Si `T` no es una enumeración, llamar a esta función no dará como resultado un comportamiento indefinido, pero el valor de retorno no se especifica.
/// Del mismo modo, si `T` es una enumeración con más variantes que `usize::MAX`, el valor de retorno no se especifica.
/// Se contarán las variantes deshabitadas.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}