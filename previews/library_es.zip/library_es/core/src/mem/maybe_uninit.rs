use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Un tipo de contenedor para construir instancias no inicializadas de `T`.
///
/// # Inicialización invariante
///
/// El compilador, en general, asume que una variable se inicializa correctamente de acuerdo con los requisitos del tipo de variable.Por ejemplo, una variable de tipo de referencia debe estar alineada y no ser NULL.
/// Este es un invariante que debe *siempre* mantenerse, incluso en código inseguro.
/// Como consecuencia, la inicialización cero de una variable de tipo de referencia provoca [undefined behavior][ub] instantáneo, sin importar si esa referencia se usa alguna vez para acceder a la memoria:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // comportamiento indefinido!⚠️
/// // El código equivalente con `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // comportamiento indefinido!⚠️
/// ```
///
/// El compilador explota esto para varias optimizaciones, como eludir las comprobaciones en tiempo de ejecución y optimizar el diseño de `enum`.
///
/// De manera similar, la memoria completamente no inicializada puede tener cualquier contenido, mientras que un `bool` siempre debe ser `true` o `false`.Por lo tanto, crear un `bool` no inicializado es un comportamiento indefinido:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // comportamiento indefinido!⚠️
/// // El código equivalente con `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // comportamiento indefinido!⚠️
/// ```
///
/// Además, la memoria no inicializada es especial porque no tiene un valor fijo ("fixed" significa "it won't change without being written to").Leer el mismo byte no inicializado varias veces puede dar resultados diferentes.
/// Esto hace que sea un comportamiento indefinido tener datos sin inicializar en una variable incluso si esa variable tiene un tipo entero, que de lo contrario puede contener cualquier patrón de bits *fijo*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // comportamiento indefinido!⚠️
/// // El código equivalente con `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // comportamiento indefinido!⚠️
/// ```
/// (Tenga en cuenta que las reglas sobre los enteros no inicializados aún no están finalizadas, pero hasta que lo estén, es aconsejable evitarlas).
///
/// Además de eso, recuerde que la mayoría de los tipos tienen invariantes adicionales además de ser considerados inicializados en el nivel de tipo.
/// Por ejemplo, un [`Vec<T>`] inicializado con `1` se considera inicializado (según la implementación actual; esto no constituye una garantía estable) porque el único requisito que el compilador conoce es que el puntero de datos no debe ser nulo.
/// La creación de un `Vec<T>` de este tipo no provoca un comportamiento indefinido *inmediato*, pero provocará un comportamiento indefinido con la mayoría de las operaciones seguras (incluida su eliminación).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` sirve para permitir que el código inseguro maneje datos no inicializados.
/// Es una señal para el compilador que indica que los datos aquí pueden *no* inicializarse:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Cree una referencia explícitamente no inicializada.
/// // El compilador sabe que los datos dentro de un `MaybeUninit<T>` pueden no ser válidos y, por lo tanto, esto no es UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Ajústelo a un valor válido.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Extraiga los datos inicializados; esto solo se permite *después* de inicializar correctamente `x`.
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// El compilador entonces sabe que no debe realizar suposiciones u optimizaciones incorrectas en este código.
///
/// Puede pensar en `MaybeUninit<T>` como un poco como `Option<T>` pero sin ningún seguimiento del tiempo de ejecución y sin ninguna de las comprobaciones de seguridad.
///
/// ## out-pointers
///
/// Puede usar `MaybeUninit<T>` para implementar "out-pointers": en lugar de devolver datos de una función, pase un puntero a alguna memoria (uninitialized) para colocar el resultado.
/// Esto puede ser útil cuando es importante para la persona que llama controlar cómo se asigna la memoria en la que se almacena el resultado y desea evitar movimientos innecesarios.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` no deja caer el contenido antiguo, lo cual es importante.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // ¡Ahora sabemos que `v` está inicializado!Esto también asegura que el vector se caiga correctamente.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inicializar una matriz elemento por elemento
///
/// `MaybeUninit<T>` se puede utilizar para inicializar una gran matriz elemento por elemento:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Cree una matriz no inicializada de `MaybeUninit`.
///     // El `assume_init` es seguro porque el tipo que afirmamos haber inicializado aquí es un grupo de `MaybeUninit`s, que no requieren inicialización.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Dejar caer un `MaybeUninit` no hace nada.
///     // Por lo tanto, el uso de la asignación de puntero sin formato en lugar de `ptr::write` no hace que se elimine el antiguo valor no inicializado.
/////
///     // Además, si hay un panic durante este bucle, tenemos una pérdida de memoria, pero no hay ningún problema de seguridad de la memoria.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Todo está inicializado.
///     // Transmutar la matriz al tipo inicializado.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// También puede trabajar con matrices parcialmente inicializadas, que se pueden encontrar en estructuras de datos de bajo nivel.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Cree una matriz no inicializada de `MaybeUninit`.
/// // El `assume_init` es seguro porque el tipo que afirmamos haber inicializado aquí es un grupo de `MaybeUninit`s, que no requieren inicialización.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Cuente el número de elementos que le hemos asignado.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Para cada elemento de la matriz, elimínelo si lo asignamos.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inicializar una estructura campo por campo
///
/// Puede usar `MaybeUninit<T>` y la macro [`std::ptr::addr_of_mut`] para inicializar estructuras campo por campo:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inicializando el campo `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inicialización del campo `list` Si hay un panic aquí, entonces el `String` en el campo `name` tiene fugas.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Todos los campos están inicializados, por lo que llamamos a `assume_init` para obtener un Foo inicializado.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` se garantiza que tiene el mismo tamaño, alineación y ABI que `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Sin embargo, recuerde que un tipo *que contiene* un `MaybeUninit<T>` no es necesariamente el mismo diseño;Rust no garantiza en general que los campos de un `Foo<T>` tengan el mismo orden que un `Foo<U>`, incluso si `T` y `U` tienen el mismo tamaño y alineación.
///
/// Además, debido a que cualquier valor de bit es válido para un `MaybeUninit<T>`, el compilador no puede aplicar optimizaciones non-zero/niche-filling, lo que puede resultar en un tamaño mayor:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Si `T` es seguro para FFI, entonces también lo es `MaybeUninit<T>`.
///
/// Si bien `MaybeUninit` es `#[repr(transparent)]` (lo que indica que garantiza el mismo tamaño, alineación y ABI que `T`), esto *no* cambia ninguna de las advertencias anteriores.
/// `Option<T>` y `Option<MaybeUninit<T>>` aún pueden tener diferentes tamaños, y los tipos que contienen un campo de tipo `T` pueden tener un diseño (y tamaño) diferente que si ese campo fuera `MaybeUninit<T>`.
/// `MaybeUninit` es un tipo de unión y `#[repr(transparent)]` en las uniones es inestable (consulte [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Con el tiempo, las garantías exactas de `#[repr(transparent)]` en las uniones pueden evolucionar, y `MaybeUninit` puede o no seguir siendo `#[repr(transparent)]`.
/// Dicho esto, `MaybeUninit<T>`*siempre* garantizará que tenga el mismo tamaño, alineación y ABI que `T`;es solo que la forma en que `MaybeUninit` implementa esa garantía puede evolucionar.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang para que podamos envolver otros tipos en él.Esto es útil para generadores.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Al no llamar a `T::clone()`, no podemos saber si estamos lo suficientemente inicializados para eso.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Crea un nuevo `MaybeUninit<T>` inicializado con el valor dado.
    /// Es seguro llamar a [`assume_init`] sobre el valor de retorno de esta función.
    ///
    /// Tenga en cuenta que soltar un `MaybeUninit<T>` nunca llamará el código de caída de `T`.
    /// Es su responsabilidad asegurarse de que `T` se descarte si se inicializó.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Crea un nuevo `MaybeUninit<T>` en un estado no inicializado.
    ///
    /// Tenga en cuenta que soltar un `MaybeUninit<T>` nunca llamará el código de caída de `T`.
    /// Es su responsabilidad asegurarse de que `T` se descarte si se inicializó.
    ///
    /// Consulte el [type-level documentation][MaybeUninit] para ver algunos ejemplos.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Cree una nueva matriz de elementos `MaybeUninit<T>`, en un estado no inicializado.
    ///
    /// Note: en una versión future Rust, este método puede volverse innecesario cuando la sintaxis literal de matriz permite [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// El siguiente ejemplo podría usar `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Devuelve una porción (posiblemente más pequeña) de datos que realmente se leyeron
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SEGURIDAD: Un `[MaybeUninit<_>; LEN]` no inicializado es válido.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Crea un nuevo `MaybeUninit<T>` en un estado no inicializado, con la memoria llena con `0` bytes.Depende de `T` si eso ya constituye una inicialización adecuada.
    ///
    /// Por ejemplo, `MaybeUninit<usize>::zeroed()` está inicializado, pero `MaybeUninit<&'static i32>::zeroed()` no porque las referencias no deben ser nulas.
    ///
    /// Tenga en cuenta que soltar un `MaybeUninit<T>` nunca llamará el código de caída de `T`.
    /// Es su responsabilidad asegurarse de que `T` se descarte si se inicializó.
    ///
    /// # Example
    ///
    /// Uso correcto de esta función: inicializar una estructura con cero, donde todos los campos de la estructura pueden contener el patrón de bits 0 como un valor válido.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Uso incorrecto* de esta función: llamar a `x.zeroed().assume_init()` cuando `0` no es un patrón de bits válido para el tipo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Dentro de un par, creamos un `NotZero` que no tiene un discriminante válido.
    /// // Este es un comportamiento indefinido.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SEGURIDAD: `u.as_mut_ptr()` apunta a la memoria asignada.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Establece el valor del `MaybeUninit<T>`.
    /// Esto sobrescribe cualquier valor anterior sin eliminarlo, así que tenga cuidado de no usarlo dos veces a menos que desee omitir la ejecución del destructor.
    ///
    /// Para su comodidad, esto también devuelve una referencia mutable al contenido (ahora inicializado de forma segura) de `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SEGURIDAD: Acabamos de inicializar este valor.
        unsafe { self.assume_init_mut() }
    }

    /// Obtiene un puntero al valor contenido.
    /// Leer de este puntero o convertirlo en una referencia es un comportamiento indefinido a menos que se inicialice el `MaybeUninit<T>`.
    /// Escribir en la memoria a la que apunta este puntero (non-transitively) es un comportamiento indefinido (excepto dentro de un `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Uso correcto de este método:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Cree una referencia en el `MaybeUninit<T>`.Esto está bien porque lo inicializamos.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Uso incorrecto* de este método:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // ¡Hemos creado una referencia a un vector no inicializado!Este es un comportamiento indefinido.⚠️
    /// ```
    ///
    /// (Tenga en cuenta que las reglas sobre referencias a datos no inicializados aún no están finalizadas, pero hasta que lo estén, es aconsejable evitarlas).
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` y `ManuallyDrop` son ambos `repr(transparent)`, por lo que podemos lanzar el puntero.
        self as *const _ as *const T
    }

    /// Obtiene un puntero mutable al valor contenido.
    /// Leer de este puntero o convertirlo en una referencia es un comportamiento indefinido a menos que se inicialice el `MaybeUninit<T>`.
    ///
    /// # Examples
    ///
    /// Uso correcto de este método:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Cree una referencia en el `MaybeUninit<Vec<u32>>`.
    /// // Esto está bien porque lo inicializamos.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Uso incorrecto* de este método:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // ¡Hemos creado una referencia a un vector no inicializado!Este es un comportamiento indefinido.⚠️
    /// ```
    ///
    /// (Tenga en cuenta que las reglas sobre referencias a datos no inicializados aún no están finalizadas, pero hasta que lo estén, es aconsejable evitarlas).
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` y `ManuallyDrop` son ambos `repr(transparent)`, por lo que podemos lanzar el puntero.
        self as *mut _ as *mut T
    }

    /// Extrae el valor del contenedor `MaybeUninit<T>`.Esta es una excelente manera de garantizar que los datos se eliminen, porque el `T` resultante está sujeto al manejo de caída habitual.
    ///
    /// # Safety
    ///
    /// Depende de la persona que llama garantizar que el `MaybeUninit<T>` realmente se encuentra en un estado inicializado.Llamar a esto cuando el contenido aún no está completamente inicializado provoca un comportamiento indefinido inmediato.
    /// El [type-level documentation][inv] contiene más información sobre este invariante de inicialización.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Además de eso, recuerde que la mayoría de los tipos tienen invariantes adicionales además de ser considerados inicializados en el nivel de tipo.
    /// Por ejemplo, un [`Vec<T>`] inicializado con `1` se considera inicializado (según la implementación actual; esto no constituye una garantía estable) porque el único requisito que el compilador conoce es que el puntero de datos no debe ser nulo.
    ///
    /// La creación de un `Vec<T>` de este tipo no provoca un comportamiento indefinido *inmediato*, pero provocará un comportamiento indefinido con la mayoría de las operaciones seguras (incluida su eliminación).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Uso correcto de este método:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Uso incorrecto* de este método:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` aún no se había inicializado, por lo que esta última línea provocó un comportamiento indefinido.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SEGURIDAD: la persona que llama debe garantizar que `self` esté inicializado.
        // Esto también significa que `self` debe ser una variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Lee el valor del contenedor `MaybeUninit<T>`.El `T` resultante está sujeto al manejo habitual de gotas.
    ///
    /// Siempre que sea posible, es preferible utilizar [`assume_init`] en su lugar, lo que evita la duplicación del contenido del `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Depende de la persona que llama garantizar que el `MaybeUninit<T>` realmente se encuentra en un estado inicializado.Llamar a esto cuando el contenido aún no está completamente inicializado provoca un comportamiento indefinido.
    /// El [type-level documentation][inv] contiene más información sobre este invariante de inicialización.
    ///
    /// Además, esto deja una copia de los mismos datos en el `MaybeUninit<T>`.
    /// Cuando utilice varias copias de los datos (llamando a `assume_init_read` varias veces, o llamando primero a `assume_init_read` y luego a [`assume_init`]), es su responsabilidad asegurarse de que esos datos se puedan duplicar.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Uso correcto de este método:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` es `Copy`, por lo que podemos leer varias veces.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplicar un valor `None` está bien, por lo que podemos leer varias veces.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Uso incorrecto* de este método:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // ¡Ahora creamos dos copias del mismo vector, lo que lleva a un ⚠️ doble libre cuando ambos se eliminan!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SEGURIDAD: la persona que llama debe garantizar que `self` esté inicializado.
        // Leer desde `self.as_ptr()` es seguro ya que `self` debe inicializarse.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Elimina el valor contenido en su lugar.
    ///
    /// Si es propietario del `MaybeUninit`, puede usar [`assume_init`] en su lugar.
    ///
    /// # Safety
    ///
    /// Depende de la persona que llama garantizar que el `MaybeUninit<T>` realmente se encuentra en un estado inicializado.Llamar a esto cuando el contenido aún no está completamente inicializado provoca un comportamiento indefinido.
    ///
    /// Además de eso, todos los invariantes adicionales del tipo `T` deben satisfacerse, ya que la implementación `Drop` de `T` (o sus miembros) puede depender de esto.
    /// Por ejemplo, un [`Vec<T>`] inicializado con `1` se considera inicializado (según la implementación actual; esto no constituye una garantía estable) porque el único requisito que el compilador conoce es que el puntero de datos no debe ser nulo.
    ///
    /// Sin embargo, dejar caer tal `Vec<T>` provocará un comportamiento indefinido.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SEGURIDAD: la persona que llama debe garantizar que `self` esté inicializado y
        // satisface todos los invariantes de `T`.
        // Dejar caer el valor en su lugar es seguro si ese es el caso.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Obtiene una referencia compartida al valor contenido.
    ///
    /// Esto puede ser útil cuando queremos acceder a un `MaybeUninit` que se ha inicializado pero no tiene propiedad del `MaybeUninit` (evitando el uso de `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Llamar a esto cuando el contenido aún no está completamente inicializado causa un comportamiento indefinido: depende de la persona que llama garantizar que el `MaybeUninit<T>` realmente esté en un estado inicializado.
    ///
    ///
    /// # Examples
    ///
    /// ### Uso correcto de este método:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inicializar `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Ahora que se sabe que nuestro `MaybeUninit<_>` está inicializado, está bien crear una referencia compartida a él:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SEGURIDAD: Se ha inicializado `x`.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Usos *incorrectos* de este método:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // ¡Hemos creado una referencia a un vector no inicializado!Este es un comportamiento indefinido.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inicialice el `MaybeUninit` usando `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Referencia a un `Cell<bool>` no inicializado: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SEGURIDAD: la persona que llama debe garantizar que `self` esté inicializado.
        // Esto también significa que `self` debe ser una variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Obtiene una referencia (unique) mutable al valor contenido.
    ///
    /// Esto puede ser útil cuando queremos acceder a un `MaybeUninit` que se ha inicializado pero no tiene propiedad del `MaybeUninit` (evitando el uso de `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Llamar a esto cuando el contenido aún no está completamente inicializado causa un comportamiento indefinido: depende de la persona que llama garantizar que el `MaybeUninit<T>` realmente esté en un estado inicializado.
    /// Por ejemplo, `.assume_init_mut()` no se puede utilizar para inicializar un `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Uso correcto de este método:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inicializa *todos* los bytes del búfer de entrada.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inicializar `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Ahora sabemos que `buf` se ha inicializado, por lo que podríamos `.assume_init()`.
    /// // Sin embargo, el uso de `.assume_init()` puede activar un `memcpy` de 2048 bytes.
    /// // Para afirmar que nuestro búfer se ha inicializado sin copiarlo, actualizamos el `&mut MaybeUninit<[u8; 2048]>` a un `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SEGURIDAD: Se ha inicializado `buf`.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Ahora podemos usar `buf` como un segmento normal:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Usos *incorrectos* de este método:
    ///
    /// No puede usar `.assume_init_mut()` para inicializar un valor:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // ¡Hemos creado una referencia (mutable) a un `bool` no inicializado!
    ///     // Este es un comportamiento indefinido.⚠️
    /// }
    /// ```
    ///
    /// Por ejemplo, no puede [`Read`] en un búfer no inicializado:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) ¡referencia a la memoria no inicializada!
    ///                             // Este es un comportamiento indefinido.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Tampoco puede utilizar el acceso directo al campo para realizar una inicialización gradual campo por campo:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ¡referencia a la memoria no inicializada!
    ///                  // Este es un comportamiento indefinido.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ¡referencia a la memoria no inicializada!
    ///                  // Este es un comportamiento indefinido.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Actualmente confiamos en que lo anterior es incorrecto, es decir, tenemos referencias a datos no inicializados (por ejemplo, en `libcore/fmt/float.rs`).
    // Deberíamos tomar una decisión final sobre las reglas antes de la estabilización.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SEGURIDAD: la persona que llama debe garantizar que `self` esté inicializado.
        // Esto también significa que `self` debe ser una variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extrae los valores de una matriz de contenedores `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Depende de la persona que llama garantizar que todos los elementos de la matriz estén en un estado inicializado.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SEGURIDAD: Ahora seguro ya que inicializamos todos los elementos
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * La persona que llama garantiza que todos los elementos de la matriz están inicializados.
        // * `MaybeUninit<T>` y T están garantizados para tener el mismo diseño
        // * MaybeUnint no cae, por lo que no hay dobles libres y, por lo tanto, la conversión es segura
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Suponiendo que todos los elementos están inicializados, obtén una porción de ellos.
    ///
    /// # Safety
    ///
    /// Depende de la persona que llama garantizar que los elementos `MaybeUninit<T>` estén realmente en un estado inicializado.
    ///
    /// Llamar a esto cuando el contenido aún no está completamente inicializado provoca un comportamiento indefinido.
    ///
    /// Consulte [`assume_init_ref`] para obtener más detalles y ejemplos.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SEGURIDAD: lanzar un slice a un `*const [T]` es seguro ya que la persona que llama garantiza que
        // `slice` se inicializa, y se garantiza que`MaybeUninit` tendrá el mismo diseño que `T`.
        // El puntero obtenido es válido ya que se refiere a la memoria propiedad de `slice` que es una referencia y, por lo tanto, se garantiza que es válida para lecturas.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Suponiendo que todos los elementos están inicializados, obtén un segmento mutable para ellos.
    ///
    /// # Safety
    ///
    /// Depende de la persona que llama garantizar que los elementos `MaybeUninit<T>` estén realmente en un estado inicializado.
    ///
    /// Llamar a esto cuando el contenido aún no está completamente inicializado provoca un comportamiento indefinido.
    ///
    /// Consulte [`assume_init_mut`] para obtener más detalles y ejemplos.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SEGURIDAD: similar a las notas de seguridad para `slice_get_ref`, pero tenemos un
        // referencia mutable que también se garantiza que sea válida para escrituras.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Obtiene un puntero al primer elemento de la matriz.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Obtiene un puntero mutable al primer elemento de la matriz.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Copia los elementos de `src` a `this`, devolviendo una referencia mutable al contenido ahora inicializado de `this`.
    ///
    /// Si `T` no implementa `Copy`, use [`write_slice_cloned`]
    ///
    /// Esto es similar a [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Esta función se activará panic si los dos cortes tienen diferentes longitudes.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SEGURIDAD: acabamos de copiar todos los elementos de len en la capacidad de reserva
    /// // los primeros elementos src.len() del vec son válidos ahora.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SEGURIDAD: &[T] y&[MaybeUninit<T>] tienen el mismo diseño
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SEGURIDAD: Los elementos válidos se acaban de copiar en `this` por lo que se inicializa
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clona los elementos de `src` a `this`, devolviendo una referencia mutable al contenido ahora inicializado de `this`.
    /// No se eliminarán los elementos ya iniciados.
    ///
    /// Si `T` implementa `Copy`, use [`write_slice`]
    ///
    /// Esto es similar a [`slice::clone_from_slice`] pero no elimina los elementos existentes.
    ///
    /// # Panics
    ///
    /// Esta función será panic si los dos cortes tienen diferentes longitudes, o si la implementación de `Clone` panics.
    ///
    /// Si hay un panic, se eliminarán los elementos ya clonados.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SEGURIDAD: acabamos de clonar todos los elementos de len en la capacidad de reserva
    /// // los primeros elementos src.len() del vec son válidos ahora.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // a diferencia de copy_from_slice, esto no llama a clone_from_slice en el segmento, esto se debe a que `MaybeUninit<T: Clone>` no implementa Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SEGURIDAD: este segmento sin procesar contendrá solo objetos inicializados
                // por eso, está permitido dejarlo caer.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Necesitamos cortarlos explícitamente a la misma longitud
        // para que la verificación de límites se elimine, y el optimizador generará memcpy para casos simples (por ejemplo, T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // se necesita guardia b/c panic podría ocurrir durante un clon
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SEGURIDAD: Se acaban de escribir elementos válidos en `this`, por lo que está inicializado
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}