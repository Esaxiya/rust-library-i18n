use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Un contenedor para impedir que el compilador llame automáticamente al destructor de `T`.
/// Esta envoltura tiene costo 0.
///
/// `ManuallyDrop<T>` está sujeto a las mismas optimizaciones de diseño que `T`.
/// Como consecuencia,*no tiene ningún efecto* sobre las suposiciones que hace el compilador sobre su contenido.
/// Por ejemplo, inicializar un `ManuallyDrop<&mut T>` con [`mem::zeroed`] es un comportamiento indefinido.
/// Si necesita manejar datos no inicializados, use [`MaybeUninit<T>`] en su lugar.
///
/// Tenga en cuenta que acceder al valor dentro de un `ManuallyDrop<T>` es seguro.
/// Esto significa que un `ManuallyDrop<T>` cuyo contenido se haya eliminado no debe exponerse a través de una API pública segura.
/// En consecuencia, `ManuallyDrop::drop` no es seguro.
///
/// # `ManuallyDrop` y dejar orden.
///
/// Rust tiene un [drop order] de valores bien definido.
/// Para asegurarse de que los campos o locales se eliminen en un orden específico, reordene las declaraciones de modo que el orden de eliminación implícito sea el correcto.
///
/// Es posible usar `ManuallyDrop` para controlar el orden de caída, pero esto requiere un código inseguro y es difícil de hacer correctamente en presencia de desenrollado.
///
///
/// Por ejemplo, si desea asegurarse de que un campo específico se elimine después de los demás, conviértalo en el último campo de una estructura:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` se eliminará después de `children`.
///     // Rust garantiza que los campos se eliminan en el orden de declaración.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Envuelva un valor para eliminarlo manualmente.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Todavía puede operar con seguridad en el valor
    /// assert_eq!(*x, "Hello");
    /// // Pero `Drop` no se ejecutará aquí
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extrae el valor del contenedor `ManuallyDrop`.
    ///
    /// Esto permite volver a eliminar el valor.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Esto deja caer el `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Saca el valor del contenedor `ManuallyDrop<T>`.
    ///
    /// Este método está diseñado principalmente para mover valores en la gota.
    /// En lugar de usar [`ManuallyDrop::drop`] para eliminar manualmente el valor, puede usar este método para tomar el valor y usarlo como desee.
    ///
    /// Siempre que sea posible, es preferible utilizar [`into_inner`][`ManuallyDrop::into_inner`] en su lugar, lo que evita la duplicación del contenido del `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Esta función mueve semánticamente el valor contenido sin evitar un uso posterior, dejando el estado de este contenedor sin cambios.
    /// Es su responsabilidad asegurarse de que este `ManuallyDrop` no se vuelva a utilizar.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SEGURIDAD: estamos leyendo de una referencia, que está garantizada
        // para ser válido para lecturas.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Elimina manualmente el valor contenido.Esto es exactamente equivalente a llamar a [`ptr::drop_in_place`] con un puntero al valor contenido.
    /// Como tal, a menos que el valor contenido sea una estructura empaquetada, el destructor se llamará en el lugar sin mover el valor y, por lo tanto, se puede usar para eliminar datos [pinned] de forma segura.
    ///
    /// Si tiene la propiedad del valor, puede usar [`ManuallyDrop::into_inner`] en su lugar.
    ///
    /// # Safety
    ///
    /// Esta función ejecuta el destructor del valor contenido.
    /// Aparte de los cambios realizados por el propio destructor, la memoria se deja sin cambios y, en lo que respecta al compilador, todavía contiene un patrón de bits que es válido para el tipo `T`.
    ///
    ///
    /// Sin embargo, este valor "zombie" no debe exponerse a código seguro y esta función no debe invocarse más de una vez.
    /// Usar un valor después de que se haya eliminado, o eliminar un valor varias veces, puede causar un comportamiento indefinido (según lo que haga `drop`).
    /// Esto normalmente se evita con el sistema de tipos, pero los usuarios de `ManuallyDrop` deben mantener esas garantías sin la ayuda del compilador.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SEGURIDAD: estamos eliminando el valor apuntado por una referencia mutable
        // que está garantizado para ser válido para escrituras.
        // Depende de la persona que llama asegurarse de que `slot` no se desconecte nuevamente.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}