//! Traits para conversiones entre tipos.
//!
//! El traits de este módulo proporciona una forma de convertir de un tipo a otro.
//! Cada trait tiene un propósito diferente:
//!
//! - Implemente el [`AsRef`] trait para conversiones de referencia a referencia económicas
//! - Implemente el [`AsMut`] trait para conversiones mutables a mutables baratas
//! - Implemente el [`From`] trait para consumir conversiones de valor a valor
//! - Implemente el [`Into`] trait para consumir conversiones de valor a valor a tipos fuera del crate actual
//! - [`TryFrom`] y [`TryInto`] traits se comportan como [`From`] y [`Into`], pero deben implementarse cuando la conversión puede fallar.
//!
//! Los traits de este módulo se utilizan a menudo como trait bounds para funciones genéricas, de modo que se admiten argumentos de varios tipos.Consulte la documentación de cada trait para ver ejemplos.
//!
//! Como autor de una biblioteca, siempre debe preferir implementar [`From<T>`][`From`] o [`TryFrom<T>`][`TryFrom`] en lugar de [`Into<U>`][`Into`] o [`TryInto<U>`][`TryInto`], ya que [`From`] y [`TryFrom`] brindan una mayor flexibilidad y ofrecen implementaciones [`Into`] o [`TryInto`] equivalentes de forma gratuita, gracias a una implementación general en la biblioteca estándar.
//! Al apuntar a una versión anterior a Rust 1.41, puede ser necesario implementar [`Into`] o [`TryInto`] directamente al convertir a un tipo fuera del crate actual.
//!
//! # Implementaciones genéricas
//!
//! - [`AsRef`] y desreferencia automática [`AsMut`] si el tipo interno es una referencia
//! - [`From`]`<U>for T` implica [`Into`]`</u><T><U>para U`</u>
//! - [`TryFrom`]`<U>for T` implica [`TryInto`]`</u><T><U>para U`</u>
//! - [`From`] y [`Into`] son reflexivos, lo que significa que todos los tipos pueden `into` mismos y `from` mismos
//!
//! Consulte cada trait para ver ejemplos de uso.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// La función de identidad.
///
/// Es importante tener en cuenta dos cosas sobre esta función:
///
/// - No siempre es equivalente a un cierre como `|x| x`, ya que el cierre puede coaccionar a `x` a un tipo diferente.
///
/// - Mueve la entrada `x` pasada a la función.
///
/// Si bien puede parecer extraño tener una función que simplemente devuelva la entrada, hay algunos usos interesantes.
///
///
/// # Examples
///
/// Usar `identity` para no hacer nada en una secuencia de otras funciones interesantes:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Supongamos que agregar uno es una función interesante.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Usando `identity` como un caso base de "do nothing" en un condicional:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Haz cosas más interesantes ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Usando `identity` para mantener las variantes `Some` de un iterador de `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Se utiliza para realizar una conversión económica de referencia a referencia.
///
/// Este trait es similar al [`AsMut`] que se utiliza para convertir entre referencias mutables.
/// Si necesita realizar una conversión costosa, es mejor implementar [`From`] con el tipo `&T` o escribir una función personalizada.
///
/// `AsRef` tiene la misma firma que [`Borrow`], pero [`Borrow`] es diferente en algunos aspectos:
///
/// - A diferencia de `AsRef`, [`Borrow`] tiene una implícita general para cualquier `T` y se puede utilizar para aceptar una referencia o un valor.
/// - [`Borrow`] también requiere que [`Hash`], [`Eq`] y [`Ord`] para el valor prestado sean equivalentes a los del valor propio.
/// Por esta razón, si desea tomar prestado solo un campo de una estructura, puede implementar `AsRef`, pero no [`Borrow`].
///
/// **Note: Este trait no debe fallar **.Si la conversión puede fallar, utilice un método dedicado que devuelva un [`Option<T>`] o un [`Result<T, E>`].
///
/// # Implementaciones genéricas
///
/// - `AsRef` autorreferencias si el tipo interno es una referencia o una referencia mutable (por ejemplo: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Al utilizar trait bounds podemos aceptar argumentos de diferentes tipos siempre que se puedan convertir al tipo `T` especificado.
///
/// Por ejemplo: al crear una función genérica que toma un `AsRef<str>` expresamos que queremos aceptar todas las referencias que se pueden convertir a [`&str`] como argumento.
/// Dado que tanto [`String`] como [`&str`] implementan `AsRef<str>`, podemos aceptar ambos como argumento de entrada.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Realiza la conversión.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Se usa para hacer una conversión de referencia mutable a mutable barata.
///
/// Este trait es similar al [`AsRef`] pero se usa para convertir entre referencias mutables.
/// Si necesita realizar una conversión costosa, es mejor implementar [`From`] con el tipo `&mut T` o escribir una función personalizada.
///
/// **Note: Este trait no debe fallar **.Si la conversión puede fallar, utilice un método dedicado que devuelva un [`Option<T>`] o un [`Result<T, E>`].
///
/// # Implementaciones genéricas
///
/// - `AsMut` autorreferencias si el tipo interno es una referencia mutable (por ejemplo: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Usando `AsMut` como trait bound para una función genérica, podemos aceptar todas las referencias mutables que se pueden convertir al tipo `&mut T`.
/// Debido a que [`Box<T>`] implementa `AsMut<T>`, podemos escribir una función `add_one` que toma todos los argumentos que se pueden convertir a `&mut u64`.
/// Debido a que [`Box<T>`] implementa `AsMut<T>`, `add_one` también acepta argumentos de tipo `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Realiza la conversión.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Una conversión de valor a valor que consume el valor de entrada.Lo contrario de [`From`].
///
/// Uno debe evitar implementar [`Into`] y, en su lugar, implementar [`From`].
/// La implementación de [`From`] proporciona automáticamente una implementación de [`Into`] gracias a la implementación general en la biblioteca estándar.
///
/// Prefiera usar [`Into`] sobre [`From`] al especificar trait bounds en una función genérica para asegurarse de que los tipos que solo implementan [`Into`] también se puedan usar.
///
/// **Note: Este trait no debe fallar **.Si la conversión puede fallar, use [`TryInto`].
///
/// # Implementaciones genéricas
///
/// - [`De`]`<T>para U` implica `Into<U> for T`
/// - [`Into`] es reflexivo, lo que significa que `Into<T> for T` está implementado
///
/// # Implementación de [`Into`] para conversiones a tipos externos en versiones antiguas de Rust
///
/// Antes de Rust 1.41, si el tipo de destino no formaba parte del crate actual, no se podía implementar [`From`] directamente.
/// Por ejemplo, tome este código:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Esto no se compilará en versiones anteriores del lenguaje porque las reglas de huérfano de Rust solían ser un poco más estrictas.
/// Para evitar esto, puede implementar [`Into`] directamente:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Es importante comprender que [`Into`] no proporciona una implementación [`From`] (como lo hace [`From`] con [`Into`]).
/// Por lo tanto, siempre debe intentar implementar [`From`] y luego volver a [`Into`] si [`From`] no se puede implementar.
///
/// # Examples
///
/// [`String`] implementa [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Para expresar que queremos que una función genérica tome todos los argumentos que se pueden convertir a un tipo `T` especificado, podemos usar un trait bound de [`Into`]`<T>".
///
/// Por ejemplo: La función `is_hello` toma todos los argumentos que se pueden convertir en un [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Realiza la conversión.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Se utiliza para realizar conversiones de valor a valor mientras se consume el valor de entrada.Es el recíproco de [`Into`].
///
/// Siempre se debe preferir implementar `From` sobre [`Into`] porque la implementación de `From` proporciona automáticamente una implementación de [`Into`] gracias a la implementación general en la biblioteca estándar.
///
///
/// Solo implemente [`Into`] cuando apunte a una versión anterior a Rust 1.41 y convierta a un tipo fuera del crate actual.
/// `From` no pudo realizar este tipo de conversiones en versiones anteriores debido a las reglas de huérfano de Rust.
/// Consulte [`Into`] para obtener más detalles.
///
/// Prefiera usar [`Into`] en lugar de `From` al especificar trait bounds en una función genérica.
/// De esta manera, los tipos que implementan directamente [`Into`] también se pueden usar como argumentos.
///
/// El `From` también es muy útil al realizar el manejo de errores.Cuando se construye una función que puede fallar, el tipo de retorno generalmente será de la forma `Result<T, E>`.
/// El `From` trait simplifica el manejo de errores al permitir que una función devuelva un solo tipo de error que encapsula múltiples tipos de error.Consulte la sección "Examples" y [the book][book] para obtener más detalles.
///
/// **Note: Este trait no debe fallar **.Si la conversión puede fallar, use [`TryFrom`].
///
/// # Implementaciones genéricas
///
/// - `From<T> for U` implica [`Into`]`<U>para T`</u>
/// - `From` es reflexivo, lo que significa que `From<T> for T` está implementado
///
/// # Examples
///
/// [`String`] implementa `From<&str>`:
///
/// Una conversión explícita de `&str` a String se realiza de la siguiente manera:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Al realizar el manejo de errores, a menudo es útil implementar `From` para su propio tipo de error.
/// Al convertir los tipos de error subyacentes a nuestro propio tipo de error personalizado que encapsula el tipo de error subyacente, podemos devolver un solo tipo de error sin perder información sobre la causa subyacente.
/// El operador '?' convierte automáticamente el tipo de error subyacente en nuestro tipo de error personalizado llamando a `Into<CliError>::into`, que se proporciona automáticamente al implementar `From`.
/// A continuación, el compilador infiere qué implementación de `Into` debe utilizarse.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Realiza la conversión.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Un intento de conversión que consume `self`, que puede ser costoso o no.
///
/// Los autores de bibliotecas generalmente no deben implementar directamente este trait, pero deben preferir implementar el [`TryFrom`] trait, que ofrece una mayor flexibilidad y proporciona una implementación `TryInto` equivalente de forma gratuita, gracias a una implementación general en la biblioteca estándar.
/// Para obtener más información sobre esto, consulte la documentación de [`Into`].
///
/// # Implementación de `TryInto`
///
/// Esto sufre las mismas restricciones y razonamientos que la implementación de [`Into`], consulte allí para obtener más detalles.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// El tipo devuelto en caso de error de conversión.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Realiza la conversión.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Conversiones de tipo simples y seguras que pueden fallar de forma controlada en algunas circunstancias.Es el recíproco de [`TryInto`].
///
/// Esto es útil cuando está haciendo una conversión de tipos que puede tener éxito trivialmente pero que también puede necesitar un manejo especial.
/// Por ejemplo, no hay forma de convertir un [`i64`] en un [`i32`] usando el [`From`] trait, porque un [`i64`] puede contener un valor que un [`i32`] no puede representar y, por lo tanto, la conversión perdería datos.
///
/// Esto podría manejarse truncando el [`i64`] a un [`i32`] (esencialmente dando el valor de [`i64`] módulo [`i32::MAX`]) o simplemente devolviendo [`i32::MAX`], o por algún otro método.
/// El [`From`] trait está diseñado para conversiones perfectas, por lo que el `TryFrom` trait informa al programador cuando una conversión de tipo podría salir mal y les permite decidir cómo manejarla.
///
/// # Implementaciones genéricas
///
/// - `TryFrom<T> for U` implica [`TryInto`]`<U>para T`</u>
/// - [`try_from`] es reflexivo, lo que significa que `TryFrom<T> for T` está implementado y no puede fallar; el tipo `Error` asociado para llamar a `T::try_from()` en un valor de tipo `T` es [`Infallible`].
/// Cuando el tipo [`!`] se estabiliza, [`Infallible`] y [`!`] serán equivalentes.
///
/// `TryFrom<T>` se puede implementar de la siguiente manera:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Como se describe, [`i32`] implementa `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Trunca silenciosamente `big_number`, requiere detectar y manejar el truncamiento después del hecho.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Devuelve un error porque `big_number` es demasiado grande para caber en un `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Devuelve `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// El tipo devuelto en caso de error de conversión.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Realiza la conversión.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLES GENÉRICOS
////////////////////////////////////////////////////////////////////////////////

// A medida que se eleva y
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Como se eleva sobre &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): reemplace las implicaciones anteriores para&/&mut por la siguiente más general:
// // Mientras se eleva sobre Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Tamaño> AsRef <U>para D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut se eleva sobre &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): reemplace el impl anterior para &mut con el siguiente más general:
// // AsMut se eleva sobre DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Tamaño> AsMut <U>para D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// De implica En
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// De (y por lo tanto A) es reflexivo
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Nota de estabilidad:** Este impl aún no existe, pero estamos "reserving space" para agregarlo en el future.
/// Consulte [rust-lang/rust#64715][#64715] para obtener más detalles.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): en su lugar, haga una solución basada en principios.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom implica TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Las conversiones infalibles son semánticamente equivalentes a las conversiones falibles con un tipo de error deshabitado.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLES DE HORMIGÓN
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// EL TIPO DE ERROR SIN ERROR
////////////////////////////////////////////////////////////////////////////////

/// El tipo de error para errores que nunca pueden ocurrir.
///
/// Dado que esta enumeración no tiene variante, un valor de este tipo nunca puede existir.
/// Esto puede ser útil para API genéricas que usan [`Result`] y parametrizan el tipo de error, para indicar que el resultado es siempre [`Ok`].
///
/// Por ejemplo, el [`TryFrom`] trait (conversión que devuelve un [`Result`]) tiene una implementación general para todos los tipos donde existe una implementación [`Into`] inversa.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Compatibilidad con Future
///
/// Esta enumeración tiene la misma función que [the `!`“never”type][never], que es inestable en esta versión de Rust.
/// Cuando `!` esté estabilizado, planeamos convertir `Infallible` en un alias de tipo para él:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Y eventualmente desaprobar `Infallible`.
///
/// Sin embargo, hay un caso en el que se puede utilizar la sintaxis `!` antes de que `!` se estabilice como un tipo completo: en la posición del tipo de retorno de una función.
/// Específicamente, es posible implementaciones para dos tipos de punteros de función diferentes:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Siendo `Infallible` una enumeración, este código es válido.
/// Sin embargo, cuando `Infallible` se convierte en un alias para never type, las dos `impl`s comenzarán a superponerse y, por lo tanto, las reglas de coherencia trait del lenguaje no las permitirán.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}