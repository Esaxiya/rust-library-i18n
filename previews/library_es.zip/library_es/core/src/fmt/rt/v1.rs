//! Este es un módulo interno utilizado por ifmt!tiempo de ejecución.Estas estructuras se emiten a matrices estáticas para precompilar cadenas de formato antes de tiempo.
//!
//! Estas definiciones son similares a sus equivalentes `ct`, pero difieren en que se pueden asignar estáticamente y están ligeramente optimizadas para el tiempo de ejecución.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Posibles alineaciones que se pueden solicitar como parte de una directiva de formato.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indicación de que los contenidos deben estar alineados a la izquierda.
    Left,
    /// Indicación de que los contenidos deben estar alineados a la derecha.
    Right,
    /// Indicación de que los contenidos deben estar alineados al centro.
    Center,
    /// No se solicitó alineación.
    Unknown,
}

/// Utilizado por los especificadores [width](https://doc.rust-lang.org/std/fmt/#width) y [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Especificado con un número literal, almacena el valor
    Is(usize),
    /// Especificado con las sintaxis `$` y `*`, almacena el índice en `args`
    Param(usize),
    /// No especificado
    Implied,
}