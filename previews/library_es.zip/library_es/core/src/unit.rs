use crate::iter::FromIterator;

/// Contrae todos los elementos de la unidad de un iterador en uno.
///
/// Esto es más útil cuando se combina con abstracciones de nivel superior, como recopilar en un `Result<(), E>` donde solo le importan los errores:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}