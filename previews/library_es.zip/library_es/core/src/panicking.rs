//! Soporte de Panic para libcore
//!
//! La biblioteca central no puede definir el pánico, pero *declara* pánico.
//! Esto significa que las funciones dentro de libcore están permitidas para panic, pero para ser útil, un crate ascendente debe definir el pánico para que libcore lo utilice.
//! La interfaz actual para entrar en pánico es:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Esta definición permite entrar en pánico con cualquier mensaje general, pero no permite fallar con un valor `Box<Any>`.
//! (`PanicInfo` solo contiene un `&(dyn Any + Send)`, para el cual completamos un valor ficticio en `PanicInfo: : internal_constructor`.) La razón de esto es que libcore no puede realizar asignaciones.
//!
//!
//! Este módulo contiene algunas otras funciones de pánico, pero estos son solo los elementos de idioma necesarios para el compilador.Todos los panics se canalizan a través de esta función.
//! El símbolo real se declara mediante el atributo `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// La implementación subyacente de la macro `panic!` de libcore cuando no se usa formato.
#[cold]
// nunca en línea a menos que panic_immediate_abort para evitar el exceso de código en los sitios de llamadas tanto como sea posible
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // necesario por codegen para panic en overflow y otros terminadores `Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Utilice Arguments::new_v1 en lugar de format_args! ("{}", Expr) para reducir potencialmente la sobrecarga de tamaño.
    // ¡El format_args!macro usa Display trait de str para escribir expr, que llama a Formatter::pad, que debe acomodar el truncamiento y el relleno de cadenas (aunque no se usa ninguno aquí).
    //
    // El uso de Arguments::new_v1 puede permitir que el compilador omita Formatter::pad del binario de salida, ahorrando hasta unos pocos kilobytes.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // necesario para panics con evaluación constante
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // necesario por codegen para panic en el acceso OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// La implementación subyacente de la macro `panic!` de libcore cuando se usa el formateo.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NOTA Esta función nunca cruza el límite de FFI;es una llamada Rust-to-Rust que se resuelve en la función `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SEGURIDAD: `panic_impl` está definido en un código seguro Rust y, por lo tanto, es seguro llamarlo.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Función interna para macros `assert_eq!` y `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}