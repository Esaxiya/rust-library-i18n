//! `Clone` trait para tipos que no se pueden 'copiar implícitamente'.
//!
//! En Rust, algunos tipos simples son "implicitly copyable" y cuando los asigna o los pasa como argumentos, el receptor obtendrá una copia, dejando el valor original en su lugar.
//! Estos tipos no requieren asignación para copiar y no tienen finalizadores (es decir, no contienen cajas propias ni implementan [`Drop`]), por lo que el compilador los considera baratos y seguros de copiar.
//!
//! Para otros tipos, las copias deben hacerse explícitamente, por convención implementando el [`Clone`] trait y llamando al método [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Ejemplo de uso básico:
//!
//! ```
//! let s = String::new(); // Tipo de cadena implementa Clon
//! let copy = s.clone(); // para que podamos clonarlo
//! ```
//!
//! Para implementar fácilmente Clone trait, también puede usar `#[derive(Clone)]`.Ejemplo:
//!
//! ```
//! #[derive(Clone)] // agregamos el Clone trait a la estructura Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ¡y ahora podemos clonarlo!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Un trait común para la capacidad de duplicar explícitamente un objeto.
///
/// Se diferencia de [`Copy`] en que [`Copy`] es implícito y extremadamente económico, mientras que `Clone` es siempre explícito y puede ser caro o no.
/// Para hacer cumplir estas características, Rust no le permite volver a implementar [`Copy`], pero puede volver a implementar `Clone` y ejecutar código arbitrario.
///
/// Dado que `Clone` es más general que [`Copy`], puede hacer automáticamente que cualquier [`Copy`] sea `Clone` también.
///
/// ## Derivable
///
/// Este trait se puede utilizar con `#[derive]` si todos los campos son `Clone`.La implementación `derive`d de [`Clone`] llama a [`clone`] en cada campo.
///
/// [`clone`]: Clone::clone
///
/// Para una estructura genérica, `#[derive]` implementa `Clone` condicionalmente agregando `Clone` enlazado en parámetros genéricos.
///
/// ```
/// // `derive` implementa Clone para lectura<T>cuando T es Clon.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## ¿Cómo puedo implementar `Clone`?
///
/// Los tipos que son [`Copy`] deberían tener una implementación trivial de `Clone`.Más formalmente:
/// si `T: Copy`, `x: T` y `y: &T`, entonces `let x = y.clone();` es equivalente a `let x = *y;`.
/// Las implementaciones manuales deben tener cuidado de mantener este invariante;sin embargo, el código inseguro no debe depender de él para garantizar la seguridad de la memoria.
///
/// Un ejemplo es una estructura genérica que contiene un puntero de función.En este caso, la implementación de `Clone` no se puede `derivar`d, pero se puede implementar como:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Implementadores adicionales
///
/// Además del [implementors listed below][impls], los siguientes tipos también implementan `Clone`:
///
/// * Tipos de elementos de función (es decir, los distintos tipos definidos para cada función)
/// * Tipos de puntero de función (p. Ej., `fn() -> i32`)
/// * Tipos de matriz, para todos los tamaños, si el tipo de elemento también implementa `Clone` (por ejemplo, `[i32; 123456]`)
/// * Tipos de tuplas, si cada componente también implementa `Clone` (por ejemplo, `()`, `(i32, bool)`)
/// * Tipos de cierre, si no capturan ningún valor del entorno o si todos esos valores capturados implementan `Clone` por sí mismos.
///   Tenga en cuenta que las variables capturadas por referencia compartida siempre implementan `Clone` (incluso si el referente no lo hace), mientras que las variables capturadas por referencia mutable nunca implementan `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Devuelve una copia del valor.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementa Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Realiza la asignación de copias desde `source`.
    ///
    /// `a.clone_from(&b)` es equivalente a `a = b.clone()` en funcionalidad, pero se puede anular para reutilizar los recursos de `a` para evitar asignaciones innecesarias.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Derive macro que genera una impl del trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): estas estructuras son utilizadas únicamente por#[derivar] para afirmar que cada componente de un tipo implementa Clonar o Copiar.
//
//
// Estas estructuras nunca deberían aparecer en el código de usuario.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementaciones de `Clone` para tipos primitivos.
///
/// Las implementaciones que no se pueden describir en Rust se implementan en `traits::SelectionContext::copy_clone_conditions()` en `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Las referencias compartidas se pueden clonar, ¡pero las referencias mutables *no*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Las referencias compartidas se pueden clonar, ¡pero las referencias mutables *no*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}