//! El libcore prelude
//!
//! Este módulo está destinado a usuarios de libcore que no se vinculan a libstd también.
//! Este módulo se importa de forma predeterminada cuando `#![no_std]` se usa de la misma manera que el prelude de la biblioteca estándar.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// La versión 2015 del núcleo prelude.
///
/// Consulte el [module-level documentation](self) para obtener más información.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// La versión 2018 del núcleo prelude.
///
/// Consulte el [module-level documentation](self) para obtener más información.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// La versión 2021 del núcleo prelude.
///
/// Consulte el [module-level documentation](self) para obtener más información.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Agrega más cosas.
}