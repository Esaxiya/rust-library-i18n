#![stable(feature = "futures_api", since = "1.36.0")]

//! Valores asincrónicos.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Este tipo es necesario porque:
///
/// a) Los generadores no pueden implementar `for<'a, 'b> Generator<&'a mut Context<'b>>`, por lo que necesitamos pasar un puntero sin formato (ver <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Los punteros sin procesar y `NonNull` no son `Send` o `Sync`, por lo que eso haría que cada future non-Send/Sync también, y no queremos eso.
///
/// También simplifica la reducción HIR de `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Envuelva un generador en un future.
///
/// Esta función devuelve un `GenFuture` debajo, pero lo oculta en `impl Trait` para dar mejores mensajes de error (`impl Future` en lugar de `GenFuture<[closure.....]>`).
///
// Esto es `const` para evitar errores adicionales después de que nos recuperemos de `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Confiamos en el hecho de que async/await futures son inamovibles para crear préstamos autorreferenciales en el generador subyacente.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SEGURIDAD: Seguro porque somos !Unpin + !Drop, y esto es solo una proyección de campo.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Reanude el generador, convirtiendo el `&mut Context` en un puntero sin formato `NonNull`.
            // La reducción de `.await` lo devolverá de manera segura a un `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SEGURIDAD: la persona que llama debe garantizar que `cx.0` es un puntero válido
    // que cumple todos los requisitos para una referencia mutable.
    unsafe { &mut *cx.0.as_ptr().cast() }
}