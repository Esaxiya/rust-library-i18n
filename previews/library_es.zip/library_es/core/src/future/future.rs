#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Un future representa un cálculo asincrónico.
///
/// Un future es un valor que puede que aún no se haya terminado de calcular.
/// Este tipo de "asynchronous value" hace posible que un hilo continúe haciendo un trabajo útil mientras espera que el valor esté disponible.
///
///
/// # El método `poll`
///
/// El método principal de future, `poll`,*intenta* resolver el future en un valor final.
/// Este método no se bloquea si el valor no está listo.
/// En su lugar, la tarea actual está programada para que se active cuando sea posible realizar más progresos "sondeando" de nuevo.
/// El `context` pasado al método `poll` puede proporcionar un [`Waker`], que es un identificador para reactivar la tarea actual.
///
/// Cuando use un future, generalmente no llamará a `poll` directamente, sino a `.await` el valor.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// El tipo de valor producido al finalizar.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Intente resolver el future a un valor final, registrando la tarea actual para despertar si el valor aún no está disponible.
    ///
    /// # Valor devuelto
    ///
    /// Esta función devuelve:
    ///
    /// - [`Poll::Pending`] si el future aún no está listo
    /// - [`Poll::Ready(val)`] con el resultado `val` de este future si terminó con éxito.
    ///
    /// Una vez que un future ha finalizado, los clientes no deberían volver a `poll`.
    ///
    /// Cuando un future aún no está listo, `poll` devuelve `Poll::Pending` y almacena un clon del [`Waker`] copiado del [`Context`] actual.
    /// Este [`Waker`] se despierta una vez que el future puede progresar.
    /// Por ejemplo, un future que espera que un conector sea legible llamaría a `.clone()` en el [`Waker`] y lo almacenaría.
    /// Cuando llega una señal a otro lugar que indica que el conector es legible, se llama a [`Waker::wake`] y se despierta la tarea del conector future.
    /// Una vez que se ha despertado una tarea, debe intentar `poll` el future nuevamente, lo que puede producir o no un valor final.
    ///
    /// Tenga en cuenta que en varias llamadas a `poll`, solo el [`Waker`] del [`Context`] pasado a la llamada más reciente debe programarse para recibir una activación.
    ///
    /// # Características de tiempo de ejecución
    ///
    /// Futures solo son *inertes*;deben ser *activamente*`encuestados` para progresar, lo que significa que cada vez que se despierte la tarea actual, debe volver a`sondear` activamente futures pendiente en el que todavía tiene interés.
    ///
    /// La función `poll` no se llama repetidamente en un bucle cerrado; en cambio, solo debe llamarse cuando future indica que está listo para avanzar (llamando a `wake()`).
    /// Si está familiarizado con las llamadas al sistema `poll(2)` o `select(2)` en Unix, vale la pena señalar que futures normalmente *no* sufre los mismos problemas que "all wakeups must poll all events";son más como `epoll(4)`.
    ///
    /// Una implementación de `poll` debe esforzarse por regresar rápidamente y no debe bloquearse.La devolución rápida evita la obstrucción innecesaria de hilos o bucles de eventos.
    /// Si se sabe de antemano que una llamada a `poll` puede demorar un poco, el trabajo debe descargarse a un grupo de subprocesos (o algo similar) para garantizar que `poll` pueda regresar rápidamente.
    ///
    /// # Panics
    ///
    /// Una vez que se ha completado un future (devolvió `Ready` desde `poll`), volver a llamar a su método `poll` puede panic, bloquearse para siempre o causar otros tipos de problemas;el `Future` trait no impone requisitos sobre los efectos de dicha llamada.
    /// Sin embargo, como el método `poll` no está marcado como `unsafe`, se aplican las reglas habituales de Rust: las llamadas nunca deben causar un comportamiento indefinido (corrupción de memoria, uso incorrecto de las funciones `unsafe`, o similares), independientemente del estado de future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}