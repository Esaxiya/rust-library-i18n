use crate::future::Future;

/// Conversión a `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// La salida que producirá el future al finalizar.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// ¿En qué tipo de future estamos convirtiendo esto?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Crea un future a partir de un valor.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}