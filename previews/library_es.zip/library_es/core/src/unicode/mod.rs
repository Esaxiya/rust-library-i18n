#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// La versión de [Unicode](http://www.unicode.org/) en la que se basan las partes Unicode de los métodos `char` y `str`.
///
/// Las nuevas versiones de Unicode se lanzan regularmente y, posteriormente, se actualizan todos los métodos de la biblioteca estándar que dependen de Unicode.
/// Por lo tanto, el comportamiento de algunos métodos `char` y `str` y el valor de esta constante cambia con el tiempo.
/// Esto *no* se considera un cambio importante.
///
/// El esquema de numeración de versiones se explica en [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Para usar en liballoc, no reexportado en libstd.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;