Panics el hilo actual.

Esto permite que un programa finalice inmediatamente y proporcione información a la persona que llama del programa.
`panic!` debe usarse cuando un programa alcanza un estado irrecuperable.

Esta macro es la manera perfecta de afirmar condiciones en código de ejemplo y en pruebas.
`panic!` está estrechamente relacionado con el método `unwrap` de las enumeraciones [`Option`][ounwrap] y [`Result`][runwrap].
Ambas implementaciones llaman a `panic!` cuando están configuradas en variantes [`None`] o [`Err`].

Al usar `panic!()`, puede especificar una carga útil de cadena, que se construye usando la sintaxis [`format!`].
Esa carga útil se usa al inyectar el panic en el hilo Rust que llama, lo que hace que el hilo se convierta en panic por completo.

El comportamiento del `std` hook predeterminado, es decir
el código que se ejecuta directamente después de que se invoca panic es imprimir la carga útil del mensaje en `stderr` junto con la información file/line/column de la llamada `panic!()`.

Puede anular el panic hook usando [`std::panic::set_hook()`].
Dentro del hook se puede acceder a un panic como un `&dyn Any + Send`, que contiene un `&str` o un `String` para invocaciones regulares de `panic!()`.
Para panic con un valor de otro tipo, se puede usar [`panic_any`].

[`Result`] enum es a menudo una mejor solución para recuperarse de errores que usar la macro `panic!`.
Esta macro debe usarse para evitar continuar utilizando valores incorrectos, como los de fuentes externas.
La información detallada sobre el manejo de errores se encuentra en el [book].

Consulte también la macro [`compile_error!`], para generar errores durante la compilación.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Implementación actual

Si el hilo principal panics terminará todos sus hilos y finalizará su programa con el código `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





