#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Se expande a `$crate::panic::panic_2015` o `$crate::panic::panic_2021` según la edición de la persona que llama.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Afirma que dos expresiones son iguales entre sí (usando [`PartialEq`]).
///
/// En panic, esta macro imprimirá los valores de las expresiones con sus representaciones de depuración.
///
///
/// Al igual que [`assert!`], esta macro tiene una segunda forma, donde se puede proporcionar un mensaje panic personalizado.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Los renacimientos a continuación son intencionales.
                    // Sin ellos, la ranura de la pila para el préstamo se inicializa incluso antes de que se comparen los valores, lo que provoca una notable ralentización.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Los renacimientos a continuación son intencionales.
                    // Sin ellos, la ranura de la pila para el préstamo se inicializa incluso antes de que se comparen los valores, lo que provoca una notable ralentización.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afirma que dos expresiones no son iguales entre sí (usando [`PartialEq`]).
///
/// En panic, esta macro imprimirá los valores de las expresiones con sus representaciones de depuración.
///
///
/// Al igual que [`assert!`], esta macro tiene una segunda forma, donde se puede proporcionar un mensaje panic personalizado.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Los renacimientos a continuación son intencionales.
                    // Sin ellos, la ranura de la pila para el préstamo se inicializa incluso antes de que se comparen los valores, lo que provoca una notable ralentización.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Los renacimientos a continuación son intencionales.
                    // Sin ellos, la ranura de la pila para el préstamo se inicializa incluso antes de que se comparen los valores, lo que provoca una notable ralentización.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afirma que una expresión booleana es `true` en tiempo de ejecución.
///
/// Esto invocará la macro [`panic!`] si la expresión proporcionada no se puede evaluar a `true` en tiempo de ejecución.
///
/// Al igual que [`assert!`], esta macro también tiene una segunda versión, donde se puede proporcionar un mensaje panic personalizado.
///
/// # Uses
///
/// A diferencia de [`assert!`], las declaraciones `debug_assert!` solo están habilitadas en compilaciones no optimizadas de forma predeterminada.
/// Una compilación optimizada no ejecutará declaraciones `debug_assert!` a menos que `-C debug-assertions` se pase al compilador.
/// Esto hace que `debug_assert!` sea útil para comprobaciones que son demasiado caras para estar presentes en una versión de lanzamiento, pero que pueden ser útiles durante el desarrollo.
/// El resultado de expandir `debug_assert!` siempre se verifica de tipo.
///
/// Una aserción no verificada permite que un programa en un estado inconsistente continúe ejecutándose, lo que puede tener consecuencias inesperadas pero no introduce inseguridad siempre que esto solo ocurra en código seguro.
///
/// Sin embargo, el costo de desempeño de las afirmaciones no se puede medir en general.
/// Por lo tanto, solo se recomienda reemplazar [`assert!`] por `debug_assert!` después de un perfil completo y, lo que es más importante, ¡solo en código seguro!
///
/// # Examples
///
/// ```
/// // el mensaje panic para estas afirmaciones es el valor en cadena de la expresión dada.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // una función muy simple
/// debug_assert!(some_expensive_computation());
///
/// // afirmar con un mensaje personalizado
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Afirma que dos expresiones son iguales entre sí.
///
/// En panic, esta macro imprimirá los valores de las expresiones con sus representaciones de depuración.
///
/// A diferencia de [`assert_eq!`], las declaraciones `debug_assert_eq!` solo están habilitadas en compilaciones no optimizadas de forma predeterminada.
/// Una compilación optimizada no ejecutará declaraciones `debug_assert_eq!` a menos que `-C debug-assertions` se pase al compilador.
/// Esto hace que `debug_assert_eq!` sea útil para comprobaciones que son demasiado caras para estar presentes en una versión de lanzamiento, pero que pueden ser útiles durante el desarrollo.
///
/// El resultado de expandir `debug_assert_eq!` siempre se verifica de tipo.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Afirma que dos expresiones no son iguales entre sí.
///
/// En panic, esta macro imprimirá los valores de las expresiones con sus representaciones de depuración.
///
/// A diferencia de [`assert_ne!`], las declaraciones `debug_assert_ne!` solo están habilitadas en compilaciones no optimizadas de forma predeterminada.
/// Una compilación optimizada no ejecutará declaraciones `debug_assert_ne!` a menos que `-C debug-assertions` se pase al compilador.
/// Esto hace que `debug_assert_ne!` sea útil para comprobaciones que son demasiado caras para estar presentes en una versión de lanzamiento, pero que pueden ser útiles durante el desarrollo.
///
/// El resultado de expandir `debug_assert_ne!` siempre se verifica de tipo.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Devuelve si la expresión dada coincide con alguno de los patrones dados.
///
/// Como en una expresión `match`, el patrón puede ser seguido opcionalmente por `if` y una expresión de protección que tiene acceso a los nombres vinculados por el patrón.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Desenvuelve un resultado o propaga su error.
///
/// El operador `?` se agregó para reemplazar `try!` y debe usarse en su lugar.
/// Además, `try` es una palabra reservada en Rust 2018, por lo que si debe usarla, deberá usar [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` coincide con el [`Result`] dado.En el caso de la variante `Ok`, la expresión tiene el valor del valor envuelto.
///
/// En el caso de la variante `Err`, recupera el error interno.Luego, `try!` realiza la conversión utilizando `From`.
/// Esto proporciona conversión automática entre errores especializados y errores más generales.
/// El error resultante se devuelve inmediatamente.
///
/// Debido al retorno anticipado, `try!` solo se puede usar en funciones que devuelven [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // El método preferido para devolver rápidamente los errores
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // El método anterior de errores de devolución rápida
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Esto es equivalente a:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Escribe datos formateados en un búfer.
///
/// Esta macro acepta un 'writer', una cadena de formato y una lista de argumentos.
/// Los argumentos se formatearán de acuerdo con la cadena de formato especificada y el resultado se pasará al escritor.
/// El escritor puede tener cualquier valor con un método `write_fmt`;generalmente, esto proviene de una implementación de [`fmt::Write`] o [`io::Write`] trait.
/// La macro devuelve lo que devuelva el método `write_fmt`;comúnmente un [`fmt::Result`] o un [`io::Result`].
///
/// Consulte [`std::fmt`] para obtener más información sobre la sintaxis de cadena de formato.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Un módulo puede importar tanto `std::fmt::Write` como `std::io::Write` y llamar a `write!` en objetos que implementan cualquiera de los dos, ya que los objetos no suelen implementar ambos.
///
/// Sin embargo, el módulo debe importar el traits calificado para que sus nombres no entren en conflicto:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // usa fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // usa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Esta macro también se puede utilizar en configuraciones `no_std`.
/// En una configuración `no_std`, usted es responsable de los detalles de implementación de los componentes.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Escriba datos formateados en un búfer, con una nueva línea adjunta.
///
/// En todas las plataformas, la nueva línea es el carácter LINE FEED (`\n`/`U+000A`) solo (sin CARRIAGE RETURN (`\r`/`U+000D`) adicional.
///
/// Para obtener más información, consulte [`write!`].Para obtener información sobre la sintaxis de la cadena de formato, consulte [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Un módulo puede importar tanto `std::fmt::Write` como `std::io::Write` y llamar a `write!` en objetos que implementan cualquiera de los dos, ya que los objetos no suelen implementar ambos.
/// Sin embargo, el módulo debe importar el traits calificado para que sus nombres no entren en conflicto:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // usa fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // usa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Indica código inalcanzable.
///
/// Esto es útil siempre que el compilador no pueda determinar que algún código es inalcanzable.Por ejemplo:
///
/// * Haga coincidir los brazos con las condiciones de la guardia.
/// * Bucles que terminan dinámicamente.
/// * Iteradores que terminan dinámicamente.
///
/// Si la determinación de que el código es inalcanzable resulta incorrecta, el programa termina inmediatamente con un [`panic!`].
///
/// La contraparte insegura de esta macro es la función [`unreachable_unchecked`], que provocará un comportamiento indefinido si se alcanza el código.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Esto siempre será [`panic!`].
///
/// # Examples
///
/// Coincidir con los brazos:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // compilar error si se comenta
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // una de las implementaciones más pobres de x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Indica código no implementado al entrar en pánico con un mensaje de "not implemented".
///
/// Esto permite que su código verifique el tipo, lo cual es útil si está creando un prototipo o implementando un trait que requiere múltiples métodos que no planea usar todos.
///
/// La diferencia entre `unimplemented!` y [`todo!`] es que mientras `todo!` transmite la intención de implementar la funcionalidad más adelante y el mensaje es "not yet implemented", `unimplemented!` no hace tales afirmaciones.
/// Su mensaje es "not implemented".
/// Además, algunos IDE marcarán `todo!` S.
///
/// # Panics
///
/// Esto siempre será [`panic!`] porque `unimplemented!` es solo una abreviatura de `panic!` con un mensaje fijo y específico.
///
/// Como `panic!`, esta macro tiene una segunda forma para mostrar valores personalizados.
///
/// # Examples
///
/// Digamos que tenemos un trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Queremos implementar `Foo` para 'MyStruct', pero por alguna razón solo tiene sentido implementar la función `bar()`.
/// `baz()` y `qux()` aún deberá definirse en nuestra implementación de `Foo`, pero podemos usar `unimplemented!` en sus definiciones para permitir que nuestro código se compile.
///
/// Aún queremos que nuestro programa deje de ejecutarse si se alcanzan los métodos no implementados.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // No tiene sentido para `baz` a `MyStruct`, por lo que no tenemos ninguna lógica aquí.
/////
///         // Esto mostrará "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Tenemos algo de lógica aquí, ¡podemos agregar un mensaje sin implementar!para mostrar nuestra omisión.
///         // Esto mostrará: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Indica código inacabado.
///
/// Esto puede ser útil si está creando un prototipo y solo está buscando que se verifique el tipo de código.
///
/// La diferencia entre [`unimplemented!`] y `todo!` es que mientras `todo!` transmite la intención de implementar la funcionalidad más adelante y el mensaje es "not yet implemented", `unimplemented!` no hace tales afirmaciones.
/// Su mensaje es "not implemented".
/// Además, algunos IDE marcarán `todo!` S.
///
/// # Panics
///
/// Esto siempre será [`panic!`].
///
/// # Examples
///
/// A continuación, se muestra un ejemplo de código en curso.Tenemos un trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Queremos implementar `Foo` en uno de nuestros tipos, pero también queremos trabajar solo en `bar()` primero.Para que nuestro código se compile, necesitamos implementar `baz()`, por lo que podemos usar `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // la implementación va aquí
///     }
///
///     fn baz(&self) {
///         // no nos preocupemos por implementar baz() por ahora
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ni siquiera estamos usando baz(), así que está bien.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definiciones de macros integradas.
///
/// La mayoría de las propiedades macro (estabilidad, visibilidad, etc.) se toman del código fuente aquí, con la excepción de las funciones de expansión que transforman entradas macro en salidas, esas funciones son proporcionadas por el compilador.
///
///
pub(crate) mod builtin {

    /// Hace que la compilación falle con el mensaje de error dado cuando se encuentra.
    ///
    /// Esta macro debe usarse cuando un crate usa una estrategia de compilación condicional para proporcionar mejores mensajes de error para condiciones erróneas.
    ///
    /// Es la forma a nivel de compilador de [`panic!`], pero emite un error durante la *compilación* en lugar de en el *tiempo de ejecución*.
    ///
    /// # Examples
    ///
    /// Dos de estos ejemplos son macros y entornos `#[cfg]`.
    ///
    /// Emite un mejor error de compilador si a una macro se le pasan valores no válidos.
    /// Sin el branch final, el compilador aún emitiría un error, pero el mensaje de error no mencionaría los dos valores válidos.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emite un error del compilador si una de varias funciones no está disponible.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Construye parámetros para las otras macros de formato de cadena.
    ///
    /// Esta macro funciona tomando un literal de cadena de formato que contiene `{}` para cada argumento adicional pasado.
    /// `format_args!` prepara los parámetros adicionales para garantizar que la salida se pueda interpretar como una cadena y canonicaliza los argumentos en un solo tipo.
    /// Cualquier valor que implemente [`Display`] trait puede pasarse a `format_args!`, al igual que cualquier implementación de [`Debug`] puede pasarse a `{:?}` dentro de la cadena de formato.
    ///
    ///
    /// Esta macro produce un valor de tipo [`fmt::Arguments`].Este valor se puede pasar a las macros dentro de [`std::fmt`] para realizar una redirección útil.
    /// Todas las demás macros de formato ([`format!`], [`write!`], [`println!`], etc.) se transfieren a través de esta.
    /// `format_args!`, a diferencia de sus macros derivadas, evita las asignaciones de montón.
    ///
    /// Puede usar el valor [`fmt::Arguments`] que `format_args!` devuelve en los contextos `Debug` y `Display` como se muestra a continuación.
    /// El ejemplo también muestra que `Debug` y `Display` dan formato a lo mismo: la cadena de formato interpolada en `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Para obtener más información, consulte la documentación en [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Igual que `format_args`, pero agrega una nueva línea al final.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspecciona una variable de entorno en tiempo de compilación.
    ///
    /// Esta macro se expandirá al valor de la variable de entorno nombrada en tiempo de compilación, produciendo una expresión de tipo `&'static str`.
    ///
    ///
    /// Si la variable de entorno no está definida, se emitirá un error de compilación.
    /// Para no emitir un error de compilación, utilice la macro [`option_env!`] en su lugar.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Puede personalizar el mensaje de error pasando una cadena como segundo parámetro:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Si la variable de entorno `documentation` no está definida, obtendrá el siguiente error:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Opcionalmente, inspecciona una variable de entorno en tiempo de compilación.
    ///
    /// Si la variable de entorno nombrada está presente en el momento de la compilación, se expandirá a una expresión de tipo `Option<&'static str>` cuyo valor es `Some` del valor de la variable de entorno.
    /// Si la variable de entorno no está presente, se expandirá a `None`.
    /// Consulte [`Option<T>`][Option] para obtener más información sobre este tipo.
    ///
    /// Nunca se emite un error de tiempo de compilación cuando se usa esta macro, independientemente de si la variable de entorno está presente o no.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatena identificadores en un identificador.
    ///
    /// Esta macro toma cualquier número de identificadores separados por comas y los concatena todos en uno, produciendo una expresión que es un nuevo identificador.
    /// Tenga en cuenta que la higiene hace que esta macro no pueda capturar variables locales.
    /// Además, como regla general, las macros solo se permiten en la posición de elemento, declaración o expresión.
    /// Eso significa que si bien puede usar esta macro para hacer referencia a variables, funciones o módulos existentes, etc., no puede definir una nueva con ella.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (nuevo, divertido, nombre) { }//¡no se puede usar de esta manera!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatena literales en un segmento de cadena estática.
    ///
    /// Esta macro toma cualquier número de literales separados por comas, produciendo una expresión de tipo `&'static str` que representa todos los literales concatenados de izquierda a derecha.
    ///
    ///
    /// Los literales enteros y de coma flotante se encadenan para concatenarlos.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Se expande al número de línea en el que se invocó.
    ///
    /// Con [`column!`] y [`file!`], estas macros proporcionan información de depuración a los desarrolladores sobre la ubicación dentro de la fuente.
    ///
    /// La expresión expandida tiene el tipo `u32` y se basa en 1, por lo que la primera línea de cada archivo se evalúa como 1, la segunda como 2, etc.
    /// Esto es consistente con los mensajes de error de compiladores comunes o editores populares.
    /// La línea devuelta *no es necesariamente* la línea de la propia invocación `line!`, sino la primera invocación de macro que conduce a la invocación de la macro `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Se expande al número de columna en el que se invocó.
    ///
    /// Con [`line!`] y [`file!`], estas macros proporcionan información de depuración a los desarrolladores sobre la ubicación dentro de la fuente.
    ///
    /// La expresión expandida tiene el tipo `u32` y se basa en 1, por lo que la primera columna de cada línea se evalúa como 1, la segunda como 2, etc.
    /// Esto es consistente con los mensajes de error de compiladores comunes o editores populares.
    /// La columna devuelta es *no necesariamente* la línea de la propia invocación `column!`, sino la primera invocación de macro que conduce a la invocación de la macro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Se expande al nombre del archivo en el que se invocó.
    ///
    /// Con [`line!`] y [`column!`], estas macros proporcionan información de depuración a los desarrolladores sobre la ubicación dentro de la fuente.
    ///
    /// La expresión expandida tiene el tipo `&'static str` y el archivo devuelto no es la invocación de la macro `file!` en sí, sino la primera invocación de macro que conduce a la invocación de la macro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifica sus argumentos.
    ///
    /// Esta macro producirá una expresión de tipo `&'static str` que es la cadena de todos los tokens pasados a la macro.
    /// No se imponen restricciones a la sintaxis de la propia invocación de macro.
    ///
    /// Tenga en cuenta que los resultados expandidos de la entrada tokens pueden cambiar en future.Debe tener cuidado si confía en la salida.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Incluye un archivo codificado UTF-8 como una cadena.
    ///
    /// El archivo se ubica en relación con el archivo actual (de manera similar a cómo se encuentran los módulos).
    /// La ruta proporcionada se interpreta de una manera específica de la plataforma en el momento de la compilación.
    /// Entonces, por ejemplo, una invocación con una ruta Windows que contenga barras invertidas `\` no se compilaría correctamente en Unix.
    ///
    ///
    /// Esta macro producirá una expresión de tipo `&'static str` que es el contenido del archivo.
    ///
    /// # Examples
    ///
    /// Suponga que hay dos archivos en el mismo directorio con el siguiente contenido:
    ///
    /// Archivo 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Archivo 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Compilar 'main.rs' y ejecutar el binario resultante imprimirá "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Incluye un archivo como referencia a una matriz de bytes.
    ///
    /// El archivo se ubica en relación con el archivo actual (de manera similar a cómo se encuentran los módulos).
    /// La ruta proporcionada se interpreta de una manera específica de la plataforma en el momento de la compilación.
    /// Entonces, por ejemplo, una invocación con una ruta Windows que contenga barras invertidas `\` no se compilaría correctamente en Unix.
    ///
    ///
    /// Esta macro producirá una expresión de tipo `&'static [u8; N]` que es el contenido del archivo.
    ///
    /// # Examples
    ///
    /// Suponga que hay dos archivos en el mismo directorio con el siguiente contenido:
    ///
    /// Archivo 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Archivo 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Compilar 'main.rs' y ejecutar el binario resultante imprimirá "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Se expande a una cadena que representa la ruta del módulo actual.
    ///
    /// La ruta del módulo actual se puede considerar como la jerarquía de módulos que conducen a crate root.
    /// El primer componente de la ruta devuelta es el nombre del crate que se está compilando actualmente.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Evalúa combinaciones booleanas de indicadores de configuración en tiempo de compilación.
    ///
    /// Además del atributo `#[cfg]`, esta macro se proporciona para permitir la evaluación de expresiones booleanas de los indicadores de configuración.
    /// Con frecuencia, esto conduce a un código menos duplicado.
    ///
    /// La sintaxis dada a esta macro es la misma sintaxis que el atributo [`cfg`].
    ///
    /// `cfg!`, a diferencia de `#[cfg]`, no elimina ningún código y solo se evalúa como verdadero o falso.
    /// Por ejemplo, todos los bloques en una expresión if/else deben ser válidos cuando se usa `cfg!` para la condición, independientemente de lo que `cfg!` esté evaluando.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analiza un archivo como una expresión o un elemento según el contexto.
    ///
    /// El archivo se ubica en relación con el archivo actual (de manera similar a cómo se encuentran los módulos).La ruta proporcionada se interpreta de una manera específica de la plataforma en el momento de la compilación.
    /// Entonces, por ejemplo, una invocación con una ruta Windows que contenga barras invertidas `\` no se compilaría correctamente en Unix.
    ///
    /// El uso de esta macro a menudo es una mala idea, porque si el archivo se analiza como una expresión, se colocará en el código circundante de forma antihigiénica.
    /// Esto podría resultar en variables o funciones diferentes de lo que esperaba el archivo si hay variables o funciones que tienen el mismo nombre en el archivo actual.
    ///
    ///
    /// # Examples
    ///
    /// Suponga que hay dos archivos en el mismo directorio con el siguiente contenido:
    ///
    /// Archivo 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Archivo 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Compilar 'main.rs' y ejecutar el binario resultante imprimirá "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Afirma que una expresión booleana es `true` en tiempo de ejecución.
    ///
    /// Esto invocará la macro [`panic!`] si la expresión proporcionada no se puede evaluar a `true` en tiempo de ejecución.
    ///
    /// # Uses
    ///
    /// Las afirmaciones siempre se comprueban tanto en versiones de depuración como de versiones, y no se pueden deshabilitar.
    /// Consulte [`debug_assert!`] para ver las afirmaciones que no están habilitadas en las versiones de versiones de forma predeterminada.
    ///
    /// El código inseguro puede depender de `assert!` para hacer cumplir invariantes en tiempo de ejecución que, si se violan, podrían generar inseguridad.
    ///
    /// Otros casos de uso de `assert!` incluyen probar y hacer cumplir invariantes en tiempo de ejecución en código seguro (cuya violación no puede resultar en inseguridad).
    ///
    ///
    /// # Mensajes personalizados
    ///
    /// Esta macro tiene una segunda forma, donde se puede proporcionar un mensaje panic personalizado con o sin argumentos para formatear.
    /// Consulte [`std::fmt`] para conocer la sintaxis de este formulario.
    /// Las expresiones utilizadas como argumentos de formato solo se evaluarán si la aserción falla.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // el mensaje panic para estas afirmaciones es el valor en cadena de la expresión dada.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // una función muy simple
    ///
    /// assert!(some_computation());
    ///
    /// // afirmar con un mensaje personalizado
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Montaje en línea.
    ///
    /// Lea el [unstable book] para conocer el uso.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Ensamblaje en línea estilo LLVM.
    ///
    /// Lea el [unstable book] para conocer el uso.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Ensamblaje en línea a nivel de módulo.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Las impresiones pasaron tokens a la salida estándar.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Habilita o deshabilita la funcionalidad de seguimiento utilizada para depurar otras macros.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Macro de atributo utilizada para aplicar macros de derivación.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Macro de atributo aplicada a una función para convertirla en una prueba unitaria.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Macro de atributo aplicada a una función para convertirla en una prueba de referencia.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Un detalle de implementación de las macros `#[test]` y `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Macro de atributo aplicada a una estática para registrarla como asignador global.
    ///
    /// Consulte también [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Mantiene el elemento al que se aplica si se puede acceder a la ruta pasada y, en caso contrario, lo elimina.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Expande todos los atributos `#[cfg]` y `#[cfg_attr]` en el fragmento de código al que se aplica.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Detalle de implementación inestable del compilador `rustc`, no lo use.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Detalle de implementación inestable del compilador `rustc`, no lo use.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}