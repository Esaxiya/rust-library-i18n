#![stable(feature = "core_hint", since = "1.27.0")]

//! Sugerencias para el compilador que afectan a cómo se debe emitir u optimizar el código.
//! Las sugerencias pueden ser tiempo de compilación o tiempo de ejecución.

use crate::intrinsics;

/// Informa al compilador que este punto del código no es accesible, lo que permite más optimizaciones.
///
/// # Safety
///
/// Alcanzar esta función es completamente *comportamiento indefinido*(UB).En particular, el compilador asume que todo UB nunca debe suceder y, por lo tanto, eliminará todas las ramas que lleguen a una llamada a `unreachable_unchecked()`.
///
/// Como todas las instancias de UB, si esta suposición resulta ser incorrecta, es decir, la llamada `unreachable_unchecked()` es realmente accesible entre todos los flujos de control posibles, el compilador aplicará la estrategia de optimización incorrecta y, a veces, incluso puede corromper el código aparentemente no relacionado, causando dificultades. para depurar problemas.
///
///
/// Utilice esta función solo cuando pueda demostrar que el código nunca la llamará.
/// De lo contrario, considere usar la macro [`unreachable!`], que no permite optimizaciones pero hará panic cuando se ejecute.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` es siempre positivo (no cero), por lo tanto, `checked_div` nunca devolverá `None`.
/////
///     // Por lo tanto, el else branch es inalcanzable.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SEGURIDAD: el contrato de seguridad para `intrinsics::unreachable` debe
    // ser sostenido por la persona que llama.
    unsafe { intrinsics::unreachable() }
}

/// Emite una instrucción de máquina para indicar al procesador que se está ejecutando en un bucle de giro de espera ocupado ("bloqueo de giro").
///
/// Al recibir la señal de bucle giratorio, el procesador puede optimizar su comportamiento, por ejemplo, ahorrando energía o cambiando los hilos hyper.
///
/// Esta función es diferente de [`thread::yield_now`] que cede directamente al programador del sistema, mientras que `spin_loop` no interactúa con el sistema operativo.
///
/// Un caso de uso común para `spin_loop` es implementar un giro optimista limitado en un bucle CAS en primitivas de sincronización.
/// Para evitar problemas como la inversión de prioridad, se recomienda encarecidamente que el bucle de giro finalice después de una cantidad finita de iteraciones y se realice una llamada al sistema de bloqueo adecuada.
///
///
/// **Nota**: En las plataformas que no admiten la recepción de sugerencias de bucle giratorio, esta función no hace nada en absoluto.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Un valor atómico compartido que los subprocesos utilizarán para coordinar
/// let live = Arc::new(AtomicBool::new(false));
///
/// // En un hilo de fondo eventualmente estableceremos el valor
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Trabaja un poco, luego haz que el valor viva
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // De vuelta en nuestro hilo actual, esperamos a que se establezca el valor
/// while !live.load(Ordering::Acquire) {
///     // El bucle de giro es una pista para la CPU de que estamos esperando, pero probablemente no por mucho tiempo.
/////
///     hint::spin_loop();
/// }
///
/// // El valor ahora está establecido
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SEGURIDAD: el atributo `cfg` garantiza que solo ejecutemos esto en objetivos x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SEGURIDAD: el atributo `cfg` garantiza que solo ejecutemos esto en objetivos x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SEGURIDAD: el atributo `cfg` garantiza que solo ejecutemos esto en objetivos aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SEGURIDAD: el atributo `cfg` garantiza que solo ejecutemos esto en objetivos de brazo
            // con soporte para la función v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Una función de identidad que *__ sugiere __* al compilador que sea el máximo pesimista sobre lo que `black_box` podría hacer.
///
/// A diferencia de [`std::convert::identity`], se recomienda a un compilador Rust que asuma que `black_box` puede usar `dummy` de cualquier forma válida posible que el código Rust pueda hacer sin introducir un comportamiento indefinido en el código de llamada.
///
/// Esta propiedad hace que `black_box` sea útil para escribir código en el que no se desean ciertas optimizaciones, como los puntos de referencia.
///
/// Sin embargo, tenga en cuenta que `black_box` solo se proporciona (y solo puede) proporcionarse sobre una base "best-effort".La medida en que puede bloquear las optimizaciones puede variar según la plataforma y el backend de generación de código utilizado.
/// Los programas no pueden confiar en `black_box` para *corrección* de ninguna manera.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Necesitamos "use" el argumento de alguna manera que LLVM no puede introspectar, y en los objetivos que lo admiten, normalmente podemos aprovechar el ensamblaje en línea para hacer esto.
    // La interpretación de LLVM del ensamblaje en línea es que es, bueno, una caja negra.
    // Esta no es la mejor implementación ya que probablemente desoptimiza más de lo que queremos, pero hasta ahora es lo suficientemente buena.
    //
    //

    #[cfg(not(miri))] // Esto es solo una pista, por lo que está bien omitir Miri.
    // SEGURIDAD: el ensamblaje en línea no es operativo.
    unsafe {
        // FIXME: No se puede usar `asm!` porque no es compatible con MIPS y otras arquitecturas.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}