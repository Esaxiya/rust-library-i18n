//! Tipos que anclan datos a su ubicación en la memoria.
//!
//! A veces es útil tener objetos que estén garantizados para no moverse, en el sentido de que su ubicación en la memoria no cambia y, por lo tanto, se puede confiar en ellos.
//! Un excelente ejemplo de tal escenario sería la construcción de estructuras autorreferenciales, ya que mover un objeto con punteros a sí mismo los invalidaría, lo que podría causar un comportamiento indefinido.
//!
//! En un nivel alto, un [`Pin<P>`] asegura que el puntero de cualquier tipo de puntero `P` tenga una ubicación estable en la memoria, lo que significa que no se puede mover a otro lugar y su memoria no se puede desasignar hasta que se elimine.Decimos que el puntero es "pinned".Las cosas se vuelven más sutiles cuando se habla de tipos que combinan datos fijos con datos no fijados;[see below](#projections-and-structural-pinning) para más detalles.
//!
//! De forma predeterminada, todos los tipos de Rust son móviles.
//! Rust permite pasar todos los tipos por valor, y los tipos de puntero inteligente comunes como [`Box<T>`] y `&mut T` permiten reemplazar y mover los valores que contienen: puede salir de un [`Box<T>`] o puede usar [`mem::swap`].
//! [`Pin<P>`] envuelve un puntero tipo `P`, por lo que [`Pin`]`<`[`Box`] `<T>>`funciona de forma muy parecida a una
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`se cae, también lo hace su contenido, y la memoria se
//!
//! desasignado.De manera similar, [`Pin`]`<&mut T>`se parece mucho a `&mut T`.Sin embargo, [`Pin<P>`] no permite que los clientes obtengan un [`Box<T>`] o `&mut T` para datos anclados, lo que implica que no puede utilizar operaciones como [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` necesita `&mut T`, pero no podemos conseguirlo.
//!     // Estamos atascados, no podemos intercambiar el contenido de estas referencias.
//!     // Podríamos usar `Pin::get_unchecked_mut`, pero eso no es seguro por una razón:
//!     // no podemos usarlo para mover cosas fuera del `Pin`.
//! }
//! ```
//!
//! Vale la pena reiterar que [`Pin<P>`]*no* cambia el hecho de que un compilador Rust considera todos los tipos móviles.[`mem::swap`] sigue siendo invocable para cualquier `T`.En cambio, [`Pin<P>`] evita que ciertos *valores*(señalados por punteros envueltos en [`Pin<P>`]) se muevan al hacer imposible llamar a métodos que requieren `&mut T` en ellos (como [`mem::swap`]).
//!
//! [`Pin<P>`] se puede utilizar para envolver cualquier tipo de puntero `P` y, como tal, interactúa con [`Deref`] y [`DerefMut`].Un [`Pin<P>`] donde `P: Deref` debe considerarse como un "`P`-style pointer" a un `P::Target` anclado, por lo tanto, un [`Pin`]`<`[`Box`] `<T>>`es un puntero propio a un `T` anclado, y un [`Pin`] `<` [`Rc`]`<T>>`es un puntero contado por referencia a un `T` anclado.
//! Para que sea correcto, [`Pin<P>`] se basa en las implementaciones de [`Deref`] y [`DerefMut`] para no salir de su parámetro `self` y solo para devolver un puntero a datos anclados cuando se los llama en un puntero fijo.
//!
//! # `Unpin`
//!
//! Muchos tipos siempre se pueden mover libremente, incluso cuando están anclados, porque no dependen de tener una dirección estable.Esto incluye todos los tipos básicos (como [`bool`], [`i32`] y referencias), así como los tipos que constan únicamente de estos tipos.Los tipos que no se preocupan por la fijación implementan el [`Unpin`] auto-trait, que cancela el efecto de [`Pin<P>`].
//! Para `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`y [`Box<T>`] funcionan de manera idéntica, al igual que [`Pin`] `<&mut T>` y `&mut T`.
//!
//! Tenga en cuenta que la fijación y [`Unpin`] solo afectan al tipo `P::Target` apuntado, no al tipo de puntero `P` en sí que se envolvió en [`Pin<P>`].Por ejemplo, si [`Box<T>`] es [`Unpin`] o no, no tiene ningún efecto en el comportamiento de [`Pin`]`<`[`Box`] `<T>>`(aquí, `T` es el tipo apuntado).
//!
//! # Ejemplo: estructura autorreferencial
//!
//! Antes de entrar en más detalles para explicar las garantías y opciones asociadas con `Pin<T>`, analizamos algunos ejemplos de cómo podría usarse.
//! Siéntase libre de [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Esta es una estructura autorreferencial porque el campo de corte apunta al campo de datos.
//! // No podemos informar al compilador sobre eso con una referencia normal, ya que este patrón no se puede describir con las reglas de préstamo habituales.
//! //
//! // En su lugar, usamos un puntero sin formato, aunque se sabe que no es nulo, ya que sabemos que apunta a la cadena.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Para asegurarnos de que los datos no se muevan cuando la función regrese, los colocamos en el montón donde permanecerá durante la vida útil del objeto, y la única forma de acceder a ellos sería a través de un puntero.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // solo creamos el puntero una vez que los datos están en su lugar, de lo contrario, ya se habrán movido antes de comenzar
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // sabemos que esto es seguro porque modificar un campo no mueve toda la estructura
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // El puntero debe apuntar a la ubicación correcta, siempre que la estructura no se haya movido.
//! //
//! // Mientras tanto, podemos mover el puntero libremente.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Dado que nuestro tipo no implementa Unpin, esto no se compilará:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Ejemplo: lista intrusiva doblemente enlazada
//!
//! En una lista intrusiva doblemente enlazada, la colección en realidad no asigna la memoria para los elementos en sí.
//! Los clientes controlan la asignación, y los elementos pueden vivir en un marco de pila que dura menos que la colección.
//!
//! Para que esto funcione, cada elemento tiene punteros a su predecesor y sucesor en la lista.Los elementos solo se pueden agregar cuando están anclados, porque mover los elementos invalidaría los punteros.Además, la implementación [`Drop`] de un elemento de lista enlazada parcheará los punteros de su predecesor y sucesor para eliminarse de la lista.
//!
//! Fundamentalmente, tenemos que poder confiar en que se llame a [`drop`].Si un elemento pudiera ser desasignado o invalidado sin llamar a [`drop`], los punteros de sus elementos vecinos se volverían inválidos, lo que rompería la estructura de datos.
//!
//! Por lo tanto, la fijación también viene con una garantía relacionada con ["drop"].
//!
//! # `Drop` guarantee
//!
//! El propósito de la fijación es poder confiar en la ubicación de algunos datos en la memoria.
//! Para que esto funcione, no solo se restringe el movimiento de los datos;La desasignación, reutilización o invalidación de la memoria utilizada para almacenar los datos también está restringida.
//! Concretamente, para los datos anclados, debe mantener el invariante de que *su memoria no se invalidará ni se reutilizará desde el momento en que se fija hasta que se llame a [`drop`]*.Solo una vez que [`drop`] regrese o panics, la memoria se puede reutilizar.
//!
//! La memoria puede ser "invalidated" por desasignación, pero también reemplazando un [`Some(v)`] por [`None`], o llamando a [`Vec::set_len`] a "kill" algunos elementos de un vector.Se puede reutilizar utilizando [`ptr::write`] para sobrescribirlo sin llamar primero al destructor.Nada de esto está permitido para datos anclados sin llamar a [`drop`].
//!
//! Este es exactamente el tipo de garantía que la lista enlazada intrusiva de la sección anterior necesita para funcionar correctamente.
//!
//! Tenga en cuenta que esta garantía *no* significa que la memoria no se pierda.Todavía está completamente bien no llamar nunca a [`drop`] en un elemento fijo (por ejemplo, aún puede llamar a [`mem::forget`] en un [`Pin`]`<`[`Box`] `<T>>`).En el ejemplo de la lista doblemente enlazada, ese elemento simplemente permanecería en la lista.Sin embargo, no puede liberar o reutilizar el almacenamiento *sin llamar a [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Si su tipo usa pinning (como los dos ejemplos anteriores), debe tener cuidado al implementar [`Drop`].La función [`drop`] toma `&mut self`, ¡pero esto se llama *incluso si su tipo fue anclado previamente*!Es como si el compilador llamara automáticamente [`Pin::get_unchecked_mut`].
//!
//! Esto nunca puede causar un problema en el código seguro porque la implementación de un tipo que se basa en la fijación requiere un código inseguro, pero tenga en cuenta que decidir hacer uso de la fijación en su tipo (por ejemplo, implementando alguna operación en [`Pin`]`<&Self>`o [`Pin`] `<&mut Self>`) también tiene consecuencias para la implementación de [`Drop`]: si un elemento de su tipo podría haber sido anclado, debe tratar [`Drop`] como implícitamente tomando [`Pin`]`<&mut Yo>`.
//!
//!
//! Por ejemplo, podría implementar `Drop` de la siguiente manera:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` está bien porque sabemos que este valor nunca se vuelve a utilizar después de descartarlo.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // El código de caída real va aquí.
//!         }
//!     }
//! }
//! ```
//!
//! La función `inner_drop` tiene el tipo que [`drop`]*debería* tener, por lo que esto asegura que no use accidentalmente `self`/`this` de una manera que esté en conflicto con la fijación.
//!
//! Además, si su tipo es `#[repr(packed)]`, el compilador moverá automáticamente los campos para poder eliminarlos.Incluso podría hacerlo para campos que estén suficientemente alineados.Como consecuencia, no puede utilizar la función de anclar con un tipo `#[repr(packed)]`.
//!
//! # Proyecciones y fijación estructural
//!
//! Cuando se trabaja con estructuras ancladas, surge la pregunta de cómo se puede acceder a los campos de esa estructura en un método que solo toma [`Pin`]`<&mut Struct>`.
//! El enfoque habitual es escribir métodos auxiliares (los llamados *proyecciones*) que convierten [`Pin`]`<&mut Struct>`en una referencia al campo, pero ¿qué tipo debería tener esa referencia?¿Es [`Pin`]`<&mut Field>`o `&mut Field`?
//! La misma pregunta surge con los campos de un `enum`, y también cuando se consideran tipos container/wrapper como [`Vec<T>`], [`Box<T>`] o [`RefCell<T>`].
//! (Esta pregunta se aplica tanto a referencias mutables como compartidas, solo usamos el caso más común de referencias mutables aquí como ilustración).
//!
//! Resulta que en realidad depende del autor de la estructura de datos decidir si la proyección fijada para un campo en particular convierte [`Pin`]`<&mut Struct>`en [`Pin`] `<&mut Field>` o `&mut Field`.Sin embargo, existen algunas restricciones, y la restricción más importante es *consistencia*:
//! cada campo puede ser *o* proyectado a una referencia fija,*o* eliminar la fijación como parte de la proyección.
//! Si ambos se hacen para el mismo campo, ¡probablemente no sea correcto!
//!
//! Como autor de una estructura de datos, puede decidir para cada campo si anclar "propagates" a este campo o no.
//! La fijación que se propaga también se llama "structural", porque sigue la estructura del tipo.
//! En las siguientes subsecciones, describimos las consideraciones que deben hacerse para cualquiera de las opciones.
//!
//! ## Fijar *no es* estructural para `field`
//!
//! Puede parecer contrario a la intuición que el campo de una estructura anclada no esté anclado, pero esa es en realidad la opción más fácil: si un [`Pin`]`<&mut Field>`nunca se crea, ¡nada puede salir mal!Por lo tanto, si decide que algún campo no tiene anclaje estructural, todo lo que tiene que asegurarse es que nunca cree una referencia anclada a ese campo.
//!
//! Los campos sin fijación estructural pueden tener un método de proyección que convierte [`Pin`]`<&mut Struct>`en `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Esto está bien porque `field` nunca se considera anclado.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! También puede `impl Unpin for Struct`*incluso si* el tipo de `field` no es [`Unpin`].Lo que ese tipo piensa sobre la fijación no es relevante cuando nunca se crea un [`Pin`]`<&mut Field>`.
//!
//! ## La fijación *es* estructural para `field`
//!
//! La otra opción es decidir que el anclaje es "structural" para `field`, lo que significa que si la estructura está anclada, también lo está el campo.
//!
//! Esto permite escribir una proyección que crea un [`Pin`]`<&mut Field>`, dando testimonio de que el campo está anclado:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Esto está bien porque `field` está anclado cuando `self` lo está.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Sin embargo, la fijación estructural viene con algunos requisitos adicionales:
//!
//! 1. La estructura solo debe ser [`Unpin`] si todos los campos estructurales son [`Unpin`].Este es el valor predeterminado, pero [`Unpin`] es un trait seguro, por lo que, como autor de la estructura, es su responsabilidad *no* agregar algo como `impl<T> Unpin for Struct<T>`.
//! (Tenga en cuenta que agregar una operación de proyección requiere un código inseguro, por lo que el hecho de que [`Unpin`] sea un trait seguro no rompe el principio de que solo debe preocuparse por algo de esto si usa `inseguro`).
//! 2. El destructor de la estructura no debe sacar los campos estructurales de su argumento.Este es el punto exacto que se planteó en el [previous section][drop-impl]: `drop` toma `&mut self`, pero la estructura (y, por lo tanto, sus campos) podrían haberse anclado antes.
//!     Debe garantizar que no mueva un campo dentro de su implementación [`Drop`].
//!     En particular, como se explicó anteriormente, esto significa que su estructura *no* debe ser `#[repr(packed)]`.
//!     Consulte esa sección para saber cómo escribir [`drop`] de una manera que el compilador pueda ayudarlo a no romper accidentalmente la fijación.
//! 3. Debe asegurarse de mantener el [`Drop` guarantee][drop-guarantee]:
//!     una vez que se fija su estructura, la memoria que contiene el contenido no se sobrescribe ni se desasigna sin llamar a los destructores del contenido.
//!     Esto puede ser complicado, como lo atestigua [`VecDeque<T>`]: el destructor de [`VecDeque<T>`] puede fallar al llamar a [`drop`] en todos los elementos si uno de los destructores panics.Esto viola la garantía [`Drop`], porque puede llevar a que se desasignen elementos sin que se llame a su destructor.([`VecDeque<T>`] no tiene proyecciones de fijación, por lo que esto no causa problemas).
//! 4. No debe ofrecer ninguna otra operación que pueda llevar a que los datos se muevan fuera de los campos estructurales cuando su tipo está anclado.Por ejemplo, si la estructura contiene un [`Option<T>`] y hay una operación similar a "tomar" con el tipo `fn(Pin<&mut Struct<T>>) -> Option<T>`, esa operación se puede usar para mover un `T` fuera de un `Struct<T>` fijado, lo que significa que la fijación no puede ser estructural para el campo que contiene este datos.
//!
//!     Para ver un ejemplo más complejo de mover datos fuera de un tipo fijo, imagine si [`RefCell<T>`] tuviera un método `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Entonces podríamos hacer lo siguiente:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Esto es catastrófico, significa que primero podemos anclar el contenido del [`RefCell<T>`] (usando `RefCell::get_pin_mut`) y luego mover ese contenido usando la referencia mutable que obtuvimos más tarde.
//!
//! ## Examples
//!
//! Para un tipo como [`Vec<T>`], ambas posibilidades (fijación estructural o no) tienen sentido.
//! Un [`Vec<T>`] con fijación estructural podría tener métodos `get_pin`/`get_pin_mut` para obtener referencias fijadas a elementos.Sin embargo, no podría * permitir llamar a [`pop`][Vec::pop] en un [`Vec<T>`] fijado porque eso movería el contenido (fijado estructuralmente).Tampoco podría permitir [`push`][Vec::push], que podría reasignar y, por lo tanto, también mover los contenidos.
//!
//! Un [`Vec<T>`] sin fijación estructural podría ser `impl<T> Unpin for Vec<T>`, porque el contenido nunca se fija y el propio [`Vec<T>`] también está bien para ser movido.
//! En ese punto, fijar simplemente no tiene ningún efecto en el vector.
//!
//! En la biblioteca estándar, los tipos de puntero generalmente no tienen fijación estructural y, por lo tanto, no ofrecen proyecciones de fijación.Es por eso que `Box<T>: Unpin` es válido para todos los `T`.
//! Tiene sentido hacer esto para los tipos de puntero, porque mover el `Box<T>` en realidad no mueve el `T`: el [`Box<T>`] puede moverse libremente (también conocido como `Unpin`) incluso si el `T` no lo es.De hecho, incluso [`Pin`]`<`[`Box`] `<T>>`y [`Pin`] `<&mut T>` son siempre [`Unpin`] en sí mismos, por la misma razón: su contenido (el `T`) está anclado, pero los punteros en sí se pueden mover sin mover los datos fijados.
//! Para [`Box<T>`] y [`Pin`]`<`[`Box`] `<T>>`, si el contenido está anclado es totalmente independiente de si el puntero está anclado, lo que significa que la fijación *no* es estructural.
//!
//! Al implementar un combinador [`Future`], normalmente necesitará un anclaje estructural para el futures anidado, ya que necesita obtener referencias ancladas a ellos para llamar a [`poll`].
//! Pero si su combinador contiene cualquier otro dato que no necesita ser anclado, puede hacer que esos campos no sean estructurales y, por lo tanto, acceder a ellos libremente con una referencia mutable incluso cuando solo tenga [`Pin`]`<&mut Self>`(tal como en su propia implementación [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Un puntero anclado.
///
/// Esta es una envoltura alrededor de una especie de puntero que hace que ese puntero "pin" tenga su valor en su lugar, evitando que el valor al que hace referencia ese puntero se mueva a menos que implemente [`Unpin`].
///
///
/// *Consulte la documentación de [`pin` module] para obtener una explicación de la fijación.*
///
/// [`pin` module]: self
///
// Note: el `Clone` derivado a continuación causa fallas, ya que es posible implementar
// `Clone` para referencias mutables.
// Consulte <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> para obtener más detalles.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Las siguientes implementaciones no se derivan para evitar problemas de solidez.
// `&self.pointer` no debe ser accesible para implementaciones de trait que no sean de confianza.
//
// Consulte <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> para obtener más detalles.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Construya un nuevo `Pin<P>` alrededor de un puntero a algunos datos de un tipo que implemente [`Unpin`].
    ///
    /// A diferencia de `Pin::new_unchecked`, este método es seguro porque el puntero `P` elimina las referencias a un tipo [`Unpin`], lo que cancela las garantías de fijación.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SEGURIDAD: el valor señalado es `Unpin`, por lo que no tiene requisitos
        // alrededor de la fijación.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Desenvuelve este `Pin<P>` devolviendo el puntero subyacente.
    ///
    /// Esto requiere que los datos dentro de este `Pin` sean [`Unpin`] para que podamos ignorar los invariantes de fijación al desenvolverlo.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Construya un nuevo `Pin<P>` alrededor de una referencia a algunos datos de un tipo que puede o no implementar `Unpin`.
    ///
    /// Si `pointer` elimina las referencias a un tipo `Unpin`, se debe utilizar `Pin::new` en su lugar.
    ///
    /// # Safety
    ///
    /// Este constructor no es seguro porque no podemos garantizar que los datos señalados por `pointer` estén anclados, lo que significa que los datos no se moverán o su almacenamiento se invalidará hasta que se eliminen.
    /// Si el `Pin<P>` construido no garantiza que los datos a los que apunta `P` estén anclados, eso es una violación del contrato de API y puede conducir a un comportamiento indefinido en operaciones posteriores de (safe).
    ///
    /// Al usar este método, está haciendo un promise sobre las implementaciones `P::Deref` y `P::DerefMut`, si existen.
    /// Lo más importante es que no deben salirse de sus argumentos `self`: `Pin::as_mut` y `Pin::as_ref` llamarán a `DerefMut::deref_mut` y `Deref::deref`*en el puntero fijo* y esperarán que estos métodos mantengan los invariantes de fijación.
    /// Además, al llamar a este método, promise que las desreferencias de `P` de referencia a no se moverán de nuevo;en particular, no debe ser posible obtener un `&mut P::Target` y luego salir de esa referencia (usando, por ejemplo, [`mem::swap`]).
    ///
    ///
    /// Por ejemplo, llamar a `Pin::new_unchecked` en un `&'a mut T` no es seguro porque, si bien puede anclarlo durante el tiempo de vida determinado `'a`, no tiene control sobre si se mantiene anclado una vez que `'a` finaliza:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Esto debería significar que el pointee `a` nunca podrá volver a moverse.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // La dirección de `a` cambió a la ranura de pila de `b`, por lo que `a` se movió a pesar de que lo habíamos fijado previamente.Hemos violado el contrato de la API de fijación.
    /////
    /// }
    /// ```
    ///
    /// Un valor, una vez fijado, debe permanecer fijado para siempre (a menos que su tipo implemente `Unpin`).
    ///
    /// De manera similar, llamar a `Pin::new_unchecked` en un `Rc<T>` no es seguro porque podría haber alias para los mismos datos que no están sujetos a las restricciones de fijación:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Esto debería significar que el puntero nunca podrá volver a moverse.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Ahora, si `x` fuera la única referencia, tenemos una referencia mutable a los datos que ancimos arriba, que podríamos usar para moverlos como hemos visto en el ejemplo anterior.
    ///     // Hemos violado el contrato de la API de fijación.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Obtiene una referencia compartida anclada de este puntero fijo.
    ///
    /// Este es un método genérico para pasar de `&Pin<Pointer<T>>` a `Pin<&T>`.
    /// Es seguro porque, como parte del contrato de `Pin::new_unchecked`, el puntero no puede moverse después de que se creó `Pin<Pointer<T>>`.
    ///
    /// "Malicious" Las implementaciones de `Pointer::Deref` también están descartadas por el contrato de `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SEGURIDAD: consulte la documentación sobre esta función
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Desenvuelve este `Pin<P>` devolviendo el puntero subyacente.
    ///
    /// # Safety
    ///
    /// Esta función no es segura.Debe garantizar que continuará tratando el puntero `P` como anclado después de llamar a esta función, de modo que se puedan mantener las invariantes en el tipo `Pin`.
    /// Si el código que usa el `P` resultante no continúa manteniendo los invariantes de fijación, eso es una violación del contrato de API y puede conducir a un comportamiento indefinido en operaciones posteriores de (safe).
    ///
    ///
    /// Si los datos subyacentes son [`Unpin`], se debe utilizar [`Pin::into_inner`] en su lugar.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Obtiene una referencia mutable anclada de este puntero fijo.
    ///
    /// Este es un método genérico para pasar de `&mut Pin<Pointer<T>>` a `Pin<&mut T>`.
    /// Es seguro porque, como parte del contrato de `Pin::new_unchecked`, el puntero no puede moverse después de que se creó `Pin<Pointer<T>>`.
    ///
    /// "Malicious" Las implementaciones de `Pointer::DerefMut` también están descartadas por el contrato de `Pin::new_unchecked`.
    ///
    /// Este método es útil cuando se realizan múltiples llamadas a funciones que consumen el tipo fijo.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // hacer algo
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` consume `self`, así que vuelva a pedir el `Pin<&mut Self>` a través de `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SEGURIDAD: consulte la documentación sobre esta función
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Asigna un nuevo valor a la memoria detrás de la referencia anclada.
    ///
    /// Esto sobrescribe los datos anclados, pero está bien: su destructor se ejecuta antes de sobrescribirse, por lo que no se viola ninguna garantía de anclaje.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Construye un nuevo pin mapeando el valor interior.
    ///
    /// Por ejemplo, si desea obtener un `Pin` de un campo de algo, puede usar esto para obtener acceso a ese campo en una línea de código.
    /// Sin embargo, hay varios errores con estos "pinning projections";
    /// consulte la documentación de [`pin` module] para obtener más detalles sobre ese tema.
    ///
    /// # Safety
    ///
    /// Esta función no es segura.
    /// Debe garantizar que los datos que devuelve no se moverán mientras el valor del argumento no se mueva (por ejemplo, porque es uno de los campos de ese valor), y también que no se mueva fuera del argumento que recibe para la función interior.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SEGURIDAD: el contrato de seguridad para `new_unchecked` debe ser
        // sostenido por la persona que llama.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Obtiene una referencia compartida de un pin.
    ///
    /// Esto es seguro porque no es posible salir de una referencia compartida.
    /// Puede parecer que aquí hay un problema con la mutabilidad interior: de hecho,*es* posible sacar un `T` de un `&RefCell<T>`.
    /// Sin embargo, esto no es un problema siempre que no exista también un `Pin<&T>` que apunte a los mismos datos, y `RefCell<T>` no le permite crear una referencia fija a su contenido.
    ///
    /// Consulte la discusión sobre ["pinning projections"] para obtener más detalles.
    ///
    /// Note: `Pin` también implementa `Deref` en el objetivo, que se puede utilizar para acceder al valor interno.
    /// Sin embargo, `Deref` solo proporciona una referencia que dura tanto como el préstamo del `Pin`, no la vida útil del `Pin` en sí.
    /// Este método permite convertir el `Pin` en una referencia con la misma vida útil que el `Pin` original.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Convierte este `Pin<&mut T>` en un `Pin<&T>` con la misma vida útil.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Obtiene una referencia mutable a los datos dentro de este `Pin`.
    ///
    /// Esto requiere que los datos dentro de este `Pin` sean `Unpin`.
    ///
    /// Note: `Pin` también implementa `DerefMut` a los datos, que se pueden usar para acceder al valor interno.
    /// Sin embargo, `DerefMut` solo proporciona una referencia que dura tanto como el préstamo del `Pin`, no la vida útil del `Pin` en sí.
    ///
    /// Este método permite convertir el `Pin` en una referencia con la misma vida útil que el `Pin` original.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Obtiene una referencia mutable a los datos dentro de este `Pin`.
    ///
    /// # Safety
    ///
    /// Esta función no es segura.
    /// Debe garantizar que nunca sacará los datos de la referencia mutable que recibe cuando llama a esta función, de modo que se puedan mantener las invariantes en el tipo `Pin`.
    ///
    ///
    /// Si los datos subyacentes son `Unpin`, se debe utilizar `Pin::get_mut` en su lugar.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Construya un nuevo pin mapeando el valor interior.
    ///
    /// Por ejemplo, si desea obtener un `Pin` de un campo de algo, puede usar esto para obtener acceso a ese campo en una línea de código.
    /// Sin embargo, hay varios errores con estos "pinning projections";
    /// consulte la documentación de [`pin` module] para obtener más detalles sobre ese tema.
    ///
    /// # Safety
    ///
    /// Esta función no es segura.
    /// Debe garantizar que los datos que devuelve no se moverán mientras el valor del argumento no se mueva (por ejemplo, porque es uno de los campos de ese valor), y también que no se mueva fuera del argumento que recibe para la función interior.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SEGURIDAD: la persona que llama es responsable de no mover el
        // valor fuera de esta referencia.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SEGURIDAD: ya que se garantiza que el valor de `this` no
        // se ha movido, esta llamada a `new_unchecked` es segura.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Obtenga una referencia fija de una referencia estática.
    ///
    /// Esto es seguro, porque el `T` se toma prestado para la vida útil del `'static`, que nunca termina.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SEGURIDAD: El 'préstamo estático garantiza que los datos no serán
        // moved/invalidated hasta que se caiga (que nunca es).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Obtenga una referencia mutable fijada a partir de una referencia mutable estática.
    ///
    /// Esto es seguro, porque el `T` se toma prestado para la vida útil del `'static`, que nunca termina.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SEGURIDAD: El 'préstamo estático garantiza que los datos no serán
        // moved/invalidated hasta que se caiga (que nunca es).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: esto significa que cualquier impl de `CoerceUnsized` que permita la coacción de
// un tipo que implica `Deref<Target=impl !Unpin>` a un tipo que implica `Deref<Target=Unpin>` no es sólido.
// Sin embargo, cualquier implícita de este tipo probablemente no sería sólida por otras razones, por lo que solo debemos tener cuidado de no permitir que tales implícitas aterricen en std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}