use crate::iter::{FusedIterator, TrustedLen};

/// Crea un nuevo iterador que repite sin cesar un solo elemento.
///
/// La función `repeat()` repite un solo valor una y otra vez.
///
/// Los iteradores infinitos como `repeat()` se utilizan a menudo con adaptadores como [`Iterator::take()`], para hacerlos finitos.
///
/// Si el tipo de elemento del iterador que necesita no implementa `Clone`, o si no desea mantener el elemento repetido en la memoria, puede usar la función [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::iter;
///
/// // el número cuatro 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // sí, todavía cuatro
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Haciéndose finito con [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // ese último ejemplo fueron demasiados cuatro.Solo tengamos cuatro cuatros.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... y ahora hemos terminado
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Un iterador que repite un elemento sin cesar.
///
/// Este `struct` es creado por la función [`repeat()`].Consulte su documentación para obtener más información.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}