use crate::fmt;

/// Crea un nuevo iterador donde cada iteración llama al cierre proporcionado `F: FnMut() -> Option<T>`.
///
/// Esto permite crear un iterador personalizado con cualquier comportamiento sin usar la sintaxis más detallada de crear un tipo dedicado e implementar el [`Iterator`] trait para él.
///
/// Tenga en cuenta que el iterador `FromFn` no hace suposiciones sobre el comportamiento del cierre y, por lo tanto, de forma conservadora no implementa [`FusedIterator`] ni anula [`Iterator::size_hint()`] de su `(0, None)` predeterminado.
///
///
/// El cierre puede usar capturas y su entorno para rastrear el estado en las iteraciones.Dependiendo de cómo se use el iterador, esto puede requerir especificar la palabra clave [`move`] en el cierre.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Reimplementemos el iterador de contador de [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Incrementa nuestro recuento.Por eso empezamos de cero.
///     count += 1;
///
///     // Compruebe si hemos terminado de contar o no.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Un iterador en el que cada iteración llama al cierre proporcionado `F: FnMut() -> Option<T>`.
///
/// Este `struct` es creado por la función [`iter::from_fn()`].
/// Consulte su documentación para obtener más información.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}