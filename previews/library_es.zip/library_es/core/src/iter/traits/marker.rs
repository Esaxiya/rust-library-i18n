/// Un iterador que siempre continúa produciendo `None` cuando se agota.
///
/// Si se llama a continuación a un iterador fusionado que ha devuelto `None` una vez, se garantiza que devolverá [`None`] de nuevo.
/// Este trait debe ser implementado por todos los iteradores que se comportan de esta manera porque permite optimizar [`Iterator::fuse()`].
///
///
/// Note: En general, no debe usar `FusedIterator` en límites genéricos si necesita un iterador fusionado.
/// En su lugar, debería llamar a [`Iterator::fuse()`] en el iterador.
/// Si el iterador ya está fusionado, el contenedor [`Fuse`] adicional será una operación no operativa sin penalización de rendimiento.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Un iterador que informa una longitud precisa mediante size_hint.
///
/// El iterador informa una sugerencia de tamaño donde es exacto (el límite inferior es igual al límite superior) o el límite superior es [`None`].
///
/// El límite superior solo debe ser [`None`] si la longitud real del iterador es mayor que [`usize::MAX`].
/// En ese caso, el límite inferior debe ser [`usize::MAX`], lo que da como resultado un [`Iterator::size_hint()`] de `(usize::MAX, None)`.
///
/// El iterador debe producir exactamente el número de elementos que informó o divergir antes de llegar al final.
///
/// # Safety
///
/// Este trait solo debe implementarse cuando se cumple el contrato.
/// Los consumidores de este trait deben inspeccionar el límite superior de [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Un iterador que al ceder un artículo habrá tomado al menos un elemento de su [`SourceIter`] subyacente.
///
/// Llamar a cualquier método que avance el iterador, p. Ej.
/// [`next()`] o [`try_fold()`], garantiza que para cada paso se ha movido al menos un valor de la fuente subyacente del iterador y el resultado de la cadena del iterador podría insertarse en su lugar, asumiendo que las restricciones estructurales de la fuente permiten tal inserción.
///
/// En otras palabras, este trait indica que se puede recopilar una canalización de iteradores en su lugar.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}