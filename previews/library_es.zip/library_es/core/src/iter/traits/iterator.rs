// ignore-tidy-filelength Este archivo consiste casi exclusivamente en la definición de `Iterator`.
// No podemos dividir eso en varios archivos.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Una interfaz para tratar con iteradores.
///
/// Este es el iterador principal trait.
/// Para obtener más información sobre el concepto de iteradores en general, consulte el [module-level documentation].
/// En particular, es posible que desee saber cómo utilizar [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// El tipo de elementos que se repiten.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Avanza el iterador y devuelve el siguiente valor.
    ///
    /// Devuelve [`None`] cuando finaliza la iteración.
    /// Las implementaciones de iteradores individuales pueden optar por reanudar la iteración, por lo que llamar a `next()` nuevamente puede o no comenzar a devolver [`Some(Item)`] nuevamente en algún momento.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Una llamada a next() devuelve el siguiente valor ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... y luego Ninguno una vez que haya terminado.
    /// assert_eq!(None, iter.next());
    ///
    /// // Más llamadas pueden devolver `None` o no.Aquí siempre lo harán.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Devuelve los límites de la longitud restante del iterador.
    ///
    /// Específicamente, `size_hint()` devuelve una tupla donde el primer elemento es el límite inferior y el segundo elemento es el límite superior.
    ///
    /// La segunda mitad de la tupla que se devuelve es una [`Option`]`<`[`usize`] `>`.
    /// Un [`None`] aquí significa que no hay un límite superior conocido o que el límite superior es mayor que [`usize`].
    ///
    /// # Notas de implementación
    ///
    /// No se impone que una implementación de iterador produzca el número declarado de elementos.Un iterador con errores puede producir menos que el límite inferior o más que el límite superior de elementos.
    ///
    /// `size_hint()` está destinado principalmente a ser utilizado para optimizaciones tales como reservar espacio para los elementos del iterador, pero no se debe confiar para, por ejemplo, omitir comprobaciones de límites en código inseguro.
    /// Una implementación incorrecta de `size_hint()` no debería dar lugar a violaciones de seguridad de la memoria.
    ///
    /// Dicho esto, la implementación debería proporcionar una estimación correcta, porque de lo contrario sería una violación del protocolo de trait.
    ///
    /// La implementación predeterminada devuelve `(0,` [`None`]`)`que es correcto para cualquier iterador.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Un ejemplo más complejo:
    ///
    /// ```
    /// // Los números pares del cero al diez.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Podríamos iterar de cero a diez veces.
    /// // Saber que son cinco exactamente no sería posible sin ejecutar filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Agreguemos cinco números más con chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ahora ambos límites se incrementan en cinco
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Devolver `None` para un límite superior:
    ///
    /// ```
    /// // un iterador infinito no tiene límite superior y el límite inferior máximo posible
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Consume el iterador, contando el número de iteraciones y devolviéndolo.
    ///
    /// Este método llamará a [`next`] repetidamente hasta que se encuentre [`None`], devolviendo la cantidad de veces que vio [`Some`].
    /// Tenga en cuenta que [`next`] debe llamarse al menos una vez, incluso si el iterador no tiene ningún elemento.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Comportamiento de desbordamiento
    ///
    /// El método no protege contra desbordamientos, por lo que contar elementos de un iterador con más de [`usize::MAX`] elementos produce el resultado incorrecto o panics.
    ///
    /// Si las aserciones de depuración están habilitadas, se garantiza un panic.
    ///
    /// # Panics
    ///
    /// Esta función podría panic si el iterador tiene más de [`usize::MAX`] elementos.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Consume el iterador, devolviendo el último elemento.
    ///
    /// Este método evaluará el iterador hasta que devuelva [`None`].
    /// Mientras lo hace, realiza un seguimiento del elemento actual.
    /// Después de que se devuelva [`None`], `last()` devolverá el último elemento que vio.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Avanza el iterador por elementos `n`.
    ///
    /// Este método saltará ansiosamente los elementos `n` llamando a [`next`] hasta `n` veces hasta que se encuentre [`None`].
    ///
    /// `advance_by(n)` devolverá [`Ok(())`][Ok] si el iterador avanza con éxito por elementos `n`, o [`Err(k)`][Err] si se encuentra [`None`], donde `k` es el número de elementos por los que avanza el iterador antes de quedarse sin elementos (es decir,
    /// la longitud del iterador).
    /// Tenga en cuenta que `k` siempre es menor que `n`.
    ///
    /// Llamar a `advance_by(0)` no consume ningún elemento y siempre devuelve [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // solo se omitió `&4`
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Devuelve el elemento "n" del iterador.
    ///
    /// Como la mayoría de las operaciones de indexación, el recuento comienza desde cero, por lo que `nth(0)` devuelve el primer valor, `nth(1)` el segundo y así sucesivamente.
    ///
    /// Tenga en cuenta que todos los elementos anteriores, así como el elemento devuelto, se consumirán del iterador.
    /// Eso significa que los elementos anteriores se descartarán y también que llamar a `nth(0)` varias veces en el mismo iterador devolverá elementos diferentes.
    ///
    ///
    /// `nth()` devolverá [`None`] si `n` es mayor o igual que la longitud del iterador.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Llamar a `nth()` varias veces no rebobina el iterador:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Devolver `None` si hay menos de `n + 1` elementos:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Crea un iterador comenzando en el mismo punto, pero avanzando por la cantidad dada en cada iteración.
    ///
    /// Nota 1: El primer elemento del iterador siempre se devolverá, independientemente del paso dado.
    ///
    /// Nota 2: El momento en el que se extraen los elementos ignorados no es fijo.
    /// `StepBy` se comporta como la secuencia `next(), nth(step-1), nth(step-1),…`, pero también es libre de comportarse como la secuencia
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// La forma en que se utiliza puede cambiar para algunos iteradores por motivos de rendimiento.
    /// La segunda forma hará avanzar el iterador antes y puede consumir más elementos.
    ///
    /// `advance_n_and_return_first` es el equivalente de:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// El método será panic si el paso dado es `0`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Toma dos iteradores y crea un nuevo iterador sobre ambos en secuencia.
    ///
    /// `chain()` devolverá un nuevo iterador que primero iterará sobre los valores del primer iterador y luego sobre los valores del segundo iterador.
    ///
    /// En otras palabras, enlaza dos iteradores juntos, en una cadena.🔗
    ///
    /// [`once`] se usa comúnmente para adaptar un valor único en una cadena de otros tipos de iteración.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dado que el argumento de `chain()` usa [`IntoIterator`], podemos pasar cualquier cosa que se pueda convertir en un [`Iterator`], no solo un [`Iterator`] en sí.
    /// Por ejemplo, los cortes (`&[T]`) implementan [`IntoIterator`] y, por lo tanto, se pueden pasar directamente a `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Si trabaja con la API Windows, es posible que desee convertir [`OsStr`] a `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Comprime' dos iteradores en un solo iterador de pares.
    ///
    /// `zip()` devuelve un nuevo iterador que iterará sobre otros dos iteradores, devolviendo una tupla donde el primer elemento proviene del primer iterador y el segundo elemento proviene del segundo iterador.
    ///
    ///
    /// En otras palabras, comprime dos iteradores juntos, en uno solo.
    ///
    /// Si cualquiera de los iteradores devuelve [`None`], [`next`] del iterador comprimido devolverá [`None`].
    /// Si el primer iterador devuelve [`None`], `zip` provocará un cortocircuito y no se llamará a `next` en el segundo iterador.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dado que el argumento de `zip()` usa [`IntoIterator`], podemos pasar cualquier cosa que se pueda convertir en un [`Iterator`], no solo un [`Iterator`] en sí.
    /// Por ejemplo, los cortes (`&[T]`) implementan [`IntoIterator`] y, por lo tanto, se pueden pasar directamente a `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` se utiliza a menudo para comprimir un iterador infinito en uno finito.
    /// Esto funciona porque el iterador finito eventualmente devolverá [`None`], terminando la cremallera.Comprimir con `(0..)` puede parecerse mucho a [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Crea un nuevo iterador que coloca una copia de `separator` entre elementos adyacentes del iterador original.
    ///
    /// En caso de que `separator` no implemente [`Clone`] o necesite ser calculado cada vez, use [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // El primer elemento de `a`.
    /// assert_eq!(a.next(), Some(&100)); // El separador.
    /// assert_eq!(a.next(), Some(&1));   // El siguiente elemento de `a`.
    /// assert_eq!(a.next(), Some(&100)); // El separador.
    /// assert_eq!(a.next(), Some(&2));   // El último elemento de `a`.
    /// assert_eq!(a.next(), None);       // El iterador está terminado.
    /// ```
    ///
    /// `intersperse` puede ser muy útil para unir elementos de un iterador usando un elemento común:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Crea un nuevo iterador que coloca un elemento generado por `separator` entre elementos adyacentes del iterador original.
    ///
    /// El cierre se llamará exactamente una vez cada vez que se coloque un elemento entre dos elementos adyacentes del iterador subyacente;
    /// específicamente, el cierre no se llama si el iterador subyacente produce menos de dos elementos y después de que se produce el último elemento.
    ///
    ///
    /// Si el elemento del iterador implementa [`Clone`], puede ser más fácil usar [`intersperse`].
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // El primer elemento de `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // El separador.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // El siguiente elemento de `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // El separador.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // El último elemento de `v`.
    /// assert_eq!(it.next(), None);               // El iterador está terminado.
    /// ```
    ///
    /// `intersperse_with` se puede utilizar en situaciones en las que es necesario calcular el separador:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // El cierre toma prestado de manera mutante su contexto para generar un artículo.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Toma un cierre y crea un iterador que llama a ese cierre en cada elemento.
    ///
    /// `map()` transforma un iterador en otro, mediante su argumento:
    /// algo que implementa [`FnMut`].Produce un nuevo iterador que llama a este cierre en cada elemento del iterador original.
    ///
    /// Si eres bueno pensando en tipos, puedes pensar en `map()` así:
    /// Si tiene un iterador que le da elementos de algún tipo `A`, y quiere un iterador de algún otro tipo `B`, puede usar `map()`, pasando un cierre que toma un `A` y devuelve un `B`.
    ///
    ///
    /// `map()` es conceptualmente similar a un bucle [`for`].Sin embargo, como `map()` es perezoso, es mejor usarlo cuando ya está trabajando con otros iteradores.
    /// Si está haciendo algún tipo de bucle para un efecto secundario, se considera más idiomático usar [`for`] que `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Si está produciendo algún tipo de efecto secundario, prefiera [`for`] a `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // no hagas esto:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ni siquiera se ejecutará, ya que es perezoso.Rust le advertirá sobre esto.
    ///
    /// // En su lugar, utilice para:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Llama a un cierre en cada elemento de un iterador.
    ///
    /// Esto es equivalente a usar un bucle [`for`] en el iterador, aunque `break` y `continue` no son posibles desde un cierre.
    /// En general, es más idiomático usar un bucle `for`, pero `for_each` puede ser más legible al procesar elementos al final de cadenas de iteradores más largas.
    ///
    /// En algunos casos, `for_each` también puede ser más rápido que un bucle, porque utilizará iteración interna en adaptadores como `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Para un ejemplo tan pequeño, un bucle `for` puede ser más limpio, pero `for_each` podría ser preferible para mantener un estilo funcional con iteradores más largos:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Crea un iterador que usa un cierre para determinar si se debe ceder un elemento.
    ///
    /// Dado un elemento, el cierre debe devolver `true` o `false`.El iterador devuelto producirá solo los elementos para los que el cierre devuelve verdadero.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Debido a que el cierre pasado a `filter()` toma una referencia y muchos iteradores iteran sobre las referencias, esto conduce a una situación posiblemente confusa, donde el tipo de cierre es una referencia doble:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // ¡Necesito dos * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// En cambio, es común usar la desestructuración en el argumento para eliminar uno:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ambos y *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// o ambos:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dos &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// de estas capas.
    ///
    /// Tenga en cuenta que `iter.filter(f).next()` es equivalente a `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Crea un iterador que filtra y mapea.
    ///
    /// El iterador devuelto arroja solo el `valor` para el que el cierre proporcionado devuelve `Some(value)`.
    ///
    /// `filter_map` se puede utilizar para hacer más concisas las cadenas de [`filter`] y [`map`].
    /// El siguiente ejemplo muestra cómo un `map().filter().map()` se puede reducir a una sola llamada a `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Este es el mismo ejemplo, pero con [`filter`] y [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Crea un iterador que proporciona el recuento de iteraciones actual así como el siguiente valor.
    ///
    /// El iterador devuelto produce pares `(i, val)`, donde `i` es el índice actual de iteración y `val` es el valor devuelto por el iterador.
    ///
    ///
    /// `enumerate()` mantiene su cuenta como [`usize`].
    /// Si desea contar por un número entero de diferente tamaño, la función [`zip`] proporciona una funcionalidad similar.
    ///
    /// # Comportamiento de desbordamiento
    ///
    /// El método no protege contra desbordamientos, por lo que enumerar más de [`usize::MAX`] elementos produce un resultado incorrecto o panics.
    /// Si las aserciones de depuración están habilitadas, se garantiza un panic.
    ///
    /// # Panics
    ///
    /// El iterador devuelto podría panic si el índice a devolver desbordara un [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Crea un iterador que puede usar [`peek`] para mirar el siguiente elemento del iterador sin consumirlo.
    ///
    /// Agrega un método [`peek`] a un iterador.Consulte su documentación para obtener más información.
    ///
    /// Tenga en cuenta que el iterador subyacente todavía está avanzado cuando se llama a [`peek`] por primera vez: para recuperar el siguiente elemento, se llama a [`next`] en el iterador subyacente, por lo tanto, cualquier efecto secundario (es decir,
    ///
    /// ocurrirá cualquier otra cosa que no sea obtener el siguiente valor) del método [`next`].
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() déjanos ver el future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // podemos peek() varias veces, el iterador no avanzará
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // una vez finalizado el iterador, también lo es peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Crea un iterador que [`omite`] elementos basados en un predicado.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` toma un cierre como argumento.Llamará a este cierre en cada elemento del iterador e ignorará los elementos hasta que devuelva `false`.
    ///
    /// Una vez que se devuelve `false`, el trabajo `skip_while()`'s finaliza y se obtienen el resto de los elementos.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Debido a que el cierre pasado a `skip_while()` toma una referencia y muchos iteradores iteran sobre las referencias, esto conduce a una situación posiblemente confusa, donde el tipo de argumento de cierre es una referencia doble:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // ¡Necesito dos * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Deteniéndose después de un `false` inicial:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // si bien esto hubiera sido falso, ya que ya obtuvimos un falso, skip_while() ya no se usa
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Crea un iterador que produce elementos basados en un predicado.
    ///
    /// `take_while()` toma un cierre como argumento.Llamará a este cierre en cada elemento del iterador y generará elementos mientras devuelve `true`.
    ///
    /// Una vez que se devuelve `false`, el trabajo `take_while()`'s finaliza y el resto de los elementos se ignoran.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Debido a que el cierre pasado a `take_while()` toma una referencia y muchos iteradores iteran sobre las referencias, esto conduce a una situación posiblemente confusa, donde el tipo de cierre es una referencia doble:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // ¡Necesito dos * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Deteniéndose después de un `false` inicial:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Tenemos más elementos que son menores que cero, pero como ya obtuvimos un falso, take_while() ya no se usa
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Debido a que `take_while()` necesita mirar el valor para ver si debe incluirse o no, los iteradores consumidores verán que se elimina:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// El `3` ya no está allí, porque se consumió para ver si la iteración debería detenerse, pero no se volvió a colocar en el iterador.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Crea un iterador que produce elementos basados en un predicado y mapas.
    ///
    /// `map_while()` toma un cierre como argumento.
    /// Llamará a este cierre en cada elemento del iterador y generará elementos mientras devuelve [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Este es el mismo ejemplo, pero con [`take_while`] y [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Deteniéndose después de un [`None`] inicial:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Tenemos más elementos que podrían caber en u32 (4, 5), pero `map_while` devolvió `None` para `-3` (ya que `predicate` devolvió `None`) y `collect` se detiene en el primer `None` encontrado.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Debido a que `map_while()` necesita mirar el valor para ver si debe incluirse o no, los iteradores consumidores verán que se elimina:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// El `-3` ya no está allí, porque se consumió para ver si la iteración debería detenerse, pero no se volvió a colocar en el iterador.
    ///
    /// Tenga en cuenta que, a diferencia de [`take_while`], este iterador **no** está fusionado.
    /// Tampoco se especifica qué devuelve este iterador después de que se devuelve el primer [`None`].
    /// Si necesita un iterador fusionado, use [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Crea un iterador que omite los primeros elementos `n`.
    ///
    /// Una vez consumidos, se ceden el resto de elementos.
    /// En lugar de anular este método directamente, anule el método `nth`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Crea un iterador que produce sus primeros elementos `n`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` se usa a menudo con un iterador infinito, para hacerlo finito:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Si hay menos de `n` elementos disponibles, `take` se limitará al tamaño del iterador subyacente:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Un adaptador de iterador similar a [`fold`] que mantiene el estado interno y produce un nuevo iterador.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` toma dos argumentos: un valor inicial que siembra el estado interno y un cierre con dos argumentos, el primero es una referencia mutable al estado interno y el segundo es un elemento iterador.
    ///
    /// El cierre se puede asignar al estado interno para compartir el estado entre iteraciones.
    ///
    /// En la iteración, el cierre se aplicará a cada elemento del iterador y el valor de retorno del cierre, un [`Option`], lo proporciona el iterador.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // en cada iteración, multiplicaremos el estado por el elemento
    ///     *state = *state * x;
    ///
    ///     // entonces, cederemos la negación del estado
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Crea un iterador que funciona como mapa, pero aplana la estructura anidada.
    ///
    /// El adaptador [`map`] es muy útil, pero solo cuando el argumento de cierre produce valores.
    /// Si en su lugar produce un iterador, hay una capa adicional de indirección.
    /// `flat_map()` eliminará esta capa adicional por sí sola.
    ///
    /// Puede pensar en `flat_map(f)` como el equivalente semántico de [`map`] ping, y luego [`flatten`] ing como en `map(f).flatten()`.
    ///
    /// Otra forma de pensar sobre `flat_map()`: el cierre de [`map`] devuelve un elemento para cada elemento, y el cierre de `flat_map()`'s devuelve un iterador para cada elemento.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() devuelve un iterador
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Crea un iterador que aplana la estructura anidada.
    ///
    /// Esto es útil cuando tiene un iterador de iteradores o un iterador de cosas que se pueden convertir en iteradores y desea eliminar un nivel de indirección.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mapeo y luego aplanamiento:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() devuelve un iterador
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// También puede reescribir esto en términos de [`flat_map()`], que es preferible en este caso ya que transmite la intención con mayor claridad:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() devuelve un iterador
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// El aplanamiento solo elimina un nivel de anidamiento a la vez:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Aquí vemos que `flatten()` no realiza un aplanado "deep".
    /// En cambio, solo se elimina un nivel de anidamiento.Es decir, si utiliza `flatten()` una matriz tridimensional, el resultado será bidimensional y no unidimensional.
    /// Para obtener una estructura unidimensional, debe volver a `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Crea un iterador que termina después del primer [`None`].
    ///
    /// Después de que un iterador devuelve [`None`], las llamadas future pueden o no producir [`Some(T)`] nuevamente.
    /// `fuse()` adapta un iterador, asegurándose de que después de proporcionar un [`None`], siempre devolverá [`None`] para siempre.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // un iterador que alterna entre Some y None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // si es par, Some(i32), de lo contrario Ninguno
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // podemos ver nuestro iterador yendo y viniendo
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // sin embargo, una vez que lo fusionamos ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // siempre devolverá `None` después de la primera vez.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Hace algo con cada elemento de un iterador, pasando el valor.
    ///
    /// Cuando utilice iteradores, a menudo encadenará varios de ellos.
    /// Mientras trabaja en dicho código, es posible que desee verificar lo que está sucediendo en varias partes del proceso.Para hacer eso, inserte una llamada a `inspect()`.
    ///
    /// Es más común que `inspect()` se use como una herramienta de depuración que que exista en su código final, pero las aplicaciones pueden encontrarlo útil en ciertas situaciones cuando los errores deben registrarse antes de descartarse.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // esta secuencia de iteradores es compleja.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // agreguemos algunas llamadas inspect() para investigar lo que está sucediendo
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Esto imprimirá:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Registrar errores antes de descartarlos:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Esto imprimirá:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Toma prestado un iterador, en lugar de consumirlo.
    ///
    /// Esto es útil para permitir la aplicación de adaptadores de iterador sin dejar de conservar la propiedad del iterador original.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // si intentamos usar iter nuevamente, no funcionará.
    /// // La siguiente línea da "error: uso de valor movido: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // intentemos eso de nuevo
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // en su lugar, agregamos un .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ahora esto está bien:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Transforma un iterador en una colección.
    ///
    /// `collect()` puede tomar cualquier elemento iterable y convertirlo en una colección relevante.
    /// Este es uno de los métodos más poderosos de la biblioteca estándar, que se utiliza en una variedad de contextos.
    ///
    /// El patrón más básico en el que se usa `collect()` es convertir una colección en otra.
    /// Tomas una colección, llamas a [`iter`] en ella, haces un montón de transformaciones y luego `collect()` al final.
    ///
    /// `collect()` también puede crear instancias de tipos que no son colecciones típicas.
    /// Por ejemplo, se puede construir un [`String`] a partir de [`char`] s, y un iterador de elementos [`Result<T, E>`][`Result`] se puede recopilar en `Result<Collection<T>, E>`.
    ///
    /// Consulte los ejemplos a continuación para obtener más información.
    ///
    /// Debido a que `collect()` es tan general, puede causar problemas con la inferencia de tipos.
    /// Como tal, `collect()` es una de las pocas veces que verá la sintaxis cariñosamente conocida como 'turbofish': `::<>`.
    /// Esto ayuda al algoritmo de inferencia a comprender específicamente en qué colección está tratando de recopilar.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Tenga en cuenta que necesitábamos el `: Vec<i32>` en el lado izquierdo.Esto se debe a que podríamos recopilar, por ejemplo, en un [`VecDeque<T>`] en su lugar:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Usando el 'turbofish' en lugar de anotar `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Debido a que `collect()` solo se preocupa por lo que está recolectando, aún puede usar una sugerencia de tipo parcial, `_`, con el turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Usando `collect()` para hacer un [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Si tiene una lista de [`Resultado<T, E>`][`Result`] s, puede usar `collect()` para ver si alguno de ellos falló:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // nos da el primer error
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // nos da la lista de respuestas
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Consume un iterador, creando dos colecciones a partir de él.
    ///
    /// El predicado pasado a `partition()` puede devolver `true` o `false`.
    /// `partition()` devuelve un par, todos los elementos para los que devolvió `true` y todos los elementos para los que devolvió `false`.
    ///
    ///
    /// Consulte también [`is_partitioned()`] y [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reordena los elementos de este iterador *in situ* de acuerdo con el predicado dado, de modo que todos los que devuelven `true` preceden a todos los que devuelven `false`.
    ///
    /// Devuelve el número de elementos `true` encontrados.
    ///
    /// No se mantiene el orden relativo de los elementos divididos.
    ///
    /// Consulte también [`is_partitioned()`] y [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partición en el lugar entre pares y probabilidades
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ¿Deberíamos preocuparnos por el recuento desbordado?La única forma de tener más de
        // `usize::MAX` las referencias mutables son con ZST, que no son útiles para particionar ...

        // Estas funciones de cierre "factory" existen para evitar la genéricoidad en `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Busque repetidamente el primer `false` y cámbielo por el último `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Comprueba si los elementos de este iterador están particionados según el predicado dado, de modo que todos los que devuelvan `true` precedan a todos los que devuelvan `false`.
    ///
    ///
    /// Consulte también [`partition()`] y [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // O todos los elementos prueban `true`, o la primera cláusula se detiene en `false` y verificamos que no haya más elementos `true` después de eso.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Un método de iterador que aplica una función siempre que regrese correctamente, produciendo un único valor final.
    ///
    /// `try_fold()` toma dos argumentos: un valor inicial y un cierre con dos argumentos: un 'accumulator' y un elemento.
    /// El cierre regresa exitosamente, con el valor que el acumulador debería tener para la próxima iteración, o regresa falla, con un valor de error que se propaga de regreso al llamador inmediatamente (short-circuiting).
    ///
    ///
    /// El valor inicial es el valor que tendrá el acumulador en la primera llamada.Si la aplicación del cierre tuvo éxito contra todos los elementos del iterador, `try_fold()` devuelve el acumulador final como exitoso.
    ///
    /// El plegado es útil siempre que tenga una colección de algo y desee producir un valor único a partir de ella.
    ///
    /// # Nota para los implementadores
    ///
    /// Varios de los otros métodos (forward) tienen implementaciones predeterminadas en términos de este, así que intente implementar esto explícitamente si puede hacer algo mejor que la implementación predeterminada del bucle `for`.
    ///
    /// En particular, intente tener esta llamada `try_fold()` en las partes internas de las que se compone este iterador.
    /// Si se necesitan múltiples llamadas, el operador `?` puede ser conveniente para encadenar el valor del acumulador, pero tenga cuidado con cualquier invariante que deba mantenerse antes de esas devoluciones anticipadas.
    /// Este es un método `&mut self`, por lo que la iteración debe poder reanudarse después de encontrar un error aquí.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // la suma comprobada de todos los elementos de la matriz
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Esta suma se desborda al agregar el elemento 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Debido a que se cortocircuitó, los elementos restantes todavía están disponibles a través del iterador.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Un método de iterador que aplica una función falible a cada elemento del iterador, deteniéndose en el primer error y devolviendo ese error.
    ///
    ///
    /// Esto también se puede considerar como la forma falible de [`for_each()`] o como la versión sin estado de [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Se cortocircuitó, por lo que los elementos restantes todavía están en el iterador:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Dobla cada elemento en un acumulador aplicando una operación, devolviendo el resultado final.
    ///
    /// `fold()` toma dos argumentos: un valor inicial y un cierre con dos argumentos: un 'accumulator' y un elemento.
    /// El cierre devuelve el valor que debería tener el acumulador para la siguiente iteración.
    ///
    /// El valor inicial es el valor que tendrá el acumulador en la primera llamada.
    ///
    /// Después de aplicar este cierre a cada elemento del iterador, `fold()` devuelve el acumulador.
    ///
    /// Esta operación a veces se denomina 'reduce' o 'inject'.
    ///
    /// El plegado es útil siempre que tenga una colección de algo y desee producir un valor único a partir de ella.
    ///
    /// Note: `fold()`, y métodos similares que atraviesan todo el iterador, pueden no terminar para iteradores infinitos, incluso en traits para los cuales un resultado es determinable en tiempo finito.
    ///
    /// Note: [`reduce()`] se puede usar para usar el primer elemento como valor inicial, si el tipo de acumulador y el tipo de artículo es el mismo.
    ///
    /// # Nota para los implementadores
    ///
    /// Varios de los otros métodos (forward) tienen implementaciones predeterminadas en términos de este, así que intente implementar esto explícitamente si puede hacer algo mejor que la implementación predeterminada del bucle `for`.
    ///
    ///
    /// En particular, intente tener esta llamada `fold()` en las partes internas de las que se compone este iterador.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // la suma de todos los elementos de la matriz
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Repasemos cada paso de la iteración aquí:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Y así, nuestro resultado final, `6`.
    ///
    /// Es común que las personas que no han usado muchos iteradores usen un bucle `for` con una lista de cosas para generar un resultado.Esos se pueden convertir en `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // en bucle:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // son iguales
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Reduce los elementos a uno solo, aplicando repetidamente una operación de reducción.
    ///
    /// Si el iterador está vacío, devuelve [`None`];de lo contrario, devuelve el resultado de la reducción.
    ///
    /// Para iteradores con al menos un elemento, esto es lo mismo que [`fold()`] con el primer elemento del iterador como valor inicial, incorporando todos los elementos subsiguientes.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Encuentra el valor máximo:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Comprueba si cada elemento del iterador coincide con un predicado.
    ///
    /// `all()` toma un cierre que devuelve `true` o `false`.Aplica este cierre a cada elemento del iterador, y si todos devuelven `true`, también lo hace `all()`.
    /// Si alguno de ellos devuelve `false`, devuelve `false`.
    ///
    /// `all()` está en cortocircuito;es decir, dejará de procesar tan pronto como encuentre un `false`, dado que pase lo que pase, el resultado también será `false`.
    ///
    ///
    /// Un iterador vacío devuelve `true`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Parando en el primer `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // todavía podemos usar `iter`, ya que hay más elementos.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Comprueba si algún elemento del iterador coincide con un predicado.
    ///
    /// `any()` toma un cierre que devuelve `true` o `false`.Aplica este cierre a cada elemento del iterador, y si alguno de ellos devuelve `true`, entonces también lo hace `any()`.
    /// Si todos devuelven `false`, devuelve `false`.
    ///
    /// `any()` está en cortocircuito;es decir, dejará de procesar tan pronto como encuentre un `true`, dado que pase lo que pase, el resultado también será `true`.
    ///
    ///
    /// Un iterador vacío devuelve `false`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Parando en el primer `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // todavía podemos usar `iter`, ya que hay más elementos.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Busca un elemento de un iterador que satisfaga un predicado.
    ///
    /// `find()` toma un cierre que devuelve `true` o `false`.
    /// Aplica este cierre a cada elemento del iterador, y si alguno de ellos devuelve `true`, entonces `find()` devuelve [`Some(element)`].
    /// Si todos devuelven `false`, devuelve [`None`].
    ///
    /// `find()` está en cortocircuito;en otras palabras, dejará de procesarse tan pronto como el cierre devuelva `true`.
    ///
    /// Debido a que `find()` toma una referencia y muchos iteradores iteran sobre las referencias, esto conduce a una situación posiblemente confusa en la que el argumento es una referencia doble.
    ///
    /// Puede ver este efecto en los ejemplos siguientes, con `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Parando en el primer `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // todavía podemos usar `iter`, ya que hay más elementos.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Tenga en cuenta que `iter.find(f)` es equivalente a `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Aplica la función a los elementos del iterador y devuelve el primer resultado que no es ninguno.
    ///
    ///
    /// `iter.find_map(f)` es equivalente a `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Aplica la función a los elementos del iterador y devuelve el primer resultado verdadero o el primer error.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Busca un elemento en un iterador y devuelve su índice.
    ///
    /// `position()` toma un cierre que devuelve `true` o `false`.
    /// Aplica este cierre a cada elemento del iterador, y si uno de ellos devuelve `true`, entonces `position()` devuelve [`Some(index)`].
    /// Si todos devuelven `false`, devuelve [`None`].
    ///
    /// `position()` está en cortocircuito;en otras palabras, dejará de procesar tan pronto como encuentre un `true`.
    ///
    /// # Comportamiento de desbordamiento
    ///
    /// El método no protege contra desbordamientos, por lo que si hay más de [`usize::MAX`] elementos que no coinciden, produce el resultado incorrecto o panics.
    ///
    /// Si las aserciones de depuración están habilitadas, se garantiza un panic.
    ///
    /// # Panics
    ///
    /// Esta función podría panic si el iterador tiene más de `usize::MAX` elementos no coincidentes.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Parando en el primer `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // todavía podemos usar `iter`, ya que hay más elementos.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // El índice devuelto depende del estado del iterador
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Busca un elemento en un iterador desde la derecha y devuelve su índice.
    ///
    /// `rposition()` toma un cierre que devuelve `true` o `false`.
    /// Aplica este cierre a cada elemento del iterador, comenzando desde el final, y si uno de ellos devuelve `true`, entonces `rposition()` devuelve [`Some(index)`].
    ///
    /// Si todos devuelven `false`, devuelve [`None`].
    ///
    /// `rposition()` está en cortocircuito;en otras palabras, dejará de procesar tan pronto como encuentre un `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Parando en el primer `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // todavía podemos usar `iter`, ya que hay más elementos.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // No es necesario realizar una verificación de desbordamiento aquí, porque `ExactSizeIterator` implica que el número de elementos encaja en un `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Devuelve el elemento máximo de un iterador.
    ///
    /// Si varios elementos son igualmente máximos, se devuelve el último elemento.
    /// Si el iterador está vacío, se devuelve [`None`].
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Devuelve el elemento mínimo de un iterador.
    ///
    /// Si varios elementos son igualmente mínimos, se devuelve el primer elemento.
    /// Si el iterador está vacío, se devuelve [`None`].
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Devuelve el elemento que da el valor máximo de la función especificada.
    ///
    ///
    /// Si varios elementos son igualmente máximos, se devuelve el último elemento.
    /// Si el iterador está vacío, se devuelve [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Devuelve el elemento que da el valor máximo con respecto a la función de comparación especificada.
    ///
    ///
    /// Si varios elementos son igualmente máximos, se devuelve el último elemento.
    /// Si el iterador está vacío, se devuelve [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Devuelve el elemento que da el valor mínimo de la función especificada.
    ///
    ///
    /// Si varios elementos son igualmente mínimos, se devuelve el primer elemento.
    /// Si el iterador está vacío, se devuelve [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Devuelve el elemento que da el valor mínimo con respecto a la función de comparación especificada.
    ///
    ///
    /// Si varios elementos son igualmente mínimos, se devuelve el primer elemento.
    /// Si el iterador está vacío, se devuelve [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Invierte la dirección de un iterador.
    ///
    /// Por lo general, los iteradores iteran de izquierda a derecha.
    /// Después de usar `rev()`, un iterador iterará de derecha a izquierda.
    ///
    /// Esto solo es posible si el iterador tiene un final, por lo que `rev()` solo funciona en [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Convierte un iterador de pares en un par de contenedores.
    ///
    /// `unzip()` consume un iterador completo de pares, produciendo dos colecciones: una de los elementos de la izquierda de los pares y otra de los elementos de la derecha.
    ///
    ///
    /// Esta función es, en cierto sentido, la opuesta a [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Crea un iterador que copia todos sus elementos.
    ///
    /// Esto es útil cuando tiene un iterador sobre `&T`, pero necesita un iterador sobre `T`.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // copiado es el mismo que .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Crea un iterador que [`clone`] s todos sus elementos.
    ///
    /// Esto es útil cuando tiene un iterador sobre `&T`, pero necesita un iterador sobre `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // clonado es lo mismo que .map(|&x| x), para enteros
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Repite un iterador sin cesar.
    ///
    /// En lugar de detenerse en [`None`], el iterador comenzará de nuevo, desde el principio.Después de iterar nuevamente, comenzará nuevamente desde el principio.Y otra vez.
    /// Y otra vez.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Suma los elementos de un iterador.
    ///
    /// Toma cada elemento, los suma y devuelve el resultado.
    ///
    /// Un iterador vacío devuelve el valor cero del tipo.
    ///
    /// # Panics
    ///
    /// Cuando se llama a `sum()` y se devuelve un tipo de entero primitivo, este método se panic si el cálculo se desborda y las aserciones de depuración están habilitadas.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Itera sobre todo el iterador, multiplicando todos los elementos.
    ///
    /// Un iterador vacío devuelve el único valor del tipo.
    ///
    /// # Panics
    ///
    /// Cuando se llama a `product()` y se devuelve un tipo de entero primitivo, el método se panic si el cálculo se desborda y las aserciones de depuración están habilitadas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compara los elementos de este [`Iterator`] con los de otro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compara los elementos de este [`Iterator`] con los de otro con respecto a la función de comparación especificada.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compara los elementos de este [`Iterator`] con los de otro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compara los elementos de este [`Iterator`] con los de otro con respecto a la función de comparación especificada.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Determina si los elementos de este [`Iterator`] son iguales a los de otro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Determina si los elementos de este [`Iterator`] son iguales a los de otro con respecto a la función de igualdad especificada.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Determina si los elementos de este [`Iterator`] son diferentes a los de otro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Determina si los elementos de este [`Iterator`] son [lexicographically](Ord#lexicographical-comparison) menores que los de otro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Determina si los elementos de este [`Iterator`] son [lexicographically](Ord#lexicographical-comparison) menores o iguales a los de otro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Determina si los elementos de este [`Iterator`] son [lexicographically](Ord#lexicographical-comparison) mayores que los de otro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Determina si los elementos de este [`Iterator`] son [lexicographically](Ord#lexicographical-comparison) mayores o iguales a los de otro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Comprueba si los elementos de este iterador están ordenados.
    ///
    /// Es decir, para cada elemento `a` y su siguiente elemento `b`, debe mantenerse `a <= b`.Si el iterador produce exactamente cero o un elemento, se devuelve `true`.
    ///
    /// Tenga en cuenta que si `Self::Item` es solo `PartialOrd`, pero no `Ord`, la definición anterior implica que esta función devuelve `false` si dos elementos consecutivos no son comparables.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Comprueba si los elementos de este iterador se ordenan utilizando la función de comparación dada.
    ///
    /// En lugar de usar `PartialOrd::partial_cmp`, esta función usa la función `compare` dada para determinar el orden de dos elementos.
    /// Aparte de eso, es equivalente a [`is_sorted`];consulte su documentación para obtener más información.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Comprueba si los elementos de este iterador se ordenan utilizando la función de extracción de clave dada.
    ///
    /// En lugar de comparar los elementos del iterador directamente, esta función compara las claves de los elementos, según lo determinado por `f`.
    /// Aparte de eso, es equivalente a [`is_sorted`];consulte su documentación para obtener más información.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Ver [TrustedRandomAccess]
    // El nombre inusual es para evitar colisiones de nombres en la resolución de métodos, consulte #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}