/// Un iterador que conoce su longitud exacta.
///
/// Muchos [`Iteradores`] no saben cuántas veces iterarán, pero algunos sí.
/// Si un iterador sabe cuántas veces puede iterar, proporcionar acceso a esa información puede resultar útil.
/// Por ejemplo, si desea iterar hacia atrás, un buen comienzo es saber dónde está el final.
///
/// Al implementar un `ExactSizeIterator`, también debe implementar [`Iterator`].
/// Al hacerlo, la implementación de [`Iterator::size_hint`]*debe* devolver el tamaño exacto del iterador.
///
/// El método [`len`] tiene una implementación predeterminada, por lo que normalmente no debería implementarlo.
/// Sin embargo, es posible que pueda proporcionar una implementación más eficaz que la predeterminada, por lo que tiene sentido anularla en este caso.
///
///
/// Tenga en cuenta que este trait es un trait seguro y, como tal,*no* y *no puede* garantizar que la longitud devuelta sea correcta.
/// Esto significa que el código `unsafe`**no debe** depender de la exactitud de [`Iterator::size_hint`].
/// El inestable e inseguro [`TrustedLen`](super::marker::TrustedLen) trait brinda esta garantía adicional.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// // un rango finito sabe exactamente cuántas veces se repetirá
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// En el [module-level docs], implementamos un [`Iterator`], `Counter`.
/// Implementemos `ExactSizeIterator` para él también:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Podemos calcular fácilmente el número restante de iteraciones.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // ¡Y ahora podemos usarlo!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Devuelve la longitud exacta del iterador.
    ///
    /// La implementación asegura que el iterador devolverá exactamente `len()` más veces un valor [`Some(T)`], antes de devolver [`None`].
    ///
    /// Este método tiene una implementación predeterminada, por lo que normalmente no debería implementarlo directamente.
    /// Sin embargo, si puede proporcionar una implementación más eficiente, puede hacerlo.
    /// Consulte la documentación de [trait-level] para ver un ejemplo.
    ///
    /// Esta función tiene las mismas garantías de seguridad que la función [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // un rango finito sabe exactamente cuántas veces se repetirá
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Esta afirmación es demasiado defensiva, pero comprueba la invariante
        // garantizado por el trait.
        // Si este trait fuera rust interno, podríamos usar debug_assert !;asert_eq!también comprobará todas las implementaciones de usuario de Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Devuelve `true` si el iterador está vacío.
    ///
    /// Este método tiene una implementación predeterminada con [`ExactSizeIterator::len()`], por lo que no es necesario que lo implemente usted mismo.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}