use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Este trait proporciona acceso transitivo a la etapa de origen en una tubería interador-adaptador en las condiciones que
/// * la fuente del iterador `S` en sí misma implementa `SourceIter<Source = S>`
/// * hay una implementación de delegación de este trait para cada adaptador en la tubería entre la fuente y el consumidor de la tubería.
///
/// Cuando la fuente es una estructura de iterador propietaria (comúnmente llamada `IntoIter`), esto puede ser útil para especializar las implementaciones de [`FromIterator`] o recuperar los elementos restantes después de que un iterador se haya agotado parcialmente.
///
///
/// Tenga en cuenta que las implementaciones no necesariamente tienen que proporcionar acceso a la fuente más interna de una canalización.Un adaptador intermedio con estado podría evaluar con entusiasmo una parte de la canalización y exponer su almacenamiento interno como fuente.
///
/// El trait no es seguro porque los implementadores deben mantener propiedades de seguridad adicionales.
/// Consulte [`as_inner`] para obtener más detalles.
///
/// # Examples
///
/// Recuperar una fuente consumida parcialmente:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Una etapa de origen en una canalización de iteradores.
    type Source: Iterator;

    /// Recupera el origen de una canalización de iteradores.
    ///
    /// # Safety
    ///
    /// Las implementaciones de deben devolver la misma referencia mutable durante toda su vida, a menos que sean reemplazadas por un llamador.
    /// Las personas que llaman solo pueden reemplazar la referencia cuando detuvieron la iteración y eliminar la canalización del iterador después de extraer la fuente.
    ///
    /// Esto significa que los adaptadores de iteradores pueden confiar en que la fuente no cambia durante la iteración, pero no pueden confiar en ella en sus implementaciones de Drop.
    ///
    /// La implementación de este método significa que los adaptadores renuncian al acceso solo privado a su fuente y solo pueden confiar en las garantías hechas en función de los tipos de receptores de métodos.
    /// La falta de acceso restringido también requiere que los adaptadores mantengan la API pública de la fuente incluso cuando tengan acceso a sus componentes internos.
    ///
    /// Las personas que llaman, a su vez, deben esperar que la fuente esté en cualquier estado que sea coherente con su API pública, ya que los adaptadores que se encuentran entre ella y la fuente tienen el mismo acceso.
    /// En particular, un adaptador puede haber consumido más elementos de los estrictamente necesarios.
    ///
    /// El objetivo general de estos requisitos es permitir que el consumidor de una tubería utilice
    /// * lo que quede en la fuente después de que la iteración se haya detenido
    /// * la memoria que no se ha utilizado al avanzar un iterador consumidor
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Un adaptador de iterador que produce salida siempre que el iterador subyacente produzca valores `Result::Ok`.
///
///
/// Si se encuentra un error, el iterador se detiene y se almacena el error.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Procese el iterador dado como si arrojara un `T` en lugar de un `Result<T, _>`.
/// Cualquier error detendrá el iterador interno y el resultado general será un error.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}