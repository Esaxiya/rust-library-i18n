//! Iteración externa componible.
//!
//! Si se ha encontrado con una colección de algún tipo y necesita realizar una operación en los elementos de dicha colección, rápidamente se encontrará con 'iterators'.
//! Los iteradores se utilizan mucho en el código idiomático Rust, por lo que vale la pena familiarizarse con ellos.
//!
//! Antes de explicar más, hablemos de cómo está estructurado este módulo:
//!
//! # Organization
//!
//! Este módulo está organizado en gran parte por tipo:
//!
//! * [Traits] son la parte central: estos traits definen qué tipo de iteradores existen y qué puede hacer con ellos.Vale la pena dedicar un tiempo de estudio adicional a los métodos de estos traits.
//! * [Functions] proporcionan algunas formas útiles de crear algunos iteradores básicos.
//! * [Structs] son a menudo los tipos de retorno de los diversos métodos en traits de este módulo.Por lo general, querrá ver el método que crea el `struct`, en lugar del `struct` en sí.
//! Para obtener más detalles sobre el motivo, consulte '[Implementación de iterador](#deployment-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! ¡Eso es!Profundicemos en los iteradores.
//!
//! # Iterator
//!
//! El corazón y el alma de este módulo es el [`Iterator`] trait.El núcleo de [`Iterator`] se ve así:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Un iterador tiene un método, [`next`], que cuando se llama, devuelve una [`Option`]`<Item>".
//! [`next`] devolverá [`Some(Item)`] siempre que haya elementos, y una vez que se hayan agotado, devolverá `None` para indicar que la iteración ha finalizado.
//! Los iteradores individuales pueden optar por reanudar la iteración, por lo que llamar a [`next`] nuevamente puede o no comenzar a devolver [`Some(Item)`] nuevamente en algún momento (por ejemplo, ver [`TryIter`]).
//!
//!
//! La definición completa de [`Iterator`] incluye varios otros métodos también, pero son métodos predeterminados, construidos sobre [`next`], por lo que los obtienes gratis.
//!
//! Los iteradores también se pueden componer y es común encadenarlos para realizar formas de procesamiento más complejas.Consulte la sección [Adapters](#adapters) a continuación para obtener más detalles.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Las tres formas de iteración
//!
//! Hay tres métodos comunes que pueden crear iteradores a partir de una colección:
//!
//! * `iter()`, que itera sobre `&T`.
//! * `iter_mut()`, que itera sobre `&mut T`.
//! * `into_iter()`, que itera sobre `T`.
//!
//! Varias cosas en la biblioteca estándar pueden implementar una o más de las tres, cuando sea apropiado.
//!
//! # Implementación de iterador
//!
//! Crear un iterador propio implica dos pasos: crear un `struct` para mantener el estado del iterador y luego implementar [`Iterator`] para ese `struct`.
//! Esta es la razón por la que hay tantas estructuras en este módulo: hay una para cada iterador y adaptador de iterador.
//!
//! Hagamos un iterador llamado `Counter` que cuente desde `1` hasta `5`:
//!
//! ```
//! // Primero, la estructura:
//!
//! /// Un iterador que cuenta de uno a cinco
//! struct Counter {
//!     count: usize,
//! }
//!
//! // queremos que nuestro recuento comience en uno, así que agreguemos un método new() para ayudar.
//! // Esto no es estrictamente necesario, pero es conveniente.
//! // Tenga en cuenta que comenzamos `count` en cero, veremos por qué en la implementación de `next()`'s a continuación.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Luego, implementamos `Iterator` para nuestro `Counter`:
//!
//! impl Iterator for Counter {
//!     // contaremos con usize
//!     type Item = usize;
//!
//!     // next() es el único método requerido
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Incrementa nuestro recuento.Por eso empezamos de cero.
//!         self.count += 1;
//!
//!         // Compruebe si hemos terminado de contar o no.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // ¡Y ahora podemos usarlo!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Llamar a [`next`] de esta manera se vuelve repetitivo.Rust tiene una construcción que puede llamar a [`next`] en su iterador, hasta que llega a `None`.Repasemos eso a continuación.
//!
//! También tenga en cuenta que `Iterator` proporciona una implementación predeterminada de métodos como `nth` y `fold` que llaman a `next` internamente.
//! Sin embargo, también es posible escribir una implementación personalizada de métodos como `nth` y `fold` si un iterador puede calcularlos de manera más eficiente sin llamar a `next`.
//!
//! # `for` bucles y `IntoIterator`
//!
//! La sintaxis del bucle `for` de Rust es en realidad azúcar para los iteradores.Aquí hay un ejemplo básico de `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Esto imprimirá los números del uno al cinco, cada uno en su propia línea.Pero notará algo aquí: nunca llamamos a nada en nuestro vector para producir un iterador.¿Lo que da?
//!
//! Hay un trait en la biblioteca estándar para convertir algo en un iterador: [`IntoIterator`].
//! Este trait tiene un método, [`into_iter`], que convierte la cosa que implementa [`IntoIterator`] en un iterador.
//! Echemos un vistazo a ese bucle `for` nuevamente y en qué lo convierte el compilador:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust elimina el azúcar en:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Primero, llamamos `into_iter()` al valor.Luego, hacemos coincidir en el iterador que regresa, llamando a [`next`] una y otra vez hasta que vemos un `None`.
//! En ese punto, sacamos `break` del ciclo y terminamos de iterar.
//!
//! Aquí hay un bit más sutil: la biblioteca estándar contiene una implementación interesante de [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! En otras palabras, todos los [`Iterator`] implementan [`IntoIterator`], simplemente regresando ellos mismos.Esto significa dos cosas:
//!
//! 1. Si está escribiendo un [`Iterator`], puede usarlo con un bucle `for`.
//! 2. Si está creando una colección, implementar [`IntoIterator`] permitirá que su colección se use con el bucle `for`.
//!
//! # Iterando por referencia
//!
//! Dado que [`into_iter()`] toma `self` por valor, el uso de un bucle `for` para iterar sobre una colección consume esa colección.A menudo, es posible que desee iterar sobre una colección sin consumirla.
//! Muchas colecciones ofrecen métodos que proporcionan iteradores sobre referencias, convencionalmente llamados `iter()` y `iter_mut()` respectivamente:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` sigue siendo propiedad de esta función.
//! ```
//!
//! Si un tipo de colección `C` proporciona `iter()`, generalmente también implementa `IntoIterator` para `&C`, con una implementación que solo llama a `iter()`.
//! Asimismo, una colección `C` que proporciona `iter_mut()` generalmente implementa `IntoIterator` para `&mut C` delegando a `iter_mut()`.Esto permite una cómoda taquigrafía:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // igual que `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // igual que `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Si bien muchas colecciones ofrecen `iter()`, no todas ofrecen `iter_mut()`.
//! Por ejemplo, mutar las claves de un [`HashSet<T>`] o [`HashMap<K, V>`] podría poner la colección en un estado inconsistente si los hashes de la clave cambian, por lo que estas colecciones solo ofrecen `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Las funciones que toman un [`Iterator`] y devuelven otro [`Iterator`] a menudo se denominan 'adaptadores de iterador', ya que son una forma del 'adaptador
//! pattern'.
//!
//! Los adaptadores de iterador comunes incluyen [`map`], [`take`] y [`filter`].
//! Para obtener más información, consulte su documentación.
//!
//! Si un adaptador de iterador panics, el iterador estará en un estado no especificado (pero seguro para la memoria).
//! Tampoco se garantiza que este estado permanezca igual en todas las versiones de Rust, por lo que debe evitar confiar en los valores exactos devueltos por un iterador que entró en pánico.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Los iteradores (y el iterador [adapters](#adapters)) son *perezosos*. Esto significa que crear un iterador no hace mucho _do_. En realidad, nada sucede hasta que llamas a [`next`].
//! A veces, esto es una fuente de confusión cuando se crea un iterador únicamente por sus efectos secundarios.
//! Por ejemplo, el método [`map`] llama a un cierre en cada elemento sobre el que itera:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Esto no imprimirá ningún valor, ya que solo creamos un iterador, en lugar de usarlo.El compilador nos advertirá sobre este tipo de comportamiento:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! La forma idiomática de escribir un [`map`] por sus efectos secundarios es usar un bucle `for` o llamar al método [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Otra forma común de evaluar un iterador es utilizar el método [`collect`] para producir una nueva colección.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Los iteradores no tienen por qué ser finitos.Como ejemplo, un rango abierto es un iterador infinito:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Es común usar el adaptador de iterador [`take`] para convertir un iterador infinito en uno finito:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Esto imprimirá los números `0` a `4`, cada uno en su propia línea.
//!
//! Tenga en cuenta que los métodos en iteradores infinitos, incluso aquellos para los que un resultado se puede determinar matemáticamente en un tiempo finito, pueden no terminar.
//! Específicamente, métodos como [`min`], que en el caso general requieren atravesar todos los elementos del iterador, es probable que no regresen con éxito para ningún iterador infinito.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // ¡Oh, no!¡Un bucle infinito!
//! // `ones.min()` provoca un bucle infinito, ¡así que no llegaremos a este punto!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;