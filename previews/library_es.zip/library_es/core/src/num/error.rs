//! Tipos de error para conversión a tipos integrales.

use crate::convert::Infallible;
use crate::fmt;

/// El tipo de error devuelto cuando falla una conversión de tipo integral comprobada.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Haga coincidir en lugar de coaccionar para asegurarse de que el código como `From<Infallible> for TryFromIntError` anterior seguirá funcionando cuando `Infallible` se convierta en un alias de `!`.
        //
        //
        match never {}
    }
}

/// Un error que se puede devolver al analizar un número entero.
///
/// Este error se utiliza como tipo de error para las funciones `from_str_radix()` en los tipos de enteros primitivos, como [`i8::from_str_radix`].
///
/// # Causas potenciales
///
/// Entre otras causas, `ParseIntError` se puede lanzar debido a espacios en blanco iniciales o finales en la cadena, por ejemplo, cuando se obtiene de la entrada estándar.
///
/// El uso del método [`str::trim()`] garantiza que no queden espacios en blanco antes del análisis.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enumeración para almacenar los distintos tipos de errores que pueden hacer que el análisis de un entero falle.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// El valor que se analiza está vacío.
    ///
    /// Entre otras causas, esta variante se construirá al analizar una cadena vacía.
    Empty,
    /// Contiene un dígito no válido en su contexto.
    ///
    /// Entre otras causas, esta variante se construirá al analizar una cadena que contiene un carácter no ASCII.
    ///
    /// Esta variante también se construye cuando un `+` o `-` se pierde dentro de una cadena, ya sea solo o en medio de un número.
    ///
    ///
    InvalidDigit,
    /// El entero es demasiado grande para almacenarlo en el tipo de entero de destino.
    PosOverflow,
    /// El entero es demasiado pequeño para almacenarlo en el tipo de entero de destino.
    NegOverflow,
    /// El valor era cero
    ///
    /// Esta variante se emitirá cuando la cadena de análisis tenga un valor de cero, lo que sería ilegal para tipos distintos de cero.
    ///
    Zero,
}

impl ParseIntError {
    /// Muestra la causa detallada del error de análisis de un entero.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}