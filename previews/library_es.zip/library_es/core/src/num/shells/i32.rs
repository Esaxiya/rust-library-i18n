//! Constantes para el tipo de entero con signo de 32 bits.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! El nuevo código debe usar las constantes asociadas directamente en el tipo primitivo.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }