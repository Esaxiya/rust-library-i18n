//! Funciones de utilidad para bignums que no tienen mucho sentido para convertirlas en métodos.

// FIXME El nombre de este módulo es un poco desafortunado, ya que otros módulos también importan `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Pruebe si truncar todos los bits menos significativos que `ones_place` introduce un error relativo menor, igual o mayor que 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Si todos los bits restantes son cero, es= 0.5 ULP, de lo contrario> 0.5 Si no hay más bits (half_bit==0), lo siguiente también devuelve correctamente Equal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Convierte una cadena ASCII que contiene solo dígitos decimales en un `u64`.
///
/// No realiza comprobaciones de desbordamiento o caracteres no válidos, por lo que si la persona que llama no tiene cuidado, el resultado es falso y puede panic (aunque no será `unsafe`).
/// Además, las cadenas vacías se tratan como cero.
/// Esta función existe porque
///
/// 1. el uso de `FromStr` en `&[u8]` requiere `from_utf8_unchecked`, que es malo, y
/// 2. juntar los resultados de `integral.parse()` y `fractional.parse()` es más complicado que toda esta función.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Convierte una cadena de dígitos ASCII en un bignum.
///
/// Al igual que `from_str_unchecked`, esta función se basa en el analizador para eliminar los que no son dígitos.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Desenvuelve un bignum en un entero de 64 bits.Panics si el número es demasiado grande.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extrae una variedad de bits.

/// El índice 0 es el bit menos significativo y el rango está medio abierto como de costumbre.
/// Panics si se le pide que extraiga más bits de los que caben en el tipo de retorno.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}