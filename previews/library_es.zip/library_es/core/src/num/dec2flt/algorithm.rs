//! Los distintos algoritmos del artículo.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Número de bits significativos en Fp
const P: u32 = 64;

// Simplemente almacenamos la mejor aproximación para *todos* los exponentes, por lo que la variable "h" y las condiciones asociadas pueden omitirse.
// Esto cambia el rendimiento por un par de kilobytes de espacio.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// En la mayoría de las arquitecturas, las operaciones de punto flotante tienen un tamaño de bit explícito, por lo tanto, la precisión del cálculo se determina por operación.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// En x86, la FPU x87 se utiliza para operaciones flotantes si las extensiones SSE/SSE2 no están disponibles.
// El x87 FPU funciona con 80 bits de precisión de forma predeterminada, lo que significa que las operaciones se redondearán a 80 bits, lo que provocará un doble redondeo cuando los valores finalmente se representen como
//
// 32/64 valores de bit flotante.Para superar esto, la palabra de control FPU se puede configurar para que los cálculos se realicen con la precisión deseada.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Una estructura utilizada para preservar el valor original de la palabra de control FPU, de modo que se pueda restaurar cuando se descarte la estructura.
    ///
    ///
    /// El x87 FPU es un registro de 16 bits cuyos campos son los siguientes:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// La documentación para todos los campos está disponible en el Manual del desarrollador de software de arquitecturas IA-32 (Volumen 1).
    ///
    /// El único campo que es relevante para el siguiente código es PC, Precision Control.
    /// Este campo determina la precisión de las operaciones realizadas por la FPU.
    /// Puede configurarse para:
    ///  - 0b00, precisión simple, es decir, 32 bits
    ///  - 0b10, doble precisión, es decir, 64 bits
    ///  - 0b11, precisión extendida doble, es decir, 80 bits (estado predeterminado) El valor 0b01 está reservado y no debe utilizarse.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SEGURIDAD: la instrucción `fldcw` ha sido auditada para poder funcionar correctamente con
        // cualquier `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Estamos utilizando la sintaxis ATT para admitir LLVM 8 y LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Establece el campo de precisión de la FPU en `T` y devuelve un `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Calcule el valor del campo Control de precisión que sea apropiado para `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bits
            8 => 0x0200, // 64 bits
            _ => 0x0300, // predeterminado, 80 bits
        };

        // Obtenga el valor original de la palabra de control para restaurarlo más tarde, cuando se descarte la estructura `FPUControlWord` SEGURIDAD: la instrucción `fnstcw` ha sido auditada para poder funcionar correctamente con cualquier `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Estamos utilizando la sintaxis ATT para admitir LLVM 8 y LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Establezca la palabra de control con la precisión deseada.
        // Esto se logra enmascarando la precisión anterior (bits 8 y 9, 0x300) y reemplazándola con la bandera de precisión calculada anteriormente.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// El camino rápido de Bellerophon usando números enteros y flotantes del tamaño de una máquina.
///
/// Esto se extrae en una función separada para que se pueda intentar antes de construir un bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Comparamos el valor exacto con MAX_SIG cerca del final, esto es solo un rechazo rápido y barato (y también libera al resto del código de preocuparse por el desbordamiento).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // La ruta rápida depende fundamentalmente de que la aritmética se redondee al número correcto de bits sin ningún redondeo intermedio.
    // En x86 (sin SSE o SSE2), esto requiere que se cambie la precisión de la pila FPU x87 para que se redondea directamente al bit 64/32.
    // La función `set_precision` se encarga de configurar la precisión en las arquitecturas que requieren configurarla cambiando el estado global (como la palabra de control de la x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // El caso e <0 no se puede plegar en la otra branch.
    // Las potencias negativas dan como resultado una parte fraccionaria repetida en binario, que se redondea, lo que provoca errores reales (¡y en ocasiones bastante significativos!) En el resultado final.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// El algoritmo Bellerophon es un código trivial justificado por un análisis numérico no trivial.
///
/// Redondea `` f '' a un flotante con significado de 64 bits y lo multiplica por la mejor aproximación de `10^e` (en el mismo formato de coma flotante).Esto suele ser suficiente para obtener el resultado correcto.
/// Sin embargo, cuando el resultado está cerca de la mitad de camino entre dos flotantes (ordinary) adyacentes, el error de redondeo compuesto de multiplicar dos aproximaciones significa que el resultado puede estar fuera de lugar en unos pocos bits.
/// Cuando esto sucede, el algoritmo iterativo R arregla las cosas.
///
/// El "close to halfway" ondulado a mano se hace preciso mediante el análisis numérico en el papel.
/// En palabras de Clinger:
///
/// > Slop, expresado en unidades del bit menos significativo, es un límite inclusivo para el error
/// > acumulado durante el cálculo de coma flotante de la aproximación af * 10 ^ e.(Slop es
/// > no es un límite para el error verdadero, pero limita la diferencia entre la aproximación zy
/// > la mejor aproximación posible que utiliza p bits de significado.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Los casos abs(e) <log5(2^N) están en fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // ¿Es la pendiente lo suficientemente grande como para marcar una diferencia al redondear an bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Un algoritmo iterativo que mejora una aproximación de punto flotante de `f * 10^e`.
///
/// Cada iteración acerca una unidad en el último lugar, lo que, por supuesto, tarda mucho en converger si `z0` está levemente apagado.
/// Afortunadamente, cuando se usa como alternativa para Bellerophon, la aproximación inicial está desfasada como máximo en un ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Encuentre enteros positivos `x`, `y` tales que `x / y` sea exactamente `(f *10^e) / (m* 2^k)`.
        // Esto no solo evita lidiar con los signos de `e` y `k`, también eliminamos la potencia de dos comunes a `10^e` y `2^k` para hacer los números más pequeños.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Esto está escrito de manera un poco incómoda porque nuestros bignums no admiten números negativos, por lo que usamos la información de valor absoluto + signo.
        // La multiplicación con m_digits no se puede desbordar.
        // Si `x` o `y` son lo suficientemente grandes como para preocuparnos por el desbordamiento, entonces también son lo suficientemente grandes como para que `make_ratio` haya reducido la fracción en un factor de 2 ^ 64 o más.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Ya no necesitas x, guarda un clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Aún te necesito, haz una copia.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Dado `x = f` y `y = m` donde `f` representan dígitos decimales de entrada como de costumbre y `m` es el significado de una aproximación de punto flotante, haga que la relación `x / y` sea igual a `(f *10^e) / (m* 2^k)`, posiblemente reducida por una potencia de dos que ambos tienen en común.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, excepto que reducimos la fracción por alguna potencia de dos.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Esto no puede desbordarse porque requiere `e` positivo y `k` negativo, lo que solo puede ocurrir para valores extremadamente cercanos a 1, lo que significa que `e` y `k` serán comparativamente pequeños.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Esto tampoco puede desbordarse, ver arriba.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), nuevamente reduciendo por una potencia común de dos.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Conceptualmente, el algoritmo M es la forma más sencilla de convertir un decimal en un flotante.
///
/// Formamos una razón que es igual a `f * 10^e`, luego agregando potencias de dos hasta que da un significado flotante válido.
/// El exponente binario `k` es el número de veces que multiplicamos el numerador o denominador por dos, es decir, en todo momento `f *10^e` es igual a `(u / v)* 2^k`.
/// Cuando hayamos descubierto el significado, solo necesitamos redondear inspeccionando el resto de la división, lo que se realiza en las funciones auxiliares más abajo.
///
///
/// Este algoritmo es muy lento, incluso con la optimización descrita en `quick_start()`.
/// Sin embargo, es el algoritmo más simple para adaptarse a los resultados de desbordamiento, subdesbordamiento y subnormales.
/// Esta implementación se hace cargo cuando Bellerophon y Algorithm R están abrumados.
/// Detectar el subdesbordamiento y el desbordamiento es fácil: la relación aún no es un significado dentro del rango, pero se ha alcanzado el exponente minimum/maximum.
/// En el caso de desbordamiento, simplemente devolvemos infinito.
///
/// Manejar subdesbordamientos y subnormales es más complicado.
/// Un gran problema es que, con el mínimo exponente, la razón podría ser aún demasiado grande para un significado.
/// Consulte underflow() para obtener más detalles.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Optimización posible de FIXME: generalice big_to_fp para que podamos hacer el equivalente de fp_to_float(big_to_fp(u)) aquí, solo que sin el doble redondeo.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Tenemos que detenernos en el exponente mínimo, si esperamos hasta `k < T::MIN_EXP_INT`, entonces estaríamos desfasados por un factor de dos.
            // Desafortunadamente, esto significa que tenemos que aplicar números normales en casos especiales con el mínimo exponente.
            // FIXME encuentra una fórmula más elegante, ¡pero ejecute la prueba `tiny-pow10` para asegurarse de que sea realmente correcta!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Omite la mayoría de las iteraciones del algoritmo M comprobando la longitud de bits.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // La longitud de bits es una estimación del logaritmo en base dos, y log(u / v) = log(u), log(v).
    // La estimación está desviada como máximo en 1, pero siempre una subestimación, por lo que el error en log(u) y log(v) tiene el mismo signo y se cancela (si ambos son grandes).
    // Por lo tanto, el error para log(u / v) es como máximo uno también.
    // La relación objetivo es aquella en la que u/v se encuentra en un significado dentro del rango.Por lo tanto, nuestra condición de terminación es log2(u / v) siendo los bits significativos, plus/minus uno.
    // FIXME Mirar el segundo bit podría mejorar la estimación y evitar algunas divisiones más.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Subdesbordamiento o subnormal.Déjelo a la función principal.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Desbordamiento.Déjelo a la función principal.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // La relación no es un significado dentro del rango con el exponente mínimo, por lo que debemos redondear los bits en exceso y ajustar el exponente en consecuencia.
    // El valor real ahora se ve así:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(representado por rem)
    //
    // Por lo tanto, cuando los bits redondeados son!= 0.5 ULP, ellos mismos deciden el redondeo.
    // Cuando son iguales y el resto es distinto de cero, el valor aún debe redondearse.
    // Solo cuando los bits redondeados son 1/2 y el resto es cero, tenemos una situación de mitad a par.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Redondeo a par ordinario, ofuscado por tener que redondear basándose en el resto de una división.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}