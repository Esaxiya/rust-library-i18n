//! Bit jugando con flotantes positivos IEEE 754.Los números negativos no son y no necesitan ser manejados.
//! Los números de coma flotante normales tienen una representación canónica como (frac, exp), de modo que el valor es 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) donde N es el número de bits.
//!
//! Los subnormales son ligeramente diferentes y extraños, pero se aplica el mismo principio.
//!
//! Aquí, sin embargo, los representamos como (sig, k) con f positivo, de modo que el valor es f *
//! 2 <sup>e</sup> .Además de hacer explícito el "hidden bit", esto cambia el exponente por el llamado cambio de mantisa.
//!
//! Dicho de otra manera, normalmente los flotantes se escriben como (1) pero aquí se escriben como (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Llamamos a (1) la **representación fraccionaria** y (2) la **representación integral**.
//!
//! Muchas funciones de este módulo solo manejan números normales.Las rutinas dec2flt toman de manera conservadora la ruta lenta universalmente correcta (algoritmo M) para números muy pequeños y muy grandes.
//! Ese algoritmo solo necesita next_float() que maneja subnormales y ceros.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Un ayudante trait para evitar duplicar básicamente todo el código de conversión para `f32` y `f64`.
///
/// Consulte el comentario del documento del módulo principal para saber por qué es necesario.
///
/// **Nunca** debe implementarse para otros tipos o usarse fuera del módulo dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Tipo utilizado por `to_bits` y `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Realiza una transmutación sin procesar a un número entero.
    fn to_bits(self) -> Self::Bits;

    /// Realiza una transmutación en bruto a partir de un número entero.
    fn from_bits(v: Self::Bits) -> Self;

    /// Devuelve la categoría a la que pertenece este número.
    fn classify(self) -> FpCategory;

    /// Devuelve la mantisa, el exponente y el signo como números enteros.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Decodifica el flotador.
    fn unpack(self) -> Unpacked;

    /// Se lanza a partir de un pequeño entero que se puede representar con exactitud.
    /// Panic si el número entero no se puede representar, el otro código de este módulo se asegura de que eso nunca suceda.
    fn from_int(x: u64) -> Self;

    /// Obtiene el valor 10 <sup>e</sup> de una tabla calculada previamente.
    /// Panics para `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Lo que dice el nombre.
    /// Es más fácil codificar de forma rígida que hacer malabarismos con elementos intrínsecos y esperar que LLVM lo doble constantemente.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Un límite conservador en los dígitos decimales de las entradas que no pueden producir desbordamiento o cero o
    /// subnormales.Probablemente el exponente decimal del valor normal máximo, de ahí el nombre.
    const MAX_NORMAL_DIGITS: usize;

    /// Cuando el dígito decimal más significativo tiene un valor posicional mayor que este, el número ciertamente se redondea al infinito.
    ///
    const INF_CUTOFF: i64;

    /// Cuando el dígito decimal más significativo tiene un valor posicional menor que este, el número ciertamente se redondea a cero.
    ///
    const ZERO_CUTOFF: i64;

    /// El número de bits en el exponente.
    const EXP_BITS: u8;

    /// El número de bits en el significado,*incluido* el bit oculto.
    const SIG_BITS: u8;

    /// El número de bits en el significado,*excluyendo* el bit oculto.
    const EXPLICIT_SIG_BITS: u8;

    /// El máximo exponente legal en representación fraccionaria.
    const MAX_EXP: i16;

    /// El exponente legal mínimo en representación fraccionaria, excluidos los subnormales.
    const MIN_EXP: i16;

    /// `MAX_EXP` para la representación integral, es decir, con el desplazamiento aplicado.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` codificado (es decir, con sesgo de compensación)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` para la representación integral, es decir, con el desplazamiento aplicado.
    const MIN_EXP_INT: i16;

    /// El significado máximo normalizado en representación integral.
    const MAX_SIG: u64;

    /// El significado mínimo normalizado en representación integral.
    const MIN_SIG: u64;
}

// Principalmente una solución para #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Devuelve la mantisa, el exponente y el signo como números enteros.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Sesgo de exponente + desplazamiento de mantisa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe no está seguro de si `as` se redondea correctamente en todas las plataformas.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Devuelve la mantisa, el exponente y el signo como números enteros.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Sesgo de exponente + desplazamiento de mantisa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe no está seguro de si `as` se redondea correctamente en todas las plataformas.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Convierte un `Fp` en el tipo de flotador de máquina más cercano.
/// No maneja resultados subnormales.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f es de 64 bits, por lo que xe tiene un desplazamiento de mantisa de 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Redondea el significado de 64 bits a T::SIG_BITS bits con medio a par.
/// No maneja el desbordamiento de exponentes.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Ajustar el cambio de mantisa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inverso de `RawFloat::unpack()` para números normalizados.
/// Panics si el significando o exponente no es válido para números normalizados.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Quita el bit oculto
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Ajuste el exponente para el sesgo del exponente y el cambio de mantisa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Deje el bit de signo en 0 ("+"), nuestros números son todos positivos
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Construye un subnormal.Se permite una mantisa de 0 y construye cero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // El exponente codificado es 0, el bit de signo es 0, por lo que solo tenemos que reinterpretar los bits.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Aproxime un bignum con un Fp.Redondea dentro de 0.5 ULP con medio a par.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Cortamos todos los bits antes del índice `start`, es decir, efectivamente desplazamos a la derecha en una cantidad de `start`, por lo que este es también el exponente que necesitamos.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Redondea (half-to-even) dependiendo de los bits truncados.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Encuentra el número de coma flotante más grande estrictamente más pequeño que el argumento.
/// No maneja subnormales, cero o subdesbordamiento de exponentes.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Encuentre el número de punto flotante más pequeño estrictamente mayor que el argumento.
// Esta operación es saturante, es decir, next_float(inf) ==inf.
// A diferencia de la mayoría del código de este módulo, esta función maneja cero, subnormales e infinitos.
// Sin embargo, como todos los demás códigos aquí, no se ocupa de NaN y números negativos.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Esto parece demasiado bueno para ser verdad, pero funciona.
        // 0.0 se codifica como la palabra todo cero.Los subnormales son 0x000m ... m donde m es la mantisa.
        // En particular, el subnormal más pequeño es 0x0 ... 01 y el más grande es 0x000F ... F.
        // El número normal más pequeño es 0x0010 ... 0, por lo que este estuche de esquina también funciona.
        // Si el incremento desborda la mantisa, el bit de acarreo incrementa el exponente como queremos y los bits de mantisa se vuelven cero.
        // Debido a la convención de bits ocultos, ¡esto también es exactamente lo que queremos!
        // Finalmente, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}