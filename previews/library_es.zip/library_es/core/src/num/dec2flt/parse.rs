//! Validando y descomponiendo una cadena decimal de la forma:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! En otras palabras, sintaxis estándar de coma flotante, con dos excepciones: sin signo y sin manejo de "inf" y "NaN".Estos son manejados por la función de controlador (super::dec2flt).
//!
//! Aunque reconocer entradas válidas es relativamente fácil, este módulo también tiene que rechazar las innumerables variaciones inválidas, nunca panic, y realizar numerosas comprobaciones en las que los otros módulos confían para no panic (o desbordamiento) a su vez.
//!
//! Para empeorar las cosas, todo eso sucede en una sola pasada sobre la entrada.
//! Por lo tanto, tenga cuidado al modificar algo y verifique dos veces con los otros módulos.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Las partes interesantes de una cadena decimal.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// El exponente decimal, garantizado para tener menos de 18 dígitos decimales.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Comprueba si la cadena de entrada es un número de punto flotante válido y, de ser así, localiza la parte integral, la parte fraccionaria y el exponente en ella.
/// No maneja letreros.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Sin dígitos antes de 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Requerimos al menos un solo dígito antes o después del punto.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Trailing basura tras parte fraccionaria
            }
        }
        _ => Invalid, // Seguimiento de basura después de la cadena del primer dígito
    }
}

/// Corta dígitos decimales hasta el primer carácter que no sea un dígito.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Extracción de exponentes y comprobación de errores.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Trailing basura tras exponente
    }
    if number.is_empty() {
        return Invalid; // Exponente vacío
    }
    // En este punto, ciertamente tenemos una cadena de dígitos válida.Puede que sea demasiado largo para ponerlo en un `i64`, pero si es tan grande, la entrada es ciertamente cero o infinita.
    // Dado que cada cero en los dígitos decimales solo ajusta el exponente en +/-1, en exp=10 ^ 18 la entrada tendría que ser 17 exabyte (!) de ceros para acercarse remotamente a ser finito.
    //
    // Este no es exactamente un caso de uso al que debamos atender.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}