//! Decodifica un valor de punto flotante en partes individuales y rangos de error.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Valor finito sin firmar decodificado, tal que:
///
/// - El valor original es igual a `mant * 2^exp`.
///
/// - Cualquier número de `(mant - minus)*2^exp` a `(mant + plus)* 2^exp` se redondeará al valor original.
/// El rango es inclusivo solo cuando `inclusive` es `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// La mantisa escamosa.
    pub mant: u64,
    /// El rango de error más bajo.
    pub minus: u64,
    /// El rango de error superior.
    pub plus: u64,
    /// El exponente compartido en base 2.
    pub exp: i16,
    /// Verdadero cuando el rango de error es inclusivo.
    ///
    /// En IEEE 754, esto es cierto cuando la mantisa original era pareja.
    pub inclusive: bool,
}

/// Valor sin firmar decodificado.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinitos, positivos o negativos.
    Infinite,
    /// Cero, positivo o negativo.
    Zero,
    /// Números finitos con más campos decodificados.
    Finite(Decoded),
}

/// Un tipo de coma flotante que se puede `decodificar`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// El valor mínimo normalizado positivo.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Devuelve un signo (verdadero cuando es negativo) y un valor `FullDecoded` del número de punto flotante dado.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // vecinos: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode siempre conserva el exponente, por lo que la mantisa se escala para subnormales.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // vecinos: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // donde maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // vecinos: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}