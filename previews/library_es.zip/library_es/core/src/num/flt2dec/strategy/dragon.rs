//! Traducción Rust casi directa (pero ligeramente optimizada) de la Figura 3 de "Impresión de números de punto flotante de forma rápida y precisa" [^ 1].
//!
//!
//! [^1]: Burger, RG y Dybvig, RK 1996. Impresión de números en coma flotante
//!   de forma rápida y precisa.SIGPLAN No.31, 5 (mayo de 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// matrices precalculadas de `Digit`s para 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// solo utilizable cuando `x < 16 * scale`;`scaleN` debería ser `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// La implementación de modo más corta para Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // se sabe que el número `v` a formatear es:
    // - igual a `mant * 2^exp`;
    // - precedido por `(mant - 2 *minus)* 2^exp` en el tipo original;y
    // - seguido de `(mant + 2 *plus)* 2^exp` en el tipo original.
    //
    // obviamente, `minus` y `plus` no pueden ser cero.(para infinitos, usamos valores fuera de rango.) también asumimos que se genera al menos un dígito, es decir, `mant` no puede ser cero también.
    //
    // esto también significa que cualquier número entre `low = (mant - minus)*2^exp` y `high = (mant + plus)* 2^exp` se asignará a este número de punto flotante exacto, con límites incluidos cuando la mantisa original era par (es decir, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` es `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // Estime `k_0` a partir de entradas originales que satisfagan `10^(k_0-1) < high <= 10^(k_0+1)`.
    // el límite ajustado `k` que satisface `10^(k-1) < high <= 10^k` se calcula más adelante.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // convierta `{mant, plus, minus} * 2^exp` en forma fraccionaria para que:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // divide `mant` por `10^k`.ahora `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // reparación cuando `mant + plus > scale` (o `>=`).
    // en realidad, no estamos modificando `scale`, ya que podemos omitir la multiplicación inicial.
    // ahora `scale < mant + plus <= scale * 10` y estamos listos para generar dígitos.
    //
    // tenga en cuenta que `d[0]`*puede* ser cero, cuando `scale - plus < mant < scale`.
    // en este caso, la condición de redondeo (`up` a continuación) se activará inmediatamente.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // equivalente a escalar `scale` en 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // caché `(2, 4, 8) * scale` para generación de dígitos.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariantes, donde `d[0..n-1]` son dígitos generados hasta ahora:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (por tanto, `mant / scale < 10`) donde `d[i..j]` es una abreviatura de `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // generar un dígito: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // esta es una descripción simplificada del algoritmo Dragon modificado.
        // muchas derivaciones intermedias y argumentos de completitud se omiten por conveniencia.
        //
        // comience con invariantes modificados, ya que hemos actualizado `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // suponga que `d[0..n-1]` es la representación más corta entre `low` y `high`, es decir, `d[0..n-1]` satisface los dos requisitos siguientes, pero `d[0..n-2]` no:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijetividad: dígitos redondeados a `v`);y
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (el último dígito es correcto).
        //
        // la segunda condición se simplifica a `2 * mant <= scale`.
        // resolver invariantes en términos de `mant`, `low` y `high` produce una versión más simple de la primera condición: `-plus < mant < minus`.
        // desde `-plus < 0 <= mant`, tenemos la representación más corta correcta cuando `mant < minus` y `2 * mant <= scale`.
        // (el primero se convierte en `mant <= minus` cuando la mantisa original es pareja).
        //
        // cuando el segundo no se mantiene (`2 * mant> scale`), necesitamos aumentar el último dígito.
        // esto es suficiente para restaurar esa condición: ya sabemos que la generación de dígitos garantiza `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // en este caso, la primera condición se convierte en `-plus < mant - scale < minus`.
        // desde `mant < scale` después de la generación, tenemos `scale < mant + plus`.
        // (nuevamente, esto se convierte en `scale <= mant + plus` cuando la mantisa original es pareja).
        //
        // en breve:
        // - detener y redondear `down` (mantener los dígitos como están) cuando `mant < minus` (o `<=`).
        // - detener y redondear `up` (aumentar el último dígito) cuando `scale < mant + plus` (o `<=`).
        // - sigue generando lo contrario.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // tenemos la representación más corta, procedemos al redondeo

        // restaurar las invariantes.
        // esto hace que el algoritmo siempre termine: `minus` y `plus` siempre aumentan, pero `mant` se recorta en módulo `scale` y `scale` es fijo.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // el redondeo al alza ocurre cuando i) solo se activó la condición de redondeo al alza, o ii) se activaron ambas condiciones y el desempate prefiere el redondeo al alza.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // si el redondeo cambia la longitud, el exponente también debería cambiar.
        // parece que esta condición es muy difícil de satisfacer (posiblemente imposible), pero estamos siendo seguros y consistentes aquí.
        //
        // SEGURIDAD: inicializamos esa memoria arriba.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SEGURIDAD: inicializamos esa memoria arriba.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// La implementación del modo fijo y exacto para Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // Estime `k_0` a partir de entradas originales que satisfagan `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // divide `mant` por `10^k`.ahora `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // reparación cuando `mant + plus >= scale`, donde `plus / scale = 10^-buf.len() / 2`.
    // Para mantener el bignum de tamaño fijo, en realidad usamos `mant + floor(plus) >= scale`.
    // en realidad, no estamos modificando `scale`, ya que podemos omitir la multiplicación inicial.
    // nuevamente con el algoritmo más corto, `d[0]` puede ser cero, pero eventualmente se redondeará hacia arriba.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // equivalente a escalar `scale` en 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // si estamos trabajando con la limitación del último dígito, necesitamos acortar el búfer antes del renderizado real para evitar el doble redondeo.
    //
    // ¡tenga en cuenta que tenemos que agrandar el búfer nuevamente cuando ocurra el redondeo!
    let mut len = if k < limit {
        // Ups, ni siquiera podemos producir *un* dígito.
        // esto es posible cuando, digamos, tenemos algo como 9.5 y se redondea a 10.
        // devolvemos un búfer vacío, con la excepción del caso de redondeo al alza posterior que ocurre cuando `k == limit` y tiene que producir exactamente un dígito.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // caché `(2, 4, 8) * scale` para generación de dígitos.
        // (esto puede ser costoso, así que no los calcule cuando el búfer esté vacío).
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // los siguientes dígitos son todos ceros, nos detenemos aquí, ¡*no* intente realizar el redondeo!más bien, complete los dígitos restantes.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SEGURIDAD: inicializamos esa memoria arriba.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // redondeando hacia arriba si nos detenemos en el medio de los dígitos si los siguientes dígitos son exactamente 5000 ..., verifique el dígito anterior e intente redondear a par (es decir, evite redondear hacia arriba cuando el dígito anterior sea par).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SEGURIDAD: `buf[len-1]` está inicializado.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // si el redondeo cambia la longitud, el exponente también debería cambiar.
        // pero se nos ha solicitado un número fijo de dígitos, así que no modifiquemos el búfer ...
        // SEGURIDAD: inicializamos esa memoria arriba.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... a menos que se nos haya solicitado la precisión fija en su lugar.
            // También debemos verificar que, si el búfer original estaba vacío, el dígito adicional solo se puede agregar cuando `k == limit` (caso edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SEGURIDAD: inicializamos esa memoria arriba.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}