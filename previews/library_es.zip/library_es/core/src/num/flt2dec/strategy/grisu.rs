//! Adaptación Rust del algoritmo Grisu3 descrito en "Impresión de números de punto flotante de forma rápida y precisa con números enteros" [^ 1].
//! Utiliza aproximadamente 1 KB de tabla precalculada y, a su vez, es muy rápido para la mayoría de las entradas.
//!
//! [^1]: Florian Loitsch.2010. Imprimir números de punto flotante de forma rápida y
//!   con precisión con números enteros.SIGPLAN No.45, 6 (junio de 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// consulte los comentarios en `format_shortest_opt` para conocer la justificación.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-yo;e=4* yo, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Dado `x > 0`, devuelve `(k, 10^k)` tal que `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// La implementación de modo más corta para Grisu.
///
/// Devuelve `None` cuando, de lo contrario, devolvería una representación inexacta.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // necesitamos al menos tres bits de precisión adicional

    // empezar con los valores normalizados con el exponente compartido
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // encuentre cualquier `cached = 10^minusk` tal que `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // dado que `plus` está normalizado, esto significa `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // dadas nuestras opciones de `ALPHA` y `GAMMA`, esto coloca a `plus * cached` en `[4, 2^32)`.
    //
    // Obviamente, es deseable maximizar `GAMMA - ALPHA`, de modo que no necesitemos muchas potencias en caché de 10, pero hay algunas consideraciones:
    //
    //
    // 1. queremos mantener `floor(plus * cached)` dentro de `u32` ya que necesita una división costosa.
    //    (esto no es realmente evitable, se requiere el resto para estimar la precisión).
    // 2.
    // el resto de `floor(plus * cached)` se multiplica repetidamente por 10 y no debería desbordarse.
    //
    // el primero da `64 + GAMMA <= 32`, mientras que el segundo da `10 * 2^-ALPHA <= 2^64`;
    // -60 y -32 es el rango máximo con esta restricción, y V8 también los usa.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // escala fps.esto da el error máximo de 1 ulp (demostrado a partir del teorema 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-rango real de menos
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // por encima de `minus`, `v` y `plus` son aproximaciones *cuantificadas*(error <1 ulp).
    // como no sabemos que el error es positivo o negativo, usamos dos aproximaciones espaciadas equitativamente y tenemos el error máximo de 2 ulps.
    //
    // el "unsafe region" es un intervalo generoso que generamos inicialmente.
    // el "safe region" es un intervalo conservador que solo aceptamos.
    // comenzamos con la repr correcta dentro de la región insegura, y tratamos de encontrar la repr más cercana a `v` que también esté dentro de la región segura.
    // si no podemos, nos damos por vencidos.
    //
    let plus1 = plus.f + 1;
    // sea plus0 = plus.f, 1;//solo para explicación sea minus0 = minus.f + 1;//solo para explicación
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // exponente compartido

    // divida `plus1` en partes integrales y fraccionarias.
    // Se garantiza que las piezas integrales encajen en u32, ya que la potencia en caché garantiza `plus < 2^32` y `plus.f` normalizado siempre es menor que `2^64 - 2^4` debido al requisito de precisión.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // Calcule el `10^max_kappa` más grande no más de `plus1` (por lo tanto, `plus1 < 10^(max_kappa+1)`).
    // este es un límite superior de `kappa` a continuación.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorema 6.2: si `k` es el mayor entero st
    // `0 <= y mod 10^k <= y - x`,              entonces `V = floor(y / 10^k) * 10^k` está en `[x, y]` y es una de las representaciones más cortas (con el número mínimo de dígitos significativos) en ese rango.
    //
    //
    // encuentre la longitud del dígito `kappa` entre `(minus1, plus1)` según el Teorema 6.2.
    // Se puede adoptar el teorema 6.2 para excluir `x` requiriendo `y mod 10^k < y - x` en su lugar.
    // (por ejemplo, `x` =32000, `y` =32777; `kappa` =2 ya que `y mod 10 ^ 3=777 <y, x=777`.) el algoritmo se basa en la fase de verificación posterior para excluir `y`.
    //
    let delta1 = plus1 - minus1;
    // deje delta1int=(delta1>> e) como usize;//solo para explicación
    let delta1frac = delta1 & ((1 << e) - 1);

    // renderice partes integrales, mientras verifica la precisión en cada paso.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // dígitos aún por representar
    loop {
        // siempre tenemos al menos un dígito para representar, como invariantes `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (se deduce que `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // divide `remainder` por `10^kappa`.ambos están escalados por `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; hemos encontrado el `kappa` correcto.
            let ten_kappa = (ten_kappa as u64) << e; // escala 10 ^ kappa de nuevo al exponente compartido
            return round_and_weed(
                // SEGURIDAD: inicializamos esa memoria arriba.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // romper el ciclo cuando hayamos renderizado todos los dígitos integrales.
        // el número exacto de dígitos es `max_kappa + 1` como `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // restaurar invariantes
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // renderice partes fraccionarias, mientras verifica la precisión en cada paso.
    // esta vez nos basamos en multiplicaciones repetidas, ya que la división perderá precisión.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // el siguiente dígito debería ser significativo, ya que lo hemos probado antes de dividir los invariantes, donde `m = max_kappa + 1` (#de dígitos en la parte integral):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // no se desbordará, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // divide `remainder` por `10^kappa`.
        // ambos están escalados por `2^e / 10^kappa`, por lo que el último está implícito aquí.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // divisor implícito
            return round_and_weed(
                // SEGURIDAD: inicializamos esa memoria arriba.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // restaurar invariantes
        kappa -= 1;
        remainder = r;
    }

    // hemos generado todos los dígitos significativos de `plus1`, pero no estoy seguro de si es el óptimo.
    // por ejemplo, si `minus1` es 3.14153 ... y `plus1` es 3.14158 ..., hay 5 diferentes representaciones más cortas de 3.14154 a 3.14158 pero solo tenemos la más grande.
    // tenemos que disminuir sucesivamente el último dígito y comprobar si esta es la repr. óptima.
    // hay como máximo 9 candidatos (..1 a ..9), por lo que esto es bastante rápido.(Fase "rounding")
    //
    // la función comprueba si esta repr "optimal" está realmente dentro de los rangos ulp, y también, es posible que la repr "second-to-optimal" pueda ser realmente óptima debido al error de redondeo.
    // en cualquier caso, esto devuelve `None`.
    // (Fase "weeding")
    //
    // todos los argumentos aquí se escalan por el valor común (pero implícito) `k`, de modo que:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (y también, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (y también, `threshold > plus1v` de invariantes anteriores)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // producir dos aproximaciones a `v` (en realidad `plus1 - v`) dentro de 1.5 ulps.
        // la representación resultante debe ser la representación más cercana a ambos.
        //
        // aquí se utiliza `plus1 - v` ya que los cálculos se realizan con respecto a `plus1` para evitar overflow/underflow (de ahí los nombres aparentemente intercambiados).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // disminuya el último dígito y deténgase en la representación más cercana a `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // trabajamos con los dígitos aproximados `w(n)`, que inicialmente es igual a `plus1 - plus1 % 10^kappa`.después de ejecutar el cuerpo del bucle `n` veces, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // establecemos `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (por lo tanto, `resto= plus1w(0)`) para simplificar las comprobaciones.
            // tenga en cuenta que `plus1w(n)` siempre está aumentando.
            //
            // tenemos tres condiciones para rescindir.cualquiera de ellos hará que el bucle no pueda continuar, pero de todos modos tenemos al menos una representación válida que se sabe que está más cerca de `v + 1 ulp`.
            // los indicaremos como TC1 a TC3 para abreviar.
            //
            // TC1: `w(n) <= v + 1 ulp`, es decir, esta es la última repr que puede ser la más cercana.
            // esto es equivalente a `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // combinado con TC2 (que comprueba si `w(n+1)` is valid), esto evita el posible desbordamiento en el cálculo de `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, es decir, la siguiente repetición definitivamente no se redondea a `v`.
            // esto es equivalente a `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // el lado izquierdo puede desbordarse, pero sabemos `threshold > plus1v`, por lo que si TC1 es falso, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` y podemos probar con seguridad si `threshold - plus1w(n) < 10^kappa` en su lugar.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, es decir, la siguiente repetición es
            // no más cerca de `v + 1 ulp` que la repr.
            // dado `z(n) = plus1v_up - plus1w(n)`, esto se convierte en `abs(z(n)) <= abs(z(n+1))`.nuevamente asumiendo que TC1 es falso, tenemos `z(n) > 0`.tenemos dos casos a considerar:
            //
            // - cuando `z(n+1) >= 0`: TC3 se convierte en `z(n) <= z(n+1)`.
            // a medida que `plus1w(n)` está aumentando, `z(n)` debería estar disminuyendo y esto es claramente falso.
            // - cuando `z(n+1) < 0`:
            //   - TC3a: la condición previa es `plus1v_up < plus1w(n) + 10^kappa`.asumiendo que TC2 es falso, `threshold >= plus1w(n) + 10^kappa` para que no se desborde.
            //   - TC3b: TC3 se convierte en `z(n) <= -z(n+1)`, es decir, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   el TC1 negado proporciona `plus1v_up > plus1w(n)`, por lo que no puede desbordarse o subdesbordarse cuando se combina con TC3a.
            //
            // en consecuencia, deberíamos detenernos cuando `TC1 || TC2 || (TC3a && TC3b)`.lo siguiente es igual a su inverso, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // la repr más corta no puede terminar con `0`
                plus1w += ten_kappa;
            }
        }

        // compruebe si esta representación es también la representación más cercana a `v - 1 ulp`.
        //
        // esto es simplemente igual a las condiciones de terminación para `v + 1 ulp`, con todo `plus1v_up` reemplazado por `plus1v_down` en su lugar.
        // El análisis de desbordamiento se mantiene igualmente.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // ahora tenemos la representación más cercana a `v` entre `plus1` y `minus1`.
        // Sin embargo, esto es demasiado liberal, por lo que rechazamos cualquier `w(n)` que no esté entre `plus0` y `minus0`, es decir, `plus1 - plus1w(n) <= minus0` o `plus1 - plus1w(n) >= plus0`.
        // utilizamos los hechos de que `threshold = plus1 - minus1` y `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// La implementación de modo más corta para Grisu con Dragon fallback.
///
/// Esto debería usarse en la mayoría de los casos.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SEGURIDAD: El verificador de préstamos no es lo suficientemente inteligente como para permitirnos usar `buf`
    // en el segundo branch, así que lavamos la vida aquí.
    // Pero solo reutilizamos `buf` si `format_shortest_opt` devolvió `None`, por lo que está bien.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// La implementación del modo exacto y fijo para Grisu.
///
/// Devuelve `None` cuando, de lo contrario, devolvería una representación inexacta.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // necesitamos al menos tres bits de precisión adicional
    assert!(!buf.is_empty());

    // normalizar y escalar `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // divida `v` en partes integrales y fraccionarias.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // tanto el antiguo `v` como el nuevo `v` (escalado por `10^-k`) tienen un error de <1 ulp (Teorema 5.1).
    // como no sabemos que el error es positivo o negativo, usamos dos aproximaciones espaciadas equitativamente y tenemos el error máximo de 2 ulps (lo mismo para el caso más corto).
    //
    //
    // el objetivo es encontrar la serie de dígitos redondeados exactamente que son comunes a `v - 1 ulp` y `v + 1 ulp`, de modo que tengamos la máxima confianza.
    // si esto no es posible, no sabemos cuál es la salida correcta para `v`, por lo que nos damos por vencidos y retrocedemos.
    //
    // `err` se define como `1 ulp * 2^e` aquí (igual que el ulp en `vfrac`), y lo escalaremos siempre que `v` se escale.
    //
    //
    //
    let mut err = 1;

    // Calcule el `10^max_kappa` más grande no más de `v` (por lo tanto, `v < 10^(max_kappa+1)`).
    // este es un límite superior de `kappa` a continuación.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // si estamos trabajando con la limitación del último dígito, necesitamos acortar el búfer antes del renderizado real para evitar el doble redondeo.
    //
    // ¡tenga en cuenta que tenemos que agrandar el búfer nuevamente cuando ocurra el redondeo!
    let len = if exp <= limit {
        // Ups, ni siquiera podemos producir *un* dígito.
        // esto es posible cuando, digamos, tenemos algo como 9.5 y se redondea a 10.
        //
        // en principio, podemos llamar inmediatamente a `possibly_round` con un búfer vacío, pero escalar `max_ten_kappa << e` en 10 puede provocar un desbordamiento.
        //
        // por lo tanto, estamos siendo descuidados aquí y ampliamos el rango de error en un factor de 10.
        // esto aumentará la tasa de falsos negativos, pero solo muy,*muy* ligeramente;
        // solo puede tener una importancia notable cuando la mantisa es mayor de 60 bits.
        //
        // SEGURIDAD: `len=0`, por lo que la obligación de haber inicializado esta memoria es trivial.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // renderizar partes integrales.
    // el error es completamente fraccionario, por lo que no es necesario verificarlo en esta parte.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // dígitos aún por representar
    loop {
        // siempre tenemos al menos un dígito para representar invariantes:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (se deduce que `remainder = vint % 10^(kappa+1)`)
        //
        //

        // divide `remainder` por `10^kappa`.ambos están escalados por `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ¿Está lleno el búfer?ejecutar el pase de redondeo con el resto.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SEGURIDAD: hemos inicializado `len` muchos bytes.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // romper el ciclo cuando hayamos renderizado todos los dígitos integrales.
        // el número exacto de dígitos es `max_kappa + 1` como `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // restaurar invariantes
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // renderizar partes fraccionarias.
    //
    // en principio, podemos continuar hasta el último dígito disponible y verificar la precisión.
    // lamentablemente estamos trabajando con enteros de tamaño finito, por lo que necesitamos algún criterio para detectar el desbordamiento.
    // V8 usa `remainder > err`, que se vuelve falso cuando los primeros dígitos significativos `i` de `v - 1 ulp` y `v` difieren.
    // sin embargo, esto rechaza demasiadas entradas válidas.
    //
    // dado que la fase posterior tiene una detección de desbordamiento correcta, en su lugar usamos un criterio más estricto:
    // continuamos hasta que `err` exceda `10^kappa / 2`, por lo que el rango entre `v - 1 ulp` y `v + 1 ulp` definitivamente contiene dos o más representaciones redondeadas.
    //
    // esto es igual a las dos primeras comparaciones de `possibly_round`, como referencia.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariantes, donde `m = max_kappa + 1` (#de dígitos en la parte integral):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // no se desbordará, `2^e * 10 < 2^64`
        err *= 10; // no se desbordará, `err * 10 < 2^e * 5 < 2^64`

        // divide `remainder` por `10^kappa`.
        // ambos están escalados por `2^e / 10^kappa`, por lo que el último está implícito aquí.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ¿Está lleno el búfer?ejecutar el pase de redondeo con el resto.
        if i == len {
            // SEGURIDAD: hemos inicializado `len` muchos bytes.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // restaurar invariantes
        remainder = r;
    }

    // más cálculos son inútiles (`possibly_round` definitivamente falla), así que nos damos por vencidos.
    return None;

    // hemos generado todos los dígitos solicitados de `v`, que también deberían ser iguales a los dígitos correspondientes de `v - 1 ulp`.
    // ahora comprobamos si hay una representación única compartida por `v - 1 ulp` y `v + 1 ulp`;esto puede ser el mismo para los dígitos generados o para la versión redondeada de esos dígitos.
    //
    // si el rango contiene múltiples representaciones de la misma longitud, no podemos estar seguros y deberíamos devolver `None` en su lugar.
    //
    // todos los argumentos aquí se escalan por el valor común (pero implícito) `k`, de modo que:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SEGURIDAD: los primeros bytes `len` de `buf` deben inicializarse.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (para la referencia, la línea de puntos indica el valor exacto de las posibles representaciones en un número determinado de dígitos).
        //
        //
        // El error es demasiado grande para que haya al menos tres representaciones posibles entre `v - 1 ulp` y `v + 1 ulp`.
        // no podemos determinar cuál es la correcta.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // de hecho, 1/2 ulp es suficiente para introducir dos posibles representaciones.
        // (recuerde que necesitamos una representación única tanto para `v - 1 ulp` como para `v + 1 ulp`.) esto no se desbordará, como `ulp < ten_kappa` de la primera verificación.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // si `v + 1 ulp` está más cerca de la representación redondeada hacia abajo (que ya está en `buf`), entonces podemos regresar con seguridad.
        // tenga en cuenta que `v - 1 ulp`*puede* ser menor que la representación actual, pero como `1 ulp < 10^kappa / 2`, esta condición es suficiente:
        // la distancia entre `v - 1 ulp` y la representación actual no puede exceder `10^kappa / 2`.
        //
        // la condición es igual a `remainder + ulp < 10^kappa / 2`.
        // ya que esto puede desbordarse fácilmente, primero verifique si `remainder < 10^kappa / 2`.
        // Ya hemos verificado que `ulp < 10^kappa / 2`, así que siempre que `10^kappa` no se desborde después de todo, la segunda verificación está bien.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SEGURIDAD: nuestra persona que llama inicializó esa memoria.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------resto------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // por otro lado, si `v - 1 ulp` está más cerca de la representación redondeada, deberíamos redondear y regresar.
        // por la misma razón, no necesitamos verificar `v + 1 ulp`.
        //
        // la condición es igual a `remainder - ulp >= 10^kappa / 2`.
        // nuevamente, primero verificamos si `remainder > ulp` (tenga en cuenta que esto no es `remainder >= ulp`, ya que `10^kappa` nunca es cero).
        //
        // También tenga en cuenta que `remainder - ulp <= 10^kappa`, por lo que la segunda comprobación no se desborda.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SEGURIDAD: nuestra persona que llama debe haber inicializado esa memoria.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // solo agregue un dígito adicional cuando se nos solicite la precisión fija.
                // También debemos verificar que, si el búfer original estaba vacío, el dígito adicional solo se puede agregar cuando `exp == limit` (caso edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SEGURIDAD: nosotros y nuestra persona que llama inicializamos esa memoria.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // de lo contrario, estamos condenados (es decir, algunos valores entre `v - 1 ulp` y `v + 1 ulp` se redondean hacia abajo y otros se redondean hacia arriba) y nos rendimos.
        //
        None
    }
}

/// La implementación del modo exacto y fijo para Grisu con Dragon fallback.
///
/// Esto debería usarse en la mayoría de los casos.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SEGURIDAD: El verificador de préstamos no es lo suficientemente inteligente como para permitirnos usar `buf`
    // en el segundo branch, así que lavamos la vida aquí.
    // Pero solo reutilizamos `buf` si `format_exact_opt` devolvió `None`, por lo que está bien.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}