//! El estimador de exponentes.

/// Encuentra `k_0` tal que `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`.
///
/// Esto se usa para aproximar `k = ceil(log_10 (mant * 2^exp))`;
/// el verdadero `k` es `k_0` o `k_0+1`.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits si mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) por lo tanto, esto siempre subestima (o es exacto), pero no mucho.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}