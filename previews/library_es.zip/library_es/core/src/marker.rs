//! traits primitivo y tipos que representan propiedades básicas de tipos.
//!
//! Los tipos Rust se pueden clasificar de varias formas útiles de acuerdo con sus propiedades intrínsecas.
//! Estas clasificaciones se representan como traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tipos que se pueden transferir a través de los límites de los hilos.
///
/// Este trait se implementa automáticamente cuando el compilador determina que es apropiado.
///
/// Un ejemplo de un tipo que no es "Enviar" es el puntero de recuento de referencias [`rc::Rc`][`Rc`].
/// Si dos subprocesos intentan clonar [`Rc`] s que apuntan al mismo valor contado de referencia, es posible que intenten actualizar el recuento de referencias al mismo tiempo, que es [undefined behavior][ub] porque [`Rc`] no usa operaciones atómicas.
///
/// Su primo [`sync::Arc`][arc] usa operaciones atómicas (incurriendo en algunos gastos generales) y, por lo tanto, es `Send`.
///
/// Consulte [the Nomicon](../../nomicon/send-and-sync.html) para obtener más detalles.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tipos con un tamaño constante conocido en tiempo de compilación.
///
/// Todos los parámetros de tipo tienen un límite implícito de `Sized`.La sintaxis especial `?Sized` se puede utilizar para eliminar este límite si no es apropiado.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//error: el tamaño no está implementado para [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// La única excepción es el tipo `Self` implícito de un trait.
/// Un trait no tiene un límite `Sized` implícito ya que es incompatible con [trait object] s donde, por definición, el trait necesita trabajar con todos los implementadores posibles y, por lo tanto, podría tener cualquier tamaño.
///
///
/// Aunque Rust le permitirá vincular `Sized` a un trait, no podrá usarlo para formar un objeto trait más adelante:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // sea y: &dyn Bar= &Impl;//error: el trait `Bar` no se puede convertir en un objeto
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // por defecto, por ejemplo, que requiere que `[T]: !Default` sea evaluable
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tipos que pueden ser "unsized" a un tipo de tamaño dinámico.
///
/// Por ejemplo, el tipo de matriz de tamaño `[i8; 2]` implementa `Unsize<[i8]>` y `Unsize<dyn fmt::Debug>`.
///
/// Todas las implementaciones de `Unsize` son proporcionadas automáticamente por el compilador.
///
/// `Unsize` está implementado para:
///
/// - `[T; N]` es `Unsize<[T]>`
/// - `T` es `Unsize<dyn Trait>` cuando `T: Trait`
/// - `Foo<..., T, ...>` es `Unsize<Foo<..., U, ...>>` si:
///   - `T: Unsize<U>`
///   - Foo es una estructura
///   - Solo el último campo de `Foo` tiene un tipo que involucra `T`
///   - `T` no es parte del tipo de ningún otro campo
///   - `Bar<T>: Unsize<Bar<U>>`, si el último campo de `Foo` tiene el tipo `Bar<T>`
///
/// `Unsize` se utiliza junto con [`ops::CoerceUnsized`] para permitir que los contenedores "user-defined", como [`Rc`], contengan tipos de tamaño dinámico.
/// Consulte [DST coercion RFC][RFC982] y [the nomicon entry on coercion][nomicon-coerce] para obtener más detalles.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Se requiere trait para las constantes utilizadas en coincidencias de patrones.
///
/// Cualquier tipo que derive `PartialEq` implementa automáticamente este trait,*independientemente* de si sus parámetros de tipo implementan `Eq`.
///
/// Si un elemento `const` contiene algún tipo que no implementa este trait, entonces ese tipo (1.) no implementa `PartialEq` (lo que significa que la constante no proporcionará ese método de comparación, que la generación de código supone que está disponible), o (2.) implementa *su propio* versión de `PartialEq` (que asumimos no se ajusta a una comparación de igualdad estructural).
///
///
/// En cualquiera de los dos escenarios anteriores, rechazamos el uso de dicha constante en una coincidencia de patrones.
///
/// Consulte también [structural match RFC][RFC1445] y [issue 63438] que motivaron la migración del diseño basado en atributos a este trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Se requiere trait para las constantes utilizadas en coincidencias de patrones.
///
/// Cualquier tipo que derive `Eq` implementa automáticamente este trait,*independientemente* de si sus parámetros de tipo implementan `Eq`.
///
/// Este es un truco para evitar una limitación en nuestro sistema de tipos.
///
/// # Background
///
/// Queremos exigir que los tipos de consts utilizados en las coincidencias de patrones tengan el atributo `#[derive(PartialEq, Eq)]`.
///
/// En un mundo más ideal, podríamos verificar ese requisito simplemente verificando que el tipo dado implemente tanto el `StructuralPartialEq` trait *como* el `Eq` trait.
/// Sin embargo, puede tener ADT que *hacen*`derive(PartialEq, Eq)`, y es un caso que queremos que el compilador acepte y, sin embargo, el tipo de la constante no implementa `Eq`.
///
/// Es decir, un caso como este:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (El problema en el código anterior es que `Wrap<fn(&())>` no implementa `PartialEq`, ni `Eq`, porque `para <'a> fn(&'a _)` does not implement those traits.)
///
/// Por lo tanto, no podemos confiar en una verificación ingenua para `StructuralPartialEq` y simplemente `Eq`.
///
/// Como truco para solucionar esto, usamos dos traits separados inyectados por cada una de las dos derivadas (`#[derive(PartialEq)]` y `#[derive(Eq)]`) y verificamos que ambos estén presentes como parte de la verificación de coincidencia estructural.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Tipos cuyos valores se pueden duplicar simplemente copiando bits.
///
/// De forma predeterminada, los enlaces de variables tienen 'semántica de movimiento'.En otras palabras:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` se ha trasladado a `y`, por lo que no se puede utilizar
///
/// // println! ("{: ?}", x);//error: uso de valor movido
/// ```
///
/// Sin embargo, si un tipo implementa `Copy`, en su lugar tiene 'semántica de copia':
///
/// ```
/// // Podemos derivar una implementación `Copy`.
/// // `Clone` También se requiere, ya que es un superretrato de `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` es una copia de `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Es importante tener en cuenta que en estos dos ejemplos, la única diferencia es si se le permite acceder a `x` después de la asignación.
/// Bajo el capó, tanto una copia como un movimiento pueden resultar en la copia de bits en la memoria, aunque esto a veces se optimiza.
///
/// ## ¿Cómo puedo implementar `Copy`?
///
/// Hay dos formas de implementar `Copy` en su tipo.El más simple es usar `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// También puede implementar `Copy` y `Clone` manualmente:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Hay una pequeña diferencia entre los dos: la estrategia `derive` también colocará un límite `Copy` en los parámetros de tipo, lo que no siempre se desea.
///
/// ## ¿Cuál es la diferencia entre `Copy` y `Clone`?
///
/// Las copias ocurren implícitamente, por ejemplo, como parte de una asignación `y = x`.El comportamiento de `Copy` no se puede sobrecargar;siempre es una simple copia bit a bit.
///
/// La clonación es una acción explícita, `x.clone()`.La implementación de [`Clone`] puede proporcionar cualquier comportamiento específico de tipo necesario para duplicar valores de forma segura.
/// Por ejemplo, la implementación de [`Clone`] para [`String`] necesita copiar el búfer de cadena apuntada en el montón.
/// Una simple copia bit a bit de los valores [`String`] simplemente copiaría el puntero, dando lugar a un doble libre en la línea.
/// Por esta razón, [`String`] es [`Clone`] pero no `Copy`.
///
/// [`Clone`] es un superretrato de `Copy`, por lo que todo lo que es `Copy` también debe implementar [`Clone`].
/// Si un tipo es `Copy`, entonces su implementación [`Clone`] solo necesita devolver `*self` (vea el ejemplo anterior).
///
/// ## ¿Cuándo puede mi tipo ser `Copy`?
///
/// Un tipo puede implementar `Copy` si todos sus componentes implementan `Copy`.Por ejemplo, esta estructura puede ser `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Una estructura puede ser `Copy` y [`i32`] es `Copy`, por lo tanto, `Point` es elegible para ser `Copy`.
/// Por el contrario, considere
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// La estructura `PointList` no puede implementar `Copy`, porque [`Vec<T>`] no es `Copy`.Si intentamos derivar una implementación `Copy`, obtendremos un error:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Las referencias compartidas (`&T`) también son `Copy`, por lo que un tipo puede ser `Copy`, incluso cuando contiene referencias compartidas de tipos `T` que *no*`Copy`.
/// Considere la siguiente estructura, que puede implementar `Copy`, porque solo contiene una *referencia compartida* a nuestro tipo `PointList` que no es "Copia" de arriba:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## ¿Cuándo *no puede* mi tipo ser `Copy`?
///
/// Algunos tipos no se pueden copiar de forma segura.Por ejemplo, copiar `&mut T` crearía una referencia mutable con alias.
/// Copiar [`String`] duplicaría la responsabilidad de administrar el búfer de [`String`], lo que generaría un doble libre.
///
/// Generalizando el último caso, cualquier tipo que implemente [`Drop`] no puede ser `Copy`, porque está administrando algún recurso además de sus propios bytes [`size_of::<T>`].
///
/// Si intenta implementar `Copy` en una estructura o enumeración que contiene datos que no son "Copiar", obtendrá el error [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## ¿Cuándo *debería* mi tipo ser `Copy`?
///
/// En términos generales, si su tipo _can_ implementa `Copy`, debería hacerlo.
/// Sin embargo, tenga en cuenta que la implementación de `Copy` es parte de la API pública de su tipo.
/// Si el tipo puede convertirse en no "Copiar" en future, sería prudente omitir la implementación de `Copy` ahora, para evitar un cambio de API rotundo.
///
/// ## Implementadores adicionales
///
/// Además del [implementors listed below][impls], los siguientes tipos también implementan `Copy`:
///
/// * Tipos de elementos de función (es decir, los distintos tipos definidos para cada función)
/// * Tipos de puntero de función (p. Ej., `fn() -> i32`)
/// * Tipos de matriz, para todos los tamaños, si el tipo de elemento también implementa `Copy` (por ejemplo, `[i32; 123456]`)
/// * Tipos de tuplas, si cada componente también implementa `Copy` (por ejemplo, `()`, `(i32, bool)`)
/// * Tipos de cierre, si no capturan ningún valor del entorno o si todos esos valores capturados implementan `Copy` por sí mismos.
///   Tenga en cuenta que las variables capturadas por referencia compartida siempre implementan `Copy` (incluso si el referente no lo hace), mientras que las variables capturadas por referencia mutable nunca implementan `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Esto permite copiar un tipo que no implementa `Copy` debido a límites de vida no satisfechos (copiar `A<'_>` cuando solo `A<'static>: Copy` y `A<'_>: Clone`).
// Tenemos este atributo aquí por ahora solo porque hay bastantes especializaciones existentes en `Copy` que ya existen en la biblioteca estándar, y no hay forma de tener este comportamiento de manera segura en este momento.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Derive macro que genera una impl del trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tipos para los que es seguro compartir referencias entre hilos.
///
/// Este trait se implementa automáticamente cuando el compilador determina que es apropiado.
///
/// La definición precisa es: un tipo `T` es [`Sync`] si y solo si `&T` es [`Send`].
/// En otras palabras, si no hay posibilidad de [undefined behavior][ub] (incluidas las carreras de datos) al pasar referencias `&T` entre subprocesos.
///
/// Como era de esperar, los tipos primitivos como [`u8`] y [`f64`] son todos [`Sync`], y también lo son los tipos agregados simples que los contienen, como tuplas, estructuras y enumeraciones.
/// Más ejemplos de tipos básicos de [`Sync`] incluyen tipos "immutable" como `&T`, y aquellos con mutabilidad heredada simple, como [`Box<T>`][box], [`Vec<T>`][vec] y la mayoría de los otros tipos de colección.
///
/// (Los parámetros genéricos deben ser [`Sync`] para que su contenedor sea [`Sync`]).
///
/// Una consecuencia algo sorprendente de la definición es que `&mut T` es `Sync` (si `T` es `Sync`) aunque parece que eso podría proporcionar una mutación no sincronizada.
/// El truco es que una referencia mutable detrás de una referencia compartida (es decir, `& &mut T`) se vuelve de solo lectura, como si fuera un `& &T`.
/// Por tanto, no hay riesgo de que se produzca una carrera de datos.
///
/// Los tipos que no son `Sync` son aquellos que tienen "interior mutability" en una forma no segura para subprocesos, como [`Cell`][cell] y [`RefCell`][refcell].
/// Estos tipos permiten la mutación de su contenido incluso a través de una referencia compartida e inmutable.
/// Por ejemplo, el método `set` en [`Cell<T>`][cell] toma `&self`, por lo que solo requiere una referencia compartida [`&Cell<T>`][cell].
/// El método no realiza ninguna sincronización, por lo que [`Cell`][cell] no puede ser `Sync`.
///
/// Otro ejemplo de un tipo que no es "Sync" es el puntero de recuento de referencias [`Rc`][rc].
/// Dada cualquier referencia [`&Rc<T>`][rc], puede clonar un nuevo [`Rc<T>`][rc], modificando los recuentos de referencia de forma no atómica.
///
/// Para los casos en los que se necesita una mutabilidad interior segura para subprocesos, Rust proporciona [atomic data types], así como bloqueo explícito a través de [`sync::Mutex`][mutex] y [`sync::RwLock`][rwlock].
/// Estos tipos aseguran que cualquier mutación no pueda causar carreras de datos, por lo tanto, los tipos son `Sync`.
/// Asimismo, [`sync::Arc`][arc] proporciona un análogo seguro para subprocesos de [`Rc`][rc].
///
/// Cualquier tipo con mutabilidad interior también debe usar la envoltura [`cell::UnsafeCell`][unsafecell] alrededor del value(s) que se puede mutar a través de una referencia compartida.
/// No hacer esto es [undefined behavior][ub].
/// Por ejemplo, [`transmutar`][transmutar]-ing de `&T` a `&mut T` no es válido.
///
/// Consulte [the Nomicon][nomicon-send-and-sync] para obtener más detalles sobre `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): una vez que el soporte para agregar notas en `rustc_on_unimplemented` aterrice en beta, y se haya extendido para verificar si un cierre está en algún lugar de la cadena de requisitos, extiéndalo como tal (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Tipo de letra de tamaño cero utilizado para marcar cosas que "act like" poseen un `T`.
///
/// Agregar un campo `PhantomData<T>` a su tipo le dice al compilador que su tipo actúa como si almacenara un valor de tipo `T`, aunque en realidad no lo hace.
/// Esta información se utiliza al calcular ciertas propiedades de seguridad.
///
/// Para obtener una explicación más detallada de cómo utilizar `PhantomData<T>`, consulte [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Una nota espantosa 👻👻👻
///
/// Aunque ambos tienen nombres aterradores, `PhantomData` y los 'tipos fantasmas' están relacionados, pero no son idénticos.Un parámetro de tipo fantasma es simplemente un parámetro de tipo que nunca se utiliza.
/// En Rust, esto a menudo hace que el compilador se queje, y la solución es agregar un uso de "dummy" a través de `PhantomData`.
///
/// # Examples
///
/// ## Parámetros de vida útil no utilizados
///
/// Quizás el caso de uso más común para `PhantomData` es una estructura que tiene un parámetro de vida útil no utilizado, generalmente como parte de algún código inseguro.
/// Por ejemplo, aquí hay una estructura `Slice` que tiene dos punteros de tipo `*const T`, presumiblemente apuntando a una matriz en algún lugar:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// La intención es que los datos subyacentes solo sean válidos durante la vida útil de `'a`, por lo que `Slice` no debería sobrevivir a `'a`.
/// Sin embargo, esta intención no se expresa en el código, ya que no hay usos del `'a` de por vida y, por lo tanto, no está claro a qué datos se aplica.
/// Podemos corregir esto diciéndole al compilador que actúe *como si* la estructura `Slice` contuviera una referencia `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Esto también, a su vez, requiere la anotación `T: 'a`, que indica que cualquier referencia en `T` es válida durante la vida útil de `'a`.
///
/// Al inicializar un `Slice`, simplemente proporcione el valor `PhantomData` para el campo `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Parámetros de tipo no utilizados
///
/// A veces sucede que tiene parámetros de tipo no utilizados que indican a qué tipo de datos es una estructura "tied", aunque esos datos no se encuentran realmente en la estructura en sí.
/// Aquí hay un ejemplo donde esto surge con [FFI].
/// La interfaz externa utiliza identificadores de tipo `*mut ()` para referirse a valores Rust de diferentes tipos.
/// Realizamos un seguimiento del tipo Rust utilizando un parámetro de tipo fantasma en la estructura `ExternalResource` que envuelve un identificador.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Propiedad y el cheque de caída
///
/// Agregar un campo de tipo `PhantomData<T>` indica que su tipo posee datos de tipo `T`.Esto, a su vez, implica que cuando se descarta su tipo, puede descartar una o más instancias del tipo `T`.
/// Esto tiene relación con el análisis [drop check] del compilador Rust.
///
/// Si su estructura de hecho no *posee* los datos de tipo `T`, es mejor usar un tipo de referencia, como `PhantomData<&'a T>` (ideally) o `PhantomData<*const T>` (si no se aplica una vida útil), para no indicar la propiedad.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// trait interno del compilador utilizado para indicar el tipo de discriminantes de enumeración.
///
/// Este trait se implementa automáticamente para cada tipo y no agrega ninguna garantía a [`mem::Discriminant`].
/// Es **comportamiento indefinido** transmutar entre `DiscriminantKind::Discriminant` y `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// El tipo de discriminante, que debe satisfacer el trait bounds requerido por `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// trait interno del compilador utilizado para determinar si un tipo contiene algún `UnsafeCell` internamente, pero no a través de una indirección.
///
/// Esto afecta, por ejemplo, si un `static` de ese tipo se coloca en una memoria estática de solo lectura o en una memoria estática de escritura.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Tipos que se pueden mover de forma segura después de ser anclados.
///
/// El propio Rust no tiene noción de tipos inamovibles y considera que los movimientos (por ejemplo, mediante asignación o [`mem::replace`]) son siempre seguros.
///
/// En cambio, el tipo [`Pin`][Pin] se utiliza para evitar movimientos a través del sistema de tipos.Los punteros `P<T>` envueltos en el contenedor [`Pin<P<T>>`][Pin] no se pueden sacar.
/// Consulte la documentación de [`pin` module] para obtener más información sobre la fijación.
///
/// La implementación de `Unpin` trait para `T` elimina las restricciones de anclar el tipo, lo que luego permite mover `T` fuera de [`Pin<P<T>>`][Pin] con funciones como [`mem::replace`].
///
///
/// `Unpin` no tiene ninguna consecuencia para los datos no anclados.
/// En particular, [`mem::replace`] mueve felizmente datos `!Unpin` (funciona para cualquier `&mut T`, no solo cuando `T: Unpin`).
/// Sin embargo, no puede usar [`mem::replace`] en datos envueltos dentro de un [`Pin<P<T>>`][Pin] porque no puede obtener el `&mut T` que necesita para eso, y *eso* es lo que hace que este sistema funcione.
///
/// Entonces, esto, por ejemplo, solo se puede hacer en tipos que implementan `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Necesitamos una referencia mutable para llamar a `mem::replace`.
/// // Podemos obtener dicha referencia si (implicitly) invoca a `Pin::deref_mut`, pero eso solo es posible porque `String` implementa `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Este trait se implementa automáticamente para casi todos los tipos.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Un tipo de marcador que no implementa `Unpin`.
///
/// Si un tipo contiene un `PhantomPinned`, no implementará `Unpin` de forma predeterminada.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementaciones de `Copy` para tipos primitivos.
///
/// Las implementaciones que no se pueden describir en Rust se implementan en `traits::SelectionContext::copy_clone_conditions()` en `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Las referencias compartidas se pueden copiar, ¡pero las referencias mutables *no*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}