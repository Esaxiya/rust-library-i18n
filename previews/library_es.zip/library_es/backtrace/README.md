# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Una biblioteca para adquirir trazas inversas en tiempo de ejecución para Rust.
Esta biblioteca tiene como objetivo mejorar el soporte de la biblioteca estándar al proporcionar una interfaz programática para trabajar, pero también admite simplemente imprimir fácilmente el backtrace actual como panics de libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Para simplemente capturar un seguimiento y aplazar el tratamiento de él hasta un momento posterior, puede utilizar el tipo `Backtrace` de nivel superior.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Sin embargo, si desea más acceso sin formato a la funcionalidad de rastreo real, puede usar las funciones `trace` y `resolve` directamente.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Resuelva este puntero de instrucción a un nombre de símbolo
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // sigue yendo al siguiente cuadro
    });
}
```

# License

Este proyecto tiene licencia de cualquiera de

 * Licencia Apache, versión 2.0, ([LICENSE-APACHE](LICENSE-APACHE) o http://www.apache.org/licenses/LICENSE-2.0)
 * Licencia MIT ([LICENSE-MIT](LICENSE-MIT) o http://opensource.org/licenses/MIT)

a tu elección.

### Contribution

A menos que usted indique explícitamente lo contrario, cualquier contribución enviada intencionalmente para su inclusión en backtrace-rs por usted, según se define en la licencia Apache-2.0, tendrá doble licencia como se indica arriba, sin ningún término o condición adicional.







