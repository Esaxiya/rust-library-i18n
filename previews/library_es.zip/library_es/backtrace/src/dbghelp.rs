//! Un módulo para ayudar a administrar los enlaces dbghelp en Windows
//!
//! Los backtraces en Windows (al menos para MSVC) se alimentan en gran medida a través de `dbghelp.dll` y las diversas funciones que contiene.
//! Estas funciones se cargan actualmente *dinámicamente* en lugar de vincularse a `dbghelp.dll` estáticamente.
//! Actualmente, esto lo hace la biblioteca estándar (y en teoría se requiere allí), pero es un esfuerzo para ayudar a reducir las dependencias de dll estáticas de una biblioteca, ya que los backtraces suelen ser bastante opcionales.
//!
//! Dicho esto, `dbghelp.dll` casi siempre se carga con éxito en Windows.
//!
//! Sin embargo, tenga en cuenta que, dado que estamos cargando todo este soporte dinámicamente, en realidad no podemos usar las definiciones en bruto en `winapi`, sino que debemos definir los tipos de puntero de función nosotros mismos y usar eso.
//! Realmente no queremos estar en el negocio de duplicar winapi, por lo que tenemos una función `verify-winapi` de Cargo que afirma que todos los enlaces coinciden con los de winapi y esta función está habilitada en CI.
//!
//! Finalmente, observará aquí que el dll para `dbghelp.dll` nunca se descarga, y eso actualmente es intencional.
//! La idea es que podemos almacenarlo en caché global y usarlo entre llamadas a la API, evitando el costoso loads/unloads.
//! Si esto es un problema para los detectores de fugas o algo así, podemos cruzar el puente cuando lleguemos allí.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Evite que `SymGetOptions` y `SymSetOptions` no estén presentes en winapi.
// De lo contrario, esto solo se usa cuando estamos comprobando dos veces los tipos con winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Aún no definido en winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Esto está definido en winapi, pero es incorrecto (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Aún no definido en winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Esta macro se utiliza para definir una estructura `Dbghelp` que contiene internamente todos los punteros de función que podemos cargar.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// La DLL cargada para `dbghelp.dll`
            dll: HMODULE,

            // Cada puntero de función para cada función que podríamos usar
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Inicialmente no hemos cargado la DLL
            dll: 0 as *mut _,
            // Inicialmente, todas las funciones se establecen en cero para indicar que deben cargarse dinámicamente.
            //
            $($name: 0,)*
        };

        // Conveniencia typedef para cada tipo de función.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Intenta abrir `dbghelp.dll`.
            /// Devuelve éxito si funciona o error si `LoadLibraryW` falla.
            ///
            /// Panics si la biblioteca ya está cargada.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Función para cada método que nos gustaría usar.
            // Cuando se llame, leerá el puntero de la función en caché o lo cargará y devolverá el valor cargado.
            // Se afirma que las cargas tienen éxito.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Proxy de conveniencia para usar los bloqueos de limpieza para hacer referencia a las funciones de dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inicialice todo el soporte necesario para acceder a las funciones de la API `dbghelp` desde este crate.
///
///
/// Tenga en cuenta que esta función es **segura**, internamente tiene su propia sincronización.
/// También tenga en cuenta que es seguro llamar a esta función varias veces de forma recursiva.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Lo primero que debemos hacer es sincronizar esta función.Esto se puede llamar simultáneamente desde otros subprocesos o de forma recursiva dentro de un subproceso.
        // Sin embargo, tenga en cuenta que es más complicado que eso porque lo que estamos usando aquí, `dbghelp`,*también* debe sincronizarse con todas las demás personas que llaman a `dbghelp` en este proceso.
        //
        // Por lo general, no hay muchas llamadas a `dbghelp` dentro del mismo proceso y probablemente podamos asumir con seguridad que somos los únicos que acceden a él.
        // Hay, sin embargo, otro usuario principal del que tenemos que preocuparnos, que es irónicamente nosotros mismos, pero en la biblioteca estándar.
        // La biblioteca estándar Rust depende de este crate para soporte de backtrace, y este crate también existe en crates.io.
        // Esto significa que si la biblioteca estándar está imprimiendo un backtrace panic, puede competir con este crate proveniente de crates.io, lo que provoca segfaults.
        //
        // Para ayudar a resolver este problema de sincronización, empleamos aquí un truco específico de Windows (después de todo, es una restricción específica de Windows sobre la sincronización).
        // Creamos un *session-local* llamado mutex para proteger esta llamada.
        // La intención aquí es que la biblioteca estándar y este crate no tengan que compartir las API de nivel Rust para sincronizar aquí, sino que puedan trabajar detrás de escena para asegurarse de que se sincronizan entre sí.
        //
        // De esa forma, cuando se llama a esta función a través de la biblioteca estándar o mediante crates.io, podemos estar seguros de que se está adquiriendo el mismo mutex.
        //
        // Entonces, todo eso es para decir que lo primero que hacemos aquí es crear atómicamente un `HANDLE` que es un mutex con nombre en Windows.
        // Sincronizamos un poco con otros subprocesos que comparten esta función específicamente y nos aseguramos de que solo se cree un identificador por instancia de esta función.
        // Tenga en cuenta que el identificador nunca se cierra una vez que se almacena en el archivo global.
        //
        // Una vez que hayamos cerrado el candado, simplemente lo adquirimos, y nuestro mango `Init` que entregamos será responsable de soltarlo eventualmente.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, ¡uf!Ahora que estamos todos sincronizados de forma segura, comencemos a procesar todo.
        // Primero, debemos asegurarnos de que `dbghelp.dll` esté realmente cargado en este proceso.
        // Hacemos esto de forma dinámica para evitar una dependencia estática.
        // Históricamente, esto se ha hecho para solucionar problemas extraños de enlaces y tiene la intención de hacer que los binarios sean un poco más portátiles, ya que se trata en gran medida de una utilidad de depuración.
        //
        //
        // Una vez que hemos abierto `dbghelp.dll`, necesitamos llamar a algunas funciones de inicialización en él, y eso se detalla más a continuación.
        // Sin embargo, solo hacemos esto una vez, por lo que tenemos un booleano global que indica si hemos terminado o no.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Asegúrese de que la bandera `SYMOPT_DEFERRED_LOADS` esté configurada, porque de acuerdo con los propios documentos de MSVC sobre esto: "This is the fastest, most efficient way to use the symbol handler.", ¡hagámoslo!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Realmente inicialice símbolos con MSVC.Tenga en cuenta que esto puede fallar, pero lo ignoramos.
        // No hay una tonelada de técnica anterior para esto per se, pero LLVM internamente parece ignorar el valor de retorno aquí y una de las bibliotecas de desinfección en LLVM imprime una advertencia aterradora si esto falla, pero básicamente lo ignora a largo plazo.
        //
        //
        // Un caso que surge mucho para Rust es que la biblioteca estándar y este crate en crates.io quieren competir por `SymInitializeW`.
        // Históricamente, la biblioteca estándar quería inicializar y luego limpiar la mayor parte del tiempo, pero ahora que está usando este crate, significa que alguien comenzará la inicialización primero y el otro recogerá esa inicialización.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}