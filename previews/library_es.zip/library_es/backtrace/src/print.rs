#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Un formateador para backtraces.
///
/// Este tipo se puede utilizar para imprimir una traza inversa independientemente de dónde provenga la traza inversa.
/// Si tiene un tipo `Backtrace`, su implementación `Debug` ya usa este formato de impresión.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Los estilos de impresión que podemos imprimir
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Imprime un trazo posterior más terso que idealmente solo contiene información relevante
    Short,
    /// Imprime un rastreo que contiene toda la información posible.
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Cree un nuevo `BacktraceFmt` que escribirá la salida en el `fmt` proporcionado.
    ///
    /// El argumento `format` controlará el estilo en el que se imprime el backtrace, y el argumento `print_path` se utilizará para imprimir las instancias `BytesOrWideString` de los nombres de archivo.
    /// Este tipo en sí no imprime ningún nombre de archivo, pero esta devolución de llamada es necesaria para hacerlo.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Imprime un preámbulo para la traza inversa a punto de imprimirse.
    ///
    /// Esto es necesario en algunas plataformas para que los backtraces se simbolicen completamente más adelante y, de lo contrario, este debería ser el primer método al que llame después de crear un `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Agrega un fotograma a la salida de retroceso.
    ///
    /// Esta confirmación devuelve una instancia RAII de un `BacktraceFrameFmt` que se puede utilizar para imprimir un fotograma y, al destruirlo, aumentará el contador de fotogramas.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Completa la salida de seguimiento.
    ///
    /// Actualmente, esto no es operativo, pero se agrega para la compatibilidad de future con formatos de backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Actualmente sin operación, incluido este hook para permitir adiciones de future.
        Ok(())
    }
}

/// Un formateador para un solo fotograma de un trazo inverso.
///
/// Este tipo es creado por la función `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Imprime una `BacktraceFrame` con este formateador de fotogramas.
    ///
    /// Esto imprimirá de forma recursiva todas las instancias `BacktraceSymbol` dentro del `BacktraceFrame`.
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Imprime una `BacktraceSymbol` dentro de una `BacktraceFrame`.
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: no es genial que no terminemos imprimiendo nada
            // con nombres de archivo que no son utf8.
            // Afortunadamente, casi todo es utf8, por lo que esto no debería ser tan malo.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Imprime un `Frame` y `Symbol` sin procesar, normalmente desde dentro de las devoluciones de llamada sin procesar de este crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Agrega un fotograma sin procesar a la salida de seguimiento.
    ///
    /// Este método, a diferencia del anterior, toma los argumentos sin procesar en caso de que provengan de diferentes ubicaciones.
    /// Tenga en cuenta que esto se puede llamar varias veces para una trama.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Agrega un fotograma sin procesar a la salida de seguimiento, incluida la información de la columna.
    ///
    /// Este método, como el anterior, toma los argumentos sin procesar en caso de que provengan de diferentes ubicaciones.
    /// Tenga en cuenta que esto se puede llamar varias veces para una trama.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia no puede simbolizar dentro de un proceso, por lo que tiene un formato especial que se puede usar para simbolizar más tarde.
        // Imprima eso en lugar de imprimir direcciones en nuestro propio formato aquí.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // No es necesario imprimir fotogramas "null", básicamente solo significa que el rastreo del sistema estaba un poco ansioso por rastrear muy lejos.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Para reducir el tamaño de TCB en el enclave Sgx, no queremos implementar la funcionalidad de resolución de símbolos.
        // Más bien, podemos imprimir el desplazamiento de la dirección aquí, que luego podría mapearse para corregir la función.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Imprima el índice del marco así como el puntero de instrucción opcional del marco.
        // Si estamos más allá del primer símbolo de este marco, imprimimos los espacios en blanco apropiados.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // A continuación, escriba el nombre del símbolo, utilizando el formato alternativo para obtener más información si somos un rastreo completo.
        // Aquí también manejamos símbolos que no tienen nombre,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Y por último, imprima el número filename/line si están disponibles.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line están impresos en líneas debajo del nombre del símbolo, así que imprima un espacio en blanco apropiado para alinearnos a la derecha.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegue a nuestra devolución de llamada interna para imprimir el nombre del archivo y luego imprima el número de línea.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Agregue el número de columna, si está disponible.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Solo nos importa el primer símbolo de un marco
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}