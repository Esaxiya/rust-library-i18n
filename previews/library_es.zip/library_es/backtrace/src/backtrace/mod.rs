use core::ffi::c_void;
use core::fmt;

/// Inspecciona la pila de llamadas actual, pasando todos los fotogramas activos al cierre proporcionado para calcular un seguimiento de la pila.
///
/// Esta función es el caballo de batalla de esta biblioteca para calcular los seguimientos de pila de un programa.El cierre `cb` dado son instancias de `Frame` que representan información sobre ese marco de llamada en la pila.
/// El cierre se produce en los marcos de forma descendente (más recientemente llamadas funciones primero).
///
/// El valor de retorno del cierre es una indicación de si el rastreo debe continuar.Un valor de retorno de `false` terminará el rastreo y regresará inmediatamente.
///
/// Una vez que se adquiere un `Frame`, es probable que desee llamar a `backtrace::resolve` para convertir el `ip` (puntero de instrucción) o la dirección del símbolo en un `Symbol` a través del cual se puede aprender el nombre y/o el nombre de archivo/número de línea.
///
///
/// Tenga en cuenta que esta es una función de nivel relativamente bajo y si desea, por ejemplo, capturar un rastreo para ser inspeccionado más tarde, entonces el tipo `Backtrace` puede ser más apropiado.
///
/// # Caracteristicas requeridas
///
/// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
///
/// # Panics
///
/// Esta función se esfuerza por nunca panic, pero si el `cb` proporcionó panics, algunas plataformas forzarán a un panic doble a abortar el proceso.
/// Algunas plataformas usan una biblioteca C que internamente usa devoluciones de llamada que no se pueden deshacer, por lo que entrar en pánico con `cb` puede desencadenar la interrupción del proceso.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // Continuar el retroceso
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Igual que `trace`, solo que no es seguro porque no está sincronizado.
///
/// Esta función no tiene garantías de sincronización, pero está disponible cuando la función `std` de este crate no está compilada.
/// Consulte la función `trace` para obtener más documentación y ejemplos.
///
/// # Panics
///
/// Consulte la información sobre `trace` para conocer las advertencias sobre el pánico de `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Un trait que representa un fotograma de un backtrace, cedido a la función `trace` de este crate.
///
/// El cierre de la función de seguimiento se generarán marcos, y el marco se distribuye virtualmente ya que la implementación subyacente no siempre se conoce hasta el tiempo de ejecución.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Devuelve el puntero de instrucción actual de este marco.
    ///
    /// Esta es normalmente la siguiente instrucción a ejecutar en el marco, pero no todas las implementaciones lo enumeran con un 100% de precisión (pero generalmente es bastante parecido).
    ///
    ///
    /// Se recomienda pasar este valor a `backtrace::resolve` para convertirlo en un nombre de símbolo.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Devuelve el puntero de pila actual de este marco.
    ///
    /// En el caso de que un backend no pueda recuperar el puntero de pila para este marco, se devuelve un puntero nulo.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Devuelve la dirección del símbolo inicial del marco de esta función.
    ///
    /// Esto intentará rebobinar el puntero de instrucción devuelto por `ip` al inicio de la función, devolviendo ese valor.
    ///
    /// En algunos casos, sin embargo, los backends solo devolverán `ip` desde esta función.
    ///
    /// El valor devuelto a veces se puede utilizar si `backtrace::resolve` falló en el `ip` indicado anteriormente.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Devuelve la dirección base del módulo al que pertenece el marco.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Esto debe ser lo primero, para garantizar que Miri tenga prioridad sobre la plataforma de host.
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // solo se usa en dbghelp simbolizar
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}