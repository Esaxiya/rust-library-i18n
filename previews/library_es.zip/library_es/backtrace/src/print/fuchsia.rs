use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr recibe una devolución de llamada que recibirá un puntero dl_phdr_info por cada DSO que se haya vinculado al proceso.
    // dl_iterate_phdr también asegura que el enlazador dinámico esté bloqueado de principio a fin de la iteración.
    // Si la devolución de llamada devuelve un valor distinto de cero, la iteración finaliza antes de tiempo.
    // 'data' se pasará como tercer argumento a la devolución de llamada en cada llamada.
    // 'size' da el tamaño de dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Necesitamos analizar el ID de compilación y algunos datos básicos del encabezado del programa, lo que significa que también necesitamos algunas cosas de la especificación ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Ahora tenemos que replicar, bit a bit, la estructura del tipo dl_phdr_info utilizada por el enlazador dinámico actual de fuchsia.
// Chromium también tiene este límite ABI, así como un crashpad.
// Eventualmente, nos gustaría mover estos casos para usar elf-search, pero tendríamos que proporcionar eso en el SDK y eso aún no se ha hecho.
//
// Por lo tanto, nosotros (y ellos) estamos atascados en tener que usar este método que incurre en un acoplamiento estrecho con la libc fucsia.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // No tenemos forma de saber cómo comprobar si e_phoff y e_phnum son válidos.
    // Sin embargo, libc debería asegurarnos esto, por lo que es seguro formar una porción aquí.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr representa un encabezado de programa ELF de 64 bits en el endianness de la arquitectura de destino.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr representa un encabezado de programa ELF válido y su contenido.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // No tenemos forma de comprobar si p_addr o p_memsz son válidos.
    // Sin embargo, la libc de Fuchsia analiza las notas primero, por lo que, en virtud de estar aquí, estos encabezados deben ser válidos.
    //
    // NoteIter no requiere que los datos subyacentes sean válidos, pero sí requiere que los límites sean válidos.
    // Confiamos en que libc se haya asegurado de que este sea nuestro caso aquí.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// El tipo de nota para los ID de compilación.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr representa un encabezado de nota ELF en el endianness del objetivo.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Nota representa una nota ELF (encabezado + contenido).
// El nombre se deja como un segmento u8 porque no siempre tiene una terminación nula y rust facilita la verificación de que los bytes coinciden de cualquier manera.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter le permite iterar de forma segura sobre un segmento de nota.
// Termina tan pronto como ocurre un error o no hay más notas.
// Si itera sobre datos no válidos, funcionará como si no se encontraran notas.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Es un invariante de función que el puntero y el tamaño dados denotan un rango válido de bytes que pueden leerse todos.
    // El contenido de estos bytes puede ser cualquier cosa, pero el rango debe ser válido para que esto sea seguro.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to alinea 'x' con la alineación de bytes 'to' suponiendo que 'to' es una potencia de 2.
// Esto sigue un patrón estándar en el código de análisis C/C ++ ELF donde se usa (x + to, 1)&-to.
// Rust no te permite negar usize, así que uso
// Conversión de complemento a 2 para recrear eso.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 consume num bytes del segmento (si está presente) y además asegura que el segmento final esté alineado correctamente.
// Si el número de bytes solicitados es demasiado grande o el segmento no se puede realinear posteriormente debido a que no existen suficientes bytes restantes, se devuelve Ninguno y el segmento no se modifica.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Esta función no tiene invariantes reales que la persona que llama deba mantener, excepto quizás que 'bytes' debería estar alineado para el rendimiento (y en algunas arquitecturas, la corrección).
// Los valores en los campos Elf_Nhdr pueden ser una tontería, pero esta función no garantiza tal cosa.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Esto es seguro siempre que haya suficiente espacio y acabamos de confirmarlo en la declaración if anterior, por lo que esto no debería ser inseguro.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Tenga en cuenta que sice_of: :<Elf_Nhdr>() siempre está alineado con 4 bytes.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Comprueba si hemos llegado al final.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Transmutamos un nhdr pero consideramos cuidadosamente la estructura resultante.
        // No confiamos en los nombresz o descsz y no tomamos decisiones inseguras basadas en el tipo.
        //
        // Entonces, incluso si sacamos la basura completa, aún deberíamos estar a salvo.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Indica que un segmento es ejecutable.
const PERM_X: u32 = 0b00000001;
/// Indica que se puede escribir en un segmento.
const PERM_W: u32 = 0b00000010;
/// Indica que un segmento es legible.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Representa un segmento ELF en tiempo de ejecución.
struct Segment {
    /// Da la dirección virtual en tiempo de ejecución del contenido de este segmento.
    addr: usize,
    /// Da el tamaño de memoria del contenido de este segmento.
    size: usize,
    /// Da al módulo la dirección virtual de este segmento con el archivo ELF.
    mod_rel_addr: usize,
    /// Otorga los permisos que se encuentran en el archivo ELF.
    /// Sin embargo, estos permisos no son necesariamente los permisos presentes en tiempo de ejecución.
    flags: Perm,
}

/// Permite iterar sobre segmentos de un DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Representa un ELF DSO (objeto compartido dinámico).
/// Este tipo hace referencia a los datos almacenados en el DSO real en lugar de hacer su propia copia.
struct Dso<'a> {
    /// El enlazador dinámico siempre nos da un nombre, incluso si el nombre está vacío.
    /// En el caso del ejecutable principal, este nombre estará vacío.
    /// En el caso de un objeto compartido será el soname (ver DT_SONAME).
    name: &'a str,
    /// En Fuchsia, prácticamente todos los binarios tienen ID de compilación, pero este no es un requisito estricto.
    /// No hay forma de hacer coincidir la información de DSO con un archivo ELF real después si no hay build_id, por lo que requerimos que cada DSO tenga uno aquí.
    ///
    /// Los DSO sin build_id se ignoran.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Devuelve un iterador sobre segmentos en este DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Estos errores codifican problemas que surgen al analizar información sobre cada DSO.
///
enum Error {
    /// NameError significa que se produjo un error al convertir una cadena de estilo C en una cadena rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError significa que no encontramos un ID de compilación.
    /// Esto podría deberse a que el DSO no tenía un ID de compilación o porque el segmento que contenía el ID de compilación tenía un formato incorrecto.
    ///
    BuildIDError,
}

/// Llama a 'dso' o 'error' para cada DSO vinculado al proceso por el vinculador dinámico.
///
///
/// # Arguments
///
/// * `visitor` - Una DsoPrinter que tendrá uno de los métodos eats llamado foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr asegura que info.name apuntará a una ubicación válida.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Esta función imprime el marcado del simbolizador Fuchsia para toda la información contenida en un DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}