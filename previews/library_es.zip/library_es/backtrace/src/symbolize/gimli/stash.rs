// solo se usa en Linux en este momento, así que permita el código muerto en otros lugares
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Un asignador de arena simple para búferes de bytes.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Asigna un búfer del tamaño especificado y devuelve una referencia mutable.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SEGURIDAD: esta es la única función que alguna vez construye un mutable
        // referencia a `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SEGURIDAD: nunca eliminamos elementos de `self.buffers`, por lo que una referencia
        // a los datos dentro de cualquier búfer vivirá tanto tiempo como `self`.
        &mut buffers[i]
    }
}