//! Soporte para simbolización usando el `gimli` crate en crates.io
//!
//! Esta es la implementación de simbolización predeterminada para Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'La vida estática es una mentira para esquivar la falta de soporte para estructuras autorreferenciales.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Convierta a 'vidas útiles estáticas, ya que los símbolos solo deben tomar prestados `map` y `stash` y los conservaremos a continuación.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Para cargar bibliotecas nativas en Windows, consulte algunas discusiones sobre rust-lang/rust#71060 para conocer las diversas estrategias aquí.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Las bibliotecas MinGW actualmente no son compatibles con ASLR (rust-lang/rust#16514), pero las DLL aún se pueden reubicar en el espacio de direcciones.
            // Parece que las direcciones en la información de depuración son todas como si esta biblioteca se hubiera cargado en su "image base", que es un campo en los encabezados de sus archivos COFF.
            // Dado que esto es lo que debuginfo parece enumerar, analizamos la tabla de símbolos y almacenamos las direcciones como si la biblioteca también estuviera cargada en "image base".
            //
            // Sin embargo, es posible que la biblioteca no se cargue en "image base".
            // (¿presumiblemente se puede cargar algo más allí?) Aquí es donde entra en juego el campo `bias`, y necesitamos averiguar el valor de `bias` aquí.Desafortunadamente, no está claro cómo adquirir esto de un módulo cargado.
            // Lo que sí tenemos, sin embargo, es la dirección de carga real (`modBaseAddr`).
            //
            // Como una pequeña excusa por ahora, mapeamos el archivo, leemos la información del encabezado del archivo y luego soltamos el mmap.Esto es un desperdicio porque probablemente volveremos a abrir el mmap más adelante, pero esto debería funcionar lo suficientemente bien por ahora.
            //
            // Una vez que tenemos el `image_base` (ubicación de carga deseada) y el `base_addr` (ubicación de carga real) podemos completar el `bias` (diferencia entre el real y el deseado) y luego la dirección indicada de cada segmento es el `image_base` ya que eso es lo que dice el archivo.
            //
            //
            // Por ahora parece que, a diferencia de ELF/MachO, podemos conformarnos con un segmento por biblioteca, usando `modBaseSize` como el tamaño completo.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS usa el formato de archivo Mach-O y usa API específicas de DYLD para cargar una lista de bibliotecas nativas que son parte de la aplicación.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Busque el nombre de esta biblioteca que corresponde a la ruta de donde cargarla también.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Cargue el encabezado de la imagen de esta biblioteca y delegue a `object` para analizar todos los comandos de carga para que podamos averiguar todos los segmentos involucrados aquí.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Itere sobre los segmentos y registre regiones conocidas para los segmentos que encontremos.
            // Además, registre información sobre segmentos de texto para procesarlos más tarde, consulte los comentarios a continuación.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Determine el "slide" para esta biblioteca, que termina siendo el sesgo que usamos para averiguar dónde se cargan los objetos en la memoria.
            // Sin embargo, este es un cálculo un poco extraño y es el resultado de probar algunas cosas en la naturaleza y ver qué se pega.
            //
            // La idea general es que el `bias` más el `stated_virtual_memory_address` de un segmento va a estar en el lugar del espacio de direcciones real donde reside el segmento.
            // Sin embargo, la otra cosa en la que confiamos es que una dirección real menos el `bias` es el índice para buscar en la tabla de símbolos y debuginfo.
            //
            // Sin embargo, resulta que para las bibliotecas cargadas por el sistema estos cálculos son incorrectos.Para los ejecutables nativos, sin embargo, parece correcto.
            // Al extraer algo de lógica de la fuente de LLDB, tiene una carcasa especial para la primera sección `__TEXT` cargada desde el desplazamiento de archivo 0 con un tamaño distinto de cero.
            // Por alguna razón, cuando esto está presente, parece significar que la tabla de símbolos es relativa solo a la diapositiva vmaddr de la biblioteca.
            // Si *no* está presente, entonces la tabla de símbolos es relativa a la diapositiva vmaddr más la dirección indicada del segmento.
            //
            // Para manejar esta situación, si *no* encontramos una sección de texto en el archivo offset cero, entonces aumentamos el sesgo por la dirección indicada de la primera sección de texto y disminuimos todas las direcciones indicadas en esa cantidad también.
            //
            // De esa manera, la tabla de símbolos siempre aparece en relación con la cantidad de sesgo de la biblioteca.
            // Esto parece tener los resultados correctos para simbolizar a través de la tabla de símbolos.
            //
            // Honestamente, no estoy del todo seguro de si esto es correcto o si hay algo más que debería indicar cómo hacer esto.
            // Por ahora, aunque esto parece funcionar lo suficientemente bien (?) y siempre deberíamos poder modificar esto con el tiempo si es necesario.
            //
            // Para obtener más información, consulte #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Otro Unix (p. Ej.
        // Linux) utilizan ELF como formato de archivo de objeto y normalmente implementan una API llamada `dl_iterate_phdr` para cargar bibliotecas nativas.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` debe ser un puntero válido.
        // `vec` debe ser un puntero válido a un `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 no admite de forma nativa la información de depuración, pero el sistema de compilación colocará la información de depuración en la ruta `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Todo lo demás debería usar ELF, pero no sabe cómo cargar bibliotecas nativas.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Todas las bibliotecas compartidas conocidas que se han cargado.
    libraries: Vec<Library>,

    /// Caché de asignaciones donde retenemos información enana analizada.
    ///
    /// Esta lista tiene una capacidad fija para todo su tiempo de vida que nunca aumenta.
    /// El elemento `usize` de cada par es un índice en `libraries` arriba, donde `usize::max_value()` representa el ejecutable actual.
    ///
    /// El `Mapping` es la información enana analizada correspondiente.
    ///
    /// Tenga en cuenta que esto es básicamente un caché LRU y cambiaremos las cosas aquí mientras simbolizamos direcciones.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Los segmentos de esta biblioteca se cargan en la memoria y dónde se cargan.
    segments: Vec<LibrarySegment>,
    /// El "bias" de esta biblioteca, normalmente donde se carga en la memoria.
    /// Este valor se agrega a la dirección indicada de cada segmento para obtener la dirección de memoria virtual real en la que se carga el segmento.
    /// Además, este sesgo se resta de las direcciones de memoria virtual reales para indexar en debuginfo y en la tabla de símbolos.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// La dirección indicada de este segmento en el archivo de objeto.
    /// Aquí no es realmente donde se carga el segmento, sino más bien esta dirección más el `bias` de la biblioteca que lo contiene es donde encontrarlo.
    ///
    stated_virtual_memory_address: usize,
    /// El tamaño de este segmento en la memoria.
    len: usize,
}

// inseguro porque es necesario sincronizarlo externamente
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // inseguro porque es necesario sincronizarlo externamente
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Una caché LRU muy pequeña y muy simple para las asignaciones de información de depuración.
        //
        // La tasa de aciertos debe ser muy alta, ya que la pila típica no se cruza entre muchas bibliotecas compartidas.
        //
        // Las estructuras `addr2line::Context` son bastante caras de crear.
        // Se espera que su costo sea amortizado por consultas `locate` posteriores, que aprovechan las estructuras construidas al construir `addr2line: : Context`s para obtener buenas aceleraciones.
        //
        // Si no tuviéramos este caché, esa amortización nunca sucedería, y los rastros de retroceso simbólicos serían ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Primero, pruebe si este `lib` tiene algún segmento que contenga el `addr` (manejo de reubicación).Si esta verificación pasa, podemos continuar a continuación y traducir la dirección.
                //
                // Tenga en cuenta que estamos usando `wrapping_add` aquí para evitar verificaciones de desbordamiento.Se ha visto en la naturaleza que el cálculo de sesgo de SVMA + se desborda.
                // Parece un poco extraño que suceda, pero no hay mucho que podamos hacer al respecto, aparte de probablemente simplemente ignorar esos segmentos, ya que es probable que estén apuntando al espacio.
                //
                // Esto surgió originalmente en rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Ahora que sabemos que `lib` contiene `addr`, podemos compensar el sesgo para encontrar la dirección de memoria virutal indicada.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariante: después de que este condicional se complete sin retorno anticipado
        // de un error, la entrada de caché para esta ruta está en el índice 0.

        if let Some(idx) = idx {
            // Cuando la asignación ya esté en la caché, muévala al frente.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Cuando la asignación no esté en la caché, cree una nueva asignación, insértela en la parte frontal de la caché y desaloje la entrada de caché más antigua si es necesario.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // no pierda la vida útil del `'static`, asegúrese de que esté dirigido solo a nosotros
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Extienda la vida útil de `sym` a `'static` ya que desafortunadamente estamos obligados a hacerlo aquí, pero solo se publicará como referencia, por lo que ninguna referencia debe persistir más allá de este marco de todos modos.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Finalmente, obtenga una asignación en caché o cree una nueva asignación para este archivo y evalúe la información DWARF para encontrar el file/line/name para esta dirección.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Pudimos ubicar la información del marco para este símbolo, y el marco de `addr2line` tiene internamente todos los detalles esenciales.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// No se pudo encontrar la información de depuración, pero la encontramos en la tabla de símbolos del ejecutable elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}