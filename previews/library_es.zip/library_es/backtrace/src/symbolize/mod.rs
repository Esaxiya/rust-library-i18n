use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Resuelve una dirección a un símbolo, pasando el símbolo al cierre especificado.
///
/// Esta función buscará la dirección dada en áreas como la tabla de símbolos local, la tabla de símbolos dinámicos o la información de depuración de DWARF (dependiendo de la implementación activada) para encontrar símbolos para ceder.
///
///
/// El cierre no se puede llamar si no se pudo realizar la resolución, y también se puede llamar más de una vez en el caso de funciones en línea.
///
/// Los símbolos producidos representan la ejecución en el `addr` especificado, devolviendo pares file/line para esa dirección (si está disponible).
///
/// Tenga en cuenta que si tiene un `Frame`, se recomienda utilizar la función `resolve_frame` en lugar de esta.
///
/// # Caracteristicas requeridas
///
/// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
///
/// # Panics
///
/// Esta función se esfuerza por nunca panic, pero si el `cb` proporcionó panics, algunas plataformas forzarán a un panic doble a abortar el proceso.
/// Algunas plataformas usan una biblioteca C que internamente usa devoluciones de llamada que no se pueden deshacer, por lo que entrar en pánico con `cb` puede desencadenar la interrupción del proceso.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // solo mira el marco superior
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Resuelve un fotograma de captura anterior a un símbolo, pasando el símbolo al cierre especificado.
///
/// Esta función realiza la misma función que `resolve` excepto que toma un `Frame` como argumento en lugar de una dirección.
/// Esto puede permitir que algunas implementaciones de plataforma de retroceso proporcionen información de símbolos más precisa o información sobre marcos en línea, por ejemplo.
///
/// Se recomienda usar esto si puede.
///
/// # Caracteristicas requeridas
///
/// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
///
/// # Panics
///
/// Esta función se esfuerza por nunca panic, pero si el `cb` proporcionó panics, algunas plataformas forzarán a un panic doble a abortar el proceso.
/// Algunas plataformas usan una biblioteca C que internamente usa devoluciones de llamada que no se pueden deshacer, por lo que entrar en pánico con `cb` puede desencadenar la interrupción del proceso.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // solo mira el marco superior
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Los valores de IP de los marcos de pila suelen ser (always?) la instrucción *después* de la llamada que es el seguimiento de pila real.
// Simbolizar esto hace que el número filename/line esté uno por delante y quizás en el vacío si está cerca del final de la función.
//
// Esto parece ser básicamente siempre el caso en todas las plataformas, por lo que siempre restamos una de una ip resuelta para resolverla en la instrucción de llamada anterior en lugar de volver a la instrucción.
//
//
// Idealmente, no haríamos esto.
// Idealmente, requeriríamos que las personas que llaman a las API `resolve` aquí realicen manualmente el -1 y tengan en cuenta que desean información de ubicación para la instrucción *anterior*, no la actual.
// Idealmente, también expondríamos en `Frame` si realmente somos la dirección de la siguiente instrucción o la actual.
//
// Por ahora, aunque esta es una preocupación bastante especializada, por lo que internamente siempre restamos una.
// Los consumidores deberían seguir trabajando y obteniendo muy buenos resultados, por lo que deberíamos ser lo suficientemente buenos.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Igual que `resolve`, solo que no es seguro porque no está sincronizado.
///
/// Esta función no tiene garantías de sincronización, pero está disponible cuando la función `std` de este crate no está compilada.
/// Consulte la función `resolve` para obtener más documentación y ejemplos.
///
/// # Panics
///
/// Consulte la información sobre `resolve` para conocer las advertencias sobre el pánico de `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Igual que `resolve_frame`, solo que no es seguro porque no está sincronizado.
///
/// Esta función no tiene garantías de sincronización, pero está disponible cuando la función `std` de este crate no está compilada.
/// Consulte la función `resolve_frame` para obtener más documentación y ejemplos.
///
/// # Panics
///
/// Consulte la información sobre `resolve_frame` para conocer las advertencias sobre el pánico de `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Un trait que representa la resolución de un símbolo en un archivo.
///
/// Este trait se cede como un objeto trait al cierre dado a la función `backtrace::resolve`, y se envía virtualmente ya que se desconoce qué implementación está detrás de él.
///
///
/// Un símbolo puede proporcionar información contextual sobre una función, por ejemplo, el nombre, el nombre del archivo, el número de línea, la dirección precisa, etc.
/// Sin embargo, no toda la información está siempre disponible en un símbolo, por lo que todos los métodos devuelven un `Option`.
///
///
pub struct Symbol {
    // TODO: este límite de por vida debe persistir eventualmente hasta `Symbol`,
    // pero eso es actualmente un cambio radical.
    // Por ahora, esto es seguro, ya que `Symbol` solo se entrega por referencia y no se puede clonar.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Devuelve el nombre de esta función.
    ///
    /// La estructura devuelta se puede utilizar para consultar varias propiedades sobre el nombre del símbolo:
    ///
    ///
    /// * La implementación de `Display` imprimirá el símbolo desactivado.
    /// * Se puede acceder al valor `str` sin procesar del símbolo (si es utf-8 válido).
    /// * Se puede acceder a los bytes sin procesar del nombre del símbolo.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Devuelve la dirección inicial de esta función.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Devuelve el nombre del archivo sin procesar como un segmento.
    /// Esto es principalmente útil para entornos `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Devuelve el número de columna donde se está ejecutando este símbolo.
    ///
    /// Solo gimli proporciona actualmente un valor aquí e incluso entonces solo si `filename` devuelve `Some`, por lo que, en consecuencia, está sujeto a advertencias similares.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Devuelve el número de línea donde se está ejecutando este símbolo.
    ///
    /// Este valor de retorno suele ser `Some` si `filename` devuelve `Some` y, en consecuencia, está sujeto a advertencias similares.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Devuelve el nombre del archivo donde se definió esta función.
    ///
    /// Esto solo está disponible actualmente cuando se utiliza libbacktrace o gimli (p. Ej.
    /// unix otras plataformas) y cuando se compila un binario con debuginfo.
    /// Si no se cumple ninguna de estas condiciones, es probable que devuelva `None`.
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Tal vez un símbolo C++ analizado, si falla el análisis del símbolo destrozado como Rust.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Asegúrese de mantener este tamaño cero, para que la función `cpp_demangle` no tenga costo cuando esté desactivada.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Un envoltorio alrededor de un nombre de símbolo para proporcionar accesos ergonómicos al nombre demandado, los bytes sin procesar, la cadena sin procesar, etc.
///
// Permitir código muerto para cuando la función `cpp_demangle` no esté habilitada.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Crea un nuevo nombre de símbolo a partir de los bytes subyacentes sin procesar.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Devuelve el nombre del símbolo (mangled) sin formato como `str` si el símbolo es utf-8 válido.
    ///
    /// Utilice la implementación `Display` si desea la versión demandada.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Devuelve el nombre del símbolo sin formato como una lista de bytes.
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Esto puede imprimirse si el símbolo demandado no es realmente válido, así que maneje el error aquí con elegancia no propagándolo hacia afuera.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Intente recuperar la memoria caché utilizada para simbolizar direcciones.
///
/// Este método intentará liberar cualquier estructura de datos global que de otra manera se haya almacenado en caché globalmente o en el hilo que típicamente representa información DWARF analizada o similar.
///
///
/// # Caveats
///
/// Si bien esta función siempre está disponible, en realidad no hace nada en la mayoría de las implementaciones.
/// Las bibliotecas como dbghelp o libbacktrace no proporcionan facilidades para desasignar el estado y administrar la memoria asignada.
/// Por ahora, la característica `gimli-symbolize` de este crate es la única característica en la que esta función tiene algún efecto.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}