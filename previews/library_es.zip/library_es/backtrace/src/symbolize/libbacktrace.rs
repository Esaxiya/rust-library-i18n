//! Estrategia de simbolización utilizando el código de análisis DWARF en libbacktrace.
//!
//! La biblioteca libbacktrace C, normalmente distribuida con gcc, admite no solo generar un backtrace (que en realidad no usamos) sino también simbolizar el backtrace y manejar información de depuración enana sobre cosas como marcos en línea y otras cosas.
//!
//!
//! Esto es relativamente complicado debido a muchas preocupaciones aquí, pero la idea básica es:
//!
//! * Primero llamamos `backtrace_syminfo`.Esto obtiene información de símbolos de la tabla de símbolos dinámicos si podemos.
//! * A continuación, llamamos `backtrace_pcinfo`.Esto analizará las tablas debuginfo si están disponibles y nos permitirá recuperar información sobre marcos en línea, nombres de archivos, números de línea, etc.
//!
//! Hay muchos trucos para convertir las tablas enanas en libbacktrace, pero con suerte no es el fin del mundo y es lo suficientemente claro cuando se lee a continuación.
//!
//! Esta es la estrategia de simbolización predeterminada para plataformas que no son MSVC ni OSX.En libstd, sin embargo, esta es la estrategia predeterminada para OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Si es posible, prefiera el nombre `function` que proviene de debuginfo y, por lo general, puede ser más preciso para marcos en línea, por ejemplo.
                // Si eso no está presente, recurra al nombre de la tabla de símbolos especificado en `symname`.
                //
                // Tenga en cuenta que a veces `function` puede parecer algo menos preciso, por ejemplo, aparecer como `try<i32,closure>` en lugar de `std::panicking::try::do_call`.
                //
                // No está muy claro por qué, pero en general, el nombre `function` parece más preciso.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // no hagas nada por ahora
}

/// Tipo de puntero `data` pasado a `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Una vez que se invoca esta devolución de llamada desde `backtrace_syminfo` cuando comenzamos a resolver, vamos más allá para llamar a `backtrace_pcinfo`.
    // La función `backtrace_pcinfo` consultará la información de depuración e intentará hacer cosas como recuperar la información file/line y los marcos en línea.
    // Sin embargo, tenga en cuenta que `backtrace_pcinfo` puede fallar o no hacer mucho si no hay información de depuración, por lo que si eso sucede, estamos seguros de llamar a la devolución de llamada con al menos un símbolo del `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Tipo de puntero `data` pasado a `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// La API libbacktrace admite la creación de un estado, pero no admite la destrucción de un estado.
// Personalmente, entiendo que esto significa que un estado debe crearse y luego vivir para siempre.
//
// Me encantaría registrar un controlador at_exit() que limpie este estado, pero libbacktrace no proporciona ninguna forma de hacerlo.
//
// Con estas restricciones, esta función tiene un estado en caché estáticamente que se calcula la primera vez que se solicita.
//
// Recuerde que el retroceso todo ocurre en serie (un bloqueo global).
//
// Tenga en cuenta que la falta de sincronización aquí se debe al requisito de que `resolve` esté sincronizado externamente.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // No ejerza las capacidades seguras para subprocesos de libbacktrace, ya que siempre lo llamamos de forma sincronizada.
        //
        0,
        error_cb,
        ptr::null_mut(), // sin datos extra
    );

    return STATE;

    // Tenga en cuenta que para que libbacktrace funcione, debe encontrar la información de depuración DWARF para el ejecutable actual.Por lo general, lo hace a través de una serie de mecanismos que incluyen, entre otros:
    //
    // * /proc/self/exe en plataformas compatibles
    // * El nombre del archivo se pasó explícitamente al crear el estado.
    //
    // La biblioteca libbacktrace es un gran fajo de código C.Esto naturalmente significa que tiene vulnerabilidades de seguridad en la memoria, especialmente cuando se maneja debuginfo mal formada.
    // Libstd se ha encontrado con muchos de estos históricamente.
    //
    // Si se usa /proc/self/exe, normalmente podemos ignorarlos, ya que asumimos que libbacktrace es "mostly correct" y, de lo contrario, no hace cosas raras con la información de depuración enana de "attempted to be correct".
    //
    //
    // Sin embargo, si pasamos un nombre de archivo, entonces es posible en algunas plataformas (como BSD) donde un actor malintencionado puede hacer que se coloque un archivo arbitrario en esa ubicación.
    // Esto significa que si le decimos a libbacktrace acerca de un nombre de archivo, puede estar usando un archivo arbitrario, posiblemente causando segfaults.
    // Sin embargo, si no le decimos nada a libbacktrace, ¡no hará nada en plataformas que no admitan rutas como /proc/self/exe!
    //
    // Teniendo en cuenta todo eso, intentamos lo más posible *no* pasar un nombre de archivo, pero debemos hacerlo en plataformas que no admiten /proc/self/exe en absoluto.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Tenga en cuenta que idealmente usaríamos `std::env::current_exe`, pero no podemos requerir `std` aquí.
            //
            // Use `_NSGetExecutablePath` para cargar la ruta ejecutable actual en un área estática (que si es demasiado pequeña, simplemente ríndase).
            //
            //
            // Tenga en cuenta que estamos confiando seriamente en libbacktrace aquí para que no muera en ejecutables corruptos, pero seguramente lo hace ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows tiene un modo de abrir archivos en el que, una vez abierto, no se pueden eliminar.
            // En general, eso es lo que queremos aquí porque queremos asegurarnos de que nuestro ejecutable no cambie después de que lo entreguemos a libbacktrace, con suerte mitigando la capacidad de pasar datos arbitrarios a libbacktrace (que puede manejarse mal).
            //
            //
            // Dado que hacemos un pequeño baile aquí para intentar conseguir una especie de bloqueo en nuestra propia imagen:
            //
            // * Obtenga un identificador del proceso actual, cargue su nombre de archivo.
            // * Abra un archivo con ese nombre de archivo con las banderas correctas.
            // * Vuelva a cargar el nombre de archivo del proceso actual, asegurándose de que sea el mismo
            //
            // Si todo eso pasa, en teoría hemos abierto el archivo de nuestro proceso y estamos garantizados que no cambiará.FWIW, un montón de esto se ha copiado de libstd históricamente, así que esta es mi mejor interpretación de lo que estaba sucediendo.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Esto vive en la memoria estática para que podamos devolverlo.
                static mut BUF: [i8; N] = [0; N];
                // ... y esto vive en la pila ya que es temporal
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // Filtrar intencionalmente `handle` aquí porque tenerlo abierto debería preservar nuestro bloqueo en este nombre de archivo.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Queremos devolver un segmento con terminación nula, por lo que si todo se completó y es igual a la longitud total, equiparé eso a la falla.
                //
                //
                // De lo contrario, cuando devuelva el éxito, asegúrese de que el byte nulo esté incluido en el segmento.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // Los errores de rastreo se esconden actualmente bajo la alfombra.
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Llame a la API `backtrace_syminfo` que (después de leer el código) debería llamar a `syminfo_cb` exactamente una vez (o fallar con un error presumiblemente).
    // Luego manejamos más dentro del `syminfo_cb`.
    //
    // Tenga en cuenta que hacemos esto ya que `syminfo` consultará la tabla de símbolos, encontrando nombres de símbolos incluso si no hay información de depuración en el binario.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}