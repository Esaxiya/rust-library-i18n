use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Representación de un backtrace propio y autónomo.
///
/// Esta estructura se puede usar para capturar un rastreo en varios puntos de un programa y luego usarse para inspeccionar cuál era el rastreo en ese momento.
///
///
/// `Backtrace` admite la impresión bonita de trazas inversas a través de su implementación `Debug`.
///
/// # Caracteristicas requeridas
///
/// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Los marcos aquí se enumeran de arriba a abajo de la pila
    frames: Vec<BacktraceFrame>,
    // Creemos que el índice es el inicio real del backtrace, omitiendo fotogramas como `Backtrace::new` y `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Versión capturada de un fotograma en un seguimiento.
///
/// Este tipo se devuelve como una lista de `Backtrace::frames` y representa un marco de pila en un rastreo inverso capturado.
///
/// # Caracteristicas requeridas
///
/// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Versión capturada de un símbolo en un retroceso.
///
/// Este tipo se devuelve como una lista de `BacktraceFrame::symbols` y representa los metadatos de un símbolo en un rastreo.
///
/// # Caracteristicas requeridas
///
/// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Captura un seguimiento en el sitio de llamada de esta función y devuelve una representación propia.
    ///
    /// Esta función es útil para representar un backtrace como un objeto en Rust.Este valor devuelto puede enviarse a través de subprocesos e imprimirse en otro lugar, y el propósito de este valor es ser completamente autónomo.
    ///
    /// Tenga en cuenta que, en algunas plataformas, adquirir un rastreo completo y resolverlo puede resultar extremadamente costoso.
    /// Si el costo es demasiado para su aplicación, se recomienda utilizar en su lugar `Backtrace::new_unresolved()`, que evita el paso de resolución del símbolo (que generalmente toma más tiempo) y permite posponerlo para una fecha posterior.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // quiero asegurarme de que haya un marco aquí para eliminar
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Similar a `new`, excepto que no resuelve ningún símbolo, simplemente captura el rastreo como una lista de direcciones.
    ///
    /// En un momento posterior, se puede llamar a la función `resolve` para resolver los símbolos de este backtrace en nombres legibles.
    /// Esta función existe porque el proceso de resolución a veces puede llevar una cantidad significativa de tiempo, mientras que cualquier trazo inverso solo se puede imprimir en raras ocasiones.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // sin nombres de símbolos
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // nombres de símbolos ahora presentes
    /// ```
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    ///
    ///
    #[inline(never)] // quiero asegurarme de que haya un marco aquí para eliminar
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Devuelve los fotogramas de cuando se capturó este rastreo.
    ///
    /// Es probable que la primera entrada de este segmento sea la función `Backtrace::new`, y el último cuadro probablemente sea algo sobre cómo comenzó este hilo o la función principal.
    ///
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Si este backtrace se creó a partir de `new_unresolved`, esta función resolverá todas las direcciones en el backtrace con sus nombres simbólicos.
    ///
    ///
    /// Si este rastreo se ha resuelto previamente o se creó a través de `new`, esta función no hace nada.
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Igual que `Frame::ip`
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Igual que `Frame::symbol_address`
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Igual que `Frame::module_base_address`
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Devuelve la lista de símbolos a los que corresponde este marco.
    ///
    /// Normalmente, solo hay un símbolo por cuadro, pero a veces, si se insertan varias funciones en un cuadro, se devolverán varios símbolos.
    /// El primer símbolo de la lista es el "innermost function", mientras que el último símbolo es el más externo (último llamador).
    ///
    /// Tenga en cuenta que si este marco proviene de un backtrace no resuelto, esto devolverá una lista vacía.
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Igual que `Symbol::name`
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Igual que `Symbol::addr`
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Igual que `Symbol::filename`
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Igual que `Symbol::lineno`
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Igual que `Symbol::colno`
    ///
    /// # Caracteristicas requeridas
    ///
    /// Esta función requiere que la función `std` de `backtrace` crate esté habilitada, y la función `std` está habilitada de forma predeterminada.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Cuando imprimimos rutas, intentamos eliminar el cwd si existe, de lo contrario, simplemente imprimimos la ruta como está.
        // Tenga en cuenta que también hacemos esto solo para el formato corto, porque si está lleno, presumiblemente queremos imprimir todo.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}