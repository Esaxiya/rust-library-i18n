# El `rustc-std-workspace-std` crate

Consulte la documentación del `rustc-std-workspace-core` crate.