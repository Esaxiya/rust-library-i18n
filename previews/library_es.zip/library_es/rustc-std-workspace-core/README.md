# El `rustc-std-workspace-core` crate

Este crate es un calce y un crate vacío que simplemente depende de `libcore` y reexporta todo su contenido.
El crate es el quid de habilitar la biblioteca estándar para depender de crates de crates.io

Crates en crates.io de los que depende la biblioteca estándar debe depender de `rustc-std-workspace-core` crate de crates.io, que está vacío.

Usamos `[patch]` para anularlo a este crate en este repositorio.
Como resultado, crates en crates.io dibujará una dependencia edge a `libcore`, la versión definida en este repositorio.
¡Eso debería dibujar todos los bordes de dependencia para garantizar que Cargo compile crates con éxito!

Tenga en cuenta que crates en crates.io debe depender de este crate con el nombre `core` para que todo funcione correctamente.Para hacer eso, pueden usar:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Mediante el uso de la tecla `package`, el crate cambia de nombre a `core`, lo que significa que se verá como

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

cuando Cargo invoca al compilador, cumpliendo la directiva `extern crate core` implícita inyectada por el compilador.




