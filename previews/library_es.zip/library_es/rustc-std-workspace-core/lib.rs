#![feature(no_core)]
#![no_core]

pub use core::*;
