// rsbegin.o y rsend.o son los llamados "compiler runtime startup objects".
// Contienen el código necesario para inicializar correctamente el tiempo de ejecución del compilador.
//
// Cuando se vincula una imagen ejecutable o dylib, todo el código de usuario y las bibliotecas son "sandwiched" entre estos dos archivos de objeto, por lo que el código o los datos de rsbegin.o se convierten en los primeros en las secciones respectivas de la imagen, mientras que el código y los datos de rsend.o se convierten en los últimos.
// Este efecto se puede utilizar para colocar símbolos al principio o al final de una sección, así como para insertar los encabezados o pies de página necesarios.
//
// Tenga en cuenta que el punto de entrada del módulo real se encuentra en el objeto de inicio de tiempo de ejecución de C (generalmente llamado `crtX.o`), que luego invoca devoluciones de llamada de inicialización de otros componentes de tiempo de ejecución (registrados a través de otra sección de imagen especial).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Marca el comienzo de la sección de información de desenrollado del marco de pila
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Espacio libre para la contabilidad interna del desbobinador.
    // Esto se define como `struct object` en $ GCC/unswind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Relájese info rutinas registration/deregistration.
    // Consulte la documentación de libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registrar información de desenrollado en el inicio del módulo
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // anular el registro al apagar
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Registro de rutina init/uninit específico de MinGW
    pub mod mingw_init {
        // Los objetos de inicio de MinGW (crt0.o/dllcrt0.o) invocarán constructores globales en las secciones .ctors y .dtors al iniciar y salir.
        // En el caso de las DLL, esto se hace cuando la DLL se carga y descarga.
        //
        // El enlazador ordenará las secciones, lo que asegura que nuestras devoluciones de llamada se encuentren al final de la lista.
        // Dado que los constructores se ejecutan en orden inverso, esto asegura que nuestras devoluciones de llamada sean las primeras y las últimas ejecutadas.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: devoluciones de llamada de inicialización de C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: devoluciones de llamada de terminación C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}