# Contribuyendo al stdarch

¡El `stdarch` crate está más que dispuesto a aceptar contribuciones!Primero, probablemente querrá revisar el repositorio y asegurarse de que las pruebas pasen por usted:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Donde `<your-target-arch>` es el triple objetivo utilizado por `rustup`, por ejemplo, `x86_x64-unknown-linux-gnu` (sin ningún `nightly-` anterior o similar).
¡Recuerde también que este repositorio requiere el canal nocturno de Rust!
De hecho, las pruebas anteriores requieren que rust nocturno sea el predeterminado en su sistema, para configurar ese uso `rustup default nightly` (y `rustup default stable` para revertir).

Si alguno de los pasos anteriores no funciona, [please let us know][new]!

A continuación, puede ayudar con [find an issue][issues], hemos seleccionado algunas con las etiquetas [`help wanted`][help] y [`impl-period`][impl] que podrían necesitar un poco de ayuda. 
Es posible que esté más interesado en [#40][vendor], que implementa todos los elementos intrínsecos del proveedor en x86.¡Ese número tiene algunos buenos consejos sobre por dónde empezar!

Si tiene preguntas generales, no dude en [join us on gitter][gitter] y pregunte.No dude en hacer ping a@BurntSushi o@alexcrichton si tiene preguntas.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Cómo escribir ejemplos de intrínsecos stdarch

Hay algunas características que deben habilitarse para que el intrínseco dado funcione correctamente y el ejemplo solo debe ser ejecutado por `cargo test --doc` cuando la característica es compatible con la CPU.

Como resultado, el `fn main` predeterminado generado por `rustdoc` no funcionará (en la mayoría de los casos).
Considere usar lo siguiente como guía para asegurarse de que su ejemplo funcione como se esperaba.

```rust
/// # // Necesitamos cfg_target_feature para asegurarnos de que el ejemplo sea solo
/// # // ejecutado por `cargo test --doc` cuando la CPU admite la función
/// # #![feature(cfg_target_feature)]
/// # // Necesitamos target_feature para que lo intrínseco funcione
/// # #![feature(target_feature)]
/// #
/// # // rustdoc por defecto usa `extern crate stdarch`, pero necesitamos el
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // La verdadera función principal
/// # fn main() {
/// #     // Ejecute esto solo si `<target feature>` es compatible
/// #     si cfg_feature_enabled! ("<target feature>"){
/// #         // Cree una función `worker` que solo se ejecutará si la función de destino
/// #         // es compatible y asegúrese de que `target_feature` esté habilitado para su trabajador
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         inseguro fn worker() {
/// // Escriba su ejemplo aquí.¡Las características intrínsecas específicas funcionarán aquí!¡Enloquecer!
///
/// #         }
///
/// #         inseguro { worker(); }
/// #     }
/// # }
```

Si parte de la sintaxis anterior no le resulta familiar, la sección [Documentation as tests] del [Rust Book] describe bastante bien la sintaxis `rustdoc`.
Como siempre, siéntase libre de [join us on gitter][gitter] y pregúntenos si tiene algún inconveniente, ¡y gracias por ayudarnos a mejorar la documentación de `stdarch`!

# Instrucciones de prueba alternativas

En general, se recomienda que utilice `ci/run.sh` para ejecutar las pruebas.
Sin embargo, es posible que esto no funcione para usted, por ejemplo, si está en Windows.

En ese caso, puede volver a ejecutar `cargo +nightly test` y `cargo +nightly test --release -p core_arch` para probar la generación de código.
Tenga en cuenta que estos requieren que se instale la cadena de herramientas nocturna y que `rustc` sepa sobre su triple objetivo y su CPU.
En particular, debe configurar la variable de entorno `TARGET` como lo haría para `ci/run.sh`.
Además, debe configurar `RUSTCFLAGS` (necesita el `C`) para indicar las funciones de destino, p. Ej. `RUSTCFLAGS="-C -target-features=+avx2"`.
También puede configurar `-C -target-cpu=native` si está desarrollando "just" con su CPU actual.

Tenga en cuenta que cuando utilice estas instrucciones alternativas, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], p. Ej.
Las pruebas de generación de instrucciones pueden fallar porque el desensamblador las nombró de manera diferente, por ejemplo
puede generar instrucciones `vaesenc` en lugar de `aesenc` a pesar de que se comportan de la misma manera.
Además, estas instrucciones ejecutan menos pruebas de las que normalmente se realizarían, así que no se sorprenda de que cuando finalmente realice una solicitud de extracción, puedan aparecer algunos errores para las pruebas que no se tratan aquí.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






