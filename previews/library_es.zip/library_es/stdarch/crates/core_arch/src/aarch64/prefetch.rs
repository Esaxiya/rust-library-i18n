#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// Ver [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// Ver [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// Ver [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// Ver [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// Ver [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// Ver [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Obtenga la línea de caché que contiene la dirección `p` utilizando los `rw` y `locality` dados.
///
/// El `rw` debe ser uno de los siguientes:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): la captación previa se está preparando para una lectura.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): la captación previa se está preparando para una escritura.
///
/// El `locality` debe ser uno de los siguientes:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Streaming o captura previa no temporal, para datos que se usan solo una vez.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Busca en el caché de nivel 3.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Buscar en el caché de nivel 2.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Buscar en el caché de nivel 1.
///
/// Las instrucciones de captación previa de memoria señalan al sistema de memoria que es probable que los accesos a la memoria desde una dirección específica ocurran en el próximo future.
/// El sistema de memoria puede responder tomando acciones que se espera que aceleren el acceso a la memoria cuando ocurran, como precargar la dirección especificada en una o más cachés.
///
/// Debido a que estas señales son solo sugerencias, es válido que una CPU en particular trate alguna o todas las instrucciones de captación previa como un NOP.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Usamos el intrínseco `llvm.prefetch` con `cache type` =1 (caché de datos).
    // `rw` y `strategy` se basan en los parámetros de la función.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}