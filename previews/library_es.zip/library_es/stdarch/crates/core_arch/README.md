`core::arch` - Elementos intrínsecos específicos de la arquitectura de la biblioteca central de Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

El módulo `core::arch` implementa elementos intrínsecos dependientes de la arquitectura (por ejemplo, SIMD).

# Usage 

`core::arch` está disponible como parte de `libcore` y `libstd` lo reexporta.Prefiere usarlo a través de `core::arch` o `std::arch` que a través de este crate.
Las características inestables a menudo están disponibles en Rust nocturno a través del `feature(stdsimd)`.

El uso de `core::arch` a través de este crate requiere Rust nocturno, y puede (y lo hace) romperse con frecuencia.Los únicos casos en los que debería considerar su uso a través de este crate son:

* si necesita volver a compilar `core::arch` usted mismo, por ejemplo, con determinadas funciones de destino habilitadas que no están habilitadas para `libcore`/`libstd`.
Note: Si necesita volver a compilarlo para un objetivo no estándar, prefiera usar `xargo` y volver a compilar `libcore`/`libstd` según corresponda en lugar de usar este crate.
  
* utilizando algunas funciones que podrían no estar disponibles incluso detrás de las funciones inestables de Rust.Intentamos mantenerlos al mínimo.
Si necesita usar algunas de estas funciones, abra un problema para que podamos exponerlas en Rust nocturno y pueda usarlas desde allí.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` se distribuye principalmente bajo los términos de la licencia MIT y la licencia Apache (versión 2.0), con partes cubiertas por varias licencias similares a BSD.

Consulte LICENSE-APACHE y LICENSE-MIT para obtener más detalles.

# Contribution

A menos que indique explícitamente lo contrario, cualquier contribución que usted envíe intencionalmente para su inclusión en `core_arch`, según se define en la licencia Apache-2.0, tendrá una licencia doble como la anterior, sin términos o condiciones adicionales.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












