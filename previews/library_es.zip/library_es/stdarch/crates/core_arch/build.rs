use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Se usa para decirle a nuestras anotaciones `#[assert_instr]` que todos los intrínsecos simd están disponibles para probar su codegen, ya que algunos están bloqueados detrás de un `-Ctarget-feature=+unimplemented-simd128` adicional que no tiene ningún equivalente en `#[target_feature]` en este momento.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}