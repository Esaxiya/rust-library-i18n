//! Desenrollado para *emscripten* target.
//!
//! Mientras que la implementación de desenrollado habitual de Rust para plataformas Unix llama directamente a las API de libunwind, en Emscripten llamamos a las API de desenrollado de C++ .
//! Esto es solo una conveniencia ya que el tiempo de ejecución de Emscripten siempre implementa esas API y no implementa libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Esto coincide con el diseño de std::type_info en C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // El byte `\x01` principal aquí es en realidad una señal mágica para LLVM para *no* aplicar ninguna otra alteración como prefijar con un carácter `_`.
    //
    //
    // Este símbolo es la tabla v utilizada por `std::type_info` de C++ .
    // Los objetos de tipo `std::type_info`, descriptores de tipo, tienen un puntero a esta tabla.
    // Los descriptores de tipo están referenciados por las estructuras EH de C++ definidas anteriormente y que construimos a continuación.
    //
    // Tenga en cuenta que el tamaño real es mayor que 3 usize, pero solo necesitamos que nuestra vtable apunte al tercer elemento.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info para una clase de rust_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Normalmente usaríamos .as_ptr().add(2) pero esto no funciona en un contexto constante.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Esto intencionalmente no usa el esquema normal de alteración de nombres porque no queremos que C++ pueda producir o capturar Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Esto es necesario porque el código C++ puede capturar nuestra ejecución con std::exception_ptr y volver a lanzarla varias veces, posiblemente incluso en otro hilo.
    //
    //
    caught: AtomicBool,

    // Esto debe ser una opción porque el tiempo de vida del objeto sigue la semántica de C++ : cuando catch_unwind mueve el Box fuera de la excepción, aún debe dejar el objeto de excepción en un estado válido porque su destructor aún será llamado por __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try en realidad nos da un indicador de esta estructura.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Dado que cleanup() no tiene permitido panic, simplemente abortamos en su lugar.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}