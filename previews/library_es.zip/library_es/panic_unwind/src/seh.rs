//! Windows SEH
//!
//! En Windows (actualmente solo en MSVC), el mecanismo de manejo de excepciones predeterminado es el Manejo de excepciones estructurado (SEH).
//! Esto es bastante diferente al manejo de excepciones basado en Dwarf (por ejemplo, lo que usan otras plataformas unix) en términos de componentes internos del compilador, por lo que se requiere que LLVM tenga una buena cantidad de soporte adicional para SEH.
//!
//! En pocas palabras, lo que sucede aquí es:
//!
//! 1. La función `panic` llama a la función Windows estándar `_CxxThrowException` para lanzar una excepción similar a C++ , lo que activa el proceso de desenrollado.
//! 2.
//! Todas las plataformas de aterrizaje generadas por el compilador usan la función de personalidad `__CxxFrameHandler3`, una función en el CRT, y el código de desenrollado en Windows usará esta función de personalidad para ejecutar todo el código de limpieza en la pila.
//!
//! 3. Todas las llamadas generadas por el compilador a `invoke` tienen una plataforma de aterrizaje configurada como una instrucción `cleanuppad` LLVM, que indica el inicio de la rutina de limpieza.
//! La personalidad (en el paso 2, definida en el CRT) es responsable de ejecutar las rutinas de limpieza.
//! 4. Finalmente, el código "catch" en el intrínseco `try` (generado por el compilador) se ejecuta e indica que el control debe volver a Rust.
//! Esto se hace a través de una instrucción `catchswitch` más una `catchpad` en términos LLVM IR, finalmente devolviendo el control normal al programa con una instrucción `catchret`.
//!
//! Algunas diferencias específicas del manejo de excepciones basado en gcc son:
//!
//! * Rust no tiene una función de personalidad personalizada, en cambio es *siempre*`__CxxFrameHandler3`.Además, no se realiza ningún filtrado adicional, por lo que terminamos detectando cualquier excepción de C++ que se parezca al tipo que estamos lanzando.
//! Tenga en cuenta que lanzar una excepción en Rust es un comportamiento indefinido de todos modos, por lo que debería estar bien.
//! * Tenemos algunos datos para transmitir a través del límite de desenrollado, específicamente un `Box<dyn Any + Send>`.Al igual que con las excepciones Dwarf, estos dos punteros se almacenan como una carga útil en la propia excepción.
//! En MSVC, sin embargo, no hay necesidad de una asignación de montón adicional porque la pila de llamadas se conserva mientras se ejecutan las funciones de filtro.
//! Esto significa que los punteros se pasan directamente a `_CxxThrowException` que luego se recuperan en la función de filtro para ser escritos en el marco de pila del intrínseco `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Esto debe ser una opción porque capturamos la excepción por referencia y su destructor es ejecutado por el tiempo de ejecución de C++ .
    // Cuando sacamos el Box de la excepción, debemos dejar la excepción en un estado válido para que su destructor se ejecute sin dejar caer el Box dos veces.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Primero, un montón de definiciones de tipos.Aquí hay algunas rarezas específicas de la plataforma, y muchas que se copian descaradamente de LLVM.El propósito de todo esto es implementar la función `panic` a continuación mediante una llamada a `_CxxThrowException`.
//
// Esta función toma dos argumentos.El primero es un puntero a los datos que estamos pasando, que en este caso es nuestro objeto trait.¡Bastante fácil de encontrar!El siguiente, sin embargo, es más complicado.
// Este es un puntero a una estructura `_ThrowInfo` y, por lo general, solo pretende describir la excepción que se lanza.
//
// Actualmente, la definición de este tipo [1] es un poco complicada, y la principal rareza (y la diferencia con el artículo en línea) es que en 32 bits los punteros son punteros, pero en 64 bits los punteros se expresan como compensaciones de 32 bits de la Símbolo `__ImageBase`.
//
// La macro `ptr_t` y `ptr!` en los módulos siguientes se utilizan para expresar esto.
//
// El laberinto de definiciones de tipos también sigue de cerca lo que LLVM emite para este tipo de operación.Por ejemplo, si compila este código C++ en MSVC y emite LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      anular foo() { rust_panic a = {0, 1};
//          tira un;}
//
// Eso es esencialmente lo que estamos tratando de emular.La mayoría de los valores constantes a continuación se copiaron de LLVM,
//
// En cualquier caso, todas estas estructuras están construidas de manera similar, y es algo detallado para nosotros.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Tenga en cuenta que aquí ignoramos intencionalmente las reglas de alteración de nombres: no queremos que C++ pueda detectar Rust panics simplemente declarando un `struct rust_panic`.
//
//
// Al modificar, asegúrese de que la cadena del nombre del tipo coincida exactamente con la utilizada en `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // El byte `\x01` principal aquí es en realidad una señal mágica para LLVM para *no* aplicar ninguna otra alteración como prefijar con un carácter `_`.
    //
    //
    // Este símbolo es la tabla v utilizada por `std::type_info` de C++ .
    // Los objetos de tipo `std::type_info`, descriptores de tipo, tienen un puntero a esta tabla.
    // Los descriptores de tipo están referenciados por las estructuras EH de C++ definidas anteriormente y que construimos a continuación.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Este descriptor de tipo solo se usa cuando se lanza una excepción.
// La parte de captura la maneja el try intrínseco, que genera su propio TypeDescriptor.
//
// Esto está bien, ya que el tiempo de ejecución de MSVC usa la comparación de cadenas en el nombre del tipo para que coincida con los descriptores de tipos en lugar de la igualdad de punteros.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor utilizado si el código C++ decide capturar la excepción y eliminarla sin propagarla.
// La parte catch del try intrínseco establecerá la primera palabra del objeto de excepción en 0 para que el destructor la omita.
//
// Tenga en cuenta que x86 Windows utiliza la convención de llamada "thiscall" para funciones miembro de C++ en lugar de la convención de llamada "C" predeterminada.
//
// La función exception_copy es un poco especial aquí: es invocada por el tiempo de ejecución de MSVC bajo un bloque try/catch y el panic que generamos aquí se usará como resultado de la copia de excepción.
//
// Esto lo usa el tiempo de ejecución de C++ para admitir la captura de excepciones con std::exception_ptr, que no podemos admitir porque Box<dyn Any>no es clonable.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException se ejecuta completamente en este marco de pila, por lo que no es necesario transferir `data` al montón.
    // Simplemente pasamos un puntero de pila a esta función.
    //
    // Aquí se necesita ManuallyDrop ya que no queremos que se elimine la excepción al desenrollar.
    // En su lugar, será eliminado por exception_cleanup que es invocado por el tiempo de ejecución de C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Esto ... puede parecer sorprendente, y con razón.En MSVC de 32 bits, los punteros entre estas estructuras son solo eso, punteros.
    // En MSVC de 64 bits, sin embargo, los punteros entre estructuras se expresan más bien como desplazamientos de 32 bits de `__ImageBase`.
    //
    // En consecuencia, en MSVC de 32 bits podemos declarar todos estos punteros en los `estáticos` anteriores.
    // En MSVC de 64 bits, tendríamos que expresar la resta de punteros en estática, lo que Rust no permite actualmente, por lo que en realidad no podemos hacer eso.
    //
    // La siguiente mejor opción es completar estas estructuras en tiempo de ejecución (de todos modos, entrar en pánico ya es el "slow path").
    // Entonces, aquí reinterpretamos todos estos campos de puntero como números enteros de 32 bits y luego almacenamos el valor relevante en ellos (atómicamente, ya que panics concurrente puede estar sucediendo).
    //
    // Técnicamente, el tiempo de ejecución probablemente hará una lectura no atómica de estos campos, pero en teoría nunca leen el valor *incorrecto*, por lo que no debería ser tan malo ...
    //
    // En cualquier caso, básicamente necesitamos hacer algo como esto hasta que podamos expresar más operaciones en estática (y es posible que nunca podamos hacerlo).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Una carga útil NULL aquí significa que llegamos aquí desde la captura (...) de __rust_try.
    // Esto sucede cuando se detecta una excepción externa que no es Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// El compilador requiere que esto exista (por ejemplo, es un elemento lang), pero el compilador nunca lo llama porque __C_specific_handler o_except_handler3 es la función de personalidad que siempre se usa.
//
// Por lo tanto, esto es solo un talón abortivo.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}