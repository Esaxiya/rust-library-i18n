//! Implementación de Rust panics mediante abortos de proceso
//!
//! En comparación con la implementación a través del desenrollado, ¡este crate es *mucho* más simple!Dicho esto, no es tan versátil, ¡pero aquí va!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" la carga útil y calce al aborto relevante en la plataforma en cuestión.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // llamar a std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // En Windows, utilice el mecanismo __fastfail específico del procesador.En Windows 8 y posteriores, esto terminará el proceso inmediatamente sin ejecutar ningún controlador de excepciones en el proceso.
            // En versiones anteriores de Windows, esta secuencia de instrucciones se tratará como una infracción de acceso, terminando el proceso pero sin omitir necesariamente todos los controladores de excepciones.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: esta es la misma implementación que en libstd's `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Esto ... es un poco extraño.El tl; dr;es que esto es necesario para enlazar correctamente, la explicación más larga se encuentra a continuación.
//
// En este momento, los binarios de libcore/libstd que enviamos están todos compilados con `-C panic=unwind`.Esto se hace para garantizar que los archivos binarios sean compatibles al máximo con tantas situaciones como sea posible.
// Sin embargo, el compilador requiere un "personality function" para todas las funciones compiladas con `-C panic=unwind`.Esta función de personalidad está codificada con el símbolo `rust_eh_personality` y está definida por el elemento lang `eh_personality`.
//
// So...
// ¿Por qué no definir ese elemento lang aquí?¡Buena pregunta!La forma en que los tiempos de ejecución de panic están vinculados es en realidad un poco sutil, ya que son "sort of" en la tienda crate del compilador, pero solo están realmente vinculados si otro no está realmente vinculado.
//
// Esto termina significando que tanto este crate como el crate de panic_unwind pueden aparecer en la tienda crate del compilador, y si ambos definen el elemento lang `eh_personality`, se producirá un error.
//
// Para manejar esto, el compilador solo requiere que se defina `eh_personality` si el tiempo de ejecución de panic que se está vinculando es el tiempo de ejecución de desenrollado y, de lo contrario, no es necesario definirlo (con razón).
// En este caso, sin embargo, esta biblioteca solo define este símbolo, por lo que hay al menos algo de personalidad en alguna parte.
//
// Básicamente, este símbolo se acaba de definir para conectarse a los binarios libcore/libstd, pero nunca debería llamarse, ya que no enlazamos en un tiempo de ejecución de desenrollado.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // En x86_64-pc-windows-gnu usamos nuestra propia función de personalidad que necesita devolver `ExceptionContinueSearch` a medida que pasamos todos nuestros marcos.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // De manera similar a lo anterior, esto corresponde al elemento lang `eh_catch_typeinfo` que solo se usa en Emscripten actualmente.
    //
    // Dado que panics no genera excepciones y las excepciones externas son actualmente UB con -C panic=abort (aunque esto puede estar sujeto a cambios), cualquier llamada catch_unwind nunca usará este typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Estos dos son llamados por nuestros objetos de inicio en i686-pc-windows-gnu, pero no necesitan hacer nada, por lo que los cuerpos son nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}