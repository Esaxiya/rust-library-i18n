//! Una biblioteca de soporte para autores de macros al definir nuevas macros.
//!
//! Esta biblioteca, proporcionada por la distribución estándar, proporciona los tipos consumidos en las interfaces de definiciones de macro definidas por procedimientos, como macros de función `#[proc_macro]`, atributos de macro `#[proc_macro_attribute]` y atributos de derivación personalizados`#[proc_macro_derive]`.
//!
//!
//! Consulte [the book] para obtener más información.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Determina si proc_macro se ha hecho accesible para el programa que se está ejecutando actualmente.
///
/// El proc_macro crate solo está diseñado para su uso dentro de la implementación de macros de procedimiento.Todas las funciones de este crate panic si se invocan desde fuera de una macro de procedimiento, como desde un script de compilación o una prueba unitaria o un binario Rust ordinario.
///
/// Teniendo en cuenta las bibliotecas Rust que están diseñadas para admitir casos de uso macro y no macro, `proc_macro::is_available()` proporciona una forma sin pánico de detectar si la infraestructura requerida para usar la API de proc_macro está disponible actualmente.
/// Devuelve verdadero si se invoca desde el interior de una macro de procedimiento, falso si se invoca desde cualquier otro binario.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// El tipo principal proporcionado por este crate, que representa un flujo abstracto de tokens, o, más específicamente, una secuencia de árboles token.
/// El tipo proporciona interfaces para iterar sobre esos árboles token y, a la inversa, recopilar varios árboles token en una secuencia.
///
///
/// Esta es tanto la entrada como la salida de las definiciones `#[proc_macro]`, `#[proc_macro_attribute]` y `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Error devuelto por `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Devuelve un `TokenStream` vacío que no contiene árboles token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Comprueba si este `TokenStream` está vacío.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Intenta dividir la cadena en tokens y analizar esos tokens en una secuencia token.
/// Puede fallar por varias razones, por ejemplo, si la cadena contiene delimitadores desequilibrados o caracteres que no existen en el idioma.
///
/// Todos los tokens del flujo analizado obtienen intervalos `Span::call_site()`.
///
/// NOTE: algunos errores pueden causar panics en lugar de devolver `LexError`.Nos reservamos el derecho de cambiar estos errores a "LexError" más tarde.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, el puente solo proporciona `to_string`, implemente `fmt::Display` basado en él (lo contrario de la relación habitual entre los dos).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Imprime el flujo token como una cadena que se supone que se puede convertir sin pérdidas de nuevo en el mismo flujo token (intervalos de módulo), excepto posiblemente `TokenTree: : Group`s con delimitadores `Delimiter::None` y literales numéricos negativos.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Imprime token en un formato conveniente para la depuración.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Crea una secuencia token que contiene un solo árbol token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Recopila varios árboles token en una sola secuencia.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Una operación "flattening" en transmisiones token, recopila árboles token de múltiples transmisiones token en una sola transmisión.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Utilice una implementación optimizada if/when posible.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Detalles de implementación pública para el tipo `TokenStream`, como iteradores.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Un iterador sobre los `TokenTree`s de`TokenStream`.
    /// La iteración es "shallow", por ejemplo, el iterador no se repite en grupos delimitados y devuelve grupos completos como árboles token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` acepta tokens arbitrarios y se expande en un `TokenStream` que describe la entrada.
/// Por ejemplo, `quote!(a + b)` producirá una expresión que, cuando se evalúa, construye el `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// La eliminación de comillas se realiza con `$` y funciona tomando la siguiente identificación única como el término sin comillas.
/// Para citar el propio `$`, utilice `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Una región de código fuente, junto con información de expansión macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Crea un nuevo `Diagnostic` con el `message` dado en el intervalo `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Un intervalo que se resuelve en el sitio de definición de macros.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// El intervalo de la invocación de la macro de procedimiento actual.
    /// Los identificadores creados con este intervalo se resolverán como si estuvieran escritos directamente en la ubicación de la macro llamada (higiene del sitio de la llamada) y otro código en el sitio de la macro llamada también podrá hacer referencia a ellos.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Un intervalo que representa la higiene de `macro_rules` y, a veces, se resuelve en el sitio de definición de macro (variables locales, etiquetas, `$crate`) y, a veces, en el sitio de llamada de macro (todo lo demás).
    ///
    /// La ubicación del tramo se toma del sitio de la llamada.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// El archivo de origen original al que apunta este intervalo.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// El `Span` para tokens en la macro expansión anterior a partir de la cual se generó `self`, si corresponde.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// El intervalo del código fuente de origen desde el que se generó `self`.
    /// Si este `Span` no se generó a partir de otras expansiones de macro, el valor de retorno es el mismo que `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Obtiene el line/column inicial en el archivo de origen para este intervalo.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Obtiene el line/column final en el archivo de origen para este intervalo.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Crea un nuevo tramo que abarca `self` y `other`.
    ///
    /// Devuelve `None` si `self` y `other` son de archivos diferentes.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Crea un nuevo intervalo con la misma información line/column que `self` pero que resuelve los símbolos como si estuvieran en `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Crea un nuevo intervalo con el mismo comportamiento de resolución de nombres que `self` pero con la información line/column de `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Se compara con los intervalos para ver si son iguales.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Devuelve el texto de origen detrás de un intervalo.
    /// Esto conserva el código fuente original, incluidos los espacios y los comentarios.
    /// Solo devuelve un resultado si el intervalo corresponde al código fuente real.
    ///
    /// Note: El resultado observable de una macro solo debe basarse en tokens y no en este texto fuente.
    ///
    /// El resultado de esta función es un mejor esfuerzo para ser utilizado solo para diagnóstico.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Imprime un tramo en un formato conveniente para la depuración.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Un par de línea-columna que representa el inicio o el final de un `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// La línea de índice 1 en el archivo de origen en la que el intervalo comienza o termina (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// La columna indexada con 0 (en caracteres UTF-8) en el archivo de origen en el que el intervalo comienza o termina (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// El archivo fuente de un `Span` determinado.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Obtiene la ruta a este archivo fuente.
    ///
    /// ### Note
    /// Si el intervalo de código asociado con este `SourceFile` fue generado por una macro externa, esta macro, puede que no sea una ruta real en el sistema de archivos.
    /// Utilice [`is_real`] para comprobarlo.
    ///
    /// También tenga en cuenta que incluso si `is_real` devuelve `true`, si `--remap-path-prefix` se pasó en la línea de comando, es posible que la ruta dada no sea válida.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Devuelve `true` si este archivo fuente es un archivo fuente real y no generado por la expansión de una macro externa.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Esto es un truco hasta que se implementen tramos entre cajas y podamos tener archivos fuente reales para tramos generados en macros externas.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Un solo token o una secuencia delimitada de árboles token (por ejemplo, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Una secuencia token rodeada por delimitadores de corchetes.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Un identificador.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Un solo carácter de puntuación (`+`, `,`, `$`, etc.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Un carácter literal (`'a'`), cadena (`"hello"`), número (`2.3`), etc.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Devuelve el intervalo de este árbol, delegando al método `span` del token contenido o una secuencia delimitada.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Configura el intervalo para *solo este token*.
    ///
    /// Tenga en cuenta que si este token es un `Group`, entonces este método no configurará el intervalo de cada uno de los tokens internos, esto simplemente se delegará en el método `set_span` de cada variante.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Imprime el árbol token en una forma conveniente para la depuración.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Cada uno de estos tiene el nombre en el tipo de estructura en la depuración derivada, así que no se moleste con una capa adicional de indirección
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, el puente solo proporciona `to_string`, implemente `fmt::Display` basado en él (lo contrario de la relación habitual entre los dos).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Imprime el árbol token como una cadena que se supone que se puede volver a convertir sin pérdidas en el mismo árbol token (intervalos de módulo), excepto posiblemente `TokenTree: : Group`s con delimitadores `Delimiter::None` y literales numéricos negativos.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Una secuencia token delimitada.
///
/// Un `Group` contiene internamente un `TokenStream` que está rodeado por 'Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Describe cómo se delimita una secuencia de árboles token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Un delimitador implícito, que puede aparecer, por ejemplo, alrededor de tokens proveniente de un "macro variable" `$var`.
    /// Es importante preservar las prioridades del operador en casos como `$var * 3` donde `$var` es `1 + 2`.
    /// Es posible que los delimitadores implícitos no sobrevivan al viaje de ida y vuelta de una secuencia token a través de una cadena.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Crea un nuevo `Group` con el delimitador dado y el flujo token.
    ///
    /// Este constructor establecerá el intervalo para este grupo en `Span::call_site()`.
    /// Para cambiar el tramo, puede utilizar el método `set_span` a continuación.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Devuelve el delimitador de este `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Devuelve el `TokenStream` de tokens que están delimitados en este `Group`.
    ///
    /// Tenga en cuenta que la secuencia token devuelta no incluye el delimitador devuelto anteriormente.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Devuelve el intervalo de los delimitadores de esta secuencia token, que abarca todo el `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Devuelve el intervalo que apunta al delimitador de apertura de este grupo.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Devuelve el intervalo que apunta al delimitador de cierre de este grupo.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Configura el intervalo para los delimitadores de este `Grupo`, pero no sus tokens internos.
    ///
    /// Este método **no** establecerá el intervalo de todos los tokens internos abarcados por este grupo, sino que solo establecerá el intervalo del delimitador tokens al nivel del `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, el puente solo proporciona `to_string`, implemente `fmt::Display` basado en él (lo contrario de la relación habitual entre los dos).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Imprime el grupo como una cadena que debería ser convertible sin pérdidas de nuevo en el mismo grupo (intervalos de módulo), excepto posiblemente `TokenTree: : Group`s con delimitadores `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Un `Punct` es un carácter de puntuación simple como `+`, `-` o `#`.
///
/// Los operadores de varios caracteres como `+=` se representan como dos instancias de `Punct` con diferentes formas de `Spacing` devueltas.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Si un `Punct` es seguido inmediatamente por otro `Punct` o seguido por otro token o espacios en blanco.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// por ejemplo, `+` es `Alone` en `+ =`, `+ident` o `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// por ejemplo, `+` es `Joint` en `+=` o `'#`.
    /// Además, la comilla simple `'` puede unirse con identificadores para formar vidas `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Crea un nuevo `Punct` a partir del carácter y el espaciado dados.
    /// El argumento `ch` debe ser un carácter de puntuación válido permitido por el idioma; de lo contrario, la función será panic.
    ///
    /// El `Punct` devuelto tendrá el intervalo predeterminado de `Span::call_site()` que se puede configurar con el método `set_span` a continuación.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Devuelve el valor de este carácter de puntuación como `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Devuelve el espaciado de este carácter de puntuación, lo que indica si es seguido inmediatamente por otro `Punct` en la secuencia token, por lo que potencialmente se pueden combinar en un operador de varios caracteres (`Joint`), o si va seguido de algún otro token o espacio en blanco (`Alone`), por lo que el operador ciertamente ha terminó.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Devuelve el intervalo de este carácter de puntuación.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configure el intervalo para este carácter de puntuación.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, el puente solo proporciona `to_string`, implemente `fmt::Display` basado en él (lo contrario de la relación habitual entre los dos).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Imprime el carácter de puntuación como una cadena que debería volver a convertirse sin pérdidas en el mismo carácter.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Un identificador (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Crea un nuevo `Ident` con el `string` dado y el `span` especificado.
    /// El argumento `string` debe ser un identificador válido permitido por el idioma (incluidas palabras clave, por ejemplo, `self` o `fn`).De lo contrario, la función será panic.
    ///
    /// Tenga en cuenta que `span`, actualmente en rustc, configura la información de higiene para este identificador.
    ///
    /// A partir de este momento, `Span::call_site()` opta explícitamente por la higiene de "call-site", lo que significa que los identificadores creados con este intervalo se resolverán como si estuvieran escritos directamente en la ubicación de la llamada de macro, y otro código en el sitio de llamada de macro podrá hacer referencia a ellos también.
    ///
    ///
    /// Los intervalos posteriores como `Span::def_site()` permitirán optar por la higiene de "definition-site", lo que significa que los identificadores creados con este intervalo se resolverán en la ubicación de la definición de macro y otro código en el sitio de llamada de macro no podrá hacer referencia a ellos.
    ///
    /// Debido a la importancia actual de la higiene, este constructor, a diferencia de otros tokens, requiere que se especifique un `Span` en la construcción.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Igual que `Ident::new`, pero crea un identificador (`r#ident`) sin formato.
    /// El argumento `string` debe ser un identificador válido permitido por el idioma (incluidas las palabras clave, por ejemplo, `fn`).
    /// Palabras clave que se pueden utilizar en segmentos de ruta (p. Ej.
    /// `self`, `super`) no son compatibles y causarán un panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Devuelve el intervalo de este `Ident`, que abarca toda la cadena devuelta por [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configura el alcance de este `Ident`, posiblemente cambiando su contexto de higiene.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, el puente solo proporciona `to_string`, implemente `fmt::Display` basado en él (lo contrario de la relación habitual entre los dos).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Imprime el identificador como una cadena que debería volver a convertirse sin pérdidas en el mismo identificador.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Una cadena literal (`"hello"`), cadena de bytes (`b"hello"`), carácter (`'a'`), carácter de byte (`b'a'`), un número entero o de coma flotante con o sin sufijo (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Los literales booleanos como `true` y `false` no pertenecen aquí, son `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Crea un nuevo literal entero con sufijo con el valor especificado.
        ///
        /// Esta función creará un número entero como `1u32` donde el valor entero especificado es la primera parte del token y la integral también tiene el sufijo al final.
        /// Los literales creados a partir de números negativos pueden no sobrevivir a los viajes de ida y vuelta a través de `TokenStream` o cadenas y pueden dividirse en dos tokens (`-` y literal positivo).
        ///
        ///
        /// Los literales creados a través de este método tienen el intervalo `Span::call_site()` de forma predeterminada, que se puede configurar con el método `set_span` a continuación.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Crea un nuevo literal entero sin sufijo con el valor especificado.
        ///
        /// Esta función creará un número entero como `1` donde el valor entero especificado es la primera parte del token.
        /// No se especifica ningún sufijo en este token, lo que significa que las invocaciones como `Literal::i8_unsuffixed(1)` son equivalentes a `Literal::u32_unsuffixed(1)`.
        /// Los literales creados a partir de números negativos pueden no sobrevivir a los recorridos a través de `TokenStream` o cadenas y pueden dividirse en dos tokens (`-` y literal positivo).
        ///
        ///
        /// Los literales creados a través de este método tienen el intervalo `Span::call_site()` de forma predeterminada, que se puede configurar con el método `set_span` a continuación.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Crea un nuevo literal de punto flotante sin sufijo.
    ///
    /// Este constructor es similar a aquellos como `Literal::i8_unsuffixed` donde el valor del flotador se emite directamente en el token pero no se usa ningún sufijo, por lo que se puede inferir que es un `f64` más adelante en el compilador.
    ///
    /// Los literales creados a partir de números negativos pueden no sobrevivir a los recorridos a través de `TokenStream` o cadenas y pueden dividirse en dos tokens (`-` y literal positivo).
    ///
    /// # Panics
    ///
    /// Esta función requiere que el flotante especificado sea finito, por ejemplo, si es infinito o NaN, esta función será panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Crea un nuevo literal de punto flotante con sufijo.
    ///
    /// Este constructor creará un literal como `1.0f32` donde el valor especificado es la parte anterior del token y `f32` es el sufijo del token.
    /// Este token siempre se inferirá que es un `f32` en el compilador.
    /// Los literales creados a partir de números negativos pueden no sobrevivir a los recorridos a través de `TokenStream` o cadenas y pueden dividirse en dos tokens (`-` y literal positivo).
    ///
    ///
    /// # Panics
    ///
    /// Esta función requiere que el flotante especificado sea finito, por ejemplo, si es infinito o NaN, esta función será panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Crea un nuevo literal de punto flotante sin sufijo.
    ///
    /// Este constructor es similar a aquellos como `Literal::i8_unsuffixed` donde el valor del flotador se emite directamente en el token pero no se usa ningún sufijo, por lo que se puede inferir que es un `f64` más adelante en el compilador.
    ///
    /// Los literales creados a partir de números negativos pueden no sobrevivir a los recorridos a través de `TokenStream` o cadenas y pueden dividirse en dos tokens (`-` y literal positivo).
    ///
    /// # Panics
    ///
    /// Esta función requiere que el flotante especificado sea finito, por ejemplo, si es infinito o NaN, esta función será panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Crea un nuevo literal de punto flotante con sufijo.
    ///
    /// Este constructor creará un literal como `1.0f64` donde el valor especificado es la parte anterior del token y `f64` es el sufijo del token.
    /// Este token siempre se inferirá que es un `f64` en el compilador.
    /// Los literales creados a partir de números negativos pueden no sobrevivir a los recorridos a través de `TokenStream` o cadenas y pueden dividirse en dos tokens (`-` y literal positivo).
    ///
    ///
    /// # Panics
    ///
    /// Esta función requiere que el flotante especificado sea finito, por ejemplo, si es infinito o NaN, esta función será panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Literal de cadena.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Carácter literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Literal de cadena de bytes.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Devuelve el intervalo que abarca este literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configura el intervalo asociado para este literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Devuelve un `Span` que es un subconjunto de `self.span()` que contiene solo los bytes de origen en el rango `range`.
    /// Devuelve `None` si el tramo recortado potencial está fuera de los límites de `self`.
    ///
    // FIXME(SergioBenitez): compruebe que el rango de bytes comienza y termina en un límite UTF-8 de la fuente.
    // de lo contrario, es probable que se produzca un panic en otro lugar cuando se imprima el texto de origen.
    // FIXME(SergioBenitez): No hay forma de que el usuario sepa a qué se asigna realmente `self.span()`, por lo que este método actualmente solo se puede llamar a ciegas.
    // Por ejemplo, `to_string()` para el carácter 'c' devuelve "'\u{63}'";no hay forma de que el usuario sepa si el texto fuente era 'c' o si era '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) algo parecido a `Option::cloned`, pero para `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, el puente solo proporciona `to_string`, implemente `fmt::Display` basado en él (lo contrario de la relación habitual entre los dos).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Imprime el literal como una cadena que debería volver a convertirse sin pérdidas en el mismo literal (excepto por el posible redondeo de los literales de coma flotante).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Seguimiento de acceso a variables de entorno.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Recupere una variable de entorno y agréguela para generar información de dependencia.
    /// El sistema de compilación que ejecuta el compilador sabrá que se accedió a la variable durante la compilación y podrá volver a ejecutar la compilación cuando cambie el valor de esa variable.
    ///
    /// Además del seguimiento de dependencias, esta función debe ser equivalente a `env::var` de la biblioteca estándar, excepto que el argumento debe ser UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}