#![feature(no_core)]
#![no_core]

// Consulte rustc-std-workspace-core para saber por qué se necesita este crate.

// Cambie el nombre de crate para evitar conflictos con el módulo alloc en liballoc.
extern crate alloc as foo;

pub use foo::*;