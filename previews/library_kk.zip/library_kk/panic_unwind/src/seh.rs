//! Windows SEH
//!
//! Windows-де (қазіргі уақытта тек MSVC-де) әдепкі ерекшелікті өңдеу механизмі-бұл құрылымдық ерекшелікті өңдеу (SEH).
//! Бұл карликтерге негізделген ерекше жағдайларды өңдеуден (мысалы, басқа unix платформаларын қолдана отырып) компилятор ішкі жағынан айтарлықтай өзгеше, сондықтан LLVM SEH үшін қосымша қолдауды қажет етеді.
//!
//! Қысқаша айтқанда, мұнда не болады:
//!
//! 1. `panic` функциясы стандартты Windows функциясын шақырады `_CxxThrowException` C++ сияқты ерекшелікті лақтыру үшін босату процесін бастайды.
//! 2.
//! Компилятор құрған барлық отырғызғыш алаңдар `__CxxFrameHandler3` жеке функциясын, CRT функциясын пайдаланады, ал Windows ішіндегі босату коды стектегі барлық тазарту кодтарын орындау үшін осы функцияны қолданады.
//!
//! 3. `invoke`-ге компилятор жасаған барлық қоңырауларда қонуға арналған алаң `cleanuppad` LLVM нұсқауы ретінде орнатылған, бұл тазарту процедурасының басталуын көрсетеді.
//! Тазарту процедураларын орындау үшін жеке тұлға (2-қадамда, ЭТТ-да анықталған) жауап береді.
//! 4. Ақыр соңында, `try` ішкі құрамындағы "catch" коды орындалады (компилятор жасайды) және басқару Rust-қа қайта оралуы керек екенін көрсетеді.
//! Бұл `catchswitch` плюс `catchpad` командасы арқылы LLVM IR терминдерімен жасалады, ақырында `catchret` командасымен бағдарламаға қалыпты басқаруды қайтарады.
//!
//! gcc негізіндегі ерекше жағдайларды өңдеуден кейбір ерекше айырмашылықтар:
//!
//! * Rust-дің жеке функциясы жоқ, оның орнына *әрқашан*`__CxxFrameHandler3` болады.Сонымен қатар, ешқандай қосымша сүзгілеу жүргізілмейді, сондықтан біз кез-келген C++ ерекшеліктерін өзіміз лақтыратын түрге ұқсас боламыз.
//! Ерекшелікті Rust-ге жіберу-бұл бәрібір анықталмаған мінез-құлық, сондықтан бұл жақсы болуы керек екенін ескеріңіз.
//! * Шекарадан өтуге мүмкіндік беретін мәліметтер бар, атап айтқанда `Box<dyn Any + Send>`.Ергежейлі ерекшеліктер сияқты, бұл екі көрсеткіш ерекше жағдайдың өзінде пайдалы жүктеме ретінде сақталады.
//! MSVC-де қосымша үйінділерді бөлудің қажеті жоқ, себебі сүзгілеу функциялары орындалған кезде қоңыраулар стегі сақталады.
//! Бұл көрсеткіштер тікелей `_CxxThrowException`-ге беріледі, содан кейін сүзгі функциясында қалпына келтіріліп, ішкі `try` стек жақтауына жазылады.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Бұл нұсқа болуы керек, өйткені біз ерекшелікті сілтеме арқылы ұстаймыз және оның деструкторы C++ жұмыс уақытымен орындалады.
    // Біз қорапты ерекше жағдайдан шығарған кезде, оның деструкторы қорапты екі рет түсірмей жұмыс істеуі үшін ерекше жағдайды қалдыруымыз керек.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Алдымен, барлық типтегі анықтамалар тобы.Мұнда бірнеше платформаға тән ерекше жағдайлар бар, және олар LLVM-ден ашық түрде көшірілген.Мұның мақсаты-`_CxxThrowException`-ге қоңырау шалу арқылы төмендегі `panic` функциясын жүзеге асыру.
//
// Бұл функция екі аргумент алады.Біріншісі-біз жіберетін деректерге сілтеме, бұл жағдайда біздің trait объектісі болады.Табу өте оңай!Келесі, алайда күрделі.
// Бұл `_ThrowInfo` құрылымының көрсеткіші, және ол тек жай шығарылатын ерекшелікті сипаттауға арналған.
//
// Қазіргі уақытта [1] түрінің анықтамасы сәл түкті, ал басты ерекшелігі (және желідегі мақаладан айырмашылығы) 32-битте көрсеткіштер көрсеткіштер, ал 64-биттерде көрсеткіштер 32-биттік ығысулар түрінде көрсетіледі. `__ImageBase` таңбасы.
//
// Мұны білдіру үшін төмендегі модульдердегі `ptr_t` және `ptr!` макросы қолданылады.
//
// Сондай-ақ, типтегі анықтамалардың лабиринті LLVM осы түрдегі жұмыс үшін не шығаратынын мұқият қадағалайды.Мысалы, егер сіз осы C++ кодын MSVC-де құрастырсаңыз және LLVM IR шығарсаңыз:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      foo() { rust_panic a = {0, 1} жарамсыздығы;
//          лақтыру а;}
//
// Бұл біз еліктегіміз келетін нәрсе.Төмендегі тұрақты мәндердің көп бөлігі LLVM-дан көшірілген,
//
// Қалай болғанда да, бұл құрылымдардың барлығы ұқсас түрде салынған және бұл біз үшін біршама мағыналы.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Біз бұл жерде аттарды манингтеу ережелерін қасақана елемейтіндігімізге назар аударыңыз: біз C++ Rust panics-ді жай `struct rust_panic` деп жариялау арқылы ұстай алатынын қаламаймыз.
//
//
// Өзгерткен кезде, түр атауының жолының `compiler/rustc_codegen_llvm/src/intrinsic.rs`-те қолданылғанымен дәл сәйкес келетіндігіне көз жеткізіңіз.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Мұндағы жетекші `\x01` байт-бұл LLVM-ге сиқырлы сигнал, `_` таңбалы префикс сияқты кез-келген басқа мангияны қолданбауға * болмайды.
    //
    //
    // Бұл символ C++ `std::type_info` пайдаланатын стол болып табылады.
    // `std::type_info` типті объектілер, типтік дескрипторлар, осы кестеге көрсеткішке ие.
    // Типтік дескрипторларға жоғарыда анықталған және төменде құрастырылатын C++ EH құрылымдары сілтеме жасайды.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Бұл типтегі дескриптор тек ерекше жағдай болған кезде қолданылады.
// Ұстау бөлігі меншікті TypeDescriptor-ды құратын ішкі intrinsic арқылы өңделеді.
//
// Бұл өте жақсы, өйткені MSVC жұмыс уақыты сілтеме теңдігінің орнына TypeDescriptors-ға сәйкес келу үшін типтің атауында жолдарды салыстыруды қолданады.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Егер C++ коды ерекше жағдайды түсіріп, оны таратпай тастауға шешім қабылдаса, қолданылатын деструктор.
// Intrinsic-тің аулау бөлігі ерекше объектінің бірінші сөзін деструктор өткізіп жіберетіндей етіп 0-ге қояды.
//
// x86 Windows стандартты "C" шақырудың орнына C++ мүшелерінің функциялары үшін "thiscall" шақыру конвенциясын қолданады.
//
// Exception_copy функциясы мұнда біршама ерекше: оны MSVC жұмыс уақыты try/catch блогы арқылы шақырады және біз осында шығаратын panic ерекше жағдай көшірмесінің нәтижесі ретінде пайдаланылады.
//
// Мұны C++ жұмыс уақыты std::exception_ptr-пен ерекшеліктерді сақтау үшін қолданады, біз оны қолдай алмаймыз, себебі Box<dyn Any>клондық емес.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException толығымен осы стек шеңберінде орындалады, сондықтан `data` үйіндіге ауыстырудың қажеті жоқ.
    // Біз бұл функцияға стек көрсеткішін жібереміз.
    //
    // Мұнда ManuallyDrop қажет, өйткені біз босату кезінде ерекше жағдайдың жойылып кетуін қаламаймыз.
    // Оның орнына C++ жұмыс уақытымен шақырылатын exception_cleanup арқылы алынып тасталады.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Бұл ... таңқаларлық болып көрінуі мүмкін, сондықтан орынды.32 биттік MSVC-де осы құрылым арасындағы көрсеткіштер дәл сол, сілтемелер.
    // 64-биттік MSVC-де құрылымдар арасындағы көрсеткіштер `__ImageBase`-тен 32-биттік ығысу ретінде көрсетілген.
    //
    // Демек, 32-биттік MSVC-де біз осы көрсеткіштердің барлығын жоғарыдағы «статикалықта» жариялай аламыз.
    // 64-разрядты MSVC-де статикадағы көрсеткіштерді азайтуды білдіруге тура келеді, бұған Rust жол бермейді, сондықтан біз мұны істей алмаймыз.
    //
    // Келесі ең жақсы нәрсе, бұл құрылымдарды жұмыс уақытында толтыру (дүрбелең "slow path" бәрібір).
    // Сонымен, біз осы көрсеткіш өрістерінің барлығын 32 биттік бүтін сандар ретінде қайта түсіндіреміз, содан кейін оған сәйкес мәнді сақтаймыз (panics қатар жүруі мүмкін).
    //
    // Техникалық тұрғыдан жұмыс уақыты бұл өрістерді бейатомиялық түрде оқуы мүмкін, бірақ теорияда олар ешқашан *қате* мәнін оқымайды, сондықтан ол жаман болмауы керек ...
    //
    // Қалай болғанда да, біз статикада көп амалдар көрсете алмайынша (және біз ешқашан жасай алмайтындай), осылай жасауымыз керек.
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Мұндағы NULL пайдалы жүктемесі біз Xrxx __rust_try-тен келгенімізді білдіреді.
    // Бұл Rust емес шетелдік ерекше жағдай болған кезде болады.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Бұл компилятордың өмір сүруін талап етеді (мысалы, бұл lang элементі), бірақ оны ешқашан компилятор шақырмайды, өйткені __C_specific_handler немесе _except_handler3 әрқашан қолданылатын жеке функция болып табылады.
//
// Демек, бұл тек жасанды түсік тастау.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}