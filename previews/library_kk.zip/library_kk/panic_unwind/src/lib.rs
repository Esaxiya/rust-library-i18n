//! panics-ді стаканы босату арқылы енгізу
//!
//! Бұл crate-бұл panics-ді Rust-да "most native" стекінің босату механизмін қолдана отырып құрастырған платформа.
//! Қазіргі уақытта бұл үш шелекке бөлінеді:
//!
//! 1. MSVC мақсаттары `seh.rs` файлында SEH қолданады.
//! 2. Emscripten `emcc.rs` файлында C++ ерекшеліктерін қолданады.
//! 3. Барлық басқа мақсаттар `gcc.rs` файлында libunwind/libgcc пайдаланады.
//!
//! Әр іске асыру туралы қосымша құжаттарды тиісті модульден табуға болады.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` Miri-де қолданылмайды, сондықтан ескертулерді үнсіз қалдырыңыз.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust жұмыс уақытының іске қосылу нысандары осы шартты белгілерге байланысты, сондықтан оларды жалпыға қол жетімді етіңіз.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Ашуды қолдамайтын мақсаттар.
        // - arch=wasm32
        // - os=жоқ ("bare metal" мақсаттары)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Miri жұмыс уақытын пайдаланыңыз.
        // Бізге әлі де қалыпты жұмыс уақытын жүктеу қажет, өйткені rustc белгілі бір тілдік элементтер анықталады деп күтеді.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Нақты жұмыс уақытын пайдаланыңыз.
        use real_imp as imp;
    }
}

extern "C" {
    /// Libstd-дегі өңдеуші panic нысаны `catch_unwind` сыртына тасталған кезде шақырылады.
    ///
    fn __rust_drop_panic() -> !;

    /// Шетелдік ерекше жағдай болған кезде шақырылған libstd өңдеушісі.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Ерекше жағдайды енгізу үшін кіру нүктесі, тек платформаға арналған арнайы делегаттар.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}