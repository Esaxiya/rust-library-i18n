//! Miri үшін panics шешілуде.
use alloc::boxed::Box;
use core::any::Any;

// Miri қозғалтқышы біз үшін тарату арқылы таралатын пайдалы жүктің түрі.
// Сілтегіш өлшемінде болуы керек.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Шығаруды бастау үшін Miri-мен берілген extern функциясы.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Біз `miri_start_panic`-ге өтетін пайдалы жүктеме дәл `cleanup` дәлелі болады.
    // Сондықтан біз оны тек бір рет қорапқа алып, өлшемді нәрсе алуымыз керек.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Негізгі `Box` қалпына келтіріңіз.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}