# `rustc-std-workspace-core` crate

Бұл crate-бұл жай және бос crate, ол жай `libcore`-ге тәуелді және оның барлық мазмұнын қайта экспорттайды.
crate-стандартты кітапхананы crates.io-тен crates-ге тәуелді етудің негізі.

Стандартты кітапхана тәуелді болатын crates.io-тегі Crates бос crates.io-тен `rustc-std-workspace-core` crate тәуелді болуы керек.

Біз оны осы репозитарийде осы crate мәніне ауыстыру үшін `[patch]` қолданамыз.
Нәтижесінде crates crates.io-те edge тәуелділігін осы репозитарийде анықталған `libcore`-ге тәуелді етеді.
Бұл Cargo-тің crates-ді сәтті құруын қамтамасыз ету үшін барлық тәуелділік шеттерін сызу керек!

Барлығы дұрыс жұмыс істеуі үшін crates.io-тегі crates осы crate-ге `core` атауымен байланысты болуы керек екенін ескеріңіз.Ол үшін олар мыналарды қолдана алады:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` пернесін пайдалану арқылы crate `core` болып өзгертіледі, яғни ол келесідей болады

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

Cargo компиляторды шақырғанда, компилятор енгізген `extern crate core` айқын емес директивасын қанағаттандырады.




