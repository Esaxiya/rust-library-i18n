`core::arch` - Rust негізгі архитектурасына арналған ішкі архитектура
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` модулі архитектураға тәуелді ішкі материалдарды (мысалы, SIMD) жүзеге асырады.

# Usage 

`core::arch` `libcore` бөлігі ретінде қол жетімді және оны `libstd` қайта экспорттайды.Оны crate-ге қарағанда `core::arch` немесе `std::arch` арқылы қолданған жөн.
Тұрақсыз мүмкіндіктер көбінесе түнгі Rust-де `feature(stdsimd)` арқылы қол жетімді.

`core::arch`-ті осы crate арқылы пайдалану түнгі Rust-ті қажет етеді және ол жиі бұзылуы мүмкін (және).Оны осы crate арқылы қолдануды қарастыратын жалғыз жағдайлар:

* егер сізге `core::arch` компиляциясын қайтадан құрастыру қажет болса, мысалы, `libcore`/`libstd` үшін қосылмаған мақсатты мүмкіндіктер қосулы болса.
Note: егер сізге оны стандартты емес мақсат үшін қайта компиляциялау қажет болса, онда осы crate орнына `xargo` және `libcore`/`libstd` қайта құрастыруды жөн көріңіз.
  
* тұрақсыз Rust мүмкіндіктерінің артында қол жетімді болмайтын кейбір мүмкіндіктерді пайдалану.Біз бұларды барынша азайтуға тырысамыз.
Егер сізге осы мүмкіндіктердің кейбірін пайдалану қажет болса, біз оларды түнде Rust-де көрсете алуымыз үшін және сіз оларды сол жерден пайдалана алуыңыз үшін мәселені ашыңыз.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` ең алдымен MIT лицензиясының және Apache лицензиясының (2.0 нұсқасы) шарттары бойынша таратылады, оның бөліктері әртүрлі BSD тәрізді лицензиялармен қамтылған.

Толығырақ ақпарат алу үшін LICENSE-APACHE және LICENCE-MIT бөлімін қараңыз.

# Contribution

Егер сіз басқаша айтпаған болсаңыз, Apache-2.0 лицензиясында анықталғандай, сіз `core_arch`-ке қосу үшін әдейі ұсынған кез-келген жарна, қосымша шарттарсыз, жоғарыда көрсетілгендей қос лицензиялы болады.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












