use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Біздің `#[assert_instr]` аннотацияларымызға барлық қарапайым интриникалар өздерінің кодогендерін тексеру үшін қол жетімді деп айту үшін қолданылады, өйткені кейбіреулері дәл қазір `#[target_feature]`-те баламасы жоқ қосымша `-Ctarget-feature=+unimplemented-simd128` артында тұр.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}