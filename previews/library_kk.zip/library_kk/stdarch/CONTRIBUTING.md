# Stdarch-ке үлес қосу

`stdarch` crate жарналарды қабылдауға дайын!Алдымен сіз репозиторийді тексеріп, сіз үшін тестілеудің өтуіне көз жеткізгіңіз келуі мүмкін:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Мұндағы `<your-target-arch>`-бұл `rustup` пайдаланған мақсатты үштік, мысалы, `x86_x64-unknown-linux-gnu` (алдыңғы `nightly-` немесе осыған ұқсас жағдайсыз).
Бұл репозиторийге Rust түнгі арнасы қажет екенін ұмытпаңыз!
Жоғарыда келтірілген тестілер шын мәнінде түнгі rust жүйесінде `rustup default nightly` (және қалпына келтіру үшін `rustup default stable`) қолдануын орнату үшін әдепкі күйде болуын талап етеді.

Егер жоғарыда аталған қадамдардың кез-келгені жұмыс істемесе, [please let us know][new]!

Келесіде сіз [find an issue][issues]-ке көмектесе аласыз, біз [`help wanted`][help] және [`impl-period`][impl] тегтерімен бірнеше таңдап алдық, олар кейбір көмектерді қолдана алады. 
Сізді [#40][vendor] қызықтыруы мүмкін, бұл x86-да барлық сатушылардың ішкі материалдарын қолдана алады.Бұл мәселе неден бастау керектігі туралы жақсы нұсқауларға ие!

Егер сізде жалпы сұрақтар болса, [join us on gitter][gitter]-ті ұнатыңыз және сұраңыз!Сұрақтарыңыз болса,@BurntSushi немесе@alexcrichton пингтен қорықпаңыз.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Stdarch intrinsics үшін мысалдарды қалай жазуға болады

Берілген ішкі жүйенің дұрыс жұмыс істеуі үшін бірнеше мүмкіндіктер қосылуы керек және мысалы, процессор қолдағанда ғана мысалды `cargo test --doc` іске қосуы керек.

Нәтижесінде `rustdoc` құратын әдепкі `fn main` жұмыс істемейді (көп жағдайда).
Мысал күткендей жұмыс істейтініне көз жеткізу үшін келесілерді нұсқаулық ретінде қолдануды қарастырыңыз.

```rust
/// # // Мысал тек қана болу үшін бізге cfg_target_feature керек
/// # // CPU функцияны қолдайтын кезде `cargo test --doc` басқарады
/// # #![feature(cfg_target_feature)]
/// # // Бізге жұмыс істеу үшін target_feature керек
/// # #![feature(target_feature)]
/// #
/// # // rustdoc әдепкі бойынша `extern crate stdarch` пайдаланады, бірақ бізге қажет
/// # // `#[macro_use]`
/// # # [макро_қолдану] extern crate stdarch;
/// #
/// # // Нақты негізгі функция
/// # fn main() {
/// #     // Мұны тек `<target feature>` қолдау көрсетілетін болса ғана іске қосыңыз
/// #     егер cfg_feature_enabled! («<target feature>«){
/// #         // Мақсатты мүмкіндік болған жағдайда ғана іске қосылатын `worker` функциясын жасаңыз
/// #         // қолдау көрсетіледі және сіздің жұмысшыңыз үшін `target_feature` қосулы екеніне көз жеткізіңіз
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         қауіпті fn worker() {
/// // Мысалыңызды осы жерге жазыңыз.Мұнда өзіндік ерекшеліктер жұмыс істейді!Жабайы бол!
///
/// #         }
///
/// #         қауіпті { worker(); }
/// #     }
/// # }
```

Егер жоғарыдағы синтаксистің кейбіреулері таныс болып көрінбесе, [Rust Book] бөліміндегі [Documentation as tests] бөлімі `rustdoc` синтаксисін жақсы сипаттайды.
Әдеттегідей, [join us on gitter][gitter]-тен қорықпаңыз және бізден қандай да бір соққыға ұрынған-соқпағаныңызды сұраңыз және `stdarch` құжаттамасын жақсартуға көмектескеніңіз үшін рақмет!

# Балама тестілеу нұсқаулары

Әдетте, сынақтарды өткізу үшін `ci/run.sh` пайдалану ұсынылады.
Бірақ бұл сіз үшін жұмыс істемеуі мүмкін, мысалы, егер сіз Windows жүйесінде болсаңыз.

Бұл жағдайда сіз кодты генерациялауды тексеру үшін `cargo +nightly test` және `cargo +nightly test --release -p core_arch` іске қосылуға болады.
Мұнда түнгі құралдар тақтасы орнатылып, `rustc` сіздің мақсатты үштік және оның процессоры туралы білуі керек екенін ескеріңіз.
Атап айтқанда, `TARGET` ортасының айнымалысын `ci/run.sh` үшін орнатқаныңыз жөн.
Сонымен қатар, мақсатты ерекшеліктерді көрсету үшін `RUSTCFLAGS` (`C` керек) орнату керек, мысалы `RUSTCFLAGS="-C -target-features=+avx2"`.
Егер сіз "just"-ті қазіргі CPU-ға қарсы дамып жатсаңыз, сіз `-C -target-cpu=native`-ны орната аласыз.

Осы баламалы нұсқауларды қолданған кезде, мысалы, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good] екенін ескертіңіз
нұсқауды жасау сынақтары сәтсіздікке ұшырауы мүмкін, себебі бөлшектегіш оларды басқаша атады, мысалы
ол `aesenc` нұсқауларының орнына олардың мінез-құлқына қарамастан `vaesenc` шығаруы мүмкін.
Сондай-ақ, бұл нұсқаулар әдеттегідей аз сынақтарды орындайды, сондықтан сіз ақыр соңында сұрау салған кезде кейбір қателер осы жерде қарастырылмаған тесттер үшін пайда болуы мүмкін деп таңданбаңыз.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






