# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate құжаттамасын қараңыз.