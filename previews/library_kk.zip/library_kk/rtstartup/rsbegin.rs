// rsbegin.o және rsend.o-бұл "compiler runtime startup objects" деп аталады.
// Оларда компилятордың жұмыс уақытын дұрыс инициализациялауға қажетті код бар.
//
// Орындалатын немесе dylib кескіні байланыстырылған кезде, барлық пайдаланушы коды мен кітапханалары осы екі нысан файлының арасында "sandwiched" болады, сондықтан код немесе rsbegin.o деректері кескіннің тиісті бөлімдерінде бірінші орын алады, ал кодтар мен rsend.o деректері соңғыларына айналады.
// Бұл эффект бөлімнің басында немесе соңында символдарды орналастыру үшін, сондай-ақ қажетті колонтитулдарды немесе колонтитулдарды кірістіру үшін қолданыла алады.
//
// Модульдің нақты кіру нүктесі C жұмыс уақытын іске қосу нысанында орналасқанын ескеріңіз (әдетте `crtX.o` деп аталады), содан кейін басқа жұмыс уақыты компоненттерінің инициализациясының кері байланысын шақырады (басқа арнайы сурет бөлімі арқылы тіркелген).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Стек жақтауының ашылуы туралы ақпарат бөлімін белгілейді
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Қаражаттың ішкі кітаптарын жүргізуге арналған сызаттар орны.
    // Бұл $ GCC/unwind-dw2-fde.h ішіндегі `struct object` ретінде анықталған.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // registration/deregistration процедураларын ашыңыз.
    // Libpanic_unwind құжаттарын қараңыз.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // модульді іске қосу туралы ақпараттарды тіркеу
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // өшіру кезінде тіркеуден шығарыңыз
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW арнайы init/uninit күнделікті тіркеуі
    pub mod mingw_init {
        // MinGW іске қосу объектілері (crt0.o/dllcrt0.o) іске қосу және шығу кезінде .ctors және .dtors бөлімдеріндегі глобалды конструкторларды шақырады.
        // DLL-де бұл DLL жүктелген және түсірілген кезде жасалады.
        //
        // Байланыстырушы бөлімдерді сұрыптайды, бұл біздің кері байланысымыздың тізімнің соңында орналасуын қамтамасыз етеді.
        // Конструкторлар кері тәртіпте жұмыс істейтіндіктен, бұл біздің кері байланысымыздың бірінші және соңғы орындалуын қамтамасыз етеді.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C инициализациясының кері байланысы
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: С-ті тоқтату
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}