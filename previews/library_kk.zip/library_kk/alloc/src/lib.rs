//! # Rust негізгі жинақ және кітапхана
//!
//! Бұл кітапхана үймеге бөлінген мәндерді басқаруға арналған ақылды көрсеткіштер мен жинақтамалар ұсынады.
//!
//! Бұл кітапхана, әдетте libcore сияқты, тікелей пайдаланудың қажеті жоқ, өйткені оның мазмұны [`std` crate](../std/index.html)-те қайта экспортталады.
//! `#![no_std]` атрибутын қолданатын Crates, әдетте, `std` тәуелді болмайды, сондықтан олар оның орнына crate қолданады.
//!
//! ## Қораптағы мәндер
//!
//! [`Box`] түрі-ақылды нұсқағыш типі.[`Box`] иесінің біреуі ғана болуы мүмкін, ал иесі үйіндіде өмір сүретін мазмұнды өзгертуге шешім қабылдауы мүмкін.
//!
//! Бұл типті ағындар арасында тиімді жіберуге болады, өйткені `Box` мәнінің өлшемі көрсеткіштің өлшемімен бірдей.
//! Ағаш тәрізді мәліметтер құрылымы көбінесе қораптармен салынады, өйткені әр түйіннің тек бір иесі, ата-анасы болады.
//!
//! ## Анықтамалық көрсеткіштер
//!
//! [`Rc`] түрі-бұл жіптің ішінде жадыны ортақ пайдалануға арналған, қауіпті емес сілтеме болып саналатын сілтеме түрі.
//! [`Rc`] көрсеткіші `T` типін орайды және тек `&T`-ке қол жеткізуге мүмкіндік береді.
//!
//! Бұл түр тұқым қуалайтын өзгергіштік (мысалы, [`Box`] қолдану) бағдарлама үшін өте шектеулі болған кезде пайдалы болады және мутацияға жол беру үшін көбінесе [`Cell`] немесе [`RefCell`] типтерімен жұптасады.
//!
//!
//! ## Есептелген көрсеткіштерге атомдық сілтеме
//!
//! [`Arc`] типі-бұл [`Rc`] типіндегі ағындардың қауіпсіз эквиваленті.Ол [`Rc`]-тің бірдей функционалдығын қамтамасыз етеді, тек егер `T` типінің ортақ болатындығын талап етпесе.
//! Сонымен қатар, [`Arc<T>`][`Arc`] өзі жіберіледі, ал [`Rc<T>`][`Rc`] жоқ.
//!
//! Бұл тип қамтылған деректерге ортақ қол жеткізуге мүмкіндік береді және көбінесе ортақ ресурстардың мутациясына мүмкіндік беру үшін мутекс сияқты синхрондау примитивтерімен жұптасады.
//!
//! ## Collections
//!
//! Бұл кітапханада ең көп таралған жалпы мақсаттағы құрылымдардың орындалуы анықталған.Олар [standard collections library](../std/collections/index.html) арқылы қайта экспортталады.
//!
//! ## Үйме интерфейстер
//!
//! [`alloc`](alloc/index.html) модулі төмен деңгейлі интерфейсті әдепкі ғаламдық бөлгішке анықтайды.Ол libc үлестіргіш API-мен үйлесімді емес.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Техникалық тұрғыдан бұл rustdoc-тағы қате: rustdoc `#[lang = slice_alloc]` блоктарындағы құжаттарды `&[T]` үшін көреді, сонымен бірге бұл мүмкіндікті `core`-де қолданатын құжаттары бар және мүмкіндік қақпасы қосылмағанына ашуланады.
// Ең дұрысы, бұл басқа crates құжаттарына арналған мүмкіндіктер қақпасын тексере алмас еді, бірақ бұл тек тіл элементтері үшін пайда болатындықтан, оны түзетудің қажеті жоқ сияқты.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Осы кітапхананы тексеруге рұқсат етіңіз

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Басқа модульдер қолданатын ішкі макростармен модуль (басқа модульдерден бұрын қосу керек).
#[macro_use]
mod macros;

// Төмен деңгейдегі бөлу стратегиялары қарастырылған

pub mod alloc;

// Жоғарыдағы үйінділерді қолданатын алғашқы типтер

// Cfg-ге құрастыру кезінде тіл элементтерін қайталамау үшін `boxed.rs` модулін шартты түрде анықтау қажет;сонымен қатар кодқа `use boxed::Box;` декларациясына рұқсат беру керек.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}