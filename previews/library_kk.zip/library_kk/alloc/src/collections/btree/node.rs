// Бұл идеалға сәйкес жүзеге асыруға тырысу
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust-де тәуелді типтер мен полиморфтық рекурсия болмағандықтан, біз көптеген қауіпсіздікті жасаймыз.
//

// Бұл модульдің негізгі мақсаты-ағашты жалпы (егер біртүрлі пішінді болса) контейнер ретінде қарастырып, B-Tree инварианттарының көпшілігімен жұмыс жасамау арқылы қиындықтардан аулақ болу.
//
// Осылайша, бұл модуль жазбалардың сұрыпталғанына, қандай түйіндер толық емес болуы мүмкін екеніне, тіпті толық емес дегенді білдірмейді.Алайда, біз бірнеше инварианттарға сүйенеміз:
//
// - Ағаштарда бірыңғай depth/height болуы керек.Бұл дегеніміз, берілген түйіннен жапыраққа дейінгі барлық жолдардың ұзындығы бірдей.
// - Ұзындығы `n` түйінінде `n` кілттері, `n` мәндері және `n + 1` шеттері болады.
//   Бұл тіпті бос түйіннің де кем дегенде бір edge болатындығын білдіреді.
//   Жапырақ түйіні үшін "having an edge" тек түйіндегі орынды анықтай аламыз дегенді білдіреді, өйткені жапырақ жиектері бос және мәліметтерді ұсынудың қажеті жоқ.
// Ішкі түйінде edge позицияны анықтайды және еншілес түйінге нұсқауыш алады.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Жапырақ түйіндерінің негізгі көрінісі және ішкі түйіндердің көрінісі.
struct LeafNode<K, V> {
    /// Біз `K` және `V` нұсқаларында ковариантты болғымыз келеді.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Бұл түйіннің ата-аналық `edges` массивіндегі индексі.
    /// `*node.parent.edges[node.parent_idx]` `node` сияқты болуы керек.
    /// Мұны `parent` нөлге тең болмаған кезде ғана бастауға кепілдік беріледі.
    parent_idx: MaybeUninit<u16>,

    /// Бұл түйінді сақтайтын кілттер мен мәндер саны.
    len: u16,

    /// Түйіннің нақты деректерін сақтайтын массивтер.
    /// Әр массивтің тек алғашқы `len` элементтері инициализацияланған және жарамды.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Жаңа `LeafNode` орнында инициализациялайды.
    unsafe fn init(this: *mut Self) {
        // Жалпы саясат ретінде біз өрістерді инициализацияланбаған күйде қалдырамыз, өйткені егер олар мүмкін болса, онда ол сәл тезірек және Valgrind-та бақылау оңайырақ болуы керек.
        //
        unsafe {
            // parent_idx, кілттер мен валдар-бәрі мүмкін
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Жаңа қораптағы `LeafNode` жасайды.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Ішкі түйіндердің негізгі көрінісі.«LeafNode» сияқты, инициалданбаған кілттер мен мәндердің түсіп қалуын болдырмау үшін оларды «BoxedNode» артында жасыру керек.
/// `InternalNode` кез келген нұсқағышты түйіннің негізгі `LeafNode` бөлігінің көрсеткішіне тікелей жіберуге болады, бұл кодтың жапсырма мен ішкі түйіндерде генеральды түрде әрекет етуіне мүмкіндік береді, тіпті сілтегіштің екеуінің қайсысын көрсетіп тұрғанын тексермейді.
///
/// Бұл сипат `repr(C)` пайдалану арқылы қосылады.
///
#[repr(C)]
// gdb_providers.py интроспекция үшін осы түрдегі атауды қолданады.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Осы түйіннің балаларына сілтемелер.
    /// `len + 1` бұлар инициализацияланған және жарамды болып саналады, тек аяғына дейін, ағаш `Dying` типтегі қарыздар арқылы ұсталса, кейбір көрсеткіштер салбырап тұр.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Жаңа қораптағы `InternalNode` жасайды.
    ///
    /// # Safety
    /// Ішкі түйіндердің инварианты-олардың кем дегенде бір инициализацияланған және жарамды edge болуы.
    /// Бұл функция мұндай edge орнатпайды.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Бізге тек деректерді инициализациялау керек;шеттері мүмкін-белгісіз.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Түйінге басқарылатын, нөлдік емес көрсеткіш.Бұл `LeafNode<K, V>`-ге тиесілі сілтеме немесе `InternalNode<K, V>`-ге тиесілі сілтеме.
///
/// Алайда, `BoxedNode` құрамында түйіндердің екі түрінің қайсысы бар екендігі туралы ақпарат жоқ, және ішінара осы ақпараттың жетіспеуіне байланысты жеке тип емес және деструкторы жоқ.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Меншікті ағаштың түбірлік түйіні.
///
/// Мұнда деструктор жоқ екенін ескеріңіз және оны қолмен тазалау керек.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Бастапқыда бос түбір түйіні бар жаңа меншікті ағашты қайтарады.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` нөлге тең болмауы керек.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Меншікті түбірлік түйінді қарызға алады.
    /// `reborrow_mut`-тен айырмашылығы, бұл қауіпсіз, өйткені қайтарылатын мән түбірді жою үшін қолданыла алмайды және ағашқа басқа сілтемелер болуы мүмкін емес.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Меншікті түбірлік түйінді сәл өзгертеді.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Айналдыруға жол беретін және бүлдіргіш әдістерді ұсынатын анықтамаға қайтымсыз ауысады.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Алдыңғы түбір түйініне бағытталған жалғыз edge көмегімен жаңа ішкі түйінді қосады, сол түйінді түбірлік түйінге айналдырады және оны қайтарады.
    /// Бұл биіктікті 1-ге арттырады және `pop_internal_level`-ке керісінше.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, тек өзіміздің ішкі екенімізді ұмытып кеткеніміз болмаса:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ішкі түбір түйінін алып тастайды, оның алғашқы туындысын жаңа түбір түйіні ретінде қолданады.
    /// Бұл тек түбірлік түйінде бір ғана бала болған кезде ғана шақырылатын болғандықтан, кілттердің, мәндердің және басқа балалардың ешқайсысында тазалау жасалмайды.
    ///
    /// Бұл биіктікті 1-ге азайтады және `push_internal_level`-ке керісінше.
    ///
    /// `Root` объектісіне эксклюзивті қол жетімділікті талап етеді, бірақ түбірлік түйінге емес;
    /// ол басқа тұтқаларды немесе түбірлік түйінге сілтемелерді жарамсыз етпейді.
    ///
    /// Егер ішкі деңгей болмаса Panics, яғни тамыр түйіні жапырақ болса.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // ҚАУІПСІЗДІК: біз ішкі деп мәлімдедік.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // ҚАУІПСІЗДІК: біз тек `self`-ті қарызға алдық және оның түрі тек ерекше болып табылады.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // ҚАУІПСІЗДІК: бірінші edge әрдайым инициализацияланады.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` әрқашан `K` және `V`-те ковариантты, тіпті `BorrowType` `Mut` болғанда да.
// Бұл техникалық тұрғыдан дұрыс емес, бірақ `NodeRef` ішкі пайдаланылуына байланысты қауіпсіздікті тудыруы мүмкін емес, өйткені біз `K` және `V` кезінде толықтай боламыз.
//
// Дегенмен, ашық тип `NodeRef`-ті орап алған сайын, оның дұрыс дисперсиясына көз жеткізіңіз.
//
/// Түйінге сілтеме.
///
/// Бұл типте оның қалай жұмыс істейтінін басқаратын бірқатар параметрлер бар:
/// - `BorrowType`: Несие түрін сипаттайтын және өмір бойына алып жүретін манекен түрі.
///    - Бұл `Immut<'a>` болғанда, `NodeRef` шамамен `&'a Node` сияқты әрекет етеді.
///    - Бұл `ValMut<'a>` болған кезде, `NodeRef` кілттер мен ағаш құрылымына қатысты шамамен `&'a Node` сияқты әрекет етеді, сонымен қатар бүкіл ағаштағы мәндерге көптеген өзгермелі сілтемелердің қатар өмір сүруіне мүмкіндік береді.
///    - Бұл `Mut<'a>` болған кезде, `NodeRef` шамамен `&'a mut Node` сияқты әрекет етеді, дегенмен кірістіру әдістері өзгертілетін көрсеткішке мәннің қатар өмір сүруіне мүмкіндік береді.
///    - Бұл `Owned` болған кезде, `NodeRef` шамамен `Box<Node>` сияқты әрекет етеді, бірақ деструкторы жоқ және оны қолмен тазалау керек.
///    - Бұл `Dying` болған кезде, `NodeRef` шамамен `Box<Node>` сияқты әрекет етеді, бірақ ағашты аздап жою әдістері бар, ал қарапайым әдістер қоңырау шалу қауіпті деп белгіленбесе де, UB қате шақырылса, оны шақыра алады.
///
///   Кез-келген `NodeRef` ағаш арқылы жылжуға мүмкіндік беретіндіктен, `BorrowType` түйіннің өзіне ғана емес, бүкіл ағашқа тиімді қолданылады.
/// - `K` және `V`: Бұл түйіндерде сақталатын кілттер мен мәндердің түрлері.
/// - `Type`: Бұл `Leaf`, `Internal` немесе `LeafOrInternal` болуы мүмкін.
/// Бұл `Leaf` болғанда, `NodeRef` жапырақ түйінін, ал `Internal` болғанда `NodeRef` ішкі түйінді, ал егер `LeafOrInternal` болғанда `NodeRef` түйіннің кез-келген түрін көрсетуі мүмкін.
///   `Type` `NodeRef` сыртында қолданылған кезде `NodeType` деп аталады.
///
/// `BorrowType` және `NodeType` екеуі де статикалық типтегі қауіпсіздікті пайдалану үшін қандай әдістерді қолданатынымызды шектейді.Мұндай шектеулерді қолдануымызда шектеулер бар:
/// - Әр типтің параметрі үшін біз әдісті тек жалпылама түрде немесе белгілі бір тип үшін анықтай аламыз.
/// Мысалы, біз `into_kv` сияқты әдісті барлық `BorrowType` үшін жалпылай анықтай алмаймыз немесе өмір бойы жүретін барлық типтер үшін бір рет анықтай алмаймыз, өйткені оның `&'a` сілтемелерін қайтарғанын қалаймыз.
///   Сондықтан біз оны тек қуаты аз `Immut<'a>` типіне анықтаймыз.
/// - Біз `Mut<'a>`-тен `Immut<'a>`-ге дейін мәжбүрлеуді ала алмаймыз.
///   Сондықтан `into_kv` сияқты әдіске жету үшін біз `reborrow`-ті неғұрлым қуатты `NodeRef`-ке қоңырау шалуымыз керек.
///
/// `NodeRef`-тегі барлық сілтемелерді қайтаратын барлық әдістер:
/// - `self` мәнін алыңыз және `BorrowType` тасымалдайтын қызмет ету мерзімін қайтарыңыз.
///   Кейде мұндай әдісті қолдану үшін біз `reborrow_mut` телефонына қоңырау шалуымыз керек.
/// - `self` сілтемесі бойынша алыңыз, және (implicitly) бұл сілтеменің өмір сүру уақытын қайтарады, оның орнына `BorrowType` тасымалдайды.
/// Осылайша, қарызды тексеруші қайтарылған сілтеме қолданылғанша, `NodeRef` қарыз болып қала беретініне кепілдік береді.
///   Кірістіруді қолдайтын әдістер шикі көрсеткішті, яғни сілтемені өмір бойы қайтару арқылы осы ережені бүгеді.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Түйін мен жапырақтардың деңгейі бөлек деңгейлердің саны, бұл `Type` арқылы толығымен сипаттала алмайтын және түйіннің өзі сақтамайтын түйіннің тұрақтысы.
    /// Бізге тек түбірлік түйіннің биіктігін сақтау керек және одан барлық басқа түйіндердің биіктігін алу керек.
    /// Егер `Type` `Leaf` болса нөлге, ал `Type` `Internal` болса нөлге тең болмауы керек.
    ///
    ///
    height: usize,
    /// Жапыраққа немесе ішкі түйінге көрсеткіш.
    /// `InternalNode` анықтамасы көрсеткіштің кез келген жағдайда жарамды болуын қамтамасыз етеді.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` ретінде оралған түйін сілтемесін ораудан шығарыңыз.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ішкі түйіннің деректерін ашады.
    ///
    /// Осы түйінге басқа сілтемелерді жарамсыз етпеу үшін бастапқы ptr мәнін қайтарады.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // ҚАУІПСІЗДІК: статикалық түйін түрі-`Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ішкі түйіннің деректеріне эксклюзивті рұқсатты алады.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Түйіннің ұзындығын табады.Бұл кілттердің немесе мәндердің саны.
    /// Жиектер саны-`len() + 1`.
    /// Қауіпсіздігіне қарамастан, бұл функцияны шақыру қауіпті код жасаған өзгертілетін сілтемелерді жарамсыз етудің жанама әсері болуы мүмкін екенін ескеріңіз.
    ///
    pub fn len(&self) -> usize {
        // Біз `len` өрісіне осы жерде ғана қол жеткізе аламыз.
        // Егер BorrowType marker::ValMut болса, біз жарамсыз етпейтін мәндерге қатысты өзгермелі сілтемелер болуы мүмкін.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Түйін мен қалдырылған деңгейлер санын қайтарады.
    /// Нөлдік биіктік түйіннің өзі жапырақ екенін білдіреді.
    /// Егер сіз тамырларды үстіңгі жағымен бейнелейтін болсаңыз, онда сан түйіннің қандай биіктікте пайда болатынын айтады.
    /// Егер сіз жапырақтары бар ағаштарды бейнелейтін болсаңыз, сан ағаштың түйіннен қаншалықты биіктікте екенін көрсетеді.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Уақытша сол түйінге басқа, өзгермейтін сілтеме шығарады.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Кез-келген жапырақтың немесе ішкі түйіннің жапырақ бөлігін ашады.
    ///
    /// Осы түйінге басқа сілтемелерді жарамсыз етпеу үшін бастапқы ptr мәнін қайтарады.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Түйін кем дегенде LeafNode бөлігі үшін жарамды болуы керек.
        // Бұл NodeRef типіндегі сілтеме емес, өйткені біз оның ерекше немесе ортақ болуын білмейміз.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Ағымдағы түйіннің ата-анасын табады.
    /// Егер ағымдағы түйіннің ата-анасы болса, онда `Ok(handle)` қайтарады, мұндағы `handle` ата-ананың ағымдағы түйінге бағытталған edge-ге нұсқайды.
    ///
    /// Егер ағымдағы түйіннің ата-анасы болмаса, `NodeRef` түпнұсқасын қайтарып берсе, `Err(self)` қайтарады.
    ///
    /// Әдіс атауы сізде түйін түйіні бар ағаштарды бейнелейді деп болжайды.
    ///
    /// `edge.descend().ascend().unwrap()` және `node.ascend().unwrap().descend()` екеуі де сәттілікке қол жеткізген кезде ештеңе жасамауы керек.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Біз түйіндерге шикі көрсеткіштерді пайдалануымыз керек, өйткені егер BorrowType marker::ValMut болса, біз жарамсыз етпеуіміз керек мәндерге қатысты өзгермелі сілтемелер болуы мүмкін.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// `self` бос болмауы керек екенін ескеріңіз.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// `self` бос болмауы керек екенін ескеріңіз.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Өзгермейтін ағаштағы кез-келген жапырақтың немесе ішкі түйіннің жапырақ бөлігін ашады.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // ҚАУІПСІЗДІК: бұл ағашқа `Immut` ретінде өзгертілетін сілтемелер болуы мүмкін емес.
        unsafe { &*ptr }
    }

    /// Түйінде сақталған кілттерге көріністі қарызға алады.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend`-ге ұқсас, түйіннің ата-аналық түйініне сілтеме алады, сонымен қатар процестегі ағымдағы түйінді бөледі.
    /// Бұл қауіпті, себебі бөлінгеніне қарамастан, ағымдағы түйінге қол жетімді болады.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Компиляторға бұл түйін `Leaf` екендігі туралы статикалық ақпаратты қауіпті деп санайды.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Компиляторға бұл түйін `Internal` екендігі туралы статикалық ақпаратты қауіпті деп санайды.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Уақытша сол түйінге басқа, өзгермелі сілтемені шығарады.Сақ болыңыз, өйткені бұл әдіс өте қауіпті, екі есе көп, өйткені ол бірден қауіпті болып көрінбеуі мүмкін.
    ///
    /// Өзгеретін көрсеткіштер ағаштың кез-келген жерінде жүре алатындықтан, қайтарылған меңзерді түпнұсқа меңзерді іліп қою үшін, шектерден тыс немесе қабаттасып алынған қарыз ережелері бойынша жарамсыз ету үшін оңай пайдалануға болады.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef`-ке тағы бір түрдегі параметрді қосуды қарастырыңыз, бұл қайта жаңартылған көрсеткіштерде навигация әдістерін пайдалануды шектейді, бұл қауіпсіздікті болдырмайды.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Кез-келген жапырақтың немесе ішкі түйіннің жапырақ бөлігіне эксклюзивті рұқсатты алады.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // ҚАУІПСІЗДІК: бізде барлық түйінге эксклюзивті қатынас бар.
        unsafe { &mut *ptr }
    }

    /// Кез-келген жапырақтың немесе ішкі түйіннің жапырақ бөлігіне эксклюзивті қол жетімділікті ұсынады.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // ҚАУІПСІЗДІК: бізде барлық түйінге эксклюзивті қатынас бар.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Кілт сақтау аймағының элементіне эксклюзивті қол жетімділікті қарызға алады.
    ///
    /// # Safety
    /// `index` 0. .МҮМКІНДІК шектерінде
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // ҚАУІПСІЗДІК: қоңырау шалушы өздігінен басқа әдістерді шақыра алмайды
        // негізгі тілім сілтемесі жойылғанға дейін, өйткені біз қарыз алу мерзіміне бірегей қол жеткізе аламыз.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Түйіннің сақтау аймағының элементіне немесе тіліміне ерекше қатынасты алады.
    ///
    /// # Safety
    /// `index` 0. .МҮМКІНДІК шектерінде
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // ҚАУІПСІЗДІК: қоңырау шалушы өздігінен басқа әдістерді шақыра алмайды
        // Қарыз алу мерзімінде бірегей қол жетімділікке ие болғандықтан, құнды кесіндіге сілтеме түскенге дейін.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge мазмұны үшін түйіннің сақтау аймағының элементіне немесе тіліміне эксклюзивті рұқсатты алады.
    ///
    /// # Safety
    /// `index` 0 шегінде ... СЫЙЫМДЫҚ + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // ҚАУІПСІЗДІК: қоңырау шалушы өздігінен басқа әдістерді шақыра алмайды
        // edge тілім сілтемесі жойылғанға дейін, өйткені қарыз алу мерзімінде бізде бірегей қол жетімділік бар.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Түйінде `idx` инициалданған элементтері көп.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Біз өзімізді қызықтыратын бір элементке сілтеме жасаймыз, бұл басқа элементтерге, атап айтқанда, қоңырау шалушыға бұрынғы итерацияда қайтарылған сілтемелерге ие болуы мүмкін.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust #74679 шығарылымы болғандықтан, массивтің өлшемсіз көрсеткіштеріне мәжбүр етуіміз керек.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Түйін ұзындығына эксклюзивті қол жетімділікті қарызға алады.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Түйінге сілтемелерді жарамсыз етіп, оның edge ата-анасымен байланысын орнатады.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Түбірдің ата-анасына edge сілтемесін тазартады.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Түйіннің соңына кілт-мән жұбын қосады.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` қайтарған әрбір элемент түйін үшін жарамды edge индексі болып табылады.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Түйіннің соңына, сол жұптың оң жағына өту үшін кілт мәнінің жұбын және edge қосады.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Түйін `Internal` немесе `Leaf` түйіні екенін тексереді.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Түйін ішіндегі белгілі бір кілттер жұбына немесе edge сілтемесі.
/// `Node` параметрі `NodeRef` болуы керек, ал `Type` не `KV` (тұтқаны кілт мәнінің жұбында білдіреді) немесе `Edge` (edge-де тұтқаны білдіреді) болуы мүмкін.
///
/// `Leaf` түйіндерінде де `Edge` тұтқалары болуы мүмкін екенін ескеріңіз.
/// Сілтегішті еншілес түйінге ұсынудың орнына, олар пернелер тіркесімі кілттер мәні жұптары арасында жүретін кеңістікті білдіреді.
/// Мысалы, ұзындығы 2 түйінде 3 edge орналасуы мүмкін, біреуі түйіннің сол жағында, екеуі екі жұп арасында, ал біреуі түйіннің оң жағында.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Бізге `#[derive(Clone)]` толық жалпылығының қажеті жоқ, өйткені `Node` тек «Clone» болады, бұл өзгермейтін сілтеме болғанда, сондықтан `Copy` болады.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Осы атқаратын қызметім сілтейтін edge немесе кілт-мән жұбын қамтитын түйінді шығарады.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Осы түйіннің түйіндегі орнын қайтарады.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node`-те кілт-мәндік жұптың жаңа тұтқасын жасайды.
    /// Қауіпті, себебі қоңырау шалушы `idx < node.len()` екеніне көз жеткізуі керек.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq-тің көпшілікке ұсынуы болуы мүмкін, бірақ тек осы модульде қолданылады.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Уақытша сол жерде басқа, өзгермейтін тұтқаны шығарады.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Біз Handle::new_kv немесе Handle::new_edge қолдана алмаймыз, өйткені біз өз түрімізді білмейміз
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Компиляторға тұтқалардың түйіні `Leaf` екендігі туралы статикалық ақпаратты қауіпті деп санайды.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Уақытша сол жерде басқа, өзгермелі тұтқаны шығарады.
    /// Сақ болыңыз, өйткені бұл әдіс өте қауіпті, екі есе көп, өйткені ол бірден қауіпті болып көрінбеуі мүмкін.
    ///
    ///
    /// Толық ақпаратты `NodeRef::reborrow_mut` бөлімінен қараңыз.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Біз Handle::new_kv немесе Handle::new_edge қолдана алмаймыз, өйткені біз өз түрімізді білмейміз
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node`-те edge жаңа тұтқасын жасайды.
    /// Қауіпті, себебі қоңырау шалушы `idx <= node.len()` екенін қамтамасыз етуі керек.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Толтырылған түйінге қосқымыз келетін edge индексін ескере отырып, бөлінген нүктенің KV индексін және кірістіруді қай жерде орындайтындығын есептейміз.
///
/// Бөлінген нүктенің мақсаты оның кілті мен мәні ата-аналық түйінге жетуінде;
/// бөліну нүктесінің сол жағындағы кілттер, мәндер мен шеттер сол жаққа айналады;
/// бөлу нүктесінің оң жағындағы кілттер, мәндер мен жиектер дұрыс бала болады.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust #74834 шығарылымы осы симметриялық ережелерді түсіндіруге тырысады.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Осы edge ішінен оңға және солға кілт мәні жұптарының арасына жаңа кілт мән жұбын енгізеді.
    /// Бұл әдіс түйінде жаңа жұптың сәйкес келуіне жеткілікті орын бар деп болжайды.
    ///
    /// Қайтарылған көрсеткіш енгізілген мәнге нұсқайды.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Осы edge ішінен оңға және солға кілт мәні жұптарының арасына жаңа кілт мән жұбын енгізеді.
    /// Егер бұл орын жеткіліксіз болса, бұл әдіс түйінді бөледі.
    ///
    /// Қайтарылған көрсеткіш енгізілген мәнге нұсқайды.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Осы edge байланыстыратын еншілес түйіндегі ата-аналық көрсеткіш пен индексті бекітеді.
    /// Бұл жиектердің реті өзгерген кезде пайдалы,
    fn correct_parent_link(self) {
        // Түйінге басқа сілтемелерді жарамсыз етіп кері сілтеме жасаңыз.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Осы edge мен осы edge оң жағындағы кілт мәні жұбы арасына жаңа жұптың оң жағына өтетін жаңа кілттер жұбын және edge қосады.
    /// Бұл әдіс түйінде жаңа жұптың сәйкес келуіне жеткілікті орын бар деп болжайды.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Осы edge мен осы edge оң жағындағы кілт мәні жұбы арасына жаңа жұптың оң жағына өтетін жаңа кілттер жұбын және edge қосады.
    /// Егер бұл орын жеткіліксіз болса, бұл әдіс түйінді бөледі.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Осы edge ішінен оңға және солға кілт мәні жұптарының арасына жаңа кілт мән жұбын енгізеді.
    /// Егер бұл орын жеткіліксіз болса, бұл әдіс түйінді бөліп, бөлінген бөлігін негізгі түйінге тамырға жеткенше рекурсивті түрде енгізуге тырысады.
    ///
    ///
    /// Егер қайтарылған нәтиже `Fit` болса, оның түйінінің түйіні осы edge түйіні немесе ата-бабасы болуы мүмкін.
    /// Егер қайтарылған нәтиже `Split` болса, `left` өрісі түбір түйіні болады.
    /// Қайтарылған көрсеткіш енгізілген мәнге нұсқайды.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Осы edge көрсетілген түйінді табады.
    ///
    /// Әдіс атауы сізде түйін түйіні бар ағаштарды бейнелейді деп болжайды.
    ///
    /// `edge.descend().ascend().unwrap()` және `node.ascend().unwrap().descend()` екеуі де сәттілікке қол жеткізген кезде ештеңе жасамауы керек.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Біз түйіндерге шикі көрсеткіштерді пайдалануымыз керек, өйткені егер BorrowType marker::ValMut болса, біз жарамсыз етпеуіміз керек мәндерге қатысты өзгермелі сілтемелер болуы мүмкін.
        // Биіктік өрісіне кіру алаңдаушылық тудырмайды, себебі бұл мән көшіріледі.
        // Сақ болыңыз, түйін көрсеткіші анықталғаннан кейін, біз жиектер жиегіне сілтеме арқылы қол жеткіземіз (Rust шығарылымы #73987) және массивке немесе оның ішіндегі басқа сілтемелерді, егер олар айналасында болса, жарамсыз етеді.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Біз бөлек кілт және мән әдістерін шақыра алмаймыз, өйткені екіншісін шақыру біріншісі қайтарған сілтемені жарамсыз етеді.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// KV тұтқасы сілтеме жасайтын кілт пен мәнді ауыстырыңыз.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Жапырақ туралы мәліметтерді күту арқылы белгілі бір `NodeType` үшін `split` іске асыруға көмектеседі.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Негізгі түйінді үш бөлікке бөледі:
    ///
    /// - Түйін қысқартылған, тек осы дескриптордың сол жағында кілт-мән жұптары болады.
    /// - Осы сапта көрсетілген кілт пен мән шығарылады.
    /// - Осы тұтқаның оң жағындағы барлық кілт мәні жұптары жаңадан бөлінген түйінге орналастырылған.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Осы дескриптормен көрсетілген кілттер мәнінің жұбын алып тастайды және оны кілт мәні жұбы құлап түскен edge мәнімен бірге қайтарады.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Негізгі түйінді үш бөлікке бөледі:
    ///
    /// - Түйін тек осы дескриптордың сол жағындағы жиектер мен кілт мәндерінің жұптарын қамтитын етіп кесіледі.
    /// - Осы сапта көрсетілген кілт пен мән шығарылады.
    /// - Осы тұтқаның оң жағындағы барлық шеттер мен кілт мәндерінің жұптары жаңадан бөлінген түйінге қойылады.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Ішкі кілт-мән жұбы бойынша теңдестіру әрекетін бағалауға және орындауға арналған сеансты ұсынады.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Балалық шақтағы түйінді қамтитын теңгерімді контекстті таңдайды, осылайша КВ арасында ата-ана түйінде бірден солға немесе оңға.
    /// Егер ата-ана болмаса, `Err` мәнін қайтарады.
    /// Panics, егер ата-ана бос болса.
    ///
    /// Егер берілген түйін қандай да бір мөлшерде толық емес болса, оңтайлы болуды сол жаққа ұнатады, яғни егер ол сол жақтағы інісіне қарағанда аз болса, ал егер олар бар болса, оң жақтағы інісіне қарағанда.
    /// Бұл жағдайда сол жақтағы бауырмен бірігу тезірек болады, өйткені біз оларды оңға жылжытпай, алдыңғы N элементтерден көп қозғалудың орнына, тек N элементін жылжытуымыз керек.
    /// Сол жақ бауырластан ұрлау, әдетте, тезірек жүреді, өйткені біз аға-інілер элементтерінің кем дегенде N-н солға жылжытпай, түйіннің N элементтерін оңға ауыстыруымыз керек.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Біріктіру мүмкін бе, жоқ па, орталық KV-ді екі көршілес түйіндермен біріктіруге жеткілікті орын бар ма, жоқ па дегенді қайтарады.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Біріктіруді орындайды және жабылуға не қайтарылатынын шешеді.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // ҚАУІПСІЗДІК: біріктірілген түйіндердің биіктігі биіктіктен төмен
                // осы edge түйінінің нөлінен жоғары, сондықтан олар ішкі болып табылады.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Ата-ананың кілт мәні жұбын және көршілес екі түйінді екі сол жақтағы түйінге біріктіріп, кішірейтілген ата-ана түйінін қайтарады.
    ///
    ///
    /// Panics, егер біз `.can_merge()` болмаса.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Ата-ананың кілт мәні жұбын және көршілес екі түйінді екі сол жақтағы түйінге біріктіріп, сол түйінді қайтарады.
    ///
    ///
    /// Panics, егер біз `.can_merge()` болмаса.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Ата-ананың кілт мәні жұбын және сол маңдағы еншілес түйіндерді сол жақтағы түйінге біріктіреді және edge қадағаланатын edge аяқталған сол түйіндегі edge дескрипторын қайтарады,
    ///
    ///
    /// Panics, егер біз `.can_merge()` болмаса.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Кілттер мәнінің жұбын сол жақтағы баладан алып тастап, оны ата-ананың кілттер қоймасына орналастырады, ал ескі ата-аналық кілттер мәнін дұрыс балаға итереді.
    ///
    /// `track_right_edge_idx` көрсетілген түпнұсқа edge аяқталған жерге сәйкес оң жақтағы edge-ге тұтқаны қайтарады.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Кілттер мәнінің жұбын оң жақтағы баладан алып тастайды және оны ата-ананың кілттер қоймасына орналастырады, ал ескі ата-аналық кілттер мәнін сол балаға итереді.
    ///
    /// Қозғалмайтын `track_left_edge_idx` көрсетілген сол жақтағы edge-ге дескрипторды қайтарады.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Бұл `steal_left` сияқты ұрлық жасайды, бірақ бірнеше элементтерді бірден ұрлайды.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Біздің қауіпсіз ұрлауымызға көз жеткізіңіз.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Парақ деректерін жылжыту.
            {
                // Ұрланған элементтерге дұрыс балада орын беріңіз.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Элементтерді сол баладан оңға қарай жылжытыңыз.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Ең көп ұрланған жұпты ата-анаға жылжытыңыз.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Ата-ананың негізгі мәндер жұбын дұрыс балаға жылжытыңыз.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Ұрланған шеттерге орын босатыңыз.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Шеттерін ұрлаңыз.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` симметриялы клоны.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Біздің қауіпсіз ұрлауымызға көз жеткізіңіз.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Парақ деректерін жылжыту.
            {
                // Ең ұрланған жұпты ата-анаға апарыңыз.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Ата-ананың кілт мәнінің жұбын сол жаққа жылжытыңыз.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Элементтерді оң баладан солға жылжытыңыз.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Бұрын ұрланған элементтер болған жерлерді толтырыңыз.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Шеттерін ұрлаңыз.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Бұрын ұрланған шеттер болған жерлерді толтырыңыз.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Бұл түйін `Leaf` түйіні екенін растайтын кез-келген статикалық ақпаратты жояды.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Бұл түйін `Internal` түйіні екенін дәлелдейтін кез-келген статикалық ақпаратты жояды.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Негізгі түйіннің `Internal` немесе `Leaf` түйіні екенін тексереді.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` қосымшасын бір түйіннен екінші түйінге ауыстырыңыз.`right` бос болуы керек.
    /// `right` бірінші edge өзгеріссіз қалады.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Енгізу нәтижесі, түйін оның сыйымдылығынан тыс кеңеюі керек болғанда.
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv` сол жағына жататын элементтері мен шеттері бар ағаштағы өзгертілген түйін.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Басқа жерге енгізу үшін кейбір кілттер мен мәндер бөлінеді.
    pub kv: (K, V),
    // `kv` оң жағына тиесілі элементтері мен шеттері бар жаңа түйін.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Осы қарыз түріндегі түйін сілтемелері ағаштағы басқа түйіндерге өтуге мүмкіндік береді.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Траверсаль қажет емес, бұл `borrow_mut` нәтижесін қолдану арқылы болады.
        // Траверсалды өшіріп, тек тамырларға жаңа сілтемелер жасай отырып, біз `Owned` типіндегі кез-келген сілтеме түбір түйініне жататынын білеміз.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Мәнді инициализацияланған элементтер тіліміне енгізеді, содан кейін бір инициализацияланбаған элемент.
///
/// # Safety
/// Тілікте `idx` элементтері көп.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Бір инициализацияланбаған элементті қалдырып, барлық инициалданған элементтердің кесіндісінен мәнді алып тастайды және қайтарады.
///
///
/// # Safety
/// Тілікте `idx` элементтері көп.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// `distance` позициясындағы элементтерді солға жылжытады.
///
/// # Safety
/// Тіліктің кем дегенде `distance` элементтері бар.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// `distance` позициясында элементтерді оңға жылжытады.
///
/// # Safety
/// Тіліктің кем дегенде `distance` элементтері бар.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Барлық мәндерді инициализацияланған элементтер тілімінен инициализацияланбаған элементтер тіліміне ауыстырады, және `src`-ті инициализацияланбаған ретінде қалдырады.
///
/// `dst.copy_from_slice(src)` сияқты жұмыс істейді, бірақ `T`-тің `Copy` болуын қажет етпейді.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;