use core::intrinsics;
use core::mem;
use core::ptr;

/// Бұл тиісті функцияны шақыру арқылы `v` бірегей сілтемесінің артындағы мәнді ауыстырады.
///
///
/// Егер `change` жабылуында panic пайда болса, онда барлық процесс тоқтатылады.
#[allow(dead_code)] // иллюстрация ретінде және future пайдалану үшін сақтаңыз
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Бұл тиісті функцияны шақыру арқылы `v` бірегей сілтемесінің артындағы мәнді ауыстырады және жол бойында алынған нәтижені қайтарады.
///
///
/// Егер `change` жабылуында panic пайда болса, онда барлық процесс тоқтатылады.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}