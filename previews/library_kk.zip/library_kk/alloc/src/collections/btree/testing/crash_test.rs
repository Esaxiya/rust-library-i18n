use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Белгілі бір оқиғаларды бақылап отыратын апаттық сынақтан өткен муляждық инстанцияларға арналған жоспар.
/// Кейбір даналар бір уақытта panic-ге теңшелуі мүмкін.
/// Оқиғалар-`clone`, `drop` немесе белгісіз `query`.
///
/// Апаттық тест муляждары идентификатормен анықталады және тапсырыс береді, сондықтан оларды BTreeMap-да кілт ретінде пайдалануға болады.
/// Іске асыру әдейі қолданады, `Debug` trait қоспағанда, crate-де анықталған ештеңеге сүйенбейді.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Апатқа қарсы тесттің муляждық дизайнын жасайды.`id` даналардың реті мен теңдігін анықтайды.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Қандай оқиғаларды бастан өткеретінін және panics-ті таңдап алатын апаттық тест-муляждың данасын жасайды.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Думиннің неше рет көшірілгенін қайтарады.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Думиннің неше рет түсірілгенін қайтарады.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// `query` мүшесі қанша рет қолданылған манекеннің даналарын қайтарады.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Нәтижесі қазірдің өзінде берілген кейбір жасырын сұрау.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}