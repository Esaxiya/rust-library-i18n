use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Жол бойында `length` айнымалысын көбейте отырып, екі көтерілетін итераторлардың бірігуінен барлық кілт мәндерінің жұптарын қосады.Соңғысы қоңырау шалушыға тамшы өңдеуші үрейленіп жатқанда, ағып кетпеуді жеңілдетеді.
    ///
    /// Егер екі итератор бірдей кілт шығарса, онда бұл әдіс жұпты сол итератордан түсіреді және оң итератордан жұпты қосады.
    ///
    /// Егер сіз ағаштың `BTreeMap` сияқты қатаң өсу ретімен аяқталуын қаласаңыз, екі итератор да кілттерді қатаң өсу ретімен шығаруы керек, олардың әрқайсысы ағаштағы барлық кілттерден үлкен, сонымен қатар кірген кезде ағашта болған кез-келген кілттерді қосуы керек.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Біз `left` және `right` сызықтық уақыт бойынша сұрыпталған реттілікке біріктіруге дайындаламыз.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Сонымен қатар, біз сызықтық уақыт бойынша сұрыпталған реттіліктен ағаш жасаймыз.
        self.bulk_push(iter, length)
    }

    /// Жол бойында `length` айнымалысын көбейте отырып, барлық мәндер жұптарын ағаштың соңына итереді.
    /// Соңғысы итератор үрейленіп тұрған кезде қоңырау шалушының ағып кетуіне жол бермеуді жеңілдетеді.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Барлық түйінді мәндер жұптарын қайталаңыз, оларды түйіндерге дұрыс деңгейде итеріңіз.
        for (key, value) in iter {
            // Ағымдағы парақ түйініне кілт-мән жұбын итеріп көріңіз.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Бос орын қалмады, жоғары көтеріліп, сол жерге итеріңіз.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Бос орын қалдырылған түйінді таптыңыз, осы жерге итеріңіз.
                                open_node = parent;
                                break;
                            } else {
                                // Тағы көтерілу.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Біз жоғарыдамыз, жаңа түбір түйінін жасап, сол жерге итеріңіз.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Кілттер мәнінің жұбын және жаңа оң ішкі ағашты итеріңіз.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Қайта ең оң жақ жапыраққа түсіңіз.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Итератор үрейленсе де, картаның қосымша элементтерді тастайтындығына көз жеткізу үшін әр қайталанудың ұзындығын көбейтіңіз.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Екі сұрыпталған тізбекті біреуіне біріктіруге арналған итератор
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Егер екі кілт тең болса, оң көзден кілт-мән жұбын қайтарады.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}