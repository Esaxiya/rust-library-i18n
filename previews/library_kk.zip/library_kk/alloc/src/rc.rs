//! Бір бұрандалы санақ көрсеткіштері.'Rc' «Анықтама» дегенді білдіреді
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] типі үйіндіде бөлінген `T` типті мәнге ортақ меншікті қамтамасыз етеді.
//! [`clone`][clone]-ті [`Rc`]-ге шақыру үйіндідегі бірдей үлестірілімге жаңа көрсеткіш шығарады.
//! Берілген бөлуге соңғы [`Rc`] сілтемесі жойылған кезде, сол бөліністе сақталған мән (көбіне "inner value" деп аталады) жойылады.
//!
//! Rust-да ортақ сілтемелер мутацияны әдепкі бойынша болдырмайды, ал [`Rc`]-бұл ерекшелік емес: сіз [`Rc`] ішіндегі нәрсеге өзгермелі сілтеме ала алмайсыз.
//! Егер сізге өзгергіштік қажет болса, [`Rc`] ішіне [`Cell`] немесе [`RefCell`] салыңыз;[an example of mutability inside an `Rc`][mutability] қараңыз.
//!
//! [`Rc`] атомдық емес анықтамалық санауды қолданады.
//! Бұл үстеме шығындар өте төмен дегенді білдіреді, бірақ [`Rc`] ағындар арасында жіберілмейді, демек [`Rc`] [`Send`][send]-ті қолданбайды.
//! Нәтижесінде, Rust компиляторы *компиляция кезінде* сіздің ағындар арасында [`Rc`] жібермейтіндігіңізді тексереді.
//! Егер сізге көп ағынды, атомдық санақ қажет болса, [`sync::Arc`][arc] пайдаланыңыз.
//!
//! [`downgrade`][downgrade] әдісін иелік етпейтін [`Weak`] көрсеткішін жасау үшін пайдалануға болады.
//! [`Weak`] сілтемесі [`жаңарту '][жаңарту] d-тен [`Rc`]-ге дейін болуы мүмкін, бірақ егер бұл [`None`]-ті бөлісте сақталған мән түсіп қалған болса, қайтарады.
//! Басқаша айтқанда, `Weak` көрсеткіштері бөлу ішіндегі мәнді тірі ұстамайды;дегенмен, олар бөлуді (ішкі құндылық үшін қолдау дүкенін) тірі қалдырады.
//!
//! [`Rc`] көрсеткіштері арасындағы цикл ешқашан бөлінбейді.
//! Осы себепті [`Weak`] циклдарды бұзу үшін қолданылады.
//! Мысалы, ағашта ата-аналар түйіндерінен балаларға арналған күшті [`Rc`] көрсеткіштері, ал балалардан ата-аналарына қайтып келетін [`Weak`] көрсеткіштері болуы мүмкін.
//!
//! `Rc<T>` автоматты түрде `T`-ге сілтеме жасайды ([`Deref`] trait арқылы), сондықтан сіз [`Rc<T>`][`Rc`] типіндегі мәнге «T» әдістерін шақыра аласыз.
//! T0 әдістерімен аты-жөні қақтығыстарды болдырмау үшін [`Rc<T>`][`Rc`] әдістері [fully qualified syntax] пайдалану деп аталатын байланысты функциялар болып табылады:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! «Rc<T>Сондай-ақ, traits-ті `Clone` сияқты іске асыруды толық білікті синтаксисті қолдану деп атауға болады.
//! Кейбіреулер толық білікті синтаксисті, ал басқалары әдіс-шақыру синтаксисін қолданғанды жөн көреді.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Әңгіме-синтаксис
//! let rc2 = rc.clone();
//! // Толық білікті синтаксис
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T` автоматты түрде ажыратылмайды, өйткені ішкі мән әлдеқашан түсіп қалған болуы мүмкін.
//!
//! # Сілтемелерді клондау
//!
//! Бұрыннан бар сілтеме есептелген көрсеткіш сияқты бірдей бөлуге жаңа сілтеме жасау [`Rc<T>`][`Rc`] және [`Weak<T>`][`Weak`] үшін енгізілген `Clone` trait көмегімен жүзеге асырылады.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Төмендегі екі синтаксис баламалы болып табылады.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // а және b екеуі foo-мен бірдей жад орнын көрсетеді.
//! ```
//!
//! `Rc::clone(&from)` синтаксисі ең идиомалық болып табылады, өйткені ол кодтың мағынасын айқынырақ береді.
//! Жоғарыда келтірілген мысалда, бұл синтаксис бұл кодтың foo-ның бүкіл мазмұнын көшірудің орнына жаңа сілтеме жасап жатқанын көруді жеңілдетеді.
//!
//! # Examples
//!
//! Gadget жиынтығы берілген `Owner` иелік ететін сценарийді қарастырайық.
//! Біздің гаджетіміз олардың `Owner` нұсқасын алғысы келеді.Біз мұны бірегей меншік құқығымен жасай алмаймыз, өйткені бірнеше бірдей гаджет бірдей `Owner`-ке тиесілі болуы мүмкін.
//! [`Rc`] бізге бірнеше «гаджет» арасында `Owner` бөлісуге мүмкіндік береді және `Owner` кез келген `Gadget` нүктесі болғанша бөлінген күйінде қалады.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... басқа өрістер
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... басқа өрістер
//! }
//!
//! fn main() {
//!     // Анықтамалық есептелген `Owner` жасаңыз.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner`-ке жататын «гаджет» жасаңыз.
//!     // `Rc<Owner>`-ті клондау процесте анықтамалық санды көбейтіп, сол `Owner` бөлінуіне жаңа нұсқағыш береді.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Біздің жергілікті айнымалы `gadget_owner`-ті тастаңыз.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner`-ті тастағанымызға қарамастан, біз Gadget-тің `Owner` атауын басып шығара аламыз.
//!     // Себебі біз тек `Rc<Owner>`-ті түсірдік, ол көрсеткен `Owner` емес.
//!     // Сол `Owner` бөлінуіне бағытталған басқа `Rc<Owner>` болғанша, ол тірі күйінде қалады.
//!     // Өріс проекциясы `gadget1.owner.name` жұмыс істейді, өйткені `Rc<Owner>` автоматты түрде `Owner`-ге сілтеме жасайды.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Функцияның соңында `gadget1` және `gadget2` жойылады, және олармен бірге біздің `Owner` сілтемелері есептеледі.
//!     // Gadget Man қазір де жойылады.
//!     //
//! }
//! ```
//!
//! Егер біздің талаптарымыз өзгеретін болса және біз `Owner`-тен `Gadget`-қа өту мүмкіндігімізге ие болсақ, біз проблемаларға тап боламыз.
//! `Owner`-тен `Gadget`-ке дейінгі [`Rc`] көрсеткіші циклды енгізеді.
//! Бұл дегеніміз, олардың анықтамалық саны ешқашан 0-ге жетпейді және бөлу ешқашан жойылмайды:
//! жадтың ағуы.Мұны айналып өту үшін біз [`Weak`] көрсеткіштерін қолдана аламыз.
//!
//! Rust бірінші кезекте осы циклды шығаруды біршама қиындатады.Соңында бір-біріне бағытталған екі мәнмен аяқталу үшін олардың біреуі өзгеріске ұшырауы керек.
//! Бұл қиын, өйткені [`Rc`] жад қауіпсіздігін оның оралатын мәніне ортақ сілтемелер беру арқылы күшейтеді және бұл тікелей мутацияға жол бермейді.
//! Біз мутацияға ұшырағымыз келетін шаманың бір бөлігін [`RefCell`] ішіне орауымыз керек, ол *ішкі өзгергіштікті* қамтамасыз етеді: ортақ сілтеме арқылы өзгергіштікке қол жеткізу әдісі.
//! [`RefCell`] Rust қарыз алу ережелерін жұмыс уақытында орындайды.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... басқа өрістер
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... басқа өрістер
//! }
//!
//! fn main() {
//!     // Анықтамалық есептелген `Owner` жасаңыз.
//!     // Біз «Гаджет» иесінің vector иесін `RefCell` ішіне орналастырғанымызға назар аударыңыз, сонда біз оны ортақ сілтеме арқылы өзгерте аламыз.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // `gadget_owner`-ке тиесілі «гаджеттерді» бұрынғыдай жасаңыз.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Gadget-ті `Owner`-ке қосыңыз.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` динамикалық қарыз осымен аяқталады.
//!     }
//!
//!     // Біздің гаджеттерімізді қайталаңыз, олардың бөлшектерін басып шығарыңыз.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` бұл `Weak<Gadget>`.
//!         // `Weak` көрсеткіштері бөлудің әлі де бар екендігіне кепілдік бере алмайтындықтан, біз `upgrade`-ке қоңырау шалуымыз керек, ол `Option<Rc<Gadget>>` қайтарады.
//!         //
//!         //
//!         // Бұл жағдайда біз бөлудің әлі де бар екенін білеміз, сондықтан біз `unwrap` `Option`.
//!         // Неғұрлым күрделі бағдарламада сізге `None` нәтижесі үшін күрделі қателіктер қажет болуы мүмкін.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Функцияның соңында `gadget_owner`, `gadget1` және `gadget2` жойылады.
//!     // Қазір гаджеттерге арналған күшті (`Rc`) көрсеткіштері жоқ, сондықтан олар жойылды.
//!     // Бұл Gadget Man-ге сілтеме санын нөлге теңестіреді, сондықтан ол да жойылады.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Бұл repr(C)-тен future-ге дейінгі өрісті қайта реттеуге қарсы, бұл өзгертілетін ішкі типтердің қауіпсіз [into|from]_raw()-іне кедергі келтіруі мүмкін.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Бір бұрандалы сілтемені санау көрсеткіші.'Rc' «Анықтама» дегенді білдіреді
/// Counted'.
///
/// Қосымша мәлімет алу үшін [module-level documentation](./index.html) қараңыз.
///
/// `Rc`-тің тән әдістері-бұл барлық байланысты функциялар, демек, оларды `value.get_mut()` орнына [`Rc::get_mut(&mut value)`][get_mut] деп атауға тура келеді.
/// Бұл ішкі типтегі `T` әдістерімен қақтығыстарды болдырмайды.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Қауіпсіздік дұрыс, өйткені Rc тірі кезінде біз ішкі көрсеткіштің жарамды екеніне кепілдік береміз.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Жаңа `Rc<T>` құрастырады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Барлық күшті көрсеткіштерге тиесілі жасырын әлсіз көрсеткіш бар, бұл әлсіз деструктор күшті деструктор жұмыс істеп тұрған кезде бөлімді ешқашан босатпайтындығына кепілдік береді, тіпті әлсіз нұсқағыш күшті ішінде сақталған болса да.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Өзіне әлсіз сілтемені пайдаланып жаңа `Rc<T>` құрастырады.
    /// Бұл функция қайтарылғанға дейін әлсіз сілтемені жаңартуға тырысу `None` мәніне әкеледі.
    ///
    /// Алайда, әлсіз сілтемені еркін клондап, кейінірек пайдалану үшін сақтауға болады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... басқа өрістер
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Ішкі құрылғыны "uninitialized" күйінде әлсіз анықтамамен салыңыз.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Біз әлсіз көрсеткішке иелік етуден бас тартпауымыз керек, әйтпесе `data_fn` оралғанша жад босатылуы мүмкін.
        // Егер біз шынымен иелік еткіміз келсе, біз өзімізге қосымша әлсіз көрсеткіш жасай аламыз, бірақ бұл әлсіз сілтемелер санына қосымша жаңартулар әкеледі, әйтпесе қажет болмауы мүмкін.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Күшті сілтемелер жалпы әлсіз анықтамаға ие болуы керек, сондықтан біздің ескі әлсіз сілтеме үшін деструкторды қолданбаңыз.
        //
        mem::forget(weak);
        strong
    }

    /// Инициализацияланбаған мазмұны бар жаңа `Rc` құрастырады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Жады `0` байтпен толтырылған, инициализацияланбаған мазмұнмен жаңа `Rc` құрастырады.
    ///
    ///
    /// Осы әдісті дұрыс және қате қолдану мысалдары үшін [`MaybeUninit::zeroed`][zeroed] қараңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Жаңа `Rc<T>` құрастырады, егер бөлу сәтсіз болса, қате қайтарады
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Барлық күшті көрсеткіштерге тиесілі жасырын әлсіз көрсеткіш бар, бұл әлсіз деструктор күшті деструктор жұмыс істеп тұрған кезде бөлімді ешқашан босатпайтындығына кепілдік береді, тіпті әлсіз нұсқағыш күшті ішінде сақталған болса да.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Мазмұны инициализацияланбаған жаңа `Rc` құрастырады, егер бөлу сәтсіз болса, қате қайтарады
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Жаңа `Rc`-ті инициализацияланбаған мазмұнмен жасайды, жады `0` байтпен толтырылады, егер бөлу сәтсіз болса, қате қайтарады
    ///
    ///
    /// Осы әдісті дұрыс және қате қолдану мысалдары үшін [`MaybeUninit::zeroed`][zeroed] қараңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Жаңа `Pin<Rc<T>>` құрастырады.
    /// Егер `T` `Unpin`-ті қолданбаса, онда `value` жадқа бекітіліп, оны жылжыту мүмкін болмайды.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Ішкі мәнді қайтарады, егер `Rc` дәл бір күшті сілтеме болса.
    ///
    /// Әйтпесе, [`Err`] берілген сол `Rc`-пен қайтарылады.
    ///
    ///
    /// Бұл әлсіз сілтемелер болған жағдайда да сәттілікке жетеді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // қамтылған нысанды көшіру

                // Әлсіздерге оларды күшті санды азайту арқылы жоғарылата алмайтындығын көрсетіңіз, содан кейін жасырын "strong weak" көрсеткішін алып тастаңыз, сонымен қатар жалған әлсіздерді жасау арқылы құлдырау логикасын қолданыңыз.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Мазмұны инициализацияланбаған сілтеме бойынша есептелген жаңа кесінді салады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Жады `0` байтпен толтырылған, инициализацияланбаған мазмұны бар сілтеме бойынша есептелген жаңа кесінді салады.
    ///
    ///
    /// Осы әдісті дұрыс және қате қолдану мысалдары үшін [`MaybeUninit::zeroed`][zeroed] қараңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>`-ге түрлендіреді.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] сияқты, қоңырау шалушының ішкі мәні шынымен инициалды күйде екеніне кепілдік беруі керек.
    ///
    /// Мазмұн әлі толық инициализацияланбаған кезде оны шақыру дереу анықталмаған әрекеттерді тудырады.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>`-ге түрлендіреді.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] сияқты, қоңырау шалушының ішкі мәні шынымен инициалды күйде екеніне кепілдік беруі керек.
    ///
    /// Мазмұн әлі толық инициализацияланбаған кезде оны шақыру дереу анықталмаған әрекеттерді тудырады.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Оралған көрсеткішті қайтарып, `Rc` тұтынады.
    ///
    /// Жадтың ағып кетуіне жол бермеу үшін меңзерді [`Rc::from_raw`][from_raw] көмегімен `Rc`-ге қайта айналдыру керек.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Деректерге шикі көрсеткішті ұсынады.
    ///
    /// Санауларға ешқандай әсер етпейді және `Rc` тұтынылмайды.
    /// Меңзер `Rc`-те күшті санау болғанша жарамды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // ҚАУІПСІЗДІК: Бұл Deref::deref немесе Rc::inner арқылы өте алмайды, себебі
        // мысалы, мысалы, raw/mut-ті ұстап тұру үшін қажет
        // `get_mut` Rc `from_raw` арқылы қалпына келтірілгеннен кейін көрсеткіш арқылы жаза алады.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Шикі көрсеткіштен `Rc<T>` құрастырады.
    ///
    /// Шикі сілтеме бұрын [`Rc<U>::into_raw`][into_raw] қоңырауымен қайтарылған болуы керек, егер `U` өлшемі мен туралануы `T` сияқты болса.
    /// Егер `U` `T` болса, бұл өте маңызды емес.
    /// Егер `U` `T` болмаса да, өлшемі мен туралануы бірдей болса, бұл негізінен әртүрлі типтегі сілтемелерді түрлендіруге ұқсас екенін ескеріңіз.
    /// Бұл жағдайда қандай шектеулер қолданылатыны туралы көбірек ақпарат алу үшін [`mem::transmute`][transmute] бөлімін қараңыз.
    ///
    /// `from_raw` пайдаланушысы `T` мәнінің тек бір рет төмендегеніне көз жеткізуі керек.
    ///
    /// Бұл функция қауіпті, өйткені дұрыс қолданбау, егер қайтарылған `Rc<T>` ешқашан қол жетімді болмаса да, жадтың қауіпсіздігіне әкелуі мүмкін.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Ағып кетпес үшін `Rc`-ке қайта оралыңыз.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Бұдан әрі `Rc::from_raw(x_ptr)` қоңыраулары жадқа қауіпті болады.
    /// }
    ///
    /// // `x` жоғарыдан тыс болған кезде жад босатылды, сондықтан `x_ptr` енді іліп қалады!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // RcBox түпнұсқасын табу үшін жылжуды кері жылжытыңыз.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Осы бөлуге жаңа [`Weak`] көрсеткішін жасайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Біз ілулі әлсіздігімізді жасамауымыз керек
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Осы бөлуге [`Weak`] көрсеткіштерінің санын алады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Осы бөлуге күшті (`Rc`) көрсеткіштерінің санын алады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Егер бұл бөлуге басқа `Rc` немесе [`Weak`] көрсеткіштері болмаса, `true` мәнін қайтарады.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Егер бірдей бөлуге басқа `Rc` немесе [`Weak`] көрсеткіштері болмаса, берілген `Rc`-ге өзгертілетін сілтемені қайтарады.
    ///
    ///
    /// Басқа жағдайда [`None`] мәнін қайтарады, өйткені ортақ мәннің мутациясы қауіпсіз емес.
    ///
    /// Басқа көрсеткіштер болған кезде ішкі мәнді [`clone`][clone] болатын [`make_mut`][make_mut] қараңыз.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Берілген `Rc`-ге өзгертілетін сілтемені ешқандай тексерусіз қайтарады.
    ///
    /// Сондай-ақ қауіпсіз және тиісті тексерулер жүргізетін [`get_mut`] қараңыз.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Қайтарылған қарыз мерзімі ішінде кез-келген басқа `Rc` немесе [`Weak`] көрсеткіштері бірдей бөлінуге жіберілмеуі керек.
    ///
    /// Егер мұндай көрсеткіштер болмаса, мысалы, `Rc::new` кейін бірден болады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Біз "count" өрістерін қамтитын анықтамалық құруды *жасамауға* абаймыз, өйткені бұл анықтамалық санауларға қол жеткізуге қайшы келеді (мысалы,
        // `Weak` бойынша).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Егер екі Rc` бірдей бөлініске бағытталса ([`ptr::eq`] ұқсас венада), `true`-ті қайтарады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Берілген `Rc`-ге өзгертілетін сілтеме жасайды.
    ///
    /// Егер бірдей бөлуге арналған басқа `Rc` көрсеткіштері болса, онда `make_mut` бірегей иеленуді қамтамасыз ету үшін ішкі бөлімді жаңа бөлуге [`clone`] етеді.
    /// Мұны жазуға клондау деп те атайды.
    ///
    /// Егер бұл бөлуге арналған басқа `Rc` көрсеткіштері болмаса, онда [`Weak`] осы бөлуге арналған сілтемелер ажыратылады.
    ///
    /// Сондай-ақ, [`get_mut`]-ті қараңыз, ол клондаудың орнына сәтсіздікке ұшырайды.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Ештеңе клондамайды
    /// let mut other_data = Rc::clone(&data);    // Ішкі деректерді клондамайды
    /// *Rc::make_mut(&mut data) += 1;        // Ішкі деректерді клондайды
    /// *Rc::make_mut(&mut data) += 1;        // Ештеңе клондамайды
    /// *Rc::make_mut(&mut other_data) *= 2;  // Ештеңе клондамайды
    ///
    /// // Енді `data` және `other_data` әртүрлі бөлінулерге нұсқайды.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] көрсеткіштер ажыратылады:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Деректерді клондау керек, басқа Rcs бар.
            // Клондалған мәнді тікелей жазуға мүмкіндік беру үшін жадты алдын-ала бөліңіз.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Тек деректерді ұрлай алады, тек әлсіздер қалады
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Айқын және әлсіз рефекті алып тастаңыз (мұнда жалған әлсіздерді жасаудың қажеті жоқ-біз үшін басқа әлсіздер тазарта алатынын білеміз)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Бұл қауіпті емес, өйткені қайтарылған көрсеткіш тек T-ге қайтарылатын *жалғыз* көрсеткіш екеніне кепілдік береміз.
        // Біздің анықтамалық санымыз осы сәтте 1-ге кепілдендірілген және біз `Rc<T>`-тің `mut` болуын талап еттік, сондықтан бөлуге болатын жалғыз сілтемені қайтарамыз.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>`-ті нақты түрге түсіруге тырысу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Мүмкін өлшемделмеген ішкі мән үшін жеткілікті кеңістігі бар `RcBox<T>`-ті бөледі, онда мәнде орналасу бар.
    ///
    /// `mem_to_rcbox` функциясы деректер көрсеткішімен бірге шақырылады және `RcBox<T>` үшін (әлеуетті май) көрсеткішті қайтаруы керек.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Берілген мәндер орналасуын пайдаланып орналасуды есептеңіз.
        // Бұрын орналасу `&*(ptr as* const RcBox<T>)` өрнегі бойынша есептелген, бірақ бұл дұрыс емес анықтаманы тудырды (#54908 қараңыз).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Мүмкін өлшемделмеген ішкі мән үшін жеткілікті кеңістігі бар `RcBox<T>`-ті бөледі, егер мәнде орналасу берілген болса, қате қайтарылады.
    ///
    ///
    /// `mem_to_rcbox` функциясы деректер көрсеткішімен бірге шақырылады және `RcBox<T>` үшін (әлеуетті май) көрсеткішті қайтаруы керек.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Берілген мәндер орналасуын пайдаланып орналасуды есептеңіз.
        // Бұрын орналасу `&*(ptr as* const RcBox<T>)` өрнегі бойынша есептелген, бірақ бұл дұрыс емес анықтаманы тудырды (#54908 қараңыз).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Макет үшін бөлу.
        let ptr = allocate(layout)?;

        // RcBox инициализациясы
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Өлшемделмеген ішкі мән үшін жеткілікті кеңістігі бар `RcBox<T>` бөледі
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Берілген мәнді пайдаланып `RcBox<T>` үшін бөліңіз.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Мәнді байт түрінде көшіру
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Мазмұнын түсірмей бөлуді босатыңыз
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Берілген ұзындықпен `RcBox<[T]>` бөледі.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Элементтерді тілімнен жаңадан бөлінген Rc <\[T\]> ішіне көшіріңіз
    ///
    /// Қауіпті, себебі қоңырау шалушы меншікті иемденуі немесе `T: Copy` байланыстыруы керек
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Белгілі бір мөлшерде болатын итератордан `Rc<[T]>` құрастырады.
    ///
    /// Өлшемі дұрыс болмауы керек мінез-құлық анықталмаған.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // T элементтерін клондау кезінде Panic күзеті.
        // panic жағдайында жаңа RcBox-қа жазылған элементтер түсіріледі, содан кейін жад босатылады.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Бірінші элементті көрсетіңіз
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Барлығы түсінікті.Жаңа RcBox босатпауы үшін күзетшіні ұмытыңыз.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` үшін қолданылатын trait мамандануы.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` тастайды.
    ///
    /// Бұл анықтамалық санды азайтады.
    /// Егер күшті сілтеме саны нөлге жетсе, онда басқа сілтемелер (егер бар болса) [`Weak`] болып табылады, сондықтан біз ішкі мәнді `drop` деп санаймыз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Ештеңе басып шығармайды
    /// drop(foo2);   // "dropped!" басып шығарады
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // қамтылған нысанды жою
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // мазмұнын жойғаннан кейін, анық емес "strong weak" меңзерін алып тастаңыз.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` көрсеткішінің клонын жасайды.
    ///
    /// Бұл бірдей сілтемеге тағы бір сілтеме жасайды, күшті сілтеме санын көбейтеді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` үшін `Default` мәні бар жаңа `Rc<T>` жасайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` әдісі болғанымен, `Eq`-ке мамандануға мүмкіндік беру үшін хак.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Біз бұл мамандандыруды осында жасаймыз, және `&T`-тегі жалпы оңтайландыру емес, өйткені ол әйтпесе барлық теңдік тексерулеріне шығындар қосады.
/// Біздің ойымызша, «Rc`s» үлкен мәндерді сақтау үшін қолданылады, олар баяу клондалады, бірақ теңдікті тексеру үшін ауыр, бұл шығындарды оңай төлейді.
///
/// Сондай-ақ, екі бірдей X-X клондары болуы мүмкін, олар бірдей мәнді көрсетеді, екі&T`-ге қарағанда.
///
/// Біз мұны тек `T: Eq` `PartialEq` ретінде әдейі рефлексивті болуы мүмкін болған кезде жасай аламыз.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Екі RC үшін теңдік.
    ///
    /// Екі `Rc` тең, егер олардың ішкі мәндері тең болса, тіпті олар әртүрлі бөліністе сақталған болса да.
    ///
    /// Егер `T` сонымен қатар `Eq`-ті іске асырса (теңдіктің рефлексивтілігін білдіреді), бірдей бөлуді көрсететін екі `Rc` әрқашан тең болады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Екі Rc үшін теңсіздік.
    ///
    /// Екі `Rc` тең емес, егер олардың ішкі мәндері тең болмаса.
    ///
    /// Егер `T` сонымен қатар `Eq` (теңдіктің рефлексивтілігін білдіреді) жүзеге асырса, бірдей бөлуге нұсқайтын екі `Rc` ешқашан тең болмайды.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Екі Rc үшін ішінара салыстыру.
    ///
    /// Екеуі ішкі құндылықтар бойынша `partial_cmp()` қоңырауы арқылы салыстырылады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Екі Rc үшін салыстыруға қарағанда аз.
    ///
    /// Екеуі ішкі құндылықтар бойынша `<` қоңырауы арқылы салыстырылады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Екі Rc` үшін «кем немесе тең» салыстыру.
    ///
    /// Екеуі ішкі құндылықтар бойынша `<=` қоңырауы арқылы салыстырылады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Екі Rc үшін салыстырудан үлкен.
    ///
    /// Екеуі ішкі құндылықтар бойынша `>` қоңырауы арқылы салыстырылады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Екі Rc` үшін «үлкен немесе тең» салыстыру.
    ///
    /// Екеуі ішкі құндылықтар бойынша `>=` қоңырауы арқылы салыстырылады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Екі Rc үшін салыстыру.
    ///
    /// Екеуі ішкі құндылықтар бойынша `cmp()` қоңырауы арқылы салыстырылады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Анықтамалық есептелген кесінді бөліп, оны `v` элементтерін клондау арқылы толтырыңыз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Анықтамалық есептелген жол кесіндісін бөліп, оған `v` көшіріңіз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Анықтамалық есептелген жол кесіндісін бөліп, оған `v` көшіріңіз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Қораптағы нысанды жаңаға, сілтеме санауға, бөлуге жылжытыңыз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Анықтамалық есептелген кесінді бөліп, оған `v` элементтерін жылжытыңыз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec-ке оның жадын босатуға мүмкіндік беріңіз, бірақ оның мазмұнын жоймаңыз
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// `Iterator` ішіндегі әрбір элементті алады және оны `Rc<[T]>` түрінде жинайды.
    ///
    /// # Өнімділік сипаттамалары
    ///
    /// ## Жалпы жағдай
    ///
    /// Жалпы жағдайда `Rc<[T]>`-ге жинау алдымен `Vec<T>`-ке жиналу арқылы жүзеге асырылады.Яғни, келесілерді жазған кезде:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// бұл біз жазғандай әрекет етеді:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Бөлудің бірінші жиынтығы осы жерде болады.
    ///     .into(); // `Rc<[T]>` үшін екінші бөлу осында болады.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Бұл `Vec<T>` құру үшін қанша керек болса, сонша рет `Vec<T>`-ті `Rc<[T]>`-ке айналдыру үшін бөледі.
    ///
    ///
    /// ## Ұзындығы белгілі итераторлар
    ///
    /// Егер сіздің `Iterator` `TrustedLen`-ті жүзеге асырады және дәл өлшемде болғанда, `Rc<[T]>` үшін жалғыз бөлу жасалады.Мысалға:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Мұнда тек бір ғана қаражат бөлінеді.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// `Rc<[T]>`-ге жинау үшін қолданылатын trait мамандануы.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Бұл `TrustedLen` итераторына қатысты.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // ҚАУІПСІЗДІК: Біз итератордың дәл ұзындығына көз жеткізуіміз керек.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Қалыпты іске асыруға қайта оралыңыз.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` - бұл басқарылатын бөлуге иелік етпейтін сілтеме жасайтын [`Rc`] нұсқасы.Бөлімге `Weak` сілтемесі бойынша [`upgrade`] қоңырауы арқылы қол жеткізіледі, ол [`Опция`]`<`[`Rc`] '<T>> «.
///
/// `Weak` сілтемесі меншікке жатпайтындықтан, бұл бөлуде сақталған мәннің түсіп қалуына жол бермейді және `Weak` өзі әлі де бар мәнге кепілдік бермейді.
/// Осылайша, ол [`None`]-ті [«жаңарту»] күнінен кейін қайтара алады.
/// Алайда, `Weak` сілтемесі *бөлудің өзі (қосалқы дүкен) бөлінуіне жол бермейді*.
///
/// `Weak` көрсеткіші [`Rc`] басқаратын бөлуге уақытша сілтеме жасау үшін пайдалы, оның ішкі мәні түсіп кетуіне жол бермейді.
/// Ол сондай-ақ [`Rc`] көрсеткіштері арасындағы дөңгелек сілтемелерді болдырмау үшін қолданылады, өйткені өзара иелік сілтемелер ешқашан [`Rc`]-ті түсіруге жол бермейді.
/// Мысалы, ағашта ата-аналар түйіндерінен балаларға арналған күшті [`Rc`] көрсеткіштері, ал балалардан ата-аналарына қайтып келетін `Weak` көрсеткіштері болуы мүмкін.
///
/// `Weak` көрсеткішін алудың әдеттегі тәсілі-[`Rc::downgrade`] қоңырау шалу.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Бұл энумдарда осы типтің мөлшерін оңтайландыруға мүмкіндік беретін `NonNull`, бірақ ол міндетті түрде жарамды сілтеме емес.
    //
    // `Weak::new` үйіндіге орын бөлудің қажеті болмайтындай етіп мұны `usize::MAX` деңгейіне қояды.
    // Бұл нақты көрсеткішке ие болатын мән емес, өйткені RcBox кем дегенде 2 туралауға ие.
    // Бұл тек `T: Sized` кезінде мүмкін болады;өлшемсіз `T` ешқашан өшпейді.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Ешқандай жад бөлмей, жаңа `Weak<T>` құрастырады.
    /// Қайтарылатын мәнге [`upgrade`] қоңырауы әрқашан [`None`] береді.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Мәліметтер өрісіне қатысты ешқандай дәлелдемелерсіз сілтемелер санына қол жеткізуге мүмкіндік беретін көмекші теріңіз.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Осы `Weak<T>` көрсеткен `T` объектісіне шикі көрсеткішті қайтарады.
    ///
    /// Меңзер сілтемелер болған жағдайда ғана жарамды.
    /// Меңзер ілулі, тегістелмеген немесе тіпті [`null`] болуы мүмкін.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Екеуі де бір затты нұсқайды
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Мұндағы күштілер оны тірі ұстайды, сондықтан біз объектіге қол жеткізе аламыз.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Бірақ енді жоқ.
    /// // Біз weak.as_ptr() жасай аламыз, бірақ көрсеткішке қол жеткізу анықталмаған әрекетке әкеледі.
    /// // assert_eq! («сәлем», қауіпті {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Егер көрсеткіш салбырап тұрса, біз күзетшіні тікелей қайтарамыз.
            // Бұл жарамды жүктеме мекен-жайы бола алмайды, өйткені пайдалы жүктеме, кем дегенде, RcBox (usize)-мен теңестірілген.
            ptr as *const T
        } else {
            // ҚАУІПСІЗДІК: егер is_dangling мәні жалған болса, онда сілтеме дериферацияланатын болады.
            // Осы сәтте пайдалы жүктеме төмендеуі мүмкін, сондықтан біз тексерілімді сақтап қалуымыз керек, сондықтан шикі нұсқағыш манипуляциясын қолданыңыз.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` тұтынады және оны шикі көрсеткішке айналдырады.
    ///
    /// Бұл әлсіз сілтемені шикі көрсеткішке айналдырады, сонымен бірге бір әлсіз сілтеменің меншігін сақтайды (әлсіз санау бұл операциямен өзгертілмейді).
    /// Оны [`from_raw`] көмегімен қайтадан `Weak<T>`-ге айналдыруға болады.
    ///
    /// Көрсеткіштің мақсатына [`as_ptr`] сияқты шектеулер қолданылады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Бұрын [`into_raw`] жасаған шикі көрсеткішті `Weak<T>`-ке қайта түрлендіреді.
    ///
    /// Мұны сенімді анықтаманы алу үшін ([`upgrade`] кейінірек қоңырау шалу арқылы) немесе `Weak<T>` түсіру арқылы әлсіз санды бөлу үшін пайдалануға болады.
    ///
    /// Ол бір әлсіз анықтамаға иелік етуді қажет етеді ([`new`] жасаған көрсеткіштерден басқа, өйткені олар ешнәрсеге иелік етпейді; әдіс оларда жұмыс істейді).
    ///
    /// # Safety
    ///
    /// Меңзер [`into_raw`]-тен шыққан болуы керек және әлсіз әлсіз сілтемеге ие болуы керек.
    ///
    /// Мұны шақырған кезде күшті санау 0-ге тең болады.
    /// Дегенмен, бұл қазіргі уақытта шикі көрсеткіш ретінде ұсынылған бір әлсіз сілтемеге иелік етеді (әлсіз сан осы операциямен өзгертілмейді), сондықтан оны алдыңғы [`into_raw`] қоңырауымен жұптастыру керек.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Соңғы әлсіз санды азайту.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Кіріс сілтемесі қалай алынғандығы туралы контекстті Weak::as_ptr-тен қараңыз.

        let ptr = if is_dangling(ptr as *mut T) {
            // Бұл әлсіз әлсіреу.
            ptr as *mut RcBox<T>
        } else {
            // Әйтпесе, көрсеткіштің әлсіз жақтан шыққанына кепілдік береміз.
            // ҚАУІПСІЗДІК: data_offset қоңырау шалу қауіпсіз, өйткені ptr сілтемесі нақты (ықтимал түсіп қалған) Т.
            let offset = unsafe { data_offset(ptr) };
            // Осылайша, біз бүкіл RcBox алу үшін ығысуды кері қайтарамыз.
            // ҚАУІПСІЗДІК: нұсқау әлсізден шыққан, сондықтан бұл ығысу қауіпсіз.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ҚАУІПСІЗДІК: біз қазір әлсіз нұсқағышты қалпына келтірдік, сондықтан әлсіздерді де жасай аламыз.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` меңзерін [`Rc`] деңгейіне дейін жаңартуға тырысады, егер сәтті болған жағдайда ішкі мәннің түсуін кешіктіреді.
    ///
    ///
    /// Егер ішкі мән содан бері түсірілсе, [`None`] мәнін қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Барлық күшті көрсеткіштерді жойыңыз.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Осы бөлуді көрсететін күшті (`Rc`) көрсеткіштерінің санын алады.
    ///
    /// Егер `self` [`Weak::new`] көмегімен жасалған болса, бұл 0 мәнін береді.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Осы бөлуге бағытталған `Weak` көрсеткіштерінің санын алады.
    ///
    /// Егер күшті көрсеткіштер болмаса, бұл нөлге тең болады.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // айқын емес әлсіз птрді алып тастаңыз
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Сілтегіш салбырап тұрған кезде және бөлінген `RcBox` болмаған кезде `None` мәнін қайтарады (яғни, бұл `Weak` `Weak::new` құрған кезде).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Біз "data" өрісін қамтитын анықтаманы *жасамауға* абаймыз, өйткені өріс бір уақытта мутацияға ұшырауы мүмкін (мысалы, егер соңғы `Rc` түсірілсе, деректер өрісі орнында түсіп қалады).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Егер екі әлсіздер бірдей бөлуді көрсетсе ([`ptr::eq`]-ге ұқсас) немесе екеуі де қандай да бір бөлуді көрсетпесе (өйткені олар `Weak::new()`) көмегімен жасалған), `true` мәнін қайтарады.
    ///
    ///
    /// # Notes
    ///
    /// Бұл көрсеткіштерді салыстырғандықтан, бұл `Weak::new()` бір-біріне тең болады, дегенмен олар ешқандай бөлуді көрсетпейді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` салыстыру.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` меңзерін тастайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ештеңе басып шығармайды
    /// drop(foo);        // "dropped!" басып шығарады
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // әлсіз санау 1-ден басталады және барлық күшті көрсеткіштер жоғалып кеткен жағдайда ғана нөлге тең болады.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// `Weak` көрсеткішінің бірдей бөлінуіне нұсқайтын клон жасайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// `T` үшін жадты инициализациясыз бөле отырып, жаңа `Weak<T>` құрастырады.
    /// Қайтарылатын мәнге [`upgrade`] қоңырауы әрқашан [`None`] береді.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Біз mem::forget-пен қауіпсіз жұмыс істеу үшін осында тіркелдік.Сондай-ақ
// егер сіз mem::forget Rcs (немесе әлсіз) болсаңыз, қайта санау толып кетуі мүмкін, содан кейін сіз көрнекі Rcs (немесе әлсіз) болған кезде бөлуді босата аласыз.
//
// Біз түсік тастаймыз, өйткені бұл дегенеративті сценарий, сондықтан бізге не болатындығы маңызды емес-ешқандай нақты бағдарлама мұндай жағдайға тап болмауы керек.
//
// Бұл үстеме шығындар шамалы болуы керек, өйткені меншік құқығы мен жылжу-семантиканың арқасында Rust-де мұны клондаудың қажеті жоқ.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Біз мәнді төмендетудің орнына толып кетуді тоқтатқымыз келеді.
        // Бұл шақырылған кезде сілтеме саны ешқашан нөл болмайды;
        // дегенмен, біз LLVM туралы басқаша жіберіп алған оңтайландыруды болжау үшін аборт жасаймыз.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Біз мәнді төмендетудің орнына толып кетуді тоқтатқымыз келеді.
        // Бұл шақырылған кезде сілтеме саны ешқашан нөл болмайды;
        // дегенмен, біз LLVM туралы басқаша жіберіп алған оңтайландыруды болжау үшін аборт жасаймыз.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Көрсеткіштің артындағы пайдалы жүктеме үшін `RcBox` ішіндегі офсетті алыңыз.
///
/// # Safety
///
/// Сілтегіш бұрын жарамды T данасын көрсетуі керек (және олар үшін жарамды метадеректерге ие болуы керек), бірақ T-ді тастауға рұқсат етіледі.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Өлшемделмеген мәнді RcBox соңына туралаңыз.
    // RcBox repr(C) болғандықтан, ол әрдайым жадындағы соңғы өріс болып қалады.
    // ҚАУІПСІЗДІК: тек өлшемді емес түрлері тек тілімдер, trait нысандары болуы мүмкін,
    // және сыртқы түрлер, енгізу қауіпсіздігі талабы қазіргі уақытта align_of_val_raw талаптарын қанағаттандыру үшін жеткілікті;бұл std-тен тыс тілге сенуге болмайтын тілді енгізу бөлшегі.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}