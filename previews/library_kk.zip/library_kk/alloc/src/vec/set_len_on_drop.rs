// `SetLenOnDrop` мәні шеңберден шыққан кезде vec ұзындығын орнатыңыз.
//
// Идея мынада: SetLenOnDrop ішіндегі ұзындық өрісі-бұл Vec деректерінің көрсеткіштері арқылы кез-келген дүкендермен бүркеншік жасамайтын оңтайландырушы көретін жергілікті айнымалы.
// Бұл #32155 лақап атын талдауға арналған шешім
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}