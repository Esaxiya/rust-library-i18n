#![stable(feature = "wake_trait", since = "1.51.0")]
//! Асинхронды тапсырмалармен жұмыс істеуге арналған түрлері мен Traits.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Тапсырманы орындаушыға оятуды жүзеге асыру.
///
/// Бұл trait құрылғысын [`Waker`] жасау үшін пайдалануға болады.
/// Орындаушы осы trait іске асырылуын анықтай алады және мұны Вейкерді осы орындаушыда орындалатын тапсырмаларға беру үшін құру үшін қолдана алады.
///
/// Бұл trait-бұл [`RawWaker`] құрылғысының жадына қауіпсіз және эргономикалық балама.
/// Ол тапсырманы оятуға арналған деректер [`Arc`]-де сақталатын жалпы орындаушының дизайнын қолдайды.
/// Кейбір орындаушылар (әсіресе енгізілген жүйелер үшін) бұл API-ны қолдана алмайды, сондықтан [`RawWaker`] сол жүйелер үшін балама ретінде бар.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// future қабылдап, оны ағымдағы жіпке дейін аяқтайтын негізгі `block_on` функциясы.
///
/// **Note:** Бұл мысал дұрыстықты қарапайымдылықпен ауыстырады.
/// Тұйықталудың алдын алу үшін өндірістік деңгейдегі қондырғылар `thread::unpark`-ке аралық қоңыраулармен, сондай-ақ кірістірілген шақырулармен жұмыс істеуі керек.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Шақырылған кезде ағымдағы жіпті оятаратын оятушы.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Ағымдағы ағынға аяқтау үшін future іске қосыңыз.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // future-ті бекітіңіз, сонда ол сұралуы мүмкін.
///     let mut fut = Box::pin(fut);
///
///     // future жіберілетін жаңа контекст жасаңыз.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Аяқтау үшін future іске қосыңыз.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Бұл тапсырманы оятыңыз.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Бұл тапсырманы оятуды тұтынбай оятыңыз.
    ///
    /// Егер орындаушы вейкерді тұтынбай-ақ оятудың арзан тәсілін қолдаса, онда бұл әдісті жоққа шығаруы керек.
    /// Әдепкі бойынша, ол [`Arc`]-ті клондайды және клонда [`wake`]-ті шақырады.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // ҚАУІПСІЗДІК: қауіпсіз, өйткені raw_waker қауіпсіз құрастырады
        // доғадан шыққан RawWaker<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: RawWaker-ді құруға арналған бұл жеке функция гөрі пайдаланылады
// `From<Arc<W>> for RawWaker` қауіпсіздігінің trait диспетчеріне тәуелді емес екендігіне көз жеткізу үшін оны `From<Arc<W>> for RawWaker` имплине енгізіп, оның орнына екеуі де осы функцияны тікелей және анық деп атайды.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Клондау үшін доғаның анықтамалық санын көбейтіңіз.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Доғаны Wake::wake функциясына ауыстырып, мәні бойынша оятыңыз
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Сілтеме бойынша оятыңыз, құлап қалмас үшін стаканды Қолмен тастаңыз
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Доғаның анықтамалық санын тамшыға азайтыңыз
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}