#![stable(feature = "rust1", since = "1.0.0")]

//! Жіпке қауіпсіз сілтеме санауыштары.
//!
//! Толығырақ ақпаратты [`Arc<T>`][Arc] құжаттамасынан қараңыз.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc`-ке сілтемелер көлемінің жұмсақ шегі.
///
/// Осы шектен асып кету сіздің бағдарламаңызды (міндетті емес болса да) _exactly_ `MAX_REFCOUNT + 1` сілтемелерінде тоқтатады.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer жад қоршауларын қолдамайды.
// Arc/Weak енгізуіндегі жалған оң есептерді болдырмау үшін синхрондау үшін атомдық жүктемелерді қолданыңыз.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Жіпке қауіпсіз сілтемені санау көрсеткіші.'Arc' «Атомдық сілтеме саналады» дегенді білдіреді.
///
/// `Arc<T>` типі үйіндіде бөлінген `T` типті мәнге ортақ меншікті қамтамасыз етеді.[`clone`][clone]-ті `Arc`-ке шақыру жаңа `Arc` данасын шығарады, ол `Arc` көзі сияқты үйіндіде бірдей бөлінуді көрсетеді, сонымен бірге сілтеме санын көбейтеді.
/// Берілген бөлуге соңғы `Arc` сілтемесі жойылған кезде, сол бөліністе сақталған мән (көбіне "inner value" деп аталады) жойылады.
///
/// Rust-тағы ортақ сілтемелер мутацияны әдепкі бойынша болдырмайды, ал `Arc`-бұл ерекшелік емес: сіз `Arc` ішіндегі нәрсеге өзгермелі сілтеме ала алмайсыз.Егер сізге `Arc` арқылы мутация жасау қажет болса, [`Mutex`][mutex], [`RwLock`][rwlock] немесе [`Atomic`][atomic] түрлерінің бірін қолданыңыз.
///
/// ## Жіптің қауіпсіздігі
///
/// [`Rc<T>`]-тен айырмашылығы, `Arc<T>` сілтеме санау үшін атомдық операцияларды қолданады.Бұл оның жіптен қауіпсіз екенін білдіреді.Кемшілігі-қарапайым операциялық жадыға қарағанда атомдық операциялардың бағасы қымбат.Егер сіз ағындар арасындағы сілтемелермен бөлінген бөлімдерді бөліспесеңіз, төменгі үстеме шығындар үшін [`Rc<T>`] пайдалануды қарастырыңыз.
/// [`Rc<T>`] қауіпсіз әдепкі болып табылады, өйткені компилятор ағындар арасында [`Rc<T>`] жіберуге тырысады.
/// Алайда, кітапхана тұтынушыларға икемділік беру үшін кітапхана `Arc<T>` таңдай алады.
///
/// `Arc<T>` егер `T` [`Send`] және [`Sync`]-ті қолданса, [`Send`] және [`Sync`]-ті қолданады.
/// Неліктен сіз `T` ішіне жіп үшін қауіпсіз емес `T` типін сала алмайсыз?Алдымен бұл біраз интуитивті болуы мүмкін: ақыр соңында, `Arc<T>` жіптің қауіпсіздігі емес пе?Кілті мынада: `Arc<T>` бірдей деректерге бірнеше иелік етуді қауіпсіз етеді, бірақ ол мәліметтерге қауіпсіздікті қоспайды.
///
/// Arc <`[` RefCell. Қарастырайық<T>«]»> «.
/// [`RefCell<T>`] [`Sync`] емес, ал егер `Arc<T>` әрқашан [`Send`] болса, Arc <`[` RefCell<T>«]»> «болар еді.
/// Бірақ содан кейін бізде проблема болады:
/// [`RefCell<T>`] жіпке қауіпсіз емес;ол атомдық емес операцияларды қолдана отырып, қарыздар есебінің есебін жүргізеді.
///
/// Сайып келгенде, бұл сізге `Arc<T>`-ті [`std::sync`] типімен, әдетте [`Mutex<T>`][mutex]-мен жұптастыру қажет болуы мүмкін дегенді білдіреді.
///
/// ## `Weak` көмегімен үзіліс циклдары
///
/// [`downgrade`][downgrade] әдісін иелік етпейтін [`Weak`] көрсеткішін құру үшін пайдалануға болады.[`Weak`] сілтемесі [`жаңарту '][жаңарту] d-тен `Arc`-ге дейін болуы мүмкін, бірақ егер бұл [`None`]-ті бөлісте сақталған мән түсіп қалған болса, қайтарады.
/// Басқаша айтқанда, `Weak` көрсеткіштері бөлу ішіндегі мәнді тірі ұстамайды;дегенмен, олар бөлуді (құндылыққа арналған дүкен) тірі қалдырады.
///
/// `Arc` көрсеткіштері арасындағы цикл ешқашан бөлінбейді.
/// Осы себепті [`Weak`] циклдарды бұзу үшін қолданылады.Мысалы, ағашта ата-аналар түйіндерінен балаларға арналған күшті `Arc` көрсеткіштері, ал балалардан ата-аналарына қайтып келетін [`Weak`] көрсеткіштері болуы мүмкін.
///
/// # Сілтемелерді клондау
///
/// Бұрыннан бар сілтеме есептелген көрсеткіштен жаңа сілтеме жасау [`Arc<T>`][Arc] және [`Weak<T>`][Weak] үшін іске асырылған `Clone` trait көмегімен жасалады.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Төмендегі екі синтаксис баламалы болып табылады.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b және foo-барлығы бірдей жад орнын көрсететін Доғалар
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` автоматты түрде `T`-ге сілтеме жасайды ([`Deref`][deref] trait арқылы), сондықтан сіз `Arc<T>` типті мәнге «T» әдістерін шақыра аласыз.T0 әдістерімен аттардың қақтығысын болдырмау үшін `Arc<T>` әдістері [fully qualified syntax] пайдалану деп аталатын байланысты функциялар болып табылады:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// «Доға<T>Сондай-ақ, traits-ті `Clone` сияқты іске асыруды толық білікті синтаксисті қолдану деп атауға болады.
/// Кейбіреулер толық білікті синтаксисті, ал басқалары әдіс-шақыру синтаксисін қолданғанды жөн көреді.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Әңгіме-синтаксис
/// let arc2 = arc.clone();
/// // Толық білікті синтаксис
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T` автоматты түрде ажыратылмайды, өйткені ішкі мән әлдеқашан түсіп қалған болуы мүмкін.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Ағындар арасында кейбір өзгермейтін деректерді бөлісу:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Бұл жерде біз бұл сынақтарды ** жүргізбейтінімізді ескеріңіз.
// Егер жіп негізгі жіптен асып кетіп, бір уақытта шығып кетсе (тығырыққа тірелетін нәрсе) болса, windows жасаушылары өте бақытсыз болады, сондықтан біз бұл сынақтарды өткізбеу арқылы бұған жол бермейміз.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Өзгеретін [`AtomicUsize`] бөлісу:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Жалпы анықтамалық санаудың қосымша мысалдары үшін [`rc` documentation][rc_examples] қараңыз.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` - бұл басқарылатын бөлуге иелік етпейтін сілтеме жасайтын [`Arc`] нұсқасы.
/// Бөлуге `Weak` сілтемесі бойынша [`upgrade`] қоңырауы арқылы қол жеткізіледі, ол [`Option`]`<`[`Arc`] `<T>> «.
///
/// `Weak` сілтемесі меншікке жатпайтындықтан, бұл бөлуде сақталған мәннің түсіп қалуына жол бермейді және `Weak` өзі әлі де бар мәнге кепілдік бермейді.
///
/// Осылайша, ол [`None`]-ті [«жаңарту»] күнінен кейін қайтара алады.
/// Алайда, `Weak` сілтемесі *бөлудің өзі (қосалқы дүкен) бөлінуіне жол бермейді*.
///
/// `Weak` көрсеткіші [`Arc`] басқаратын бөлуге уақытша сілтеме жасау үшін пайдалы, оның ішкі мәні түсіп кетуіне жол бермейді.
/// Ол сондай-ақ [`Arc`] көрсеткіштері арасындағы дөңгелек сілтемелерді болдырмау үшін қолданылады, өйткені өзара иелік сілтемелер ешқашан [`Arc`]-ті түсіруге жол бермейді.
/// Мысалы, ағашта ата-аналар түйіндерінен балаларға арналған күшті [`Arc`] көрсеткіштері, ал балалардан ата-аналарына қайтып келетін `Weak` көрсеткіштері болуы мүмкін.
///
/// `Weak` көрсеткішін алудың әдеттегі тәсілі-[`Arc::downgrade`] қоңырау шалу.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Бұл энумдарда осы типтің мөлшерін оңтайландыруға мүмкіндік беретін `NonNull`, бірақ ол міндетті түрде жарамды сілтеме емес.
    //
    // `Weak::new` үйіндіге орын бөлудің қажеті болмайтындай етіп мұны `usize::MAX` деңгейіне қояды.
    // Бұл нақты көрсеткішке ие болатын мән емес, өйткені RcBox кем дегенде 2 туралауға ие.
    // Бұл тек `T: Sized` кезінде мүмкін болады;өлшемсіз `T` ешқашан өшпейді.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Бұл repr(C)-тен future-ге дейінгі өрісті қайта реттеуге қарсы, бұл өзгертілетін ішкі типтердің қауіпсіз [into|from]_raw()-іне кедергі келтіруі мүмкін.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX мәні уақытша "locking" әлсіз көрсеткіштерді жаңарту немесе мықтысын төмендету мүмкіндігі үшін күзетші рөлін атқарады;бұл `make_mut` және `get_mut` жарыстарынан аулақ болу үшін қолданылады.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Жаңа `Arc<T>` құрастырады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Әлсіз көрсеткішті 1 ретінде бастаңыз, ол барлық күшті (kinda) көрсеткіштерінде болатын әлсіз көрсеткіш, қосымша ақпарат алу үшін std/rc.rs қараңыз
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Өзіне әлсіз сілтемені пайдаланып жаңа `Arc<T>` құрастырады.
    /// Бұл функция қайтарылғанға дейін әлсіз сілтемені жаңартуға тырысу `None` мәніне әкеледі.
    /// Алайда, әлсіз сілтемені еркін клондап, кейінірек пайдалану үшін сақтауға болады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Ішкі құрылғыны "uninitialized" күйінде әлсіз анықтамамен салыңыз.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Біз әлсіз көрсеткішке иелік етуден бас тартпауымыз керек, әйтпесе `data_fn` оралғанша жад босатылуы мүмкін.
        // Егер біз шынымен иелік еткіміз келсе, біз өзімізге қосымша әлсіз көрсеткіш жасай аламыз, бірақ бұл әлсіз сілтемелер санына қосымша жаңартулар әкеледі, әйтпесе қажет болмауы мүмкін.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Енді біз ішкі құнды дұрыс инициализациялай аламыз және әлсіз сілтемені мықты сілтемеге айналдырамыз.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Мәліметтер өрісіне жоғарыдағы жазу нөлге тең емес күшті санауды бақылайтын кез келген ағынға көрінуі керек.
            // Сондықтан `Weak::upgrade`-те `compare_exchange_weak` синхрондау үшін бізге кем дегенде "Release" тапсырыс керек.
            //
            // "Acquire" тапсырыс қажет емес.
            // `data_fn` ықтимал мінез-құлқын қарастырған кезде біз оның жаңартылмайтын `Weak` сілтемесімен не істей алатынын қарауымыз керек:
            //
            // - Ол әлсіз сілтемелер санын көбейтіп, `Weak`-ті *клондай алады*.
            // - Ол әлсіз сілтемелер санын азайта отырып, сол клондарды тастай алады (бірақ нөлге дейін).
            //
            // Бұл жанама әсерлер бізге ешқандай әсер етпейді және қауіпсіз кодтың көмегімен басқа жанама әсерлер мүмкін емес.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Күшті сілтемелер жалпы әлсіз анықтамаға ие болуы керек, сондықтан біздің ескі әлсіз сілтеме үшін деструкторды қолданбаңыз.
        //
        mem::forget(weak);
        strong
    }

    /// Инициализацияланбаған мазмұны бар жаңа `Arc` құрастырады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Жады `0` байтпен толтырылған, инициализацияланбаған мазмұнмен жаңа `Arc` құрастырады.
    ///
    ///
    /// Осы әдісті дұрыс және қате қолдану мысалдары үшін [`MaybeUninit::zeroed`][zeroed] қараңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Жаңа `Pin<Arc<T>>` құрастырады.
    /// Егер `T` `Unpin`-ті қолданбаса, онда `data` жадқа бекітіліп, оны жылжыту мүмкін болмайды.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Жаңа `Arc<T>` құрастырады, егер бөлу сәтсіз болса, қате қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Әлсіз көрсеткішті 1 ретінде бастаңыз, ол барлық күшті (kinda) көрсеткіштерінде болатын әлсіз көрсеткіш, қосымша ақпарат алу үшін std/rc.rs қараңыз
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Мазмұны инициализацияланбаған жаңа `Arc` құрастырады, егер бөлу сәтсіз болса, қате қайтарады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Жаңа `Arc`-ті инициализацияланбаған мазмұнмен құрастырады, жады `0` байтпен толтырылады, егер бөлу сәтсіз болса, қате қайтарады.
    ///
    ///
    /// Осы әдісті дұрыс және қате қолдану мысалдары үшін [`MaybeUninit::zeroed`][zeroed] қараңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Ішкі мәнді қайтарады, егер `Arc` дәл бір күшті сілтеме болса.
    ///
    /// Әйтпесе, [`Err`] берілген сол `Arc`-пен қайтарылады.
    ///
    ///
    /// Бұл әлсіз сілтемелер болған жағдайда да сәттілікке жетеді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Күшті-әлсіз сілтемені тазарту үшін әлсіз көрсеткішті жасаңыз
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Мазмұны инициализацияланбаған, атомдық сілтеме бойынша есептелген жаңа кесінді салады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Жады `0` байтпен толтырылған, инициализацияланбаған мазмұны бар жаңа атомдық-анықтамалық есептелген кесінді салады.
    ///
    ///
    /// Осы әдісті дұрыс және қате қолдану мысалдары үшін [`MaybeUninit::zeroed`][zeroed] қараңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>`-ге түрлендіреді.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] сияқты, қоңырау шалушының ішкі мәні шынымен инициалды күйде екеніне кепілдік беруі керек.
    ///
    /// Мазмұн әлі толық инициализацияланбаған кезде оны шақыру дереу анықталмаған әрекеттерді тудырады.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>`-ге түрлендіреді.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] сияқты, қоңырау шалушының ішкі мәні шынымен инициалды күйде екеніне кепілдік беруі керек.
    ///
    /// Мазмұн әлі толық инициализацияланбаған кезде оны шақыру дереу анықталмаған әрекеттерді тудырады.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Оралған көрсеткішті қайтарып, `Arc` тұтынады.
    ///
    /// Жадтың ағып кетуіне жол бермеу үшін меңзерді [`Arc::from_raw`] көмегімен `Arc`-ге қайта айналдыру керек.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Деректерге шикі көрсеткішті ұсынады.
    ///
    /// Санауларға ешқандай әсер етпейді және `Arc` тұтынылмайды.
    /// Көрсеткіш `Arc`-те күшті санау болғанша жарамды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // ҚАУІПСІЗДІК: Бұл Deref::deref немесе RcBoxPtr::inner арқылы өте алмайды, себебі
        // мысалы, мысалы, raw/mut-ті ұстап тұру үшін қажет
        // `get_mut` Rc `from_raw` арқылы қалпына келтірілгеннен кейін көрсеткіш арқылы жаза алады.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Шикі көрсеткіштен `Arc<T>` құрастырады.
    ///
    /// Шикі сілтеме бұрын [`Arc<U>::into_raw`][into_raw] қоңырауымен қайтарылған болуы керек, егер `U` өлшемі мен туралануы `T` сияқты болса.
    /// Егер `U` `T` болса, бұл өте маңызды емес.
    /// Егер `U` `T` болмаса да, өлшемі мен туралануы бірдей болса, бұл негізінен әртүрлі типтегі сілтемелерді түрлендіруге ұқсас екенін ескеріңіз.
    /// Бұл жағдайда қандай шектеулер қолданылатыны туралы көбірек ақпарат алу үшін [`mem::transmute`][transmute] бөлімін қараңыз.
    ///
    /// `from_raw` пайдаланушысы `T` мәнінің тек бір рет төмендегеніне көз жеткізуі керек.
    ///
    /// Бұл функция қауіпті, өйткені дұрыс қолданбау, егер қайтарылған `Arc<T>` ешқашан қол жетімді болмаса да, жадтың қауіпсіздігіне әкелуі мүмкін.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Ағып кетпес үшін `Arc`-ке қайта оралыңыз.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Бұдан әрі `Arc::from_raw(x_ptr)` қоңыраулары жадқа қауіпті болады.
    /// }
    ///
    /// // `x` жоғарыдан тыс болған кезде жад босатылды, сондықтан `x_ptr` енді іліп қалады!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // ArcInner түпнұсқасын табу үшін жылжуды кері жылжытыңыз.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Осы бөлуге жаңа [`Weak`] көрсеткішін жасайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Бұл Relaxed жақсы, өйткені біз төмендегі CAS мәнін тексереміз.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // әлсіз есептегіштің қазіргі уақытта "locked" екенін тексеріңіз;егер солай болса, айналдырыңыз.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: қазіргі уақытта бұл код толып кету мүмкіндігін елемейді
            // usize::MAX ішіне;тұтастай алғанда Rc және Arc екеуін де толып кетуді реттеу үшін реттеу керек.
            //

            // Clone()-тен айырмашылығы, бұл бізге `is_unique`-тен келетін жазумен үндестіру үшін Acquire оқуы болуы керек, осының алдында жазбаға дейінгі оқиғалар осы оқудан бұрын болады.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Біз ілулі әлсіздігімізді жасамауымыз керек
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Осы бөлуге [`Weak`] көрсеткіштерінің санын алады.
    ///
    /// # Safety
    ///
    /// Бұл әдіс өздігінен қауіпсіз, бірақ оны дұрыс қолдану қосымша күтімді қажет етеді.
    /// Басқа жіп кез-келген уақытта әлсіз санды өзгерте алады, соның ішінде осы әдісті шақыру мен нәтижеге әсер ету арасында.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Бұл тұжырым детерминирленген, өйткені біз `Arc` немесе `Weak`-ті жіптер арасында бөліспедік.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Егер әлсіз санау қазір құлыптаулы болса, санақтың мәні құлыпты алудан 0 бұрын болды.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Осы бөлуге күшті (`Arc`) көрсеткіштерінің санын алады.
    ///
    /// # Safety
    ///
    /// Бұл әдіс өздігінен қауіпсіз, бірақ оны дұрыс қолдану қосымша күтімді қажет етеді.
    /// Басқа жіп кез-келген уақытта күшті санақты өзгерте алады, соның ішінде осы әдісті шақыру мен нәтижеге әсер ету арасында.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Бұл тұжырым детерминирленген, өйткені біз `Arc`-ті жіптер арасында бөліспедік.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Берілген меңзермен байланысты `Arc<T>` бойынша анықтамалық санақты бір-бірлеп арттырады.
    ///
    /// # Safety
    ///
    /// Меңзер `Arc::into_raw` арқылы алынған болуы керек, ал байланысты `Arc` данасы жарамды болуы керек (яғни
    /// күшті әдіс осы әдістің ұзақтығы үшін кем дегенде 1 болуы керек.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Бұл тұжырым детерминирленген, өйткені біз `Arc`-ті жіптер арасында бөліспедік.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Доғаны сақтаңыз, бірақ ManualDrop-қа орап, қайта санауға қол тигізбеңіз
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Енді қайта есептеуді көбейтіңіз, бірақ жаңа қайта санауды төмендетпеңіз
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Берілген меңзермен байланысты `Arc<T>` бойынша анықтамалық санақ біртіндеп азаяды.
    ///
    /// # Safety
    ///
    /// Меңзер `Arc::into_raw` арқылы алынған болуы керек, ал байланысты `Arc` данасы жарамды болуы керек (яғни
    /// бұл әдісті қолдану кезінде күшті санау 1-ден кем болмауы керек.
    /// Бұл әдісті соңғы `Arc` және резервтік сақтауды босату үшін қолдануға болады, бірақ **соңғы `Arc` шыққаннан кейін** шақыруға болмайды.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Бұл тұжырымдар детерминирленген, өйткені біз `Arc`-ті жіптер арасында бөліспедік.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Бұл қауіпті емес, өйткені бұл доға тірі болған кезде біз ішкі көрсеткіштің жарамды екеніне кепілдік береміз.
        // Сонымен қатар, біз `ArcInner` құрылымының өзі `Sync` екенін білеміз, өйткені ішкі деректер де `Sync`, сондықтан біз бұл мазмұнға өзгермейтін көрсеткішті ұсынамыз.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` сызығы жоқ бөлігі.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Қазіргі уақытта деректерді жойыңыз, бірақ біз қорапты бөлуді босатпасақ та болады (әлсіз көрсеткіштер әлі де айналасында болуы мүмкін).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Барлық күшті сілтемелерге негізделген әлсіз рефті тастаңыз
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Егер екі Arc бір бөлуді көрсетсе ([`ptr::eq`]-ге ұқсас венада), `true` мәнін қайтарады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Мүмкін өлшемделмеген ішкі мән үшін жеткілікті кеңістігі бар `ArcInner<T>`-ті бөледі, онда мәнде орналасу бар.
    ///
    /// `mem_to_arcinner` функциясы деректер көрсеткішімен бірге шақырылады және `ArcInner<T>` үшін (әлеуетті май) көрсеткішті қайтаруы керек.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Берілген мәндер орналасуын пайдаланып орналасуды есептеңіз.
        // Бұрын орналасу `&*(ptr as* const ArcInner<T>)` өрнегі бойынша есептелген, бірақ бұл дұрыс емес анықтаманы тудырды (#54908 қараңыз).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Мүмкін өлшемделмеген ішкі мән үшін жеткілікті кеңістігі бар `ArcInner<T>`-ті бөледі, егер мәнде орналасу берілген болса, қате қайтарылады.
    ///
    ///
    /// `mem_to_arcinner` функциясы деректер көрсеткішімен бірге шақырылады және `ArcInner<T>` үшін (әлеуетті май) көрсеткішті қайтаруы керек.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Берілген мәндер орналасуын пайдаланып орналасуды есептеңіз.
        // Бұрын орналасу `&*(ptr as* const ArcInner<T>)` өрнегі бойынша есептелген, бірақ бұл дұрыс емес анықтаманы тудырды (#54908 қараңыз).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner инициализациясы
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Өлшемделмеген ішкі мән үшін жеткілікті кеңістігі бар `ArcInner<T>` бөледі.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Берілген мәнді пайдаланып `ArcInner<T>` үшін бөліңіз.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Мәнді байт түрінде көшіру
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Мазмұнын түсірмей бөлуді босатыңыз
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Берілген ұзындықпен `ArcInner<[T]>` бөледі.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Элементтерді тілімнен жаңадан бөлінген Arc <\[T\]> ішіне көшіріңіз
    ///
    /// Қауіпті, себебі қоңырау шалушы меншікті иемденуі немесе `T: Copy` байланыстыруы керек.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Белгілі бір мөлшерде болатын итератордан `Arc<[T]>` құрастырады.
    ///
    /// Өлшемі дұрыс болмауы керек мінез-құлық анықталмаған.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // T элементтерін клондау кезінде Panic күзеті.
        // panic жағдайында жаңа ArcInner ішіне жазылған элементтер түсіріледі, содан кейін жад босатылады.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Бірінші элементті көрсетіңіз
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Барлығы түсінікті.Жаңа ArcInner босатпауы үшін күзетшіні ұмытыңыз.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` үшін қолданылатын trait мамандануы.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` көрсеткішінің клонын жасайды.
    ///
    /// Бұл бірдей сілтемеге тағы бір сілтеме жасайды, күшті сілтеме санын көбейтеді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Бұл жерде жұмсақ тапсырысты қолдану жақсы, өйткені бастапқы сілтеме туралы білім басқа жіптердің нысанды қате түрде жоюына жол бермейді.
        //
        // [Boost documentation][1]-де түсіндірілгендей, анықтамалық есептегішті көбейту әрдайым memory_order_relaxed көмегімен жасалуы мүмкін: объектіге жаңа сілтемелер тек бар сілтеме арқылы жасалуы мүмкін, ал бар сілтемені бір ағыннан екіншісіне беру кез-келген қажетті синхрондауды қамтамасыз етуі керек.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Алайда, егер біреу Arcs 'mem: : ұмытып' жатса, біз оны қайта санаудан жаппай сақтанғанымыз жөн.
        // Егер біз мұны жасамасақ, санау толып кетуі мүмкін және пайдаланушылар ақысыз пайдалануды алады.
        // Біз `isize::MAX`-ке бірден қанықтырамыз, егер сілтеме санын бірден арттыратын ~2 миллиард ағындар жоқ.
        //
        // Бұл branch ешқашан нақты бағдарламада қабылданбайды.
        //
        // Біз мұндай бағдарламаны мүлдем азғындағандықтан, түсік тастаймыз, сондықтан оны қолдаудың қажеті жоқ.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Берілген `Arc`-ге өзгертілетін сілтеме жасайды.
    ///
    /// Егер бірдей бөлуге басқа `Arc` немесе [`Weak`] көрсеткіштері болса, онда `make_mut` жаңа бөлу жасайды және бірегей иелік етуді қамтамасыз ету үшін ішкі мәнге [`clone`][clone]-ті шақырады.
    /// Мұны жазуға клондау деп те атайды.
    ///
    /// Бұл [`Rc::make_mut`]-тің қалған `Weak` көрсеткіштерін ажырататын мінез-құлқынан ерекшеленетінін ескеріңіз.
    ///
    /// Сондай-ақ, [`get_mut`][get_mut]-ті қараңыз, ол клондаудың орнына сәтсіздікке ұшырайды.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Ештеңе клондамайды
    /// let mut other_data = Arc::clone(&data); // Ішкі деректерді клондамайды
    /// *Arc::make_mut(&mut data) += 1;         // Ішкі деректерді клондайды
    /// *Arc::make_mut(&mut data) += 1;         // Ештеңе клондамайды
    /// *Arc::make_mut(&mut other_data) *= 2;   // Ештеңе клондамайды
    ///
    /// // Енді `data` және `other_data` әртүрлі бөлінулерге нұсқайды.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Бізде күшті сілтеме де, әлсіз сілтеме де бар екенін ескеріңіз.
        // Осылайша, біздің анық сілтемені шығару өздігінен жадтың бөлінуіне әкелмейді.
        //
        // `weak`-ге жазулардың (мысалы, азаюдың) `strong`-ге шығарылғанға дейінгі кез-келген жазбаларын көру үшін, сатып алуды пайдаланыңыз.
        // Бізде әлсіз санау болғандықтан, ArcInner-дің өзін бөлуге мүмкіндік жоқ.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Тағы бір мықты көрсеткіш бар, сондықтан біз клондауымыз керек.
            // Клондалған мәнді тікелей жазуға мүмкіндік беру үшін жадты алдын-ала бөліңіз.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Жоғарыда айтылғандарға жеткілікті, өйткені бұл оңтайландыру болып табылады: біз әрқашан әлсіз көрсеткіштерді тастай отырып жарысамыз.
            // Ең сорақысы, біз қажетсіз жаңа доға бөлдік.
            //

            // Біз соңғы күшті рефекті алып тастадық, бірақ қосымша әлсіз рефтер қалды.
            // Біз мазмұнын жаңа доғаға ауыстырамыз, ал қалған әлсіз реферлерді жарамсыз етеміз.
            //

            // `weak` көрсеткішінің usize::MAX шығуы мүмкін емес екенін ескеріңіз (яғни, құлыпталған), өйткені әлсіз санауды тек күшті сілтеме бар жіппен құлыптауға болады.
            //
            //

            // ArcInner-ді қажет болған жағдайда тазарта алатындай, біздің жасырын әлсіз көрсеткішті материалдандырыңыз.
            //
            let _weak = Weak { ptr: this.ptr };

            // Тек деректерді ұрлай алады, тек әлсіздер қалады
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Біз кез-келген түрдегі жалғыз сілтеме болдық;күшті реферекті санау.
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()` сияқты, қауіпсіз емес, өйткені біздің сілтеме тек бірегей болды немесе мазмұнды клондау кезінде болды.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Егер бірдей бөлуге басқа `Arc` немесе [`Weak`] көрсеткіштері болмаса, өзгертілетін сілтемені берілген `Arc`-ке қайтарады.
    ///
    ///
    /// Басқа жағдайда [`None`] мәнін қайтарады, өйткені ортақ мәннің мутациясы қауіпсіз емес.
    ///
    /// Басқа көрсеткіштер болған кезде ішкі мәнді [`clone`][clone] болатын [`make_mut`][make_mut] қараңыз.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Бұл қауіпті емес, өйткені қайтарылған көрсеткіш тек T-ге қайтарылатын *жалғыз* көрсеткіш екеніне кепілдік береміз.
            // Біздің анықтамалық санымыз осы сәтте 1-ге кепілдендірілген және біз доғаның өзін `mut` болуын талап еттік, сондықтан ішкі деректерге мүмкін болатын жалғыз сілтемені қайтарамыз.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Берілген `Arc`-ге өзгертілетін сілтемені ешқандай тексерусіз қайтарады.
    ///
    /// Сондай-ақ қауіпсіз және тиісті тексерулер жүргізетін [`get_mut`] қараңыз.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Қайтарылған қарыз мерзімі ішінде кез-келген басқа `Arc` немесе [`Weak`] көрсеткіштері бірдей бөлінуге жіберілмеуі керек.
    ///
    /// Егер мұндай көрсеткіштер болмаса, мысалы, `Arc::new` кейін бірден болады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Біз "count" өрістерін қамтитын анықтаманы *жасамауға* абаймыз, өйткені бұл сілтемелер санына бір уақытта қол жеткізуге мүмкіндік береді (мысалы.
        // `Weak` бойынша).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Бұл түпнұсқа деректерге бірегей сілтеме (соның ішінде әлсіз сілтемелер) екенін анықтаңыз.
    ///
    ///
    /// Бұл әлсіз реферекті санауды құлыптауды қажет ететіндігін ескеріңіз.
    fn is_unique(&mut self) -> bool {
        // егер біз әлсіз көрсеткіш ұстаушы болып көрінсек, әлсіз көрсеткіштер санын құлыптаңыз.
        //
        // Мұндағы сатып алу белгісі `weak` санының кемуіне (`Weak::drop` арқылы, босатуды қолданғанға дейін) кез-келген `strong`-ке (әсіресе `Weak::upgrade`-ге) жазулармен байланысты қатынасты қамтамасыз етеді.
        // Егер жаңартылған әлсіз рефер ешқашан түсірілмесе, CAS сәтсіздікке ұшырайды, сондықтан синхрондау бізге маңызды емес.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Бұл `drop` есептегішінің азаюымен синхрондау үшін `Acquire` болуы керек-`drop`-соңғы сілтемеден басқа кез келген кез келген кезде болатын жалғыз қатынас.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Мұндағы шығарылым `downgrade` оқылымымен үндестіріліп, `strong` оқылымының жазудан кейін орын алуына жол бермейді.
            //
            //
            self.inner().weak.store(1, Release); // құлыпты босатыңыз
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` тастайды.
    ///
    /// Бұл анықтамалық санды азайтады.
    /// Егер күшті сілтеме саны нөлге жетсе, онда басқа сілтемелер (егер бар болса) [`Weak`] болып табылады, сондықтан біз ішкі мәнді `drop` деп санаймыз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Ештеңе басып шығармайды
    /// drop(foo2);   // "dropped!" басып шығарады
    /// ```
    #[inline]
    fn drop(&mut self) {
        // `fetch_sub` қазірдің өзінде атомды болғандықтан, біз объектіні жоймасақ, басқа ағындармен синхрондаудың қажеті жоқ.
        // Дәл осы логика төмендегі `fetch_sub` үшін `weak` санына қатысты.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Бұл қоршау деректерді пайдаланудың қайта реттелуіне және деректердің жойылуына жол бермеу үшін қажет.
        // Ол `Release` деп белгіленгендіктен, санақ санының азаюы осы `Acquire` қоршауымен синхрондалады.
        // Бұл дегеніміз, деректерді пайдалану анықтамалық санды азайту алдында болады, бұл қоршау алдында болады, ол деректерді жойғанға дейін болады.
        //
        // [Boost documentation][1]-де түсіндірілгендей,
        //
        // > Нысанға кез-келген ықтимал қол жетімділікті біреуден қамтамасыз ету маңызды
        // > ағынды (бар сілтеме арқылы)*жоюдан* бұрын орын алады
        // > басқа жіптегі объект.Бұған "release" қол жеткізеді
        // > анықтаманы тастағаннан кейінгі жұмыс (объектіге кез-келген қол жетімділік
        // > осы сілтеме арқылы бұрын болғаны анық), және
        // > "acquire" нысанды жоймас бұрын жұмыс.
        //
        // Атап айтқанда, доғаның мазмұны өзгермейтін болса да, Mutex сияқты интерьерге жазба жасауға болады.<T>.
        // Mutex жойылған кезде сатып алынбағандықтан, біз A ағынында жазуларды B ағынында жұмыс істейтін деструкторға көрінетін етіп жасау үшін оның синхрондау логикасына сүйене алмаймыз.
        //
        //
        // Сондай-ақ, мұндағы сатып алу қоршауын Acquire жүктемесімен алмастыруға болатындығын ескеріңіз, бұл өте даулы жағдайларда өнімділігін арттыра алады.[2] қараңыз.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>`-ті нақты түрге түсіруге тырысу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Ешқандай жад бөлмей, жаңа `Weak<T>` құрастырады.
    /// Қайтарылатын мәнге [`upgrade`] қоңырауы әрқашан [`None`] береді.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Мәліметтер өрісіне қатысты ешқандай дәлелдемелерсіз сілтемелер санына қол жеткізуге мүмкіндік беретін көмекші теріңіз.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Осы `Weak<T>` көрсеткен `T` объектісіне шикі көрсеткішті қайтарады.
    ///
    /// Меңзер сілтемелер болған жағдайда ғана жарамды.
    /// Меңзер ілулі, тегістелмеген немесе тіпті [`null`] болуы мүмкін.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Екеуі де бір затты нұсқайды
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Мұндағы күштілер оны тірі ұстайды, сондықтан біз объектіге қол жеткізе аламыз.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Бірақ енді жоқ.
    /// // Біз weak.as_ptr() жасай аламыз, бірақ көрсеткішке қол жеткізу анықталмаған әрекетке әкеледі.
    /// // assert_eq! («сәлем», қауіпті {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Егер көрсеткіш салбырап тұрса, біз күзетшіні тікелей қайтарамыз.
            // Бұл жарамды жүктеме мекен-жайы бола алмайды, өйткені пайдалы жүктеме, кем дегенде, ArcInner (usize) сияқты тураланған.
            ptr as *const T
        } else {
            // ҚАУІПСІЗДІК: егер is_dangling мәні жалған болса, онда сілтеме дериферацияланатын болады.
            // Осы сәтте пайдалы жүктеме төмендеуі мүмкін, сондықтан біз тексерілімді сақтап қалуымыз керек, сондықтан шикі нұсқағыш манипуляциясын қолданыңыз.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` тұтынады және оны шикі көрсеткішке айналдырады.
    ///
    /// Бұл әлсіз сілтемені шикі көрсеткішке айналдырады, сонымен бірге бір әлсіз сілтеменің меншігін сақтайды (әлсіз санау бұл операциямен өзгертілмейді).
    /// Оны [`from_raw`] көмегімен қайтадан `Weak<T>`-ге айналдыруға болады.
    ///
    /// Көрсеткіштің мақсатына [`as_ptr`] сияқты шектеулер қолданылады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Бұрын [`into_raw`] жасаған шикі көрсеткішті `Weak<T>`-ке қайта түрлендіреді.
    ///
    /// Мұны сенімді анықтаманы алу үшін ([`upgrade`] кейінірек қоңырау шалу арқылы) немесе `Weak<T>` түсіру арқылы әлсіз санды бөлу үшін пайдалануға болады.
    ///
    /// Ол бір әлсіз анықтамаға иелік етуді қажет етеді ([`new`] жасаған көрсеткіштерден басқа, өйткені олар ешнәрсеге иелік етпейді; әдіс оларда жұмыс істейді).
    ///
    /// # Safety
    ///
    /// Меңзер [`into_raw`]-тен шыққан болуы керек және әлсіз әлсіз сілтемеге ие болуы керек.
    ///
    /// Мұны шақырған кезде күшті санау 0-ге тең болады.
    /// Дегенмен, бұл қазіргі уақытта шикі көрсеткіш ретінде ұсынылған бір әлсіз сілтемеге иелік етеді (әлсіз сан осы операциямен өзгертілмейді), сондықтан оны алдыңғы [`into_raw`] қоңырауымен жұптастыру керек.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Соңғы әлсіз санды азайту.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Кіріс сілтемесі қалай алынғандығы туралы контекстті Weak::as_ptr-тен қараңыз.

        let ptr = if is_dangling(ptr as *mut T) {
            // Бұл әлсіз әлсіреу.
            ptr as *mut ArcInner<T>
        } else {
            // Әйтпесе, көрсеткіштің әлсіз жақтан шыққанына кепілдік береміз.
            // ҚАУІПСІЗДІК: data_offset қоңырау шалу қауіпсіз, өйткені ptr сілтемесі нақты (ықтимал түсіп қалған) Т.
            let offset = unsafe { data_offset(ptr) };
            // Осылайша, біз бүкіл RcBox алу үшін ығысуды кері қайтарамыз.
            // ҚАУІПСІЗДІК: нұсқау әлсізден шыққан, сондықтан бұл ығысу қауіпсіз.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ҚАУІПСІЗДІК: біз қазір әлсіз нұсқағышты қалпына келтірдік, сондықтан әлсіздерді де жасай аламыз.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` меңзерін [`Arc`] деңгейіне дейін жаңартуға тырысады, егер сәтті болған жағдайда ішкі мәннің түсуін кешіктіреді.
    ///
    ///
    /// Егер ішкі мән содан бері түсірілсе, [`None`] мәнін қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Барлық күшті көрсеткіштерді жойыңыз.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Біз fetch_add орнына күшті санды ұлғайту үшін CAS циклін қолданамыз, өйткені бұл функция ешқашан анықтамалық санды нөлден бірге алмауы керек.
        //
        //
        let inner = self.inner()?;

        // Босаңсыған жүктеме, өйткені біз 0-дің кез-келген жазуы өрісті толығымен нөлдік күйде қалдырады (сондықтан 0-дің "stale" көрсеткіші жақсы) және кез-келген басқа мән төмендегі CAS арқылы расталады.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Мұны не үшін жасайтынымызды `Arc::clone` ішіндегі түсініктемелерден қараңыз (`mem::forget` үшін).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed істен шыққан жағдайда жақсы, өйткені бізде жаңа күй туралы күту жоқ.
            // Сатып алу сәтті жағдайда `Arc::new_cyclic` синхрондалуы үшін қажет, егер `Weak` сілтемелер жасалғаннан кейін ішкі мәнді инициалдаса болады.
            // Бұл жағдайда біз толық инициализацияланған мәнді сақтаймыз деп күтеміз.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // нөл жоғарыда тексерілген
                Err(old) => n = old,
            }
        }
    }

    /// Осы бөлуді көрсететін күшті (`Arc`) көрсеткіштерінің санын алады.
    ///
    /// Егер `self` [`Weak::new`] көмегімен жасалған болса, бұл 0 мәнін береді.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Осы бөлуге бағытталған `Weak` көрсеткіштерінің санына жуықтайды.
    ///
    /// Егер `self` [`Weak::new`] көмегімен жасалған болса немесе қалған күшті көрсеткіштер болмаса, бұл 0 мәнін қайтарады.
    ///
    /// # Accuracy
    ///
    /// Іске асырудың егжей-тегжейіне байланысты, басқа ағындар кез келген `Arc` немесе`Weak` белгілерін бірдей бөлуді меңзеген кезде, кез келген бағытта 1-ге өшірілуі мүмкін.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Әлсіз санауды оқығаннан кейін кем дегенде бір күшті көрсеткіш болғанын байқағандықтан, әлсіз сілтеме (кез-келген күшті сілтемелер тірі болған кезде бар) әлсіз санауды бақылаған кезде әлі де болғанын білеміз, сондықтан оны қауіпсіз түрде алып тастай аламыз.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Сілтегіш салбырап тұрған кезде және бөлінген `ArcInner` болмаған кезде `None` мәнін қайтарады (яғни, бұл `Weak` `Weak::new` құрған кезде).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Біз "data" өрісін қамтитын анықтаманы *жасамауға* абаймыз, өйткені өріс бір уақытта мутацияға ұшырауы мүмкін (мысалы, егер соңғы `Arc` түсірілсе, деректер өрісі орнында түсіп қалады).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Егер екі әлсіздер бірдей бөлуді көрсетсе ([`ptr::eq`]-ге ұқсас) немесе екеуі де қандай да бір бөлуді көрсетпесе (өйткені олар `Weak::new()`) көмегімен жасалған), `true` мәнін қайтарады.
    ///
    ///
    /// # Notes
    ///
    /// Бұл көрсеткіштерді салыстырғандықтан, бұл `Weak::new()` бір-біріне тең болады, дегенмен олар ешқандай бөлуді көрсетпейді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` салыстыру.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// `Weak` көрсеткішінің бірдей бөлінуіне нұсқайтын клон жасайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Неліктен бұл босаңсығанын Arc::clone() ішіндегі түсініктемелерден қараңыз.
        // Бұл fetch_add (құлыпты елемей) қолдана алады, өйткені әлсіз санау тек *басқа* әлсіз көрсеткіштер болмаған жерде ғана құлыпталады.
        //
        // (Сондықтан біз бұл жағдайда бұл кодты іске асыра алмаймыз).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Мұны не үшін жасайтынымызды Arc::clone() ішіндегі түсініктемелерден қараңыз (mem::forget үшін).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Жадын бөлмей, жаңа `Weak<T>` құрастырады.
    /// Қайтарылатын мәнге [`upgrade`] қоңырауы әрқашан [`None`] береді.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` меңзерін тастайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ештеңе басып шығармайды
    /// drop(foo);        // "dropped!" басып шығарады
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Егер біз соңғы әлсіз көрсеткіш болғанымызды білетін болсақ, онда деректерді толығымен бөлуге уақыт келді.Жадқа тапсырыс беру туралы Arc::drop() дискуссиясын қараңыз
        //
        // Мұнда құлыптаулы күйді тексеру қажет емес, өйткені әлсіз санды дәл бір әлсіз реф болған жағдайда ғана бұғаттауға болады, яғни құлдырау құлып босатылғаннан кейін ғана орын алатын әлсіз әлсіз рефункцияны кейін іске қосуы мүмкін.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Біз бұл мамандандыруды осында жасаймыз, және `&T`-тегі жалпы оңтайландыру емес, өйткені ол әйтпесе барлық теңдік тексерулеріне шығындар қосады.
/// Біздің ойымызша, «Arc`» клондау баяу, бірақ теңдікті тексеру үшін үлкен мәндерді сақтау үшін пайдаланылады, бұл шығындарды жеңілдетеді.
///
/// Сондай-ақ, екі бірдей X-X клондары болуы мүмкін, олар бірдей мәнді көрсетеді, екі&T`-ге қарағанда.
///
/// Біз мұны тек `T: Eq` `PartialEq` ретінде әдейі рефлексивті болуы мүмкін болған кезде жасай аламыз.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Екі Arc үшін теңдік.
    ///
    /// Екі `Arc` тең болады, егер олардың ішкі мәндері тең болса, тіпті олар әртүрлі бөліністе сақталса да.
    ///
    /// Егер `T` сонымен қатар `Eq` (теңдіктің рефлексивтілігін білдіреді) жүзеге асырса, бірдей бөлуді көрсететін екі «Arc» әрқашан тең болады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Екі Arc үшін теңсіздік.
    ///
    /// Екі `Arc` тең емес, егер олардың ішкі мәндері тең болмаса.
    ///
    /// Егер `T` сонымен қатар `Eq` (теңдіктің рефлексивтілігін білдіретін) жүзеге асырса, бірдей мәнді көрсететін екі Arc` ешқашан тең болмайды.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Екі «Arc» үшін ішінара салыстыру.
    ///
    /// Екеуі ішкі құндылықтар бойынша `partial_cmp()` қоңырауы арқылы салыстырылады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Екі Arc үшін салыстыруға қарағанда аз.
    ///
    /// Екеуі ішкі құндылықтар бойынша `<` қоңырауы арқылы салыстырылады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Екі «Arc» үшін «кем немесе тең» салыстыру.
    ///
    /// Екеуі ішкі құндылықтар бойынша `<=` қоңырауы арқылы салыстырылады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Екі Arc үшін салыстырудан үлкен.
    ///
    /// Екеуі ішкі құндылықтар бойынша `>` қоңырауы арқылы салыстырылады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Екі «Arc» үшін «үлкен немесе тең» салыстыру.
    ///
    /// Екеуі ішкі құндылықтар бойынша `>=` қоңырауы арқылы салыстырылады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Екі Arc үшін салыстыру.
    ///
    /// Екеуі ішкі құндылықтар бойынша `cmp()` қоңырауы арқылы салыстырылады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` үшін `Default` мәні бар жаңа `Arc<T>` жасайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Анықтамалық есептелген кесінді бөліп, оны `v` элементтерін клондау арқылы толтырыңыз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Анықтамалық есептелген `str` бөліп, оған `v` көшіріңіз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Анықтамалық есептелген `str` бөліп, оған `v` көшіріңіз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Қораптағы нысанды сілтеме бойынша есептелген жаңа бөлуге көшіріңіз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Анықтамалық есептелген кесінді бөліп, оған `v` элементтерін жылжытыңыз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec-ке оның жадын босатуға мүмкіндік беріңіз, бірақ оның мазмұнын жоймаңыз
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// `Iterator` ішіндегі әрбір элементті алады және оны `Arc<[T]>` түрінде жинайды.
    ///
    /// # Өнімділік сипаттамалары
    ///
    /// ## Жалпы жағдай
    ///
    /// Жалпы жағдайда `Arc<[T]>`-ге жинау алдымен `Vec<T>`-ке жиналу арқылы жүзеге асырылады.Яғни, келесілерді жазған кезде:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// бұл біз жазғандай әрекет етеді:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Бөлудің бірінші жиынтығы осы жерде болады.
    ///     .into(); // `Arc<[T]>` үшін екінші бөлу осында болады.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Бұл `Vec<T>` құру үшін қанша керек болса, сонша рет `Vec<T>`-ті `Arc<[T]>`-ке айналдыру үшін бөледі.
    ///
    ///
    /// ## Ұзындығы белгілі итераторлар
    ///
    /// Егер сіздің `Iterator` `TrustedLen`-ті жүзеге асырады және дәл өлшемде болғанда, `Arc<[T]>` үшін жалғыз бөлу жасалады.Мысалға:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Мұнда тек бір ғана қаражат бөлінеді.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// `Arc<[T]>`-ге жинау үшін қолданылатын trait мамандануы.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Бұл `TrustedLen` итераторына қатысты.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // ҚАУІПСІЗДІК: Біз итератордың дәл ұзындығына көз жеткізуіміз керек.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Қалыпты іске асыруға қайта оралыңыз.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Көрсеткіштің артындағы пайдалы жүктеме үшін `ArcInner` ішіндегі жылжуды алыңыз.
///
/// # Safety
///
/// Сілтегіш бұрын жарамды T данасын көрсетуі керек (және олар үшін жарамды метадеректерге ие болуы керек), бірақ T-ді тастауға рұқсат етіледі.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Өлшемделмеген мәнді ArcInner соңына туралаңыз.
    // RcBox repr(C) болғандықтан, ол әрдайым жадындағы соңғы өріс болып қалады.
    // ҚАУІПСІЗДІК: тек өлшемді емес түрлері тек тілімдер, trait нысандары болуы мүмкін,
    // және сыртқы түрлер, енгізу қауіпсіздігі талабы қазіргі уақытта align_of_val_raw талаптарын қанағаттандыру үшін жеткілікті;бұл std-тен тыс тілге сенуге болмайтын тілді енгізу бөлшегі.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}