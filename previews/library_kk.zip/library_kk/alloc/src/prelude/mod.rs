//! Prelude бөлу
//!
//! Бұл модульдің мақсаты модульдердің жоғарғы жағына глобус импортын қосу арқылы `alloc` crate жиі қолданылатын заттарының импортын жеңілдету болып табылады:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;