//! UTF-8-кодталған, өсірілетін жол.
//!
//! Бұл модульде [`String`] типі, жолдарға түрлендіруге арналған [`ToString`] trait және [`String`]-тармен жұмыс жасау нәтижесінде пайда болатын бірнеше қате түрлері бар.
//!
//!
//! # Examples
//!
//! Жолдық әріптен жаңа [`String`] жасаудың бірнеше әдісі бар:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Бұрыннан жаңа [`String`] құруға болады
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Егер сізде жарамды UTF-8 байт vector болса, сіз одан [`String`] жасай аласыз.Сіз керісінше де жасай аласыз.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Біз бұл байттардың жарамды екенін білеміз, сондықтан біз `unwrap()` қолданамыз.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// UTF-8-кодталған, өсірілетін жол.
///
/// `String` типі-жолдың мазмұнына иелік ететін ең көп таралған жол түрі.Ол өзінің қарыздық әріптесімен, қарабайыр [`str`]-пен тығыз қарым-қатынаста.
///
/// # Examples
///
/// Сіз `String`-ті [a literal string][`str`]-тен [`String::from`] көмегімен жасай аласыз:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Сіз [`char`]-ті `String`-ге [`push`] әдісімен қосуға болады және [`&str`]-ті [`push_str`] әдісімен қосуға болады:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Егер сізде UTF-8 байт vector болса, сіз [`from_utf8`] әдісімен одан `String` жасай аласыз:
///
/// ```
/// // кейбір байттар, vector түрінде
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Біз бұл байттардың жарамды екенін білеміз, сондықтан біз `unwrap()` қолданамыз.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// Жолдар әрқашан UTF-8 жарамды.Мұның бірнеше мәні бар, оның біріншісі, егер сізге UTF-8 емес жол қажет болса, [`OsString`] қарастырыңыз.Бұл ұқсас, бірақ UTF-8 шектеусіз.Екінші қорытынды, сіз `String`-ге индекстей алмайсыз:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Индекстеу тұрақты жұмыс режиміне арналған, бірақ UTF-8 кодтау бұған мүмкіндік бермейді.Сонымен қатар, индекс қандай нәрсені қайтаруы керек екендігі белгісіз: байт, код нүктесі немесе графема кластері.
/// [`bytes`] және [`chars`] әдістері сәйкесінше алғашқы екеуінде итераторларды қайтарады.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s [« Deref`] »жүзеге асырады<Target=str>, және [[str`] барлық әдістерін мұра етіп алыңыз.Сонымен қатар, бұл `String` амперсанд пен (`&`) көмегімен [`&str`] қабылдайтын функцияға беруге болатындығын білдіреді:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Бұл `String`-тен [`&str`] жасайды және оны жібереді. Бұл түрлендіру өте арзан, сондықтан, егер функциялар белгілі бір себептермен `String`-ті қажет етпесе, ['&str`]-ді аргумент ретінде қабылдайды.
///
/// Кейбір жағдайларда Rust-да [`Deref`] мәжбүрлеу деп аталатын осы түрлендіруді жүзеге асыру үшін жеткілікті ақпарат жоқ.Келесі мысалда [`&'a str`][`&str`] тізбегі trait `TraitExample`-ті жүзеге асырады, ал `example_func` функциясы trait-ді іске асыратын кез-келген нәрсені алады.
/// Бұл жағдайда Rust екі жасырын түрлендіруді қажет етеді, бұл Rust жасауға мүмкіндігі жоқ.
/// Сол себепті келесі мысал құрастырылмайды.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Оның орнына жұмыс істейтін екі нұсқа бар.Біріншісі, жолды қамтитын жол кесіндісін анық шығару үшін [`as_str()`] әдісін қолдана отырып, `example_func(&example_string);` жолын `example_func(example_string.as_str());`-ге ауыстыру.
/// Екінші тәсіл `example_func(&example_string);`-ті `example_func(&*example_string);`-ге өзгертеді.
/// Бұл жағдайда біз `String`-ті [`str`][`&str`]-тен ажыратамыз, содан кейін [`str`][`&str`]-ті [`&str`]-ке қайтарамыз.
/// Екінші әдіс идиомалық болып табылады, бірақ екеуі де конверсияны жасырын түрлендіруге емес, нақты түрде жасауға тырысады.
///
/// # Representation
///
/// `String` үш компоненттен тұрады: кейбір байттарға көрсеткіш, ұзындық және сыйымдылық.Меңзер ішкі деректерді сақтау үшін пайдаланылатын `String` буферін көрсетеді.Ұзындық-бұл буферде сақталған байт саны, ал сыйымдылық-буфердегі байт өлшемі.
///
/// Осылайша, ұзындық әрқашан сыйымдылықтан аз немесе оған тең болады.
///
/// Бұл буфер әрқашан үйіндіде сақталады.
///
/// Бұларды [`as_ptr`], [`len`] және [`capacity`] әдістерімен қарауға болады:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME vec_into_raw_parts тұрақтандырылған кезде оны жаңартыңыз.
/// // Жолдың деректерін автоматты түрде тастауға жол бермеңіз
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // хикаяттың он тоғыз байты бар
/// assert_eq!(19, len);
///
/// // Біз жолды ptr, len және сыйымдылықтан қайта құра аламыз.
/// // Мұның бәрі қауіпті, себебі біз компоненттердің жарамды екеніне көз жеткіземіз:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Егер `String` сыйымдылығы жеткілікті болса, оған элементтер қосу қайтадан бөлінбейді.Мысалы, мына бағдарламаны қарастырайық:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Бұл келесілерді шығарады:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Бастапқыда бізде жады мүлдем бөлінбейді, бірақ жолға қосылған кезде оның сыйымдылығы сәйкесінше артады.Егер оның орнына бастапқыда дұрыс сыйымдылықты бөлу үшін [`with_capacity`] әдісін қолдансақ:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Біз басқаша нәтижемен аяқтаймыз:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Мұнда цикл ішінде көбірек жадыны бөлудің қажеті жоқ.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// `String`-ті UTF-8 байттан vector түрлендіру кезіндегі мүмкін қателік мәні.
///
/// Бұл тип-[`String`] жүйесіндегі [`from_utf8`] әдісі үшін қате түрі.
/// Ол қайта бөлуді болдырмау үшін осылай жасалған: [`into_bytes`] әдісі конверсиялау кезінде қолданылған vector байтын қайтарады.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] типі ұсынатын [`Utf8Error`] типі [`u8`] s кесіндісін [`&str`] түрлендіру кезінде пайда болуы мүмкін қатені білдіреді.
/// Бұл мағынада бұл `FromUtf8Error` аналогы және сіз оны `FromUtf8Error`-тен [`utf8_error`] әдісі арқылы ала аласыз.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Негізгі пайдалану:
///
/// ```
/// // кейбір жарамсыз байттар, vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// `String`-ті UTF-16 байт тілімінен түрлендіру кезінде мүмкін қателік мәні.
///
/// Бұл тип-[`String`] жүйесіндегі [`from_utf16`] әдісі үшін қате түрі.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Негізгі пайдалану:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Жаңа бос `String` жасайды.
    ///
    /// `String` бос екенін ескерсек, бұл ешқандай бастапқы буферді бөлмейді.Бұл дегеніміз, бұл алғашқы операция өте арзан, бірақ кейінірек деректер қосқан кезде шамадан тыс бөлінуді тудыруы мүмкін.
    ///
    /// Егер сізде `String` қанша дерек сақтайтыны туралы ойыңыз болса, шамадан тыс қайта орналастырудың алдын алу үшін [`with_capacity`] әдісін қарастырыңыз.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Белгілі бір сыйымдылығы бар жаңа бос `String` жасайды.
    ///
    /// String`s-де олардың деректерін ұстауға арналған ішкі буфер бар.
    /// Сыйымдылығы-бұл буфердің ұзындығы және оны [`capacity`] әдісімен сұрауға болады.
    /// Бұл әдіс бос `String` жасайды, бірақ `capacity` байттарын сақтай алатын бастапқы буфері бар.
    /// Бұл `String`-ге көптеген деректер қосымшасы қажет болған кезде пайдалы, ол оны қайта бөлудің санын азайтады.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Егер берілген сыйымдылық `0` болса, онда ешқандай бөлу болмайды және бұл әдіс [`new`] әдісімен бірдей.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Жолда одан да көп сыйымдылық болса да, ешқандай белгілер болмайды
    /// assert_eq!(s.len(), 0);
    ///
    /// // Мұның бәрі қайта бөлінбестен жасалады ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... бірақ бұл жолды қайта бөлуге мәжбүр етуі мүмкін
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): бұл әдісті анықтау үшін қажет болатын cfg(test) әдісі қол жетімді емес.
    // Бұл әдісті тестілеу үшін қажет етпейтіндіктен, мен оны ескертемін, тек қосымша ақпарат үшін slice::hack модулін slice.rs ішінен қараңыз
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// vector байттарын `String` түрлендіреді.
    ///
    /// ([`String`]) жолы ([`u8`]) байттан, ал ([`Vec<u8>`]) байтының vector байттан жасалған, сондықтан бұл функция екеуінің арасында түрленеді.
    /// Барлық байт тілімдері жарамды емес 'String`s, алайда: `String` оның жарамды UTF-8 болуын талап етеді.
    /// `from_utf8()` байттардың UTF-8 жарамдылығын тексереді, содан кейін түрлендіреді.
    ///
    /// Егер сіз байт тілімінің UTF-8 жарамды екендігіне сенімді болсаңыз және сіз жарамдылықты тексеруге қосымша шығындар жасағыңыз келмесе, онда осы функцияның қауіпті нұсқасы бар, дәл осындай мінез-құлыққа ие, бірақ тексеруді өткізіп жібереді, [`from_utf8_unchecked`].
    ///
    ///
    /// Бұл әдіс тиімділік үшін vector көшірмесін жасамауға тырысады.
    ///
    /// Егер сізге `String` орнына [`&str`] керек болса, [`str::from_utf8`] қарастырыңыз.
    ///
    /// Бұл әдіске керісінше-[`into_bytes`].
    ///
    /// # Errors
    ///
    /// Егер тілім UTF-8 болмаса, берілген байттардың неге UTF-8 емес екендігі туралы сипаттамамен [`Err`] қайтарады.Сіз қоныс аударған vector қосылады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// // кейбір байттар, vector түрінде
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Біз бұл байттардың жарамды екенін білеміз, сондықтан біз `unwrap()` қолданамыз.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Қате байттар:
    ///
    /// ```
    /// // кейбір жарамсыз байттар, vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Бұл қатемен не істеуге болатыны туралы толығырақ ақпарат алу үшін [`FromUtf8Error`] құжаттарын қараңыз.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Жарамсыз таңбаларды қоса, байт кесіндісін жолға түрлендіреді.
    ///
    /// Жолдар ([`u8`]) байттан, ал ([`&[u8]`][byteslice]) байт тілім байттан жасалған, сондықтан бұл функция екінің арасында түрленеді.Барлық байт тілімдері жарамды жол емес, дегенмен: жолдар жарамды UTF-8 болуы керек.
    /// Осы түрлендіру кезінде `from_utf8_lossy()` кез келген жарамсыз UTF-8 дәйектілігін келесідей болатын [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]-ке ауыстырады:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Егер сіз байт тілімінің UTF-8 жарамды екендігіне сенімді болсаңыз және сіз конверсияға қосымша шығындар жасағыңыз келмесе, онда [`from_utf8_unchecked`] функциясының қауіпті нұсқасы бар, ол бірдей мінез-құлыққа ие, бірақ тексерулерді өткізіп жібереді.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Бұл функция [`Cow<'a, str>`] мәнін қайтарады.Егер біздің байттық тілім жарамсыз UTF-8 болса, онда біз жолдың өлшемін өзгертетін, демек, `String` талап ететін ауыстыратын таңбаларды енгізуіміз керек.
    /// Бірақ егер ол қазірдің өзінде жарамды UTF-8 болса, бізге жаңа бөлудің қажеті жоқ.
    /// Бұл қайтару түрі екі жағдайды да өңдеуге мүмкіндік береді.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// // кейбір байттар, vector түрінде
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Қате байттар:
    ///
    /// ```
    /// // кейбір жарамсыз байттар
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// UTF-16 кодталған vector `v`-ті `String`-ге декодтаңыз, егер `v`-те жарамсыз мәліметтер болса, [`Err`]-ті қайтарыңыз.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Бұл коллекция арқылы жасалмайды: : <Result<_, _>> () өнімділік себептері бойынша.
        // FIXME: функцияны #48994 жабылған кезде қайтадан жеңілдетуге болады.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Жарамсыз деректерді [the replacement character (`U+FFFD`)][U+FFFD]-ке ауыстыра отырып, UTF-16 кодталған `v` кесіндісін `String` етіп декодтаңыз.
    ///
    /// [`from_utf8_lossy`]-тен айырмашылығы, [`Cow<'a, str>`] қайтарады, `from_utf16_lossy` `String` береді, өйткені UTF-16-тен UTF-8-ке түрлендіру жадыны бөлуді қажет етеді.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// `String`-ті шикі компоненттерге бөледі.
    ///
    /// Шикі көрсеткішті негізгі деректерге, жолдың ұзындығына (байтпен) және берілгендердің сыйымдылығына (байтпен) қайтарады.
    /// Бұл [`from_raw_parts`] аргументтері сияқты дәл осындай дәйектемелер.
    ///
    /// Осы функцияны шақырғаннан кейін қоңырау шалушы бұрын `String` басқаратын жад үшін жауап береді.
    /// Мұның жалғыз жолы-[`from_raw_parts`] функциясымен шикі көрсеткішті, ұзындықты және сыйымдылықты қайтадан `String`-ге айналдыру, бұл деструкторға тазартуды жүзеге асыруға мүмкіндік береді.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Ұзындығы, сыйымдылығы және көрсеткіштен жаңа `String` жасайды.
    ///
    /// # Safety
    ///
    /// Бұл тексерілмеген инварианттар санына байланысты өте қауіпті:
    ///
    /// * `buf`-тағы жадты стандартты кітапхана қолданатын дәл осындай бөлгіш бөліп беруі керек, дәл 1 туралануы керек.
    /// * `length` `capacity`-тен аз немесе оған тең болуы керек.
    /// * `capacity` дұрыс мән болуы керек.
    /// * `buf`-тегі бірінші `length` байт UTF-8 жарамды болуы керек.
    ///
    /// Бұларды бұзу дистрибьютордың ішкі деректер құрылымын бұзу сияқты мәселелер тудыруы мүмкін.
    ///
    /// `buf`-ке меншік тиімді түрде `String`-ке ауысады, содан кейін ол өз қалауы бойынша меңзер көрсеткен жадының мазмұнын бөлуі, қайта бөлуі немесе өзгерте алады.
    /// Осы функцияны шақырғаннан кейін көрсеткішті ештеңе пайдаланбайтынына көз жеткізіңіз.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME vec_into_raw_parts тұрақтандырылған кезде оны жаңартыңыз.
    ///     // Жолдың деректерін автоматты түрде тастауға жол бермеңіз
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Жолдың жарамды UTF-8 бар-жоғын тексермей vector байтты `String`-ке түрлендіреді.
    ///
    /// Толығырақ ақпаратты [`from_utf8`] қауіпсіз нұсқасынан қараңыз.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Бұл функция қауіпті, себебі ол берілген байттардың UTF-8 жарамдылығын тексермейді.
    /// Егер бұл шектеу бұзылса, бұл `String` пайдаланушыларының future пайдаланушыларының жадының қауіпсіздігіне қатысты мәселелер туғызуы мүмкін, өйткені стандартты кітапхананың қалған бөлігі «Жолдар UTF-8 жарамды» деп санайды.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// // кейбір байттар, vector түрінде
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// `String`-ті vector байтына айналдырады.
    ///
    /// Бұл `String` тұтынады, сондықтан оның мазмұнын көшірудің қажеті жоқ.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Бүкіл `String` қамтитын жол кесіндісін шығарады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// `String`-ті өзгеретін жол кесіндісіне түрлендіреді.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Берілген жол кесіндісін осы `String` соңына қосады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Осы «жолдың» сыйымдылығын байтпен қайтарады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Бұл «жолдың» сыйымдылығы оның ұзындығынан кем дегенде `additional` байт болатындығына кепілдік береді.
    ///
    /// Егер оны қаласаңыз, жиі қайта бөлуді болдырмау үшін сыйымдылықты `additional` байттан арттыруға болады.
    ///
    ///
    /// Егер сіз бұл "at least" әрекетін қаламасаңыз, [`reserve_exact`] әдісін қараңыз.
    ///
    /// # Panics
    ///
    /// Panics, егер жаңа қуаттылық [`usize`]-тен асып кетсе.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Бұл шын мәнінде қуатты арттыра алмауы мүмкін:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s енді ұзындығы 2 және сыйымдылығы 10 құрайды
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Бізде қосымша 8 сыйымдылық бар болғандықтан, мұны ...
    /// s.reserve(8);
    ///
    /// // ... өспейді.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Бұл «жолдың» сыйымдылығы оның ұзындығынан үлкен `additional` байт екеніне көз жеткізеді.
    ///
    /// [`reserve`] әдісін қолдану туралы ойланыңыз, егер сіз бөлгіштен жақсы білмесеңіз.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics, егер жаңа қуаттылық `usize`-тен асып кетсе.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Бұл шын мәнінде қуатты арттыра алмауы мүмкін:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s енді ұзындығы 2 және сыйымдылығы 10 құрайды
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Бізде қосымша 8 сыйымдылық бар болғандықтан, мұны ...
    /// s.reserve_exact(8);
    ///
    /// // ... өспейді.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Берілген `String`-ге енгізілетін кем дегенде `additional` элементтері үшін сыйымдылықты сақтауға тырысады.
    /// Жиі қайта бөлуді болдырмау үшін коллекция көбірек орын сақтауы мүмкін.
    /// `reserve` шақырғаннан кейін сыйымдылық `self.len() + additional`-тен үлкен немесе оған тең болады.
    /// Егер сыйымдылық жеткілікті болса, ештеңе жасамайды.
    ///
    /// # Errors
    ///
    /// Егер сыйымдылық асып кетсе немесе бөлгіш қате туралы айтса, қате қайтарылады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Жадты алдын-ала сақтаңыз, егер мүмкін болмасаңыз
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Енді біз бұл біздің күрделі жұмысымыздың ортасында OOM болмайтынын білеміз
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Осы `String` ішіне дәл `additional` элементтерін енгізу үшін минималды сыйымдылықты сақтауға тырысады.
    ///
    /// `reserve_exact` шақырғаннан кейін сыйымдылық `self.len() + additional`-тен үлкен немесе оған тең болады.
    /// Егер сыйымдылық жеткілікті болса, ештеңе жасамайды.
    ///
    /// Бөлгіштің коллекцияға ол сұрағаннан көбірек орын бере алатындығын ескеріңіз.
    /// Сондықтан сыйымдылыққа минималды деп сенуге болмайды.
    /// Егер future енгізілімдері күтілсе, `reserve`-ге артықшылық беріңіз.
    ///
    /// # Errors
    ///
    /// Егер сыйымдылық асып кетсе немесе бөлгіш қате туралы айтса, қате қайтарылады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Жадты алдын-ала сақтаңыз, егер мүмкін болмасаңыз
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Енді біз бұл біздің күрделі жұмысымыздың ортасында OOM болмайтынын білеміз
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Бұл `String` сыйымдылығын оның ұзындығына сәйкес келеді.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Осы `String` сыйымдылығын төменгі шекарамен азайтады.
    ///
    /// Сыйымдылығы кем дегенде ұзындығы мен берілген мәннің шамасында қалады.
    ///
    ///
    /// Егер ағымдағы сыйымдылық төменгі шектен аз болса, бұл тыйым салынады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Берілген [`char`]-ті осы `String` соңына қосады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Осы «жолдың» байт тілімін қайтарады.
    ///
    /// Бұл әдіске керісінше-[`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Осы `String`-ті көрсетілген ұзындыққа дейін қысқартады.
    ///
    /// Егер `new_len` жолдың ағымдағы ұзындығынан үлкен болса, бұл ешқандай әсер етпейді.
    ///
    ///
    /// Бұл әдіс жолдың бөлінген сыйымдылығына әсер етпейтінін ескеріңіз
    ///
    /// # Panics
    ///
    /// Panics, егер `new_len` [`char`] шекарасында жатпаса.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Жолдық буферден соңғы таңбаны алып тастайды және оны қайтарады.
    ///
    /// Егер бұл `String` бос болса, [`None`] қайтарады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Осы `String` ішінен байт күйінде [`char`] алып тастайды және оны қайтарады.
    ///
    /// Бұл *O*(*n*) операциясы, себебі ол буфердегі барлық элементтерді көшіруді қажет етеді.
    ///
    /// # Panics
    ///
    /// Panics, егер `idx` «Жолдың» ұзындығынан үлкен немесе оған тең болса немесе ол [`char`] шекарасында болмаса.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String` үлгісіндегі `pat` барлық сәйкестіктерін алып тастаңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Сәйкестіктер итеративті түрде анықталады және жойылады, сондықтан өрнектер қабаттасқан жағдайда тек бірінші өрнек жойылады:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // ҚАУІПСІЗДІК: басталу мен аяқталу utf8 байт шекарасында болады
        // Іздеуші құжаттар
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Тек предикатпен көрсетілген таңбаларды сақтайды.
    ///
    /// Басқаша айтқанда, `c` `false` қайтаратындай `c` барлық таңбаларын алып тастаңыз.
    /// Бұл әдіс өз орнына жұмыс істейді, әр кейіпкерге бастапқы ретпен дәл бір рет барады және сақталған кейіпкерлердің ретін сақтайды.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Нақты тапсырыс индекс сияқты сыртқы күйді бақылау үшін пайдалы болуы мүмкін.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Idx-ті келесі сызбаға бағыттаңыз
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Осы `String` ішіне таңбаны байт күйінде енгізеді.
    ///
    /// Бұл *O*(*n*) әрекеті, өйткені буфердегі барлық элементтерді көшіру қажет.
    ///
    /// # Panics
    ///
    /// Panics, егер `idx` «жолдың» ұзындығынан үлкен болса немесе ол [`char`] шекарасында болмаса.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Бұл `String` ішіне байт күйінде жол кесіндісін енгізеді.
    ///
    /// Бұл *O*(*n*) әрекеті, өйткені буфердегі барлық элементтерді көшіру қажет.
    ///
    /// # Panics
    ///
    /// Panics, егер `idx` «жолдың» ұзындығынан үлкен болса немесе ол [`char`] шекарасында болмаса.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Осы `String` мазмұнына өзгертілетін сілтеме береді.
    ///
    /// # Safety
    ///
    /// Бұл функция қауіпті, себебі ол берілген байттардың UTF-8 жарамдылығын тексермейді.
    /// Егер бұл шектеу бұзылса, бұл `String` пайдаланушыларының future пайдаланушыларының жадының қауіпсіздігіне қатысты мәселелер туғызуы мүмкін, өйткені стандартты кітапхананың қалған бөлігі «Жолдар UTF-8 жарамды» деп санайды.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Осы `String` ұзындығын [`char`] s немесе графема емес, байтпен қайтарады.
    /// Басқаша айтқанда, бұл адам жіптің ұзындығын есептейтін нәрсе болмауы мүмкін.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Егер `String` нөлге тең болса, `true` қайтарады, ал басқаша жағдайда `false`.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Берілген байт индексі бойынша жолды екіге бөледі.
    ///
    /// Жаңадан бөлінген `String` қайтарады.
    /// `self` құрамында `[0, at)` байттары, ал қайтарылған `String`-те `[at, len)` байттары бар.
    /// `at` UTF-8 кодтық нүктесінің шекарасында болуы керек.
    ///
    /// `self` сыйымдылығы өзгермейтінін ескеріңіз.
    ///
    /// # Panics
    ///
    /// Panics, егер `at` `UTF-8` код нүктесінің шекарасында болмаса немесе ол жолдың соңғы кодтық нүктесінен тыс болса.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Барлық мазмұнды алып тастап, осы `String` кесіледі.
    ///
    /// Бұл `String` нөлдің ұзындығын білдіреді дегенмен, ол оның сыйымдылығына тимейді.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// `String`-те көрсетілген ауқымды жоятын және жойылған `chars`-ді шығаратын дренажды итератор жасайды.
    ///
    ///
    /// Note: Итератор аяғына дейін тұтынылмаса да, элементтер ауқымы жойылады.
    ///
    /// # Panics
    ///
    /// Panics, егер бастапқы нүкте немесе соңғы нүкте [`char`] шекарасында жатпаса немесе олар шекарадан тыс болса.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Жолдан β дейінгі аралықты алып тастаңыз
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Толық диапазон жіпті тазартады
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Жад қауіпсіздігі
        //
        // Drain жолдық нұсқасында vector нұсқасының жадының қауіпсіздігі жоқ.
        // Деректер жай байт.
        // Ауқымды жою Drop кезінде жүретіндіктен, егер Drain итераторы ағып кетсе, алып тастау болмайды.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Бір уақытта екі қарыз алыңыз.
        // Drop арқылы қайталану аяқталғанға дейін &mut жолына қол жеткізілмейді.
        let self_ptr = self as *mut _;
        // ҚАУІПСІЗДІК: `slice::range` және `is_char_boundary` тиісті шекараларды тексереді.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Жолдағы көрсетілген ауқымды жояды және оны берілген жолмен ауыстырады.
    /// Берілген жолға диапазонмен бірдей ұзындық қажет емес.
    ///
    /// # Panics
    ///
    /// Panics, егер бастапқы нүкте немесе соңғы нүкте [`char`] шекарасында жатпаса немесе олар шекарадан тыс болса.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Аралықты жолдан β дейін ауыстырыңыз
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Жад қауіпсіздігі
        //
        // Replace_range-де vector Splice жадының қауіпсіздігі жоқ.
        // vector нұсқасы.Деректер жай байт.

        // НАЗАР АУДАРЫҢЫЗ: бұл айнымалы сызықтық (#81138) болады
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // НАЗАР АУДАРЫҢЫЗ: бұл айнымалы сызықтық (#81138) болады
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range`-ті қайтадан пайдалану негізсіз (#81138) болады деп ойлаймыз, `range` хабарлаған шекаралар өзгеріссіз қалады, бірақ дау-дамайды іске асыру қоңыраулар арасында өзгеруі мүмкін
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Осы `String`-ті [«Box`]» <`[`str`] `>« түріне айналдырады.
    ///
    /// Бұл кез-келген артық сыйымдылықты төмендетеді.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// `String` түрлендіруге тырысқан [`u8`] байттың бір бөлігін қайтарады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// // кейбір жарамсыз байттар, vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// `String` түрлендіруге тырысқан байттарды қайтарады.
    ///
    /// Бұл әдіс бөлуді болдырмау үшін мұқият салынған.
    /// Ол байттың көшірмесін жасауды қажет етпейтін етіп, байтты жылжытқанда қатені жұмсайды.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// // кейбір жарамсыз байттар, vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Түрлендіру сәтсіздігі туралы көбірек мәлімет алу үшін `Utf8Error` жүктеп алыңыз.
    ///
    /// [`std::str`] типі ұсынатын [`Utf8Error`] типі [`u8`] s кесіндісін [`&str`] түрлендіру кезінде пайда болуы мүмкін қатені білдіреді.
    /// Бұл мағынада бұл `FromUtf8Error` аналогы.
    /// Оны пайдалану туралы толығырақ ақпаратты оның құжаттамасынан қараңыз.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// // кейбір жарамсыз байттар, vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // бірінші байт бұл жерде жарамсыз
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // String`s арқылы қайталанатын болғандықтан, итератордан бірінші жолды алып, оған барлық келесі жолдарды қосу арқылы біз кем дегенде бір бөлінуден аулақ бола аламыз.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Біз CoW-ді қайталап отырғандықтан, (potentially) бірінші элементті алып, оған барлық келесі элементтерді қосу арқылы кем дегенде бір бөлуден аулақ бола аламыз.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// `&str` имплегіне өкілеттік беретін ыңғайлылық.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Бос `String` жасайды.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Екі жолды біріктіруге арналған `+` операторын жүзеге асырады.
///
/// Бұл `String`-ті сол жақта тұтынады және оның буферін қайта қолданады (қажет болған жағдайда оны өсіреді).
/// Бұл жаңа `String` бөлуді болдырмау және барлық операцияларға барлық мазмұнды көшіру үшін жасалады, бұл *O*(*n*^ 2) жұмыс уақытын *n*-байтты жолды бірнеше рет біріктіру арқылы құруға әкеледі.
///
///
/// Оң жақтағы жіп тек қарызға алынған;оның мазмұны қайтарылған `String`-ке көшіріледі.
///
/// # Examples
///
/// Екі жолды біріктіру мән бойынша біріншісін алады, ал екіншісін қарызға алады:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` жылжытылды және оны бұдан былай пайдалану мүмкін емес.
/// ```
///
/// Егер сіз бірінші `String` пайдалануды жалғастырғыңыз келсе, оны клондап, оның орнына клонға қоса аласыз:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` мұнда әлі де күшінде.
/// ```
///
/// `&str` тілімдерін біріктіру біріншісін `String` түріне айналдыру арқылы жүзеге асырылады:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `String` қосымшасы үшін `+=` операторын жүзеге асырады.
///
/// Бұл [`push_str`][String::push_str] әдісі сияқты мінез-құлыққа ие.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] үшін лақап ат.
///
/// Бұл бүркеншік ат үйлесімділікке қатысты, сондықтан ескірген болуы мүмкін.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// `String` мәніне түрлендіруге арналған trait.
///
/// Бұл trait автоматты түрде [`Display`] trait іске асыратын кез келген типке енгізіледі.
/// Осылайша, `ToString` тікелей жүзеге асырылмауы керек:
/// [`Display`] орындалуы керек, ал сіз `ToString` бағдарламасын тегін аласыз.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Берілген мәнді `String` түрлендіреді.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Бұл іске асыруда `to_string` әдісі panics, егер `Display` іске асыруы қатені қайтарса.
/// Бұл `Display` қате орындалуын көрсетеді, өйткені `fmt::Write for String` ешқашан қатені қайтармайды.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Жалпы нұсқаулар-жалпы функцияларды ішке алмау.
    // Алайда, `#[inline]`-ті осы әдістен алып тастау елеусіз регрессияларды тудырады.
    // Оны алып тастауға тырысқан соңғы әрекетті <https://github.com/rust-lang/rust/pull/74852> қараңыз.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str`-ті `String` түрлендіреді.
    ///
    /// Нәтиже үйіндіге бөлінеді.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: сынақ libstd-ді тартады, бұл мұнда қателіктер тудырады
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Берілген қораптағы `str` кесіндісін `String` түрлендіреді.
    /// `str` тіліміне тиесілі екендігі байқалады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Берілген `String`-ті қораптағы `str` тіліміне түрлендіреді.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Жолдық тілімді Қарыз алынған нұсқаға түрлендіреді.
    /// Үйінді бөлу орындалмайды және жол көшірілмейді.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Жолды меншіктелген нұсқаға айналдырады.
    /// Үйінді бөлу орындалмайды және жол көшірілмейді.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Жол сілтемесін Қарызға алынған нұсқаға түрлендіреді.
    /// Үйінді бөлу орындалмайды және жол көшірілмейді.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Берілген `String`-ті `u8` типті мәндерді ұстайтын vector `Vec` түрлендіреді.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` үшін ағызатын итератор.
///
/// Бұл құрылым X001-де [`drain`] әдісімен жасалады.
/// Толығырақ оның құжаттамасын қараңыз.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Деструкторда&'mut mut string ретінде қолданылады
    string: *mut String,
    /// Жойылатын бөліктің басы
    start: usize,
    /// Алынатын бөліктің соңы
    end: usize,
    /// Жойылатын ағымдағы қалған ауқым
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain қолданыңыз.
            // "Reaffirm" panic кодын қайта енгізбеу үшін шекара тексеріледі.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Осы итератордың қалған (ішкі) жолын тілім ретінде қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: тұрақсыздық кезінде AsRef төменде көрсетілген.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str` тұрақтандырған кезде түсініктеме.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain үшін <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> for Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}