//! Үйінді бөлуге арналған нұсқағыш түрі.
//!
//! [`Box<T>`], кездейсоқ 'box' деп аталады, үйінділерді Rust бөлудің қарапайым түрін ұсынады.Қораптар осы бөлуге меншікті қамтамасыз етеді және олардың аясынан тыс болған кезде олардың мазмұнын тастайды.Сонымен қатар қораптар олардың ешқашан `isize::MAX` байттан артық бөлмейтіндігіне кепілдік береді.
//!
//! # Examples
//!
//! [`Box`] жасау арқылы мәнді үйіндіден үйіндіге жылжытыңыз:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! [`Box`] мәнін [dereferencing] арқылы стекке қайта жылжытыңыз:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Мәліметтердің рекурсивті құрылымын құру:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Бұл `Cons (1, Cons(2, Nil))`.
//!
//! Рекурсивті құрылымдар қорапта болуы керек, өйткені егер `Cons` анықтамасы келесідей болса:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Бұл жұмыс істемейді.Себебі `List` өлшемі тізімде қанша элементтің болуына байланысты, сондықтан біз `Cons` үшін қанша жад бөлу керектігін білмейміз.Анықталған өлшемі бар [`Box<T>`]-ті енгізу арқылы біз `Cons` қандай үлкен болуы керектігін білеміз.
//!
//! # Жадтың орналасуы
//!
//! Нөлдік емес мәндер үшін [`Box`] оны бөлу үшін [`Global`] бөлгішін қолданады.[`Box`] және [`Global`] үлестіргішімен бөлінген шикі нұсқағыш арасында екі жолды түрлендіруге болады, егер [`Layout`] бөлгішпен бірге қолданылған болса, типке сәйкес келеді.
//!
//! Дәлірек айтқанда, [`Global`] бар [`Global`] бөлгішімен бірге бөлінген `value: *mut T` [`Box::<T>::from_raw(value)`] көмегімен қорапқа айналуы мүмкін.
//! Керісінше, [`Box::<T>::into_raw`]-тен алынған `value:*mut T` жадын [`Layout::for_value(&* value)`] бар [`Global`] бөлгіш арқылы бөлуге болады.
//!
//! Нөлдік өлшемдер үшін `Box` көрсеткіші оқу және жазу үшін [valid] болуы керек және жеткілікті тураланған болуы керек.
//! Атап айтқанда, кез-келген тураланған бүтін санды нөлге тең емес мәнді шикі көрсеткішке беру жарамды сілтемені шығарады, бірақ босатылғаннан бері бұрын бөлінген жадқа бағытталған көрсеткіш дұрыс емес.
//! Егер `Box::new` пайдалану мүмкін болмаса, ZST-ге қорапты құрудың ұсынылған тәсілі-[`ptr::NonNull::dangling`] пайдалану.
//!
//! `T: Sized` болған жағдайда, `Box<T>` бір көрсеткіш ретінде ұсынылатындығына кепілдік береді, сонымен қатар ABI-мен C көрсеткіштерімен үйлесімді (яғни C типті `T*`).
//! Бұл дегеніміз, егер сізде C-ден шақырылатын "C" Rust функциялары болса, сіз `Box<T>` типтерін қолдана отырып, сол Rust функцияларын анықтай аласыз және С0 жағында сәйкес тип ретінде `T*` қолдана аласыз.
//! Мысал ретінде, `Foo` мәнін құратын және бұзатын функцияларды жариялайтын C тақырыбын қарастырайық:
//!
//! ```c
//! /* C тақырыбы */
//!
//! /* Қоңырау шалушыға меншік құқығын қайтарады */
//! struct Foo* foo_new(void);
//!
//! /* Меншік құқығын қоңырау шалушыдан алады;NULL арқылы шақырылған кезде оп-оп */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Бұл екі функция Rust-де келесідей орындалуы мүмкін.Мұнда C-ден `struct Foo*` типі `Box<Foo>`-ге аударылады, бұл меншіктегі шектеулерді ескереді.
//! `foo_delete` үшін нөл аргументі Rust-да `Option<Box<Foo>>` ретінде ұсынылғанын ескеріңіз, өйткені `Box<Foo>` нөлге тең болмайды.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Тіпті `Box<T>`-тің C кескіні мен C ABI-дің C көрсеткіші сияқты болғанымен, бұл сіз ерікті `T*`-ті `Box<T>`-ге түрлендіріп, заттардың жұмыс істеуін күте аласыз дегенді білдірмейді.
//! `Box<T>` мәндер әрқашан толық тураланған, нөлге жатпайтын көрсеткіштер болады.Сонымен қатар, `Box<T>` үшін деструктор ғаламдық үлестірушімен мәнді босатуға тырысады.Жалпы алғанда, ең жақсы тәжірибе-бұл `Box<T>` тек ғаламдық бөлгіштен шыққан көрсеткіштерге арналған.
//!
//! **Маңызды.** Кем дегенде, қазіргі уақытта сіз C тілінде анықталған, бірақ Rust арқылы шақырылған функциялар үшін `Box<T>` түрлерін пайдаланудан аулақ болуыңыз керек.Мұндай жағдайларда сіз C типтерін мүмкіндігінше жақынырақ көрсетуіңіз керек.
//! C анықтамасы `T*`-ті қолданатын `Box<T>` сияқты типтерді пайдалану, [rust-lang/unsafe-code-guidelines#198][ucg#198]-да сипатталғандай, анықталмаған әрекетке әкелуі мүмкін.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Үйінді бөлуге арналған нұсқағыш түрі.
///
/// Толығырақ [module-level documentation](../../std/boxed/index.html) қараңыз.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Үйіндідегі жадыны бөледі, содан кейін оған `x` орналастырады.
    ///
    /// Бұл `T` нөлдік өлшемге тең болса, оны бөлмейді.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Мазмұны инициалданбаған жаңа қорапты құрастырады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Жады `0` байтпен толтырылған, инициализацияланбаған мазмұнмен жаңа `Box` құрастырады.
    ///
    ///
    /// Осы әдісті дұрыс және қате қолдану мысалдары үшін [`MaybeUninit::zeroed`][zeroed] қараңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Жаңа `Pin<Box<T>>` құрастырады.
    /// Егер `T` `Unpin`-ті қолданбаса, онда `x` жадқа бекітіліп, оны жылжыту мүмкін болмайды.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Үйіндідегі жадыны бөледі, содан кейін `x` орналастырады, егер бөлу сәтсіз болса, қате қайтарады
    ///
    ///
    /// Бұл `T` нөлдік өлшемге тең болса, оны бөлмейді.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Үйіндіде инициализацияланбаған мазмұны бар жаңа қорапты құрастырады, егер бөлу сәтсіз болса, қате қайтарады
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Жинағы үйіндіде `0` байтпен толтырылған, инициализацияланбаған мазмұны бар жаңа `Box` құрастырады
    ///
    ///
    /// Осы әдісті дұрыс және қате қолдану мысалдары үшін [`MaybeUninit::zeroed`][zeroed] қараңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Берілген бөлгіште жадыны бөледі, содан кейін оған `x` орналастырады.
    ///
    /// Бұл `T` нөлдік өлшемге тең болса, оны бөлмейді.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Берілген бөлгіште жадыны бөледі, содан кейін `x` орналастырады, егер бөлу сәтсіз болса, қате қайтарады
    ///
    ///
    /// Бұл `T` нөлдік өлшемге тең болса, оны бөлмейді.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Берілген бөлгіште инициализацияланбаған мазмұны бар жаңа қорапты құрастырады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Материалды unwrap_or_else-ден артық көріңіз, өйткені жабылу кейде ішкі сипатта болмайды.
        // Бұл код өлшемін үлкенірек етеді.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Берілген бөлгіште инициализацияланбаған мазмұны бар жаңа қорапты құрастырады, егер бөлу сәтсіз болса, қате қайтарады
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Берілген бөлгіште жад `0` байтпен толтырылған, инициализацияланбаған мазмұнмен жаңа `Box` құрастырады.
    ///
    ///
    /// Осы әдісті дұрыс және қате қолдану мысалдары үшін [`MaybeUninit::zeroed`][zeroed] қараңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Материалды unwrap_or_else-ден артық көріңіз, өйткені жабылу кейде ішкі сипатта болмайды.
        // Бұл код өлшемін үлкенірек етеді.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Жаңа `Box`-ті инициализацияланбаған мазмұнмен жасайды, жады берілген бөлгіште `0` байтпен толтырылады, егер бөлу сәтсіз болса, қате қайтарады,
    ///
    ///
    /// Осы әдісті дұрыс және қате қолдану мысалдары үшін [`MaybeUninit::zeroed`][zeroed] қараңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Жаңа `Pin<Box<T, A>>` құрастырады.
    /// Егер `T` `Unpin`-ті қолданбаса, онда `x` жадқа бекітіліп, оны жылжыту мүмкін болмайды.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// `Box<T>`-ті `Box<[T]>` түрлендіреді
    ///
    /// Бұл түрлендіру үйіндіге бөлінбейді және орнында болады.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// `Box` тұтынады, оралған мәнді қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Құрамында инициализацияланбаған жаңа қорапты тілім салынады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Жады `0` байтпен толтырылған, инициализацияланбаған мазмұны бар жаңа қорапты кесінді жасайды.
    ///
    ///
    /// Осы әдісті дұрыс және қате қолдану мысалдары үшін [`MaybeUninit::zeroed`][zeroed] қараңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Берілген бөлгіште инициализацияланбаған мазмұны бар жаңа қорапты тілім жасайды.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Берілген бөлгіште инициализацияланбаған мазмұны бар жаңа жәшік кесіндісін жасайды, жады `0` байтпен толтырылады.
    ///
    ///
    /// Осы әдісті дұрыс және қате қолдану мысалдары үшін [`MaybeUninit::zeroed`][zeroed] қараңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// `Box<T, A>`-ге түрлендіреді.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] сияқты, қоңырау шалушының мәні инициализацияланған күйде екеніне кепілдік беруі керек.
    ///
    /// Мазмұн әлі толық инициализацияланбаған кезде оны шақыру дереу анықталмаған әрекеттерді тудырады.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// `Box<[T], A>`-ге түрлендіреді.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] сияқты, мәндердің шынымен баптандырылған күйде екеніне кепілдік беру қоңырау шалушының қолында.
    ///
    /// Мазмұн әлі толық инициализацияланбаған кезде оны шақыру дереу анықталмаған әрекеттерді тудырады.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Кейінге қалдырылған инициализация:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Шикі көрсеткіштен қорапты құрастырады.
    ///
    /// Осы функцияны шақырғаннан кейін, шикі нұсқағыш алынған `Box` иелігінде болады.
    /// Дәлірек айтқанда, `Box` деструкторы `T` деструкторын шақырады және бөлінген жадты босатады.
    /// Бұл қауіпсіз болу үшін жад `Box` қолданған [memory layout] сәйкес бөлінген болуы керек.
    ///
    ///
    /// # Safety
    ///
    /// Бұл функция қауіпті, себебі дұрыс қолданбау жадта ақаулар тудыруы мүмкін.
    /// Мысалы, егер функция бірдей шикі көрсеткіште екі рет шақырылса, екі еселенген болуы мүмкін.
    ///
    /// Қауіпсіздік шарттары [memory layout] бөлімінде сипатталған.
    ///
    /// # Examples
    ///
    /// Бұрын [`Box::into_raw`] көмегімен шикі көрсеткішке айналдырылған `Box` жасаңыз:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Жаһандық үлестіргішті қолдану арқылы нөлден `Box` қолмен жасаңыз:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Жалпы .write `ptr`-тің алдыңғы мазмұнын (uninitialized) құрту әрекетін болдырмау үшін қажет, бірақ бұл қарапайым мысал үшін `*ptr = 5` да жұмыс істеген болар еді.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Берілген бөлгіште шикі көрсеткіштен қорапты құрастырады.
    ///
    /// Осы функцияны шақырғаннан кейін, шикі нұсқағыш алынған `Box` иелігінде болады.
    /// Дәлірек айтқанда, `Box` деструкторы `T` деструкторын шақырады және бөлінген жадты босатады.
    /// Бұл қауіпсіз болу үшін жад `Box` қолданған [memory layout] сәйкес бөлінген болуы керек.
    ///
    ///
    /// # Safety
    ///
    /// Бұл функция қауіпті, себебі дұрыс қолданбау жадта ақаулар тудыруы мүмкін.
    /// Мысалы, егер функция бірдей шикі көрсеткіште екі рет шақырылса, екі еселенген болуы мүмкін.
    ///
    /// # Examples
    ///
    /// Бұрын [`Box::into_raw_with_allocator`] көмегімен шикі көрсеткішке айналдырылған `Box` жасаңыз:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Жүйелік үлестіргішті қолдану арқылы нөлден `Box` қолмен жасаңыз:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Жалпы .write `ptr`-тің алдыңғы мазмұнын (uninitialized) құрту әрекетін болдырмау үшін қажет, бірақ бұл қарапайым мысал үшін `*ptr = 5` да жұмыс істеген болар еді.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// `Box` тұтынады, оралған шикі көрсеткішті қайтарады.
    ///
    /// Меңзер дұрыс тураланған және нөл емес болады.
    ///
    /// Осы функцияны шақырғаннан кейін қоңырау шалушы бұрын `Box` басқаратын жад үшін жауап береді.
    /// Атап айтқанда, қоңырау шалушы X001 қолданған [memory layout] ескере отырып, `T`-ті дұрыс жойып, жадыны босатуы керек.
    /// Мұны істеудің ең оңай жолы-`Box` деструкторына тазартуды жүзеге асыруға мүмкіндік беретін шикі көрсеткішті [`Box::from_raw`] функциясымен қайтадан `Box`-ге айналдыру.
    ///
    ///
    /// Note: бұл байланысты функция, демек, оны `b.into_raw()` орнына `Box::into_raw(b)` деп атауға тура келеді.
    /// Бұл ішкі типтегі әдіспен қайшылық болмауы үшін.
    ///
    /// # Examples
    /// Шикі меңзерді автоматты тазарту үшін `Box`-ке қайта `Box`-ге айналдыру:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Деструкторды нақты іске қосу және жадыны бөлу арқылы қолмен тазарту:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// `Box` тұтынады, оралған шикі көрсеткішті және бөлгішті қайтарады.
    ///
    /// Меңзер дұрыс тураланған және нөл емес болады.
    ///
    /// Осы функцияны шақырғаннан кейін қоңырау шалушы бұрын `Box` басқаратын жад үшін жауап береді.
    /// Атап айтқанда, қоңырау шалушы X001 қолданған [memory layout] ескере отырып, `T`-ті дұрыс жойып, жадыны босатуы керек.
    /// Мұны істеудің ең оңай жолы-`Box` деструкторына тазартуды жүзеге асыруға мүмкіндік беретін шикі көрсеткішті [`Box::from_raw_in`] функциясымен қайтадан `Box`-ге айналдыру.
    ///
    ///
    /// Note: бұл байланысты функция, демек, оны `b.into_raw_with_allocator()` орнына `Box::into_raw_with_allocator(b)` деп атауға тура келеді.
    /// Бұл ішкі типтегі әдіспен қайшылық болмауы үшін.
    ///
    /// # Examples
    /// Шикі меңзерді автоматты тазарту үшін `Box`-ке қайта `Box`-ге айналдыру:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Деструкторды нақты іске қосу және жадыны бөлу арқылы қолмен тазарту:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Бокс "unique pointer" ретінде Stacked Borrows арқылы танылады, бірақ іштей ол типтік жүйеге арналған бастапқы көрсеткіш болып табылады.
        // Оны тікелей шикі көрсеткішке айналдыру "releasing" бүркеншік шикізатқа қол жеткізуге мүмкіндік беретін бірегей көрсеткіш деп танылмайды, сондықтан барлық шикі көрсеткіштер `Box::leak` арқылы өтуі керек.
        //
        // *That* функциясын шикі көрсеткішке бұру дұрыс әрекет етеді.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Негізгі бөлгішке сілтемені қайтарады.
    ///
    /// Note: бұл байланысты функция, демек, оны `b.allocator()` орнына `Box::allocator(&b)` деп атауға тура келеді.
    /// Бұл ішкі типтегі әдіспен қайшылық болмауы үшін.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Өзгеретін анықтаманы қайтара отырып, `Box` тұтынады және ағып кетеді, `&'a mut T`.
    /// `T` типі таңдалған `'a` өмір сүру мерзімінен асып кетуі керек екенін ескеріңіз.
    /// Егер типте тек статикалық сілтемелер болса немесе мүлде жоқ болса, онда бұл `'static` болып таңдалуы мүмкін.
    ///
    /// Бұл функция негізінен бағдарламаның қалған уақытында өмір сүретін деректер үшін пайдалы.
    /// Қайтарылған сілтемені тастау жадтың ағып кетуіне әкеледі.
    /// Егер бұл қолайсыз болса, онда сілтеме алдымен `Box` шығаратын [`Box::from_raw`] функциясымен оралуы керек.
    ///
    /// Содан кейін бұл `Box`-ті түсіруге болады, бұл `T`-ті дұрыс бұзады және бөлінген жадты босатады.
    ///
    /// Note: бұл байланысты функция, демек, оны `b.leak()` орнына `Box::leak(b)` деп атауға тура келеді.
    /// Бұл ішкі типтегі әдіспен қайшылық болмауы үшін.
    ///
    /// # Examples
    ///
    /// Қарапайым пайдалану:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Өлшемсіз деректер:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// `Box<T>`-ті `Pin<Box<T>>` түрлендіреді
    ///
    /// Бұл түрлендіру үйіндіге бөлінбейді және орнында болады.
    ///
    /// Бұл [`From`] арқылы да қол жетімді.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // `T: !Unpin` кезінде `Pin<Box<T>>` ішін жылжыту немесе ауыстыру мүмкін емес, сондықтан оны ешқандай қосымша талаптарсыз тікелей бекіту қауіпсіз.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Ештеңе жасамаңыз, түсіруді қазіргі уақытта компилятор орындайды.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// T үшін `Default` мәнімен `Box<T>` жасайды.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Осы қораптың `clone()` мазмұны бар жаңа қорапты қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Мәні бірдей
    /// assert_eq!(x, y);
    ///
    /// // Бірақ олар бірегей нысандар
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Клондалған мәнді тікелей жазуға мүмкіндік беру үшін жадты алдын-ала бөліңіз.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Бастапқы деректерді `self` ішіне жаңа бөлу құралынсыз көшіреді.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Мәні бірдей
    /// assert_eq!(x, y);
    ///
    /// // Бөлу болған жоқ
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // бұл деректердің көшірмесін жасайды
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// `T` жалпы түрін `Box<T>` түрлендіреді
    ///
    /// Конверсия үйіндіге бөлініп, `t`-ны стектен оған көшіреді.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// `Box<T>`-ті `Pin<Box<T>>` түрлендіреді
    ///
    /// Бұл түрлендіру үйіндіге бөлінбейді және орнында болады.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// `&[T]`-ті `Box<[T]>` түрлендіреді
    ///
    /// Бұл түрлендіру үйіндіге бөлініп, `slice` көшірмесін орындайды.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // &[u8] жасаңыз, ол <[u8]> қорабын жасау үшін қолданылады
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// `&str`-ті `Box<str>` түрлендіреді
    ///
    /// Бұл түрлендіру үйіндіге бөлініп, `s` көшірмесін орындайды.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// `Box<str>`-ті `Box<[u8]>` түрлендіреді
    /// Бұл түрлендіру үйіндіге бөлінбейді және орнында болады.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // қорап жасаңыз<str>ол <[u8]> қорапты құру үшін қолданылады
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // &[u8] жасаңыз, ол <[u8]> қорабын жасау үшін қолданылады
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// `[T; N]`-ті `Box<[T]>` түрлендіреді
    /// Бұл түрлендіру массивті үймеге бөлінген жадқа көшіреді.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Қорапты бетон түріне төмендетуге тырысу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Қорапты бетон түріне төмендетуге тырысу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Қорапты бетон түріне төмендетуге тырысу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ішкі Uniq-ті тікелей Box-тан бөліп алу мүмкін емес, оның орнына Uni-ді бүркеншік атпен * const-қа жібереміз
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Әдепкі бойынша `last()` іске асыруды қолданатын өлшемді I-ге арналған мамандандыру.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}