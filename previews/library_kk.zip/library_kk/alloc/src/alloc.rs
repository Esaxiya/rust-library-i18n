//! Жадыны бөлу API

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Бұл ғаламдық бөлгішті шақырудың сиқырлы белгілері.rustc оларды `__rg_alloc` т.с.с. шақыру үшін жасайды.
    // егер `#[global_allocator]` төлсипаты болса (макробритті кеңейтетін код осы функцияларды тудырады) немесе libstd (`__rdl_alloc` және т.б.) бойынша әдепкі іске асыруларды шақыру үшін
    //
    // басқаша.
    // LLVM-дің rustc fork-де бұл функционалдық атаулар оларды `malloc`, `realloc` және `free` сияқты оларды оңтайландыру үшін арнайы жағдайлар болады.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Ғаламдық жад бөлгіш.
///
/// Бұл тип [`Allocator`] trait-ті `#[global_allocator]` атрибутымен тіркелген бөлгішке қоңырауды қайта жіберу немесе `std` crate әдепкі мәні бойынша жүзеге асырады.
///
///
/// Note: бұл түрі тұрақсыз болса, оның функционалдығына [free functions in `alloc`](self#functions) арқылы қол жеткізуге болады.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Жаһандық бөлгішпен жадыны бөлу.
///
/// Бұл функция `#[global_allocator]` атрибутымен тіркелген бөлгіштің [`GlobalAlloc::alloc`] әдісіне немесе `std` crate әдепкі жағдайына бағыттайды.
///
///
/// Бұл функция [`Global`] типіндегі `alloc` әдісінің пайдасына ол және [`Allocator`] trait тұрақты болған кезде ескіреді деп күтілуде.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] қараңыз.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Жаһандық бөлгішпен жадыны бөлу.
///
/// Бұл функция `#[global_allocator]` атрибутымен тіркелген бөлгіштің [`GlobalAlloc::dealloc`] әдісіне немесе `std` crate әдепкі жағдайына бағыттайды.
///
///
/// Бұл функция [`Global`] типіндегі `dealloc` әдісінің пайдасына ол және [`Allocator`] trait тұрақты болған кезде ескіреді деп күтілуде.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] қараңыз.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Жаһандық бөлгішпен жадыны қайта бөлу.
///
/// Бұл функция `#[global_allocator]` атрибутымен тіркелген бөлгіштің [`GlobalAlloc::realloc`] әдісіне немесе `std` crate әдепкі жағдайына бағыттайды.
///
///
/// Бұл функция [`Global`] типіндегі `realloc` әдісінің пайдасына ол және [`Allocator`] trait тұрақты болған кезде ескіреді деп күтілуде.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] қараңыз.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Жаһандық бөлгішпен нөлдік инициалданған жадыны бөліңіз.
///
/// Бұл функция `#[global_allocator]` атрибутымен тіркелген бөлгіштің [`GlobalAlloc::alloc_zeroed`] әдісіне немесе `std` crate әдепкі жағдайына бағыттайды.
///
///
/// Бұл функция [`Global`] типіндегі `alloc_zeroed` әдісінің пайдасына ол және [`Allocator`] trait тұрақты болған кезде ескіреді деп күтілуде.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] қараңыз.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // ҚАУІПСІЗДІК: `layout` өлшемі нөлге тең емес,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // ҚАУІПСІЗДІК: `Allocator::grow` сияқты
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // ҚАУІПСІЗДІК: `new_size` нөлге тең емес, өйткені `old_size` `new_size`-тен үлкен немесе оған тең
            // қауіпсіздік талаптарына сәйкес.Қоңырау шалушы басқа шарттарды сақтауы керек
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` мүмкін `new_size >= old_layout.size()` немесе сол сияқты нәрсені тексереді.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // ҚАУІПСІЗДІК: өйткені `new_layout.size()` `old_size`-тен үлкен немесе оған тең болуы керек,
            // ескі де, жаңа да бөлу `old_size` байт үшін оқуға және жазуға жарамды.
            // Сондай-ақ, ескі бөлу әлі бөлінбегендіктен, ол `new_ptr` қабаттасуы мүмкін емес.
            // Осылайша, `copy_nonoverlapping`-ке қоңырау шалу қауіпсіз.
            // `dealloc` қауіпсіздік шартын қоңырау шалушы сақтауы керек.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // ҚАУІПСІЗДІК: `layout` өлшемі нөлге тең емес,
            // қоңырау шалушы басқа шарттарды сақтауы керек
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ҚАУІПСІЗДІК: қоңырау шалушы барлық шарттарды сақтауы керек
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ҚАУІПСІЗДІК: қоңырау шалушы барлық шарттарды сақтауы керек
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // ҚАУІПСІЗДІК: шартты қоңырау шалушы сақтауы керек
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // ҚАУІПСІЗДІК: `new_size` нөлге тең емес.Қоңырау шалушы басқа шарттарды сақтауы керек
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` мүмкін `new_size <= old_layout.size()` немесе сол сияқты нәрсені тексереді.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // ҚАУІПСІЗДІК: өйткені `new_size` `old_layout.size()`-тен кіші немесе оған тең болуы керек,
            // ескі де, жаңа да бөлу `new_size` байт үшін оқуға және жазуға жарамды.
            // Сондай-ақ, ескі бөлу әлі бөлінбегендіктен, ол `new_ptr` қабаттасуы мүмкін емес.
            // Осылайша, `copy_nonoverlapping`-ке қоңырау шалу қауіпсіз.
            // `dealloc` қауіпсіздік шартын қоңырау шалушы сақтауы керек.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Бірегей көрсеткіштерге арналған бөлгіш.
// Бұл функция ашылмауы керек.Егер ол орындалса, MIR кодтегі істен шығады.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Бұл қолтаңба `Box` сияқты болуы керек, әйтпесе ICE болады.
// `Box`-ге қосымша параметр қосылған кезде (мысалы, `A: Allocator`), мұнда да қосу керек.
// Мысалы, егер `Box` `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`-ге өзгертілсе, онда бұл функцияны `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`-ке өзгерту керек.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Бөлу қатесін өңдеуші

extern "Rust" {
    // Бұл жаһандық бөлу қателерін өңдеушіні шақырудың сиқырлы белгісі.
    // rustc, егер `#[alloc_error_handler]` болса, `__rg_oom`-ке қоңырау шалады немесе әйтпесе (`__rdl_oom`)-ден төмен әдепкі іске асыруды шақырады.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Жадыны бөлу қателігі немесе сәтсіздік туралы тоқтату.
///
/// Бөлу қателігіне жауап ретінде есептеуді тоқтатқысы келетін жадыны бөлу API интерфейсіне қоңырау шалушыларға `panic!` немесе оған ұқсас әрекеттерді тікелей емес, осы функцияны шақыру ұсынылады.
///
///
/// Бұл функцияның әдепкі әрекеті-хабарламаны стандартты қатеге басып шығару және процесті тоқтату.
/// Оны [`set_alloc_error_hook`] және [`take_alloc_error_hook`] ауыстыруға болады.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Бөлу үшін `std::alloc::handle_alloc_error` сынағын тікелей пайдалануға болады.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // генерацияланған `__rust_alloc_error_handler` арқылы шақырылады

    // егер `#[alloc_error_handler]` болмаса
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // егер `#[alloc_error_handler]` болса
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Клондарды алдын-ала бөлінген, инициализацияланбаған жадыға мамандандырыңыз.
/// `Box::clone` және `Rc`/`Arc::make_mut` қолданады.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *Бірінші* бөлу оптимизаторға клондалған мәнді орнында құрып, локалды өткізіп, жылжуға мүмкіндік береді.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Біз әрқашан жергілікті мәнді ескермей, орнында көшіре аламыз.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}