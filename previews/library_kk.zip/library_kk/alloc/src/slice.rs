//! Іргелес дәйектілікке динамикалық өлшемді көрініс, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Бөлшектер-бұл жад блогындағы көрініс және ұзындық ретінде көрсетілген.
//!
//! ```
//! // Vec кесу
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // массивті тілімге мәжбүрлеу
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Кесінділер өзгеріске ұшырайды немесе ортақ болады.
//! Ортақ тілім түрі-`&[T]`, ал өзгертілетін тілім түрі-`&mut [T]`, мұндағы `T` элемент типін білдіреді.
//! Мысалы, өзгертілетін тілім көрсететін жадының блогын өзгертуге болады:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Бұл модульде мыналар бар:
//!
//! ## Structs
//!
//! Тіліктер үшін пайдалы бірнеше құрылымдар бар, мысалы, тілім бойынша итерацияны бейнелейтін [`Iter`].
//!
//! ## Trait енгізу
//!
//! Тілімдерге арналған traits-дің бірнеше орындалуы бар.Кейбір мысалдарға мыналар кіреді:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], элементтер типі [`Eq`] немесе [`Ord`] болатын тілімдерге арналған.
//! * [`Hash`] - элемент типі [`Hash`] болатын тілімдер үшін.
//!
//! ## Iteration
//!
//! Тіліктер `IntoIterator`-ті қолданады.Итератор тілім элементтеріне сілтемелер береді.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Өзгермелі кесінді элементтерге өзгертілетін сілтемелер береді:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Бұл итератор кесінді элементтеріне өзгертілетін сілтемелер береді, сондықтан тілімнің элементтер типі `i32`, ал итератордың элементтер түрі `&mut i32` болады.
//!
//!
//! * [`.iter`] және [`.iter_mut`]-әдепкі итераторларды қайтарудың айқын әдістері.
//! * Итераторларды қайтаратын келесі әдістер-[`.split`], [`.splitn`], [`.chunks`], [`.windows`] және басқалары.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Осы модульдегі көптеген қолданыстар тек тестілік конфигурацияда қолданылады.
// Қолданылмаған импорт туралы ескертуді жөндеуден гөрі өшіру оңай.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Бөлшектерді кеңейтудің негізгі әдістері
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) NB тестілеу кезінде `vec!` макросын енгізу үшін қажет, толығырақ осы файлдағы `hack` модулін қараңыз.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB-ны тестілеу кезінде `Vec::clone`-ті енгізу үшін қажет, толығырақ осы файлдағы `hack` модулін қараңыз.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` қол жетімді болмаған кезде, бұл үш функция `impl [T]`-да болатын әдістер болып табылады, бірақ `core::slice::SliceExt` емес, біз бұл функцияларды `test_permutations` сынағы үшін жеткізуіміз керек
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Біз бұған кірістірілген атрибутты қоспауымыз керек, өйткені бұл көбінесе `vec!` макросында қолданылады және перфрессияны тудырады.
    // Талқылау және жетілдіру нәтижелері үшін #71204 қараңыз.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // элементтер төмендегі циклде инициалданған деп белгіленді
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) LLVM үшін тексерулерді жою үшін қажет және zip-ге қарағанда жақсы кодтегіші бар.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // век бөлінген және инициализацияланған, ең болмағанда осы ұзындыққа.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // жоғарыда `s` сыйымдылығымен бөлінген, ал төменде ptr::copy_to_non_overlapping-те `s.len()` инициализациясы.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Тілімді сұрыптайды.
    ///
    /// Мұндай сұрыптау тұрақты (яғни тең элементтердің ретін өзгертпейді) және *O*(*n*\*log(* n*)) ең нашар).
    ///
    /// Қолданылған кезде тұрақсыз сұрыптауға басымдық беріледі, себебі ол тұрақты сұрыптауға қарағанда тезірек болады және ол қосымша жадыны бөлмейді.
    /// [`sort_unstable`](slice::sort_unstable) қараңыз.
    ///
    /// # Ағымдағы енгізу
    ///
    /// Ағымдағы алгоритм-бұл [timsort](https://en.wikipedia.org/wiki/Timsort) шабыттандырылған адаптивті, қайталанатын біріктіру сұрыптамасы.
    /// Ол кесінді дерлік сұрыпталған немесе бірінен соң бірі тізбектелген екі немесе одан да көп сұрыпталған тізбектен тұратын жағдайларда өте жылдам жасалынған.
    ///
    ///
    /// Сондай-ақ, ол уақытша сақтауды `self` өлшемінің жартысына бөледі, бірақ оның орнына қысқа тілімдерге бөлінбейтін кірістіру сұрыптамасы қолданылады.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Тіліктерді компаратор функциясымен сұрыптайды.
    ///
    /// Мұндай сұрыптау тұрақты (яғни тең элементтердің ретін өзгертпейді) және *O*(*n*\*log(* n*)) ең нашар).
    ///
    /// Компаратор функциясы кесіндідегі элементтерге жалпы реттілікті анықтауы керек.Егер тапсырыс жалпы болмаса, элементтердің реті көрсетілмеген.
    /// Тапсырыс-бұл жалпы тапсырыс, егер ол (барлық `a`, `b` және `c` үшін):
    ///
    /// * жалпы және антисимметриялық: дәл `a < b`, `a == b` немесе `a > b` бірі дұрыс, және
    /// * өтпелі, `a < b` және `b < c` `a < c` білдіреді.`==` және `>` үшін бірдей болуы керек.
    ///
    /// Мысалы, [`f64`] [`Ord`]-ті `NaN != NaN`-ті қолданбайтын болса, біз `partial_cmp`-ті сұрыптау функциясы ретінде пайдалана аламыз, егер кесіндіде `NaN` жоқ екенін білсек.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Қолданылған кезде тұрақсыз сұрыптауға басымдық беріледі, себебі ол тұрақты сұрыптауға қарағанда тезірек болады және ол қосымша жадыны бөлмейді.
    /// [`sort_unstable_by`](slice::sort_unstable_by) қараңыз.
    ///
    /// # Ағымдағы енгізу
    ///
    /// Ағымдағы алгоритм-бұл [timsort](https://en.wikipedia.org/wiki/Timsort) шабыттандырылған адаптивті, қайталанатын біріктіру сұрыптамасы.
    /// Ол кесінді дерлік сұрыпталған немесе бірінен соң бірі тізбектелген екі немесе одан да көп сұрыпталған тізбектен тұратын жағдайларда өте жылдам жасалынған.
    ///
    /// Сондай-ақ, ол уақытша сақтауды `self` өлшемінің жартысына бөледі, бірақ оның орнына қысқа тілімдерге бөлінбейтін кірістіру сұрыптамасы қолданылады.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // кері сұрыптау
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Кескінді экстракциялау функциясымен сұрыптайды.
    ///
    /// Бұл сұрыптау тұрақты (яғни, тең элементтердің ретін өзгертпейді) және *O*(*m*\* * n *\* log(*n*)) нашар жағдайда, мұнда кілттің функциясы *O*(*m*) болады.
    ///
    /// Қымбат негізгі функциялар үшін (мысалы
    /// қарапайым қасиеттер немесе қарапайым операциялар емес функциялар), [`sort_by_cached_key`](slice::sort_by_cached_key) айтарлықтай тезірек болуы мүмкін, өйткені ол элементтердің кілттерін есептемейді.
    ///
    ///
    /// Қолданылған кезде тұрақсыз сұрыптауға басымдық беріледі, себебі ол тұрақты сұрыптауға қарағанда тезірек болады және ол қосымша жадыны бөлмейді.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) қараңыз.
    ///
    /// # Ағымдағы енгізу
    ///
    /// Ағымдағы алгоритм-бұл [timsort](https://en.wikipedia.org/wiki/Timsort) шабыттандырылған адаптивті, қайталанатын біріктіру сұрыптамасы.
    /// Ол кесінді дерлік сұрыпталған немесе бірінен соң бірі тізбектелген екі немесе одан да көп сұрыпталған тізбектен тұратын жағдайларда өте жылдам жасалынған.
    ///
    /// Сондай-ақ, ол уақытша сақтауды `self` өлшемінің жартысына бөледі, бірақ оның орнына қысқа тілімдерге бөлінбейтін кірістіру сұрыптамасы қолданылады.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Кескінді экстракциялау функциясымен сұрыптайды.
    ///
    /// Сұрыптау кезінде кілт функциясы бір элементке бір рет қана шақырылады.
    ///
    /// Бұл сұрыптау тұрақты (яғни, тең элементтердің ретін өзгертпейді) және *O*(*m*\* * n *+* n *\* log(*n*)) нашар, мұндағы негізгі функция *O*(*m*) .
    ///
    /// Қарапайым негізгі функциялар үшін (мысалы, меншікті қатынасу немесе негізгі операциялар болып табылатын функциялар), [`sort_by_key`](slice::sort_by_key) тезірек болуы мүмкін.
    ///
    /// # Ағымдағы енгізу
    ///
    /// Ағымдағы алгоритм Орсон Питерстің [pattern-defeating quicksort][pdqsort]-ге негізделген, ол кездейсоқ ритмді квиксорттың жылдам жағдайын және ең ауыр ауыр жағдаймен біріктіреді, сонымен қатар белгілі бір өрнектері бар кесінділерде сызықтық уақытты алады.
    /// Бұл дегенеративті жағдайларды болдырмау үшін рандомизацияны қолданады, бірақ детерминирленген мінез-құлықты қамтамасыз ету үшін seed тіркелген.
    ///
    /// Нашар жағдайда алгоритм уақытша сақтауды тілімнің ұзындығына `Vec<(K, usize)>` құрайды.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Бөлінуді азайту үшін біздің vector-ны мүмкін болатын ең кіші түр бойынша индекстеуге арналған көмекші макро.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` элементтері ерекше, өйткені олар индекстелген, сондықтан кез-келген сұрып түпнұсқа тілімге қатысты тұрақты болады.
                // Біз мұнда `sort_unstable` қолданамыз, себебі ол аз жадыны бөлуді қажет етеді.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self`-ті жаңа `Vec`-ке көшіреді.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Мұнда `s` және `x` дербес өзгертілуі мүмкін.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self`-ті жаңа `Vec`-ке бөлгішпен көшіреді.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Мұнда `s` және `x` дербес өзгертілуі мүмкін.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // Қосымша мәлімет алу үшін осы файлдағы `hack` модулін қараңыз.
        hack::to_vec(self, alloc)
    }

    /// `self`-ті vector-ге клондарсыз және бөлусіз түрлендіреді.
    ///
    /// Алынған vector мәнін `Vec арқылы қайтадан қорапқа айналдыруға болады<T>бұл `into_boxed_slice` әдісі.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` енді оны пайдалану мүмкін емес, себебі ол `x`-ге ауыстырылды.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // Қосымша мәлімет алу үшін осы файлдағы `hack` модулін қараңыз.
        hack::into_vec(self)
    }

    /// Тілікті `n` рет қайталау арқылы vector жасайды.
    ///
    /// # Panics
    ///
    /// Бұл функция panic болады, егер сыйымдылығы асып кетсе.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// Толып кеткен кезде panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Егер `n` нөлден үлкен болса, оны `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` деп бөлуге болады.
        // `2^expn` бұл `n` битінің сол жақтағы '1' битімен ұсынылған сан, ал `rem`-`n` қалған бөлігі.
        //
        //

        // `set_len()` қатынасу үшін `Vec` пайдалану.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` қайталау `buf`-ті екі есе көбейту арқылы жүзеге асырылады.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Егер `m > 0` болса, '1' сол жаққа дейін қалған биттер болады.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` сыйымдылығы бар.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) қайталау `buf`-тің өзінен алғашқы `rem` қайталауларын көшіру арқылы жүзеге асырылады.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Бұл `2^expn > rem` бастап қайталанбайды.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()`-ге тең (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` кесіндісін жалғыз `Self::Output` мәніне тегістейді.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Берілген сепараторды әрқайсысының арасына қойып, `T` кесіндісін жалғыз `Self::Output` мәніне тегістейді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Берілген сепараторды әрқайсысының арасына қойып, `T` кесіндісін жалғыз `Self::Output` мәніне тегістейді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Осы тілімнің көшірмесі бар vector мәнін қайтарады, мұнда әр байт ASCII бас әріптің эквивалентімен бейнеленеді.
    ///
    ///
    /// 'a'-тен 'z'-ке дейінгі ASCII әріптері 'A'-тен 'Z'-ге дейін салыстырылады, бірақ ASCII емес әріптер өзгермейді.
    ///
    /// Орнындағы мәнді бас әріпке айналдыру үшін [`make_ascii_uppercase`] пайдаланыңыз.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Осы байламның көшірмесі бар vector мәнін қайтарады, мұнда әр байт ASCII кіші әріпіне теңестіріледі.
    ///
    ///
    /// 'A'-тен 'Z'-ке дейінгі ASCII әріптері 'a'-тен 'z'-ге дейін салыстырылады, бірақ ASCII емес әріптер өзгермейді.
    ///
    /// Орындағы мәнді кішірейту үшін [`make_ascii_lowercase`] пайдаланыңыз.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Деректердің нақты түрлеріне арналған кесінділерге арналған traits кеңейтімі
////////////////////////////////////////////////////////////////////////////////

/// [`[T]: : concat`] үшін trait көмекшісі (тілім::concat).
///
/// Note: `Item` типті параметр бұл trait-де қолданылмайды, бірақ бұл имплдардың жалпы болуына мүмкіндік береді.
/// Онсыз біз бұл қатені аламыз:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Себебі бірнеше `Borrow<[_]>` имплементері бар `V` типтері болуы мүмкін, мысалы бірнеше `T` типтері қолданылуы мүмкін:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Біріктірілгеннен кейін пайда болған тип
    type Output;

    /// [`[T]: : concat`] жүзеге асыру (тілім::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: : join`] үшін trait көмекшісі (тілім::қосылу)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Біріктірілгеннен кейін пайда болған тип
    type Output;

    /// [`[T]: : қосылуды] жүзеге асыру (тілім::қосылу)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Тіліктерге арналған стандартты trait орындалуы
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // жазылмайтын нәрсені мақсатқа тастаңыз
        target.truncate(self.len());

        // target.len <= self.len жоғарыдағы кесіндіге байланысты, сондықтан мұндағы тілімдер әрдайым шектеулі болады.
        //
        let (init, tail) = self.split_at(target.len());

        // «allocations/resources» мәндерін қайта қолданыңыз.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Алдын ала сұрыпталған `v[1..]` тізбегіне `v[0]` енгізеді, сонда бүкіл `v[..]` сұрыпталады.
///
/// Бұл кірістірудің ажырамас ішкі бағдарламасы.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Мұнда кірістіруді жүзеге асырудың үш әдісі бар:
            //
            // 1. Іргелес элементтерді біріншісі соңғы межелі орынға жеткенше ауыстырыңыз.
            //    Алайда, осылайша деректерді қажет болғаннан көбірек көшіреміз.
            //    Егер элементтер үлкен құрылымдар болса (көшіру қымбат), бұл әдіс баяу болады.
            //
            // 2. Бірінші элементтің дұрыс орны табылғанша қайталаңыз.
            // Одан кейін элементтерді ауыстырып, оған орын беріңіз, содан кейін оны қалған тесікке салыңыз.
            // Бұл жақсы әдіс.
            //
            // 3. Бірінші элементті уақытша айнымалыға көшіріңіз.Ол үшін дұрыс орын табылғанша қайталаңыз.
            // Біз жүріп өткен кезде барлық өтілген элементтерді алдыңғы ұяшыққа көшіріңіз.
            // Соңында, уақытша айнымалыдан қалған саңылауға деректерді көшіріңіз.
            // Бұл әдіс өте жақсы.
            // Эталондық көрсеткіштер 2-ші әдіске қарағанда сәл жақсы өнімділікті көрсетті.
            //
            // Барлық әдістер эталонды, ал 3-ші нәтиже көрсетті.Сондықтан біз сол біреуін таңдадық.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Кірістіру процесінің аралық күйін әрқашан екі мақсатқа бағытталған `hole` бақылайды:
            // 1. `v` тұтастығын `is_less` ішіндегі panics-тен қорғайды.
            // 2. Соңында `v` ішіндегі қалған тесікті толтырады.
            //
            // Panic қауіпсіздігі:
            //
            // Егер процесстің кез келген нүктесінде `is_less` panics болса, `hole` құлап, `v`-тегі тесікті `tmp`-мен толтырады, осылайша `v` бастапқыда ұстап тұрған барлық нысандарды дәл бір рет ұстап тұруын қамтамасыз етеді.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` құлайды және осылайша `tmp`-ті `v`-тегі қалған тесікке көшіреді.
        }
    }

    // Түсірген кезде `src`-тен `dest`-ке көшіреді.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Х03Х уақытша сақтау ретінде `v[..mid]` және `v[mid..]` кемитін емес қосылыстарын біріктіреді және нәтижені `v[..]` сақтайды.
///
/// # Safety
///
/// Екі тілім бос болмауы керек және `mid` шектерде болуы керек.
/// `buf` буфері қысқа тілімнің көшірмесін сақтауға жеткілікті болуы керек.
/// Сондай-ақ, `T` нөлдік өлшемді болмауы керек.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Біріктіру процесі алдымен `buf`-ке қысқа нұсқаны көшіреді.
    // Содан кейін ол жаңадан көшірілген жүгіруді және алға қарай (немесе артқа) жүгіреді, олардың келесі тұтынылмаған элементтерін салыстырады және кішісін (немесе үлкенін) `v`-ке көшіреді.
    //
    // Қысқа жүгіру толығымен аяқталғаннан кейін, процесс аяқталады.Егер алдымен ұзағырақ жүгіру қажет болса, онда біз `v` ішіндегі қалған шұңқырға неғұрлым аз қалғанын көшіруіміз керек.
    //
    // Процестің аралық күйін әрқашан екі мақсатқа бағытталған `hole` бақылайды:
    // 1. `v` тұтастығын `is_less` ішіндегі panics-тен қорғайды.
    // 2. Егер ұзағырақ уақыт жұмсалса, `v` ішіндегі қалған тесікті толтырады.
    //
    // Panic қауіпсіздігі:
    //
    // Егер процесстің кез келген нүктесінде `is_less` panics болса, онда `hole` құлап, `v` саңылауын `buf`-тегі тұтынылмаған диапазонмен толтырады, осылайша `v` бастапқыда ұстап тұрған барлық объектілерді дәл бір рет ұстап тұрады.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Сол жаққа жүгіру қысқа.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Бастапқыда бұл көрсеткіштер олардың массивтерінің басына нұсқайды.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Аз жағын тұтыныңыз.
            // Егер тең болса, тұрақтылықты сақтау үшін сол жаққа жүгіруді жөн көріңіз.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Дұрыс жүгіру қысқа.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Бастапқыда бұл көрсеткіштер массивтерінің ұштарын көрсетеді.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Үлкен жағын тұтыныңыз.
            // Егер тең болса, тұрақтылықты сақтау үшін дұрыс жүгіруді жөн көріңіз.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Соңында, `hole` құлап кетеді.
    // Егер қысқа жүгіріс толықтай жұмсалмаса, оның қалдығы енді `v` саңылауына көшіріледі.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Түсірген кезде `start..end` ауқымын `dest..`-ке көшіреді.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` өлшемі нөлге тең емес, сондықтан оның мөлшеріне бөлген жөн.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Бұл біріктіру сұранысы XSX-те егжей-тегжейлі сипатталған TimSort-тан кейбір (бірақ барлығы емес) идеяларды алады.
///
///
/// Алгоритм табиғи жүгіру деп аталатын қатаң кемитін және кемімейтін секрецияларды анықтайды.Әлі біріктірілмеген күтілуде.
/// Әрбір жаңадан табылған стек стекке итеріледі, содан кейін осы екі инвариант қанағаттандырылғанға дейін бірнеше жұп іргелес жүгірістер біріктіріледі:
///
/// 1. әрбір `i` үшін `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. әрбір `i` үшін `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Инварианттар жалпы жұмыс уақыты *O*(*n*\*log(* n*)) ең нашар болғанына) кепілдік береді.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ұзындығы бойынша кесінділер кірістіру сұрыптауының көмегімен сұрыпталады.
    const MAX_INSERTION: usize = 20;
    // Өте қысқа жүгіру, ең болмағанда, көптеген элементтерді қамту үшін кірістіру сұрыптауының көмегімен кеңейтіледі.
    const MIN_RUN: usize = 10;

    // Сұрыптаудың нөлдік өлшемдер бойынша мағыналы әрекеті жоқ.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Қысқа массивтер бөлуді болдырмау үшін кірістіру бойынша сұрыптау арқылы орнында сұрыпталады.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Сызғыш жад ретінде пайдалану үшін буферді бөліңіз.Біз 0 ұзындығын сақтаймыз, сондықтан егер `is_less` panics болса, дторларға қауіп төндірмей, `v` мазмұнының таяз көшірмелерін сақтай аламыз.
    //
    // Екі сұрыпталған жүгіруді біріктіру кезінде бұл буфер қысқа мерзімнің көшірмесін ұстайды, оның ұзындығы әрқашан көп дегенде `len / 2` болады.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v`-те табиғи жүгіруді анықтау үшін біз оны артқа қарай өтеміз.
    // Бұл таңқаларлық шешім болып көрінуі мүмкін, бірақ біріктірудің (forwards) қарама-қарсы бағытында жүретінін жиі ескеріңіз.
    // Эталондық көрсеткіштер бойынша алға қарай біріктіру артқа қосылудан сәл тезірек.
    // Қорытындылай келе, артқа өту арқылы жүгіруді анықтау өнімділікті жақсартады.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Келесі табиғи жүгіруді табыңыз, егер ол қатаң түрде төмендейтін болса, оны өзгертіңіз.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Егер ол өте қысқа болса, тағы бірнеше элементтерді енгізіңіз.
        // Енгізуді сұрыптау қысқа тізбектердегі сұрыптауды біріктіруге қарағанда жылдамырақ, сондықтан бұл өнімділікті айтарлықтай жақсартады.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Бұл жүгіруді стекке итеріңіз.
        runs.push(Run { start, len: end - start });
        end = start;

        // Инварианттарды қанағаттандыру үшін іргелес жүгірістердің бірнеше жұбын біріктіріңіз.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Соңында, дәл бір жүгіру стекте қалуы керек.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Жүгірістер стегін зерттейді және біріктіру үшін келесі жүгіру жұбын анықтайды.
    // Нақтырақ айтсақ, егер `Some(r)` қайтарылса, бұл келесіде `runs[r]` пен `runs[r + 1]` біріктірілуі керек дегенді білдіреді.
    // Егер алгоритм оның орнына жаңа іске қосуды жалғастыра берсе, `None` қайтарылады.
    //
    // TimSort өзінің арбамен орындалуымен танымал, мұнда сипатталған:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Оқиғаның мәні: біз инварианттарды стек үстіндегі төрт жүгіріске енгізуіміз керек.
    // Оларды тек үштікке енгізу инварианттардың стектегі *барлық* жүгіру үшін сақталуын қамтамасыз ету үшін жеткіліксіз.
    //
    // Бұл функция инварианттарды алғашқы төрт айналымға дұрыс тексереді.
    // Сонымен қатар, егер жоғарғы іске қосу 0 индексінен басталса, ол сұрыптауды аяқтау үшін стек толығымен құлағанша біріктіру операциясын қажет етеді.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}