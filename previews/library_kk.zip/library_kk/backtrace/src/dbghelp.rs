//! Dbghelp байланысын Windows-те басқаруға көмектесетін модуль
//!
//! Windows-тегі артқы тректер (ең болмағанда MSVC үшін) негізінен `dbghelp.dll` және оның құрамындағы әртүрлі функциялар арқылы жұмыс істейді.
//! Бұл функциялар қазіргі уақытта `dbghelp.dll`-ке статикалық байланыстырудан гөрі *динамикалық* жүктелген.
//! Қазіргі уақытта мұны стандартты кітапхана жасайды (және теориялық тұрғыдан сол жерде қажет), бірақ бұл кітапхананың статикалық тәуелділіктерін азайтуға көмектесетін күш, өйткені артқы жолдар әдетте міндетті емес.
//!
//! Айтуынша, `dbghelp.dll` әрдайым дерлік Windows-ке жүктеледі.
//!
//! Осы қолдаудың барлығын динамикалық түрде жүктейтіндіктен, біз `winapi` ішіндегі бастапқы анықтамаларды қолдана алмайтындығымызды ескереміз, керісінше біз функцияның нұсқағышының типтерін өзіміз анықтап, оны қолдануымыз керек.
//! Біз шынымен winapi-ді көшіру ісімен айналысқымыз келмейді, сондықтан бізде Cargo `verify-winapi` мүмкіндігі бар, ол барлық байланыстар winapi-ге сәйкес келеді және бұл функция CI-де қосылады.
//!
//! Сонымен, сіз мұнда `dbghelp.dll` үшін DLL ешқашан түсірілмейтінін және қазіргі уақытта әдейі жасалатынын ескертесіз.
//! Біздің ойымызша, біз оны жаһандық деңгейде кэштей аламыз және оны API-ге қоңырау шалу кезінде қолдана аламыз, қымбат loads/unloads-тен аулақ боламыз.
//! Егер бұл ағып кететін детекторларға қатысты болса немесе біз оған жеткенде көпірден өте аламыз.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// `SymGetOptions` және `SymSetOptions` айналасында жұмыс жасаңыз, ол winapi-де жоқ.
// Әйтпесе, бұл тек winapi-ге қарсы түрлерді тексерген кезде ғана қолданылады.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Винапиде әлі анықталмаған
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Бұл winapi-де анықталған, бірақ ол дұрыс емес (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Винапиде әлі анықталмаған
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Бұл макро `Dbghelp` құрылымын анықтау үшін қолданылады, оның ішіне біз жүктей алатын барлық функционалды көрсеткіштер кіреді.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` үшін жүктелген DLL
            dll: HMODULE,

            // Біз қолдана алатын әр функцияға арналған әр функцияның көрсеткіші
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Бастапқыда DLL жүктелмеген
            dll: 0 as *mut _,
            // Бастапқыда барлық функциялар динамикалық жүктелуі керек деп нөлге қойылады.
            //
            $($name: 0,)*
        };

        // Әр функция түрі үшін ыңғайлы typedef.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` ашу әрекеттері.
            /// Егер ол жұмыс жасаса немесе `LoadLibraryW` сәтсіз болса, қате қайтарады.
            ///
            /// Panics, егер кітапхана жүктелген болса.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Біз қолданғымыз келетін әр әдіс үшін функция.
            // Шақырылған кезде ол кэштелген функция көрсеткішін оқиды немесе оны жүктейді және жүктелген мәнді қайтарады.
            // Жүктемелер табысқа жету үшін бекітіледі.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Dbghelp функцияларына сілтеме жасау үшін тазалау құлыптарын қолдануға ыңғайлы прокси.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Осы crate-тен `dbghelp` API функцияларына қол жеткізу үшін барлық қолдауды бастаңыз.
///
///
/// Бұл функция **қауіпсіз** екенін ескеріңіз, оның ішкі синхронизациясы бар.
/// Сондай-ақ, бұл функцияны бірнеше рет рекурсивті түрде шақыруға болатындығын ескеріңіз.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Біріншіден, бұл функцияны синхрондау қажет.Мұны басқа жіптерден бір уақытта немесе бір жіптің ішінде рекурсивті деп атауға болады.
        // Назар аударыңыз, бұл одан да күрделі, себебі біз мұнда қолданатын `dbghelp`,*сонымен қатар* барлық `dbghelp` қоңырау шалушыларымен осы процесте синхрондалуы керек.
        //
        // Әдетте, `dbghelp`-ке бір процестің ішінде онша көп қоңырау шалынбайды және біз оған тек біз ғана қол жеткізіп жатырмыз деп ойлауымыз мүмкін.
        // Алайда біз мазалайтын басқа бір негізгі пайдаланушы бар, ол өзімізді ирониялық, бірақ стандартты кітапханада.
        // Rust стандартты кітапханасы артқы тректі қолдау үшін осы crate-ге байланысты, және бұл crate crates.io-те де бар.
        // Бұл дегеніміз, егер стандартты кітапхана panic артқы ізін басып шығарса, онда crates.io-тен шығатын осы crate-мен бәсекелес болуы мүмкін, бұл бұзушылықтарды тудырады.
        //
        // Бұл синхрондау мәселесін шешуге көмектесу үшін біз мұнда Windows-ке қатысты айла-шарғы қолданамыз (бұл синхрондау туралы Windows-қа арналған шектеулер).
        // Біз бұл қоңырауды қорғау үшін *сессия-жергілікті* атты мутекс деп атаймыз.
        // Мұндағы мақсат-стандартты кітапхана мен crate осы жерде синхрондау үшін Rust деңгейіндегі API интерфейстерімен бөлісудің қажеті жоқ, керісінше олардың бір-бірімен синхрондалғандығына көз жеткізу үшін артта жұмыс істей алады.
        //
        // Осылайша, бұл функция стандартты кітапхана арқылы немесе crates.io арқылы шақырылғанда, дәл сол мутекс сатып алынғанына сенімді бола аламыз.
        //
        // Сонымен, мұның бәрі біз `HANDLE`-ті атомдық түрде жасаймыз, бұл Windows-те мутекс деп аталады.
        // Біз бұл функцияны бөлісетін басқа ағындармен сәл үндестіреміз және осы функцияның бір данасында бір ғана дескриптордың жасалуын қамтамасыз етеміз.
        // Дүниеде сақталғаннан кейін тұтқа ешқашан жабылмайтынын ескеріңіз.
        //
        // Біз шынымен құлыптан өткеннен кейін біз оны сатып аламыз және `Init` тұтқасы біз оны ақыр аяғында тастауға жауап береді.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Жарайды, бауырым!Енді бәріміз қауіпсіз синхрондалғаннан кейін бәрін өңдеуге кірісейік.
        // Алдымен біз `dbghelp.dll` осы процесте шынымен жүктелгенін қамтамасыз етуіміз керек.
        // Біз мұны статикалық тәуелділіктен аулақ болу үшін динамикалық түрде жасаймыз.
        // Бұрын бұл таңқаларлық байланыстыру мәселелерін шешу үшін жасалды және екілік файлдарды портативті етіп жасауға арналған, өйткені бұл көбінесе жөндеуге арналған утилита.
        //
        //
        // `dbghelp.dll`-ті ашқаннан кейін біз оған кейбір инициализация функцияларын шақыруымыз керек, бұл төменде толығырақ.
        // Біз мұны бір-ақ рет жасаймыз, сондықтан біздің әлі аяқталған-аяқталмағандығымызды көрсететін ғаламдық буль бар.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` жалаушасының орнатылғандығына көз жеткізіңіз, өйткені MSVC-дің бұл туралы жеке құжаттарына сәйкес: "This is the fastest, most efficient way to use the symbol handler.", сондықтан солай етейік!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // MSVC көмегімен символдарды инициализациялаңыз.Бұл сәтсіздікке ұшырауы мүмкін екенін ескеріңіз, бірақ біз оны елемейміз.
        // Бұл үшін алдын-ала техниканың бір тоннасы жоқ, бірақ LLVM іштегі қайтару мәнін елемейтін сияқты және LLVM-дегі зарарсыздандырғыш кітапханалардың бірі бұл сәтсіз болса, қорқынышты ескертуді басып шығарады, бірақ ұзақ мерзімді негізде оны елемейді.
        //
        //
        // Бұл жағдай Rust үшін көп кездеседі, бұл стандартты кітапхана және crates.io-тағы crate екеуі де `SymInitializeW` үшін бәсекелескісі келеді.
        // Стандартты кітапхана тарихи тұрғыдан көп жағдайда тазартуды бастамақшы болған, бірақ қазір бұл crate-ді қолданған кезде біреу инициализацияға жетеді, ал екіншісі сол инициализацияны алады.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}