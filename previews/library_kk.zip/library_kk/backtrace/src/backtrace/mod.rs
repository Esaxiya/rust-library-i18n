use core::ffi::c_void;
use core::fmt;

/// Барлық белсенді кадрларды стек ізін есептеу үшін берілген жабуға өткізіп, ағымдағы шақыру стегін тексереді.
///
/// Бұл функция бағдарлама үшін стек іздерін есептеуде осы кітапхананың жұмыс күші болып табылады.Берілген жабу `cb` стектегі қоңырау жақтауы туралы ақпаратты білдіретін `Frame` даналарын береді.
/// Жабу жоғарыдан төмен қарай жақтаулармен беріледі (жақында алдымен функциялар деп аталады).
///
/// Жабудың қайтарылатын мәні-бұл артта қалудың жалғасуының белгісі.`false` қайтару мәні кері бағытты тоқтатады және дереу оралады.
///
/// `Frame` сатып алынғаннан кейін, сіз `ip` (нұсқау сілтемесі) немесе символдық мекен-жайын `Symbol`-ге атын және/немесе файлдың атын/жол нөмірін білуге болатын түрлендіру үшін қоңырау шалғыңыз келеді.
///
///
/// Бұл салыстырмалы түрде төмен деңгейлі функция екенін ескеріңіз, егер сіз, мысалы, кейінірек тексерілетін артқы ізді түсіргіңіз келсе, онда `Backtrace` түрі сәйкес келуі мүмкін.
///
/// # Қажетті мүмкіндіктер
///
/// Бұл функция `backtrace` crate-тің `std` мүмкіндігін қосуды талап етеді, ал `std` функциясы әдепкі бойынша қосылады.
///
/// # Panics
///
/// Бұл функция ешқашан panic-ге ұмтылмайды, бірақ егер `cb` panics қамтамасыз етсе, онда кейбір платформалар процесті тоқтатуға екі еселенген panic мәжбүр етеді.
/// Кейбір платформалар C кітапханасын пайдаланады, олар қоңырауды қайтару мүмкін емес, оларды іштей қолданады, сондықтан `cb`-тен дүрбелең процестің тоқтатылуына себеп болуы мүмкін.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // артта қалуды жалғастыру
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace` сияқты, тек синхрондалмағандықтан қауіпті.
///
/// Бұл функцияда синхрондау кепілдігі жоқ, бірақ осы crate-тің `std` мүмкіндігі жинақталмаған кезде қол жетімді.
/// Қосымша құжаттама мен мысалдар үшін `trace` функциясын қараңыз.
///
/// # Panics
///
/// `cb` дүрбелеңіндегі ескертулер туралы `trace` туралы ақпаратты қараңыз.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Осы crate-тің `trace` функциясына берілген артқы тректің бір кадрын бейнелейтін trait.
///
/// Қадағалау функциясының жабылуы кадрлармен қамтамасыз етілетін болады, және рамка іс жүзінде жіберіледі, өйткені оның орындалуы әрқашан жұмыс уақытына дейін белгілі бола бермейді.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Осы кадрдың ағымдағы нұсқауышын қайтарады.
    ///
    /// Әдетте, бұл кадрда орындалатын келесі нұсқаулық, бірақ барлық іске асырулар мұны 100% дәлдікпен тізімдемейді (бірақ ол әдетте өте жақын).
    ///
    ///
    /// Бұл мәнді таңба атауына айналдыру үшін оны `backtrace::resolve`-ге беру ұсынылады.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Осы кадрдың ағымдағы стек көрсеткішін қайтарады.
    ///
    /// Егер бұл фрейм үшін стек сілтемесін backend қалпына келтіре алмаса, нөлдік көрсеткіш қайтарылады.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Осы функцияның кадрдың басталатын адресін қайтарады.
    ///
    /// Бұл `ip` қайтарған нұсқаулық көрсеткішін функцияның басына қайтарып, сол мәнді қайтаруға тырысады.
    ///
    /// Алайда, кейбір жағдайларда, бұл функциялардан `ip` қайтарылады.
    ///
    /// Қайтарылған мәнді кейде `backtrace::resolve` жоғарыда келтірілген `ip` сәтсіз болған жағдайда пайдалануға болады.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Жақтау тиесілі модульдің негізгі адресін қайтарады.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Бұл бірінші кезекте болуы керек, бұл Miri хост платформасына қарағанда басымдыққа ие
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // тек dbghelp символында қолданылады
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}