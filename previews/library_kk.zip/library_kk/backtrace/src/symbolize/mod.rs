use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Таңбаны көрсетілген жабуға өткізіп, мекен-жайды символға шешіңіз.
///
/// Бұл функция берілген адресті жергілікті символдар кестесі, динамикалық символдар кестесі немесе DWARF түзету ақпараттары (белсенді іске асырылуына байланысты) сияқты аудандардан іздейді, олар пайда болатын белгілерді табады.
///
///
/// Егер ажыратымдылықты орындау мүмкін болмаса, жабу деп аталмауы мүмкін, сонымен қатар егер сызылған функциялар жағдайында оны бірнеше рет шақыруға болады.
///
/// Берілген шартты белгілер көрсетілген `addr` бойынша орындалуды білдіреді, сол мекен-жай үшін file/line жұптарын қайтарады (егер бар болса).
///
/// Егер сізде `Frame` болса, онда оның орнына `resolve_frame` функциясын пайдалану ұсынылатындығын ескеріңіз.
///
/// # Қажетті мүмкіндіктер
///
/// Бұл функция `backtrace` crate-тің `std` мүмкіндігін қосуды талап етеді, ал `std` функциясы әдепкі бойынша қосылады.
///
/// # Panics
///
/// Бұл функция ешқашан panic-ге ұмтылмайды, бірақ егер `cb` panics қамтамасыз етсе, онда кейбір платформалар процесті тоқтатуға екі еселенген panic мәжбүр етеді.
/// Кейбір платформалар C кітапханасын пайдаланады, олар қоңырауды қайтару мүмкін емес, оларды іштей қолданады, сондықтан `cb`-тен дүрбелең процестің тоқтатылуына себеп болуы мүмкін.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // тек жоғарғы жақтауға қарау
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Бұрын түсірілген кадрды таңбаға дейін жабыңыз, таңбаны көрсетілген жабуға жіберіңіз.
///
/// Бұл функция `resolve` сияқты функцияны орындайды, тек адрес орнына `Frame` аргумент ретінде қабылданады.
/// Бұл артқы трекингтің кейбір платформалық енгізулеріне символдар туралы не дәлірек айтқанда, ішкі фреймдер туралы ақпаратты ұсынуға мүмкіндік береді.
///
/// Мүмкіндігінше осыны пайдалану ұсынылады.
///
/// # Қажетті мүмкіндіктер
///
/// Бұл функция `backtrace` crate-тің `std` мүмкіндігін қосуды талап етеді, ал `std` функциясы әдепкі бойынша қосылады.
///
/// # Panics
///
/// Бұл функция ешқашан panic-ге ұмтылмайды, бірақ егер `cb` panics қамтамасыз етсе, онда кейбір платформалар процесті тоқтатуға екі еселенген panic мәжбүр етеді.
/// Кейбір платформалар C кітапханасын пайдаланады, олар қоңырауды қайтару мүмкін емес, оларды іштей қолданады, сондықтан `cb`-тен дүрбелең процестің тоқтатылуына себеп болуы мүмкін.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // тек жоғарғы жақтауға қарау
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Стек кадрларынан алынған IP мәндері әдетте стек трассасы болып табылатын шақырудан *кейін*(always?) нұсқауы болып табылады.
// Мұны символизациялау filename/line нөмірінің алдыңғы қатарда болуына әкеледі, егер ол функцияның аяқталуына жақын болса.
//
// Бұл барлық платформаларда негізінен әрқашан кездесетін сияқты, сондықтан біз оны қайтарылған команданың орнына әрқашан алдыңғы шақыру нұсқаулығына шешу үшін шешілген ipден біреуін алып тастаймыз.
//
//
// Ең дұрысы біз мұны жасамас едік.
// Ең дұрысы біз мұнда `resolve` API-ді шақырушылардан -1-ті қолмен жасауын және ағымдық емес,*алдыңғы* нұсқаулық үшін орналасу туралы ақпарат қажет екенін ескеруін талап етеміз.
// Ең дұрысы, егер біз келесі нұсқаулықтың немесе ағымдықтың мекен-жайы болып табылсақ, `Frame`-ке шығамыз.
//
// Әзірге бұл өте ұнамды мәселе, сондықтан біз оны әрқашан іштей алып тастаймыз.
// Тұтынушылар жұмыс істеп, жақсы нәтижелерге қол жеткізуі керек, сондықтан біз жеткілікті деңгейде болуымыз керек.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` сияқты, тек синхрондалмағандықтан қауіпті.
///
/// Бұл функцияда синхрондау кепілдігі жоқ, бірақ осы crate-тің `std` мүмкіндігі жинақталмаған кезде қол жетімді.
/// Қосымша құжаттама мен мысалдар үшін `resolve` функциясын қараңыз.
///
/// # Panics
///
/// `cb` дүрбелеңіндегі ескертулер туралы `resolve` туралы ақпаратты қараңыз.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` сияқты, тек синхрондалмағандықтан қауіпті.
///
/// Бұл функцияда синхрондау кепілдігі жоқ, бірақ осы crate-тің `std` мүмкіндігі жинақталмаған кезде қол жетімді.
/// Қосымша құжаттама мен мысалдар үшін `resolve_frame` функциясын қараңыз.
///
/// # Panics
///
/// `cb` дүрбелеңіндегі ескертулер туралы `resolve_frame` туралы ақпаратты қараңыз.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Файлдағы шартты белгіні білдіретін trait.
///
/// Бұл trait нысаны trait ретінде `backtrace::resolve` функциясының жабылуына әкеліп соғады және ол іс жүзінде жіберіледі, өйткені оның артында қандай іске асыру бар екендігі белгісіз.
///
///
/// Символ функция туралы мәтінмәндік ақпарат бере алады, мысалы, аты, файл аты, жол нөмірі, нақты адрес және т.б.
/// Барлық ақпарат әрдайым символ түрінде бола бермейді, сондықтан барлық әдістер `Option` мәнін береді.
///
///
pub struct Symbol {
    // TODO: бұл өмірді `Symbol`-ге дейін сақтау керек,
    // бірақ қазіргі уақытта бұл өзгеріс.
    // Әзірге бұл қауіпсіз, өйткені `Symbol` тек сілтеме арқылы беріледі және оны клондау мүмкін емес.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Осы функцияның атын қайтарады.
    ///
    /// Қайтарылған құрылымды символ атауына қатысты әртүрлі қасиеттерге сұрау салу үшін пайдалануға болады:
    ///
    ///
    /// * `Display` іске асырылуы бұзылған таңбаны басып шығарады.
    /// * Символдың шикі `str` мәніне қол жеткізуге болады (егер ол utf-8 жарамды болса).
    /// * Таңба атауының бастапқы байттарына қол жеткізуге болады.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Осы функцияның бастапқы мекен-жайын қайтарады.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Файлдың бастапқы атауын тілім ретінде қайтарады.
    /// Бұл негізінен `no_std` орталары үшін пайдалы.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Осы таңба қазір орындалатын баған нөмірін қайтарады.
    ///
    /// Мұнда тек gimli ғана мән береді, содан кейін ғана егер `filename` `Some` мәнін берсе, демек, ол ұқсас ескертулерге тәуелді болады.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Осы таңба қазір орындалып жатқан жол нөмірін қайтарады.
    ///
    /// Бұл қайтару мәні, егер `filename` `Some` қайтарса, әдетте `Some` болып табылады және сәйкесінше ескертулерге тәуелді болады.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Осы функция анықталған файл атауын қайтарады.
    ///
    /// Бұл қазіргі уақытта libbacktrace немесе gimli қолданылған кезде ғана қол жетімді (мысалы
    /// unix екіншісі debuginfo-мен құрастырылған кезде).
    /// Егер бұл шарттардың ешқайсысы орындалмаса, онда бұл `None` мәнін қайтарады.
    ///
    /// # Қажетті мүмкіндіктер
    ///
    /// Бұл функция `backtrace` crate-тің `std` мүмкіндігін қосуды талап етеді, ал `std` функциясы әдепкі бойынша қосылады.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Мүмкін, талданған C++ символы, егер Rust ретінде мангольдік белгіні талдау сәтсіз болса.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Бұл нөлдік өлшемді ұстаңыз, сонда `cpp_demangle` мүмкіндігі өшірілген кезде ешқандай шығындар болмайды.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Белгі атауының айналасындағы орам, демонгацияланған атқа эргономикалық қосылғыштарды, байттарды, шикізат тізбегін және т.б.
///
// `cpp_demangle` функциясы қосылмаған кезде өлі кодқа рұқсат етіңіз.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Шикі байттардың ішінен жаңа таңба атауын жасайды.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Егер utf-8 таңбасы жарамды болса, шикі (mangled) символының атын `str` ретінде қайтарады.
    ///
    /// Егер сіз бұзылған нұсқаны қаласаңыз, `Display` бағдарламасын қолданыңыз.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Шикі символ атауын байт тізімі ретінде қайтарады
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Егер бұл бұзылған таңба шынымен жарамсыз болса, оны басып шығаруға болады, сондықтан қатені сыртқа таратпау арқылы осында өңдеңіз.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Мекен-жайларды символизациялау үшін қолданылатын кэш жадын қалпына келтіруге тырысыңыз.
///
/// Бұл әдіс, әйтпесе глобальды немесе жіпте кэштелген кез-келген ғаламдық деректер құрылымын шығаруға тырысады, олар әдетте DWARF ақпараттарын немесе ұқсастарын талдайды.
///
///
/// # Caveats
///
/// Бұл функция әрқашан қол жетімді болғанымен, көптеген іске асыруларда ештеңе істемейді.
/// Dbghelp немесе libbacktrace сияқты кітапханалар күйді бөлуге және бөлінген жадыны басқаруға мүмкіндік бермейді.
/// Әзірге бұл crate-тің `gimli-symbolize` ерекшелігі-бұл функцияның кез-келген әсер ететін жалғыз мүмкіндігі.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}