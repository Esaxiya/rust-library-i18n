//! Libbacktrace-де DWARF-кодын қолдану арқылы символика стратегиясы.
//!
//! Әдетте gcc-мен таратылатын libbacktrace C кітапханасы артқы ізді құруды ғана емес (оны біз қолданбаймыз), сонымен қатар артқы трек символикасын және сызылған кадрлар мен басқа нәрселер туралы қарапайым картридждермен жұмыс жасауды қолдайды.
//!
//!
//! Бұл әр түрлі мәселелерге байланысты салыстырмалы түрде күрделі, бірақ негізгі идея:
//!
//! * Алдымен біз `backtrace_syminfo` деп атаймыз.Егер мүмкін болса, бұл символдық ақпаратты динамикалық кестеден алады.
//! * Әрі қарай біз `backtrace_pcinfo` телефонына қоңырау шаламыз.Бұл қол жетімді болса, debuginfo кестелерін талдайды және кірістірілген жақтаулар, файл аттары, жол нөмірлері және т.б. туралы ақпаратты қалпына келтіруге мүмкіндік береді.
//!
//! Ергежейлі кестелерді libbacktrace-ге қосу туралы көптеген қулықтар бар, бірақ бұл әлемнің соңы емес және төменде оқыған кезде жеткілікті айқын болады деп үміттенемін.
//!
//! Бұл MSVC емес және OSX емес платформалар үшін стандартты символика стратегиясы.Libstd дегенмен, бұл OSX үшін әдепкі стратегия.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Мүмкіндігінше debuginfo-дан келетін және мысалы, кірістірілген фреймдер үшін дәлірек болатын `function` атауын таңдаған жөн.
                // Егер ол жоқ болса, `symname`-де көрсетілген кесте символына қайта оралыңыз.
                //
                // Кейде `function` біршама аз дәлдікті сезінетінін ескеріңіз, мысалы, `std::panicking::try::do_call`-тің `try<i32,closure>` құрамына кірмейді.
                //
                // Неге екені түсініксіз, бірақ жалпы `function` атауы дәлірек болып көрінеді.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // әзірге ештеңе жасамаңыз
}

/// `syminfo_cb` форматына өткен `data` көрсеткішінің түрі
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Осы қоңырау `backtrace_syminfo`-тен шақырылғаннан кейін, біз шеше бастағанда, біз `backtrace_pcinfo`-ге қоңырау шаламыз.
    // `backtrace_pcinfo` функциясы түзету ақпаратын қарастырады және file/line ақпаратын қалпына келтіру, сонымен қатар сызылған кадрларды жасауға тырысады.
    // `backtrace_pcinfo` сәтсіздікке ұшырауы мүмкін екенін немесе егер жөндеу туралы ақпарат болмаса, көп жұмыс істей алмайтындығын ескеріңіз, сондықтан егер бұл орын алса, біз `syminfo_cb`-тен кем дегенде бір таңбамен қоңырау шаламыз.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `pcinfo_cb` форматына өткен `data` көрсеткішінің түрі
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API күй құруды қолдайды, бірақ күйді жоюды қолдамайды.
// Мен мұны мемлекет құруға, содан кейін мәңгілік өмір сүруге арналған деп түсінемін.
//
// Мен осы күйді тазартатын at_exit() өңдегішін тіркегім келеді, бірақ libbacktrace мұны жасауға ешқандай мүмкіндік бермейді.
//
// Осы шектеулермен бұл функция статикалық кэштелген күйге ие, ол бірінші рет сұралған кезде есептеледі.
//
// Бэктрекингтің барлығы сериялық түрде болатынын ұмытпаңыз (бір жаһандық құлып).
//
// Бұл жерде синхрондаудың болмауы `resolve` сыртқы синхрондау талабына байланысты екенін ескеріңіз.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Libbacktrace-тің қауіпті мүмкіндіктерін пайдаланбаңыз, өйткені біз оны әрқашан синхрондалған түрде атаймыз.
        //
        0,
        error_cb,
        ptr::null_mut(), // қосымша деректер жоқ
    );

    return STATE;

    // Libbacktrace мүлдем жұмыс істеуі үшін ағымдағы орындалатын үшін DWARF түзету ақпаратын табу керек екенін ескеріңіз.Әдетте ол бірнеше тетіктер арқылы жүзеге асырылады, бірақ мыналармен шектелмейді:
    //
    // * /proc/self/exe қолдау көрсетілетін платформаларда
    // * Файл атауы күйді құру кезінде нақты берілген
    //
    // Libbacktrace кітапханасы-C кодының үлкен жиынтығы.Бұл, әрине, жады қауіпсіздігінің осалдығын білдіреді, әсіресе дұрыс емес debuginfo-мен жұмыс істеу кезінде.
    // Либстд бұлардың көпшілігіне тарихи тұрғыдан жүгінді.
    //
    // Егер /proc/self/exe пайдаланылса, онда біз бұларды елемеуге болады, өйткені libbacktrace "mostly correct" деп санайды, әйтпесе "attempted to be correct" ергежейлі түзету ақпаратымен оғаш нәрселер жасамайды.
    //
    //
    // Егер біз файл атауын берсек, онда кейбір платформаларда (мысалы, BSD сияқты) зиянды актер ерікті файлды сол жерге орналастыруға себеп болуы мүмкін.
    // Бұл libbacktrace-ге файл атауы туралы айтатын болсақ, ол ерікті файлды қолдануы мүмкін, себебі сегменттер бұзылуы мүмкін.
    // Егер біз libbacktrace-ге ештеңе айтпасақ, ол /proc/self/exe сияқты жолдарды қолдамайтын платформаларда ештеңе жасамайды!
    //
    // Файл атауына өтуге * * болмауға барынша тырысатынымызды ескерсек те, /proc/self/exe-ті мүлдем қолдамайтын платформаларда болуымыз керек.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Ең дұрысы біз `std::env::current_exe` қолданатын едік, бірақ біз мұнда `std` талап ете алмайтынымызды ескеріңіз.
            //
            // Ағымдағы орындалатын жолды статикалық аймаққа жүктеу үшін `_NSGetExecutablePath` пайдаланыңыз (егер ол тым кішкентай болса, бас тартыңыз).
            //
            //
            // Біз libbacktrace-ке бүлінетін орындалатын файлдарда өліп қалмауға үлкен сенім артып отырғандығымызды ескеріңіз, бірақ ол сөзсіз ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows файлдарды ашу режимі бар, ол ашылғаннан кейін оны жою мүмкін емес.
            // Біз мұнда жалпы тілегіміз келеді, өйткені біз libbacktrace-ге бергеннен кейін, орындалатын файлдың біздің ішімізден өзгермеуін қамтамасыз еткіміз келеді, бұл кездейсоқ деректерді libbacktrace-ге беру мүмкіндігімізді азайтады (бұл дұрыс пайдаланылмауы мүмкін).
            //
            //
            // Мұнда біз өз биемізге өзіндік құлып алуға тырысу үшін аздап би билейтінімізді ескерсек:
            //
            // * Ағымдағы процестің тұтқасын алыңыз, оның файл атауын жүктеңіз.
            // * Файлдың атын оң жақтағы жалаушалармен ашыңыз.
            // * Ағымдағы процестің файл атауын бірдей етіп, оны қайта жүктеңіз
            //
            // Егер осының бәрі өтсе, біз теория жүзінде біздің процестің файлын аштық және оның өзгермейтініне кепілдік береміз.FWIW-дің бір бөлігі тарихи libstd-тен көшірілген, сондықтан бұл менің болып жатқан оқиғаны ең жақсы түсіндіруім.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Бұл статикалық жадта өмір сүреді, сондықтан біз оны қайтара аламыз ..
                static mut BUF: [i8; N] = [0; N];
                // ... және бұл уақытша болғандықтан стекте өмір сүреді
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // мұнда `handle` әдейі ағып кетеді, себебі бұл файлдың атауындағы құлыпты сақтау керек.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Біз үзілген тілімді қайтарғымыз келеді, егер бәрі толтырылған болса және ол жалпы ұзындыққа тең болса, оны сәтсіздікке теңестіреміз.
                //
                //
                // Әйтпесе, табысты қайтарған кезде нөлге байттың тілімге қосылғанына көз жеткізіңіз.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // кері қателіктер қазіргі уақытта кілемшенің астында жатыр
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` API-ге қоңырау шалыңыз, ол (кодты оқудан бастап) `syminfo_cb`-ге дәл бір рет қоңырау шалуы керек (немесе қате болуы мүмкін).
    // Содан кейін біз `syminfo_cb` шеңберінде көбірек жұмыс істейміз.
    //
    // Біз мұны істейтіндігімізді ескеріңіз, өйткені `syminfo` таңбалар кестесін қарастырады, екілік файлда түзету туралы ақпарат болмаса да, таңбалардың аттарын табады.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}