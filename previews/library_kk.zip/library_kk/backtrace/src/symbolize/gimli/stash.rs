// дәл қазір Linux-де қолданылады, сондықтан басқа жерде өлі кодқа рұқсат етіңіз
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Байт буферіне арналған қарапайым арена бөлгіш.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Көрсетілген көлемдегі буферді бөледі және оған өзгермелі сілтемені қайтарады.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // ҚАУІПСІЗДІК: бұл өзгертілетін құрылысты жасайтын жалғыз функция
        // `self.buffers` сілтемесі.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // ҚАУІПСІЗДІК: біз элементтерді ешқашан `self.buffers`-тен алып тастамаймыз, сондықтан сілтеме
        // кез-келген буфер ішіндегі деректерге `self` өмір сүргенше өмір сүреді.
        &mut buffers[i]
    }
}