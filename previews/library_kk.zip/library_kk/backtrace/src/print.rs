#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Артқы тректерге арналған форматтаушы.
///
/// Бұл түрді артқы тректің қайдан шыққанына қарамастан басып шығару үшін қолдануға болады.
/// Егер сізде `Backtrace` түрі болса, оның `Debug` орындалуы осы басып шығару пішімін қолданады.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Басып шығаруға болатын стильдер
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Жақсы ақпаратты ғана қамтитын терретрияны басып шығарады
    Short,
    /// Барлық мүмкін ақпаратты қамтитын кері ізді басып шығарады
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Ұсынылған `fmt`-ке шығыс жазатын жаңа `BacktraceFmt` жасаңыз.
    ///
    /// `format` аргументі артқы трек басылған стильді басқарады, ал `print_path` аргументі `BytesOrWideString` файл аттарын басып шығару үшін қолданылады.
    /// Бұл түрдің өзі файл атауын басып шығармайды, бірақ бұл үшін қайта қоңырау шалу қажет.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Басып шығарылатын артқы тректің кіріспесін басып шығарады.
    ///
    /// Бұл кейбір платформаларда артқы тректер кейінірек толық символикалануы үшін қажет, әйтпесе бұл `BacktraceFmt` жасағаннан кейін сіз қоңырау шалатын алғашқы әдіс болуы керек.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Артқы жолдың шығысына кадр қосады.
    ///
    /// Бұл міндеттеме кадрды басып шығару үшін қолдануға болатын `BacktraceFrameFmt` RAII данасын қайтарады, ал жойылған кезде ол кадр есептегішін көбейтеді.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Артқы жолдың шығуын аяқтайды.
    ///
    /// Қазіргі уақытта бұл тыйым салынады, бірақ future артқы із форматтарымен үйлесімділік үшін қосылады.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Қазіргі уақытта future қосымшаларына рұқсат беру үшін осы hook қоса алғанда, тыйым салынады.
        Ok(())
    }
}

/// Кері іздің бір кадрына арналған форматтаушы.
///
/// Бұл типті `BacktraceFmt::frame` функциясы жасайды.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Осы кадр форматтаушысымен `BacktraceFrame` басып шығарады.
    ///
    /// Бұл `BacktraceFrame` ішіндегі барлық `BacktraceSymbol` даналарын рекурсивті түрде басып шығарады.
    ///
    /// # Қажетті мүмкіндіктер
    ///
    /// Бұл функция `backtrace` crate-тің `std` мүмкіндігін қосуды талап етеді, ал `std` функциясы әдепкі бойынша қосылады.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceFrame` ішінде `BacktraceSymbol` басып шығарады.
    ///
    /// # Қажетті мүмкіндіктер
    ///
    /// Бұл функция `backtrace` crate-тің `std` мүмкіндігін қосуды талап етеді, ал `std` функциясы әдепкі бойынша қосылады.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: біз ештеңе басып шығармайтынымыз жақсы емес
            // utf8 емес файл аттарымен.
            // Бақытымызға орай барлығы дерлік utf8, сондықтан бұл өте жаман болмауы керек.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Әдетте осы crate шикі кері байланысының ішінен шикі бақыланатын `Frame` және `Symbol` басып шығарады.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Шикі жақтауды артқы ізге қосады.
    ///
    /// Бұл әдіс, алдыңғы әдіске қарағанда, әр түрлі дереккөздер болған жағдайда бастапқы дәлелдерді қолданады.
    /// Мұны бір кадр үшін бірнеше рет атауға болатындығын ескеріңіз.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Бағана туралы ақпаратты қоса, артқы ізге шикі жақтауды қосады.
    ///
    /// Бұл әдіс, алдыңғы әдіс сияқты, әр түрлі жерден дерек көзі болған жағдайда бастапқы дәлелдерді қабылдайды.
    /// Мұны бір кадр үшін бірнеше рет атауға болатындығын ескеріңіз.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Фуксия процесс барысында символ жасай алмайды, сондықтан оны кейінірек символдау үшін қолдануға болатын арнайы формат бар.
        // Мұнда мекен-жайларды өз форматында басып шығарудың орнына басып шығарыңыз.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" кадрларын басып шығарудың қажеті жоқ, бұл негізінен жүйенің артқы ізі супер алысқа ұмтылғанын білдіреді.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Sgx анклавындағы TCB өлшемін кішірейту үшін біз символдарды ажыратуға мүмкіндік беретін функцияны іске асырғымыз келмейді.
        // Керісінше, біз мекен-жайдың офсетін осы жерге басып шығара аламыз, оны кейінірек функцияны түзету үшін салыстыруға болады.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Жақтаудың индексін, сондай-ақ кадрдың қосымша нұсқау нұсқауын басып шығарыңыз.
        // Егер біз осы жақтаудың бірінші символынан тыс болсақ, біз тек бос орынды басып шығарамыз.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Егер біз толық кері шегініс жасасақ, қосымша ақпарат алу үшін баламалы форматты қолдана отырып, таңба атауын жазыңыз.
        // Мұнда біз аты жоқ белгілерді де басқарамыз,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Соңында, егер олар бар болса, filename/line нөмірін басып шығарыңыз.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line белгілердің атымен жолдарда басылады, сондықтан өзімізді оң жаққа туралау үшін бос орынды босатыңыз.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Файл атауын басып шығару үшін ішкі қоңырауды жіберіңіз, содан кейін жол нөмірін басып шығарыңыз.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Егер бар болса, баған нөмірін қосыңыз.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Біз тек жақтаудың бірінші символына ғана мән береміз
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}