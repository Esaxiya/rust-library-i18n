# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust жұмыс уақытында артқы тректер алуға арналған кітапхана.
Бұл кітапхана жұмыс жасау үшін бағдарламалық интерфейсті қамтамасыз ету арқылы стандартты кітапхананың қолдауын күшейтуге бағытталған, бірақ сонымен қатар қазіргі артқы ізді libstd's panics сияқты оңай басып шығаруды қолдайды.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Артқы ізді түсіріп, онымен жұмыс жасауды кейінге қалдыру үшін сіз `Backtrace` жоғарғы деңгейін қолдана аласыз.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Егер сіз нақты қадағалау функцияларына шикі қол жетімділік алғыңыз келсе, онда сіз `trace` және `resolve` функцияларын тікелей пайдалана аласыз.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Осы нұсқаулықтың таңбасының атауына қарай шешіңіз
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // келесі кадрға өтуді жалғастырыңыз
    });
}
```

# License

Бұл жоба лицензияланған

 * Apache лицензиясы, 2.0, ([LICENSE-APACHE](LICENSE-APACHE) немесе http://www.apache.org/licenses/LICENSE-2.0 нұсқалары)
 * MIT лицензиясы ([LICENSE-MIT](LICENSE-MIT) немесе http://opensource.org/licenses/MIT)

сіздің қалауыңыз бойынша.

### Contribution

Егер сіз басқаша айтпаған болсаңыз, Apache-2.0 лицензиясында анықталғандай, сіз backtrace-rs-ке қосу үшін әдейі ұсынған кез-келген жарна ешқандай қосымша шарттарсыз жоғарыда көрсетілгендей қос лицензиялы болады.







