use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Бұл тұрақты беткей емес, бірақ LLVM дәл қазір оның артықшылығын әрдайым пайдалана алмаса да, олардың арасындағы `?` арзан ұстауға көмектеседі.
    //
    // (Өкінішке орай, нәтиже мен опция сәйкес келмейді, сондықтан ControlFlow екеуіне де сәйкес келмейді.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}