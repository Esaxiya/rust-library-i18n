#![stable(feature = "futures_api", since = "1.36.0")]

//! Асинхронды мәндер.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Бұл түр қажет, себебі:
///
/// а) генераторлар `for<'a, 'b> Generator<&'a mut Context<'b>>`-ті қолдана алмайды, сондықтан біз шикі көрсеткішті жіберуіміз керек (<https://github.com/rust-lang/rust/issues/68923> қараңыз).
///
/// б) Шикі көрсеткіштер мен `NonNull` `Send` немесе `Sync` емес, сондықтан бұл future non-Send/Sync-ті жасайды және біз мұны қаламаймыз.
///
/// Сондай-ақ, ол HIR-ді `.await` төмендетуді жеңілдетеді.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Генераторды future ішіне ораңыз.
///
/// Бұл функция `GenFuture` астына қайтарады, бірақ қате туралы жақсы хабарлар беру үшін оны `impl Trait` ішінде жасырады (`GenFuture<[closure.....]>` орнына `impl Future`).
///
// Бұл біз `const async fn` қалпына келтіргеннен кейін қосымша қателіктерді болдырмау үшін `const`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Негізгі генераторда өзіндік сілтеме қарыздарын құру үшін біз async/await futures қозғалмайтындығына сенеміз.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // ҚАУІПСІЗДІК: Қауіпсіз, өйткені біз !Unpin + !Drop, және бұл жай өріс проекциясы.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // `&mut Context`-ті `NonNull` шикі көрсеткішіне айналдырып, генераторды жалғастырыңыз.
            // `.await` төмендету оны `&mut Context`-ке қайтарады.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // ҚАУІПСІЗДІК: қоңырау шалушы `cx.0` жарамды көрсеткіш екеніне кепілдік беруі керек
    // ол өзгермелі анықтамаға қойылатын барлық талаптарды орындайды.
    unsafe { &mut *cx.0.as_ptr().cast() }
}