use crate::future::Future;

/// `Future` түрлендіру.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// future аяқталғаннан кейін шығаратын өнім.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Мұны future-тің қай түріне айналдырып жатырмыз?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Мәннен future жасайды.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}