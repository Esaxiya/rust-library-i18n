use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Бұл функция бір жерде қолданылып, оның орындалуы сызылған болуы мүмкін болғанымен, бұған дейінгі әрекеттер rustc-ны баяулатады:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Жадының блогының орналасуы.
///
/// `Layout` данасы белгілі бір жадының орналасуын сипаттайды.
/// Сіз `Layout` құрылғысын бөлгішке беру үшін кіріс ретінде жасайсыз.
///
/// Барлық орналасулар байланысты өлшемге және екі деңгейдің теңестірілуіне ие.
///
/// (`GlobalAlloc` жадтың барлық сұраныстарының өлшемі нөлге тең болмауын талап етсе де, орналасулар нөлдік емес өлшемге ие болу үшін * қажет емес екенін ескеріңіз).
/// Қоңырау шалушы осы сияқты шарттардың орындалуын қамтамасыз етуі керек, неғұрлым нашар талаптары бар белгілі бір үлестіргіштерді қолдануы керек немесе неғұрлым жеңіл `Allocator` интерфейсін қолдануы керек.
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // байтпен өлшенетін сұралған жад блогының мөлшері.
    size_: usize,

    // байтпен өлшенетін сұралған жад блогының туралануы.
    // біз мұның әрқашан екінің күші екендігіне кепілдік береміз, өйткені API сияқты `posix_memalign` оны қажет етеді және бұл Layout конструкторларына мәжбүрлі шектеулер болып табылады.
    //
    //
    // (Алайда, біз аналогты түрде «align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)» талап етпейміз
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Берілген `size` және `align`-тен `Layout` құрастырады немесе егер келесі шарттардың кез-келгені орындалмаса, `LayoutError` береді:
    ///
    /// * `align` нөл болмауы керек,
    ///
    /// * `align` екі күш болуы керек,
    ///
    /// * `size`, `align` дәлдіктеріне дейін дөңгелектелгенде, асып кетпеуі керек (яғни дөңгелектелген мән `usize::MAX`-тен аз немесе оған тең болуы керек).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (екінің күші теңестіруді білдіреді!=0.)

        // Дөңгеленген өлшемі:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Біз жоғарыдан тураланғанын білеміз!=0.
        // Егер қосу (туралау, 1) толып кетпесе, онда дөңгелектеу жақсы болады.
        //
        // Керісінше,&!-Мен масштабтау! (Туралау, 1) тек төменгі ретті биттерді алып тастайды.
        // Егер толып кету қосындымен орын алса, онда&-mask бұл толып жатқанды қайтару үшін жеткілікті шегере алмайды.
        //
        //
        // Жоғарыда жиынтықтың толып кетуін тексеру қажет және жеткілікті екендігін білдіреді.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // ҚАУІПСІЗДІК: `from_size_align_unchecked` үшін жағдайлар жасалды
        // жоғарыда тексерілген.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Барлық тексерулерді айналып өтіп, макет жасайды.
    ///
    /// # Safety
    ///
    /// Бұл функция қауіпті, себебі ол [`Layout::from_size_align`]-тен алғышарттарды тексермейді.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // ҚАУІПСІЗДІК: қоңырау шалушы `align` нөлден үлкен екеніне көз жеткізуі керек.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Осы макеттің жад блогы үшін минималды өлшемі байтпен.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Осы макеттің жад блогы үшін минималды байт туралауы.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `T` типті мәнді ұстауға жарамды `Layout` құрастырады.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // ҚАУІПСІЗДІК: теңестіру Rust екіге тең болатынына кепілдік береді
        // size + align combo мекенжай кеңістігімізге сәйкес келетініне кепілдік беріледі.
        // Нәтижесінде panics кодын енгізуді болдырмау үшін тексерілмеген конструкторды пайдаланыңыз, егер ол жеткілікті оңтайландырылмаған болса.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` үшін тірек құрылымын бөлу үшін қолдануға болатын жазбаны сипаттайтын макет шығарады (ол trait немесе тілім сияқты басқа өлшемсіз тип болуы мүмкін).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // ҚАУІПСІЗДІК: қауіпті нұсқаны не үшін қолданатындығын `new` жүйесінен қараңыз
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` үшін тірек құрылымын бөлу үшін қолдануға болатын жазбаны сипаттайтын макет шығарады (ол trait немесе тілім сияқты басқа өлшемсіз тип болуы мүмкін).
    ///
    /// # Safety
    ///
    /// Бұл функция қоңырау шалу үшін келесі шарттар сақталған кезде ғана қауіпсіз болады:
    ///
    /// - Егер `T` `Sized` болса, бұл функция қоңырау шалу үшін әрдайым қауіпсіз.
    /// - Егер `T` өлшемсіз құйрығы:
    ///     - а [slice], содан кейін кесінді құйрығының ұзындығы интиализацияланған бүтін сан болуы керек, ал *бүкіл мәннің* мөлшері (құйрықтың динамикалық ұзындығы + статикалық өлшемді префикс) `isize` сәйкес келуі керек.
    ///     - a [trait object], содан кейін көрсеткіштің vtable бөлігі мөлшерленбейтін конверсиямен алынған `T` типі үшін жарамды vtable-ды көрсетуі керек және *барлық мәннің* өлшемі (динамикалық құйрық ұзындығы + статикалық өлшемді префикс) `isize`-ке сәйкес келуі керек.
    ///
    ///     - (unstable) [extern type] болса, онда бұл функция қоңырау шалу үшін әрдайым қауіпсіз, бірақ panic немесе басқаша түрде қате мәнді қайтаруы мүмкін, өйткені сыртқы типтің орналасуы белгісіз.
    ///     Бұл сыртқы типтегі құйрыққа сілтеме жасаудағы [`Layout::for_value`] сияқты мінез-құлық.
    ///     - әйтпесе, бұл функцияны шақыруға консервативті жол берілмейді.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // ҚАУІПСІЗДІК: біз қоңырау шалушыға осы функциялардың алғышарттарын береміз
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // ҚАУІПСІЗДІК: қауіпті нұсқаны не үшін қолданатындығын `new` жүйесінен қараңыз
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Салбырап тұрған, бірақ осы Макет үшін жақсы тураланған `NonNull` жасайды.
    ///
    /// Көрсеткіш мәні жарамды көрсеткішті көрсетуі мүмкін екенін ескеріңіз, демек, оны "not yet initialized" қарауыл мәні ретінде қолдануға болмайды.
    /// Бөлінген түрлер инициализацияны басқа тәсілдермен қадағалап отыруы керек.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // ҚАУІПСІЗДІК: туралау нөлге тең емес екеніне кепілдік беріледі
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self`-мен бірдей орналасу мәнін ұстай алатын жазуды сипаттайтын макет жасайды, бірақ ол `align` (байтпен өлшенеді) туралауына тураланады.
    ///
    ///
    /// Егер `self` белгіленген туралауға сәйкес келсе, онда `self` қайтарады.
    ///
    /// Қайтарылған орналасудың басқа туралануына қарамастан, бұл әдіс жалпы өлшемге ешқандай толтырғыш қоспайтынын ескеріңіз.
    /// Басқаша айтқанда, егер `K` өлшемі 16 болса, `K.align_to(32)`*бәрібір* өлшемі болады.
    ///
    /// Егер `self.size()` пен берілген `align` тіркесімі [`Layout::from_size_align`] тізіміндегі шарттарды бұзса, қате қайтарады.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Келесі мекен-жай `align`-ті қанағаттандыратынына (байтпен өлшенетін) көз жеткізу үшін `self`-тен кейін енгізуіміз керек толтырғыштың мөлшерін қайтарады.
    ///
    /// мысалы, егер `self.size()` 9-ға тең болса, онда `self.padding_needed_for(4)` 3-ті қайтарады, өйткені бұл 4 тураланған адрес алу үшін қажет байт байттарының минималды саны (сәйкес жад блогы 4 тураланған адрестен басталады).
    ///
    ///
    /// Бұл функцияның қайтару мәнінің мағынасы жоқ, егер `align` екі қуат емес болса.
    ///
    /// Қайтарылған мәннің утилитасы `align` барлық бөлінген жад блогы үшін бастапқы адрестің туралануынан аз немесе оған тең болуын талап ететіндігін ескеріңіз.Бұл шектеулерді қанағаттандырудың бір жолы-`align <= self.align()` қамтамасыз ету.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Дөңгеленген мән:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // содан кейін біз толтырылған айырмашылықты қайтарамыз: `len_rounded_up - len`.
        //
        // Біз модульдік арифметиканы қолданамыз:
        //
        // 1. туралау> 0 деп кепілдендірілген, сондықтан туралау, 1 әрқашан жарамды.
        //
        // 2.
        // `len + align - 1` ең көбі `align - 1`-ге толып кетуі мүмкін, сондықтан `!(align - 1)` бар&-маска толып кеткен жағдайда `len_rounded_up` 0 болатынын қамтамасыз етеді.
        //
        //    Осылайша, `len` қосқан кезде қайтарылған төсеме 0 береді, бұл `align` теңестіруін тривиальды түрде қанағаттандырады.
        //
        // (Әрине, өлшемі мен толтырылған жадының блоктарын жоғарыда көрсетілген тәртіппен бөлуге тырысу, бөлгіштің қателігін тудыруы керек.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Бұл макеттің өлшемін макеттің тураланымына дейін дөңгелектеу арқылы макет жасайды.
    ///
    ///
    /// Бұл макет өлшеміне `padding_needed_for` нәтижесін қосқанға тең.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Бұл толып кетуі мүмкін емес.Орналасу инвариантынан дәйексөз:
        // > `size`, `align` дәлдіктеріне дейін дөңгелектегенде,
        // > асып кетпеуі керек (яғни дөңгелектелген мән-ден аз болуы керек
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` даналарына арналған жазуды сипаттайтын макет жасайды, әр дананың сұралған өлшемі мен туралануын қамтамасыз ету үшін әрқайсысының арасында тиісті мөлшерде толтырулар болады.
    /// Сәтті болған кезде `(k, offs)` қайтарылады, мұндағы `k`-массивтің орналасуы, ал `offs`-массивтің әрбір элементінің басталуы арасындағы қашықтық.
    ///
    /// Арифметикалық толтыру кезінде `LayoutError` қайтарады.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Бұл толып кетуі мүмкін емес.Орналасу инвариантынан дәйексөз:
        // > `size`, `align` дәлдіктеріне дейін дөңгелектегенде,
        // > асып кетпеуі керек (яғни дөңгелектелген мән-ден аз болуы керек
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // ҚАУІПСІЗДІК: self.align қазірдің өзінде жарамды және алгоритм өлшемі болғандығы белгілі
        // қазірдің өзінде толтырылған.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `self` жазбасын сипаттайтын макет жасайды, содан кейін `next`, соның ішінде `next` дұрыс туралануын қамтамасыз ету үшін кез-келген қажетті толтыруды қосады, бірақ *артқы толтырғыш жоқ*.
    ///
    /// C ұсынылған `repr(C)` орналасуына сәйкес болу үшін барлық өрістермен орналасуды кеңейткеннен кейін `pad_to_align` қоңырауына қоңырау шалу керек.
    /// (`repr(Rust)`, as it is unspecified.) әдепкі Rust ұсыну схемасына сәйкес келудің жолы жоқ
    ///
    /// Екі бөліктің де туралануын қамтамасыз ету үшін алынған орналасудың туралануы `self` және `next` максималды болатынын ескеріңіз.
    ///
    /// `Ok((k, offset))` қайтарады, мұндағы `k`-тізбектелген жазбаның орналасуы, ал `offset`-байланған жазбаға ендірілген `next` басталуының салыстырмалы орны (жазбаның өзі 0 ығысуынан басталады).
    ///
    ///
    /// Арифметикалық толтыру кезінде `LayoutError` қайтарады.
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` құрылымының орналасуын және оның өрістерінің орналасуларынан өрістердің жылжуын есептеу үшін:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` көмегімен аяқтауды ұмытпаңыз!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // оның жұмыс істейтіндігін тексеріңіз
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self` даналарына арналған жазуды сипаттайтын макет жасайды, әр дананың арасында толтырусыз.
    ///
    /// `repeat`-тен айырмашылығы, `repeat_packed`, егер `self` данасы дұрыс тураланған болса да, қайталанатын `self` даналарының дұрыс туралануына кепілдік бермейтінін ескеріңіз.
    /// Басқаша айтқанда, егер `repeat_packed` қайтарған макет массивті бөлу үшін қолданылса, массивтегі барлық элементтердің тураланғанына кепілдік берілмейді.
    ///
    /// Арифметикалық толтыру кезінде `LayoutError` қайтарады.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// `self` жазбасын сипаттайтын макет жасайды, содан кейін `next`, екеуінің арасында қосымша төсеу жоқ.
    /// Ешқандай төсеме салынбағандықтан, `next` туралауы маңызды емес, нәтижесінде *орналасуға* мүлдем қосылмайды.
    ///
    ///
    /// Арифметикалық толтыру кезінде `LayoutError` қайтарады.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` жазбасын сипаттайтын макет жасайды.
    ///
    /// Арифметикалық толтыру кезінде `LayoutError` қайтарады.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` немесе басқа `Layout` конструкторына берілген параметрлер оның құжатталған шектеулерін қанағаттандырмайды.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (бұл бізге trait қатесінің төменгі ағыны үшін қажет)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}