//! Жадыны бөлу API

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` қатесі ресурстардың таусылуына немесе берілген кіріс аргументтерін осы үлестірушімен біріктіру кезінде қателіктерге байланысты болуы мүмкін бөлу қателігін көрсетеді.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (бұл бізге trait қатесінің төменгі ағыны үшін қажет)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` енгізу [`Layout`][] арқылы сипатталған деректердің ерікті блоктарын бөлуге, өсіруге, кішірейтуге және бөлуге болады.
///
/// `Allocator` ZST-ге, сілтемелерге немесе ақылды сілтемелерге енгізуге арналған, өйткені `MyAlloc([u8; N])` сияқты бөлгішті бөлінген жадыға жаңартпай, жылжыту мүмкін емес.
///
/// [`GlobalAlloc`][]-тен айырмашылығы, `Allocator`-де нөлдік өлшемді бөлуге рұқсат етіледі.
/// Егер негізгі бөлгіш мұны қолдамаса (мысалы, jemalloc) немесе нөлдік көрсеткішті қайтарса (мысалы, `libc::malloc`), оны іске асыру керек.
///
/// ### Қазіргі уақытта жад бөлінген
///
/// Кейбір әдістер жады блогын *қазіргі уақытта бөлгіш арқылы бөлуді* талап етеді.Бұл дегеніміз:
///
/// * жад блогының бастапқы адресін бұрын [`allocate`], [`grow`] немесе [`shrink`] қайтарған және
///
/// * кейіннен жад блогы бөлінбеген, мұнда блоктар тікелей [`deallocate`]-ге жіберіле отырып бөлінеді немесе `Ok` қайтаратын [`grow`] немесе [`shrink`]-ке ауыстырылады.
///
/// Егер `grow` немесе `shrink` `Err` мәнін қайтарса, берілген сілтеме жарамды болып қалады.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Жад сыйымдылығы
///
/// Кейбір әдістер макеттің жад блогына *сәйкес келуін* талап етеді.
/// "fit" форматына жад блогы үшін нені білдіреді (немесе баламалы, "fit" жад блогы үшін орналасу) келесі шарттар орындалуы керек:
///
/// * Блокты [`layout.align()`] сияқты дәлдеуімен бөлу керек, және
///
/// * Берілген [`layout.size()`] `min ..= max` ауқымына енуі керек, мұнда:
///   - `min` - бұл блокты бөлу үшін жақында қолданылған макеттің өлшемі және
///   - `max` бұл [`allocate`], [`grow`] немесе [`shrink`]-тен қайтарылған ең соңғы нақты өлшем.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Бөлгіштен қайтарылған жад блоктары жарамды жадыға бағытталуы керек және оның дұрысы және оның барлық клондары түскенге дейін жарамдылығын сақтауы керек,
///
/// * бөлу құралын клондау немесе жылжыту осы бөлгіштен қайтарылған жад блоктарын жарамсыз етпеуі керек.Клондалған бөлгіш дәл сол бөлгіш сияқты әрекет етуі керек және
///
/// * [*currently allocated*] болатын жад блогының кез келген көрсеткіші бөлгіштің кез келген басқа әдісіне берілуі мүмкін.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Жадының блогын бөлуге тырысады.
    ///
    /// Табысқа жеткенде, `layout` өлшемі мен туралау кепілдіктеріне сәйкес келетін [`NonNull<[u8]>`][NonNull] қайтарылады.
    ///
    /// Қайтарылған блоктың мөлшері `layout.size()` көрсетілгеннен үлкенірек болуы мүмкін және оның мазмұны инициалданбаған болуы мүмкін немесе болмауы мүмкін.
    ///
    /// # Errors
    ///
    /// `Err` мәнін қайтару жадтың таусылғанын немесе `layout` үлестірушінің өлшеміне немесе туралау шектеулеріне сәйкес келмейтіндігін көрсетеді.
    ///
    /// Іске асырулар `Err`-ті дүрбелең немесе түсік тастаудан гөрі жадының сарқылуына қайтаруға шақырады, бірақ бұл қатаң талап емес.
    /// (Атап айтқанда: бұл trait-ті жадының таусылуын тоқтататын жергілікті бөлу кітапханасының үстінде қолдану *заңды*.)
    ///
    /// Бөлу қателігіне байланысты есептеуді тоқтатқысы келетін клиенттерге `panic!` немесе соған ұқсас шақырудан гөрі [`handle_alloc_error`] функциясын шақыру ұсынылады.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` ұнайды, бірақ сонымен бірге қайтарылған жадтың инициализацияланғандығына кепілдік береді.
    ///
    /// # Errors
    ///
    /// `Err` мәнін қайтару жадтың таусылғанын немесе `layout` үлестірушінің өлшеміне немесе туралау шектеулеріне сәйкес келмейтіндігін көрсетеді.
    ///
    /// Іске асырулар `Err`-ті дүрбелең немесе түсік тастаудан гөрі жадының сарқылуына қайтаруға шақырады, бірақ бұл қатаң талап емес.
    /// (Атап айтқанда: бұл trait-ті жадының таусылуын тоқтататын жергілікті бөлу кітапханасының үстінде қолдану *заңды*.)
    ///
    /// Бөлу қателігіне байланысты есептеуді тоқтатқысы келетін клиенттерге `panic!` немесе соған ұқсас шақырудан гөрі [`handle_alloc_error`] функциясын шақыру ұсынылады.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // ҚАУІПСІЗДІК: `alloc` жарамды жад блогын қайтарады
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` сілтемесі бар жадыны бөледі.
    ///
    /// # Safety
    ///
    /// * `ptr` осы бөлгіш арқылы [*currently allocated*] жадының блогын белгілеуі керек және
    /// * `layout` бұл жадының блогы [*fit*] болуы керек.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Жадының блогын кеңейту әрекеттері.
    ///
    /// Сілтегіш пен бөлінген жадтың нақты өлшемін қамтитын жаңа [`NonNull<[u8]>`][NonNull] шығарады.Көрсеткіш `new_layout` сипаттаған деректерді ұстауға жарайды.
    /// Мұны орындау үшін бөлгіш `ptr` сілтеме жасаған бөлуді жаңа орналасуға сай кеңейтуі мүмкін.
    ///
    /// Егер бұл `Ok` мәнін қайтарса, онда `ptr` сілтеме жасаған жады блогына меншік құқығы осы үлестіргішке өтті.
    /// Жад босатылған болуы мүмкін немесе босатылмаған болуы мүмкін, егер ол осы әдістің қайтару мәні арқылы қоңырау шалушыға қайта жіберілмесе, оны пайдалануға жарамсыз деп санау керек.
    ///
    /// Егер бұл әдіс `Err` мәнін қайтарса, онда жады блогына меншік құқығы осы үлестіргішке берілмеген және жад блогының мазмұны өзгеріссіз қалады.
    ///
    /// # Safety
    ///
    /// * `ptr` осы бөлгіш арқылы [*currently allocated*] жадының блогын белгілеуі керек.
    /// * `old_layout` бұл жадының блогы [*fit*] болуы керек (`new_layout` аргументі оған сәйкес келмейді).
    /// * `new_layout.size()` `old_layout.size()`-тен үлкен немесе оған тең болуы керек.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Егер жаңа орналасу үлестірушінің өлшеміне және бөлгіштің туралау шектеулеріне сәйкес келмесе немесе басқаша өсу сәтсіз болса, `Err` қайтарады.
    ///
    /// Іске асырулар `Err`-ті дүрбелең немесе түсік тастаудан гөрі жадының сарқылуына қайтаруға шақырады, бірақ бұл қатаң талап емес.
    /// (Атап айтқанда: бұл trait-ті жадының таусылуын тоқтататын жергілікті бөлу кітапханасының үстінде қолдану *заңды*.)
    ///
    /// Бөлу қателігіне байланысты есептеуді тоқтатқысы келетін клиенттерге `panic!` немесе соған ұқсас шақырудан гөрі [`handle_alloc_error`] функциясын шақыру ұсынылады.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // ҚАУІПСІЗДІК: өйткені `new_layout.size()` үлкен немесе тең болуы керек
        // `old_layout.size()`, ескі де, жаңа да бөлу `old_layout.size()` байт үшін оқуға және жазуға жарамды.
        // Сондай-ақ, ескі бөлу әлі бөлінбегендіктен, ол `new_ptr` қабаттасуы мүмкін емес.
        // Осылайша, `copy_nonoverlapping`-ке қоңырау шалу қауіпсіз.
        // `dealloc` қауіпсіздік шартын қоңырау шалушы сақтауы керек.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` ұнайды, бірақ сонымен бірге жаңа мазмұнды қайтару алдында нөлге теңестіруді қамтамасыз етеді.
    ///
    /// Жады блогында сәтті қоңырау шалғаннан кейін келесі мазмұн болады
    /// `grow_zeroed`:
    ///   * `0..old_layout.size()` байттары бастапқы бөлінуден сақталған.
    ///   * `old_layout.size()..old_size` байттары бөлгіштің орындалуына байланысты сақталады немесе нөлге айналады.
    ///   `old_size` `grow_zeroed` қоңырауына дейінгі жад блогының өлшеміне жатады, ол оны бөлу кезінде бастапқыда сұралған өлшемнен үлкен болуы мүмкін.
    ///   * `old_size..new_size` байттары нөлге теңестірілген.`new_size`-бұл `grow_zeroed` қоңырауы арқылы қайтарылған жад блогының өлшемін білдіреді.
    ///
    /// # Safety
    ///
    /// * `ptr` осы бөлгіш арқылы [*currently allocated*] жадының блогын белгілеуі керек.
    /// * `old_layout` бұл жадының блогы [*fit*] болуы керек (`new_layout` аргументі оған сәйкес келмейді).
    /// * `new_layout.size()` `old_layout.size()`-тен үлкен немесе оған тең болуы керек.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Егер жаңа орналасу үлестірушінің өлшеміне және бөлгіштің туралау шектеулеріне сәйкес келмесе немесе басқаша өсу сәтсіз болса, `Err` қайтарады.
    ///
    /// Іске асырулар `Err`-ті дүрбелең немесе түсік тастаудан гөрі жадының сарқылуына қайтаруға шақырады, бірақ бұл қатаң талап емес.
    /// (Атап айтқанда: бұл trait-ті жадының таусылуын тоқтататын жергілікті бөлу кітапханасының үстінде қолдану *заңды*.)
    ///
    /// Бөлу қателігіне байланысты есептеуді тоқтатқысы келетін клиенттерге `panic!` немесе соған ұқсас шақырудан гөрі [`handle_alloc_error`] функциясын шақыру ұсынылады.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // ҚАУІПСІЗДІК: өйткені `new_layout.size()` үлкен немесе тең болуы керек
        // `old_layout.size()`, ескі де, жаңа да бөлу `old_layout.size()` байт үшін оқуға және жазуға жарамды.
        // Сондай-ақ, ескі бөлу әлі бөлінбегендіктен, ол `new_ptr` қабаттасуы мүмкін емес.
        // Осылайша, `copy_nonoverlapping`-ке қоңырау шалу қауіпсіз.
        // `dealloc` қауіпсіздік шартын қоңырау шалушы сақтауы керек.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Жад блогын кішірейту әрекеттері.
    ///
    /// Сілтегіш пен бөлінген жадтың нақты өлшемін қамтитын жаңа [`NonNull<[u8]>`][NonNull] шығарады.Көрсеткіш `new_layout` сипаттаған деректерді ұстауға жарайды.
    /// Мұны орындау үшін бөлгіш `ptr` сілтемесін жаңа орналасуға сәйкес келуі мүмкін.
    ///
    /// Егер бұл `Ok` мәнін қайтарса, онда `ptr` сілтеме жасаған жады блогына меншік құқығы осы үлестіргішке өтті.
    /// Жад босатылған болуы мүмкін немесе босатылмаған болуы мүмкін, егер ол осы әдістің қайтару мәні арқылы қоңырау шалушыға қайта жіберілмесе, оны пайдалануға жарамсыз деп санау керек.
    ///
    /// Егер бұл әдіс `Err` мәнін қайтарса, онда жады блогына меншік құқығы осы үлестіргішке берілмеген және жад блогының мазмұны өзгеріссіз қалады.
    ///
    /// # Safety
    ///
    /// * `ptr` осы бөлгіш арқылы [*currently allocated*] жадының блогын белгілеуі керек.
    /// * `old_layout` бұл жадының блогы [*fit*] болуы керек (`new_layout` аргументі оған сәйкес келмейді).
    /// * `new_layout.size()` `old_layout.size()`-тен кіші немесе оған тең болуы керек.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Егер жаңа орналасу үлестірушінің өлшеміне және бөлгіштің туралау шектеулеріне сәйкес келмесе немесе басқаша кішірею сәтсіз болса, `Err` мәнін қайтарады.
    ///
    /// Іске асырулар `Err`-ті дүрбелең немесе түсік тастаудан гөрі жадының сарқылуына қайтаруға шақырады, бірақ бұл қатаң талап емес.
    /// (Атап айтқанда: бұл trait-ті жадының таусылуын тоқтататын жергілікті бөлу кітапханасының үстінде қолдану *заңды*.)
    ///
    /// Бөлу қателігіне байланысты есептеуді тоқтатқысы келетін клиенттерге `panic!` немесе соған ұқсас шақырудан гөрі [`handle_alloc_error`] функциясын шақыру ұсынылады.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // ҚАУІПСІЗДІК: өйткені `new_layout.size()` төмен немесе оған тең болуы керек
        // `old_layout.size()`, ескі де, жаңа да бөлу `new_layout.size()` байт үшін оқуға және жазуға жарамды.
        // Сондай-ақ, ескі бөлу әлі бөлінбегендіктен, ол `new_ptr` қабаттасуы мүмкін емес.
        // Осылайша, `copy_nonoverlapping`-ке қоңырау шалу қауіпсіз.
        // `dealloc` қауіпсіздік шартын қоңырау шалушы сақтауы керек.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Осы `Allocator` данасы үшін "by reference" адаптерін жасайды.
    ///
    /// Қайтарылған адаптер `Allocator`-ті де іске асырады және оны қарызға алады.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // ҚАУІПСІЗДІК: қауіпсіздік шартын қоңырау шалушы сақтауы керек
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ҚАУІПСІЗДІК: қауіпсіздік шартын қоңырау шалушы сақтауы керек
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ҚАУІПСІЗДІК: қауіпсіздік шартын қоңырау шалушы сақтауы керек
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ҚАУІПСІЗДІК: қауіпсіздік шартын қоңырау шалушы сақтауы керек
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}