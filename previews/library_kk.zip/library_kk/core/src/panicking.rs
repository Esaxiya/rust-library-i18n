//! Libcore үшін Panic қолдауы
//!
//! Негізгі кітапхана дүрбелеңді анықтай алмайды, бірақ паниканы *жариялайды*.
//! Бұл libcore ішіндегі функцияларға panic рұқсат етілген дегенді білдіреді, бірақ crate ағыны пайдалы болуы үшін libcore қолдану үшін дүрбелеңді анықтауы керек.
//! Паникаға арналған қазіргі интерфейс:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Бұл анықтама кез-келген жалпы хабарламамен үрейленуге мүмкіндік береді, бірақ `Box<Any>` мәнімен сәтсіздікке жол бермейді.
//! (`PanicInfo` құрамында `&(dyn Any + Send)` ғана бар, ол үшін біз «PanicInfo: : internal_constructor» ішіндегі бос мәнді толтырамыз.) Мұның себебі, libcore бөлуге рұқсат етілмеген.
//!
//!
//! Бұл модульде тағы бірнеше дүрбелең функциялары бар, бірақ бұл тек компилятор үшін қажетті тіл элементтері.Барлық panics осы функция арқылы жүзеге асырылады.
//! Нақты белгі `#[panic_handler]` атрибуты арқылы жарияланады.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Пішімдеу қолданылмаған кезде libcore-тің `panic!` макросының негізгі орындалуы.
#[cold]
// қоңыраулар сайттарында мүмкіндігінше көбеюге жол бермеу үшін panic_immediate_abort қоспағанда, ешқашан қатарға кірмеңіз
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // толтыру кезінде panic және басқа `Assert` MIR терминаторлары үшін кодоген қажет
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Үстеме шығындарды азайту үшін format_args орнына Arguments::new_v1 пайдаланыңыз! («{}», Expr).
    // Format_args!макро стрдің Display trait-ті экспр жазу үшін пайдаланады, ол Formatter::pad-ті шақырады, ол жолды кесу мен толтыруды қамтуы керек (бұл жерде ешқайсысы қолданылмаса да)
    //
    // Arguments::new_v1 пайдалану компиляторға Formatter::pad шығатын екілік жүйеден шығарып, бірнеше килобайтқа дейін үнемдеуге мүмкіндік береді.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // бағаланған panics үшін қажет
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice қол жетімділігінде panic үшін codegen қажет
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Пішімдеу кезінде libcore-тің `panic!` макросының негізгі орындалуы қолданылады.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ЕСКЕРТПЕ Бұл функция FFI шекарасынан ешқашан өтпейді;бұл `#[panic_handler]` функциясы шешілетін Rust-Rust қоңырауы.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // ҚАУІПСІЗДІК: `panic_impl` қауіпсіз Rust кодында анықталған, сондықтан қоңырау шалу қауіпсіз.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` және `assert_ne!` макростарына арналған ішкі функция
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}