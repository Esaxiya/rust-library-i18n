#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` тапсырма орындаушысының орындаушысына теңшелген ояту әрекетін қамтамасыз ететін [`Waker`] құруға мүмкіндік береді.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Ол деректер көрсеткішінен және `RawWaker` тәртібін реттейтін [virtual function pointer table (vtable)][vtable]-тен тұрады.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Орындаушының талабы бойынша ерікті деректерді сақтау үшін пайдалануға болатын мәліметтер көрсеткіші.
    /// Бұл мысалы болуы мүмкін
    /// тапсырмаға байланысты `Arc` типті өшірілген көрсеткіш.
    /// Бұл өрістің мәні бірінші параметр ретінде vtable құрамына кіретін барлық функцияларға беріледі.
    ///
    data: *const (),
    /// Осы вейкердің әрекетін реттейтін виртуалды функциялар сілтегіш кестесі.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Берілген `data` көрсеткіші мен `vtable` жаңа `RawWaker` жасайды.
    ///
    /// `data` көрсеткіші орындаушының талабы бойынша ерікті деректерді сақтау үшін қолданыла алады.Бұл мысалы болуы мүмкін
    /// тапсырмаға байланысты `Arc` типті өшірілген көрсеткіш.
    /// Бұл көрсеткіштің мәні бірінші параметр ретінде `vtable` құрамына кіретін барлық функцияларға беріледі.
    ///
    /// `vtable` `RawWaker`-тен жасалынатын `Waker`-тің жұмысын реттейді.
    /// `Waker`-тегі әрбір операция үшін `RawWaker` негізіндегі `vtable`-ге байланысты функция шақырылады.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// [`RawWaker`] тәртібін анықтайтын виртуалды функционалды кесте кестесі (vtable).
///
/// Vtable ішіндегі барлық функцияларға берілген көрсеткіш-[`RawWaker`] қоршауындағы `data` көрсеткіші.
///
/// Бұл құрылымның ішіндегі функциялар [`RawWaker`] іске асырудың ішінен дұрыс салынған [`RawWaker`] нысанының `data` сілтегішіне шақырылуға арналған.
/// Құрамындағы функциялардың біріне кез-келген басқа `data` меңзерінің көмегімен қоңырау шалу анықталмаған мінез-құлықты тудырады.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Бұл функция [`RawWaker`] клондалған кезде, мысалы, [`RawWaker`] сақталатын [`Waker`] клондалған кезде шақырылады.
    ///
    /// Бұл функцияны жүзеге асыру үшін [`RawWaker`] және онымен байланысты тапсырманың қосымша данасы үшін қажет барлық ресурстар сақталуы керек.
    /// Нәтижесінде `wake`-ке қоңырау шалу [`RawWaker`] түпнұсқасы оятар еді, сол тапсырманың оянуына әкелуі керек.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Бұл функция `wake` [`Waker`]-ге шақырылған кезде шақырылады.
    /// Ол осы [`RawWaker`]-пен байланысты тапсырманы оятуы керек.
    ///
    /// Бұл функцияны жүзеге асыру [`RawWaker`] данасымен және онымен байланысты тапсырмамен байланысты кез-келген ресурстарды босатуды қамтамасыз етуі керек.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Бұл функция `wake_by_ref` [`Waker`]-ге шақырылған кезде шақырылады.
    /// Ол осы [`RawWaker`]-пен байланысты тапсырманы оятуы керек.
    ///
    /// Бұл функция `wake`-ге ұқсас, бірақ берілген көрсеткішті тұтынбауы керек.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Бұл функция [`RawWaker`] құлап қалған кезде шақырылады.
    ///
    /// Бұл функцияны жүзеге асыру [`RawWaker`] данасымен және онымен байланысты тапсырмамен байланысты кез-келген ресурстарды босатуды қамтамасыз етуі керек.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Берілген `clone`, `wake`, `wake_by_ref` және `drop` функцияларынан жаңа `RawWakerVTable` жасайды.
    ///
    /// # `clone`
    ///
    /// Бұл функция [`RawWaker`] клондалған кезде, мысалы, [`RawWaker`] сақталатын [`Waker`] клондалған кезде шақырылады.
    ///
    /// Бұл функцияны жүзеге асыру үшін [`RawWaker`] және онымен байланысты тапсырманың қосымша данасы үшін қажет барлық ресурстар сақталуы керек.
    /// Нәтижесінде `wake`-ке қоңырау шалу [`RawWaker`] түпнұсқасы оятар еді, сол тапсырманың оянуына әкелуі керек.
    ///
    /// # `wake`
    ///
    /// Бұл функция `wake` [`Waker`]-ге шақырылған кезде шақырылады.
    /// Ол осы [`RawWaker`]-пен байланысты тапсырманы оятуы керек.
    ///
    /// Бұл функцияны жүзеге асыру [`RawWaker`] данасымен және онымен байланысты тапсырмамен байланысты кез-келген ресурстарды босатуды қамтамасыз етуі керек.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Бұл функция `wake_by_ref` [`Waker`]-ге шақырылған кезде шақырылады.
    /// Ол осы [`RawWaker`]-пен байланысты тапсырманы оятуы керек.
    ///
    /// Бұл функция `wake`-ге ұқсас, бірақ берілген көрсеткішті тұтынбауы керек.
    ///
    /// # `drop`
    ///
    /// Бұл функция [`RawWaker`] құлап қалған кезде шақырылады.
    ///
    /// Бұл функцияны жүзеге асыру [`RawWaker`] данасымен және онымен байланысты тапсырмамен байланысты кез-келген ресурстарды босатуды қамтамасыз етуі керек.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Асинхронды тапсырманың `Context`.
///
/// Қазіргі уақытта `Context` тек ағымдағы тапсырманы ояту үшін қолдануға болатын `&Waker`-ке қол жеткізуді қамтамасыз етеді.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Өмір сүру уақытын инвариантты етуге мәжбүр ете отырып, дисперсияның өзгеруіне қарсы future-ті қамтамасыз етіңіз (аргумент-позицияның өмір сүру уақыты қайшы келеді, ал қайтару позициясының өмірлік уақыты ковариантты).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// `&Waker` құрылғысынан жаңа `Context` жасаңыз.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Ағымдағы тапсырма үшін `Waker` сілтемесін қайтарады.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker`-бұл тапсырманы орындауға дайын екендігі туралы хабарлау арқылы оятуға арналған тұтқа.
///
/// Бұл дескриптор орындаушыға тән ояту әрекетін анықтайтын [`RawWaker`] данасын қамтиды.
///
///
/// [`Clone`], [`Send`] және [`Sync`] іске асырады.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Осы `Waker`-ге байланысты тапсырманы оятыңыз.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Нақты ояту қоңырауы виртуалды функционалды шақыру арқылы орындаушы анықтайтын іске асыруға беріледі.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop`-ге қоңырау шалмаңыз-ракетканы `wake` тұтынады.
        crate::mem::forget(self);

        // ҚАУІПСІЗДІК: бұл қауіпсіз, себебі `Waker::from_raw`-бұл жалғыз жол
        // пайдаланушыдан `RawWaker` келісімшартының сақталғанын мойындауын талап ететін `wake` және `data` инициализациясы.
        //
        unsafe { (wake)(data) };
    }

    /// Осы `Waker`-пен байланысты тапсырманы `Waker` тұтынбай-ақ оятыңыз.
    ///
    /// Бұл `wake`-ге ұқсас, бірақ тиесілі `Waker` болған жағдайда тиімділігі аз болуы мүмкін.
    /// Бұл әдіске `waker.clone().wake()` қоңырауынан гөрі артықшылық беру керек.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Нақты ояту қоңырауы виртуалды функционалды шақыру арқылы орындаушы анықтайтын іске асыруға беріледі.
        //

        // ҚАУІПСІЗДІК: `wake` қараңыз
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Егер `Waker` және басқа `Waker` дәл сол тапсырманы оятқан болса, `true` қайтарады.
    ///
    /// Бұл функция бар күш-жігерді жұмсау негізінде жұмыс істейді және тіпті Waker-дің тапсырмасы оянған кезде де жалған болуы мүмкін.
    /// Алайда, егер бұл функция `true`-ті қайтарса, Waker-дің дәл сол тапсырманы оятуға кепілдік беріледі.
    ///
    /// Бұл функция, ең алдымен, оңтайландыру мақсатында қолданылады.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`]-тен жаңа `Waker` жасайды.
    ///
    /// Егер [RawWaker`] мен [RawWakerVTable`] құжаттамасында анықталған келісімшарт сақталмаса, қайтарылған `Waker`-тің әрекеті анықталмаған.
    ///
    /// Сондықтан бұл әдіс қауіпті.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // ҚАУІПСІЗДІК: бұл қауіпсіз, себебі `Waker::from_raw`-бұл жалғыз жол
            // пайдаланушыдан [`RawWaker`] келісімшартының сақталғанын мойындауын талап ететін `clone` және `data` инициализациясы.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // ҚАУІПСІЗДІК: бұл қауіпсіз, себебі `Waker::from_raw`-бұл жалғыз жол
        // пайдаланушыдан `RawWaker` келісімшартының сақталғанын мойындауын талап ететін `drop` және `data` инициализациясы.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}