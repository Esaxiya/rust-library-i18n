//! Түрлер арасындағы түрлендіруге арналған Traits.
//!
//! Осы модульдегі traits бір түрден екінші түрге түрлендіру әдісін ұсынады.
//! Әр trait әр түрлі мақсатта қызмет етеді:
//!
//! - Анықтамалық сілтемені түрлендіру үшін [`AsRef`] trait-ті қолданыңыз
//! - [`AsMut`] trait-ті арзан өзгеретін-өзгеретін түрлендірулер үшін қолданыңыз
//! - [`From`] trait мәнді мәнге ауыстыруды тұтыну үшін енгізіңіз
//! - Ағымдағы crate-ден тыс түрлерге мәндерден түрлендірулерді тұтыну үшін [`Into`] trait енгізіңіз
//! - [`TryFrom`] және [`TryInto`] traits өздерін [`From`] және [`Into`] сияқты ұстайды, бірақ конверсия сәтсіз болған кезде іске асырылуы керек.
//!
//! Бұл модульдегі traits көбінесе trait bounds ретінде жалпы функциялар үшін қолданылады, мысалы бірнеше типтегі аргументтерге қолдау көрсетіледі.Мысалдар үшін әр trait құжаттамасын қараңыз.
//!
//! Кітапхананың авторы ретінде сіз [`Into<U>`][`Into`] немесе [`TryInto<U>`][`TryInto`]-тен гөрі [`From<T>`][`From`] немесе [`TryFrom<T>`][`TryFrom`]-ті іске асыруды жөн көріңіз, өйткені [`From`] және [`TryFrom`] икемділікті ұсынады және стандартты кітапханаға көрпе енгізудің арқасында [`Into`] немесе [`TryInto`] эквиваленттерін ақысыз ұсынады.
//! Rust 1.41-ге дейінгі нұсқаны бағыттағанда, ағымдағы crate-ден тыс түрге түрлендіру кезінде [`Into`] немесе [`TryInto`]-ті тікелей қолдану қажет болуы мүмкін.
//!
//! # Жалпы іске асыру
//!
//! - [`AsRef`] және ішкі түрі сілтеме болса, [`AsMut`] автоматты түрде ажыратылуы
//! - [`Бастап ']` <U>үшін T`мағынасы [«ішіне»] «</u><T><U>U` үшін</u>
//! - [`TryFrom`]`<U>үшін T` мағынасы [`TryInto`] '</u><T><U>U` үшін</u>
//! - [`From`] және [`Into`] рефлексивті болып табылады, яғни барлық типтер өздерін және `from` өздерін `into` жасай алады
//!
//! Пайдалану мысалдары үшін әр trait қараңыз.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Сәйкестендіру функциясы.
///
/// Бұл функцияға назар аударатын екі нәрсе маңызды:
///
/// - Бұл әрқашан `|x| x` сияқты жабылуға тең емес, өйткені жабу `x`-ны басқа түрге мәжбүр етуі мүмкін.
///
/// - Ол функцияға берілген `x` кірісін жылжытады.
///
/// Кірісті қайтаратын функцияның болуы таңқаларлық көрінуі мүмкін, бірақ кейбір қызықты жерлері бар.
///
///
/// # Examples
///
/// Басқа, қызықты функциялар тізбегінде ештеңе жасамау үшін `identity` пайдалану:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Біреуін қосу қызықты функция деп көрсетейік.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// `identity`-ті "do nothing" негізгі жағдайы ретінде шартты жағдайда пайдалану:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Көбірек қызықты нәрселер жасаңыз ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` итераторының `Some` нұсқаларын сақтау үшін `identity` қолдану:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Анықтамалық сілтемені арзан түрлендіру үшін қолданылады.
///
/// Бұл trait өзгермелі сілтемелер арасында түрлендіру үшін қолданылатын [`AsMut`]-ге ұқсас.
/// Егер сізге қымбат түрлендіру қажет болса, онда `&T` түрімен [`From`] қолданған жөн немесе тапсырыс функциясын жазған жөн.
///
/// `AsRef` [`Borrow`] сияқты бірдей қолтаңбасы бар, бірақ [`Borrow`] бірнеше аспектілері бойынша ерекшеленеді:
///
/// - `AsRef`-тен айырмашылығы, [`Borrow`]-те кез-келген `T` үшін көрпе импл бар, оны сілтеме немесе мән қабылдау үшін пайдалануға болады.
/// - [`Borrow`] сондай-ақ қарызға алынған құн үшін [`Hash`], [`Eq`] және [`Ord`] меншікті құнға баламалы болуын талап етеді.
/// Осы себепті, егер сіз құрылымның жалғыз өрісін ғана алғыңыз келсе, сіз `AsRef` қолдана аласыз, бірақ [`Borrow`] емес.
///
/// **Note: Бұл trait сәтсіздікке ұшырамауы керек **.Егер конверсия сәтсіз болса, [`Option<T>`] немесе [`Result<T, E>`] қайтаратын арнайы әдісті қолданыңыз.
///
/// # Жалпы іске асыру
///
/// - `AsRef` егер ішкі түрі сілтеме немесе өзгертілетін сілтеме болса, автоматты түрде өшіру (мысалы: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds пайдалану арқылы біз әртүрлі типтегі аргументтерді, егер оларды көрсетілген `T` түріне ауыстыра алсақ, қабылдай аламыз.
///
/// Мысалы: `AsRef<str>` қабылдайтын жалпы функцияны құру арқылы біз [`&str`] түрлендіруге болатын барлық сілтемелерді аргумент ретінде қабылдағымыз келетіндігін білдіреміз.
/// [`String`] және [`&str`] екеуі де `AsRef<str>`-ті іске асыратындықтан, екеуін де кіріс аргументі ретінде қабылдай аламыз.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Конверсияны орындайды.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Өзгеретін-өзгеретін арзан сілтемені түрлендіру үшін қолданылады.
///
/// Бұл trait [`AsRef`]-ге ұқсас, бірақ өзгермелі сілтемелер арасында түрлендіру үшін қолданылады.
/// Егер сізге қымбат түрлендіру қажет болса, онда `&mut T` түрімен [`From`] қолданған жөн немесе тапсырыс функциясын жазған жөн.
///
/// **Note: Бұл trait сәтсіздікке ұшырамауы керек **.Егер конверсия сәтсіз болса, [`Option<T>`] немесе [`Result<T, E>`] қайтаратын арнайы әдісті қолданыңыз.
///
/// # Жалпы іске асыру
///
/// - `AsMut` егер ішкі түрі өзгертілетін сілтеме болса, автоматты түрде өшіру (мысалы: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Жалпы функция үшін `AsMut`-ті trait bound ретінде қолданып, біз `&mut T` түріне түрлендіруге болатын барлық өзгермелі сілтемелерді қабылдай аламыз.
/// [`Box<T>`] `AsMut<T>`-ті жүзеге асыратындықтан, біз `&mut u64`-ге түрлендіруге болатын барлық аргументтерді қабылдайтын `add_one` функциясын жаза аламыз.
/// [`Box<T>`] `AsMut<T>`-ті іске асыратындықтан, `add_one` `&mut Box<u64>` типтегі аргументтерді де қабылдайды:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Конверсияны орындайды.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Кіріс мәнін тұтынатын мәннен мәнге түрлендіру.[`From`] керісінше.
///
/// [`Into`]-ті қолданудан аулақ болу керек және оның орнына [`From`]-ті қолдану керек.
/// [`From`]-ті енгізу автоматты түрде стандартты кітапханада көрпенің енгізілуінің арқасында [`Into`]-тің орындалуын қамтамасыз етеді.
///
/// trait bounds-ті жалпы функцияға көрсеткенде, [`Into`]-ті қолданатын типтердің де қолданылуын қамтамасыз ету үшін [`Into`]-ті [`From`]-тен артық көріңіз.
///
/// **Note: Бұл trait сәтсіздікке ұшырамауы керек **.Егер конверсия сәтсіз болса, [`TryInto`] пайдаланыңыз.
///
/// # Жалпы іске асыру
///
/// - [«Бастап»]<T>үшін U` `Into<U> for T` білдіреді
/// - [`Into`] рефлексивті болып табылады, яғни `Into<T> for T` іске асады
///
/// # Rust ескі нұсқаларында сыртқы түрлерге түрлендіруге арналған [`Into`] енгізу
///
/// Rust 1.41 дейін, егер тағайындалған тип қазіргі crate бөлігі болмаса, онда сіз [`From`]-ті тікелей қолдана алмадыңыз.
/// Мысалы, мына кодты алыңыз:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Бұл тілдің ескі нұсқаларында жинақталмайды, өйткені Rust-дің жетім болу ережелері сәл қатал болатын.
/// Мұны айналып өту үшін сіз [`Into`]-ті тікелей қолдана аласыз:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// [`Into`] [`From`] іске асыруын қамтамасыз етпейтінін түсіну маңызды ([`From`] [`Into`] сияқты).
/// Сондықтан, сіз әрқашан [`From`]-ті қолдануға тырысыңыз, содан кейін [`From`] орындалмаса, [`Into`]-ге оралыңыз.
///
/// # Examples
///
/// [`String`] іске асырады [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Жалпы функциялардың көрсетілген `T` түріне түрлендіруге болатын барлық аргументтерді қабылдағанын қалайтындығымызды білдіру үшін [[Into`] «мәніне trait bound қолдана аламыз.<T>«.
///
/// Мысалы: `is_hello` функциясы [`Vec`]`<`[`u8`] `>` түрлендіруге болатын барлық аргументтерді қабылдайды.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Конверсияны орындайды.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Кіріс мәнін тұтыну кезінде мәннен мәнге айырбастау үшін қолданылады.Бұл [`Into`] өзара.
///
/// Әрқашан `From`-ті [`Into`]-тен артық көруді жөн көреді, өйткені `From`-ті стандартты кітапханада көрпеге енгізудің арқасында автоматты түрде [`Into`]-ті ұсынады.
///
///
/// [`Into`]-ті тек Rust 1.41 нұсқасына бағыттаған кезде және ағымдағы crate түрінен тыс түрлендіргенде ғана іске қосыңыз.
/// `From` Rust-тің жетім болу ережелеріне байланысты осы түрлендірулерді бұрынғы нұсқаларында жасай алмады.
/// Толығырақ [`Into`] қараңыз.
///
/// trait bounds-ді жалпы функцияға көрсеткенде [`Into`]-ті `From`-тен гөрі артық көріңіз.
/// Осылайша, [`Into`]-ті тікелей іске асыратын типтерді аргумент ретінде пайдалануға болады.
///
/// `From` қателермен жұмыс істеу кезінде де өте пайдалы.Істен шығуға қабілетті функцияны құру кезінде қайтару түрі әдетте `Result<T, E>` түрінде болады.
/// `From` trait қателіктермен жұмыс істеуді жеңілдетеді, бұл функцияға бірнеше қате типтерін қаптайтын жалғыз қате түрін қайтаруға мүмкіндік береді.Қосымша мәлімет алу үшін "Examples" бөлімін және [the book][book] бөлімін қараңыз.
///
/// **Note: Бұл trait сәтсіздікке ұшырамауы керек **.Егер конверсия сәтсіз болса, [`TryFrom`] пайдаланыңыз.
///
/// # Жалпы іске асыру
///
/// - `From<T> for U` T`<U>үшін</u> [«Into`]» білдіреді
/// - `From` рефлексивті болып табылады, яғни `From<T> for T` іске асады
///
/// # Examples
///
/// [`String`] `From<&str>` іске асырады:
///
/// `&str`-тен String-ке нақты түрлендіру келесідей жүзеге асырылады:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Қателермен жұмыс істеу кезінде `From`-ті өзіңіздің қателіктеріңіз үшін қолдану пайдалы болады.
/// Негізгі қате түрлерін негізгі қателік түрін қамтитын өзіміздің тұтынушылық қателік түріне түрлендіру арқылы біз негізгі себептер туралы ақпаратты жоғалтпай бір қате түрін қайтара аламыз.
/// '?' операторы `From` іске қосылған кезде автоматты түрде ұсынылатын `Into<CliError>::into` қоңырауы арқылы автоматты түрде негізгі қате түрін біздің тұтынушылық қате түріне түрлендіреді.
/// Содан кейін компилятор `Into` қайсысын қолдану керектігін айтады.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Конверсияны орындайды.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// `self` тұтынатын конверсия әрекеті, ол қымбат болуы мүмкін немесе болмауы мүмкін.
///
/// Кітапхана авторлары әдетте бұл trait-ді тікелей қолданбауы керек, бірақ [`TryFrom`] trait-ді қолдануды жөн көруі керек, ол үлкен икемділікті ұсынады және стандартты кітапханаға көрпе енгізудің арқасында `TryInto` эквивалентін тегін ұсынады.
/// Бұл туралы қосымша ақпаратты [`Into`] құжаттамасынан қараңыз.
///
/// # `TryInto` енгізу
///
/// Бұл [`Into`]-ті енгізу сияқты шектеулер мен дәлелдерге ұшырайды, толығырақ сол жерден қараңыз.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Түр түрлендіру кезінде қате болған жағдайда қайтарылды.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Конверсияны орындайды.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Кейбір жағдайларда бақыланатын әдіспен сәтсіздікке ұшырауы мүмкін қарапайым және қауіпсіз түрдегі түрлендірулер.Бұл [`TryInto`] өзара.
///
/// Бұл түрлендіруді жүзеге асырған кезде пайдалы, ол сәтсіз болуы мүмкін, бірақ арнайы өңдеу қажет болуы мүмкін.
/// Мысалы, [`i64`]-ті [`i32`]-ке [`From`] trait түрлендірудің мүмкіндігі жоқ, өйткені [`i64`] құрамында [`i32`] көрсете алмайтын мән болуы мүмкін, сондықтан конверсия деректерді жоғалтады.
///
/// Мұны [`i64`]-ті [`i32`]-ге қысқарту арқылы (мәні [[i64`] мәнін [`i32::MAX`] модулін беру арқылы) немесе [`i32::MAX`]-ті қайтару арқылы немесе басқа әдіспен шешуге болады.
/// [`From`] trait тамаша түрлендіруге арналған, сондықтан `TryFrom` trait программистке типтік түрлендірудің қашан нашарлауы мүмкін екенін хабарлайды және оны қалай өңдеу керектігін шешуге мүмкіндік береді.
///
/// # Жалпы іске асыру
///
/// - `TryFrom<T> for U` T`<U>үшін</u> [`TryInto`]« білдіреді
/// - [`try_from`] рефлексивті болып табылады, яғни `TryFrom<T> for T` іске асады және сәтсіздікке ұшырайды-`T` типіне `T::try_from()` қоңырау шалуға арналған `Error` типі-[`Infallible`].
/// [`!`] түрі тұрақтандырылған кезде [`Infallible`] және [`!`] эквивалентті болады.
///
/// `TryFrom<T>` келесідей жүзеге асырылуы мүмкін:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Сипатталғандай, [`i32`] «TryFrom <`[`i64`]`> `» жүзеге асырады:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // `big_number`-ті үнсіз кесіп тастайды, фактіні анықтағаннан кейін кесуді анықтауды және өңдеуді қажет етеді.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Қате қайтарады, өйткені `big_number` `i32` өлшеміне сыймайтындай үлкен.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` қайтарады.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Түр түрлендіру кезінде қате болған жағдайда қайтарылды.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Конверсияны орындайды.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ЖАЛПЫ АҚПАРАТ
////////////////////////////////////////////////////////////////////////////////

// &Көтеру ретінде
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut-тен жоғары көтергіштер ретінде
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): &/&mut үшін жоғарыдағы имплингтерді келесі жалпыға ауыстырыңыз:
// // Дерефті көтергендей
// импл <D: ?Sized + Deref<Target: AsRef<U>>, U:? Өлшемі> AsRef <U>үшін D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut &mut үстінен көтеріледі
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut үшін жоғарыдағы мағынаны келесі жалпыға ауыстырыңыз:
// // AsMut DerefMut үстінен көтеріледі
// импл <D: ?Sized + Deref<Target: AsMut<U>>, U:? Өлшемі> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Кімнен дегенді білдіреді
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (және осылайша Into) рефлексивті болып табылады
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Тұрақтылық туралы ескерту:** Бұл түсінік әлі жоқ, бірақ біз оны future-ге қосу үшін "reserving space" болып табыламыз.
/// Толығырақ [rust-lang/rust#64715][#64715] қараңыз.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): орнына принципиалды түзету жасаңыз.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom TryInto мағынасын білдіреді
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Жаңылмайтын конверсиялар семантикалық тұрғысынан адамда жоқ қате түріндегі қате түрлендірулерге тең.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// БЕТОНДЫҚ ИМПЛС
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ҚАТЕ ЖОҚ ҚАТЕЛІК ТҮРІ
////////////////////////////////////////////////////////////////////////////////

/// Ешқашан болуы мүмкін емес қателіктер үшін қате түрі.
///
/// Бұл энумның нұсқасы болмағандықтан, бұл типтің мәні ешқашан болмайды.
/// Бұл нәтиже әрқашан [`Ok`] болатындығын көрсету үшін [`Result`] пайдаланатын және қате түрін параметрлейтін жалпы API үшін пайдалы болуы мүмкін.
///
/// Мысалы, [`TryFrom`] trait ([`Result`] қайтаратын конверсия) кері [`Into`] іске асырылуы бар барлық типтер үшін көрпеге арналған.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future үйлесімділігі
///
/// Бұл энум [the `!`“never”type][never] рөлімен бірдей, бұл Rust нұсқасында тұрақсыз.
/// `!` тұрақтандырылған кезде біз оған `Infallible` типтік бүркеншік ат қоюды жоспарлап отырмыз:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Және ақырында `Infallible`-ті қолданыстан шығарады.
///
/// Алайда, `!` синтаксисін `!` толыққанды тип ретінде тұрақтанғанға дейін қолдануға болатын бір жағдай бар: функцияны қайтару типінде.
/// Нақтырақ айтсақ, екі түрлі функционалды нұсқағыш типтерін жүзеге асыруға болады:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` энум болғандықтан, бұл код жарамды.
/// Алайда, `Infallible` never type бүркеншік атына айналған кезде екі `impl`` қабаттаса бастайды, сондықтан тілдің trait когеренттік ережелерімен тыйым салынады.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}