use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Бұл орамның иесі референттің иесі екенін көрсететін шикізат емес `*mut T` айналасындағы орам.
/// `Box<T>`, `Vec<T>`, `String` және `HashMap<K, V>` сияқты абстракцияларды құру үшін пайдалы.
///
/// `*mut T`-тен айырмашылығы, `Unique<T>` "as if"-ті қолданады, бұл `T` данасы.
/// Ол `Send`/`Sync`-ті жүзеге асырады, егер `T` `Send`/`Sync` болса.
/// Бұл сонымен қатар `T` данасының күтуге болатын күшті лақап беру кепілдіктерінің түрін білдіреді:
/// меңзердің референті Unique-ге ие болу үшін бірегей жолсыз өзгертілмеуі керек.
///
/// Егер сіздің мақсатыңыз үшін `Unique` пайдалану дұрыс екендігіне сенімді болмасаңыз, семантикасы әлсіз `NonNull` қолдануды қарастырыңыз.
///
///
/// `*mut T`-тен айырмашылығы, көрсеткіш ешқашан нөлденбесе де, әрдайым нөл болмауы керек.
/// Енумдар осы тыйым салынған мәнді дискриминант ретінде қолдануы үшін қажет-`Option<Unique<T>>` мөлшері `Unique<T>` сияқты.
/// Дегенмен, егер ол анықталмаса, көрсеткіш әлі де сөнуі мүмкін.
///
/// `*mut T`-тен айырмашылығы, `Unique<T>` `T`-ге қарағанда ковариантты.
/// Бұл әрқашан Unique-дің лақап талаптарын қолдайтын кез келген түрге сәйкес келуі керек.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: бұл маркердің дисперсияға салдары болмайды, бірақ қажет
    // біздің `T` логикалық тұрғыдан тиесілі екендігімізді түсіну үшін.
    //
    // Толығырақ ақпаратты қараңыз:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` көрсеткіштер `Send`, егер `T` `Send` болса, өйткені олар сілтеме жасайтын деректер өзгермейді.
/// Бұл лақап инвариант типтік жүйемен орындалмайтынын ескеріңіз;`Unique` көмегімен абстракция оны орындауы керек.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` көрсеткіштер `Sync`, егер `T` `Sync` болса, өйткені олар сілтеме жасайтын деректер өзгермейді.
/// Бұл лақап инвариант типтік жүйемен орындалмайтынын ескеріңіз;`Unique` көмегімен абстракция оны орындауы керек.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Салбырап тұрған, бірақ үйлесімді жаңа `Unique` жасайды.
    ///
    /// Бұл `Vec::new` сияқты жалқау бөлінетін типтерді инициализациялау үшін пайдалы.
    ///
    /// Көрсеткіш мәні `T`-ке дұрыс сілтемені көрсетуі мүмкін екенін ескеріңіз, демек, бұл "not yet initialized" қарауыл мәні ретінде қолданылмауы керек.
    /// Бөлінген түрлер инициализацияны басқа тәсілдермен қадағалап отыруы керек.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // ҚАУІПСІЗДІК: mem::align_of() бос, бос мәнді қайтарады.The
        // осылайша new_unchecked()-ке қоңырау шалу шарттары сақталады.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Жаңа `Unique` жасайды.
    ///
    /// # Safety
    ///
    /// `ptr` нөлдік емес болуы керек.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ҚАУІПСІЗДІК: қоңырау шалушы `ptr`-нің нөлге жатпайтындығына кепілдік беруі керек.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Егер `ptr` нөлсіз болса, жаңа `Unique` жасайды.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ҚАУІПСІЗДІК: Меңзер тексеріліп қойған және нөл емес.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Негізгі `*mut` көрсеткішін алады.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Мазмұнын анықтау.
    ///
    /// Нәтижесінде өмір сүру ұзақтығы өзін-өзі байланыстырады, сондықтан бұл "as if" әрекет етеді, бұл шын мәнінде қарызға алынған T данасы.
    /// Егер ұзағырақ (unbound) қызмет ету мерзімі қажет болса, `&*my_ptr.as_ptr()` пайдаланыңыз.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ҚАУІПСІЗДІК: қоңырау шалушы `self` барлық талаптарға сай екеніне кепілдік беруі керек
        // анықтамаға қойылатын талаптар.
        unsafe { &*self.as_ptr() }
    }

    /// Мазмұнын өзгертеді.
    ///
    /// Нәтижесінде өмір сүру ұзақтығы өзін-өзі байланыстырады, сондықтан бұл "as if" әрекет етеді, бұл шын мәнінде қарызға алынған T данасы.
    /// Егер ұзағырақ (unbound) қызмет ету мерзімі қажет болса, `&mut *my_ptr.as_ptr()` пайдаланыңыз.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ҚАУІПСІЗДІК: қоңырау шалушы `self` барлық талаптарға сай екеніне кепілдік беруі керек
        // өзгермелі анықтамаға қойылатын талаптар.
        unsafe { &mut *self.as_ptr() }
    }

    /// Басқа типтегі көрсеткішке жібереді.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // ҚАУІПСІЗДІК: Unique::new_unchecked() жаңа ерекше қажеттіліктер туғызады
        // берілген көрсеткіш нөл болмауы керек.
        // Біз өзін-өзі көрсеткіш ретінде өткізіп жатқандықтан, ол нөл болмайды.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ҚАУІПСІЗДІК: өзгертілетін сілтеме нөл болмайды
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}