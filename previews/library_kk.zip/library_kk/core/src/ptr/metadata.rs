#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Кез келген бағытталған типтің көрсеткіш метамәліметтерін ұсынады.
///
/// # Көрсеткіштің метадеректері
///
/// Rust-дегі шикі көрсеткіштер мен сілтеме түрлерін екі бөліктен тұрады деп қарастыруға болады:
/// мәннің жад адресін және кейбір метадеректерді қамтитын деректер көрсеткіші.
///
/// Статикалық өлшемді типтер үшін (`Sized` traits іске асырылатын), сондай-ақ `extern` типтері үшін көрсеткіштер «жіңішке» деп аталады: метадеректер нөлдік өлшемді және оның түрі `()`.
///
///
/// [dynamically-sized types][dst] көрсеткіштері «кең» немесе «май» деп аталады, олардың нөлдік емес метадеректері бар:
///
/// * Соңғы өрісі DST болатын құрылымдар үшін метадеректер соңғы өрістің метадеректері болып табылады
/// * `str` типі үшін метадеректер `usize` байттағы ұзындық болып табылады
/// * `[T]` сияқты кесінді түрлері үшін метадеректер-бұл `usize` өлшеміндегі элементтердің ұзындығы
/// * `dyn SomeTrait` сияқты trait нысандары үшін метадеректер [`DynMetadata<Self>`][DynMetadata] (мысалы, `DynMetadata<dyn SomeTrait>`)
///
/// future-де Rust тілі әр түрлі көрсеткіш метадеректері бар жаңа типтерге ие болуы мүмкін.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Осы trait нүктесі оның `Metadata` байланысты типі болып табылады, ол жоғарыда сипатталғандай `()` немесе `usize` немесе `DynMetadata<_>`.
/// Ол әр түрге автоматты түрде енгізіледі.
/// Оны жалпы контексте, тіпті тиісті шекарасыз жүзеге асыруға болады деп қабылдауға болады.
///
/// # Usage
///
/// Шикі көрсеткіштерді олардың [`to_raw_parts`] әдісімен деректер адресі мен метамәліметтер компоненттеріне бөлуге болады.
///
/// Сонымен қатар, метамәліметтерді [`metadata`] функциясының көмегімен шығаруға болады.
/// Анықтаманы [`metadata`]-ке беруге болады және оны мәжбүрлеп мәжбүрлеуге болады.
///
/// (possibly-wide) сілтемесін мекен-жайы мен метадеректерінен [`from_raw_parts`] немесе [`from_raw_parts_mut`] көмегімен біріктіруге болады.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// `Self` сілтемелеріндегі сілтемелер мен сілтемелердегі метадеректер түрі.
    #[lang = "metadata_type"]
    // NOTE: `static_assert_expected_bounds_for_metadata` ішінде trait bounds ұстаңыз
    //
    // `library/core/src/ptr/metadata.rs`-те осындағылармен синхронды:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Осы trait бүркеншік атын қолданатын типтерге бағыттаушылар «жіңішке».
///
/// Оған статикалық-Size типтері және `extern` түрлері жатады.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait бүркеншік аттары тілде тұрақты болғанға дейін оны тұрақтандырмаңыз?
pub trait Thin = Pointee<Metadata = ()>;

/// Көрсеткіштің метамәліметтер компонентін шығарыңыз.
///
/// `*mut T`, `&T` немесе `&mut T` типті мәндерді тікелей осы функцияға беруге болады, өйткені олар `* const T`-ге жанама түрде мәжбүр етеді.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // ҚАУІПСІЗДІК: `PtrRepr` бірігуінен мәнге қол жеткізу * const T кезінен бастап қауіпсіз
    // және PtrComponents<T>бірдей жад орналасуларына ие болыңыз.
    // Бұл кепілдендіруді тек std ғана жасай алады.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Деректер мекен-жайы мен метадеректерден (possibly-wide) шикі көрсеткішін қалыптастырады.
///
/// Бұл функция қауіпсіз, бірақ қайтарылған меңзерді таңдау мүмкін емес.
/// Тіліктер үшін қауіпсіздік талаптарын [`slice::from_raw_parts`] құжаттамасынан қараңыз.
/// trait нысандары үшін метадеректер сілтегіштен сол баяулаған түрге келуі керек.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // ҚАУІПСІЗДІК: `PtrRepr` бірігуінен мәнге қол жеткізу * const T кезінен бастап қауіпсіз
    // және PtrComponents<T>бірдей жад орналасуларына ие болыңыз.
    // Бұл кепілдендіруді тек std ғана жасай алады.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// [`from_raw_parts`] сияқты функционалдылықты орындайды, тек шикі `*mut` сілтемесіне қарағанда шикі `* mut` көрсеткіші қайтарылады.
///
///
/// Толығырақ ақпаратты [`from_raw_parts`] құжаттамасынан қараңыз.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // ҚАУІПСІЗДІК: `PtrRepr` бірігуінен мәнге қол жеткізу * const T кезінен бастап қауіпсіз
    // және PtrComponents<T>бірдей жад орналасуларына ие болыңыз.
    // Бұл кепілдендіруді тек std ғана жасай алады.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` байланысын болдырмау үшін қолмен импл.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` байланысын болдырмау үшін қолмен импл.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait нысаны үшін метадеректер.
///
/// Бұл vtable (виртуалды шақыру кестесі) сілтемесі, ол trait нысаны ішінде сақталған бетон түрімен жұмыс істеу үшін барлық қажетті ақпаратты ұсынады.
/// Құрамында, атап айтқанда:
///
/// * тип өлшемі
/// * типті туралау
/// * түрдегі `drop_in_place` импл-нұсқауыш (қарапайым деректер үшін тыйым салу болуы мүмкін)
/// * trait типін енгізудің барлық әдістеріне нұсқау
///
/// Алғашқы үшеуі ерекше, өйткені олар кез-келген trait нысанын бөлу, түсіру және бөлу үшін қажет.
///
/// Бұл құрылымды `dyn` trait нысаны болып табылмайтын типтік параметрмен атауға болады (мысалы, `DynMetadata<u64>`), бірақ бұл құрылымның мағыналы мәнін алуға болмайды.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Барлық кестелердің ортақ префиксі.Одан кейін trait әдістеріне арналған функционалды көрсеткіштер болады.
///
/// `DynMetadata::size_of` және т.б. енгізудің жеке бөлшектері.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Осы кестеге байланысты типтің өлшемін қайтарады.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Осы кестеге байланысты типтің туралануын қайтарады.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Өлшем мен туралауды `Layout` ретінде қайтарады
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // ҚАУІПСІЗДІК: компилятор бұл столды Rust бетон түріне шығарды
        // дұрыс орналасуы бар екені белгілі.`Layout::for_value`-тегідей негіздеме.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` шекараларын болдырмау үшін қолмен импл.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}