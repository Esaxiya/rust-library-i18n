use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` бірақ нөлдік емес және ковариантты.
///
/// Бұл шикізаттық көрсеткіштерді қолданатын деректер құрылымын құру кезінде жиі дұрыс қолданылады, бірақ оның қосымша қасиеттеріне байланысты пайдалану өте қауіпті.Егер сіз `NonNull<T>` пайдалану керек екеніне сенімді болмасаңыз, онда `*mut T` қолданыңыз!
///
/// `*mut T`-тен айырмашылығы, көрсеткіш ешқашан нөлденбесе де, әрдайым нөл болмауы керек.Енумдар осы тыйым салынған мәнді дискриминант ретінде қолдануы үшін қажет-`Option<NonNull<T>>` өлшемі `* mut T` сияқты.
/// Дегенмен, егер ол анықталмаса, көрсеткіш әлі де сөнуі мүмкін.
///
/// `*mut T`-тен айырмашылығы, `NonNull<T>` `T`-тен ковариантты болып таңдалды.Бұл ковариант типтерін құру кезінде `NonNull<T>` қолдануға мүмкіндік береді, бірақ егер ол шын мәнінде ковариант болмауы керек типте қолданылса, негізсіздік қаупін тудырады.
/// (Қарама-қарсы таңдау `*mut T` үшін жасалды, дегенмен техникалық тұрғыдан қауіпті функцияларға тек қауіпті функцияларды шақыру себеп болуы мүмкін.)
///
/// Коварианс `Box`, `Rc`, `Arc`, `Vec` және `LinkedList` сияқты қауіпсіз абстракциялар үшін дұрыс.Бұл жағдай Rust-тің әдеттегі ортақ XOR өзгермелі ережелерін сақтайтын жалпыға ортақ API ұсынады.
///
/// Егер сіздің түріңіз қауіпсіз түрде ковариантты бола алмаса, онда оның өзгермейтіндігін қамтамасыз ететін қосымша өріс бар екеніне көз жеткізуіңіз керек.Көбіне бұл өріс `PhantomData<Cell<T>>` немесе `PhantomData<&'a mut T>` сияқты [`PhantomData`] болады.
///
/// `NonNull<T>`-те `&T` үшін `From` данасы бар екеніне назар аударыңыз.Алайда, бұл (а сілтемесінен алынған) ортақ сілтеме арқылы мутацияның анықталмаған әрекеті болып табылады, егер мутация [`UnsafeCell<T>`] ішінде болмаса.Ортақ сілтемеден өзгертілетін сілтеме жасау үшін де солай болады.
///
/// Бұл `From` данасын `UnsafeCell<T>`-ті қолданбаған кезде, сізде `as_mut` ешқашан шақырылмайтындығына және `as_ptr`-тің мутация үшін ешқашан пайдаланылмайтындығына көз жеткізесіз.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` көрсеткіштер `Send` емес, өйткені олар сілтеме жасайтын деректер бүркеншік аттауы мүмкін.
// Бұл ескерту қажет емес, бірақ қате туралы жақсы хабарламалар беруі керек.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` көрсеткіштер `Sync` емес, өйткені олар сілтеме жасайтын деректер бүркеншік аттауы мүмкін.
// Бұл ескерту қажет емес, бірақ қате туралы жақсы хабарламалар беруі керек.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Салбырап тұрған, бірақ үйлесімді жаңа `NonNull` жасайды.
    ///
    /// Бұл `Vec::new` сияқты жалқау бөлінетін типтерді инициализациялау үшін пайдалы.
    ///
    /// Көрсеткіш мәні `T`-ке дұрыс сілтемені көрсетуі мүмкін екенін ескеріңіз, демек, бұл "not yet initialized" қарауыл мәні ретінде қолданылмауы керек.
    /// Бөлінген түрлер инициализацияны басқа тәсілдермен қадағалап отыруы керек.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // ҚАУІПСІЗДІК: mem::align_of() нөлдік емес пайдалануды қайтарады, содан кейін ол құйылады
        // а * mut Т.
        // Сондықтан `ptr` нөл емес және new_unchecked() қоңырауының шарттары сақталады.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Мәнге ортақ сілтемелерді қайтарады.[`as_ref`]-тен айырмашылығы, бұл мәнді инициализациялауды талап етпейді.
    ///
    /// Өзгеретін аналог үшін [`as_uninit_mut`] қараңыз.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Бұл әдісті шақырған кезде, сіз төмендегілердің барлығының дұрыс екендігіне көз жеткізіңіз:
    ///
    /// * Меңзер дұрыс тураланған болуы керек.
    ///
    /// * Ол [the module documentation] анықталған мағынада "dereferencable" болуы керек.
    ///
    /// * Сіз Rust-нің бүркеншік ережелерін сақтауыңыз керек, өйткені қайтарылған өмір сүру мерзімі `'a` ерікті түрде таңдалады және деректердің нақты қызмет ету мерзімін көрсетпейді.
    ///
    ///   Атап айтқанда, осы өмір бойына көрсеткіштің көрсеткен жады мутацияға ұшырамауы керек (`UnsafeCell` ішінен басқа).
    ///
    /// Бұл осы әдістің нәтижесі қолданылмаған жағдайда да қолданылады!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // ҚАУІПСІЗДІК: қоңырау шалушы `self` барлық талаптарға сай екеніне кепілдік беруі керек
        // анықтамаға қойылатын талаптар.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Мәнге бірегей сілтемелерді қайтарады.[`as_mut`]-тен айырмашылығы, бұл мәнді инициализациялауды талап етпейді.
    ///
    /// Ортақ әріптес үшін [`as_uninit_ref`] қараңыз.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Бұл әдісті шақырған кезде, сіз төмендегілердің барлығының дұрыс екендігіне көз жеткізіңіз:
    ///
    /// * Меңзер дұрыс тураланған болуы керек.
    ///
    /// * Ол [the module documentation] анықталған мағынада "dereferencable" болуы керек.
    ///
    /// * Сіз Rust-нің бүркеншік ережелерін сақтауыңыз керек, өйткені қайтарылған өмір сүру мерзімі `'a` ерікті түрде таңдалады және деректердің нақты қызмет ету мерзімін көрсетпейді.
    ///
    ///   Атап айтқанда, осы өмір бойына көрсеткіштің көрсеткен жадына басқа көрсеткіштер арқылы қол жетімді болмауы керек (оқылмайды немесе жазылмайды).
    ///
    /// Бұл осы әдістің нәтижесі қолданылмаған жағдайда да қолданылады!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // ҚАУІПСІЗДІК: қоңырау шалушы `self` барлық талаптарға сай екеніне кепілдік беруі керек
        // анықтамаға қойылатын талаптар.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Жаңа `NonNull` жасайды.
    ///
    /// # Safety
    ///
    /// `ptr` нөлдік емес болуы керек.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ҚАУІПСІЗДІК: қоңырау шалушы `ptr`-нің нөлге жатпайтындығына кепілдік беруі керек.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Егер `ptr` нөлсіз болса, жаңа `NonNull` жасайды.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ҚАУІПСІЗДІК: Меңзер тексеріліп қойған және нөл емес
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// [`std::ptr::from_raw_parts`] сияқты функционалдылықты орындайды, тек `NonNull` көрсеткіші шикі `*const` көрсеткішіне қарағанда қайтарылады.
    ///
    ///
    /// Толығырақ ақпаратты [`std::ptr::from_raw_parts`] құжаттамасынан қараңыз.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // ҚАУІПСІЗДІК: `ptr::from::raw_parts_mut` нәтижесі нөл емес, өйткені `data_address` мәні.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Көрсеткіні адрес және метамәліметтер компоненттеріне бөлу (мүмкін кең) болуы мүмкін.
    ///
    /// Кейінірек көрсеткішті [`NonNull::from_raw_parts`] көмегімен қалпына келтіруге болады.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Негізгі `*mut` көрсеткішін алады.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Мәнге ортақ сілтемені қайтарады.Егер мән инициализацияланбаған болса, оның орнына [`as_uninit_ref`] қолданылуы керек.
    ///
    /// Өзгеретін аналог үшін [`as_mut`] қараңыз.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Бұл әдісті шақырған кезде, сіз төмендегілердің барлығының дұрыс екендігіне көз жеткізіңіз:
    ///
    /// * Меңзер дұрыс тураланған болуы керек.
    ///
    /// * Ол [the module documentation] анықталған мағынада "dereferencable" болуы керек.
    ///
    /// * Меңзер `T` инициализацияланған данасын көрсетуі керек.
    ///
    /// * Сіз Rust-нің бүркеншік ережелерін сақтауыңыз керек, өйткені қайтарылған өмір сүру мерзімі `'a` ерікті түрде таңдалады және деректердің нақты қызмет ету мерзімін көрсетпейді.
    ///
    ///   Атап айтқанда, осы өмір бойына көрсеткіштің көрсеткен жады мутацияға ұшырамауы керек (`UnsafeCell` ішінен басқа).
    ///
    /// Бұл осы әдістің нәтижесі қолданылмаған жағдайда да қолданылады!
    /// (Инициализациялау бөлігі әлі толық шешілмеген, бірақ ол болғанға дейін жалғыз қауіпсіз тәсіл-олардың шынымен инициализацияланғандығына көз жеткізу.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ҚАУІПСІЗДІК: қоңырау шалушы `self` барлық талаптарға сай екеніне кепілдік беруі керек
        // анықтамаға қойылатын талаптар.
        unsafe { &*self.as_ptr() }
    }

    /// Мәнге бірегей сілтемені қайтарады.Егер мән инициализацияланбаған болса, оның орнына [`as_uninit_mut`] қолданылуы керек.
    ///
    /// Ортақ әріптес үшін [`as_ref`] қараңыз.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Бұл әдісті шақырған кезде, сіз төмендегілердің барлығының дұрыс екендігіне көз жеткізіңіз:
    ///
    /// * Меңзер дұрыс тураланған болуы керек.
    ///
    /// * Ол [the module documentation] анықталған мағынада "dereferencable" болуы керек.
    ///
    /// * Меңзер `T` инициализацияланған данасын көрсетуі керек.
    ///
    /// * Сіз Rust-нің бүркеншік ережелерін сақтауыңыз керек, өйткені қайтарылған өмір сүру мерзімі `'a` ерікті түрде таңдалады және деректердің нақты қызмет ету мерзімін көрсетпейді.
    ///
    ///   Атап айтқанда, осы өмір бойына көрсеткіштің көрсеткен жадына басқа көрсеткіштер арқылы қол жетімді болмауы керек (оқылмайды немесе жазылмайды).
    ///
    /// Бұл осы әдістің нәтижесі қолданылмаған жағдайда да қолданылады!
    /// (Инициализациялау бөлігі әлі толық шешілмеген, бірақ ол болғанға дейін жалғыз қауіпсіз тәсіл-олардың шынымен инициализацияланғандығына көз жеткізу.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ҚАУІПСІЗДІК: қоңырау шалушы `self` барлық талаптарға сай екеніне кепілдік беруі керек
        // өзгермелі анықтамаға қойылатын талаптар.
        unsafe { &mut *self.as_ptr() }
    }

    /// Басқа типтегі көрсеткішке жібереді.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // ҚАУІПСІЗДІК: `self`-бұл нөлге жатпайтын `NonNull` көрсеткіші
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Жіңішке көрсеткіштен және ұзындықтан нөлдік шикі кесінді жасайды.
    ///
    /// `len` аргументі-бұл байт саны емес,**элементтер саны**.
    ///
    /// Бұл функция қауіпсіз, бірақ қайтарылатын мәнді анықтау қауіпті.
    /// Бөлшектердің қауіпсіздігі үшін [`slice::from_raw_parts`] құжаттамасын қараңыз.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // бірінші элементтің көрсеткішімен бастағанда тілім көрсеткішін жасаңыз
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Бұл мысал осы әдісті қолдан жасанды түрде көрсететініне назар аударыңыз, бірақ `тілім= NonNull::from(&x[..]);` would be a better way to write code like this.) болсын
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // ҚАУІПСІЗДІК: `data`-бұл нөлге жатпайтын `NonNull` көрсеткіші
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Бос емес шикі кесінді ұзындығын қайтарады.
    ///
    /// Қайтарылған мән-бұл байт саны емес,**элементтер саны**.
    ///
    /// Бұл функция қауіпсіз, тіпті бос емес шикі тілімді тілімге беру мүмкін болмаған жағдайда да, егер сілтегіштің мекен-жайы дұрыс болмаса.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Бөлшектің буферіне нөлдік көрсеткішті қайтарады.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // ҚАУІПСІЗДІК: Біз `self`-тің нөлдік емес екенін білеміз.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Шикі көрсеткішті тілімнің буферіне қайтарады.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Мүмкін инициализацияланбаған мәндер тіліміне ортақ сілтемені қайтарады.[`as_ref`]-тен айырмашылығы, бұл мәнді инициализациялауды талап етпейді.
    ///
    /// Өзгеретін аналог үшін [`as_uninit_slice_mut`] қараңыз.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Бұл әдісті шақырған кезде, сіз төмендегілердің барлығының дұрыс екендігіне көз жеткізіңіз:
    ///
    /// * Көрсеткіш `ptr.len() * mem::size_of::<T>()` көп байт үшін оқу үшін [valid] болуы керек және ол дұрыс туралануы керек.Бұл, атап айтқанда:
    ///
    ///     * Бұл тілімнің барлық жад ауқымы бір бөлінген объектіде қамтылуы керек!
    ///       Бөлшектер ешқашан бірнеше бөлінген нысандарға ене алмайды.
    ///
    ///     * Көрсеткіш нөлдік ұзындықтағы кесінділер үшін де туралануы керек.
    ///     Мұның бір себебі, максимум макетін оңтайландыру сілтемелерге (кез-келген ұзындықтағы кесінділерді қоса) тураланған және нөлден басқа, оларды басқа деректерден ажырата алады.
    ///
    ///     [`NonNull::dangling()`] көмегімен нөлдік ұзындықтағы кесінділер үшін `data` ретінде қолдануға болатын нұсқағышты алуға болады.
    ///
    /// * Тіліктің `ptr.len() * mem::size_of::<T>()` жалпы мөлшері `isize::MAX`-тен үлкен болмауы керек.
    ///   [`pointer::offset`] қауіпсіздік құжаттамасын қараңыз.
    ///
    /// * Сіз Rust-нің бүркеншік ережелерін сақтауыңыз керек, өйткені қайтарылған өмір сүру мерзімі `'a` ерікті түрде таңдалады және деректердің нақты қызмет ету мерзімін көрсетпейді.
    ///   Атап айтқанда, осы өмір бойына көрсеткіштің көрсеткен жады мутацияға ұшырамауы керек (`UnsafeCell` ішінен басқа).
    ///
    /// Бұл осы әдістің нәтижесі қолданылмаған жағдайда да қолданылады!
    ///
    /// Сондай-ақ, [`slice::from_raw_parts`] қараңыз.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // ҚАУІПСІЗДІК: қоңырау шалушы `as_uninit_slice` қауіпсіздік шартын сақтауы керек.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Мүмкін инициализацияланбаған мәндер тіліміне бірегей сілтемені қайтарады.[`as_mut`]-тен айырмашылығы, бұл мәнді инициализациялауды талап етпейді.
    ///
    /// Ортақ әріптес үшін [`as_uninit_slice`] қараңыз.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Бұл әдісті шақырған кезде, сіз төмендегілердің барлығының дұрыс екендігіне көз жеткізіңіз:
    ///
    /// * Көрсеткіш `ptr.len() * mem::size_of::<T>()` көптеген байттарды оқу және жазу үшін [valid] болуы керек және ол дұрыс тураланған болуы керек.Бұл, атап айтқанда:
    ///
    ///     * Бұл тілімнің барлық жад ауқымы бір бөлінген объектіде қамтылуы керек!
    ///       Бөлшектер ешқашан бірнеше бөлінген нысандарға ене алмайды.
    ///
    ///     * Көрсеткіш нөлдік ұзындықтағы кесінділер үшін де туралануы керек.
    ///     Мұның бір себебі, максимум макетін оңтайландыру сілтемелерге (кез-келген ұзындықтағы кесінділерді қоса) тураланған және нөлден басқа, оларды басқа деректерден ажырата алады.
    ///
    ///     [`NonNull::dangling()`] көмегімен нөлдік ұзындықтағы кесінділер үшін `data` ретінде қолдануға болатын нұсқағышты алуға болады.
    ///
    /// * Тіліктің `ptr.len() * mem::size_of::<T>()` жалпы мөлшері `isize::MAX`-тен үлкен болмауы керек.
    ///   [`pointer::offset`] қауіпсіздік құжаттамасын қараңыз.
    ///
    /// * Сіз Rust-нің бүркеншік ережелерін сақтауыңыз керек, өйткені қайтарылған өмір сүру мерзімі `'a` ерікті түрде таңдалады және деректердің нақты қызмет ету мерзімін көрсетпейді.
    ///   Атап айтқанда, осы өмір бойына көрсеткіштің көрсеткен жадына басқа көрсеткіштер арқылы қол жетімді болмауы керек (оқылмайды немесе жазылмайды).
    ///
    /// Бұл осы әдістің нәтижесі қолданылмаған жағдайда да қолданылады!
    ///
    /// Сондай-ақ, [`slice::from_raw_parts_mut`] қараңыз.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Бұл қауіпсіз, өйткені `memory` көптеген байттарды оқуға және жазуға жарамды.
    /// // Мұнда `memory.as_mut()` қоңырауына жол берілмейтінін ескеріңіз, себебі мазмұн инициализацияланбаған болуы мүмкін.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // ҚАУІПСІЗДІК: қоңырау шалушы `as_uninit_slice_mut` қауіпсіздік шартын сақтауы керек.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Шикі сілтемені шекараны тексермей, элементке немесе подпликаға қайтарады.
    ///
    /// Бұл әдісті шекарадан тыс индекспен немесе `self` анықталмаған кезде шақыру *[анықталмаған мінез-құлық]*, тіпті егер нәтиже көрсеткіші қолданылмаса да.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // ҚАУІПСІЗДІК: қоңырау шалушы `self`-дің анықталуы және `index` шекарасында болуын қамтамасыз етеді.
        // Нәтижесінде, нәтиже көрсеткіші NULL бола алмайды.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // ҚАУІПСІЗДІК: Бірегей көрсеткішті нөл деп айтуға болмайды, сондықтан шарттар
        // new_unchecked() құрметке ие.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ҚАУІПСІЗДІК: өзгертілетін сілтеме нөл болмайды.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // ҚАУІПСІЗДІК: Анықтама нөлдік бола алмайды, сондықтан шарттар
        // new_unchecked() құрметке ие.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}