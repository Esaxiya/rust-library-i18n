//! prelude
//!
//! Бұл модуль libcore қолданушыларына арналған, олар libstd-ге сілтеме жасамайды.
//! Бұл модуль стандартты кітапхана prelude сияқты `#![no_std]` пайдаланылған кезде әдепкі бойынша импортталады.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// prelude ядросының 2015 жылғы нұсқасы.
///
/// Толығырақ [module-level documentation](self) қараңыз.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// prelude ядросының 2018 нұсқасы.
///
/// Толығырақ [module-level documentation](self) қараңыз.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// prelude өзегінің 2021 нұсқасы.
///
/// Толығырақ [module-level documentation](self) қараңыз.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Тағы заттарды қосыңыз.
}