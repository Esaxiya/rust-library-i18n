use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` инициализацияланбаған даналарын құруға арналған орағыш тип.
///
/// # Инициализация инвариантты
///
/// Жалпы алғанда, компилятор айнымалының түріне сәйкес өзгермелі инициализацияланған деп болжайды.Мысалы, анықтамалық типтің айнымалысы тураланған және NULL болмауы керек.
/// Бұл инвариант, оны *әрдайым* сақтау қажет, тіпті қауіпті кодта.
/// Нәтижесінде сілтеме түріндегі айнымалыны нөлдік инициализациялау жедел [undefined behavior][ub]-ті тудырады, бұл сілтеме жадқа қол жеткізуге үйреніп алғанына қарамастан:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // анықталмаған мінез-құлық!⚠️
/// // `MaybeUninit<&i32>` бар баламалы код:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // анықталмаған мінез-құлық!⚠️
/// ```
///
/// Мұны компилятор әр түрлі оңтайландыру үшін пайдаланады, мысалы, жұмыс уақытын тексеруді және `enum` орналасуын оңтайландыруды.
///
/// Сол сияқты, толығымен инициализацияланбаған жадта кез-келген мазмұн болуы мүмкін, ал `bool` әрқашан `true` немесе `false` болуы керек.Демек, инициализацияланбаған `bool` құру анықталмаған әрекет болып табылады:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // анықталмаған мінез-құлық!⚠️
/// // `MaybeUninit<bool>` бар баламалы код:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // анықталмаған мінез-құлық!⚠️
/// ```
///
/// Сонымен қатар, инициализацияланбаған жадтың тұрақты мәні жоқ болуымен ерекше ("fixed" "it won't change without being written to" мағынасын білдіреді).Бір инициализацияланбаған байтты бірнеше рет оқу әр түрлі нәтиже беруі мүмкін.
/// Бұл айнымалыда инициализацияланбаған деректердің болуы анықталмаған мінез-құлыққа айналады, тіпті егер бұл айнымалыда бүтін тип болса, әйтпесе кез-келген *бекітілген* биттік үлгіні ұстай алады:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // анықталмаған мінез-құлық!⚠️
/// // `MaybeUninit<i32>` бар баламалы код:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // анықталмаған мінез-құлық!⚠️
/// ```
/// (Инициализацияланбаған бүтін сандар туралы ережелер әлі аяқталмағанына назар аударыңыз, бірақ олар болғанға дейін олардан аулақ болған жөн).
///
/// Сонымен қатар, типтердің көпшілігінде тек тип деңгейінде инициализацияланған деп есептелмейтін қосымша инварианттар бар екенін ұмытпаңыз.
/// Мысалы, `1`-инициализацияланған [`Vec<T>`] инициализацияланған болып саналады (ағымдағы іске асыруда; бұл тұрақты кепілдікке жатпайды), өйткені компилятордың білетін жалғыз талабы-бұл деректер көрсеткіші нөл болмауы керек.
/// Мұндай `Vec<T>` жасау *жедел* анықталмаған мінез-құлықты туғызбайды, бірақ қауіпсіз операциялардың көпшілігінде анықталмаған мінез-құлықты тудырады (оны тастаумен қоса).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` қауіпсіз емес кодты инициализацияланбаған деректермен жұмыс істеуге мүмкіндік береді.
/// Бұл компиляторға берілгендер *инициализацияланбағанын* көрсететін сигнал:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Анықталмаған сілтеме жасаңыз.
/// // Компилятор `MaybeUninit<T>` ішіндегі мәліметтер жарамсыз болуы мүмкін екенін біледі, демек бұл UB емес:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Оны дұрыс мәнге қойыңыз.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Бастапқы деректерді шығарып алыңыз-бұған `x` дұрыс инициализациялағаннан кейін * рұқсат етіледі!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Содан кейін компилятор осы код бойынша ешқандай қате болжамдар немесе оңтайландырулар жасамауды біледі.
///
/// Сіз `MaybeUninit<T>`-ті `Option<T>`-ге ұқсас деп ойлай аласыз, бірақ жұмыс уақытының кез-келгенін қадағаламай және қауіпсіздік тексерулерінсіз.
///
/// ## out-pointers
///
/// "out-pointers"-ті іске асыру үшін сіз `MaybeUninit<T>` қолдана аласыз: функциядан деректерді қайтарудың орнына, нәтижені енгізу үшін оны (uninitialized) жадына көрсеткішті жіберіңіз.
/// Бұл қоңырау шалушы үшін жадтың қалай сақталатынын бақылау маңызды болған кезде пайдалы болуы мүмкін және қажетсіз қадамдардан аулақ болғыңыз келеді.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ескі мазмұнды түсірмейді, бұл маңызды.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Енді біз `v` инициализацияланғанын білеміз!Бұл vector-дің дұрыс түсіп кетуіне көз жеткізеді.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Массивтің элементтерін инициализациялау
///
/// `MaybeUninit<T>` массивтің элементтерін инициализациялау үшін қолдануға болады:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` инициализацияланбаған массивін жасаңыз.
///     // `assume_init` қауіпсіз болып табылады, өйткені біз бұл жерде инициализацияладық деп ұйғарып отырған түр-инициализацияны қажет етпейтін «MaybeUninit» топтамасы.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit`-ті құлату ештеңе жасамайды.
///     // Осылайша, `ptr::write` орнына шикі көрсеткіш тағайындауды қолдану ескі инициализацияланбаған мәннің түсуіне әкелмейді.
/////
///     // Сондай-ақ, егер осы цикл кезінде panic болса, бізде жадтың ағуы бар, бірақ жад қауіпсіздігінде ешқандай мәселе жоқ.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Барлығы баптандырылған.
///     // Массивті инициализацияланған түрге ауыстырыңыз.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Сіз сондай-ақ жартылай инициализацияланған массивтермен жұмыс жасай аласыз, оларды төменгі деңгейлі құрылымдарда табуға болады.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` инициализацияланбаған массивін жасаңыз.
/// // `assume_init` қауіпсіз болып табылады, өйткені біз бұл жерде инициализацияладық деп ұйғарып отырған түр-инициализацияны қажет етпейтін «MaybeUninit» топтамасы.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Біз тағайындаған элементтердің санын санаңыз.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Массивтің әр элементіне, егер біз оны бөліп алсақ, тастаңыз.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Өрістер бойынша құрылымды инициализациялау
///
/// Өрістер бойынша өрістерді инициализациялау үшін `MaybeUninit<T>` және [`std::ptr::addr_of_mut`] макросын пайдалануға болады:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` өрісін инициализациялау
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` өрісін инициализациялау Егер мұнда panic болса, онда `name` өрісіндегі `String` ағып кетеді.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Барлық өрістер инициализацияланған, сондықтан біз инициалданған Foo алу үшін `assume_init` телефонына қоңырау шаламыз.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` өлшемімен, туралануымен және ABI-мен бірдей кепілдендірілген:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Бірақ *құрамында `MaybeUninit<T>` бар* типтің бірдей орналасуы емес екенін ұмытпаңыз;Rust жалпы алғанда `Foo<T>` өрістерінің `Foo<U>` сияқты ретіне ие екеніне кепілдік бермейді, тіпті егер `T` пен `U` өлшемдері мен тураланулары бірдей болса.
///
/// Сонымен қатар кез-келген бит мәні `MaybeUninit<T>` үшін жарамды болғандықтан, компилятор non-zero/niche-filling оңтайландыруларын қолдана алмайды, бұл үлкен өлшемге әкелуі мүмкін:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Егер `T` FFI қауіпсіз болса, онда `MaybeUninit<T>` да қауіпсіз болады.
///
/// `MaybeUninit`-`#[repr(transparent)]` (бұл `T` сияқты өлшемге, туралауға және ABI-ге кепілдік беретіндігін көрсете отырып), бұл алдыңғы ескертулердің ешқайсысын *өзгертпейді*.
/// `Option<T>` және `Option<MaybeUninit<T>>` әр түрлі өлшемдерге ие болуы мүмкін, және `T` типті өрісті қамтитын типтер, егер бұл өріс `MaybeUninit<T>` болғаннан басқаша орналасуы (және өлшемі) болуы мүмкін.
/// `MaybeUninit` бұл кәсіподақ түрі, ал кәсіподақтардағы `#[repr(transparent)]` тұрақсыз ([the tracking issue](https://github.com/rust-lang/rust/issues/60405)) қараңыз).
/// Уақыт өте келе `#[repr(transparent)]`-тің кәсіподақтардағы нақты кепілдіктері өзгеруі мүмкін, ал `MaybeUninit` `#[repr(transparent)]` болып қалуы да мүмкін.
/// Сонымен, `MaybeUninit<T>` мөлшері, туралануы және ABI-нің `T` сияқты болатындығына әрдайым * кепілдік береді;бұл `MaybeUninit`-ті қолдану тәсілі өзгеруі мүмкін.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Басқа түрлерін орауға болатындай етіп, зат түрін салыңыз.Бұл генераторлар үшін пайдалы.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()`-ке қоңырау шалмай, біз бұл үшін жеткілікті инициализацияланған-жатпағанымызды біле алмаймыз.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Берілген мәнмен инициализацияланған жаңа `MaybeUninit<T>` жасайды.
    /// Бұл функцияны қайтару мәні бойынша [`assume_init`]-ге қоңырау шалу қауіпсіз.
    ///
    /// Назар аударыңыз, `MaybeUninit<T>`-ті түсіру ешқашан T-дің кодын шақырмайды.
    /// `T` инициализацияланған болса, оның құлап кетуіне көз жеткізу сіздің міндетіңіз.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Инициализацияланбаған күйінде жаңа `MaybeUninit<T>` жасайды.
    ///
    /// Назар аударыңыз, `MaybeUninit<T>`-ті түсіру ешқашан T-дің кодын шақырмайды.
    /// `T` инициализацияланған болса, оның құлап кетуіне көз жеткізу сіздің міндетіңіз.
    ///
    /// Кейбір мысалдар үшін [type-level documentation][MaybeUninit] қараңыз.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Инициализацияланбаған күйде `MaybeUninit<T>` элементтерінің жаңа массивін жасаңыз.
    ///
    /// Note: future Rust нұсқасында массивтің әріптік синтаксисі [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) мүмкіндік берген кезде бұл әдіс қажет болмауы мүмкін.
    ///
    /// Төмендегі мысалда `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` қолданылуы мүмкін.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Шын мәнінде оқылған (мүмкін кішірек) деректер бөлігін қайтарады
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // ҚАУІПСІЗДІК: инициализацияланбаған `[MaybeUninit<_>; LEN]` жарамды.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Жады `0` байтпен толтырылған, инициализацияланбаған күйде жаңа `MaybeUninit<T>` жасайды.Бұл `T`-ге байланысты, ол дұрыс инициализация жасай ма.
    ///
    /// Мысалы, `MaybeUninit<usize>::zeroed()` инициализацияланған, бірақ `MaybeUninit<&'static i32>::zeroed()` емес, себебі сілтемелер нөл болмауы керек.
    ///
    /// Назар аударыңыз, `MaybeUninit<T>`-ті түсіру ешқашан T-дің кодын шақырмайды.
    /// `T` инициализацияланған болса, оның құлап кетуіне көз жеткізу сіздің міндетіңіз.
    ///
    /// # Example
    ///
    /// Осы функцияны дұрыс қолдану: құрылымды нөлге теңестіру, мұндағы құрылымның барлық өрістері биттің өрнегін 0 жарамды мән ретінде ұстай алады.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Дұрыс емес* осы функцияны қолдану: `0` тип үшін жарамды бит үлгісі болмаған кезде `x.zeroed().assume_init()` шақыру:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Жұптың ішінде біз жарамды дискриминанты жоқ `NotZero` жасаймыз.
    /// // Бұл анықталмаған тәртіп.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // ҚАУІПСІЗДІК: `u.as_mut_ptr()` бөлінген жадқа нұсқайды.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` мәнін орнатады.
    /// Бұл кез келген алдыңғы мәнді түсірмей жазады, сондықтан деструкторды өткізіп жіберуді қаламасаңыз, мұны екі рет пайдаланбаңыз.
    ///
    /// Сізге ыңғайлы болу үшін, бұл `self` мазмұнына (қазір қауіпсіз инициалданған) өзгертілетін сілтеме береді.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // ҚАУІПСІЗДІК: біз бұл мәнді жаңа бастадық.
        unsafe { self.assume_init_mut() }
    }

    /// Құрамындағы мәнге көрсеткішті алады.
    /// Осы көрсеткіштен оқу немесе оны сілтемеге айналдыру, егер `MaybeUninit<T>` инициализациясы болмаса, анықталмаған әрекет болып табылады.
    /// Осы көрсеткіш (non-transitively) көрсеткен жадқа жазу-бұл анықталмаған әрекет (`UnsafeCell<T>` ішінен басқа).
    ///
    /// # Examples
    ///
    /// Осы әдісті дұрыс қолдану:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>`-ке сілтеме жасаңыз.Бұл жақсы, өйткені біз оны баптандырдық.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Бұл әдісті *дұрыс емес* қолдану:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Біз инициализацияланбаған vector сілтемесін жасадық!Бұл анықталмаған тәртіп.⚠️
    /// ```
    ///
    /// (Инициализацияланбаған деректерге сілтемелер туралы ережелер әлі аяқталмағанына назар аударыңыз, бірақ олар болғанға дейін олардан аулақ болған жөн).
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` және `ManuallyDrop` екеуі де `repr(transparent)`, сондықтан біз меңзерді бере аламыз.
        self as *const _ as *const T
    }

    /// Құрамындағы мәнге өзгермелі көрсеткішті алады.
    /// Осы көрсеткіштен оқу немесе оны сілтемеге айналдыру, егер `MaybeUninit<T>` инициализациясы болмаса, анықталмаған әрекет болып табылады.
    ///
    /// # Examples
    ///
    /// Осы әдісті дұрыс қолдану:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>`-ке сілтеме жасаңыз.
    /// // Бұл жақсы, өйткені біз оны баптандырдық.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Бұл әдісті *дұрыс емес* қолдану:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Біз инициализацияланбаған vector сілтемесін жасадық!Бұл анықталмаған тәртіп.⚠️
    /// ```
    ///
    /// (Инициализацияланбаған деректерге сілтемелер туралы ережелер әлі аяқталмағанына назар аударыңыз, бірақ олар болғанға дейін олардан аулақ болған жөн).
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` және `ManuallyDrop` екеуі де `repr(transparent)`, сондықтан біз меңзерді бере аламыз.
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` контейнерінен мәнді шығарады.Бұл деректердің түсіп қалуын қамтамасыз етудің тамаша әдісі, өйткені алынған `T` әдеттегі тамшылармен жұмыс істейді.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` шынымен инициалды күйде екеніне кепілдік беру қоңырау шалушының қолында.Мазмұн әлі толық инициализацияланбаған кезде оны шақыру дереу анықталмаған әрекеттерді тудырады.
    /// [type-level documentation][inv] инициализациясы туралы қосымша ақпаратты қамтиды.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Сонымен қатар, типтердің көпшілігінде тек тип деңгейінде инициализацияланған деп есептелмейтін қосымша инварианттар бар екенін ұмытпаңыз.
    /// Мысалы, `1`-инициализацияланған [`Vec<T>`] инициализацияланған болып саналады (ағымдағы іске асыруда; бұл тұрақты кепілдікке жатпайды), өйткені компилятордың білетін жалғыз талабы-бұл деректер көрсеткіші нөл болмауы керек.
    ///
    /// Мұндай `Vec<T>` жасау *жедел* анықталмаған мінез-құлықты туғызбайды, бірақ қауіпсіз операциялардың көпшілігінде анықталмаған мінез-құлықты тудырады (оны тастаумен қоса).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Осы әдісті дұрыс қолдану:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Бұл әдісті *дұрыс емес* қолдану:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` әлі инициалданбаған болатын, сондықтан бұл соңғы жол анықталмаған мінез-құлықты тудырды.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // ҚАУІПСІЗДІК: қоңырау шалушы `self` инициализацияланғанына кепілдік беруі керек.
        // Бұл сонымен қатар `self` `value` нұсқасы болуы керек дегенді білдіреді.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` контейнеріндегі мәнді оқиды.Алынған `T` әдеттегі тамшылармен өңделеді.
    ///
    /// Мүмкіндігінше оның орнына [`assume_init`] қолданған жөн, бұл `MaybeUninit<T>` мазмұнын қайталауға жол бермейді.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` шынымен инициалды күйде екеніне кепілдік беру қоңырау шалушының қолында.Мазмұн әлі толық инициализацияланбаған кезде бұл атау анықталмаған әрекеттерді тудырады.
    /// [type-level documentation][inv] инициализациясы туралы қосымша ақпаратты қамтиды.
    ///
    /// Сонымен қатар, бұл `MaybeUninit<T>` артында бірдей деректердің көшірмесін қалдырады.
    /// Деректердің бірнеше көшірмесін пайдаланған кезде (`assume_init_read`-ге бірнеше рет қоңырау шалу арқылы немесе алдымен `assume_init_read`, содан кейін [`assume_init`] қоңырау шалу арқылы), сіз бұл деректердің шынымен қайталануын қамтамасыз етуіңіз керек.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Осы әдісті дұрыс қолдану:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` бұл `Copy`, сондықтан біз бірнеше рет оқи аламыз.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` мәнін көшіруге болады, сондықтан біз бірнеше рет оқи аламыз.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Бұл әдісті *дұрыс емес* қолдану:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Біз қазір бірдей vector екі данасын жасадық, екеуі де құлап қалғанда екі еселенген тегін ⚠️ шығарады!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // ҚАУІПСІЗДІК: қоңырау шалушы `self` инициализацияланғанына кепілдік беруі керек.
        // `self.as_ptr()`-тен оқу қауіпсіз, себебі `self` инициализациясы керек.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Қамтылған мәнді орнына түсіреді.
    ///
    /// Егер сізде `MaybeUninit` иелігі болса, оның орнына [`assume_init`] қолдана аласыз.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` шынымен инициалды күйде екеніне кепілдік беру қоңырау шалушының қолында.Мазмұн әлі толық инициализацияланбаған кезде бұл атау анықталмаған әрекеттерді тудырады.
    ///
    /// Оның үстіне, `T` типті барлық қосымша инварианттар қанағаттандырылуы керек, өйткені `T` (немесе оның мүшелері) `Drop` іске асырылуы осыған сүйенуі мүмкін.
    /// Мысалы, `1`-инициализацияланған [`Vec<T>`] инициализацияланған болып саналады (ағымдағы іске асыруда; бұл тұрақты кепілдікке жатпайды), өйткені компилятордың білетін жалғыз талабы-бұл деректер көрсеткіші нөл болмауы керек.
    ///
    /// Мұндай `Vec<T>`-ті тастау анықталмаған мінез-құлықты тудырады.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // ҚАУІПСІЗДІК: қоңырау шалушы `self` инициализацияланғанына кепілдік беруі керек
        // `T` барлық инварианттарын қанағаттандырады.
        // Мәнді орнына түсіру, егер солай болса, қауіпсіз болады.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Қамтылған мәнге ортақ сілтеме алады.
    ///
    /// Бұл біз инициализацияланған, бірақ `MaybeUninit` иелігі жоқ `MaybeUninit`-ке қол жеткізгіміз келген кезде пайдалы болуы мүмкін (`.assume_init()`)-ті пайдалануға жол бермейді).
    ///
    /// # Safety
    ///
    /// Мазмұн әлі толық инициализацияланбаған кезде оны шақыру анықталмаған мінез-құлықты тудырады: қоңырау шалушының `MaybeUninit<T>` шынымен инициалды күйде екеніне кепілдік беруі керек.
    ///
    ///
    /// # Examples
    ///
    /// ### Осы әдісті дұрыс қолдану:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` инициализациясы:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Енді біздің `MaybeUninit<_>` инициализациясы белгілі болғандықтан, оған ортақ сілтеме жасаған дұрыс:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // ҚАУІПСІЗДІК: `x` инициализацияланды.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Осы әдісті * дұрыс қолданбау:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Біз инициализацияланбаған vector сілтемесін жасадық!Бұл анықталмаған тәртіп.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` көмегімен `MaybeUninit` инициализациясы:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Инициализацияланбаған `Cell<bool>` сілтемесі: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // ҚАУІПСІЗДІК: қоңырау шалушы `self` инициализацияланғанына кепілдік беруі керек.
        // Бұл сонымен қатар `self` `value` нұсқасы болуы керек дегенді білдіреді.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Құрамындағы мәнге өзгертілетін (unique) сілтемесін алады.
    ///
    /// Бұл біз инициализацияланған, бірақ `MaybeUninit` иелігі жоқ `MaybeUninit`-ке қол жеткізгіміз келген кезде пайдалы болуы мүмкін (`.assume_init()`)-ті пайдалануға жол бермейді).
    ///
    /// # Safety
    ///
    /// Мазмұн әлі толық инициализацияланбаған кезде оны шақыру анықталмаған мінез-құлықты тудырады: қоңырау шалушының `MaybeUninit<T>` шынымен инициалды күйде екеніне кепілдік беруі керек.
    /// Мысалы, `.assume_init_mut()` `MaybeUninit` инициализациясы үшін қолданыла алмайды.
    ///
    /// # Examples
    ///
    /// ### Осы әдісті дұрыс қолдану:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Кіріс буферінің *барлық* байттарын инициализациялайды.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` инициализациясы:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Енді біз `buf` инициализацияланғанын білеміз, сондықтан оны `.assume_init()` жасай алдық.
    /// // Алайда, `.assume_init()` пайдалану 2048 байттың `memcpy`-ін тудыруы мүмкін.
    /// // Біздің буфер оны көшірместен баптандырылғанын растау үшін біз `&mut MaybeUninit<[u8; 2048]>`-ті `&mut [u8; 2048]` деңгейіне шығарамыз:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // ҚАУІПСІЗДІК: `buf` инициализацияланды.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Енді біз `buf`-ді әдеттегі тілім ретінде қолдана аламыз:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Осы әдісті * дұрыс қолданбау:
    ///
    /// Сіз `.assume_init_mut()` мәнін инициализациялау үшін пайдалана алмайсыз:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Біз инициализацияланбаған `bool`-ке сілтеме жасадық!
    ///     // Бұл анықталмаған тәртіп.⚠️
    /// }
    /// ```
    ///
    /// Мысалы, сіз [`Read`]-ті инициализацияланбаған буферге қоса алмайсыз:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) инициализацияланбаған жадқа сілтеме!
    ///                             // Бұл анықталмаған тәртіп.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Өрістерді біртіндеп инициалдау үшін өріске тікелей қол жеткізуді де пайдалана алмайсыз:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) инициализацияланбаған жадқа сілтеме!
    ///                  // Бұл анықталмаған тәртіп.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) инициализацияланбаған жадқа сілтеме!
    ///                  // Бұл анықталмаған тәртіп.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Қазіргі уақытта біз жоғарыда айтылғандардың дұрыс еместігіне сенеміз, яғни инициализацияланбаған деректерге сілтемелер бар (мысалы, `libcore/fmt/float.rs`-те).
    // Біз тұрақтандыруға дейін ережелер туралы түпкілікті шешім қабылдауымыз керек.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // ҚАУІПСІЗДІК: қоңырау шалушы `self` инициализацияланғанына кепілдік беруі керек.
        // Бұл сонымен қатар `self` `value` нұсқасы болуы керек дегенді білдіреді.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` контейнерлер массивінен мәндерді шығарады.
    ///
    /// # Safety
    ///
    /// Массивтің барлық элементтерінің инициалды күйде екеніне кепілдік беру қоңырау шалушының қолында.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // ҚАУІПСІЗДІК: Енді барлық элементтерді инициалдаған кезде қауіпсіз
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Қоңырау шалушы барлық массив элементтерінің инициализацияланғандығына кепілдік береді
        // * `MaybeUninit<T>` және T-ге бірдей орналасуға кепілдік беріледі
        // * МүмкінUnint құламайды, сондықтан екі реттік төлем болмайды, сондықтан конверсия қауіпсіз болады
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Барлық элементтер инициалданған деп есептесеңіз, оларға кесінді алыңыз.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` элементтерінің инициалды күйде екеніне кепілдік беру қоңырау шалушының қолында.
    ///
    /// Мазмұн әлі толық инициализацияланбаған кезде бұл атау анықталмаған әрекеттерді тудырады.
    ///
    /// Қосымша мәліметтер мен мысалдар үшін [`assume_init_ref`] қараңыз.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // ҚАУІПСІЗДІК: `*const [T]` кесіндісін құю қауіпсіз, өйткені қоңырау шалушы бұған кепілдік береді
        // `slice` инициализацияланған, және «Мүмкін,» `T` сияқты орналасуына кепілдік береді.
        // Алынған көрсеткіш жарамды, өйткені ол сілтеме болып табылатын және оқуға жарамды екендігіне кепілдік беретін `slice`-ге тиесілі жадты білдіреді.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Барлық элементтер инициалданған деп есептесеңіз, оларға өзгермелі кесінді алыңыз.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` элементтерінің инициалды күйде екеніне кепілдік беру қоңырау шалушының қолында.
    ///
    /// Мазмұн әлі толық инициализацияланбаған кезде бұл атау анықталмаған әрекеттерді тудырады.
    ///
    /// Қосымша мәліметтер мен мысалдар үшін [`assume_init_mut`] қараңыз.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // ҚАУІПСІЗДІК: `slice_get_ref` қауіпсіздік нұсқауларына ұқсас, бірақ бізде
        // өзгертілетін сілтеме, ол сонымен қатар жазбалар үшін жарамды екеніне кепілдік береді.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Массивтің бірінші элементіне нұсқағышты алады.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Массивтің бірінші элементіне өзгермелі көрсеткішті алады.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src`-тен `this`-ге дейінгі элементтерді көшіреді және `this` инитирленген мазмұнына өзгертілетін сілтеме береді.
    ///
    /// Егер `T` `Copy`-ті қолданбаса, [`write_slice_cloned`]-ті қолданыңыз
    ///
    /// Бұл [`slice::copy_from_slice`]-ге ұқсас.
    ///
    /// # Panics
    ///
    /// Бұл функция panic болады, егер екі тілімнің ұзындығы әр түрлі болса.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ҚАУІПСІЗДІК: біз леннің барлық элементтерін қосалқы қуатқа көшірдік
    /// // vec-тің алғашқы src.len() элементтері қазір жарамды.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // ҚАУІПСІЗДІК: &[T] және&[MaybeUninit<T>] бірдей орналасуы бар
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // ҚАУІПСІЗДІК: жарамды элементтер жаңа `this`-ке көшірілді, сондықтан ол инициализацияланған
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Элементтерді `src`-тен `this`-ке клондап, `this`-тің инициализацияланған мазмұнына өзгермелі сілтемені қайтарады.
    /// Кез-келген инициирленген элементтер алынып тасталмайды.
    ///
    /// Егер `T` `Copy`-ті қолданса, [`write_slice`] пайдаланыңыз
    ///
    /// Бұл [`slice::clone_from_slice`]-ге ұқсас, бірақ бар элементтерді түсірмейді.
    ///
    /// # Panics
    ///
    /// Бұл функция panic болады, егер екі тілімнің ұзындығы әр түрлі болса немесе `Clone` panics орындалса.
    ///
    /// Егер panic болса, клондалған элементтер алынып тасталады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ҚАУІПСІЗДІК: біз леннің барлық элементтерін қосалқы қуатқа клондадық
    /// // vec-тің алғашқы src.len() элементтері қазір жарамды.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice-ге қарағанда, бұл тілімде clone_from_slice деп аталмайды, себебі `MaybeUninit<T: Clone>` Clone-ді қолданбайды.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // ҚАУІПСІЗДІК: бұл шикі тілім тек баптандырылған нысандарды қамтиды
                // сондықтан оны тастауға рұқсат етіледі.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Біз оларды бірдей ұзындыққа кесуіміз керек
        // шекараларды тексеру үшін оңтайландырғыш қарапайым жағдайлар үшін memcpy жасайды (мысалы, T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // күзетші қажет, b/c panic клон кезінде орын алуы мүмкін
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // ҚАУІПСІЗДІК: жарамды элементтер `this` форматына жазылды, сондықтан ол инициализацияланды
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}