//! Жадпен жұмыс істеудің негізгі функциялары.
//!
//! Бұл модуль типтердің өлшемі мен туралануына сұрау салуға, жадты инициализациялауға және манипуляциялауға арналған функцияларды қамтиды.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Меншікті және "forgets"-ті **жойғышты іске қоспай-ақ** мәні туралы алады.
///
/// Үймелейтін жады немесе файлдың дескрипторы сияқты басқарылатын кез келген ресурстар қол жетімсіз күйде мәңгі қалады.Алайда, бұл жадқа сілтегіштердің жарамды болып қалуына кепілдік бермейді.
///
/// * Егер сіз жадты босатқыңыз келсе, [`Box::leak`] қараңыз.
/// * Егер сіз жадқа шикі көрсеткішті алғыңыз келсе, [`Box::into_raw`] қараңыз.
/// * Егер сіз деструкторды қолдана отырып, мәнді дұрыс тастағыңыз келсе, [`mem::drop`] қараңыз.
///
/// # Safety
///
/// `forget` `unsafe` ретінде белгіленбейді, өйткені Rust қауіпсіздік кепілдіктеріне деструкторлар әрқашан жұмыс істейтініне кепілдік кірмейді.
/// Мысалы, бағдарлама [`Rc`][rc] көмегімен сілтеме циклын құра алады немесе деструкторларсыз шығу үшін [`process::exit`][exit] шақырады.
/// Осылайша, `mem::forget`-ті қауіпсіз кодтан алу Rust қауіпсіздік кепілдіктерін түбегейлі өзгертпейді.
///
/// Жады немесе I/O нысандары сияқты ресурстардың ағып кетуі әдетте жағымсыз болып табылады.
/// Қажеттілік FFI немесе қауіпті кодты қолдану жөніндегі кейбір мамандандырылған жағдайларда туындайды, бірақ солай бола тұрса да, әдетте, [`ManuallyDrop`] таңдалады.
///
/// Мәнді ұмытып кетуге болатындықтан, сіз жазған кез келген `unsafe` коды осы мүмкіндікті қамтамасыз етуі керек.Сіз мәнді қайтара алмайсыз және қоңырау шалушы міндетті түрде деструкторды іске қосады деп күте алмайсыз.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget`-ті канондық қауіпсіз қолдану `Drop` trait іске асыратын мәннің деструкторын айналып өту болып табылады.Мысалы, бұл `File` ағып кетеді, яғни
/// айнымалы қабылдаған кеңістікті қайтарып алыңыз, бірақ негізгі жүйелік ресурстарды ешқашан жаппаңыз:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Бұл негізгі ресурстарға меншік құқығы Rust-ден тыс кодқа өткенде, мысалы шикі файл дескрипторын С кодына жіберу кезінде пайдалы.
///
/// # `ManuallyDrop`-пен байланыс
///
/// `mem::forget`*жады* меншігін беру үшін де қолданыла алатын болса, бұл қателіктерге әкеледі.
/// [`ManuallyDrop`] орнына қолданылуы керек.Мысалы, осы кодты қарастырайық:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` мазмұнын пайдаланып `String` құрастырыңыз
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // ағып `v`, өйткені оның жадын қазір `s` басқарады
/// mem::forget(v);  // ҚАТЕ, v жарамсыз және оны функцияға жіберуге болмайды
/// assert_eq!(s, "Az");
/// // `s` жанама түрде түсіп, оның жады бөлінеді.
/// ```
///
/// Жоғарыда келтірілген мысалда екі мәселе бар:
///
/// * Егер `String` құрылысы мен `mem::forget()` шақырылымы арасында көбірек код қосылса, оның ішіндегі panic екі еселенген еркіндікті тудыруы мүмкін, өйткені бірдей жадты `v` және `s` басқарады.
/// * `v.as_mut_ptr()`-ге қоңырау шалып, деректердің меншік құқығын `s`-ге жібергеннен кейін, `v` мәні жарамсыз.
/// Мәнді `mem::forget`-ге ауыстырған кезде де (ол оны тексермейді), кейбір типтерде олардың мәндеріне қатаң талаптар қойылады, олар оларды ілулі немесе жарамсыз етеді.
/// Жарамсыз мәндерді кез-келген түрде пайдалану, соның ішінде оларды функцияларға беру немесе оларды қайтару, анықталмаған мінез-құлықты құрайды және компилятор жасаған болжамдарды бұзуы мүмкін.
///
/// `ManuallyDrop`-ке ауысу екі мәселені болдырмайды:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // `v`-ті шикізатқа бөлшектемес бұрын, оның түсіп кетпеуін қадағалаңыз!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Енді `v` бөлшектеңіз.Бұл операциялар panic жасай алмайды, сондықтан ағып кету мүмкін емес.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Соңында, `String` құрастырыңыз.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` жанама түрде түсіп, оның жады бөлінеді.
/// ```
///
/// `ManuallyDrop` екі еселенгенге жол бермейді, өйткені біз «v`» деструкторын ештеңе жасамас бұрын өшіреміз.
/// `mem::forget()` бұған жол бермейді, өйткені ол өзінің аргументін жұмсайды, біз оны `v`-тен қажет нәрсені шығарғаннан кейін ғана шақыруға мәжбүр етеміз.
/// `ManuallyDrop` салу мен жолды құру арасында panic енгізілген болса да (бұл кодта көрсетілгендей болуы мүмкін емес), бұл екі еселенген бос емес, ағып кетуге әкеледі.
/// Басқаша айтқанда, `ManuallyDrop` (екі еселенген) құлау жағындағы қателіктердің орнына ағып кету жағында қателіктер жібереді.
///
/// Сондай-ақ, `ManuallyDrop` меншік құқығын `s`-ге ауыстырғаннан кейін бізге "touch" `v`-ті болдырмауға мүмкіндік береді-`v`-пен оның деструкторынсыз жою үшін өзара әрекеттесудің соңғы сатысы толығымен болдырылмайды.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] сияқты, сонымен бірге өлшемделмеген мәндерді қабылдайды.
///
/// Бұл функция тек `unsized_locals` функциясы тұрақталған кезде алып тастауға арналған жылтыр.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Түрдің өлшемін байтпен қайтарады.
///
/// Нақтырақ айтсақ, бұл массивтегі элементтер қатарының байтпен жылжуы, сол типтегі элементтермен, туралауды толтырумен қоса.
///
/// Сонымен, кез-келген `T` типі мен ұзындығы `n` үшін `[T; n]` өлшемі `n * size_of::<T>()` болады.
///
/// Жалпы, типтің мөлшері компиляциялар бойынша тұрақты емес, бірақ примитивтер сияқты ерекше түрлері.
///
/// Келесі кестеде примитивтердің өлшемі келтірілген.
///
/// Түріsize_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 кар. |4
///
/// Сонымен қатар, `usize` және `isize` өлшемдері бірдей.
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` және `Option<Box<T>>` типтерінің өлшемдері бірдей.
/// Егер `T` өлшемі болса, онда олардың барлық түрлері `usize` өлшемімен бірдей.
///
/// Көрсеткіштің өзгергіштігі оның өлшемін өзгертпейді.Осылайша, `&T` және `&mut T` өлшемдері бірдей.
/// `*const T` және `* mut T` сияқты.
///
/// # `#[repr(C)]` элементтерінің өлшемі
///
/// Элементтерге арналған `C` көрінісі анықталған орналасуға ие.
/// Осы орналасудың көмегімен элементтердің өлшемдері де тұрақты болады, егер барлық өрістер тұрақты өлшемге ие болса.
///
/// ## Құрылымдардың мөлшері
///
/// `structs` үшін өлшем келесі алгоритммен анықталады.
///
/// Декларация тапсырысы бойынша реттелген құрылымдағы әрбір өріс үшін:
///
/// 1. Өрістің өлшемін қосыңыз.
/// 2. Ағымдағы өлшемді келесі өрістің [alignment] еселік дәлдігіне дейін дөңгелектеңіз.
///
/// Сонымен, құрылымның өлшемін оның [alignment] еселігіне дейін дөңгелектеңіз.
/// Құрылымды туралау әдетте оның барлық өрістерінің ең үлкен туралануы болып табылады;оны `repr(align(N))` көмегімен өзгертуге болады.
///
/// `C`-тен айырмашылығы, өлшемі нөлдік құрылымдар өлшемі бойынша бір байтқа дейін дөңгелектенбейді.
///
/// ## Тілек мөлшері
///
/// Дискриминанттан басқа ешқандай мәлімет жоқ энумдардың мөлшері олар жинақталған платформадағы С энументтерімен бірдей.
///
/// ## Одақтардың мөлшері
///
/// Кәсіподақ мөлшері-бұл оның ең үлкен өрісінің мөлшері.
///
/// `C`-тен айырмашылығы, нөлдік өлшемді кәсіподақтар бір байтқа дейін дөңгелектенбейді.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Кейбір қарабайырлықтар
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Кейбір массивтер
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Көрсеткіштің теңдігі
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` пайдалану.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Бірінші өрістің өлшемі 1, сондықтан өлшемге 1 қосыңыз.Өлшемі-1.
/// // Екінші өрістің туралануы 2-ге тең, сондықтан толтыруға арналған өлшемге 1 қосыңыз.Өлшемі 2.
/// // Екінші өрістің өлшемі 2, сондықтан өлшемге 2 қосыңыз.Өлшемі 4.
/// // Үшінші өрістің туралануы 1-ге тең, сондықтан толтыруға арналған өлшемге 0 қосыңыз.Өлшемі 4.
/// // Үшінші өрістің өлшемі 1, сондықтан өлшемге 1 қосыңыз.Өлшемі 5.
/// // Сонымен, құрылымның туралануы 2-ге тең (себебі оның өрістерінің арасындағы ең үлкен туралау 2-ге тең), сондықтан толтыруға арналған өлшемге 1 қосыңыз.
/// // Өлшемі 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple құрылымдары бірдей ережелерді сақтайды.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Өрістерді ретке келтіру өлшемді төмендетуі мүмкін екенін ескеріңіз.
/// // Біз `third`-ті `second`-ге дейін қою арқылы екі байтты да алып тастай аламыз.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Кәсіподақ мөлшері-ең үлкен өрістің өлшемі.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Белгіленген мәннің байт өлшемін қайтарады.
///
/// Әдетте бұл `size_of::<T>()` сияқты.
/// Алайда, егер `T`* * статикалық белгілі өлшемі болмаса, мысалы, [`[T]`][slice] кесіндісі немесе [trait object] болса, онда динамикалық түрде белгілі өлшемді алу үшін `size_of_val` қолдануға болады.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // ҚАУІПСІЗДІК: `val`-сілтеме, сондықтан ол дұрыс шикі көрсеткіш
    unsafe { intrinsics::size_of_val(val) }
}

/// Белгіленген мәннің байт өлшемін қайтарады.
///
/// Әдетте бұл `size_of::<T>()` сияқты.Алайда, егер `T`* * статикалық белгілі өлшемі болмаса, мысалы, [`[T]`][slice] кесіндісі немесе [trait object] болса, динамикалық түрде белгілі өлшемді алу үшін `size_of_val_raw` қолдануға болады.
///
/// # Safety
///
/// Бұл функция қоңырау шалу үшін келесі шарттар сақталған кезде ғана қауіпсіз болады:
///
/// - Егер `T` `Sized` болса, бұл функция қоңырау шалу үшін әрдайым қауіпсіз.
/// - Егер `T` өлшемсіз құйрығы:
///     - [slice], содан кейін кесінді құйрығының ұзындығы инициализацияланған бүтін сан болуы керек, ал *бүкіл мәннің* мөлшері (құйрықтың динамикалық ұзындығы + статикалық өлшемді префикс) `isize` сәйкес келуі керек.
///     - a [trait object], содан кейін көрсеткіштің vtable бөлігі өлшемсіз мәжбүрлеу арқылы алынған жарамды vtable-ды көрсетуі керек және *бүкіл мәннің* өлшемі (динамикалық құйрық ұзындығы + статикалық өлшемді префикс) `isize`-ке сәйкес келуі керек.
///
///     - (unstable) [extern type] болса, онда бұл функция қоңырау шалу үшін әрдайым қауіпсіз, бірақ panic немесе басқаша түрде қате мәнді қайтаруы мүмкін, өйткені сыртқы типтің орналасуы белгісіз.
///     Бұл [`size_of_val`]-тің сыртқы түрдегі құйрығы бар типке сілтеме жасауымен бірдей.
///     - әйтпесе, бұл функцияны шақыруға консервативті жол берілмейді.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ҚАУІПСІЗДІК: қоңырау шалушы жарамды шикі көрсеткішті қамтамасыз етуі керек
    unsafe { intrinsics::size_of_val(val) }
}

/// [ABI]-мәннің минималды туралануын қайтарады.
///
/// `T` типті мәнге әрбір сілтеме осы санның еселігі болуы керек.
///
/// Бұл құрылымдық өрістер үшін қолданылатын туралау.Ол қалаған туралауға қарағанда кішірек болуы мүмкін.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` көрсеткен мән түрінің [ABI] талап етілетін минималды туралануын қайтарады.
///
/// `T` типті мәнге әрбір сілтеме осы санның еселігі болуы керек.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // ҚАУІПСІЗДІК: val-сілтеме, сондықтан ол дұрыс шикі көрсеткіш
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [ABI]-мәннің минималды туралануын қайтарады.
///
/// `T` типті мәнге әрбір сілтеме осы санның еселігі болуы керек.
///
/// Бұл құрылымдық өрістер үшін қолданылатын туралау.Ол қалаған туралауға қарағанда кішірек болуы мүмкін.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` көрсеткен мән түрінің [ABI] талап етілетін минималды туралануын қайтарады.
///
/// `T` типті мәнге әрбір сілтеме осы санның еселігі болуы керек.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // ҚАУІПСІЗДІК: val-сілтеме, сондықтан ол дұрыс шикі көрсеткіш
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val` көрсеткен мән түрінің [ABI] талап етілетін минималды туралануын қайтарады.
///
/// `T` типті мәнге әрбір сілтеме осы санның еселігі болуы керек.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Бұл функция қоңырау шалу үшін келесі шарттар сақталған кезде ғана қауіпсіз болады:
///
/// - Егер `T` `Sized` болса, бұл функция қоңырау шалу үшін әрдайым қауіпсіз.
/// - Егер `T` өлшемсіз құйрығы:
///     - [slice], содан кейін кесінді құйрығының ұзындығы инициализацияланған бүтін сан болуы керек, ал *бүкіл мәннің* мөлшері (құйрықтың динамикалық ұзындығы + статикалық өлшемді префикс) `isize` сәйкес келуі керек.
///     - a [trait object], содан кейін көрсеткіштің vtable бөлігі өлшемсіз мәжбүрлеу арқылы алынған жарамды vtable-ды көрсетуі керек және *бүкіл мәннің* өлшемі (динамикалық құйрық ұзындығы + статикалық өлшемді префикс) `isize`-ке сәйкес келуі керек.
///
///     - (unstable) [extern type] болса, онда бұл функция қоңырау шалу үшін әрдайым қауіпсіз, бірақ panic немесе басқаша түрде қате мәнді қайтаруы мүмкін, өйткені сыртқы типтің орналасуы белгісіз.
///     Бұл [`align_of_val`]-тің сыртқы түрдегі құйрығы бар типке сілтеме жасауымен бірдей.
///     - әйтпесе, бұл функцияны шақыруға консервативті жол берілмейді.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ҚАУІПСІЗДІК: қоңырау шалушы жарамды шикі көрсеткішті қамтамасыз етуі керек
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Егер `T` типінің мәндерін төмендету маңызды болса, `true` мәнін қайтарады.
///
/// Бұл тек оңтайландыру туралы кеңес және консервативті түрде жүзеге асырылуы мүмкін:
/// ол `true`-ті қайтаруды қажет етпейтін түрлер үшін қайтаруы мүмкін.
/// Осылайша, әрдайым `true` қайтару осы функцияның дұрыс орындалуы болар еді.Бірақ егер бұл функция шынымен `false` мәнін қайтаратын болса, онда сіз `T`-ті тастаудың ешқандай жанама әсері жоқ екеніне сенімді бола аласыз.
///
/// Деректерді қолмен тастау керек коллекциялар сияқты деңгейлерді іске асырудың төмен деңгейі, бұл функцияны жойылған кезде барлық мазмұнды қажетсіз тастауға тырыспау үшін қолдануы керек.
///
/// Бұл шығарылымдардың өзгеруіне әсер етпеуі мүмкін (мұнда жанама әсерлері жоқ цикл оңай анықталады және жойылады), бірақ көбінесе дебаг жасау үшін үлкен жеңіс болып табылады.
///
/// Назар аударыңыз, [`drop_in_place`] бұл тексерісті жүзеге асырады, сондықтан сіздің жұмысыңыздың мөлшері аз [`drop_in_place`] қоңырауларына дейін азайтылатын болса, оны пайдалану қажет емес.
/// Сіз тілім [`drop_in_place`] жасай алатыныңызды және барлық мәндер үшін бір need_drop тексерісін жүргізетіндігіңізді ескеріңіз.
///
/// Vec сияқты түрлері, сондықтан `needs_drop`-ті қолданбай тек `drop_in_place(&mut self[..])`.
/// Екінші жағынан, [`HashMap`] сияқты түрлер мәндерді бір-бірлеп түсіруі керек және осы API қолдануы керек.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Мұнда коллекция `needs_drop`-ті қалай пайдалануға болатындығы туралы мысал келтірілген:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // деректерді тастаңыз
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Барлық нөлдік байт үлгісімен ұсынылған `T` типінің мәнін қайтарады.
///
/// Бұл дегеніміз, мысалы, `(u8, u16)` ішіндегі байт міндетті түрде нөлге айналдырылмайды.
///
/// Нөлдік байт үлгісі `T` типінің жарамды мәнін көрсететініне кепілдік жоқ.
/// Мысалы, нөлдік байт үлгісі сілтеме типтері (`&T`, `&mut T`) және функционалды сілтемелер үшін жарамды мән емес.
/// Мұндай типтерде `zeroed` пайдалану бірден [undefined behavior][ub] туғызады, себебі [the Rust compiler assumes][inv] инициализацияланған деп санайтын айнымалыда әрқашан жарамды мән болады.
///
///
/// Бұл [`MaybeUninit::zeroed().assume_init()`][zeroed] сияқты әсер етеді.
/// Бұл кейде FFI үшін пайдалы болады, бірақ оны болдырмау керек.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Бұл функцияны дұрыс қолдану: бүтін санды нөлге теңестіру.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Дұрыс емес* бұл функцияны қолдану: сілтемені нөлге теңестіру.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Анықталмаған тәртіп!
/// let _y: fn() = unsafe { mem::zeroed() }; // Тағы да!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // ҚАУІПСІЗДІК: қоңырау шалушы нөлдік мәннің `T` үшін жарамды екеніне кепілдік беруі керек.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Rust қалыпты жадының инициализациясын айналып өтіп, ештеңе істемей тұрып, `T` типті мәнін шығарады.
///
/// **Бұл функция ескірген.** Оның орнына [`MaybeUninit<T>`] қолданыңыз.
///
/// Амортизацияның себебі-бұл функцияны негізінен дұрыс пайдалану мүмкін емес: ол [`MaybeUninit::uninit().assume_init()`][uninit] сияқты әсер етеді.
///
/// [`assume_init` documentation][assume_init] түсіндіргендей, [the Rust compiler assumes][inv] мәні дұрыс инициалданған.
/// Нәтижесінде, мысалы, қоңырау шалыңыз
/// `mem::uninitialized::<bool>()` `bool`-ті қайтару үшін дереу анықталмаған мінез-құлықты тудырады, ол `true` немесе `false` емес.
/// Ең жаманы, мұнда қайтарылатын нәрсе сияқты нағыз инициализацияланбаған жады ерекше, өйткені компилятор оның тұрақты мәні жоқ екенін біледі.
/// Бұл айнымалыда инициализацияланбаған деректердің болуы анықталмаған мінез-құлыққа айналады, тіпті егер бұл айнымалыда бүтін тип болса.
/// (Инициализацияланбаған бүтін сандар туралы ережелер әлі аяқталмағанына назар аударыңыз, бірақ олар болғанға дейін олардан аулақ болған жөн).
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // ҚАУІПСІЗДІК: қоңырау шалушы `T` үшін өлшемді мәннің жарамды екеніне кепілдік беруі керек.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Екі өзгертілетін жерде мәндерді ауыстырады, екеуін деинициализацияламай.
///
/// * Егер сіз әдепкі немесе жалған мәнмен ауыстырғыңыз келсе, [`take`] қараңыз.
/// * Егер сіз ескі мәнді қайтара отырып, берілген мәнмен ауыстырғыңыз келсе, [`replace`] қараңыз.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // ҚАУІПСІЗДІК: бастапқы көрсеткіштер барлық өзгертілетін қауіпсіз өзгермелі сілтемелерден жасалған
    // `ptr::swap_nonoverlapping_one` шектеулері
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Алдыңғы `dest` мәнін қайтара отырып, `dest` стандартты мәнімен `T` ауыстырады.
///
/// * Егер сіз екі айнымалының мәндерін ауыстырғыңыз келсе, [`swap`] қараңыз.
/// * Егер сіз әдепкі мәннің орнына берілген мәнмен ауыстырғыңыз келсе, [`replace`] қараңыз.
///
/// # Examples
///
/// Қарапайым мысал:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` оны құрылым өрісіне "empty" мәнімен ауыстыру арқылы иелік етуге мүмкіндік береді.
/// `take` болмаса, сіз келесі мәселелерді шеше аласыз:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Назар аударыңыз, `T` міндетті түрде [`Clone`]-ті қолданбайды, сондықтан ол `self.buf`-ті клондап, қалпына келтіре алмайды.
/// Бірақ `take` `self.buf`-тің бастапқы мәнін `self`-тен ажыратып, оны қайтаруға мүмкіндік береді:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Алдыңғы `dest` мәнін қайтара отырып, `src` сілтеме жасалған `dest` ішіне жылжытады.
///
/// Екі мән де түсірілмейді.
///
/// * Егер сіз екі айнымалының мәндерін ауыстырғыңыз келсе, [`swap`] қараңыз.
/// * Егер сіз әдепкі мәнмен ауыстырғыңыз келсе, [`take`] бөлімін қараңыз.
///
/// # Examples
///
/// Қарапайым мысал:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` құрылым өрісін басқа мәнге ауыстыру арқылы тұтынуға мүмкіндік береді.
/// `replace` болмаса, сіз келесі мәселелерді шеше аласыз:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// `T` міндетті түрде [`Clone`]-ті қолданбайтындығын ескеріңіз, сондықтан біз `self.buf[i]`-ті көшіріп алмау үшін клондау мүмкін емес.
/// Бірақ `replace`-ті осы индекстегі бастапқы мәнді `self`-тен ажырату үшін қолдануға болады, оны қайтаруға мүмкіндік береді:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // ҚАУІПСІЗДІК: Біз `dest`-тен оқимыз, бірақ кейін оған `src` жазамыз,
    // ескі мән қайталанбайтындай етіп.
    // Ештеңе құлатылмайды және panic мұнда ешнәрсе болмайды.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Құнды тастайды.
///
/// Бұл аргументтің [`Drop`][drop] орындалуын шақыру арқылы жасалады.
///
/// Бұл `Copy`-ті жүзеге асыратын типтер үшін тиімді болмайды, мысалы
/// integers.
/// Мұндай мәндер көшіріліп, функцияға _then_ көшіріледі, сондықтан функция осы функция шақырғаннан кейін де сақталады.
///
///
/// Бұл функция сиқырлы емес;ол сөзбе-сөз анықталады
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// `_x` функцияға ауысқандықтан, функция қайтарылғанға дейін автоматты түрде түсіп кетеді.
///
/// [drop]: Drop
///
/// # Examples
///
/// Негізгі пайдалану:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // vector-ді нақты тастаңыз
/// ```
///
/// [`RefCell`] қарыз алу ережелерін жұмыс уақытында орындайтындықтан, `drop` [`RefCell`] қарызын босата алады:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // осы слоттағы өзгермелі қарыздан бас тарту
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// [`Copy`]-ті қолданатын бүтін сандар мен басқа типтерге `drop` әсер етпейді.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` көшірмесі жылжытылады және түсіріледі
/// drop(y); // `y` көшірмесі жылжытылады және түсіріледі
///
/// println!("x: {}, y: {}", x, y.0); // әлі қол жетімді
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src`-ті `&U` типті деп түсіндіреді, содан кейін `src` мәнін қозғамай оқиды.
///
/// Бұл функция `src` көрсеткіші [`size_of::<U>`][size_of] байт үшін `&T`-ті `&U`-ге ауыстырып, содан кейін `&U`-ті оқу арқылы жарамды деп санайды (тек егер бұл `&U` `&T`-ге қарағанда қаттырақ туралау талаптарын қойса да дұрыс жасалады).
/// Сондай-ақ, ол `src`-тен тыс жылжудың орнына қауіпсіз мәннің көшірмесін жасайды.
///
/// Егер `T` және `U` өлшемдері әр түрлі болса, бұл компиляция уақытының қателігі емес, бірақ тек `T` және `U` өлшемдері бірдей болғанда ғана осы функцияны шақыру ұсынылады.Бұл функция [undefined behavior][ub]-ті іске қосады, егер `U` `T`-тен үлкен болса.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array'-тен деректерді көшіріңіз және оны 'Foo' ретінде қарастырыңыз
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Көшірілген деректерді өзгертіңіз
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' мазмұны өзгермеуі керек еді
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Егер U туралау талабы жоғары болса, src сәйкес тураланбауы мүмкін.
    if align_of::<U>() > align_of::<T>() {
        // ҚАУІПСІЗДІК: `src`-оқуға жарамды екеніне кепілдік берілген сілтеме.
        // Қоңырау шалушы нақты трансмутуацияның қауіпсіздігіне кепілдік беруі керек.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // ҚАУІПСІЗДІК: `src`-оқуға жарамды екеніне кепілдік берілген сілтеме.
        // Біз жай ғана `src as *const U` тураланғанын тексердік.
        // Қоңырау шалушы нақты трансмутуацияның қауіпсіздігіне кепілдік беруі керек.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Энум дискриминантын білдіретін мөлдір емес түрі.
///
/// Қосымша ақпарат алу үшін осы модульдегі [`discriminant`] функциясын қараңыз.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Бұл trait іске асыруларын шығару мүмкін емес, өйткені біз T-ге шек қоюды қаламаймыз.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` ішіндегі enum нұсқасын бірегей анықтайтын мәнді қайтарады.
///
/// Егер `T` енум болмаса, бұл функцияны шақыру анықталмаған әрекетке әкелмейді, бірақ қайтарылатын мән анықталмайды.
///
///
/// # Stability
///
/// Enum нұсқасы өзгерген жағдайда, энум нұсқасының дискриминанты өзгеруі мүмкін.
/// Кейбір нұсқалардың дискриминанты сол компиляторы бар компиляциялар арасында өзгермейді.
///
/// # Examples
///
/// Мұны нақты деректерді ескермей, деректерді тасымалдайтын энумдарды салыстыру үшін пайдалануға болады:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// `T` типті энум түріндегі нұсқалардың санын қайтарады.
///
/// Егер `T` енум болмаса, бұл функцияны шақыру анықталмаған әрекетке әкелмейді, бірақ қайтарылатын мән анықталмайды.
/// Сонымен, егер `T`-`usize::MAX`-тен көп нұсқалары бар энум болса, қайтару мәні анықталмаған.
/// Адамның тұрмаған нұсқалары саналады.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}