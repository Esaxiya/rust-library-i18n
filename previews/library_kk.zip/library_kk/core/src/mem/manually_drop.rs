use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Компилятордың автоматты түрде «Т» деструкторын шақыруына жол бермейтін қаптама.
/// Бұл орауыш құны 0 тұрады.
///
/// `ManuallyDrop<T>` `T` сияқты орналасу оңтайландыруларына жатады.
/// Нәтижесінде, компилятор оның мазмұны туралы болжауларына *ешқандай әсер етпейді*.
/// Мысалы, `ManuallyDrop<&mut T>`-ті [`mem::zeroed`]-пен инициализациялау-бұл анықталмаған әрекет.
/// Егер сізге инициализацияланбаған деректерді өңдеу қажет болса, оның орнына [`MaybeUninit<T>`] пайдаланыңыз.
///
/// `ManuallyDrop<T>` ішіндегі мәнге қол жеткізу қауіпсіз екенін ескеріңіз.
/// Бұл дегеніміз, мазмұны түсірілген `ManuallyDrop<T>` жалпыға қол жетімді API арқылы шығарылмауы керек.
/// Сәйкесінше, `ManuallyDrop::drop` қауіпті.
///
/// # `ManuallyDrop` және тапсырысты тастаңыз.
///
/// Rust анықталған [drop order] мәндеріне ие.
/// Өрістердің немесе жергілікті тұрғындардың белгілі бір тәртіппен түсірілгеніне көз жеткізу үшін, декларацияны жасырын түсіру тәртібі дұрыс болатындай етіп қайта орналастырыңыз.
///
/// Түсіру ретін басқару үшін `ManuallyDrop` қолдануға болады, бірақ бұл үшін қауіпті код қажет және оны босату кезінде дұрыс орындау қиын.
///
///
/// Мысалы, егер сіз белгілі бір өрістің басқалардан кейін түсіп қалғанына көз жеткізгіңіз келсе, оны құрылымның соңғы өрісіне айналдырыңыз:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` кейін түсіріледі.
///     // Rust декларация тәртібінде өрістердің алынып тасталуына кепілдік береді.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Қолмен түсірілетін мәнді ораңыз.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Сіз мән бойынша қауіпсіз жұмыс жасай аласыз
    /// assert_eq!(*x, "Hello");
    /// // Бірақ `Drop` мұнда іске қосылмайды
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` контейнерінен мәнді шығарады.
    ///
    /// Бұл мәнді қайтадан түсіруге мүмкіндік береді.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Бұл `Box` төмендейді.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` контейнеріндегі мәнді шығарады.
    ///
    /// Бұл әдіс, ең алдымен, мәндерді біртіндеп шығаруға арналған.
    /// Мәнді қолмен түсіру үшін [`ManuallyDrop::drop`] пайдаланудың орнына, мәнді қабылдау және оны қалағанынша пайдалану үшін осы әдісті қолдануға болады.
    ///
    /// Мүмкіндігінше оның орнына [`into_inner`][`ManuallyDrop::into_inner`] қолданған жөн, бұл `ManuallyDrop<T>` мазмұнын қайталауға жол бермейді.
    ///
    ///
    /// # Safety
    ///
    /// Бұл функция мазмұнды одан әрі пайдалануға кедергі келтірмей, контейнер күйін өзгеріссіз қалдырады.
    /// Осы `ManuallyDrop` қайтадан пайдаланылмауын қамтамасыз ету сіздің жауапкершілігіңізде.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // ҚАУІПСІЗДІК: біз анықтамалықтан оқып отырмыз, оған кепілдік беріледі
        // оқуға жарамды болуы керек.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Құрамындағы мәнді қолмен түсіреді.Бұл [`ptr::drop_in_place`]-ді көрсетілген мәнге сілтегішпен шақыруға барабар.
    /// Осылайша, егер қамтылған мән жинақталған құрылым болмаса, деструктор мәнді жылжытпай-ақ орнына шақырылады және осылайша [pinned] деректерін қауіпсіз түрде тастауға болады.
    ///
    /// Егер сізде құндылыққа иелік етілсе, оның орнына [`ManuallyDrop::into_inner`] қолдануға болады.
    ///
    /// # Safety
    ///
    /// Бұл функция деструкторды қамтиды.
    /// Деструктордың өзі жасаған өзгертулерден басқа, жады өзгеріссіз қалады, ал компиляторға қатысты `T` типіне жарамды биттік өрнек сақталады.
    ///
    ///
    /// Алайда, бұл "zombie" мәні қауіпсіз кодқа ұшырамауы керек және бұл функция бірнеше рет шақырылмауы керек.
    /// Мәнді құлатқаннан кейін пайдалану немесе мәнді бірнеше рет түсіру үшін анықталмаған мінез-құлық туындауы мүмкін (`drop` жасағанына байланысты).
    /// Әдетте бұны типтік жүйе алдын алады, бірақ `ManuallyDrop` қолданушылары компилятордың көмегінсіз осы кепілдіктерді сақтауы керек.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // ҚАУІПСІЗДІК: біз өзгеретін сілтеме көрсеткен мәнді тастаймыз
        // жазбаларға жарамды екендігіне кепілдік беріледі.
        // `slot`-тің қайта құлатылмауын тексеру қоңырау шалушының қолында.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}