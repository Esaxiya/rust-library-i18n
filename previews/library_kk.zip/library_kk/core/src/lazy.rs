//! Жалқау мәндер және статикалық деректердің бір реттік инициализациясы.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Бір рет жазуға болатын ұяшық.
///
/// `RefCell`-тен айырмашылығы, `OnceCell` тек оның мәніне ортақ `&T` сілтемелерін ұсынады.
/// `Cell`-тен айырмашылығы, `OnceCell` оған қол жеткізу үшін мәнді көшіруді немесе ауыстыруды қажет етпейді.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Инвариант: ең көп дегенде бір рет жазылады.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Жаңа бос ұяшық жасайды.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Негізгі мәнге сілтеме алады.
    ///
    /// Ұяшық бос болса, `None` қайтарады.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // ҚАУІПСІЗДІК: «ішкі» инвариантты болғандықтан қауіпсіз
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Негізгі мәнге өзгермелі сілтеме алады.
    ///
    /// Ұяшық бос болса, `None` қайтарады.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // ҚАУІПСІЗДІК: Қауіпсіз, өйткені бізде бірегей қол жетімділік бар
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Ұяшықтың мазмұнын `value` деңгейіне қояды.
    ///
    /// # Errors
    ///
    /// Бұл әдіс ұяшық бос болса `Ok(())`, ал егер ол толы болса `Err(value)` береді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // ҚАУІПСІЗДІК: Қауіпсіз, өйткені біз өзгеретін қарыздарды ала алмаймыз
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // ҚАУІПСІЗДІК: Бұл біз ұяны орнататын жалғыз орын, ешқандай жарыстар жоқ
        // reentrancy/concurrency-ге байланысты болуы мүмкін және біз қазір ұяшық `None` екенін тексердік, сондықтан бұл жазу «ішкі» инвариантты қолдайды.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Ұяшықтың мазмұнын алады, егер ұяшық бос болса, оны `f` арқылы бастайды.
    ///
    /// # Panics
    ///
    /// Егер `f` panics болса, panic қоңырау шалушыға таралады, ал ұяшық инициализацияланбаған күйінде қалады.
    ///
    ///
    /// Ұяшықты `f`-тен инициализациялау қате болып табылады.Мұны істеу panic пайда болады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Ұяшықтың мазмұнын алады, егер ұяшық бос болса, оны `f` арқылы бастайды.
    /// Егер ұяшық бос болса және `f` сәтсіз болса, қате қайтарылады.
    ///
    /// # Panics
    ///
    /// Егер `f` panics болса, panic қоңырау шалушыға таралады, ал ұяшық инициализацияланбаған күйінде қалады.
    ///
    ///
    /// Ұяшықты `f`-тен инициализациялау қате болып табылады.Мұны істеу panic пайда болады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Қайта табысты инициализациялаудың *кейбір* нысандары UB-ге әкелуі мүмкін екенін ескеріңіз (`reentrant_init` тестін қараңыз).
        // Мен бұл `assert`-ті алып тастаған кезде, `set/get`-ті сақтау дұрыс болар еді деп ойлаймын, бірақ ескі мәнді үнсіз пайдаланғаннан гөрі, panic үшін жақсы сияқты.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Оралған мәнді қайтарып, ұяшықты тұтынады.
    ///
    /// Егер ұяшық бос болса, `None` мәнін қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // `into_inner` мәні бойынша `self` қабылдайтын болғандықтан, компилятор оның қарызға алынбағанын статикалық түрде тексереді.
        // Сондықтан `Option<T>`-тен көшуге болады.
        self.inner.into_inner()
    }

    /// Осы `OnceCell` мәнін алып, оны инициализацияланбаған күйге келтіреді.
    ///
    /// Егер `OnceCell` инициалданбаған болса, әсер етпейді және `None` қайтарады.
    ///
    /// Қауіпсіздікке өзгертілетін анықтама қажет болғандықтан кепілдік беріледі.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Бірінші қатынас кезінде инициализацияланған мән.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   инициализацияға дайын
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Берілген инициалдау функциясымен жаңа жалқау мән жасайды.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Осы жалқау мәнді бағалауға мәжбүр етеді және нәтижеге сілтеме береді.
    ///
    ///
    /// Бұл `Deref` импл-баламасына сәйкес келеді, бірақ нақты болып табылады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Іске қосу функциясы ретінде `Default` пайдаланып, жаңа жалқау мән жасайды.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}