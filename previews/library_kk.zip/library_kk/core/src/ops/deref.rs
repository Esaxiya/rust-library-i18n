/// `*v` сияқты өзгермейтін дериферация операциялары үшін қолданылады.
///
/// Х01X `*` операторымен өзгермейтін контексттерде анық дерерификациялау операциялары үшін пайдаланудан басқа, `Deref` көптеген жағдайларда компилятормен жанама түрде қолданылады.
/// Бұл механизм ['`Deref` coercion'][more] деп аталады.
/// Өзгермелі контекстте [`DerefMut`] қолданылады.
///
/// Ақылды көрсеткіштерге арналған `Deref`-ті қолдану олардың артындағы деректерге қол жеткізуді ыңғайлы етеді, сондықтан олар `Deref`-ті қолданады.
/// Екінші жағынан, `Deref` және [`DerefMut`] қатысты ережелер ақылды көрсеткіштерді орналастыру үшін арнайы жасалған.
/// Осыған байланысты **`Deref` шатастырмау үшін тек ақылды көрсеткіштер үшін** қолданылуы керек.
///
/// Осындай себептермен **бұл trait ешқашан сәтсіздікке ұшырамауы керек**.Кезеңсіздіктегі сәтсіздік `Deref`-ті тікелей шақырған кезде өте түсініксіз болуы мүмкін.
///
/// # `Deref` мәжбүрлеу туралы толығырақ
///
/// Егер `T` `Deref<Target = U>`-ті іске асырса, ал `x`-бұл `T` типті мән болса, онда:
///
/// * Өзгермейтін контексттерде `*x` (мұндағы `T` сілтеме де, шикі нұсқаушы да емес) `* Deref::deref(&x)` мәніне тең.
/// * `&T` типті мәндер `&U` типті мәндерге мәжбүр етіледі
/// * `T` `U` типіндегі барлық (immutable) әдістерін жасырын түрде жүзеге асырады.
///
/// Қосымша мәлімет алу үшін [the chapter in *The Rust Programming Language*][book], сонымен қатар [the dereference operator][ref-deref-op], [method resolution] және [type coercions] сілтемелер бөлімдерін қараңыз.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Бір өрісті құрылым, оған құрылымды анықтау арқылы қол жеткізуге болады.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Деректерді анықтағаннан кейінгі нәтиже.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Мәнді анықтайды.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;` сияқты өзгертілетін дериферация операциялары үшін қолданылады.
///
/// Х01X `*` операторымен өзгермелі контекстте анық дерерификациялау операциялары үшін пайдаланумен қатар, `DerefMut` көптеген жағдайларда компилятормен жанама түрде қолданылады.
/// Бұл механизм ['`Deref` coercion'][more] деп аталады.
/// Өзгермейтін контексттерде [`Deref`] қолданылады.
///
/// Ақылды көрсеткіштерге арналған `DerefMut`-ті енгізу олардың артындағы деректердің мутациясын ыңғайлы етеді, сондықтан олар `DerefMut`-ті қолданады.
/// Екінші жағынан, [`Deref`] және `DerefMut` қатысты ережелер ақылды көрсеткіштерді орналастыру үшін арнайы жасалған.
/// Осыған байланысты **«DerefMut» шатастырмау үшін тек ақылды көрсеткіштер үшін** қолданылуы керек.
///
/// Осындай себептермен **бұл trait ешқашан сәтсіздікке ұшырамауы керек**.Кезеңсіздіктегі сәтсіздік `DerefMut`-ті тікелей шақырған кезде өте түсініксіз болуы мүмкін.
///
/// # `Deref` мәжбүрлеу туралы толығырақ
///
/// Егер `T` `DerefMut<Target = U>`-ті іске асырса, ал `x`-бұл `T` типті мән болса, онда:
///
/// * Өзгеретін контексттерде `*x` (мұндағы `T` сілтеме де, шикі нұсқаушы да емес) `* DerefMut::deref_mut(&mut x)` эквивалентіне тең.
/// * `&mut T` типті мәндер `&mut U` типті мәндерге мәжбүр етіледі
/// * `T` `U` типіндегі барлық (mutable) әдістерін жасырын түрде жүзеге асырады.
///
/// Қосымша мәлімет алу үшін [the chapter in *The Rust Programming Language*][book], сонымен қатар [the dereference operator][ref-deref-op], [method resolution] және [type coercions] сілтемелер бөлімдерін қараңыз.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Құрылымды өзгертуге болатын өзгертілетін бір өрісті құрылым.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Өзгеріссіз мән.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Құрылымды `arbitrary_self_types` функциясынсыз әдісті қабылдағыш ретінде пайдалануға болатындығын көрсетеді.
///
/// Мұны stdlib `Box<T>`, `Rc<T>`, `&T` және `Pin<P>` сияқты типтері жүзеге асырады.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}