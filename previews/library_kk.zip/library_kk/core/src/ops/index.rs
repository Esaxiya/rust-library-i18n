/// (`container[index]`) операцияларын өзгермейтін контексттерде индекстеу үшін қолданылады.
///
/// `container[index]` бұл `*container.index(index)` үшін синтаксистік қант, бірақ өзгермейтін құндылық ретінде қолданылғанда ғана.
/// Егер өзгертілетін мән сұралса, оның орнына [`IndexMut`] қолданылады.
/// Бұл `let value = v[index]` сияқты жағымды нәрселерге мүмкіндік береді, егер `value` типі [`Copy`]-ті жүзеге асырса.
///
/// # Examples
///
/// Келесі мысал `Index`-ді тек оқуға арналған `NucleotideCount` контейнеріне енгізеді, бұл жеке санақтарды индекс синтаксисімен алуға мүмкіндік береді.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Индекстеуден кейін қайтарылған тип.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Индекстеу (`container[index]`) жұмысын орындайды.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// (`container[index]`) операцияларын өзгермелі жағдайда индекстеу үшін қолданылады.
///
/// `container[index]` бұл шын мәнінде `*container.index_mut(index)` үшін синтаксистік қант, бірақ өзгермелі мән ретінде қолданылғанда ғана.
/// Егер өзгермейтін мән сұралса, оның орнына [`Index`] trait қолданылады.
/// Бұл `v[index] = value` сияқты жақсы нәрселерге мүмкіндік береді.
///
/// # Examples
///
/// Екі жағы бар, әрқайсысы өзгермейтін және өзгермейтін индекстелетін `Balance` құрылымын өте қарапайым жүзеге асыру.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Бұл жағдайда `balance[Side::Right]`-бұл `*balance.index(Side::Right)` үшін қант, өйткені біз оны жазбай*`balance[Side::Right]` ты *оқып* жатырмыз.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Алайда, бұл жағдайда `balance[Side::Left]`-бұл `*balance.index_mut(Side::Left)` үшін қант, өйткені біз `balance[Side::Left]` жазып жатырмыз.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Өзгеретін индекстеу (`container[index]`) жұмысын орындайды.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}