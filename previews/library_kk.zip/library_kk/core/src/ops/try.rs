/// `?` операторының әрекетін реттеуге арналған trait.
///
/// `Try`-ті іске асыратын тип-оны success/failure дихотомиясы тұрғысынан қараудың канондық тәсілі.
/// Бұл trait сәтсіздік немесе сәтсіздік мәндерін бар данадан шығаруға да, сәтсіздік немесе сәтсіздік мәнінен жаңа дананы жасауға мүмкіндік береді.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Бұл мәннің түрі сәтті деп саналғанда.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Бұл мәннің сәтсіз болған түрі.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" операторын қолданады.`Ok(t)` қайтарымы орындалудың қалыпты түрде жалғасуын білдіреді, ал `?` нәтижесі-`t` мәні.
    /// `Err(e)`-тің қайтарылуы branch-ті `catch`-нің ішкі аймағына немесе функциясынан оралуы керек дегенді білдіреді.
    ///
    /// Егер `Err(e)` нәтижесі қайтарылса, `e` мәні қоршау ауқымының қайтару түрінде "wrapped" болады (ол `Try`-ті қолдануы керек).
    ///
    /// Нақтырақ айтқанда, `X::from_error(From::from(e))` мәні қайтарылады, мұндағы `X`-қоршау функциясының қайтару түрі.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Композиттік нәтижені құру үшін қате мәнін ораңыз.
    /// Мысалы, `Result::Err(x)` және `Result::from_error(x)` эквивалентті болып табылады.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Композиттік нәтижені құру үшін OK мәнін ораңыз.
    /// Мысалы, `Result::Ok(x)` және `Result::from_ok(x)` эквивалентті болып табылады.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}