/// Өзгермейтін қабылдағышты қабылдайтын байланыс операторының нұсқасы.
///
/// `Fn` даналарын мутация күйінсіз бірнеше рет атауға болады.
///
/// *Бұл trait (`Fn`) пен [function pointers] (`fn`)-ті шатастыруға болмайды.*
///
/// `Fn` автоматты түрде жабылатын айнымалыларға өзгермейтін сілтемелер беретін немесе ешнәрсе түсірмейтін, сондай-ақ (safe) [function pointers] жабылуымен жүзеге асырылады (кейбір ескертулермен, толығырақ олардың құжаттамасынан қараңыз).
///
/// Сонымен қатар, `Fn`-ті іске асыратын кез-келген `F` түрі үшін `&F` да `Fn`-ті қолданады.
///
/// [`FnMut`] және [`FnOnce`] екеуі де `Fn` супертрайттары болғандықтан, `Fn` кез-келген данасын [`FnMut`] немесе [`FnOnce`] күтілетін параметр ретінде пайдалануға болады.
///
/// Функцияға ұқсас типтегі параметрді қабылдағыңыз келген кезде және оны бірнеше рет және мутациясыз күйде шақыру қажет болғанда (мысалы, оны бір уақытта шақырған кезде) байланыстырушы ретінде пайдаланыңыз.
/// Егер сізге мұндай қатаң талаптар қажет болмаса, [`FnMut`] немесе [`FnOnce`] шектері ретінде қолданыңыз.
///
/// Осы тақырып бойынша қосымша ақпарат алу үшін [chapter on closures in *The Rust Programming Language*][book] қараңыз.
///
/// Сонымен қатар, `Fn` traits үшін арнайы синтаксис (мысалы
/// `Fn(usize, bool) -> usize`).Мұның техникалық мәліметтеріне қызығушылық танытқандар [the relevant section in the *Rustonomicon*][nomicon] сілтемесіне жүгіне алады.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Жабуды шақыру
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` параметрін қолдану
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // сондықтан regex сол `&str: !FnMut`-ке сене алады
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Қоңырау шалу әрекетін орындайды.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Өзгеретін қабылдағыш қабылдайтын қоңырау операторының нұсқасы.
///
/// `FnMut` даналарын бірнеше рет шақыруға болады және күйді өзгерте алады.
///
/// `FnMut` алынған айнымалыларға, сондай-ақ [`Fn`]-ті жүзеге асыратын барлық типтерге өзгертілетін сілтеме жасайтын жабулар арқылы автоматты түрде жүзеге асырылады (мысалы, `FnMut`-[`Fn`] супертрейті).
/// Сонымен қатар, `FnMut`-ті іске асыратын кез-келген `F` түрі үшін `&mut F` да `FnMut`-ті қолданады.
///
/// [`FnOnce`]-бұл `FnMut` супертрейті болғандықтан, `FnMut` кез-келген данасын [`FnOnce`] күтілетін жерде қолдануға болады, ал [`Fn`]-`FnMut` субтрейті болғандықтан, `FnMut` кез-келген данасын `FnMut` күтілетін жерде қолдануға болады.
///
/// Функцияға ұқсас типтің параметрін қабылдағыңыз келген кезде және оны мутация күйіне келтіре отырып, қайта-қайта қоңырау шалу керек болғанда, `FnMut` мәнін шектеу ретінде пайдаланыңыз.
/// Егер сіз параметрдің күйін өзгерткенін қаламасаңыз, [`Fn`] мәнін шектеу ретінде пайдаланыңыз;егер сізге бірнеше рет қоңырау шалудың қажеті болмаса, [`FnOnce`] пайдаланыңыз.
///
/// Осы тақырып бойынша қосымша ақпарат алу үшін [chapter on closures in *The Rust Programming Language*][book] қараңыз.
///
/// Сонымен қатар, `Fn` traits үшін арнайы синтаксис (мысалы
/// `Fn(usize, bool) -> usize`).Мұның техникалық мәліметтеріне қызығушылық танытқандар [the relevant section in the *Rustonomicon*][nomicon] сілтемесіне жүгіне алады.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Толығымен жабылатын жабу деп аталады
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` параметрін пайдалану
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // сондықтан regex сол `&str: !FnMut`-ке сене алады
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Қоңырау шалу әрекетін орындайды.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Қосымша қабылдағышты қабылдайтын қоңырау операторының нұсқасы.
///
/// `FnOnce` даналарын шақыруға болады, бірақ бірнеше рет шақыруға болмауы мүмкін.Осыған байланысты, егер тип туралы тек `FnOnce`-ті жүзеге асыратыны белгілі болса, оны тек бір рет атауға болады.
///
/// `FnOnce` алынған айнымалыларды, сондай-ақ [`FnMut`]-ті іске асыратын барлық типтерді жабу арқылы автоматты түрде жүзеге асырылады, мысалы, (safe) [function pointers] (`FnOnce`-бұл [`FnMut`] супертрейті болғандықтан).
///
///
/// [`Fn`] және [`FnMut`] екеуі де `FnOnce` субтрейтрі болғандықтан, [`Fn`] немесе [`FnMut`] кез-келген данасын `FnOnce` күтілетін жерде пайдалануға болады.
///
/// Функцияға ұқсас типтегі параметрді қабылдағыңыз келген кезде және оны тек бір рет шақыру керек болғанда, `FnOnce`-ті шектеу ретінде пайдаланыңыз.
/// Егер сізге параметрді қайталап шақыру қажет болса, [`FnMut`] байланыстырылған ретінде пайдаланыңыз;егер сізге күйді өзгертпеу үшін қажет болса, [`Fn`] пайдаланыңыз.
///
/// Осы тақырып бойынша қосымша ақпарат алу үшін [chapter on closures in *The Rust Programming Language*][book] қараңыз.
///
/// Сонымен қатар, `Fn` traits үшін арнайы синтаксис (мысалы
/// `Fn(usize, bool) -> usize`).Мұның техникалық мәліметтеріне қызығушылық танытқандар [the relevant section in the *Rustonomicon*][nomicon] сілтемесіне жүгіне алады.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` параметрін қолдану
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` өзінің алынған айнымалыларын тұтынады, сондықтан оны бірнеше рет іске қосу мүмкін емес.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()`-ті қайта шақыруға тырысу `func` үшін `use of moved value` қатесін жібереді.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` енді осы уақытта шақыруға болмайды
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // сондықтан regex сол `&str: !FnMut`-ке сене алады
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Қоңырау шалу операторынан кейін қайтарылған тип қолданылады.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Қоңырау шалу әрекетін орындайды.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}