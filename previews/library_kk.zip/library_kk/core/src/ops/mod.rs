//! Шамадан тыс жүктелетін операторлар.
//!
//! Осы traits-ті іске асыру белгілі бір операторларға шамадан тыс жүктеме жасауға мүмкіндік береді.
//!
//! Осы traits-дің кейбіреулері prelude арқылы импортталады, сондықтан олар әр Rust бағдарламасында қол жетімді.Тек traits қолдайтын операторларға шамадан тыс жүктеме жүктелуі мүмкін.
//! Мысалы, (`+`) қосу операторы [`Add`] trait арқылы шамадан тыс жүктелуі мүмкін, бірақ (`=`) тағайындау операторында trait тірегі жоқ болғандықтан, оның семантикасын шамадан тыс жүктеу мүмкіндігі жоқ.
//! Сонымен қатар, бұл модуль жаңа операторларды құрудың ешқандай механизмін ұсынбайды.
//! Егер артық жүктеме немесе теңшелетін операторлар қажет болса, сіз Rust синтаксисін кеңейту үшін макростарға немесе компилятор плагиндеріне жүгінуіңіз керек.
//!
//! traits операторын енгізу әдеттегі мағыналары мен [operator precedence]-ті ескере отырып, сәйкесінше таңқаларлық болмауы керек.
//! Мысалы, [`Mul`]-ті енгізу кезінде операция көбейтуге ұқсас болуы керек (және ассоциативтілік сияқты күтілетін қасиеттерді бөлісу керек).
//!
//! `&&` және `||` операторларының қысқа тұйықталуы, яғни олар екінші операндты нәтижеге ықпал еткен жағдайда ғана бағалайтынын ескеріңіз.Бұл әрекетті traits қолдана алмайтындықтан, `&&` және `||` шамадан тыс жүктелетін операторлар ретінде қолданылмайды.
//!
//! Операторлардың көпшілігі өз операндаларын мәні бойынша қабылдайды.Кіріктірілген типтерге қатысты жалпы емес контексттерде бұл әдетте қиындық тудырмайды.
//! Алайда, бұл операторларды жалпы кодта пайдалану, егер операторлардың оларды тұтынуына жол бермей, мәндерді қайта пайдалану қажет болса, біраз назар аударуды қажет етеді.Опциялардың бірі-кейде [`clone`] пайдалану.
//! Тағы бір нұсқа-сілтемелер үшін қосымша операторлық енгізулерді ұсынатын түрлерге сену.
//! Мысалы, қосымшаны қолдайтын `T` пайдаланушы анықтаған тип үшін, `T` пен `&T` екеуінің де traits [`Add<T>`][`Add`] және [`Add<&T>`][`Add`]-ті қолданған жөн, осылайша жалпы код қажетсіз жазусыз жазылуы мүмкін.
//!
//!
//! # Examples
//!
//! Бұл мысал [`Add`] және [`Sub`]-ті жүзеге асыратын `Point` құрылымын жасайды, содан кейін екі `Point`-ті қосу мен азайтуды көрсетеді.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Мысал енгізу үшін әр trait үшін құжаттаманы қараңыз.
//!
//! [`Fn`], [`FnMut`] және [`FnOnce`] traits функциялары сияқты шақырылатын типтер бойынша жүзеге асырылады.[`Fn`]-`&self`, [`FnMut`]-`&mut self`, [`FnOnce`]-`self` қабылдайтынын ескеріңіз.
//! Бұл даналарға шақырылатын әдістердің үш түріне сәйкес келеді: сілтеме бойынша шақыру, өзгертілетін сілтеме және шақыру бойынша мән.
//! Осы traits-дің ең көп таралған қолданысы функцияларды немесе жабылуларды аргумент ретінде қабылдайтын жоғары деңгейлі функциялардың шекарасы ретінде әрекет ету болып табылады.
//!
//! Параметр ретінде [`Fn`] қабылдау:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Параметр ретінде [`FnMut`] қабылдау:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Параметр ретінде [`FnOnce`] қабылдау:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` өзінің алынған айнымалыларын тұтынады, сондықтан оны бірнеше рет іске қосу мүмкін емес
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()`-ті қайта шақыруға тырысу `func` үшін `use of moved value` қатесін жібереді
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` енді осы уақытта шақыруға болмайды
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;