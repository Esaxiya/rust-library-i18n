//! Компилятор ішкі.
//!
//! Тиісті анықтамалар `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Сәйкес конструкциялар `compiler/rustc_mir/src/interpret/intrinsics.rs`-ге сәйкес келеді
//!
//! # Тұрақты ішкі заттар
//!
//! Note: ішкі заттардың тұрақтылығына қатысты кез-келген өзгерістерді тіл тобымен талқылау қажет.
//! Бұған қаттылық тұрақтылығының өзгеруі жатады.
//!
//! Компиляция кезінде меншікті қол жетімді ету үшін іске асыруды <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs>-тен `compiler/rustc_mir/src/interpret/intrinsics.rs`-ке көшіріп, ішкіге `#[rustc_const_unstable(feature = "foo", issue = "01234")]` қосу керек.
//!
//!
//! Егер ішкі `const fn` атрибутымен `const fn`-тен қолданылуы керек болса, меншікті атрибут `rustc_const_stable` болуы керек.
//! Мұндай өзгерісті T-lang консультациясынсыз жасамау керек, өйткені ол компилятордың қолдауынсыз қолданушы кодында қайталанбайтын мүмкіндікті тілге қосады.
//!
//! # Volatiles
//!
//! Өзгермелі ішкі элементтер I/O жадында жұмыс істеуге арналған операцияларды қамтамасыз етеді, оларды басқа ұшпа ішкі жүйелер бойынша компилятор қайта реттемеуге кепілдік береді.[[volatile]]-те LLVM құжаттамасын қараңыз.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Атомдық меншіктеу машинада қолданылатын бірнеше рет орындалатын атомдық операцияларды қамтамасыз етеді.Олар C++ 11 сияқты семантикаларға бағынады.[[atomics]]-те LLVM құжаттамасын қараңыз.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Жадыны тапсырыс бойынша жылдам жаңарту:
//!
//! * Құлып алу үшін тосқауыл алыңыз.Кейінгі оқулар мен жазулар тосқауылдан кейін орын алады.
//! * Босату, құлыпты босатуға арналған тосқауыл.Алдыңғы оқулар мен жазулар кедергіден бұрын орын алады.
//! * Тізбектелген дәйекті, дәйекті дәйекті операциялардың ретімен орындалуына кепілдік беріледі.Бұл атомдық типтермен жұмыс істеудің стандартты режимі және Java `volatile`-ге тең.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Бұл импорт құжаттардың ішкі сілтемелерін жеңілдету үшін қолданылады
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // ҚАУІПСІЗДІК: `ptr::drop_in_place` қараңыз
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // Ескерту: бұл ішкі заттар шикі көрсеткіштерді алады, өйткені олар `&` үшін де, `&mut` үшін де жарамсыз жадты өзгертеді.
    //

    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange` әдісі арқылы [`Ordering::SeqCst`] ті `success` және `failure` параметрлері ретінде беру арқылы қол жетімді.
    ///
    /// Мысалға, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange` әдісі арқылы [`Ordering::Acquire`] ті `success` және `failure` параметрлері ретінде беру арқылы қол жетімді.
    ///
    /// Мысалға, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange` әдісі арқылы [`Ordering::Release`]-`success` және [`Ordering::Relaxed`]-`failure` параметрлері арқылы қол жетімді.
    /// Мысалға, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange` әдісі арқылы [`Ordering::AcqRel`]-`success` және [`Ordering::Acquire`]-`failure` параметрлері арқылы қол жетімді.
    /// Мысалға, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange` әдісі арқылы [`Ordering::Relaxed`] ті `success` және `failure` параметрлері ретінде беру арқылы қол жетімді.
    ///
    /// Мысалға, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл тұрақтылық нұсқасы [`atomic`] типтерінде `compare_exchange` әдісі арқылы [`Ordering::SeqCst`]-`success` және [`Ordering::Relaxed`]-`failure` параметрлері арқылы қол жетімді.
    /// Мысалға, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange` әдісі арқылы [`Ordering::SeqCst`]-`success` және [`Ordering::Acquire`]-`failure` параметрлері арқылы қол жетімді.
    /// Мысалға, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange` әдісі арқылы [`Ordering::Acquire`]-`success` және [`Ordering::Relaxed`]-`failure` параметрлері арқылы қол жетімді.
    /// Мысалға, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange` әдісі арқылы [`Ordering::AcqRel`]-`success` және [`Ordering::Relaxed`]-`failure` параметрлері арқылы қол жетімді.
    /// Мысалға, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл тұрақтылық нұсқасы [`atomic`] типтерінде `compare_exchange_weak` әдісі арқылы [`Ordering::SeqCst`]-ті `success` және `failure` параметрлері ретінде беру арқылы қол жетімді.
    ///
    /// Мысалға, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange_weak` әдісі арқылы [`Ordering::Acquire`] ті `success` және `failure` параметрлері ретінде беру арқылы қол жетімді.
    ///
    /// Мысалға, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange_weak` әдісі арқылы [`Ordering::Release`]-`success` және [`Ordering::Relaxed`]-`failure` параметрлері арқылы қол жетімді.
    /// Мысалға, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange_weak` әдісі арқылы [`Ordering::AcqRel`]-`success` және [`Ordering::Acquire`]-`failure` параметрлері арқылы қол жетімді.
    /// Мысалға, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange_weak` әдісі арқылы [`Ordering::Relaxed`] ті `success` және `failure` параметрлері ретінде беру арқылы қол жетімді.
    ///
    /// Мысалға, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange_weak` әдісі арқылы [`Ordering::SeqCst`]-`success` және [`Ordering::Relaxed`]-`failure` параметрлері арқылы қол жетімді.
    /// Мысалға, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange_weak` әдісі арқылы [`Ordering::SeqCst`]-`success` және [`Ordering::Acquire`]-`failure` параметрлері арқылы қол жетімді.
    /// Мысалға, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange_weak` әдісі арқылы [`Ordering::Acquire`]-`success` және [`Ordering::Relaxed`]-`failure` параметрлері арқылы қол жетімді.
    /// Мысалға, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ағымдағы мән `old` мәнімен бірдей болса, мәнді сақтайды.
    ///
    /// Бұл тұрақтандырылған нұсқасы [`atomic`] типтерінде `compare_exchange_weak` әдісі арқылы [`Ordering::AcqRel`]-`success` және [`Ordering::Relaxed`]-`failure` параметрлері арқылы қол жетімді.
    /// Мысалға, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Меңзердің ағымдағы мәнін жүктейді.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `load` әдісі арқылы [`Ordering::SeqCst`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Меңзердің ағымдағы мәнін жүктейді.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `load` әдісі арқылы [`Ordering::Acquire`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Меңзердің ағымдағы мәнін жүктейді.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `load` әдісі арқылы [`Ordering::Relaxed`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Көрсетілген жад орнында мәнді сақтайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `store` әдісі арқылы [`Ordering::SeqCst`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Көрсетілген жад орнында мәнді сақтайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `store` әдісі арқылы [`Ordering::Release`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Көрсетілген жад орнында мәнді сақтайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `store` әдісі арқылы [`Ordering::Relaxed`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Ескі мәнді қайтара отырып, берілген жад орнында мәнді сақтайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `swap` әдісі арқылы [`Ordering::SeqCst`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ескі мәнді қайтара отырып, берілген жад орнында мәнді сақтайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `swap` әдісі арқылы [`Ordering::Acquire`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ескі мәнді қайтара отырып, берілген жад орнында мәнді сақтайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `swap` әдісі арқылы [`Ordering::Release`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ескі мәнді қайтара отырып, берілген жад орнында мәнді сақтайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `swap` әдісі арқылы [`Ordering::AcqRel`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ескі мәнді қайтара отырып, берілген жад орнында мәнді сақтайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `swap` әдісі арқылы [`Ordering::Relaxed`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнге қосылады.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_add` әдісі арқылы [`Ordering::SeqCst`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнге қосылады.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_add` әдісі арқылы [`Ordering::Acquire`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнге қосылады.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_add` әдісі арқылы [`Ordering::Release`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнге қосылады.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_add` әдісі арқылы [`Ordering::AcqRel`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнге қосылады.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_add` әдісі арқылы [`Ordering::Relaxed`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәннен шығарыңыз.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_sub` әдісі арқылы [`Ordering::SeqCst`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәннен шығарыңыз.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_sub` әдісі арқылы [`Ordering::Acquire`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәннен шығарыңыз.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_sub` әдісі арқылы [`Ordering::Release`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәннен шығарыңыз.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_sub` әдісі арқылы [`Ordering::AcqRel`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәннен шығарыңыз.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_sub` әдісі арқылы [`Ordering::Relaxed`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ағымдағы мәнмен және алдыңғы мәнді қайтара отырып.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_and` әдісі арқылы [`Ordering::SeqCst`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ағымдағы мәнмен және алдыңғы мәнді қайтара отырып.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_and` әдісі арқылы [`Ordering::Acquire`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ағымдағы мәнмен және алдыңғы мәнді қайтара отырып.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_and` әдісі арқылы [`Ordering::Release`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ағымдағы мәнмен және алдыңғы мәнді қайтара отырып.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_and` әдісі арқылы [`Ordering::AcqRel`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ағымдағы мәнмен және алдыңғы мәнді қайтара отырып.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_and` әдісі арқылы [`Ordering::Relaxed`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнмен биттік nand.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`AtomicBool`] типінде `fetch_nand` әдісі арқылы [`Ordering::SeqCst`] арқылы `order` түрінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнмен биттік nand.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`AtomicBool`] типінде `fetch_nand` әдісі арқылы [`Ordering::Acquire`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнмен биттік nand.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`AtomicBool`] типінде `fetch_nand` әдісі арқылы [`Ordering::Release`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнмен биттік nand.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`AtomicBool`] типінде `fetch_nand` әдісі арқылы [`Ordering::AcqRel`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнмен биттік nand.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`AtomicBool`] типінде `fetch_nand` әдісі арқылы [`Ordering::Relaxed`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Битрайтты немесе ағымдағы мәнмен, алдыңғы мәнді қайтарады.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_or` әдісі арқылы [`Ordering::SeqCst`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Битрайтты немесе ағымдағы мәнмен, алдыңғы мәнді қайтарады.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_or` әдісі арқылы [`Ordering::Acquire`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Битрайтты немесе ағымдағы мәнмен, алдыңғы мәнді қайтарады.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_or` әдісі арқылы [`Ordering::Release`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Битрайтты немесе ағымдағы мәнмен, алдыңғы мәнді қайтарады.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_or` әдісі арқылы [`Ordering::AcqRel`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Битрайтты немесе ағымдағы мәнмен, алдыңғы мәнді қайтарады.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_or` әдісі арқылы [`Ordering::Relaxed`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнмен биттік жолмен.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_xor` әдісі арқылы [`Ordering::SeqCst`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнмен биттік жолмен.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_xor` әдісі арқылы [`Ordering::Acquire`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнмен биттік жолмен.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_xor` әдісі арқылы [`Ordering::Release`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнмен биттік жолмен.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_xor` әдісі арқылы [`Ordering::AcqRel`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнмен биттік жолмен.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] типтерінде `fetch_xor` әдісі арқылы [`Ordering::Relaxed`] арқылы `order` ретінде қол жетімді.
    /// Мысалға, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Қол қойылған салыстыруды қолдана отырып, ағымдағы мәнмен максимум.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] таңбалы бүтін типтерінде `fetch_max` әдісі арқылы [`Ordering::SeqCst`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылған салыстыруды қолдана отырып, ағымдағы мәнмен максимум.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] таңбалы бүтін типтерінде `fetch_max` әдісі арқылы [`Ordering::Acquire`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылған салыстыруды қолдана отырып, ағымдағы мәнмен максимум.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] таңбалы бүтін типтерінде `fetch_max` әдісі арқылы [`Ordering::Release`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылған салыстыруды қолдана отырып, ағымдағы мәнмен максимум.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] таңбалы бүтін типтерінде `fetch_max` әдісі арқылы [`Ordering::AcqRel`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ағымдағы мәнмен максимум.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] таңбалы бүтін типтерінде `fetch_max` әдісі арқылы [`Ordering::Relaxed`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Қол қойылған салыстыруды қолдана отырып, ағымдағы мәнмен минимум.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] таңбалы бүтін типтерінде `fetch_min` әдісі арқылы [`Ordering::SeqCst`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылған салыстыруды қолдана отырып, ағымдағы мәнмен минимум.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] таңбалы бүтін типтерінде `fetch_min` әдісі арқылы [`Ordering::Acquire`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылған салыстыруды қолдана отырып, ағымдағы мәнмен минимум.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] таңбалы бүтін типтерінде `fetch_min` әдісі арқылы [`Ordering::Release`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылған салыстыруды қолдана отырып, ағымдағы мәнмен минимум.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] таңбалы бүтін типтерінде `fetch_min` әдісі арқылы [`Ordering::AcqRel`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылған салыстыруды қолдана отырып, ағымдағы мәнмен минимум.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic`] таңбалы бүтін типтерінде `fetch_min` әдісі арқылы [`Ordering::Relaxed`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Қол қойылмаған салыстыруды қолдана отырып, ағымдағы мәнмен минимум.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы [`atomic`] белгісіз бүтін типтерінде `fetch_min` әдісі арқылы [`Ordering::SeqCst`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылмаған салыстыруды қолдана отырып, ағымдағы мәнмен минимум.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы [`atomic`] белгісіз бүтін типтерінде `fetch_min` әдісі арқылы [`Ordering::Acquire`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылмаған салыстыруды қолдана отырып, ағымдағы мәнмен минимум.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы [`atomic`] белгісіз бүтін типтерінде `fetch_min` әдісі арқылы [`Ordering::Release`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылмаған салыстыруды қолдана отырып, ағымдағы мәнмен минимум.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы [`atomic`] белгісіз бүтін типтерінде `fetch_min` әдісі арқылы [`Ordering::AcqRel`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылмаған салыстыруды қолдана отырып, ағымдағы мәнмен минимум.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы [`atomic`] белгісіз бүтін типтерінде `fetch_min` әдісі арқылы [`Ordering::Relaxed`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Қол қойылмаған салыстыруды қолдана отырып, ағымдағы мәнмен максимум.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы [`atomic`] белгісіз бүтін типтерінде `fetch_max` әдісі арқылы [`Ordering::SeqCst`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылмаған салыстыруды қолдана отырып, ағымдағы мәнмен максимум.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы [`atomic`] белгісіз бүтін типтерінде `fetch_max` әдісі арқылы [`Ordering::Acquire`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылмаған салыстыруды қолдана отырып, ағымдағы мәнмен максимум.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы [`atomic`] белгісіз бүтін типтерінде `fetch_max` әдісі арқылы [`Ordering::Release`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылмаған салыстыруды қолдана отырып, ағымдағы мәнмен максимум.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы [`atomic`] белгісіз бүтін типтерінде `fetch_max` әдісі арқылы [`Ordering::AcqRel`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Қол қойылмаған салыстыруды қолдана отырып, ағымдағы мәнмен максимум.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы [`atomic`] белгісіз бүтін типтерінде `fetch_max` әдісі арқылы [`Ordering::Relaxed`]-ті `order` ретінде алуға болады.
    /// Мысалға, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ішкі `prefetch`-код генераторына қолдау көрсетілсе, алдын ала жүктеу нұсқауын енгізу туралы нұсқаулық;әйтпесе, бұл тыйым салынады.
    /// Алдын ала жүктеу бағдарламаның жұмысына әсер етпейді, бірақ оның жұмыс сипаттамаларын өзгерте алады.
    ///
    /// `locality` аргументі тұрақты бүтін сан болуы керек және (0)-тан бастап, жергілікті емес, (3)-қа дейінгі, уақытша жергілікті анықтаушы болып табылады, бұл өте кэште сақталады.
    ///
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Ішкі `prefetch`-код генераторына қолдау көрсетілсе, алдын ала жүктеу нұсқауын енгізу туралы нұсқаулық;әйтпесе, бұл тыйым салынады.
    /// Алдын ала жүктеу бағдарламаның жұмысына әсер етпейді, бірақ оның жұмыс сипаттамаларын өзгерте алады.
    ///
    /// `locality` аргументі тұрақты бүтін сан болуы керек және (0)-тан бастап, жергілікті емес, (3)-қа дейінгі, уақытша жергілікті анықтаушы болып табылады, бұл өте кэште сақталады.
    ///
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Ішкі `prefetch`-код генераторына қолдау көрсетілсе, алдын ала жүктеу нұсқауын енгізу туралы нұсқаулық;әйтпесе, бұл тыйым салынады.
    /// Алдын ала жүктеу бағдарламаның жұмысына әсер етпейді, бірақ оның жұмыс сипаттамаларын өзгерте алады.
    ///
    /// `locality` аргументі тұрақты бүтін сан болуы керек және (0)-тан бастап, жергілікті емес, (3)-қа дейінгі, уақытша жергілікті анықтаушы болып табылады, бұл өте кэште сақталады.
    ///
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Ішкі `prefetch`-код генераторына қолдау көрсетілсе, алдын ала жүктеу нұсқауын енгізу туралы нұсқаулық;әйтпесе, бұл тыйым салынады.
    /// Алдын ала жүктеу бағдарламаның жұмысына әсер етпейді, бірақ оның жұмыс сипаттамаларын өзгерте алады.
    ///
    /// `locality` аргументі тұрақты бүтін сан болуы керек және (0)-тан бастап, жергілікті емес, (3)-қа дейінгі, уақытша жергілікті анықтаушы болып табылады, бұл өте кэште сақталады.
    ///
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Атом қоршауы.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic::fence`]-те [`Ordering::SeqCst`] арқылы `order` ретінде қол жетімді.
    ///
    ///
    pub fn atomic_fence();
    /// Атом қоршауы.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic::fence`]-те [`Ordering::Acquire`] арқылы `order` ретінде қол жетімді.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Атом қоршауы.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic::fence`]-те [`Ordering::Release`] арқылы `order` ретінде қол жетімді.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Атом қоршауы.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic::fence`]-те [`Ordering::AcqRel`] арқылы `order` ретінде қол жетімді.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Тек компиляторға арналған жады кедергісі.
    ///
    /// Компилятор жадыға кіруді ешқашан бұл тосқауыл арқылы қайта реттемейді, бірақ ол үшін ешқандай нұсқаулық шығарылмайды.
    /// Бұл алдын-ала ойластырылуы мүмкін бір жіптегі операцияларға, мысалы, сигнал өңдеушілерімен өзара әрекеттесуге сәйкес келеді.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic::compiler_fence`]-те [`Ordering::SeqCst`] арқылы `order` ретінде қол жетімді.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Тек компиляторға арналған жады кедергісі.
    ///
    /// Компилятор жадыға кіруді ешқашан бұл тосқауыл арқылы қайта реттемейді, бірақ ол үшін ешқандай нұсқаулық шығарылмайды.
    /// Бұл алдын-ала ойластырылуы мүмкін бір жіптегі операцияларға, мысалы, сигнал өңдеушілерімен өзара әрекеттесуге сәйкес келеді.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic::compiler_fence`]-те [`Ordering::Acquire`] арқылы `order` ретінде қол жетімді.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Тек компиляторға арналған жады кедергісі.
    ///
    /// Компилятор жадыға кіруді ешқашан бұл тосқауыл арқылы қайта реттемейді, бірақ ол үшін ешқандай нұсқаулық шығарылмайды.
    /// Бұл алдын-ала ойластырылуы мүмкін бір жіптегі операцияларға, мысалы, сигнал өңдеушілерімен өзара әрекеттесуге сәйкес келеді.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic::compiler_fence`]-те [`Ordering::Release`] арқылы `order` ретінде қол жетімді.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Тек компиляторға арналған жады кедергісі.
    ///
    /// Компилятор жадыға кіруді ешқашан бұл тосқауыл арқылы қайта реттемейді, бірақ ол үшін ешқандай нұсқаулық шығарылмайды.
    /// Бұл алдын-ала ойластырылуы мүмкін бір жіптегі операцияларға, мысалы, сигнал өңдеушілерімен өзара әрекеттесуге сәйкес келеді.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы [`atomic::compiler_fence`]-те [`Ordering::AcqRel`] арқылы `order` ретінде қол жетімді.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Сиқырлы ішкі, ол функцияға байланысты атрибуттардан шығады.
    ///
    /// Мысалы, деректер ағыны мұны статикалық мәлімдемелерді енгізу үшін пайдаланады, сондықтан `rustc_peek(potentially_uninitialized)` шынымен деректер ағынының басқару ағынының сол нүктесінде инициализацияланбағанын есептегенін екі рет тексереді.
    ///
    ///
    /// Бұл ішкі компилятордан тыс қолдануға болмайды.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Процестің орындалуын тоқтатады.
    ///
    /// Бұл операцияның ыңғайлы және тұрақты нұсқасы-[`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Оптимизаторға кодтағы осы тармақтың қол жетімді еместігі туралы хабарлайды, әрі қарай оңтайландыруға мүмкіндік береді.
    ///
    /// Ескерту: бұл `unreachable!()` макросынан өте өзгеше: panics орындалған кездегі макростан айырмашылығы, бұл функциямен белгіленген кодқа жету *анықталмаған тәртіп*.
    ///
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы-[`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Оптимизаторға шарттың әрқашан дұрыс болатындығын хабарлайды.
    /// Егер шарт жалған болса, мінез-құлық анықталмайды.
    ///
    /// Бұл ішкі үшін ешқандай код жасалмайды, бірақ оңтайландырушы оны (және оның күйін) сақтауға тырысады, бұл қоршаған кодты оңтайландыруға кедергі келтіруі және өнімділікті төмендетуі мүмкін.
    /// Егер инвариантты оңтайландырушы өздігінен таба алса немесе ол ешқандай оңтайландыруға мүмкіндік бермесе, оны қолдануға болмайды.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Компиляторға branch шарты дұрыс болатындығы туралы кеңестер береді.
    /// Оған берілген мәнді қайтарады.
    ///
    /// `if` мәлімдемелерінен басқа кез-келген қолдану әсер етпеуі мүмкін.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Компиляторға branch шарты жалған болуы мүмкін деген кеңестер береді.
    /// Оған берілген мәнді қайтарады.
    ///
    /// `if` мәлімдемелерінен басқа кез-келген қолдану әсер етпеуі мүмкін.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Түзеткіштің тексеру құралы үшін түзеткішті орындайды.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    pub fn breakpoint();

    /// Түрдің өлшемі байтпен.
    ///
    /// Нақтырақ айтсақ, бұл бірдей типтегі дәйекті элементтер арасындағы байтпен жылжу, соның ішінде туралауды толтыру.
    ///
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы-[`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Түрдің минималды туралануы.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы-[`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Түрдің қолайлы туралануы.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Сілтеме мәнінің байттағы өлшемі.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы-[`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Сілтеме мәнінің қажетті туралануы.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы-[`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Түрдің атын қамтитын статикалық жол кесіндісін алады.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы-[`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Көрсетілген түрге ғаламдық бірегей идентификаторды алады.
    /// Бұл функция қай crate шақырылғанына қарамастан тип үшін бірдей мән береді.
    ///
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы-[`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Егер `T` тұрғыны болмаса, ешқашан орындалмайтын қауіпті функциялар үшін күзетші:
    /// Бұл статикалық түрде не panic болады, не ештеңе істемейді.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Егер `T` нөлдік инициализацияға жол бермесе, ешқашан орындалмайтын қауіпті функциялардың күзеті: Бұл статикалық түрде не panic болады, не ештеңе істемейді.
    ///
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    pub fn assert_zero_valid<T>();

    /// Егер `T` жарамсыз биттік үлгілері болса, оны ешқашан орындау мүмкін емес қауіпті функциялардың қорғаушысы: Бұл статикалық түрде не panic болады, не ештеңе істемейді.
    ///
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    pub fn assert_uninit_valid<T>();

    /// Статикалық `Location` сілтемесін алады, оның қай жерде шақырылғанын көрсетеді.
    ///
    /// Оның орнына [`core::panic::Location::caller`](crate::panic::Location::caller) қолдануды қарастырыңыз.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Мәнді ауқымнан тыс жылжытады.
    ///
    /// Бұл тек [`mem::forget_unsized`] үшін бар;оның орнына қалыпты `forget` `ManuallyDrop` пайдаланады.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Бір типтің мәнінің биттерін басқа тип ретінде қайта түсіндіреді.
    ///
    /// Екі түрдің өлшемдері бірдей болуы керек.
    /// Түпнұсқа да, нәтиже де [invalid value](../../nomicon/what-unsafe-does.html) болмауы мүмкін.
    ///
    /// `transmute` мағыналық жағынан бір түрдің екіншісіне ауысуымен эквивалентті.Ол бастапқы мәннен тағайындалған мәнге биттерді көшіреді, содан кейін түпнұсқаны ұмытады.
    /// Бұл `transmute_copy` сияқты, капюшон астындағы C's `memcpy`-ге тең.
    ///
    /// `transmute` мәні бойынша жұмыс болғандықтан,*аударылған мәндердің* туралануы алаңдаушылық туғызбайды.
    /// Кез-келген басқа функциялар сияқты, компилятор `T` пен `U` екеуінің де сәйкес келуін қамтамасыз етеді.
    /// Алайда,*басқа жерде көрсетілген* мәндерді ауыстыру кезінде (мысалы, сілтемелер, сілтемелер, қораптар ...) қоңырау шалушы көрсетілген мәндердің дұрыс туралануын қамтамасыз етуі керек.
    ///
    /// `transmute` **керемет** қауіпті.Бұл функциямен [undefined behavior][ub] тудырудың көптеген жолдары бар.`transmute` абсолютті соңғы құрал болуы керек.
    ///
    /// [nomicon](../../nomicon/transmutes.html) қосымша құжаттарға ие.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` шынымен пайдалы болатын бірнеше нәрсе бар.
    ///
    /// Меңзерді функция көрсеткішіне айналдыру.Бұл функция көрсеткіштері мен деректер көрсеткіштері әр түрлі болатын машиналарға *портативті емес*.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Өмірді ұзарту немесе инвариантты өмірді қысқарту.Бұл жетілдірілген, өте қауіпті Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Үміт үзбеңіз: `transmute` көптеген қолданыстарына басқа тәсілдер арқылы қол жеткізуге болады.
    /// Төменде қауіпсіз құрылымдармен ауыстырылатын `transmute` кең таралған қосымшалары бар.
    ///
    /// Шикі bytes(`&[u8]`)-ті `u32`, `f64`-ге айналдыру және т.б.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // орнына `u32::from_ne_bytes` қолданыңыз
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // немесе endianness анықтау үшін `u32::from_le_bytes` немесе `u32::from_be_bytes` пайдаланыңыз
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Меңзерді `usize`-ке айналдыру:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Оның орнына `as` кастингін қолданыңыз
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T`-ті `&mut T`-ке айналдыру:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Оның орнына қайтадан табуды қолданыңыз
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T`-ті `&mut U`-ке айналдыру:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Енді `as`-ті біріктіріп, қайта қондырыңыз, `as` `as` тізбегінің транзиттік емес екенін ескеріңіз.
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str`-ті `&[u8]`-ке айналдыру:
    ///
    /// ```
    /// // мұны істеудің жақсы тәсілі емес.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Сіз `str::as_bytes` қолдана аласыз
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Егер сіз әріптер тізбегін басқара алсаңыз, тек байт жолын қолданыңыз
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>`-ті `Vec<Option<&T>>`-ке айналдыру.
    ///
    /// Контейнердің ішкі түрін өзгерту үшін, сіз контейнердің инварианттарының ешқайсысын бұзбауыңыз керек.
    /// `Vec` үшін бұл ішкі типтердің өлшемі *мен туралануы* сәйкес келуі керек дегенді білдіреді.
    /// Басқа контейнерлер типтің, тураланудың немесе тіпті `TypeId` өлшеміне сүйенуі мүмкін, бұл жағдайда трансмютер контейнердің инварианттарын бұзбай мүлдем мүмкін болмайды.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // vector клонын жасаңыз, өйткені оларды кейінірек қайта қолданамыз
    /// let v_clone = v_orig.clone();
    ///
    /// // Трансмутты қолдану: бұл `Vec` деректерінің анықталмаған орналасуына сүйенеді, бұл жаман идея және анықталмаған мінез-құлықты тудыруы мүмкін.
    /////
    /// // Алайда, бұл көшірме емес.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Бұл ұсынылған, қауіпсіз жол.
    /// // Ол бүкіл vector-ді жаңа массивке көшіреді.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Бұл "transmuting"-тен `Vec`-ке көшіруге болмайтын, қауіпті тәсіл, деректердің орналасуына сүйенбей.
    /// // Біз `transmute` сөзбе-сөз қоңырау шалудың орнына, біз сілтеуішті орындаймыз, бірақ (`&i32`) ішкі түрін жаңасына (`Option<&i32>`) түрлендіру тұрғысынан алғанда, мұның бәрі бірдей ескертулерге ие.
    /////
    /// // Жоғарыда келтірілген ақпараттан басқа, [`from_raw_parts`] құжаттамасымен де танысыңыз.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME vec_into_raw_parts тұрақтандырылған кезде оны жаңартыңыз.
    ///     // vector түпнұсқасының түсірілмегеніне көз жеткізіңіз.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` енгізу:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Мұны істеудің бірнеше әдісі бар және келесі (transmute) әдісінде бірнеше проблемалар бар.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // бірінші: трансмуту қауіпсіз емес;ол тек T және
    ///         // U өлшемі бірдей.
    ///         // Екіншіден, дәл осы жерде сізде бір жадқа бағытталған екі өзгермелі сілтемелер бар.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Бұл типтегі қауіпсіздік проблемаларынан арылады;`&mut *` сізге* тек *`&mut T` немесе `* mut T` `&mut T` береді.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // дегенмен, сізде бірдей жадқа бағытталған екі өзгермелі сілтемелер бар.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Стандартты кітапхана осылай жасайды.
    /// // Егер сізге осылай жасау керек болса, бұл ең жақсы әдіс
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Енді бір жадқа бағытталған үш өзгеретін сілтемелер бар.`slice`, ret.0 мәні және ret.1 мәні.
    ///         // `slice` `let ptr = ...` кейін ешқашан пайдаланылмайды, сондықтан оны "dead" ретінде қарастыруға болады, сондықтан сізде тек екі нақты өзгермелі тілім болады.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Бұл ішкі const-ті тұрақты етеді, бірақ бізде const fn-де бірнеше жеке код бар
    // оны `const fn` ішінде қолдануға жол бермейтін тексерулер.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Егер `T` ретінде берілген нақты түрге желім қажет болса, `true` қайтарады;егер `T` үшін берілген нақты тип `Copy`-ті жүзеге асырса, `false` мәнін қайтарады.
    ///
    ///
    /// Егер нақты түрге желім қажет болмаса немесе `Copy`-ті қолданбайтын болса, онда бұл функцияның қайтару мәні анықталмайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы-[`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Меңзерден жылжуды есептейді.
    ///
    /// Бұл бүтін санға және одан түрлендіруге жол бермеу үшін ішкі ретінде жүзеге асырылады, өйткені конверсия лақап ақпаратты лақтырады.
    ///
    /// # Safety
    ///
    /// Бастапқы және нәтижелік көрсеткіштер шекарада немесе бөлінген нысанның соңынан бір байт болуы керек.
    /// Егер кез-келген сілтеме шегі болмаса немесе арифметикалық толып кету болса, қайтарылған мәнді әрі қарай пайдалану анықталмаған әрекетке әкеледі.
    ///
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы-[`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ықтимал ораманы көрсеткіштен есептейді.
    ///
    /// Бұл бүтін санға көшуді болдырмау үшін ішкі ретінде жүзеге асырылады, өйткені конверсия белгілі бір оңтайландыруларды тежейді.
    ///
    /// # Safety
    ///
    /// Ішкі `offset`-тен айырмашылығы, бұл ішкі көрсеткіш бөлінген объектінің соңына немесе одан өткен бір байтқа бағытталу үшін пайда болған көрсеткішті шектемейді және ол екеуінің арифметикасын толықтырады.
    /// Алынған мән жадқа нақты қол жеткізу үшін пайдалану үшін міндетті емес.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы-[`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// `count`*`size_of::<T>()` өлшемі бар және сәйкес келетін ішкі `llvm.memcpy.p0i8.0i8.*`-ге тең.
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ұшпайтын параметр `true`-ге орнатылған, сондықтан оның өлшемі нөлге тең болмаса, ол оңтайландырылмайды.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Сәйкес ішкі `llvm.memmove.p0i8.0i8.*`-ге тең, өлшемі `count* size_of::<T>()` және туралануы бар
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ұшпайтын параметр `true`-ге орнатылған, сондықтан оның өлшемі нөлге тең болмаса, ол оңтайландырылмайды.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Сәйкес ішкі `llvm.memset.p0i8.*`-ге тең, өлшемі `count* size_of::<T>()` және `min_align_of::<T>()` теңестіруі бар.
    ///
    ///
    /// Ұшпайтын параметр `true`-ге орнатылған, сондықтан оның өлшемі нөлге тең болмаса, ол оңтайландырылмайды.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` көрсеткішінен ауыспалы жүктемені орындайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы-[`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` меңзеріне ауыспалы дүкенді орындайды.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы-[`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` көрсеткішінен ауыспалы жүктемені орындайды Меңзерді туралау қажет емес.
    ///
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` меңзеріне ауыспалы дүкенді орындайды.
    /// Меңзерді туралау қажет емес.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// `f32` квадрат түбірін қайтарады
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// `f64` квадрат түбірін қайтарады
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32` бүтін қуатқа дейін көтереді.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64` бүтін қуатқа дейін көтереді.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// `f32` синусын қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// `f64` синусын қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// `f32` косинусын қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// `f64` косинусын қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32`-ті `f32` қуатына дейін көтереді.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64`-ті `f64` қуатына дейін көтереді.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// `f32` экспоненциалын қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// `f64` экспоненциалын қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// `f32` қуатына көтерілген 2 қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// `f64` қуатына көтерілген 2 қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// `f32` табиғи логарифмін қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// `f64` табиғи логарифмін қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// `f32` базалық 10 логарифмін қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// `f64` базалық 10 логарифмін қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// `f32` негізінің 2 логарифмін шығарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// `f64` негізінің 2 логарифмін шығарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` мәндері үшін `a * b + c` қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` мәндері үшін `a * b + c` қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// `f32` абсолютті мәнін қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// `f64` абсолютті мәнін қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Екі минималды `f32` мәнін қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Екі минималды `f64` мәнін қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Екі максималды `f32` мәнін қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Екі максималды `f64` мәнін қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `y`-ден `x`-ге дейінгі белгіні `f32` мәндеріне көшіреді.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `y`-ден `x`-ге дейінгі белгіні `f64` мәндеріне көшіреді.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32`-тен кем немесе оған тең ең үлкен бүтін санды қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64`-тен кем немесе оған тең ең үлкен бүтін санды қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32`-тен үлкен немесе оған тең ең кіші бүтін санды қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64`-тен үлкен немесе оған тең ең кіші бүтін санды қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// `f32` бүтін бөлігін қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// `f64` бүтін бөлігін қайтарады.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// `f32` мәніне ең жақын бүтін санды қайтарады.
    /// Егер аргумент бүтін сан болмаса, нақты өзгермелі нүктелік ерекшелікті тудыруы мүмкін.
    pub fn rintf32(x: f32) -> f32;
    /// `f64` мәніне ең жақын бүтін санды қайтарады.
    /// Егер аргумент бүтін сан болмаса, нақты өзгермелі нүктелік ерекшелікті тудыруы мүмкін.
    pub fn rintf64(x: f64) -> f64;

    /// `f32` мәніне ең жақын бүтін санды қайтарады.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    pub fn nearbyintf32(x: f32) -> f32;
    /// `f64` мәніне ең жақын бүтін санды қайтарады.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    pub fn nearbyintf64(x: f64) -> f64;

    /// `f32` мәніне ең жақын бүтін санды қайтарады.Жартылай жағдайларды нөлден дөңгелектейді.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// `f64` мәніне ең жақын бүтін санды қайтарады.Жартылай жағдайларды нөлден дөңгелектейді.
    ///
    /// Бұл ішкі сипаттаманың тұрақтандырылған нұсқасы
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Алгебралық ережелер негізінде оңтайландыруға мүмкіндік беретін қалқымалы қосу.
    /// Кірістер шектеулі болуы мүмкін.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Алгебралық ережелер негізінде оңтайландыруға мүмкіндік беретін қалқымалы алып тастау.
    /// Кірістер шектеулі болуы мүмкін.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Алгебралық ережелер негізінде оңтайландыруға мүмкіндік беретін қалқымалы көбейту.
    /// Кірістер шектеулі болуы мүмкін.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Алгебралық ережелерге негізделген оңтайландыруға мүмкіндік беретін флоат бөлімі.
    /// Кірістер шектеулі болуы мүмкін.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Алгебралық ережелерге негізделген оңтайландыруға мүмкіндік беретін қалқымалы.
    /// Кірістер шектеулі болуы мүмкін.
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Ауқымнан тыс мәндер үшін undef мәнін қайтаруы мүмкін LLVM's fptoui/fptosi түрлендіріңіз
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] және [`f64::to_int_unchecked`] ретінде тұрақтандырылған.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// `T` бүтін санына қойылған биттер санын қайтарады
    ///
    /// Бұл тұрақтандырылған нұсқалар `count_ones` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// `T` бүтін типіндегі жетекші орнатылмаған биттер санын қайтарады.
    ///
    /// Бұл тұрақтандырылған нұсқалар `leading_zeros` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `0` мәні бар `x` бит енін `T` қайтарады.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` сияқты, бірақ `0` мәні бар `x` берілген кезде `undef` қайтаратындықтан, аса қауіпті.
    ///
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// X001 бүтін санындағы (zeroes) орнатылмаған биттердің соңын қайтарады.
    ///
    /// Бұл тұрақтандырылған нұсқалар `trailing_zeros` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` мәні бар `x` бит енін `T` қайтарады:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` сияқты, бірақ `0` мәні бар `x` берілген кезде `undef` қайтаратындықтан, аса қауіпті.
    ///
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// `T` бүтін типтегі байттарды айналдырады.
    ///
    /// Бұл тұрақтандырылған нұсқалар `swap_bytes` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Биттерді `T` бүтін санына қайтарады.
    ///
    /// Бұл тұрақтандырылған нұсқалар `reverse_bits` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Тексерілген бүтін санды қосуды орындайды.
    ///
    /// Бұл тұрақтандырылған нұсқалар `overflowing_add` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Тексерілген бүтін санды азайтуды орындайды
    ///
    /// Бұл тұрақтандырылған нұсқалар `overflowing_sub` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Тексерілген бүтін көбейтуді орындайды
    ///
    /// Бұл тұрақтандырылған нұсқалар `overflowing_mul` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Нақты бөлуді орындайды, нәтижесінде `x % y != 0` немесе `y == 0` немесе `x == T::MIN && y == -1` анықталмаған мінез-құлық пайда болады
    ///
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// `y == 0` немесе `x == T::MIN && y == -1` болатын жерде анықталмаған әрекетке әкеліп соқтырады, тексерілмеген бөлуді орындайды
    ///
    ///
    /// Бұл ішкі үшін қауіпсіз қаптамалар `checked_div` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// `y == 0` немесе `x == T::MIN && y == -1` кезінде анықталмаған әрекетке әкеліп соқтырылған, тексерілмеген бөлудің қалған бөлігін қайтарады
    ///
    ///
    /// Бұл ішкі үшін қауіпсіз қаптамалар `checked_rem` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Тексерілмеген солға жылжуды орындайды, нәтижесінде `y < 0` немесе `y >= N` кезінде анықталмаған мінез-құлық пайда болады, мұндағы N-биттердің T ені.
    ///
    ///
    /// Бұл ішкі үшін қауіпсіз қаптамалар `checked_shl` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Тексерілмеген оңға жылжуды орындайды, нәтижесінде `y < 0` немесе `y >= N` кезінде анықталмаған мінез-құлық пайда болады, мұндағы N-биттердің T ені.
    ///
    ///
    /// Бұл ішкі үшін қауіпсіз қаптамалар `checked_shr` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// `x + y > T::MAX` немесе `x + y < T::MIN` кезінде анықталмаған әрекетке әкеліп соқтырылған тексерілмеген қосудың нәтижесін қайтарады.
    ///
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// `x - y > T::MAX` немесе `x - y < T::MIN` кезіндегі анықталмаған әрекетке әкеліп соқтырылған алып тастаудың нәтижесін қайтарады.
    ///
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// `x *y > T::MAX` немесе `x* y < T::MIN` кезінде анықталмаған әрекетке әкеліп соқтырылған, көбейтілмеген нәтижені қайтарады.
    ///
    ///
    /// Бұл өзіндік тұрақты аналогы жоқ.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Солға бұруды орындайды.
    ///
    /// Бұл тұрақтандырылған нұсқалар `rotate_left` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Дұрыс айналдыруды орындайды.
    ///
    /// Бұл тұрақтандырылған нұсқалар `rotate_right` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// (A + b) mod 2 <sup>N</sup> қайтарады, мұндағы N-биттердің T ені.
    ///
    /// Бұл тұрақтандырылған нұсқалар `wrapping_add` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// (A, b) mod 2 <sup>N</sup> қайтарады, мұндағы N-биттердің T ені.
    ///
    /// Бұл тұрақтандырылған нұсқалар `wrapping_sub` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// (A * b) mod 2 <sup>N</sup> қайтарады, мұндағы N-биттердің T ені.
    ///
    /// Бұл тұрақтандырылған нұсқалар `wrapping_mul` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Сандық шектерде қаныққан `a + b` есептейді.
    ///
    /// Бұл тұрақтандырылған нұсқалар `saturating_add` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Сандық шектерде қаныққан `a - b` есептейді.
    ///
    /// Бұл тұрақтандырылған нұсқалар `saturating_sub` әдісі арқылы бүтін примитивтерде қол жетімді.
    /// Мысалға,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' нұсқасындағы дискриминанттың мәнін қайтарады;
    /// егер `T` дискриминанты болмаса, `0` мәнін қайтарады.
    ///
    /// Бұл ішкі жүйенің тұрақтандырылған нұсқасы-[`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// `T` типінің `usize`-ге шығарылған нұсқаларының санын қайтарады;
    /// егер `T` нұсқалары болмаса, `0` мәнін қайтарады.Адамның тұрмаған нұсқалары саналады.
    ///
    /// Бұл тұрақтандырылған нұсқасы-[`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust-тің "try catch" құрылымы, ол `try_fn` функциясының көрсеткішін `data` деректер көрсеткішімен орындайды.
    ///
    /// Үшінші аргумент, егер panic пайда болса, аталатын функция.
    /// Бұл функция деректердің сілтемесін және сілтемені ұстап алынған мақсатты ерекше нысанға апарады.
    ///
    /// Қосымша ақпарат үшін компилятордың қайнар көзін және std аулауды жүзеге асыруды қараңыз.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// LLVM бойынша `!nontemporal` дүкенін шығарады (олардың құжаттарын қараңыз).
    /// Мүмкін, ешқашан тұрақты болмайды.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Толығырақ `<*const T>::offset_from` құжаттамасын қараңыз.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Толығырақ `<*const T>::guaranteed_eq` құжаттамасын қараңыз.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Толығырақ `<*const T>::guaranteed_ne` құжаттамасын қараңыз.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Компиляция кезінде бөлу.Жұмыс кезінде қоңырау шалуға болмайды.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Мұнда кейбір функциялар анықталған, өйткені олар кездейсоқ осы модульде тұрақты күйде қол жетімді болды.
// <https://github.com/rust-lang/rust/issues/15702> қараңыз.
// (`transmute` сонымен қатар осы санатқа жатады, бірақ оны `T` пен `U` өлшемдерінің бірдей болуына байланысты орауға болмайды.)
//

/// `ptr`-тің `align_of::<T>()`-ге сәйкес тураланғанын тексереді.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count *size_of::<T>()` байттарын `src`-тен `dst` дейін көшіреді.Қайнар көзі мен тағайындалған орны* сәйкес келмеуі керек *.
///
/// Қабаттасуы мүмкін жад аймақтары үшін оның орнына [`copy`] пайдаланыңыз.
///
/// `copy_nonoverlapping` мағынасы жағынан C's [`memcpy`]-ге тең, бірақ аргумент реті ауыстырылған.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Төмендегі шарттардың кез-келгені бұзылған жағдайда мінез-құлық анықталмайды:
///
/// * `src` `count * size_of::<T>()` байтты оқу үшін [valid] болуы керек.
///
/// * `dst` `count * size_of::<T>()` байт жазу үшін [valid] болуы керек.
///
/// * `src` және `dst` екеуі де дұрыс туралануы керек.
///
/// * «Санау» өлшемімен `src`-тен басталатын жады аймағы *
///   өлшемі: :<T>() `байттар *бірдей өлшеммен `dst`-тен басталатын жады аймағымен* сәйкес келмеуі керек *.
///
/// [`read`] сияқты, `copy_nonoverlapping`, `T`-тің [`Copy`] екендігіне қарамастан, `T`-тің биттік көшірмесін жасайды.
/// Егер `T` [`Copy`] болмаса,*екеуін де*`*src`-тен басталатын аймақтағы және `* dst`-тен басталатын аймақтағы мәндерді қолданып [violate memory safety][read-ownership] жасай алады.
///
///
/// Тиімді көшірілген өлшем болса да ескеріңіз (`count * size_of: :<T>()`)-`0`, көрсеткіштер NULL емес және дұрыс тураланған болуы керек.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] қолмен енгізіңіз:
///
/// ```
/// use std::ptr;
///
/// /// `src` барлық элементтерін `dst` ішіне жылжытады, ал `src` бос қалады.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // `dst`-тің барлық `src`-ті ұстап тұруға жеткілікті сыйымдылығына көз жеткізіңіз.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Есепке шақыру әрқашан қауіпсіз, өйткені `Vec` ешқашан `isize::MAX` байттан артық бөлмейді.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Оның мазмұнын түсірмей, `src` кесіңіз.
///         // Мұны бірінші кезекте, егер panics төмендеуі мүмкін болса, қиындықтар туындамас үшін жасаймыз.
///         src.set_len(0);
///
///         // Екі аймақ қабаттаса алмайды, өйткені өзгермелі сілтемелер бүркеншік атқа ие емес, және екі түрлі vectors бірдей жадқа ие бола алмайды.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Енді `src` мазмұнын сақтайтындығы туралы `dst`-ке хабарлаңыз.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Бұл тексерулерді тек жұмыс уақытында орындаңыз
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Кодген әсерін кішірейту үшін дүрбелең емес.
        abort();
    }*/

    // ҚАУІПСІЗДІК: қауіпсіздік шарты `copy_nonoverlapping` болуы керек
    // қоңырау шалушы қолдайды.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count * size_of::<T>()` байттарын `src`-тен `dst` дейін көшіреді.Қайнар көзі мен тағайындалған орны қабаттасуы мүмкін.
///
/// Егер дерек көзі мен тағайындалуы *ешқашан* қабаттаспаса, оның орнына [`copy_nonoverlapping`] қолдануға болады.
///
/// `copy` мағынасы жағынан C's [`memmove`]-ге тең, бірақ аргумент реті ауыстырылған.
/// Көшіру байттар `src`-тен уақытша массивке көшіріліп, содан кейін массивтен `dst`-ке көшірілгендей болады.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Төмендегі шарттардың кез-келгені бұзылған жағдайда мінез-құлық анықталмайды:
///
/// * `src` `count * size_of::<T>()` байтты оқу үшін [valid] болуы керек.
///
/// * `dst` `count * size_of::<T>()` байт жазу үшін [valid] болуы керек.
///
/// * `src` және `dst` екеуі де дұрыс туралануы керек.
///
/// [`read`] сияқты, `copy`, `T`-тің [`Copy`] екендігіне қарамастан, `T`-тің биттік көшірмесін жасайды.
/// Егер `T` [`Copy`] болмаса, `*src`-тен басталатын аймақтағы және `* dst`-тен басталатын аймақтағы мәндердің екеуі де [violate memory safety][read-ownership] болады.
///
///
/// Тиімді көшірілген өлшем болса да ескеріңіз (`count * size_of: :<T>()`)-`0`, көрсеткіштер NULL емес және дұрыс тураланған болуы керек.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Қауіпті буферден тиімді Rust vector жасаңыз:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` оның типіне және нөлге тең емес туралануы керек.
/// /// * `ptr` `T` типті `elts` сабақтас элементтерін оқу үшін жарамды болуы керек.
/// /// * Бұл элементтер осы функцияны шақырғаннан кейін, егер `T: Copy` болмаса ғана қолданылмауы керек.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // ҚАУІПСІЗДІК: Біздің алдын-ала шарт көздің туралануын және жарамдылығын қамтамасыз етеді,
///     // және `Vec::with_capacity` оларды жазуға ыңғайлы кеңістігімізді қамтамасыз етеді.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // ҚАУІПСІЗДІК: Біз оны осындай үлкен қуатпен бұрын жасадық,
///     // және алдыңғы `copy` бұл элементтерді инициализациялады.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Бұл тексерулерді тек жұмыс уақытында орындаңыз
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Кодген әсерін кішірейту үшін дүрбелең емес.
        abort();
    }*/

    // ҚАУІПСІЗДІК: `copy` үшін қауіпсіздік шартын қоңырау шалушы сақтауы керек.
    unsafe { copy(src, dst, count) }
}

/// `count * size_of::<T>()` байт жадты `dst`-тен `val`-ке дейін орнатады.
///
/// `write_bytes` C-дің [`memset`]-ге ұқсас, бірақ `count * size_of::<T>()` байттарын `val`-ке қояды.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Төмендегі шарттардың кез-келгені бұзылған жағдайда мінез-құлық анықталмайды:
///
/// * `dst` `count * size_of::<T>()` байт жазу үшін [valid] болуы керек.
///
/// * `dst` дұрыс тураланған болуы керек.
///
/// Сонымен қатар, қоңырау шалушы берілген жад аймағына `count * size_of::<T>()` байт жазудың жарамды мәні `T` болатындығына көз жеткізуі керек.
/// Жарамсыз `T` мәнін қамтитын `T` ретінде терілген жад аймағын пайдалану-бұл анықталмаған әрекет.
///
/// Тиімді көшірілген өлшем болса да ескеріңіз (`count * size_of: :<T>()`)-`0`, көрсеткіш NULL болмауы керек және дұрыс тураланған болуы керек.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Негізгі пайдалану:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Жарамсыз мән жасау:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Бұрын ұсталған мәнді нөлдік көрсеткішпен `Box<T>` орнына жазу арқылы жібереді.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Осы уақытта `v` пайдалану немесе түсіру анықталмаған әрекетке әкеледі.
/// // drop(v); // ERROR
///
/// // Тіпті `v` "uses" ағып кетеді, демек, бұл анықталмаған әрекет.
/// // mem::forget(v); // ERROR
///
/// // Шын мәнінде, `v` негізгі орналасу инварианттарына сәйкес жарамсыз, сондықтан *кез келген* операция оған әсер етпейді, бұл анықталмаған тәртіп.
/////
/// // v2 =v болсын;//ҚАТЕ
///
/// unsafe {
///     // Оның орнына дұрыс мән берейік
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Қазір қорап жақсы
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // ҚАУІПСІЗДІК: `write_bytes` үшін қауіпсіздік шартын қоңырау шалушы сақтауы керек.
    unsafe { write_bytes(dst, val, count) }
}